<?php

/**
 * VaultPanel provisioning module for WHMCS.
 *
 * Each WHMCS service is one VaultPanel hosting account, created through
 * VaultPanel's billing API with the service's id as its billing id
 * (whmcs-<service id>). WHMCS creates, suspends, unsuspends, upgrades and
 * terminates it, sets its password, signs the customer in ("Log in to
 * VaultPanel") and reads its disk usage.
 *
 * Server (Setup > Products/Services > Servers): the hostname of your
 * VaultPanel (its panel domain, with a certificate WHMCS trusts), Secure
 * ticked, and a billing API key (Hosting > Billing API in VaultPanel) as the
 * Password or the Access Hash.
 *
 * Requires WHMCS 8 (PHP 7.4 or newer) and VaultPanel with the billing API's
 * account list and sign-in links.
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/ApiClient.php';

use VaultPanel\Whmcs\ApiClient;
use VaultPanel\Whmcs\ApiException;
use WHMCS\Database\Capsule;

// VaultPanel's passwords are at least this long.
if (!defined('VAULTPANEL_MIN_PASSWORD')) {
    define('VAULTPANEL_MIN_PASSWORD', 12);
}

function vaultpanel_MetaData()
{
    return [
        'DisplayName' => 'VaultPanel',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
        'DefaultNonSSLPort' => '80',
        'DefaultSSLPort' => '443',
        'ServiceSingleSignOnLabel' => 'Log in to VaultPanel',
    ];
}

function vaultpanel_ConfigOptions()
{
    return [
        // configoption1: the plan's id (or name).
        'Plan' => [
            'Type' => 'text',
            'Size' => '40',
            'Loader' => 'vaultpanel_PlanLoader',
            'SimpleMode' => true,
            'Description' => 'The VaultPanel hosting plan of this product',
        ],
        // configoption2
        'Server ID' => [
            'Type' => 'text',
            'Size' => '40',
            'Description' => 'Optional: the id of the VaultPanel server new accounts go on. Empty lets VaultPanel choose (the plan\'s server group, then the least busy server).',
        ],
    ];
}

// The plans VaultPanel offers, for the Plan dropdown.
function vaultpanel_PlanLoader(array $params)
{
    $plans = vaultpanel_client($params, 'PlanLoader')->get('/plans');
    $options = [];
    foreach (isset($plans['items']) ? $plans['items'] : [] as $plan) {
        $options[$plan['id']] = $plan['name'];
    }
    if (!$options) {
        throw new Exception('VaultPanel offers no hosting plans yet. Create one under Hosting > Hosting Plans.');
    }
    return $options;
}

function vaultpanel_TestConnection(array $params)
{
    try {
        vaultpanel_client($params, 'TestConnection')->get('/plans');
        return ['success' => true, 'error' => ''];
    } catch (Exception $e) {
        return ['success' => false, 'error' => vaultpanel_error($e)];
    }
}

function vaultpanel_CreateAccount(array $params)
{
    try {
        $plan = trim((string) vaultpanel_param($params, 'configoption1'));
        if ($plan === '') {
            return 'Choose the VaultPanel plan in the product\'s Module Settings first.';
        }
        $details = isset($params['clientsdetails']) ? $params['clientsdetails'] : [];
        $email = trim((string) vaultpanel_param($details, 'email'));
        $company = trim((string) vaultpanel_param($details, 'companyname'));
        $name = trim(vaultpanel_param($details, 'firstname') . ' ' . vaultpanel_param($details, 'lastname'));
        if ($name === '') {
            $name = $company !== '' ? $company : $email;
        }
        $body = ['name' => mb_substr($name, 0, 100), 'email' => $email, 'plan' => $plan, 'externalId' => vaultpanel_externalId($params)];
        if ($company !== '') {
            $body['company'] = mb_substr($company, 0, 100);
        }
        $serverId = trim((string) vaultpanel_param($params, 'configoption2'));
        if ($serverId !== '') {
            $body['serverId'] = $serverId;
        }
        // A shorter password is left out: the customer then signs in from
        // WHMCS ("Log in to VaultPanel"), or sets one with VaultPanel's invite.
        $password = (string) vaultpanel_param($params, 'password');
        if (strlen($password) >= VAULTPANEL_MIN_PASSWORD) {
            $body['password'] = $password;
        }

        $client = vaultpanel_client($params, 'CreateAccount');
        try {
            $client->post('/accounts', $body);
        } catch (ApiException $e) {
            if ($e->errorCode === 'EXTERNAL_ID_TAKEN') {
                // Created before (an order run again): fine while it still exists.
                $account = $client->get('/accounts/' . vaultpanel_ref($params));
                if (isset($account['status']) && $account['status'] === 'terminated') {
                    return 'This service\'s VaultPanel account was removed. Create a new service for a new account.';
                }
            } else {
                $fields = $e->fieldMessages();
                if (isset($fields['email'])) {
                    return 'VaultPanel already has an account for ' . $email . '. VaultPanel has one hosting account per email address, so each client can have one VaultPanel service.';
                }
                throw $e;
            }
        }
        // The welcome email shows the address the customer signs in with.
        vaultpanel_saveUsername($params, $email);
        return 'success';
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

function vaultpanel_SuspendAccount(array $params)
{
    try {
        $reason = trim((string) vaultpanel_param($params, 'suspendreason'));
        vaultpanel_client($params, 'SuspendAccount')->post('/accounts/' . vaultpanel_ref($params) . '/suspend', $reason !== '' ? ['reason' => mb_substr($reason, 0, 300)] : []);
        return 'success';
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

function vaultpanel_UnsuspendAccount(array $params)
{
    try {
        vaultpanel_client($params, 'UnsuspendAccount')->post('/accounts/' . vaultpanel_ref($params) . '/unsuspend');
        return 'success';
    } catch (ApiException $e) {
        return $e->errorCode === 'NOT_SUSPENDED' ? 'success' : vaultpanel_error($e);
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

// Removes the account and everything it owns (websites, apps, databases and
// their files and backups). Running it again finishes what was left.
function vaultpanel_TerminateAccount(array $params)
{
    try {
        vaultpanel_client($params, 'TerminateAccount')->delete('/accounts/' . vaultpanel_ref($params));
        return 'success';
    } catch (ApiException $e) {
        // Never created, or removed in VaultPanel already.
        return $e->status === 404 ? 'success' : vaultpanel_error($e);
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

function vaultpanel_ChangePackage(array $params)
{
    try {
        $plan = trim((string) vaultpanel_param($params, 'configoption1'));
        if ($plan === '') {
            return 'Choose the VaultPanel plan in the product\'s Module Settings first.';
        }
        vaultpanel_client($params, 'ChangePackage')->post('/accounts/' . vaultpanel_ref($params) . '/plan', ['plan' => $plan]);
        return 'success';
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

function vaultpanel_ChangePassword(array $params)
{
    try {
        $password = (string) vaultpanel_param($params, 'password');
        if (strlen($password) < VAULTPANEL_MIN_PASSWORD) {
            return 'VaultPanel passwords have at least ' . VAULTPANEL_MIN_PASSWORD . ' characters.';
        }
        vaultpanel_client($params, 'ChangePassword')->post('/accounts/' . vaultpanel_ref($params) . '/password', ['password' => $password]);
        return 'success';
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

// "Log in to VaultPanel": a sign-in link that works once, for two minutes.
function vaultpanel_ServiceSingleSignOn(array $params)
{
    try {
        $link = vaultpanel_client($params, 'ServiceSingleSignOn')->post('/accounts/' . vaultpanel_ref($params) . '/login');
        return ['success' => true, 'redirectTo' => $link['url']];
    } catch (Exception $e) {
        return ['success' => false, 'errorMsg' => vaultpanel_error($e)];
    }
}

// Disk usage and limits of every service on this server, in MB (WHMCS's
// usage cron). VaultPanel does not count bandwidth.
function vaultpanel_UsageUpdate(array $params)
{
    try {
        $client = vaultpanel_client($params, 'UsageUpdate');
        $usage = [];
        for ($page = 1; $page <= 1000; $page++) {
            $result = $client->get('/accounts', ['page' => $page, 'pageSize' => 100]);
            foreach (isset($result['items']) ? $result['items'] : [] as $account) {
                if (preg_match('/^whmcs-(\d+)$/', (string) (isset($account['externalId']) ? $account['externalId'] : ''), $match)) {
                    $usage[(int) $match[1]] = isset($account['usage']) ? $account['usage'] : [];
                }
            }
            $pages = isset($result['pagination']['totalPages']) ? (int) $result['pagination']['totalPages'] : 1;
            if ($page >= $pages) {
                break;
            }
        }
        $now = date('Y-m-d H:i:s');
        foreach ($usage as $serviceId => $used) {
            Capsule::table('tblhosting')
                ->where('id', $serviceId)
                ->where('server', (int) vaultpanel_param($params, 'serverid'))
                ->update([
                    'diskusage' => isset($used['diskMb']) ? (int) $used['diskMb'] : 0,
                    // 0: the plan has no disk limit.
                    'disklimit' => isset($used['limits']['diskMb']) ? (int) $used['limits']['diskMb'] : 0,
                    'lastupdate' => $now,
                ]);
        }
        return 'success';
    } catch (Exception $e) {
        return vaultpanel_error($e);
    }
}

function vaultpanel_ClientArea(array $params)
{
    $vars = ['serviceId' => (int) vaultpanel_param($params, 'serviceid'), 'account' => null, 'error' => null];
    try {
        $vars['account'] = vaultpanel_summary(vaultpanel_client($params, 'ClientArea')->get('/accounts/' . vaultpanel_ref($params)));
    } catch (Exception $e) {
        $vars['error'] = $e instanceof ApiException && $e->status === 404 ? 'This service has no VaultPanel account yet.' : 'VaultPanel cannot be reached right now. Try again in a few minutes.';
    }
    return ['templatefile' => 'templates/overview', 'vars' => $vars];
}

function vaultpanel_AdminServicesTabFields(array $params)
{
    try {
        $account = vaultpanel_client($params, 'AdminServicesTabFields')->get('/accounts/' . vaultpanel_ref($params));
        $summary = vaultpanel_summary($account);
        $usage = [];
        foreach ($summary['usage'] as $row) {
            $usage[] = htmlspecialchars($row['label'] . ': ' . $row['used'] . ' of ' . $row['limit']);
        }
        $link = vaultpanel_baseUrl($params) . '/customers/' . rawurlencode($account['id']);
        return [
            'VaultPanel account' => '<a href="' . htmlspecialchars($link) . '" target="_blank" rel="noopener">' . htmlspecialchars($account['id']) . '</a> (' . htmlspecialchars($summary['statusLabel']) . ', plan ' . htmlspecialchars($summary['plan']) . ', server ' . htmlspecialchars($summary['server']) . ')',
            'VaultPanel usage' => implode('<br>', $usage),
        ];
    } catch (Exception $e) {
        return ['VaultPanel account' => htmlspecialchars(vaultpanel_error($e))];
    }
}

// ---- Helpers ------------------------------------------------------------------

function vaultpanel_param(array $values, string $key)
{
    return isset($values[$key]) ? $values[$key] : '';
}

// The billing id of the service's account.
function vaultpanel_externalId(array $params)
{
    return 'whmcs-' . (int) vaultpanel_param($params, 'serviceid');
}

function vaultpanel_ref(array $params)
{
    return rawurlencode(vaultpanel_externalId($params));
}

// https://<hostname>[:port] from the server's settings.
function vaultpanel_baseUrl(array $params)
{
    $host = trim((string) vaultpanel_param($params, 'serverhostname'));
    if ($host === '') {
        $host = trim((string) vaultpanel_param($params, 'serverip'));
    }
    if ($host === '') {
        throw new ApiException('Set the hostname of your VaultPanel in this server\'s settings (Setup > Products/Services > Servers).');
    }
    $prefix = (string) vaultpanel_param($params, 'serverhttpprefix');
    if ($prefix !== 'http' && $prefix !== 'https') {
        $secure = vaultpanel_param($params, 'serversecure');
        $prefix = $secure === '' || $secure === false || $secure === 'off' || $secure === '0' ? 'http' : 'https';
    }
    $port = trim((string) vaultpanel_param($params, 'serverport'));
    $default = $prefix === 'https' ? '443' : '80';
    return $prefix . '://' . $host . ($port !== '' && $port !== $default ? ':' . $port : '');
}

function vaultpanel_client(array $params, string $action)
{
    $key = trim((string) vaultpanel_param($params, 'serveraccesshash'));
    if ($key === '') {
        $key = trim((string) vaultpanel_param($params, 'serverpassword'));
    }
    if (strpos($key, 'vpk_') !== 0) {
        throw new ApiException('Paste a VaultPanel billing API key (it starts with vpk_) into this server\'s Password or Access Hash. Create one in VaultPanel under Hosting > Billing API.');
    }
    $secrets = array_values(array_filter([$key, (string) vaultpanel_param($params, 'password')]));
    $log = function ($call, $request, $response) use ($action, $secrets) {
        if (function_exists('logModuleCall')) {
            logModuleCall('vaultpanel', $action . ' ' . $call, $request, $response, '', $secrets);
        }
    };
    return new ApiClient(vaultpanel_baseUrl($params), $key, 30, $log);
}

function vaultpanel_error(Exception $e)
{
    if ($e instanceof ApiException && $e->status === 401) {
        return 'VaultPanel refused the API key. Create a billing API key in VaultPanel (Hosting > Billing API) and paste it into this server\'s Password or Access Hash.';
    }
    if ($e instanceof ApiException && $e->errorCode === 'RATE_LIMITED') {
        return 'VaultPanel is receiving too many billing calls. Try again in a minute.';
    }
    return 'VaultPanel: ' . $e->getMessage();
}

function vaultpanel_saveUsername(array $params, string $email)
{
    try {
        if (class_exists(Capsule::class) && $email !== '') {
            Capsule::table('tblhosting')->where('id', (int) vaultpanel_param($params, 'serviceid'))->update(['username' => $email]);
        }
    } catch (Exception $e) {
        // Only what the service page shows as the username.
    }
}

// The account as the client area and the admin tab show it.
function vaultpanel_summary(array $account)
{
    $statuses = ['active' => 'Active', 'suspended' => 'Suspended', 'terminated' => 'Removed'];
    $status = isset($account['status']) ? $account['status'] : '';
    $used = isset($account['usage']) ? $account['usage'] : [];
    $limits = isset($used['limits']) ? $used['limits'] : [];
    $rows = [];
    $kinds = ['diskMb' => 'Disk (MB)', 'websites' => 'Websites', 'applications' => 'Apps', 'databases' => 'Databases', 'cronJobs' => 'Cron jobs'];
    foreach ($kinds as $key => $label) {
        if (!array_key_exists($key, $used)) {
            continue;
        }
        $limit = array_key_exists($key, $limits) && $limits[$key] !== null ? (string) $limits[$key] : 'unlimited';
        $rows[] = ['label' => $label, 'used' => (string) $used[$key], 'limit' => $limit];
    }
    return [
        'id' => isset($account['id']) ? $account['id'] : '',
        'status' => $status,
        'statusLabel' => isset($statuses[$status]) ? $statuses[$status] : $status,
        'plan' => isset($account['plan']['name']) ? $account['plan']['name'] : '',
        'server' => isset($account['server']['name']) ? $account['server']['name'] : '',
        'usage' => $rows,
    ];
}
