<?php

// The VaultPanel billing API (docs/api.md, "Billing API"), with an API key
// from VaultPanel's Hosting > Billing API page.

namespace VaultPanel\Whmcs;

class ApiException extends \Exception
{
    /** @var string|null VaultPanel's error code, such as EXTERNAL_ID_TAKEN */
    public ?string $errorCode;

    /** @var int The HTTP status, 0 when VaultPanel could not be reached */
    public int $status;

    /** @var array Field problems ([{ field, message }]) or other details */
    public array $details;

    public function __construct(string $message, ?string $errorCode = null, int $status = 0, $details = [])
    {
        parent::__construct($message);
        $this->errorCode = $errorCode;
        $this->status = $status;
        $this->details = is_array($details) ? $details : [];
    }

    // The field problems of a refused request, by field.
    public function fieldMessages(): array
    {
        $out = [];
        foreach ($this->details as $detail) {
            if (is_array($detail) && isset($detail['field'], $detail['message'])) {
                $out[(string) $detail['field']] = (string) $detail['message'];
            }
        }
        return $out;
    }
}

class ApiClient
{
    private string $baseUrl;
    private string $apiKey;
    private int $timeout;
    /** @var callable|null */
    private $logger;

    // logger(string $call, string $request, string $response) records each
    // call, for WHMCS's module log.
    public function __construct(string $baseUrl, string $apiKey, int $timeout = 30, ?callable $logger = null)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->apiKey = $apiKey;
        $this->timeout = $timeout;
        $this->logger = $logger;
    }

    public function get(string $path, array $query = [])
    {
        return $this->request('GET', $path . ($query ? '?' . http_build_query($query) : ''), null);
    }

    public function post(string $path, array $body = [])
    {
        return $this->request('POST', $path, $body);
    }

    public function delete(string $path)
    {
        return $this->request('DELETE', $path, null);
    }

    // The "data" of VaultPanel's reply. Throws ApiException with VaultPanel's
    // error code and message when it refuses or cannot be reached.
    private function request(string $method, string $path, ?array $body)
    {
        $headers = ['Authorization: Bearer ' . $this->apiKey, 'Accept: application/json', 'User-Agent: VaultPanel-WHMCS/1.0'];
        $payload = '';
        $ch = curl_init($this->baseUrl . '/api/v1/billing' . $path);
        if ($body !== null) {
            $payload = (string) json_encode((object) $body);
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        }
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = $raw === false ? curl_error($ch) : '';
        if ($this->logger) {
            call_user_func($this->logger, $method . ' ' . $path, $payload, $raw === false ? $curlError : (string) $raw);
        }
        if ($raw === false) {
            throw new ApiException('Could not reach VaultPanel at ' . $this->baseUrl . ': ' . $curlError, 'UNREACHABLE');
        }
        $json = json_decode((string) $raw, true);
        if ($status >= 200 && $status < 300 && is_array($json)) {
            return $json['data'] ?? null;
        }
        $error = is_array($json) && isset($json['error']) && is_array($json['error']) ? $json['error'] : [];
        $code = isset($error['code']) ? (string) $error['code'] : null;
        $details = $error['details'] ?? [];
        $exception = new ApiException(isset($error['message']) ? (string) $error['message'] : 'VaultPanel answered HTTP ' . $status, $code, $status, $details);
        // A refused form names its fields.
        $fields = $exception->fieldMessages();
        if ($fields) {
            $parts = [];
            foreach ($fields as $field => $text) {
                $parts[] = ($field !== '' ? $field . ': ' : '') . $text;
            }
            $exception = new ApiException(implode('; ', $parts), $code, $status, $details);
        }
        throw $exception;
    }
}
