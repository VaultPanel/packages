{* The VaultPanel account of this service, in the WHMCS client area. *}
{if $error}
    <div class="alert alert-warning">{$error|escape}</div>
{elseif $account}
    <div class="row">
        <div class="col-sm-6">
            <table class="table table-sm">
                <tr><td>Status</td><td>{$account.statusLabel|escape}</td></tr>
                <tr><td>Plan</td><td>{$account.plan|escape}</td></tr>
                <tr><td>Server</td><td>{$account.server|escape}</td></tr>
            </table>
        </div>
        <div class="col-sm-6">
            <table class="table table-sm">
                {foreach $account.usage as $row}
                    <tr><td>{$row.label|escape}</td><td>{$row.used|escape} of {$row.limit|escape}</td></tr>
                {/foreach}
            </table>
        </div>
    </div>
    {if $account.status eq 'active'}
        <p>
            <a href="clientarea.php?action=productdetails&amp;id={$serviceId}&amp;dosinglesignon=1" class="btn btn-primary" target="_blank" rel="noopener">Log in to VaultPanel</a>
        </p>
    {/if}
{/if}
