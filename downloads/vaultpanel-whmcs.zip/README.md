# VaultPanel module for WHMCS

Sell VaultPanel hosting from WHMCS. Each WHMCS service is one VaultPanel hosting account: WHMCS
creates it when an order is paid, suspends and unsuspends it with the invoices, changes its plan on
upgrades, sets its password, removes it on termination, signs the customer in with **Log in to
VaultPanel**, and shows its disk usage.

It works through VaultPanel's [billing API](../../docs/api.md#billing-api). Requires WHMCS 8 (PHP 7.4
or newer, with curl) and a VaultPanel with the billing API's account list and sign-in links.

## Install

1. Download the module from
   [installer.vaultpanel.net/downloads/vaultpanel-whmcs.zip](https://installer.vaultpanel.net/downloads/vaultpanel-whmcs.zip)
   (checksum in [SHA256SUMS](https://installer.vaultpanel.net/downloads/SHA256SUMS)), unzip it and copy
   its `modules/servers/vaultpanel` into your WHMCS folder, so the module is at
   `<whmcs>/modules/servers/vaultpanel/vaultpanel.php`.
2. In VaultPanel, open **Hosting > Billing API**, click **New API key**, name it "WHMCS" and copy
   the key (it starts with `vpk_` and is shown once).
3. VaultPanel needs an address with a certificate WHMCS trusts: set a panel domain under
   **System > Panel Domain** (for example `cp.example.com`). The self-signed certificate of the
   panel's own port is refused.
4. In WHMCS, **System Settings > Servers > Add New Server**:
   - **Hostname**: the panel domain, such as `cp.example.com`.
   - **Module**: VaultPanel.
   - **Password** (or **Access Hash**): the API key.
   - **Secure**: ticked. Port: leave empty for 443.
   - Click **Test Connection**. Then save, and put the server in a server group.
5. **System Settings > Products/Services**: create a product (type Hosting Account), and on
   **Module Settings** pick VaultPanel, the server group, and the VaultPanel **Plan** (the list comes
   from your panel; plans are created in VaultPanel under **Hosting > Hosting Plans**). **Server ID**
   is optional: empty lets VaultPanel pick the server (the plan's server group, then the least busy).
   Choose "Automatically setup the product as soon as the first payment is received".

## What it does

| WHMCS | VaultPanel |
| --- | --- |
| Create | A hosting account on the product's plan, billing id `whmcs-<service id>`, named after the client, with the client's email. The service password is used when it has at least 12 characters; otherwise the customer signs in from WHMCS, or sets one with VaultPanel's invite. The service's username becomes the email the customer signs in with. Running Create again for the same service is fine. |
| Suspend / Unsuspend | Turns the account's websites off, stops its apps and pauses its cron jobs, with the suspension reason; and back on. |
| Terminate | Removes the account and everything it owns: websites, apps, databases and their files and backups. Running it again finishes what was left. |
| Change Package | Moves the account to the new product's plan. Nothing is deleted when it is over the smaller plan's limits; new things are refused. |
| Change Password | Sets the VaultPanel password (at least 12 characters) and signs the customer out elsewhere. |
| Log in to VaultPanel | A sign-in link that works once, for two minutes. It skips the customer's two-factor code, like the password the billing system can set. Suspended accounts get none. |
| Usage update (WHMCS cron) | Disk usage and limit in MB for every service on the server (0 is no limit). VaultPanel does not count bandwidth. |
| Client area | Status, plan, server, usage against the plan's limits, and the sign-in button. |
| Admin service tab | The VaultPanel account id (a link to it in VaultPanel), status, plan, server and usage. |

Every call is in VaultPanel's audit log as the API key, and in WHMCS's module log
(**System Logs > Module Log**) with the key and passwords hidden.

## Limits

- VaultPanel has one hosting account per email address, so a client can have one VaultPanel service.
  A second service for the same client fails with that reason.
- No domain is set up on order: the customer adds websites in VaultPanel.
- Moving a service to another server in WHMCS does not move the account between VaultPanel servers.

## Tests

`php integrations/whmcs/tests/run.php` runs the module against a stand-in for the billing API
(`tests/mock-api.php`, served by PHP's built-in server), with WHMCS's database and module log faked.
CI runs it on PHP 7.4 and 8.3.
