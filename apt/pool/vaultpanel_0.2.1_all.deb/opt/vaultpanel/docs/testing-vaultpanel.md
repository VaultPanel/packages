# Try VaultPanel

These steps follow [development.md](development.md) on `main`. Part 1 runs the panel on your own computer. Part 2 connects a server so you can see live stats and run jobs.

## Part 1: run the panel on your computer

You need **Node.js 22+**, **Docker** (it runs MariaDB and Redis for you) and **git**.

```sh
git clone https://github.com/VaultPanel/VaultPanel.git
cd VaultPanel
docker compose -f docker/compose.yml up -d
cp .env.example .env
```

Open `.env` and set the secret key to a random value. You can generate one with `openssl rand -hex 32`:

```
VAULTPANEL_SECRET_KEY=<paste the 64 hex characters here>
```

Then install the dependencies and create the tables:

```sh
npm install
npm run db:migrate
```

Now start three processes, each in its own terminal window:

```sh
npm run dev:backend     # the API; prints the setup token
npm run dev:worker      # background tasks (offline detection, timeouts)
npm run dev:frontend    # the UI at http://localhost:5173
```

1. In the `dev:backend` output, find the line `No accounts exist yet. Create the owner account at /setup with setup token: …` and copy the token.
2. Open http://localhost:5173/setup, paste the token and create your owner account.
3. Things to try:
   - Turn on two-factor sign-in in **Account**, then sign out and back in.
   - Invite a user from **Users**, open the invite link in a private window, and sign in with a lower role. Check that the restricted pages and buttons are hidden or refused.
   - Look at **Audit log**: it lists every sign-in, invite and denied action.
   - Switch between light and dark mode, and narrow the window to phone width.

## Part 2: connect a server

The agent needs **Linux with systemd** and **Node.js 20+**. It cannot run on macOS or Windows itself, and a VPS on the internet can't reach `localhost` on your computer. So pick one of these:

### Option A: put everything on a test VPS (recommended)

Use a throwaway Ubuntu VPS, not a server you care about, because the agent runs as root and can restart services and reboot.

1. On the VPS, install Node.js 22 and Docker, then follow Part 1 there.
2. From your computer, open an SSH tunnel so the UI shows up in your browser:

   ```sh
   ssh -L 5173:localhost:5173 you@your-vps
   ```

   Then browse to http://localhost:5173 on your computer.

   Or, to open it on the VPS's public IP instead of a tunnel:
   - Run the UI with `npm run dev -w @vaultpanel/frontend -- --host 0.0.0.0`. Note that `npm run dev:frontend -- --host` does not pass the flag on.
   - Set `VAULTPANEL_PUBLIC_URL=http://YOUR_VPS_IP:5173` in `.env` and restart the backend.
   - Allow the port with `ufw allow 5173/tcp` and browse to `http://YOUR_VPS_IP:5173`.
   - This is plain HTTP open to the internet, so use a test password. For a domain name instead of an IP, Vite also needs `server.allowedHosts`.

3. Once the "panel connects its own server" change is merged (see "Trying the automatic connection" below), skip this step and the next: the VPS shows up in the panel by itself when the backend starts as root. Until then: in the panel, go to **Servers → Add server**. Copy the install command it shows and **add `--insecure-http` at the end**. This flag is needed because the test panel uses plain HTTP. Run it on the VPS:
   ```sh
   curl -fsSL http://localhost:5173/api/v1/agent/install.sh \
     | sudo bash -s -- --panel http://localhost:5173 --token vpe_… --insecure-http
   ```
4. Within about 15 seconds the server shows as online, with CPU, memory, disk and network charts.

### Option B: a Linux computer or WSL, without installing a service

If Part 1 runs on Linux (or WSL with systemd turned on), add a server in the UI, copy only its `vpe_…` token, and run:

```sh
node agent/src/cli.js register --panel http://localhost:5173 --token vpe_… --config ./tmp/agent.json --insecure-http
node agent/src/cli.js run --config ./tmp/agent.json
```

### Things to try once a server is connected

- **Services**: check the status of a service such as `ssh` or `cron`, then restart one. Each action becomes a job; open it in **Jobs** to watch its live log.
- **Processes**: list the processes by CPU or memory use.
- **Reboot** (only on a throwaway VPS): it asks you to confirm, the server goes offline, and it comes back on its own.
- Stop the agent (`sudo systemctl stop vaultpanel-agent`). After about 90 seconds the server shows as offline.
- Try to restart `vaultpanel-agent` itself from the panel. It is refused on purpose.

### Trying Phase 2 (monitoring and alerts, now on main)

1. On the VPS: `cd ~/VaultPanel && git fetch && git checkout main && git pull && npm install && npm run db:migrate`, then restart the backend, the worker and the frontend.
2. Your agent is older than this version. Open the server's page and run the upgrade command it shows (it keeps the registration).
3. Open **Monitoring** and **Alerts** (sidebar, under Monitoring) and **Services** (under Infrastructure). To see an alert fire, add a rule on **Alerts → Rules**, for example disk above a low percentage with "Immediately".
4. On the server page, try **Logs**, **Stop** and **Start** on a service, and stop a harmless process (run `sleep 1000` over SSH, then Stop it from **Processes**).

### Trying Phase 3 (websites, domains, SSL and files)

This is on `main` now.

1. On the VPS:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Then restart the backend, the worker and the frontend (same commands as before).
2. Open the server's page and run the agent upgrade command it shows (it keeps the registration). Websites need agent 0.3.0.
3. Open the ports websites use: `ufw allow 80,443/tcp` (if ufw is on).
4. On the server page, open the **Websites** tab. In the **Web stack** card, install NGINX, PHP-FPM and Certbot (one click each, or "Install all missing"). This runs `apt-get` and takes a minute or two; watch it in the drawer.
5. Click **New website**. Pick **Static site**, enter a domain, and create it. The drawer shows the agent creating the Linux user, folder and NGINX config, then checking the site answers.
   - With a real domain: point its A record at the VPS IP first. Then `http://your-domain/` shows the placeholder page.
   - Without a domain: use any name like `test.example.com` and check it from the VPS with `curl -H "Host: test.example.com" http://127.0.0.1/`.
6. On the website page:
   - **Domains**: click **Check DNS** to see whether each domain points at this server.
   - **Files**: open `public/index.html`, edit it, Save, and reload the site. Try upload, new folder, rename and delete too.
   - **Logs**: the NGINX access and error logs of the site.
   - **SSL** (needs a real domain pointing at the VPS and port 80 open): tick **Use the Let's Encrypt staging service** for a first try, then issue. After it works, issue again without staging for a trusted certificate. HTTP then redirects to HTTPS.
   - **Settings**: switch type (for example to **Reverse proxy** on port 3000, then run any app on that port), disable and enable, or delete (choose whether to delete the files too).
7. Also try a **PHP site**: create one, upload an `info.php` with `<?php phpinfo();` in **Files** under `public/`, and open it in the browser. It runs as the site's own user.
8. **Domains**, **SSL Certificates** and **File Manager** in the sidebar list everything across servers. The dashboard shows a websites count.

### Trying Phase 4 (apps, Git deploy, PM2 and databases)

This is on `main` now.

1. On the VPS:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Then restart the backend, the worker and the frontend (same commands as before).
2. Run the agent upgrade command shown on the server's page. Apps and databases need agent 0.4.0.
3. On the server page, open the **Applications** tab. In the **App runtime** card, install Git and PM2 (and Python if you want a Python app). On the **Databases** tab, install MariaDB from the **Database server** card. Each runs `apt-get` (or `npm install -g pm2`) and shows its log in the drawer.
4. Go to **Applications** in the sidebar and click **New application**:
   - Runtime **Node.js**, repository `https://github.com/heroku/node-js-getting-started.git`, branch `main`, port `3000`, start command `npm start`.
   - Domain: a real domain whose A record points at the VPS, or a made-up one like `hello.example.com`.
   - Leave **Deploy as soon as the app is set up** ticked and create it. The drawer shows each stage: prepare, fetch, install, build, configure, start (health check).
5. Check it works:
   - With a real domain: open `http://your-domain/`.
   - Without one: `curl -H "Host: hello.example.com" http://127.0.0.1/` on the VPS.
   - The **Overview** tab shows the PM2 process (pid, memory, restarts). Try **Restart** and **Stop**/**Start**.
6. On the app page, try each tab:
   - **Environment**: add `GREETING=hello`, save, then click **Apply and restart** (the banner says when saved settings are not live yet).
   - **Logs**: the app's output and error logs.
   - **Deployments**: click **Deploy** again, then **Roll back** on an older release. Rolling back is instant because old releases are kept.
   - **Domains**: issue SSL here exactly as for a website (staging first).
   - **Databases**: **New database** creates a MariaDB database and user for this app and adds `DATABASE_URL`, `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` and `DB_PASSWORD` to its environment. Click **Apply and restart** so the app sees them.
   - **Settings**: build and run commands, the deploy key (add it to a private repository as a read-only deploy key), **Push to deploy**, and delete.
7. Push to deploy: in **Settings**, turn on **Push to deploy** and copy the URL and the secret (both shown once). In GitHub, add the URL under the repository's Settings, Webhooks, with content type `application/json`, the secret in **Secret**, and the "push" event. Pushes to the app's branch then deploy it. The panel URL must be reachable from GitHub, so this needs the panel on a public address.
8. **Databases** in the sidebar lists every database and user. Try **New user** with read-only access, and **Password** on a user to show it (each look is recorded in the audit log). PostgreSQL and Redis are shown as "Coming later".
9. A Python app works the same way: runtime **Python**, for example `https://github.com/render-examples/flask-hello-world.git` with start command `gunicorn app:app --bind 127.0.0.1:$PORT`.

### Trying Phase 5 (backups, cron jobs, webhooks and logs)

This is on the Phase 5 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase5-backups-cron-logs-ln30ov && git checkout claude/phase5-backups-cron-logs-ln30ov`
in step 1 instead of `git checkout main && git pull`.

1. On the VPS:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Then restart the backend, the worker and the frontend (same commands as before). The worker matters here: it takes scheduled backups and sends webhooks.
2. Run the agent upgrade command shown on the server's page. Backups, cron jobs and logs need agent 0.5.0.
3. On the server page, open the new **Automation** tab. If the **Scheduler** card says Cron is not installed, install it there (most Ubuntu servers already have it).
4. **Backups** (sidebar, under Automation):
   - Click **Back up now** and pick a website, app or database from Phase 3 or 4. The drawer shows the log; the backup appears with its size.
   - Change something: edit a file in the site's **Files** tab, or add a row to the database.
   - On the backup, click **Restore**, keep **Back up the current state first** ticked, and type the name to confirm. The file or row comes back, and a "Safety copy before a restore" backup of the changed state is kept.
   - Click **Download** on a backup: the panel copies it from the server first, then your browser downloads it.
   - **New schedule**: pick something, choose a preset such as "Every day at 03:00" or **Custom** with your own cron expression and your time zone, and how many to keep. The **Schedules** tab shows the next backup. To see it work quickly, use the custom expression `*/5 * * * *` with keep 2, wait 15 minutes, and check that only the newest 2 scheduled backups are left.
   - Backups stay on the server they were made on (`/var/backups/vaultpanel`, root only) unless you choose S3-compatible storage or another server over SFTP (see "Trying S3-compatible backup storage" and "Trying SFTP backup storage" below).
5. Each website, app and database also has its own **Backups** tab (databases: the **Backups** link on each row).
6. **Cron jobs** (sidebar, or the **Cron** tab of a website or app):
   - Click **New cron job**, pick a website, give it a name, choose **Custom** with the schedule `* * * * *` (every minute), and the command `date`. Save, then wait a minute: the job's **Runs** show the output and exit code.
   - Click **Run now** to run it at once.
   - Try a failing command such as `ls /no-such-folder`: the run shows as failed with the error.
   - Commands run as the site's own user, without a shell, so `|`, `>` and `&&` are refused. For those, put a script in the site's folder (for example `bash /var/www/<site>/run.sh`).
   - For an app, tick **Load the app’s environment variables** to give the command its `.env` (for example `npm run cleanup`).
7. **Logs** (sidebar, under Monitoring): read the server's journal, the kernel log, sign-ins (SSH and sudo) and cron. Try the level and time filters, **Find text** (for example `sshd`), and **Refresh every 10 s**.
8. **Webhooks** (sidebar, owners and admins): add one to be told when things happen.
   - For a quick test, open https://webhook.site, copy your unique URL, and add it with format **JSON** and a few events. The signing secret is shown once.
   - Click **Test**, then **Deliveries** to see the answer. A failed delivery is retried after 1, 5 and 30 minutes, and **Send again** sends it again.
   - Slack and Discord: create an incoming webhook in Slack (or in a Discord channel's Integrations) and choose that format.
   - Back up something or run a failing cron job to see real events arrive.
9. The dashboard has a **Backups** card, and the **Alerts** page now points to webhooks for notifications.

### Trying the automatic connection of the panel's own server

The server VaultPanel runs on now connects itself: no **Add server**, no install command. This is on its own pull request until it is merged. To try it before then, use
`git fetch origin claude/auto-connect-local-server-yzbi5x && git checkout claude/auto-connect-local-server-yzbi5x`
in step 1 instead of `git checkout main && git pull`.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
2. Stop the backend (Ctrl+C) and start it again with `npm run dev:backend`. Before the API starts, you see a line starting with `[vaultpanel]`:
   - `Connected this server to the panel as "<hostname>".` The agent was installed as the `vaultpanel-agent` service, using the same Node.js the panel runs on (so the old "Node.js 20 or newer is required (found v18…)" error cannot happen here).
   - Or, if you had already connected the VPS with **Add server**: `"<name>" was already connected by hand; it is now marked as the server this panel runs on.` Nothing is installed twice.
3. Open **Servers**: the VPS is there with a blue **This server** label and goes **Online** within about 15 seconds. The dashboard shows the same label. No `--insecure-http` is needed: the agent talks to the backend directly on `127.0.0.1:4000`, inside the VPS.
4. If an earlier **Add server** attempt never connected, its entry stays as **Waiting for agent**. Remove it from its **Settings** tab.
5. Restart the backend again: the line now says `This server is connected to the panel as "<hostname>".` and nothing else changes.
6. Updates: after a later `git pull`, restarting the backend also updates this server's agent, so you no longer need the upgrade command for it (other servers still use it).
7. Optional checks:
   - `systemctl status vaultpanel-agent` shows it running, and `grep panelUrl /etc/vaultpanel-agent/config.json` shows `http://127.0.0.1:4000`.
   - Remove the server from its **Settings** tab and restart the backend: it is **not** added back, and the line says how to add it again (`npm run connect-local -- --force`).
   - To turn the automatic connection off, put `VAULTPANEL_LOCAL_AGENT=false` in `.env`.
   - If the backend does not run as root, the line says so; run `npm run connect-local` once as root instead.

### Trying Phase 6 (security: firewall, SSH, Fail2ban, updates, sign-in)

This is on the Phase 6 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase6-security-hardening-8p73gj && git checkout claude/phase6-security-hardening-8p73gj`
in step 1 instead of `git checkout main && git pull`.

**Before you start, so you cannot lock yourself out:**

- Have your provider's web console ready (Contabo: customer panel, your VPS, **VNC**). It works even if SSH or the firewall goes wrong.
- Check `VAULTPANEL_PUBLIC_URL` in `~/VaultPanel/.env` is the address you open the panel on (for you `http://YOUR_VPS_IP:5173`). On the panel's own server VaultPanel keeps that port open, together with SSH. If you open the panel some other way, fix this first.
- Keep one SSH session open while you change SSH settings. Open sessions stay connected; test a new login in a second window before closing the first.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Restart the backend as root (it updates this server's agent to 0.6.0 by itself), the worker and the frontend. Other servers: run the upgrade command on their page.
2. **Security** in the sidebar opens the **Security overview**: a score for each server (firewall, root sign-in, SSH passwords, brute-force protection, automatic updates, waiting updates). It fills in within about 5 minutes of the agent update. The server page also has a new **Security** tab with everything in one place.
3. **Firewall** (Security, Firewall):
   - If UFW is not installed, click **Install UFW** (installing changes nothing yet).
   - Read the blue **Lockout protection** box: it names the SSH port and the panel port that always stay open.
   - Click **Turn on**. The confirmation lists what is kept open (SSH, the panel, and ports 80 and 443 when NGINX is installed). After it finishes, the panel and SSH still work, and the rule list shows them with "VaultPanel: keep … reachable".
   - **Add rule**: try **Allow** with the HTTPS shortcut, or an app port. Then try **Deny** on port 22 from anyone: it is refused with the reason. A deny rule for your own address is refused too (the form shows your address).
   - Delete a rule with the bin icon. Deleting the only rule that keeps SSH open is refused.
   - Rules made with `ufw` by hand are listed as "Added outside VaultPanel" and are left alone.
4. **SSH** (Security, SSH):
   - On your computer, show your public key: `cat ~/.ssh/id_ed25519.pub` (no key yet? `ssh-keygen -t ed25519`). Click **Add key** and paste it.
   - In a second terminal, check you can log in with the key: `ssh root@YOUR_VPS_IP`.
   - Untick **Allow password sign-in** and click **Save SSH settings**. Root sign-in "Keys only" is the safe choice. If no administrator has a key, the agent refuses this, so you cannot lock yourself out.
   - **Failed SSH sign-ins** lists who tried to guess passwords in the last 24 hours; **Block** adds a firewall rule for one address.
5. **Brute-force protection** (same page, or the server's Security tab): install Fail2ban if needed, tick **Protect SSH**, click **Add my address** so your own address is never blocked, and save. Blocked addresses show below with **Unblock**.
6. **Security updates**: shows how many security updates are waiting, turns daily automatic updates on or off, and **Install security updates now** runs them (several minutes; the server is not restarted; "Restart needed" appears when it should be).
7. **Two-factor sign-in** for the panel:
   - **Account**: turn on two-factor sign-in. You now get **10 recovery codes**: download or copy them. **Make new codes** later replaces them; the page shows how many are left.
   - Sign out and back in, click **Lost your app? Use a recovery code**, and use one. It works once; you land on Account with how many are left.
   - **Account, Where you're signed in** lists your browsers; sign one out, or **Sign out everywhere else**.
   - **Security, Authentication** (owners): choose who must use two-factor sign-in (**Owners and admins**, or **Everyone**). You must have it on yourself first. Someone it covers who has not set it up only sees a setup screen until they do. The same page lists everyone's two-factor state and signed-in browsers, with **Turn off 2FA** for someone who lost their phone (also on Users, Edit).
8. **App limits**: on an app's **Settings** tab, set **CPU** (100 = one core) and **Memory (MiB)**, save, and apply the changes. The app restarts under the limits. Apps also can no longer read other users' home folders.
9. If something is refused with **LOCKOUT_REFUSED**, VaultPanel is protecting your way in; the message says what to add first. If you get locked out anyway, use the web console: `ufw disable`, or remove `/etc/ssh/sshd_config.d/00-vaultpanel.conf` and run `systemctl reload ssh`.

### Trying Phase 7 (several servers: groups, bulk actions, agent updates)

This is on the Phase 7 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase7-multi-server-xebgeb && git checkout claude/phase7-multi-server-xebgeb`
in step 1 instead of `git checkout main && git pull`.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Restart the backend as root (it updates this server's agent to 0.7.0 by itself), the worker and the frontend.
2. Phase 7 is about several servers, so connect a second one if you can (a second small VPS is enough): **Servers**, **Add server**, and run the install command on it as root. With only one server everything below still works; the lists just have one row.
3. **Server Groups** (sidebar, under Infrastructure): click **New group**, call it "Production", pick a color and tick your servers. Make a second group too ("Europe"); a server can be in both. Each card shows how many servers are online, firing alerts, and average CPU, memory and disk. Open a group to see its servers side by side, and **Edit** or **Delete** it (deleting a group never touches its servers).
4. **Servers** page: each server shows its groups, there is an **All groups** filter, and an **Agent** column with an **Update** badge when an agent is older than the panel's.
5. **Bulk actions**: on **Servers**, tick two or more servers and click **Run on selected** (or open a group and click **Run on group**).
   - Pick **Restart a service**, type `nginx` (if NGINX is installed), choose **One server at a time**, and start. The page that opens shows each server waiting, running, then succeeded, with a **Log** button for what the agent did.
   - Try a service that does not exist, such as `php8.3-fpm` on a server without PHP, with **Stop if a server fails** ticked: the first server fails with the reason and the others are not touched.
   - Offline servers and servers without an agent are listed as **Skipped** with the reason, instead of failing.
   - **Bulk Actions** in the sidebar lists everything run this way.
   - Reboot is there too. One at a time waits for each server to come back online before the next one restarts. Only try it on servers you can afford to restart. If the list includes This server (the one the panel runs on), it is rebooted last, after every other server is done; the panel is then unreachable until you start the backend, worker and frontend again on it, and the action finishes once its agent reports in.
6. **Agent updates from the panel**: agents from 0.7.0 on can update themselves. When the panel has a newer agent than a server, its page shows **Update agent**: the agent downloads the new version from the panel, checks it, swaps it in and restarts, and the server shows the new version a few seconds later. **Run on selected**, **Update the agent** does this for many servers at once and skips the ones already current. Agents older than 0.7.0 (a second server you connected before this update) need the upgrade command on their page once. You will see the button the next time the agent changes, since all your agents are on 0.7.0 after this update.

### Trying Phase 8 (hosting plans, customers, quotas and the billing API)

This is on the Phase 8 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase8-hosting-plans-afhwaf && git checkout claude/phase8-hosting-plans-afhwaf`
in step 1 instead of `git checkout main && git pull`.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Restart the backend as root (it updates this server's agent to 0.8.0, which measures site and app folder sizes), the worker and the frontend. Other servers now show **Update agent** on their page, or use **Run on selected**, **Update the agent**.
2. **Hosting Plans** (sidebar, under Hosting): click **New plan**. Call it "Starter", set a monthly price, and limits such as 2 websites, 1 app, 2 databases, 2 database users, 5 cron jobs and 2 GB of disk. Under **Caps on each app** set 512 MB of memory and 50% CPU. An empty limit means unlimited. Make a second, bigger plan ("Business") too.
3. **Customers**: click **New customer**, enter a name and an email you can use, pick Starter and leave the server on **Choose for me**. The panel shows an invite link once: copy it.
4. Open the invite link in a private window (so you stay signed in as yourself in the normal one), choose a password and sign in. The customer sees **My Hosting** with their plan, what they use of it, and the server's IP address to point their domains at. The sidebar has only websites, apps, databases, files, backups, cron jobs and their own activity; going to `/servers` in the address bar shows that they do not have access.
5. As the customer, add websites until the plan's limit: the third one is refused with a message saying the plan allows 2. Create an app and open its settings: memory and CPU cannot go above the plan's caps. A reverse-proxy website can only point at the port of one of the customer's own apps.
6. Back as yourself, open the customer. **Usage** shows each limit (disk space appears within about 15 minutes, once the agent has measured the folders). **What the account owns** lists their websites, apps and databases. **Add existing** moves a website, app or database that belongs to no customer into the account; **Take back** does the reverse.
7. **Change plan** to Business: the limits change at once. Moving to a smaller plan than what the account uses never deletes anything; the account shows **Over plan** and new things are refused.
8. **Suspend** (give a reason): the customer is signed out in the private window and cannot sign in again ("Your hosting account is suspended"), their websites are turned off, apps stopped and cron jobs paused. **Unsuspend** turns all of it back on.
9. **Billing API** (under Hosting): click **New API key**, name it, and copy the key (it is shown once). The page lists every endpoint with curl examples. On the VPS, with the key in `VAULTPANEL_KEY`:
   ```sh
   curl -s http://VPS_IP:5173/api/v1/billing/plans -H "Authorization: Bearer $VAULTPANEL_KEY"
   curl -s -X POST http://VPS_IP:5173/api/v1/billing/accounts -H "Authorization: Bearer $VAULTPANEL_KEY" \
     -H "Content-Type: application/json" \
     -d '{"name":"Test Client","email":"client@example.com","plan":"Starter","externalId":"test-1"}'
   curl -s -X POST http://VPS_IP:5173/api/v1/billing/accounts/test-1/suspend -H "Authorization: Bearer $VAULTPANEL_KEY"
   ```
   The new account appears on **Customers** with "Billing API" as its source, and the key shows when it was last used. **Revoke** stops the key at once. This is the API that WHMCS, Blesta or your own billing code calls; VaultPanel itself never charges anyone.
10. **Remove account** (type the customer's email to confirm) deletes everything the account owns, files and backups included, and closes its sign-in. Only try it on a test customer.

### Trying Phase 9 (the AI assistant)

This is on the Phase 9 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase9-ai-assistant-av4jut && git checkout claude/phase9-ai-assistant-av4jut`
in step 1 instead of `git checkout main && git pull`.

You need an API key from an AI provider: a Claude key from console.anthropic.com (the default), or an
OpenAI-compatible service. Ollama on your own server needs no key, but small models are much weaker
at this, and the model must support tool calling.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Restart the backend as root (it updates this server's agent to 0.9.0, which can list listening
   ports), the worker and the frontend. **The worker must be running** (`npm run dev:worker`): it is
   what writes the answers. Other servers show **Update agent** on their page.
2. **Assistant Settings** (sidebar, under System): keep **Claude (Anthropic)**, leave the
   model on Claude Opus 5.5, paste your API key and tick **Turn the assistant on**. Click **Test
   connection**: it should say the provider answered and how long it took. Click **Save settings**.
   The key is not shown again; the field shows only its last four characters.
3. **AI Assistant**: pick one of the suggested questions, or ask your own, for example "Is my app
   api healthy? Check its logs." While it works, the page shows what it is checking ("Reading the
   app's error log on web-1"...). The answer lists what it checked under **Checked N things**.
4. Ask it to fix something, for example "Restart the app". It does not restart anything itself: it
   shows a **Proposed action** card with the reason. Click **Review action**, read it, then
   **Approve and run**. The card shows **Running** and then **Done** (or the error); the change is in
   **Jobs** and in the **Audit Log** under your name, like clicking the button yourself. **Cancel**
   drops it. A proposal nobody approves expires after 60 minutes.
5. Ask a follow-up ("Did that work?"): it knows what you approved and checks again.
6. On an app's or a website's page, **Ask the assistant** opens the assistant with a question
   about it filled in; press Enter to send it.
7. Sign in as a **Viewer**: they can ask questions, and the assistant can only read what a viewer can
   read. Proposed changes show which permission they need and cannot be approved.
   Hosting customers do not see the assistant at all.
8. To try a self-hosted model instead: install Ollama on the VPS, `ollama pull qwen3` (or another
   model with tool calling), then in Assistant Settings choose **OpenAI-compatible**, address
   `http://127.0.0.1:11434/v1`, model `qwen3`, no key, Test connection and Save. Nothing then leaves
   your server.

What is sent to the provider: your questions, and the status, log lines, process and port lists the
assistant reads to answer them. Environment variable values and passwords are never sent.

### Trying Phase 10, part 1 (Docker containers)

This is on the Phase 10 pull request until it is merged. To try it before then, use
`git fetch origin claude/phase10-docker-containers-cfmrp4 && git checkout claude/phase10-docker-containers-cfmrp4`
in step 1 instead of `git checkout main && git pull`.

1. On the VPS, as root:
   ```sh
   cd ~/VaultPanel && git checkout main && git pull
   npm install && npm run db:migrate
   ```
   Restart the backend as root (it updates this server's agent to 0.10.0), the worker and the
   frontend. Other servers show **Update agent** on their page.
2. **Containers** (sidebar, under Applications). The Docker card shows what the agent found. On the
   Contabo VPS Docker is the snap, which also runs VaultPanel's own MariaDB and Redis: it should say
   **Running** and "Snap package". If it says **Stopped**, click **Start Docker** (it runs
   `snap start --enable docker`). On a server without Docker, **Install Docker** installs Ubuntu's
   `docker.io`.
3. **All containers** lists everything Docker runs, including VaultPanel's own database and Redis
   containers marked **Used by VaultPanel**: their stop, restart and remove buttons are greyed out,
   so they cannot be stopped from the panel by mistake. **Logs** and the info button work on any
   container.
4. **Deploy container**: name `hello`, image `nginx:alpine` (if Docker Hub says
   "toomanyrequests", use `mirror.gcr.io/library/nginx:alpine`), port **This server only** `8081` →
   `80`, a volume `html` at `/usr/share/nginx/html`, and a variable `GREETING=hello`. Click
   **Deploy**. The job pulls the image, starts it and checks it stays up for 10 seconds. Then
   `curl -s http://127.0.0.1:8081 | head -3` on the VPS shows nginx's page.
5. On the container's page: **Overview** shows its settings and what Docker reports now (CPU, memory,
   mounts); **Logs** shows its output; **Environment** shows the variables (values hidden until
   **Show values**; viewing them is in the Audit Log). **Stop**, **Start** and **Restart** work from
   the header.
6. **Add a domain** opens a new website already set to proxy to port 8081. Give it a domain that
   points at the VPS, and issue SSL as for any website: that is how a container is put on the
   internet with HTTPS.
7. Try a bad change: in **Settings** change the image to `nginx:no-such-tag` and **Save and
   redeploy**. The job fails, the page says "The last change did not work", and the old container
   keeps running (the curl from step 4 still works). Put the image back.
8. A public port: add a port **Public** `8082` → `80` and save. The form warns that Docker opens it
   itself, ignoring UFW. `http://VPS_IP:8082` answers from anywhere. Remove the port again if you do
   not want that.
9. **Images**: the nginx image shows which containers use it. **Pull image** with `redis:7` (or
   `mirror.gcr.io/library/redis:7`), then remove it with the bin icon (images in use cannot be
   removed).
10. **Settings → Remove**, tick **Also delete its volumes**, type `hello` to confirm. The container
    and its `vp-hello-html` volume are gone (`docker ps -a` and `docker volume ls` on the VPS).
11. Sign in as a **Developer**: they can start, stop, restart and read logs, but not deploy, change
    or remove. A **Viewer** only sees the lists. Hosting customers do not see Containers.

### Trying Phase 10, part 2 (API tokens, the command-line tool and the SDK)

Update first: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
then restart the backend, the worker and the frontend. No agent update is needed: this part is all
panel and tooling.

1. In the panel open **Users & Access → API Tokens**. Create one called `Terminal`, tick **Read**
   and **Deploy**, leave **Expires** on "Until it is revoked" and click **Create token**. Copy the
   `vpt_…` value before closing the window: it is shown once.
2. In a terminal on the VPS, in `~/VaultPanel`:

   ```sh
   node cli/bin/vaultpanel.js login --url http://VPS_IP:5173
   # paste the token when it asks
   node cli/bin/vaultpanel.js whoami
   ```

   It should name you, the token and its scopes. The token is saved in
   `~/.config/vaultpanel/config.json`, readable only by you.

3. Try a few commands:

   ```sh
   node cli/bin/vaultpanel.js servers list
   node cli/bin/vaultpanel.js websites list
   node cli/bin/vaultpanel.js dashboard
   node cli/bin/vaultpanel.js apps list --json
   ```

   `--json` is for scripts; everything else prints a table.

4. Deploy from the terminal and watch it: `node cli/bin/vaultpanel.js apps deploy <app name> --watch`.
   The deployment's log scrolls past and the command exits 0 when it succeeds. Check with
   `echo $?`; a failed deployment exits 2.
5. Scopes really limit it. With the Read+Deploy token, try
   `node cli/bin/vaultpanel.js servers add test-from-cli`: it is refused, and says the token's scopes
   do not cover it. Make a second token with **Everything**, run it again with
   `VAULTPANEL_TOKEN=vpt_… node cli/bin/vaultpanel.js servers add test-from-cli`, and it works. Remove
   that server afterwards with `… servers remove test-from-cli --force`.
6. A token can never do more than the person who made it. Sign in as a **Viewer**, create a token
   with **Servers** ticked, and the panel says plainly how many of the permissions it asked for you
   actually have (or refuses it when you have none of them). Using it to add a server is refused.
7. The raw API, with curl:

   ```sh
   curl http://VPS_IP:5173/api/v1/servers -H "Authorization: Bearer vpt_…"
   ```

   The answer is the panel's usual `{ success, data, message, requestId }`.

8. The SDK, from the repository:

   ```sh
   cd ~/VaultPanel
   VAULTPANEL_URL=http://VPS_IP:5173 VAULTPANEL_TOKEN=vpt_… node --input-type=module -e "
     import { VaultPanel } from '@vaultpanel/sdk';
     const panel = new VaultPanel();
     const { items } = await panel.servers.list();
     console.log(items.map((s) => s.name));
   "
   ```

9. Revoke the `Terminal` token in the panel, then run `node cli/bin/vaultpanel.js servers list`
   again: it stops at once, says the token is not valid any more and tells you to sign in again.
10. Open **Security → Audit Log**: the calls you made from the terminal are there under your own
    name, with the token named too.

### Trying Phase 10, part 3 (plugins)

Update first: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
then restart the backend, the worker and the frontend. No agent update is needed.

The repository has a small example plugin, **Status Board**, that shows every server and the
latest panel events on a page inside the panel. It runs on its own, here on the VPS on port 4100.

1. If the firewall is on, open the plugin's port: `ufw allow 4100/tcp`.
2. In a second terminal (or a `tmux`/`screen` window), start the plugin with your VPS address:

   ```sh
   cd ~/VaultPanel
   PLUGIN_PUBLIC_URL=http://VPS_IP:4100 node examples/status-board-plugin/server.js
   ```

   It prints `Manifest URL for the panel: http://VPS_IP:4100/manifest.json` and says it is not
   connected yet.

3. In the panel open **Plugins** (near the bottom of the sidebar) and click **Install plugin**. Paste that manifest URL and
   click **Review**. The panel explains what it asks for: **Read** (14 permissions), seven events
   and a page called "Status board", with a warning that it uses plain http. Tick
   **I approve these permissions for Status Board** and click **Approve and install**.
4. The panel shows the plugin's **token** (`vpp_…`) and **signing secret** (`whsec_…`) once. Keep
   the window open, stop the plugin with Ctrl+C, and start it again with both:

   ```sh
   VAULTPANEL_PLUGIN_TOKEN=vpp_… VAULTPANEL_PLUGIN_SECRET=whsec_… \
   PLUGIN_PUBLIC_URL=http://VPS_IP:4100 node examples/status-board-plugin/server.js
   ```

   It should say `Calling the panel at http://127.0.0.1:4000`. Click **Done** in the panel.

5. **Status board** appears near the bottom of the sidebar, under Plugins (just above System). Open it: the plugin's page shows inside
   the panel, greets you by email and lists your servers with their state. Switch the panel to dark
   mode and reload: the page follows.
6. Open **Plugins → Status Board → Events** and click **Send test event**. It shows
   **Delivered** with HTTP 200, the plugin's terminal prints `event webhook.test`, and the event
   appears under "Latest events" on the board within 15 seconds.
7. A real event: deploy one of your apps (Phase 4) or wait for an alert. `deployment.succeeded`
   shows up in the plugin's Events tab and on the board.
8. The plugin can only read. With its token:

   ```sh
   curl http://VPS_IP:5173/api/v1/servers -H "Authorization: Bearer vpp_…"          # works
   curl -X POST http://VPS_IP:5173/api/v1/servers -H "Authorization: Bearer vpp_…" \
     -H 'Content-Type: application/json' -d '{"name":"nope"}'                         # 403
   ```

   **Security → Audit Log** shows the refused call as `plugin:status-board`.

9. Open `http://VPS_IP:4100/` straight in a browser tab: the plugin refuses ("Open this page from
   the Status board link in the VaultPanel sidebar"), because only the panel can sign the link.
10. On the plugin's page click **Turn off**: the sidebar entry goes, and the plugin's own calls are
    refused (a board that is still open shows "This plugin is turned off in the panel" at its next
    refresh). **Turn on** brings it all back.
11. **Settings → Make new credentials** gives a new token and secret and the old ones stop at once:
    the board shows an error until you restart the plugin with the new pair.
12. When you are done, **Settings → Remove** (type `status-board` to confirm), stop the plugin and,
    if you opened it, close the port: `ufw delete allow 4100/tcp`.

If **Review** says the manifest cannot be reached, the panel may not be able to reach its own
public address. Start the plugin with `PLUGIN_EVENTS_URL=http://127.0.0.1:4100` as well, add
`VAULTPANEL_PLUGIN_ALLOW_LOCAL=true` to `.env`, restart the backend and the worker, and install from
`http://127.0.0.1:4100/manifest.json`. To write your own plugin, see `docs/plugins.md`.

### Trying the one-command installer

Use a **fresh** Ubuntu 22.04/24.04 or Debian 12/13 server (a new, small VPS is ideal). Not the VPS
where you run the panel by hand: that one already uses ports 3307 and 6379 for its database, and the
installed panel would take over its agent.

1. Make the installer reachable. The installer downloads VaultPanel from GitHub, which only works while
   the repository is public. While it is private, log in to the new server as root and use a copy:

   ```sh
   git clone https://github.com/VaultPanel/VaultPanel.git  # asks for your GitHub login
   bash VaultPanel/install.sh
   ```

   On a server that only runs VaultPanel, use the install command from [VaultPanel/packages](https://github.com/VaultPanel/packages)
   (`apt update ...`, then `curl -sS https://installer.vaultpanel.net/v2/install.sh -o install.sh` with
   its checksum and `DB_ENGINE`).

2. Watch the steps (packages, Node.js 22, Docker, MariaDB for websites and apps, settings, database,
   build, services). It takes a
   few minutes and ends with **VaultPanel is installed.**, the address (`http://SERVER_IP:8090/setup`)
   and a setup token. If the firewall is on, port 8090 was opened for you.
3. Open the address, paste the token and create the owner account. **Servers** shows the server as
   **This server**, Online, agent v0.11.0.
4. On the server, type `vaultpanel`: the VaultPanel banner, the address, and Panel, Worker and Agent
   all `running`. Try `vaultpanel status`, `vaultpanel logs`, `vaultpanel help`.
5. Log out of SSH and log in again: the login message ends with the VaultPanel banner and the address.
6. Reboot the server (`reboot`). After a minute the panel answers again at the same address with
   nothing started by hand, and `vaultpanel status` shows everything `running` and the database `ok`.
7. Update by running the installer again: `git -C VaultPanel pull && bash VaultPanel/install.sh`
   (once the repository is public, `vaultpanel update` does it). It keeps your settings and account
   ("kept the settings in /opt/vaultpanel/.env") and ends with "Open: ... and sign in".
8. Optional, with a domain: follow "Trying the panel domain" below, with port 8090 as the panel port.

### Trying the panel domain

This puts the panel itself on a domain such as `cp.example.com` with HTTPS. You need a domain or
subdomain you control. Your current address (`http://VPS_IP:5173`, or `:8090` on an installed panel)
keeps working the whole time.

1. Update to this version and restart the backend as root, the worker and the frontend (the update
   recipe at the top). No database migration and no agent update are needed.
2. At your DNS provider, add an **A record** for the domain (for example `cp`) pointing at the VPS IP.
   Check it from the VPS: `getent hosts cp.example.com` should print the VPS IP.
3. If the firewall is on, make sure 80 and 443 are open: `ufw status` (they open by themselves when
   NGINX is installed after the firewall).
4. In the panel, open **System > Panel Domain**. If NGINX or Certbot are missing, install the web stack
   from **This server**'s page first.
5. Type the domain and leave **Panel port** as it is: 5173 for the dev servers, 8090 for an installed
   panel. Click **Add domain** and watch the log. Step 1 turns **Live**.
6. Open `http://cp.example.com`: the VaultPanel sign-in page. With the dev servers there is no need to
   touch Vite's `allowedHosts`; the domain is let through on its own.
7. In **SSL certificate**, keep **Start with a test certificate** ticked and click **Get a test
   certificate**. When it finishes, a yellow box says it is a test certificate: the setup works.
   Click **Get the trusted certificate**.
8. Open `https://cp.example.com`: a padlock, and `http://` sends you to `https://`. Sign in there.
   Signing in over HTTPS uses a secure cookie, while `http://VPS_IP:5173` still lets you sign in too.
9. In **Panel address**, click **Use https://cp.example.com**. **Address now** changes, and **Add a
   server** now shows install commands with `https://cp.example.com`. **Go back to ...** undoes it.
10. Open **Websites**, **Domains** and **SSL Certificates**: the panel's domain is not listed there,
    only on the Panel Domain page. Adding a website with the same domain is refused with "is the
    panel's own domain".
11. Optional: **Remove** on the Panel Domain page takes the panel off the domain and deletes the
    certificate. The IP address keeps working.

If step 5 fails with "The domain does not reach the panel", the panel port is wrong: it must be the
port you open the panel on now. If the certificate request says the domain does not point to this
server, DNS has not updated yet or port 80 is closed; wait a few minutes and try again.

### Trying the server terminal

The terminal opens a root shell on a server from the panel, like SSH. Only owners have it.

1. Update to this version: the update recipe at the top (pull, `npm install`, migrate), then restart
   the backend as root, the worker and the frontend. `npm install` matters this time: it brings the
   terminal's new packages. Restarting the backend updates **This server**'s agent to v0.11.0; other
   servers need **Update agent** on their page first.
2. Open **Terminal** in the sidebar (under Infrastructure). **This server** is picked, the badge turns
   **Connected** and a prompt like `root@vmi3632702:~#` appears. Run `uptime`, `df -h`, `top` (q to
   quit) or `nano /tmp/test.txt` (Ctrl+X to leave): colours, full-screen programs and arrow keys work.
3. Resize the browser window, or click **Full screen** (Esc leaves it): run `stty size` and the numbers
   follow the window.
4. Copy: select text with the mouse, then click **Copy** or press **Ctrl+Shift+C** (Ctrl+C copies too
   while text is selected; with nothing selected it stops the running command, as usual). Right-click
   **Copy** also works. Paste the text somewhere else to check. This works on `http://VPS_IP:5173`.
5. Paste: copy a command from anywhere, click in the terminal and press **Ctrl+V** (or right-click
   **Paste**). Over plain HTTP the **Paste** button only explains this, because browsers let a page
   read the clipboard only over HTTPS; on the panel's https:// domain the button pastes directly.
6. Type `exit`: the badge shows **Closed** and a **Reconnect** button starts a new shell.
7. Each server also has a **Terminal** tab on its page. Open two terminals at once: both work.
8. **Security > Audit Log** shows **server.terminal.open** and **server.terminal.close** for each
   session, with who, from which address, and how long. Replays are under **Sessions and recordings**
   (see Trying terminal recording).
9. Sign in as an admin or developer: there is no Terminal in the sidebar or tab, and an API token
   cannot open one even with the **Everything** scope.

If the terminal says the agent "has not connected its terminal channel yet", wait a few seconds and
try again; if it stays, `journalctl -u vaultpanel-agent -n 50` on that server shows why. Through the
panel's domain, NGINX passes the terminal's connection on with no extra setup.

### Trying the database interface

Open a database to see its tables, browse rows and run SQL, like phpMyAdmin but inside the panel.
It needs the databases.manage permission (owners and admins, and customers for their own databases).

1. Update to this version: the update recipe at the top (pull, `npm install`, migrate), then restart
   the backend as root, the worker and the frontend. Restarting the backend updates **This server**'s
   agent to v0.12.0; other servers need **Update agent** on their page first (until then the page
   says the agent cannot list tables).
2. Go to **Databases**. Database names are now links, and each active one has an **Open** button.
   No database yet? Click **New database**, name it `shop_test`, and wait for **Active**.
3. Open it. The **Tables** list on the left shows each table with its approximate row count. A new
   database has none: go to the **SQL** tab, tick **Allow changes**, and run:
   `CREATE TABLE notes (id INT PRIMARY KEY AUTO_INCREMENT, body TEXT, created_at DATETIME DEFAULT NOW());`
   then `INSERT INTO notes (body) VALUES ('hello'), ('world'), (NULL);`. The table list refreshes.
4. Click **notes**. **Browse** shows the rows, 50 per page (25 to 250 with the selector), with
   **Previous** and **Next**. NULL shows as a grey _NULL_. Click a column name to sort by it, again to
   reverse. **CSV** downloads the page you see; **Query** opens the SQL tab with a `SELECT` for it.
5. **Structure** lists the columns (type, null, key, default, extra), the indexes and the
   `CREATE TABLE` statement with a **Copy** button.
6. **SQL** runs one or more statements (Ctrl+Enter runs too). With **Allow changes** off it is
   read-only: run `UPDATE notes SET body = 'x';` and it fails on that line with "UPDATE command
   denied" and a hint to turn on Allow changes. Each `SELECT` shows its own result (the first 1,000
   rows, with a CSV button) and each change shows how many rows it affected.
7. With **Allow changes** on, SQL that drops, deletes, truncates or alters asks for confirmation
   first. Changes are recorded in **Security > Audit Log** as **database.query**, with the SQL.
8. It only reaches that database: `SELECT * FROM mysql.user;` or a table in another database is
   denied, and so are `SELECT ... INTO OUTFILE` and client commands like `\! id`. A query that runs
   longer than 30 seconds is stopped.
9. Sign in as a developer or viewer: database names are not links and `/databases/<id>` says you
   do not have access.

Databases created outside the panel (by hand, or by an installer) do not show up on the Databases
page, so they cannot be opened here yet. Your apps' databases made in the panel all can.

**phpMyAdmin itself.** If you prefer the real phpMyAdmin:

1. On **Databases**, the **phpMyAdmin** card lists your servers. Click **Set up** next to This
   server. Keep port **8081** (or pick another free one). If the panel has its own domain with a
   real certificate (System > Panel Domain), leave **Serve it over HTTPS** ticked. Click
   **Set up phpMyAdmin**; the job installs it (a minute or two) and opens the port if the firewall
   is on. On Contabo with UFW off nothing else is needed.
2. The row now shows the address, such as `http://VPS_IP:8081/`, and **Open phpMyAdmin**.
3. Sign in with a database user: on the **Users** tab click **Password** next to the user (for
   example `shop_test`) to see its password. Signing in as `root` is refused on purpose.
4. You see only that user's databases, with Browse, Structure, SQL, Search, Insert, Export and
   Import, as usual in phpMyAdmin.
5. **Settings** changes the port (or HTTPS); the power button turns phpMyAdmin off (the package
   stays installed, nothing in your databases changes).

If the job fails with "does not answer on port 8081", another program uses that port: open
**Settings** and pick another, such as 8082.

### Trying one-click phpMyAdmin

Each database can open in phpMyAdmin in a new tab, already signed in, with no username or password
to type. It signs in as that database's own VaultPanel account, which reaches only that database
(never root). After you log out of phpMyAdmin, its normal login form comes back and you can sign in
with any database user and password as before.

This is on the pull request until it is merged. To try it before then, use
`git fetch origin claude/database-interface-g3t34o && git checkout claude/database-interface-g3t34o`
instead of `git checkout main` in the update steps. Restart the backend as root (it updates This
server's agent to 0.19.0); other servers need **Update agent**. No migration.

1. Set up phpMyAdmin on the server first (the steps above), if you have not already.
2. On **Databases**, each active database on that server now has a **phpMyAdmin** button. Click it.
   A new tab opens, says "Opening ... in phpMyAdmin" for a second or two, then shows that
   database's tables in phpMyAdmin. The top of the page says "Signed in from VaultPanel".
3. The same button, **Open in phpMyAdmin**, is at the top of a database's own page
   (click its name).
4. Click phpMyAdmin's **Log out** icon (top left, under the logo). You land on phpMyAdmin's login
   form. Sign in there with a database user and its password (Users tab, **Password**), as before.
5. A link only works once and only for two minutes. Copying the address of the opening tab and
   visiting it again just shows the login form.
6. Hosting customers get the same button on their own databases.

If the browser blocks the new tab, the panel says so: allow pop-ups for the panel's address and
click the button again. If the server has no phpMyAdmin, the button is not shown.

### Trying customer app ports

Each hosting customer now has their own app ports: as many as their plan allows apps (ports from
10000 up). Their apps can only listen on those ports, and no other app (yours or another
customer's) can take them. With no app limit on the plan, the account always has one free port more
than the apps it has.

This is on the pull request until it is merged. To try it before then, use
`git fetch origin claude/customer-app-ports-gut6b9 && git checkout claude/customer-app-ports-gut6b9`
in step 1 instead of `git checkout main && git pull`.

1. Update with the recipe at the top (pull, `npm install`, `npm run db:migrate`), then restart the
   backend, the worker and the frontend. The agent does not change. Existing customers get their
   ports within about five minutes of the worker starting, or at once when you change their plan.
2. **Hosting Plans**: edit Starter and set **Apps** to 3. The note under the limits says each
   customer gets one app port per app.
3. **Customers**: open a customer on Starter. The new **App ports** card shows three ports, such as
   10000, 10001 and 10002, all "free". A second customer on the same server gets different ones.
4. Sign in as that customer (a private window). **My Hosting** shows **Your app ports**. Go to
   **Applications > New application**: the **Port** field is now a list of your free ports (or
   "No web port" for a worker), with the first one picked. Create the app.
5. Back on **My Hosting** (or the customer's page as yourself), that port now shows the app's name.
   The app's **Settings** tab only offers its own port and the account's free ones.
6. As yourself, create an app and type one of the customer's ports (say 10002): it is refused with
   "one of a hosting customer's app ports". The suggested port for your own apps skips them.
7. **Change plan** to one with 1 app: the free ports go, and the one the app uses stays. Change back
   and the ports come back. Raising a plan's app limit adds ports to all its customers.
8. **Add existing** an app of yours (say on port 3000) to the customer: 3000 joins their ports, and
   one free port goes so the count still matches the plan. **Take back** gives 3000 back to you
   with the app, and the customer gets a new port in its place.
9. **Remove account** frees all of the account's ports.

### Trying S3-compatible backup storage

Backups can now be copied to an S3-compatible bucket: Amazon S3, Backblaze B2, Wasabi, Cloudflare R2,
MinIO or any other service that speaks the S3 API. Each server's agent copies the backup there right
after writing it, checks the copy, and (unless you ask to keep both) removes it from the server.
Restores and downloads fetch it back and check its SHA-256 first. The secret key is stored encrypted
in the panel and only travels inside the job that needs it.

This is on the pull request until it is merged. To try it before then, use
`git fetch origin claude/s3-backup-storage-30xmgp && git checkout claude/s3-backup-storage-30xmgp`
in step 1 instead of `git checkout main && git pull`.

You need a bucket and a key for it first. For Backblaze B2: create a private bucket, then an
application key limited to that bucket with read and write access; note its **keyID**, its
**applicationKey** and the bucket's **Endpoint** (such as `s3.us-west-004.backblazeb2.com`, where
`us-west-004` is the region). For Amazon S3: a bucket and an IAM user allowed `s3:PutObject`,
`s3:GetObject` and `s3:DeleteObject` on it. To test without an account, MinIO in Docker works:
`docker run -d -p 127.0.0.1:9000:9000 -e MINIO_ROOT_USER=npadmin -e MINIO_ROOT_PASSWORD=npsecret123 minio/minio server /data`,
then create a bucket in it (for example with `docker exec <container> mc mb local/npbackups` after
`mc alias set local http://127.0.0.1:9000 npadmin npsecret123`).

1. Update with the recipe at the top (pull, `npm install`, `npm run db:migrate`), then restart the
   backend as root (that updates This server's agent to 0.13.0), the worker and the frontend. Other
   servers need **Update agent** before they can use storage.
2. **Backups**: the **S3-compatible storage** card now has **Set up**. Click it.
3. Pick the **Service** (Backblaze B2, Amazon S3, Wasabi, Cloudflare R2, or "MinIO or another
   S3-compatible service"), give it a name, and fill in the region, bucket, access key ID and secret
   key. For B2, Amazon S3 and Wasabi the endpoint fills itself in from the region; for MinIO type it
   (such as `http://127.0.0.1:9000`) and keep **Path-style addresses** ticked. Leave **Also keep
   each backup on its server** off to save disk. Click **Add storage**.
4. The **Check** window opens: pick a server and click **Check now**. Its agent writes a small file
   to the bucket, reads it back and deletes it. The **Storage** tab then shows "Works", or the
   reason it failed in plain words (wrong secret key, bucket not found, wrong region, the server's
   clock is off, and so on).
5. Click **Back up now**, pick a website, app or database, and set **Store in** to your storage.
   The log shows the backup being written, copied to the bucket, confirmed, and removed from the
   server. The backup's status reads "In <your storage>". In the bucket it is under
   `vaultpanel/<server id>/<site|app|database>/<name>/<backup id>.tar.gz` (or `.sql.gz`).
6. Change something in the site (or database), then **Restore** the backup: the agent fetches it
   from the bucket, checks its checksum, and restores it. **Download** works the same way.
7. **New schedule** (or edit one): set **Store in** to your storage. Each scheduled backup goes to the
   bucket, and the oldest beyond the number to keep are deleted from the bucket too.
8. To see a failure: edit the storage and type a wrong secret key, then back up to it. The backup
   still completes, kept on the server, with "On the server only: the copy to ... failed" and the
   reason under its status.
9. **Delete** a backup kept in storage: it is deleted from the bucket as well. A storage that still
   holds backups or is used by a schedule cannot be removed; nothing in the bucket is ever deleted
   by removing a storage.
10. Hosting customers don't see the Storage tab or the **Store in** choice; their backups stay on the
    server unless you give them a schedule that uses storage.

### Trying SFTP backup storage

Backups can also be copied to another server you own, over SFTP (the **Another server (SFTP)** card).
The panel makes its own SSH key for each such destination; you add its public key to a user on the
backup server, and the panel trusts that server's host key on the first check (a different key later
is refused, so nobody can pose as it). Each server's agent uses the standard `sftp` command
(`openssh-client`, already on Ubuntu and Debian). It is on the same pull request as S3 storage.

You need a second Linux server (any VPS, or a home server reachable over SSH) with a user for the
backups. On it, as root: `adduser --disabled-password --gecos "" backups` (not root; the panel refuses
root). Its firewall must let your VPS in on the SSH port.

1. Update as for S3 storage (pull, `npm install`, `npm run db:migrate`, restart the backend as root,
   the worker and the frontend). Other servers need **Update agent** (0.13.0) first.
2. **Backups**: the **Another server (SFTP)** card now has **Set up**. Click it (or **Storage** tab,
   **Add storage**, and **Kind** "Another server, over SFTP").
3. Fill in a name, the **Host** (the backup server's name or IP), **User** (`backups`), **SSH port**
   (22) and **Folder** (`vaultpanel-backups`, inside the user's home; or a full path such as
   `/srv/backups` the user can write to). Click **Add storage**.
4. The **Check** window shows the panel's public key. On the backup server, add it for the user:
   ```sh
   su - backups
   mkdir -p ~/.ssh && chmod 700 ~/.ssh
   echo 'ssh-ed25519 AAAA... vaultpanel-backups' >> ~/.ssh/authorized_keys  # paste the key from the panel
   chmod 600 ~/.ssh/authorized_keys
   ```
   (the **Copy** button copies the key; the window also shows the one-line command with your key in it).
5. Back in the panel, pick a server and click **Check now**. The first check reads the backup server's
   host key, trusts it, writes a small file, reads it back and deletes it. The **Storage** tab then
   shows "Works" and the trusted host key's fingerprint (`SHA256:...`). To compare it, run
   `ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub` on the backup server. If the check says the key
   was refused, step 4 is missing or has a typo.
6. Back up with **Store in** set to this storage, restore, download, schedule and delete exactly as in
   steps 5 to 9 of the S3 section. On the backup server the files are under
   `~/vaultpanel-backups/<server id>/<site|app|database>/<name>/<backup id>.tar.gz` (or `.sql.gz`).
7. To see the host key protection: reinstall the backup server (or change its host keys with
   `rm /etc/ssh/ssh_host_* && dpkg-reconfigure openssh-server`), then back up to it. The copy is
   refused with "The host key of ... is not the one the panel trusts", and the backup stays on your
   server. If the change was on purpose, edit the storage, tick **Trust the server's new host key**,
   save and check it again. Changing the host or port forgets the old key too.

### Trying app scaling (several copies of an app)

An app can run several copies on its server, to use more than one CPU core. Node.js apps run them in
PM2 cluster mode: the copies share the app's port and PM2 spreads connections between them. Python apps
get `WEB_CONCURRENCY`, which Gunicorn and Uvicorn use as their number of workers. This is scaling on one
server; running one app across several servers is not built yet.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`, then
   restart the backend as root (that updates This server's agent to 0.14.0), the worker and the
   frontend. Other servers need **Update agent** (0.14.0) before their apps can scale; until then the
   panel says the agent is too old.
2. Use a deployed Node.js app whose **Start command** (Settings tab) runs a Node.js file, such as
   `node server.js` or `node dist/main.js`. `npm start` cannot run in cluster mode: put the command your
   package.json start script runs instead, save, and **Apply changes**. To see the copies answer, this
   small server prints which process answered:
   ```js
   require("http")
     .createServer((req, res) => res.end(`process ${process.pid}\n`))
     .listen(process.env.PORT);
   ```
3. Open the app. The **Overview** tab has a **Scaling** card. Set **Copies** to `4` and click
   **Scale now**. The job log says "Running 4 copies in PM2 cluster mode" and the health check ends
   with "(4 copies running)".
4. The **Process** card now shows **Copies: 4 of 4 running**, and the **Scaling** card lists each copy
   with its PID, memory, CPU and restarts. On the server, `curl -s 127.0.0.1:<port>` a few times (or open
   the app's domain and reload) shows different process numbers.
5. Set **Copies** to `2` and **Scale now**. The log shows `pm2 scale <app> 2` and "PM2 now runs 2
   copies": the other copies kept serving, nothing restarted. Going from 1 to several copies, or back
   to 1, restarts the app once.
6. Deploy again: the new release starts with the same number of copies.
7. With a start command such as `npm start`, scaling above 1 fails with "the start command must run a
   Node.js file"; the app keeps running as it was.
8. Python: with a start command such as `gunicorn -b 127.0.0.1:$PORT app:app`, set **Workers** to 3.
   The app restarts with `WEB_CONCURRENCY=3` and Gunicorn starts 3 workers (`ps -u <app> -f` shows
   them).
9. Limits: the CPU and memory limits in **Settings** cover all copies together, so give a scaled app a
   higher CPU limit (100% is one core) or leave it empty.

### Trying DNS zones

VaultPanel can be the DNS server for your domains, like cPanel or CyberPanel: BIND runs on one of your
servers and answers for the zones you add under **Web > DNS Zones**. Only staff see DNS zones.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`, then
   restart the backend as root (that updates This server's agent to 0.15.0), the worker and the
   frontend. Other servers need **Update agent** (0.15.0) before they can serve DNS.
2. Open **DNS Zones** in the sidebar (under Web). The **DNS servers** card lists your servers. Click
   **Set up DNS** next to This server and confirm. The job installs BIND (`bind9`), sets it up to answer
   only for your own zones (no recursion, no zone transfers) and, when the firewall is on, opens port 53.
   The server then shows **Set up**. On the server, `systemctl status named` shows it running.
3. Click **New zone**, enter your domain (for example `tupalm.site`), keep **Served by** on This server,
   tick **Add mail records** if you want them, and **Add zone**. The zone opens with records for `@`,
   `www`, `ns1` and `ns2` pointing at the server's public IP, and two NS records. A moment later the
   status says the server serves the latest version.
4. Check the server answers (from any computer): `dig @VPS_IP tupalm.site A +short` prints the IP, and
   `dig @VPS_IP www.tupalm.site +short` too. `dig @VPS_IP google.com` gets `REFUSED`: the server does not
   answer for other domains.
5. **Add record**: for example type TXT, name `@`, value `hello from VaultPanel`, and **Add record**.
   Within a few seconds `dig @VPS_IP tupalm.site TXT +short` shows it. Edit it and delete it the same
   way. A record that would break the zone is refused with the reason (for example a CNAME on a name
   that has other records, or an NS record for a name with no address).
6. Point the domain at your server, at your registrar (only when you are ready to move its DNS here,
   since the registrar's own records stop being used):
   - First register the name servers with their address (often called "child name servers", "glue
     records" or "register name servers"): `ns1.tupalm.site` and `ns2.tupalm.site`, both with the
     VPS IP. The zone's **Name servers** card lists what to enter and has copy buttons.
   - Then set the domain's name servers to `ns1.tupalm.site` and `ns2.tupalm.site`.
   - Back in the zone, **Check now**. It says **Uses these name servers** once public DNS lists your name
     servers; registries can take a few hours to publish the change.
   - Many registries want two name servers on different addresses. Both point at one server here; if
     the registrar refuses that, use name servers on two servers (tick **Use other name server
     names** when adding the zone), or keep the registrar's DNS and add the records there instead.
7. Settings: **Zone settings** changes the default TTL and the contact address. **Apply again** sends
   the zone to the server again (for example after reinstalling BIND). **Delete zone** asks you to
   type the domain, then removes it from the server.
8. If port 53 is closed at your provider (some block it), `dig @VPS_IP` times out from outside while
   `dig @127.0.0.1 tupalm.site` on the server works.

### Trying email hosting

VaultPanel can host email for your domains on your own server, like cPanel or CyberPanel: mailboxes you
read in any mail app, forwarders, and DKIM-signed outgoing mail. Only staff see the Email page.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`, then
   restart the backend as root (that updates This server's agent to 0.16.1), the worker and the
   frontend. Other servers need **Update agent** (0.16.1) before they can host email. Agent 0.16.0
   set up only Dovecot 2.3 and stopped with `MAIL_UNSUPPORTED` on Ubuntu 26.04 and Debian 13
   (Dovecot 2.4); 0.16.1 sets up both, so update and click **Set up email** again.
2. Pick the mail host name, for example `mail.tupalm.site`. If VaultPanel runs the DNS for
   `tupalm.site` (see "Trying DNS zones"), it adds the address for you. Otherwise add an A record for it
   with the VPS IP where the domain's DNS is.
3. For a trusted certificate (so mail apps do not warn): add a website for `mail.tupalm.site` under
   **Websites** and issue its SSL certificate. You can also do this later and set up again.
4. Open **Email** in the sidebar (under Web). On the **Mail servers** card, click **Set up email** next
   to This server, enter the host name and confirm. The job installs Postfix, Dovecot and OpenDKIM and
   opens ports 25, 465, 587, 993 and 995 when the firewall is on. The server then shows **Running**, and
   **Let's Encrypt** or **Own certificate**.
5. Click **Check DNS**. "Host name" should say it points at the VPS IP. "Reverse DNS" usually says the
   IP points back at something like `vmi3632702.contaboserver.net`: set the reverse DNS (PTR) of the IP
   to `mail.tupalm.site` in your Contabo customer panel, or Gmail and others may refuse your mail.
6. **New domain**: enter `tupalm.site`, keep **Add its records to the DNS zone** ticked, and **Add
   domain**. On the domain's **DNS records** tab, MX, SPF, DKIM and DMARC show **In place** a few
   seconds later (DKIM appears once the server made the key). If the domain's DNS is elsewhere, copy the
   four records there; **Check public DNS** shows when they are live.
7. **New mailbox**: `info`, leave the password empty and **Add mailbox**. Copy the password shown (it
   is shown only once). Edit gives a new one if you lose it.
8. Connect a mail app (the **Mail apps** tab has the settings): IMAP `mail.tupalm.site` port 993
   SSL/TLS, SMTP port 587 STARTTLS (or 465 SSL/TLS), user name `info@tupalm.site`. Send yourself a mail
   from Gmail: it arrives in the inbox. Reply from the app: in Gmail, "Show original" says DKIM: PASS and
   SPF: PASS.
9. From the server you can check too: `doveadm auth test info@tupalm.site 'the password'` says auth
   succeeded, and `ls /var/mail/vhosts/tupalm.site/info/Maildir/new` lists the mail that arrived.
10. **Forwarders**: `hello` sending to `info@tupalm.site` and your Gmail address: mail to
    hello@tupalm.site reaches both.
11. Turn a mailbox off (Edit, untick **Mailbox is on**): mail still arrives, but the mail app can no
    longer sign in or send. **Check sizes** shows how full each mailbox is.
12. Delete a mailbox (type its address to confirm): with **Also delete the mail stored in it** its
    folder is removed from the server.
13. Some providers block port 25 on new servers. If mail from Gmail never arrives, ask your provider
    whether incoming and outgoing port 25 is open; `ss -ltn | grep ':25 '` on the server shows Postfix
    listening.

### Trying PHP versions per website

Each PHP website runs the PHP version its owner picks. Staff install the versions a server offers;
customers (and staff) pick one per site. Screenshots: `/mnt/project-files/screenshots/php-versions/`.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install`, then restart the backend
   as root (that updates This server's agent to 0.17.0), the worker and the frontend. No migration.
   Other servers need **Update agent** (0.17.0) first.
2. As the owner, open **Servers**, your server, **Websites** tab. Under **Web stack** there is a new
   **PHP versions** card listing what is installed (on Ubuntu 26.04 that is the system's own PHP) and
   which websites use each one.
3. Pick **PHP 8.3** (or any version you don't have) and click **Install**. The job log shows apt-get.
   When Ubuntu or Debian does not ship that version, the agent first adds the ondrej/php repository
   (Ubuntu) or packages.sury.org (Debian), then installs `php8.3-fpm` and the usual extensions. A minute
   or so later the card lists PHP 8.3. If the repository has nothing for your release yet, the job
   stops with `PHP_VERSION_UNAVAILABLE` and leaves apt as it was; try another version.
4. On the server, `ls /etc/php` shows the new version and `systemctl status php8.3-fpm` is running.
5. Sign in as a customer (Customers, open one, or use their own sign-in). **Websites**, **New website**,
   type **PHP site**: the **PHP version** list offers every installed version.
6. Open one of the customer's PHP sites. The **Overview** tab has a **PHP version** card: pick another
   version and click **Switch**. The site shows **Applying changes**, then the badge under its name
   shows the new version. On the server, its pool file moved to `/etc/php/<new version>/fpm/pool.d/`.
   Put a `phpinfo.php` with `<?php phpinfo();` in the site's `public` folder to see it in the browser
   (delete it afterwards).
7. Back on the server page, **Remove** is greyed out for versions websites still use. Remove a version
   no site uses: it is purged with apt-get. The agent refuses (`PHP_VERSION_IN_USE`) while a site or
   phpMyAdmin runs on it, and (`PHP_VERSION_NEEDED`) when removing it would take other software with
   it, such as the system's own `php-fpm` or phpMyAdmin.

### Trying custom NGINX rules

Staff add NGINX rules to a website; they go into its server block (its vhost) like an include. For
real .htaccess files, see the next section. Customers cannot edit them. Screenshot:
`/mnt/project-files/screenshots/custom-nginx/`.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
   then restart the backend as root (that updates This server's agent to 0.18.0), the worker and the
   frontend. Other servers need **Update agent** (0.18.0) first.
2. As the owner, open a website, **Settings** tab. Under **Configuration** there is a new
   **Custom NGINX rules** card. Enter:

   ```
   location /old-page {
       return 301 /;
   }
   add_header X-Frame-Options SAMEORIGIN;
   ```

   and click **Save and apply**. The site shows **Applying changes** for a moment.

3. Open `http://your-domain/old-page`: it redirects to the home page. `curl -I http://your-domain/`
   shows the `X-Frame-Options` header. On the server, `/etc/nginx/sites-available/<site>.conf` has
   the rules between "Custom rules from the panel" and "End of custom rules".
4. Try something not allowed, such as `include /etc/passwd;`: the box says the directive is not
   allowed and the button stays off. Something NGINX itself refuses (for example a second
   `location / { }`) is tested with `nginx -t` on the server: the job fails, the site keeps its old
   configuration, and the website page says the change was not applied.
5. Empty the box and save to remove the rules.
6. Signed in as a customer, the Settings tab has no Custom NGINX rules card.

### Trying .htaccess files

Apache runs behind NGINX for the websites that turn .htaccess files on. It listens on
127.0.0.1:8080 only, so NGINX keeps ports 80 and 443 and the certificates. Screenshots:
`/mnt/project-files/screenshots/htaccess/`.

1. Update as in the section above (agent 0.18.0, `npm run db:migrate`).
2. Open the server, **Websites** tab, **Web stack** card. There is a new **Apache** row: click
   **Install** and wait for the job to finish. `ss -ltnp | grep 8080` shows Apache on 127.0.0.1 only,
   and `ss -ltnp | grep ':80 '` still shows NGINX.
3. Open a PHP website, **Settings** tab. Tick **Use .htaccess files** and click **Save and apply**. The
   site type on its page now reads "PHP 8.3, .htaccess".
4. In the File Manager, create `public/.htaccess` with:

   ```
   RewriteEngine On
   RewriteRule ^hello$ index.php [L]
   Header set X-Htaccess works
   ```

   Open `http://your-domain/hello`: it shows the home page, and `curl -I http://your-domain/hello`
   shows `X-Htaccess: works`. A WordPress site's own .htaccess (pretty permalinks) now works as is.

5. Password protection: create a password file with
   `htpasswd -c /var/www/<site>/.htpasswd alice` (as root, then `chown <site>:<site>` it) and add
   `AuthType Basic`, `AuthName "Private"`, `AuthUserFile /var/www/<site>/.htpasswd`,
   `Require valid-user` to the .htaccess. The browser asks for a password.
6. Lines that are not allowed, such as `SetHandler ...`, `SetEnv ...`, `php_value ...` or
   `Options +FollowSymLinks`, make the site answer "500 Internal Server Error"; the reason is in
   `/var/log/apache2/vp-<site>.error.log`. Remove the line and it works again.
7. Untick **Use .htaccess files** and save: NGINX serves the site again and the .htaccess file is
   ignored. Customers can turn the option on and off for their own sites too.
8. On a server without Apache, the box is greyed out and says to install Apache from the Web stack
   card first.

### Trying the CMS installer

**Web > App Installer** puts WordPress, Joomla, Drupal or Laravel in a PHP website in one step, like
Softaculous. The panel creates a database and database user for the app (counted against a customer's
plan), and the agent downloads the app from its own project, checks it, and runs its installer as the
website's own Linux user. Screenshots: `/mnt/project-files/screenshots/cms-installer/`.

1. Update as in the sections above. This needs agent 0.20.0 and a migration: run `npm run db:migrate`,
   then restart the backend (This server's agent updates itself). Other servers need **Update agent**
   on their page; until then the installer says the agent is too old.
2. The server needs NGINX, PHP-FPM and MariaDB (the Websites tab's **Web stack** card). The agent
   installs the PHP extensions each app needs (mysql, xml, mbstring, curl, zip, gd, intl) and, for
   Drupal and Laravel, Composer, the first time.
3. Open **Web > App Installer** and click **Install** on **WordPress**. Choose **A new website**, type a
   domain that points at the server (or pick an existing PHP website), leave **Folder** empty, and click
   **Install WordPress**. A box shows the address, the admin page, the admin username and password
   once: save the password, the panel does not keep it.
4. The app shows under **Installed apps** as Preparing, then Installing, then Installed with its
   version (a minute or two; the job icon shows the agent's log). Open the address: the WordPress site
   is there. Click **Admin** and sign in with the saved username and password.
5. Joomla works the same way (it needs PHP 8.1 or newer). Its admin page is `/administrator/`.
6. **Folder**: type `blog` to install WordPress or Joomla at `example.com/blog`. The folder must be
   empty; an existing site's placeholder `index.php`/`index.html` is replaced, but other files stop the
   install with `CMS_TARGET_NOT_EMPTY`. Pretty permalinks in a folder need .htaccess files turned on
   (see the section above); at the site's root they work as is.
7. **Laravel** (PHP 8.2 or newer) and **Drupal** (PHP 8.1 or newer) are installed with Composer into a
   project folder at the top of the site (`laravel` or `drupal` by default). The website's document root
   is switched to the project's `public/` (Laravel) or `web/` (Drupal) folder, so `.env` and `vendor/`
   are never served. Laravel gets its `.env` with the database, an app key and its migrations run; open
   the address to see the Laravel welcome page. Drupal is installed with Drush and its admin page is
   `/user/login`. Only one Drupal or Laravel app fits in a website, and not next to another app.
8. Each website has an **Apps** tab listing what is installed in it, with the same Install button.
9. Click the bin icon on an installed app: its files are deleted (the website stays), and with
   **Also delete its database** ticked, its database and user too. For Drupal and Laravel, the
   website's document root goes back to what it was.
10. Signed in as a hosting customer, App Installer shows only their own websites and apps. Each install
    uses one database and one database user from their plan; when the plan is full the install is
    refused before anything is made.
11. What can go wrong: `CMS_PHP_TOO_OLD` (switch the site to a newer PHP first), `CMS_SOURCE_UNAVAILABLE`
    (the server cannot reach wordpress.org, GitHub or packagist.org), `CMS_CHECKSUM_MISMATCH` (the
    download did not match its published checksum, so nothing was installed). A failed install
    leaves no files behind; remove it from the list to also drop its database.

### Trying panel email

The panel can now send its own email through an SMTP server you enter on **System > Panel Email**: invite
links for new users and customers, password reset links, a "Forgot your password?" link on the
sign-in page, and alerts (failed backups, cron jobs and deployments, firing alerts, servers going
offline). This is separate from the email hosting on **Web > Email**, though a mailbox made there can
be the account the panel sends from.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
   then restart the backend, the worker and the frontend. No agent update is needed.
2. Open **System > Panel Email**. Enter your SMTP details:
   - A mailbox made on **Web > Email**: host = its mail host name (for example `mail.example.com`),
     port `587`, security **STARTTLS**, user name = the full mailbox address, its password, and the same
     address as **From address**.
   - Or a service such as Brevo, Mailgun, Amazon SES or Gmail (with an app password): use the host,
     port and login it gives you.
     Many VPS providers (Contabo too) block outgoing port 25, so use 587 or 465.
3. Type your own address in **Send a test email to** and click **Send test email**. "Sent to ..." means
   the mail server accepted it; check your inbox and spam folder. A problem shows a plain reason, for
   example a wrong password, a port that does not answer (blocked or wrong), or the wrong security
   option for the port (SSL/TLS goes with 465, STARTTLS with 587). The test works before you save.
4. Tick **Send email from the panel** and click **Save settings**. The badge at the top says
   **Sending email**. The password is stored encrypted and never shown again.
5. **Invites**: on **Users**, click **Invite user** with an address you can read. The box says
   "Emailed to ..." and still shows the link. The email has the link; open it to choose a password.
   Creating a customer under **Hosting > Customers** without a password emails their invite the same
   way, and so does the billing API.
6. **Reset links**: edit a user and click **Create password reset link** (or **Password reset link**
   on a customer's page). The link is emailed and shown.
7. **Forgot password**: sign out. The sign-in page now shows **Forgot your password?** Click it, enter
   your address and click **Email me a reset link**. The answer is the same for any address, so it
   does not tell anyone which addresses have accounts. The email arrives within seconds. Asking again
   within 5 minutes sends nothing more.
8. **Alerts**: under **Alerts by email**, tick the events you want (the failure events are ticked at
   first), keep **Send to owners and admins**, add any other addresses, and click **Save alert
   emails**. To see one, stop a server's agent (`systemctl stop vaultpanel-agent` on a second server)
   and wait about two minutes for **Server went offline**, or run a cron job that fails
   (`exit 1`). Alert emails are sent by the worker, so it must be running.
9. **Recent emails** at the bottom lists what went out, with the reason for any that failed. Failed
   alerts are tried again up to 4 times over about 40 minutes.
10. Untick **Send email from the panel** and save: nothing is emailed any more, the sign-in page goes
    back to "Ask an owner or admin", and links are shown to hand over as before.

### Trying the login message (VaultPanel only)

Update as usual and restart the backend as root: This server's agent becomes 0.23.0. Other servers
need their agent updated ("Update agent" on the server page).

It is on by default: the first time the agent starts on a server, it switches to "VaultPanel only"
by itself.

1. Log in to the server over SSH: the VaultPanel banner shows with its links, then "Last login", then
   your prompt. No Ubuntu welcome text or news:

   ```
    * Website:         https://www.vaultpanel.net
    * Documentation:   https://www.vaultpanel.net/docs/
    * Best Practices:  https://www.vaultpanel.net/docs/best-practices/
    * VaultPanel:      https://cp.vaultpanel.net/
    * VaultPanel CLI:  vaultpanel

   Last login: ...
   ```

   The VaultPanel line is the panel's address (System > Panel Domain); it follows a change within a
   minute.

2. Open the server's **Terminal** tab: the same banner shows above the prompt.
3. In the panel open the server, **Security** tab. The **Login message** card says **VaultPanel only**.
   Click **Show the system's message**, log in again: the original message is back. Restarting the
   agent keeps it that way.
4. Click **Show only VaultPanel**: the banner is back.

### Trying static website Git deploy

Update as usual (`npm run db:migrate` adds the new tables) and restart the backend as root: This
server's agent becomes 0.22.0. Other servers need their agent updated ("Update agent" on the server
page). Git must be installed on the server (Software card on the server page). A build that uses npm
needs Node.js installed system-wide, as apps do.

Git deploy is optional. A static site without it is managed with the file manager as before.

1. Open a **static** website and its **Deployments** tab (or click **Deploy from Git** at the top
   of the page).
2. Fill in **Git repository** (for a quick try: `https://github.com/octocat/Spoon-Knife.git`),
   **Branch** `main`, and leave **Build command** and **Output folder** empty for plain HTML. Keep
   **Deploy now** ticked and click **Turn on Git deploy**. The log shows the clone, then
   "Switching current to releases/...", then the health check. Visit the site: it shows the
   repository's page.
3. For a site that is built (Vite, React, Astro...), set **Build command** (for example
   `npm run build`) and **Output folder** (`dist`, or `build` for Create React App). With a
   package.json and no **Install command**, the dependencies are installed with npm first. To try
   it with Spoon-Knife: Install command `npm init -y` and `npm install vite` on two lines, Build
   command `npx vite build`, Output folder `dist`, then **Save settings** and **Deploy now**.
4. **Deployments** lists each deploy with its commit. **Roll back** on an older one makes it live
   again at once, without rebuilding. A deploy whose build fails leaves the live release in place
   and says which step failed (**Log** shows why).
5. Private repository: use its `git@github.com:you/site.git` address, copy the **Deploy key** into
   the repository (GitHub: Settings, Deploy keys), then **Deploy now**.
6. **Push to deploy**: **Turn on**, copy the URL into the repository's webhooks (content type
   application/json, push events) and the secret into its **Secret** field. Each push to the branch
   deploys the site.
7. **Settings** tab: **Document root** now shows `current` and is locked while Git deploy is on.
8. **Turn off Git deploy**: the site serves its old folder (`public/`) again, with the files it had
   before.

#### Environment variables and the Deploy button

Update as usual (`npm run db:migrate` adds the variables table) and restart the backend as root:
This server's agent becomes 0.24.0. Variables need agent 0.24.0 on the site's server.

1. On a static website with Git deploy on, the top of the page has a **Deploy** button. Click it:
   a new deployment starts and the page opens the **Deployments** tab.
2. Open the **Environment** tab. Add a variable, for example `VITE_TITLE` = `Hello`, and click
   **Save and deploy** (or **Save variables**, used by the next deploy).
3. The deploy log lists the variable names under Build ("Environment variables for the install and
   build: VITE_TITLE"); values are never logged. A Vite site sees it as `import.meta.env.VITE_TITLE`.
4. **Edit as text** takes a `.env` file pasted in, one `KEY=value` per line. PORT, PATH, HOME and
   USER are set by VaultPanel and refused.
5. The build copies the variables it uses into the site's files, so do not put passwords here.

### Trying automatic SSL renewal and expiry alerts

Update as usual (`npm run db:migrate` adds four columns to the certificates table), then restart the
backend as root, the worker and the frontend: This server's agent becomes 0.25.0. Other servers need
**Update agent** on their page; until then Certbot there keeps its own 30-day window, and the panel
still renews their certificates when Certbot misses one.

Let's Encrypt certificates always last 90 days; this sets how early they renew, not how long they last.

1. Open **Web > SSL Certificates**. The **Automatic renewal** card shows **Renew this many days before
   expiry** (30) and **Warn when this many days are left** (14).
2. Set the first to `45` and the second to `50`, then click **Save**: it is refused, because the
   warning has to start after renewal does. Set the second to `20` and **Save**. The message says it
   was applied, and each server with certificates runs **Set SSL renewal window** (see **Jobs**). Its
   log lists each certificate, such as "vp-blog: renews 45 days before expiry".
3. On the server, check the window and Certbot's timer:
   `grep renew_before_expiry /etc/letsencrypt/renewal/vp-*.conf` shows `45 days`, and
   `systemctl list-timers | grep certbot` (or `snap.certbot.renew` for the snap) shows the timer.
   If the timer was off, the job's log says it turned it on.
4. Ask Certbot what it would do: `certbot renew --dry-run` tries every certificate against the
   staging service without changing anything.
5. The panel's own renewal: it checks every few minutes for certificates a day or more inside the
   window that Certbot has not renewed, and runs **Renew SSL certificate** for them, once a day per
   certificate. To see it, set the window to a number larger than a certificate's days left (on the
   website's **SSL** tab, **Expires** shows them) and wait up to five minutes: a renewal job appears
   in **Jobs** without anyone clicking **Renew**, and the expiry date moves on.
6. Alerts: on **Automation > Webhooks** and **System > Panel Email**, the events **An SSL certificate is
   close to expiring**, **An SSL certificate expired** and **Automatic SSL renewal failed** can be
   ticked. A certificate with fewer days left than the warning number shows **Expiring soon** and sends
   the expiring event once (again only if it renews and gets close to expiry again).
7. Agent older than 0.25.0 on a server: the card names it and says Certbot there keeps 30 days.

### Trying the financial report

**Hosting > Financial Report** shows what your hosting accounts are worth at their plans' prices. VaultPanel
takes no payments, so these are expected amounts, not money received: your billing system (WHMCS,
Blesta...) has the record of what was actually paid.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install`, then restart the backend
   and the frontend. No migration or agent update is needed.
2. Give your plans prices on **Hosting > Hosting Plans** (a plan without a price is left out of the
   amounts, and the report says how many accounts that affects). Quarterly and yearly prices are spread
   over months: $290 a year counts as $24.17 a month.
3. Open **Hosting > Financial Report**:
   - **Expected each month** and **each year**: active accounts at their plan's price.
   - **On hold (suspended)**: what suspended accounts would bring in once unsuspended.
   - **Accounts**: how many were added and removed in the period.
   - **By plan**: accounts on each plan and their expected amount per month.
   - **Month by month**: accounts open at the end of each month and their value, with accounts added,
     removed and suspended. Past months use each account's current plan, since plan changes are not
     kept per month.
4. Pick **Last 3, 6, 12, 24 or 36 months** at the top, and **Download CSV** for a spreadsheet.
5. Plans in different currencies are never added together: the cards show the biggest one and a note
   lists the others.
6. Only owners and admins see the report. Customers and other roles cannot open it.

### Trying name servers and subdomains for customers

Hosting customers now see the name servers to use on **My Hosting**, and can add subdomains of
their own domains on **Web > Subdomains**.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`
   (adds the new columns), then restart the backend, worker and frontend. No agent update is needed.
2. As the owner, open **Web > DNS Zones**. On a server where DNS is set up, click **For customers**.
   Enter your name servers (for example `ns1.yourbrand.com, ns2.yourbrand.com`; they must point at
   this server) and tick **Add a DNS zone for each new customer domain**. Save. The server's row
   now says what customers see.
3. Sign in as a hosting customer on that server. **My Hosting** has a **Name servers** card with
   the name servers and a copy button for each.
4. As the customer, add a website for a new domain, for example `example.com` with
   `www.example.com`. Once the site is created, a zone for `example.com` appears on the owner's
   **DNS Zones** page with your name servers, and the customer's **Name servers** card lists the
   domain. **Check** asks public DNS whether the registrar already uses the name servers.
5. As the customer, open **Web > Subdomains** and click **New subdomain**. Type `blog`, pick
   `example.com`, choose Static or PHP and **Create subdomain**. It becomes its own site
   (`blog-example-com`) on the same server. When this panel answers DNS for `example.com`, an A
   record for `blog` is added to the zone, and the list shows **Record added**. Otherwise add the
   A record where the domain's DNS is.
6. Subdomains count against the plan's new **Subdomains** limit, not its websites (set it on
   **Hosting > Hosting Plans**; empty means no limit). **My Hosting** shows the count.
7. Delete the subdomain with the bin icon: its site goes, and so does the record VaultPanel added.
8. A customer cannot add a subdomain or website under another account's domain (for example
   `shop.someone-else.com`), or under one of your own zones that is not theirs: the form says
   which domain it belongs to. Owners and admins are not limited, and a subdomain they add under a
   customer's domain belongs to that customer.
9. Removing a customer's account also removes the DNS zones that were added for it.

### Trying zip upload, extract and compress

The website file manager now takes big files (a whole site as a zip, for example), unpacks archives
and makes zips.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`
   (adds the uploads table), then restart the backend as root, the worker and the frontend. This
   server's agent becomes 0.26.0. On other servers click **Update agent** on the server's page.
2. Open a website, then the **Files** tab. Click **Upload** and pick a zip bigger than 1 MB (up to
   2 GB; `VAULTPANEL_FILE_UPLOAD_MAX_MB` in `.env` changes that). A bar shows how much has gone up,
   then **Saving ... on the server** while the agent fetches it from the panel and checks it. The
   file appears in the list, owned by the website's user.
3. Upload the same file again: you are asked whether to replace it.
4. On the zip's row, click the **Extract** icon (a folder with an arrow). **Extract into folder** is
   the folder you are in; type a new name such as `public/shop` to unpack into a new folder, or empty
   it for the home folder. Leave **Replace files that already exist** off to keep files you already
   have. Click **Extract**: a message says how many files were unpacked. `.tar.gz`, `.tgz` and
   `.tar` files work the same way.
5. Tick the boxes next to a few files or folders, then click **Compress** in the toolbar (or the box
   icon on one row). Name the zip and click **Compress**. The zip appears in the same folder.
   Download it with the arrow icon to check what is inside (downloads in the file manager are still
   limited to 1 MB; use SFTP for bigger ones).
6. Limits you may see: **ARCHIVE_TOO_LARGE** (the archive unpacks to more than 20 GB), **DISK_FULL**
   (not enough free space to unpack it), **FILE_EXISTS** (a zip with that name is already there),
   **AGENT_OUTDATED** (the server's agent is older than 0.26.0: click **Update agent**).
7. Behind a domain: the panel's NGINX takes up to 64 MB per request, and uploads go up in 8 MB
   pieces, so no NGINX change is needed.

### Trying terminal recording

The panel records each terminal session as it runs so an owner can replay it later. Recording happens
in the panel, so no agent update is needed. Only owners can see sessions and recordings.

1. Update to this version: the update recipe at the top (pull, `npm install`, migrate), then restart
   the backend, the worker and the frontend. The migration adds the `terminal_sessions` table.
2. Open **Terminal** in the sidebar. A red **● Recording** badge sits next to **Connected**. Run a few
   commands (`uptime`, `ls /etc`, `top` then q), then type `exit`.
3. Click the **Sessions and recordings** tab. Your session is at the top with the server, who opened
   it, when, how long it lasted and **Screen** under Recording.
4. Click the row (or **Replay**). The page shows who, from which address, how it ended and how much
   output there was, and a player below it. Press **Play**: your commands appear as they did, with
   colours and `top` redrawn. Try the slider to jump around, the speed (0.5× to 8×) and **Skip idle
   time** (long pauses shortened to 2 seconds).
5. **Download** saves a `.cast` file (asciicast v2). `asciinema play file.cast` plays it in any
   terminal, and asciinema.org's player opens it too.
6. Back on the tab, the **Recording** card has the settings:
   - Untick **Record terminal sessions** and Save, open a new terminal: there is no Recording badge,
     and the session is listed as **Not recorded** (it still shows who opened it and when).
   - Tick **Also record what is typed**: a warning explains that typed passwords (sudo, `mysql -p`) are
     kept. Open a terminal, run something, exit: the replay page has a **What was typed** list, one
     line per command with its time (click a time to jump there). Turn it off again afterwards.
   - **Keep recordings for (days)**, default 90: older sessions and their files are deleted by the
     worker. **Largest recording (MB)**, default 50: a session that prints more keeps running, but its
     recording stops there and is marked **Cut at size limit**.
     Settings apply to terminals opened after saving.
7. On a finished session, **Delete** removes it and its file. A session that is still open cannot be
   deleted (the button is greyed out).
8. **Security > Audit Log** shows **terminal.recording.view**, **terminal.recording.download**,
   **terminal.recording.delete** and **terminal.recording.settings**, besides the terminal's own open
   and close entries.
9. Sign in as an admin: there is no Terminal page, and `/api/v1/terminal-sessions` answers 403.

Recordings are files under the panel's data folder, in `terminal-recordings/` (readable by the
panel's user only). If the panel restarts while a terminal is open, that session is marked ended
with "The panel restarted".

### Trying the plugin directory

Update first: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
then restart the backend, the worker and the frontend. No agent update is needed.

A plugin directory is a list of plugins at a URL. VaultPanel has none built in; the example
**Status Board** plugin serves a small one that lists itself, so you can try it on the VPS.

1. Open the plugin's port if the firewall is on (`ufw allow 4100/tcp`) and start the plugin, as in
   "Trying Phase 10, part 3" above:

   ```sh
   cd ~/VaultPanel
   PLUGIN_PUBLIC_URL=http://VPS_IP:4100 node examples/status-board-plugin/server.js
   ```

   It prints `Or add this plugin directory in the panel: http://VPS_IP:4100/directory.json`.
   If Status Board is still installed from earlier, remove it first (its page, **Settings → Remove**).

2. Open **Plugins** and the **Directory** tab. It says there are no directories yet. Click
   **Add directory**, paste that directory URL and click **Add directory**. "VaultPanel examples ·
   1 plugin" appears with "read just now".
3. Below it, **Status Board 1.0.0** is listed with **Hosted**, "Asks for Read", 7 events and
   "monitoring". Type `board` in the search box or pick the category to filter.
4. Click **Install**. The panel reads its manifest and opens the usual review, with "Listed in
   VaultPanel examples". Approve and install, then restart the plugin with the token and secret as in
   step 4 of "Trying Phase 10, part 3". Back on the Directory tab, the card now says **Installed**.
5. A newer version: stop the plugin and start it again with `PLUGIN_VERSION=1.1.0` in front (keep
   the token and secret). On the Directory tab click **Read all again**: the card shows **Update
   from 1.0.0**, and the **Installed** tab shows "1.1.0 available" next to Status Board.
6. Click **Update from 1.0.0**. It opens the plugin's **Settings**, which says the directory lists
   1.1.0. Click **Check for changes**, tick the approval and click **Approve and update**. The
   plugin is now 1.1.0 and the notice is gone.
7. Stop the plugin and click **Read again** on the directory: a warning says it could not be read
   (the connection is refused), and Status Board is still listed from the last good copy.
8. **Remove** the directory: its plugins leave the Directory tab, and Status Board stays installed.
   **Security → Audit Log** shows `plugin.directory.add` and `plugin.directory.remove`.
9. Errors you may see when adding: **DIRECTORY_UNREACHABLE** (the URL did not answer, or the
   address is not allowed: on the same server, start the plugin with
   `PLUGIN_EVENTS_URL=http://127.0.0.1:4100` and set `VAULTPANEL_PLUGIN_ALLOW_LOCAL=true` in `.env`),
   "This is not a VaultPanel plugin directory" (the file is not in the directory format, see
   docs/plugins.md), **DIRECTORY_ADDED** (already added).
10. When done, remove the plugin, stop it and close the port: `ufw delete allow 4100/tcp`.

### Trying permissions and big files in the file manager

The website file manager can now change permissions, and open and download files bigger than 1 MB.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`
   (adds the downloads table), then restart the backend as root, the worker and the frontend. This
   server's agent becomes 0.27.0. On other servers click **Update agent** on the server's page.
2. Open a website, then the **Files** tab. On a folder's row click the key icon (**Permissions**).
   Tick or untick Read, Write and Open for Owner, Group and Everyone, or type the number (folders
   are usually `755`, files `644`). Tick **Also change everything inside** to set the folders
   inside to the same and the files inside to the second number. Click **Save permissions**: a
   message says how many files and folders changed, and the **Mode** column shows the new value.
   Links are skipped, and the website's home folder itself cannot be changed.
3. Download a file bigger than 1 MB with the arrow icon: a bar says **Getting ... from the server**,
   then your browser saves it (up to 2 GB; `VAULTPANEL_FILE_DOWNLOAD_MAX_MB` in `.env` changes that).
   The panel keeps its copy for an hour, and only you can download it.
4. Click a text file between 1 and 10 MB (a big log or SQL file, for example): it opens in the
   editor. Change it and click **Save**; bigger files are saved the way big uploads are. Files over
   10 MB can be downloaded but not opened, and binary files say they are not text.
5. **AGENT_OUTDATED** means the server's agent is older than 0.27.0: click **Update agent**.

### Trying uploaded and wildcard SSL certificates

A website can now use a certificate you bought elsewhere, or one Let's Encrypt wildcard certificate
(`example.com` and `*.example.com`) that covers every subdomain.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install`, then restart the
   backend as root, the worker and the frontend. This server's agent becomes 0.28.0. On other
   servers click **Update agent** on the server's page.
2. **Upload a certificate.** Open a website, then the **SSL** tab. Choose **Upload a certificate**
   (on a site that already has HTTPS, click **Replace certificate** first). Paste the certificate
   with its intermediate certificates (the CA bundle) after it, and the private key without a
   passphrase, or use **Load from a file**. Click **Install certificate**. Mistakes show at once:
   a key that does not belong to the certificate, an expired one, or a domain of the site it does
   not cover. When it is done, **Source** says **Uploaded** and the SSL Certificates page shows an
   **Uploaded** badge. VaultPanel never renews it: upload the renewed one before it expires (the
   expiry alerts still warn you). The key is sent to the server once and not kept in the panel.
3. To try it without buying one, make a self-signed certificate on the server (browsers will warn):
   `openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout key.pem -out cert.pem -days 90 -subj /CN=example.com -addext "subjectAltName=DNS:example.com,DNS:www.example.com"`
   with your site's domains, then paste `cert.pem` and `key.pem`.
4. **Wildcard certificate.** Let's Encrypt checks wildcards through DNS, so the domain needs a DNS
   zone on the same server (**Web > DNS Zones**), and the domain's name servers at the registrar
   must point at that server (see "Trying DNS zones"). Then on the **SSL** tab, under
   **Let's Encrypt**, tick **Wildcard certificate (\*.example.com)** and click **Issue
   certificate**. The option appears when all the site's domains are one domain and names one
   level under it (`example.com`, `www.example.com`, `shop.example.com`). The operation log shows
   the check record being added to the zone and removed again; **Covers** then says
   `example.com, *.example.com`, and new subdomains added to the site are covered without issuing
   again. Certbot renews it on its own like any other certificate.
5. **DNS_ZONE_MISSING**: add the zone on the DNS Zones page of the site's server first.
   **WILDCARD_NOT_POSSIBLE**: the site's domains do not fit one wildcard (for example
   `a.b.example.com`); issue a normal certificate. A failed wildcard request that mentions DNS
   usually means the name servers at the registrar do not point at this server yet.
   **AGENT_OUTDATED**: click **Update agent**.

### Trying wildcard domains

A website can serve every subdomain of a domain with one entry, `*.example.com`, for example an
app that gives each customer their own subdomain.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install`, then restart the
   backend as root, the worker and the frontend. This server's agent becomes 0.37.0. On other
   servers click **Update agent** on the server's page.
2. At your DNS provider (or in **Web > DNS Zones** when VaultPanel runs the domain's DNS), add an
   `A` record named `*` with the server's address. `dig +short anything.example.com` prints it.
3. Open a website, **Edit domains**, and add `*.example.com` under **More domains**. Save. Any
   name under it (`shop.example.com`, `abc.example.com`) now shows the site.
   **Check DNS** looks up a random name under the wildcard, so it says OK only when the `*`
   record exists.
4. A name with its own site wins: create another website for `admin.example.com`, and that name
   shows the other site while every other subdomain still shows the first.
5. **HTTPS.** On the **SSL** tab the **Wildcard certificate (\*.example.com)** box is ticked. It
   needs the domain's DNS zone on this server (see "Trying uploaded and wildcard SSL
   certificates"). With your DNS elsewhere, untick it: the certificate covers the site's other
   domains, and a warning lists `*.example.com` as not covered (HTTPS on other subdomains then
   shows a certificate warning). Uploading a wildcard certificate bought elsewhere also works.
6. Refused: `*.*.example.com` and `shop.*.example.com` (one `*.` at the start only), `*.co.uk`
   (it would catch other people's domains), and wildcards on servers whose agent is older than
   0.37.0 (**AGENT_OUTDATED**).

### Trying wildcard certificates through Cloudflare or Namecheap

A domain whose DNS stays at Cloudflare or Namecheap can get a Let's Encrypt wildcard certificate:
the agent adds the check record there through the provider's API.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
   then restart the backend as root, the worker and the frontend (or `sudo vaultpanel update`). This
   server's agent becomes 0.38.0; on other servers click **Update agent**.
2. Get credentials:
   - **Cloudflare**: My Profile > API Tokens > Create Token > the **Edit zone DNS** template, limited
     to your domain. Copy the token.
   - **Namecheap**: Profile > Tools > Namecheap API Access. Namecheap turns it on only for accounts
     with 20 domains, or $50 on the account or spent in the last two years. Copy the API key, and
     under **Whitelisted IPs** add the server's public IPv4 address (`curl -4 ifconfig.me` on the
     server). The domain must use Namecheap's BasicDNS or PremiumDNS.
3. Open **Web > DNS Zones**. Under **DNS providers** click **Add provider**, pick the provider, give
   it a name, paste the token (and for Namecheap your user name and the API key) and save. The
   secret is not shown again; **Edit** with an empty secret keeps it.
4. Open a website whose domains fit one wildcard (`example.com`, `*.example.com`, `shop.example.com`),
   the **SSL** tab. Tick **Wildcard certificate**, pick your provider under **Check DNS through**
   and click **Issue certificate**. The log shows "Let's Encrypt checks example.com through
   Cloudflare", then the hook adding the record; it can take a few minutes for Namecheap. When it is
   done, **Covers** says `example.com, *.example.com` and **DNS check** names the provider.
5. On the server, `sudo ls -l /etc/vaultpanel-agent/acme-dns/` shows `vp-<site>.json` with mode
   `-rw-------` (root). `sudo certbot renew --cert-name vp-<site> --dry-run` renews through the
   provider the same way.
6. For Namecheap, check the domain's records at Namecheap afterwards: they are all still there, and
   the `_acme-challenge` TXT record is gone again.
7. Errors: **AGENT_OUTDATED** (update the agent), "Whitelist <address> under Profile > Tools >
   Namecheap API Access", "the API token sees no zone that holds …" (the token is limited to other
   domains), "does not use Namecheap's name servers". **Remove** on a provider is refused while a
   certificate renews through it (**DNS_PROVIDER_IN_USE**).

### Trying website uptime monitoring

The panel checks each website the way visitors reach it, and alerts when one goes down.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
   then restart the backend, the **worker** (it runs the checks) and the frontend, or
   `sudo vaultpanel update`. No agent update is needed.
2. Open a website's **Overview**. Within 5 minutes the **Uptime** card shows **Up**, the address
   checked (`https://` when the certificate covers the domain), the response time and the
   certificate's expiry. **Check now** checks at once.
3. Make it fail: for a reverse proxy site, stop its app; for any site, `sudo systemctl stop nginx`
   on its server. **Check now** shows **Down** with the reason ("Connection refused", "HTTP 502…").
   After the next regular check (it tries twice, 10 seconds apart) the **Websites** list shows a red
   **Down** badge, and about a minute later **Alerts** shows **Website down** for that address,
   with the alert email and webhooks you set up.
4. Bring it back (`sudo systemctl start nginx`). The next check shows **Up**, **Recent downtime**
   lists how long it was down, and the alert resolves.
5. A certificate browsers would refuse also counts as down: an expired one, one that does not
   cover the domain, or a self-signed one. Let's Encrypt staging certificates are untrusted on
   purpose and are not counted.
6. **Turn monitoring off** on the card for a site you do not want checked; its open alert
   resolves. To change how often websites are checked, set `VAULTPANEL_UPTIME_CHECK_SECONDS` in
   `/opt/vaultpanel/.env` (at least 60; `0` turns regular checks off) and restart the worker.
7. Domains pointing at an internal address (127.0.0.1, 169.254.169.254, a private network that is
   not the site's server) are reported down without being contacted.

### Trying the WHMCS module

Sell VaultPanel hosting from a WHMCS installation (WHMCS 8, PHP 7.4 or newer). The full steps are in
[integrations/whmcs/README.md](../integrations/whmcs/README.md); in short:

1. Update the panel (`sudo vaultpanel update`). Give it a panel domain with a trusted certificate
   (**System > Panel Domain**), since WHMCS refuses self-signed certificates.
2. In VaultPanel: create a hosting plan (**Hosting > Hosting Plans**) and a billing API key
   (**Hosting > Billing API > New API key**). Copy the key.
3. Copy `integrations/whmcs/modules/servers/vaultpanel` to `<whmcs>/modules/servers/vaultpanel`.
4. In WHMCS, add a server: hostname = the panel domain, module VaultPanel, the key as Password,
   Secure ticked. **Test Connection** says it works. Put it in a server group.
5. Create a product with module VaultPanel: the **Plan** list shows your VaultPanel plans.
6. Place an order as a test client and accept it (or run **Create** from the service page). In
   VaultPanel, **Customers** shows the account with billing id `whmcs-<service id>`, made through
   the Billing API; the WHMCS service's username is the client's email.
7. On the service in WHMCS: **Suspend** turns the account's websites off (VaultPanel shows it
   suspended), **Unsuspend** turns them back on, **Change Package** to a product with another plan
   changes the plan, **Change Password** sets the VaultPanel password.
8. **Log in to VaultPanel** (client area, or the admin service page): VaultPanel opens signed in as the
   customer. Opening the same link again says it expired or was already used.
9. After WHMCS's daily cron has run (it updates server usage), the service's disk usage and limit
   fill in.
10. **Terminate** removes the account and everything it owns. **System Logs > Module Log** shows
    each call, with the key and passwords hidden.

### Trying the server self-check

Each agent checks what the panel's features need from its server, and the panel alerts when a check
fails, so a problem like the file manager's "Cannot find module" shows up before someone hits it.

1. Update: `sudo vaultpanel update` (or `git pull && npm install && npm run db:migrate` and restart
   the backend, worker and frontend). The panel's own server's agent becomes 0.39.0; on other
   servers click **Update agent** on the Overview.
2. Open a server's **Overview**. The **Self-check** card lists the checks with "N of N passed" and
   the time of the agent's last report (every 5 minutes). **Check now** reads them at once. A
   server whose agent is older says to update it.
3. Agent files: on the server, `sudo touch /opt/vaultpanel-agent/selfcheck-test && sudo chmod 600
/opt/vaultpanel-agent/selfcheck-test`, then **Check now**. **Agent files** fails, names the file
   and gives the command. `sudo rm /opt/vaultpanel-agent/selfcheck-test` and **Check now** again.
   (Making the agent's own code unreadable, such as `fileWorker.js`, also fails **File manager**,
   but the agent would then not start again if it restarted, so do not try it on a server you
   need.)
4. NGINX: `echo 'selfcheck_test on;' | sudo tee /etc/nginx/conf.d/selfcheck-test.conf`, then
   **Check now**. **NGINX configuration** fails with NGINX's `[emerg] unknown directive` line. Do
   not reload NGINX meanwhile. After about 10 minutes **Alerts** shows **Server self-check failed** for
   the server, with the alert email and webhooks you set up. `sudo rm
/etc/nginx/conf.d/selfcheck-test.conf`; the next check passes and the alert resolves.
5. Root helper (agents running as their own user): `sudo systemctl stop vaultpanel-agent-helper`.
   Within a minute the card shows **Root helper** failed instead of the other checks; jobs fail
   with HELPER_UNAVAILABLE meanwhile. `sudo systemctl start vaultpanel-agent-helper` brings the checks back.
6. Warnings do not alert: `sudo systemctl stop certbot.timer` on a server with a certificate shows
   **Certificate renewal** as a warning; issuing or renewing a certificate from the panel turns the
   timer back on (or `sudo systemctl start certbot.timer`).
7. **Alerts > Rules** lists **Server self-check failed** (10 minutes, warning) among the default
   rules; it can be edited, limited to a server or turned off like the others.

### Trying database backups from a website or app

A website's or app's Backups tab can back up its database as well as its files. Each is its own
backup, restored on its own.

1. Update: `sudo vaultpanel update` (or `git pull && npm install && npm run db:migrate` and restart
   the backend and frontend). The agent does not change.
2. **Backups > Back up now** asks **Website files**, **App files** or **Database**, then which
   one. Back up a database and it is listed like before.
3. Link a database to a website: **Databases**, **Link** on the database's row, choose the website
   under **For website**, **Save**. The **Used by** column shows it. (A new database can be linked
   when created, with **For website**. Databases the app installer made for WordPress, Joomla,
   Drupal or Laravel are already linked to their website.)
4. Open the website, **Backups** tab, **Back up now**: choose **Database**, keep the database
   picked and click **Back up now**. The list shows the backup with the database's name in the
   **Of** column; backups of the files say **Files**. Restore and download work as on the Backups
   page; restoring the database leaves the files alone, and the other way round.
5. On a website without a linked database, choosing **Database** says none is linked, with links
   to the Databases page and to create one for the website.
6. **Add schedule** on the same tab: choose **Files** or **Database**. The schedule card lists both
   schedules, each with **Edit** and **Remove schedule**. Choosing a part that already has a
   schedule says saving replaces it.
7. An app works the same way, with the databases linked to the app (**For app**).
8. Unlink: **Link** again, **For website** None, **Save**. The website's tab no longer lists that
   database's backups; the Backups page still does.

### Trying the CLI and SDK as npm packages

The `vaultpanel` command-line tool and the JavaScript SDK are packaged for npm as `@vaultpanel/cli`
and `@vaultpanel/sdk`. They are not on npm yet; until they are, you can install the exact files npm
would get. Do this on your own computer (Node.js 22 or newer), not on the server.

1. In a clone of the repository on `main`: `npm install`, then
   `npm pack -w @vaultpanel/sdk -w @vaultpanel/cli`. Two files appear: `vaultpanel-sdk-0.1.0.tgz` and
   `vaultpanel-cli-0.1.0.tgz`.
2. Install them globally, outside the repository:
   `npm install -g ./vaultpanel-sdk-0.1.0.tgz ./vaultpanel-cli-0.1.0.tgz`. Then `vaultpanel --help`
   works from any folder.
3. In the panel, open **Users > API Tokens**, create a token with **Read** ticked and copy it.
4. `vaultpanel login --url http://VPS_IP:5173` and paste the token. It says
   "Signed in to ... as you@example.com". `vaultpanel whoami` shows your role and the token's
   permissions.
5. `vaultpanel tokens --scopes` lists the scopes your panel offers (Read, Logs, Deploy, Manage
   hosting, Servers, Customers, Everything). `vaultpanel servers list` shows your servers.
6. To remove it again: `npm uninstall -g @vaultpanel/cli @vaultpanel/sdk`.

Once the packages are published (see `docs/publishing.md`), step 1 and 2 become
`npm install -g @vaultpanel/cli`, or `npx @vaultpanel/cli --help` without installing.

### Trying single-page apps (React, Vue)

A React or Vue build has one `index.html` and handles addresses like `/dashboard` itself. Without
help, NGINX answers a refresh on `/dashboard` with "404 Not Found". The **Single-page app** setting
sends every address with no file of its own to `index.html` (NGINX's
`try_files $uri $uri/ /index.html`). You don't paste a server block: VaultPanel writes `listen`,
`server_name` and `root` for each website itself.

1. Update: `cd ~/VaultPanel && git checkout main && git pull && npm install && npm run db:migrate`,
   then restart the backend as root (This server's agent becomes 0.30.0), the worker and the
   frontend. Other servers need **Update agent**.
2. Create a website of type **Static files** (or open one), **Settings** tab. Set **Document root**
   to the folder with the build, for example `build` (Create React App) or `dist` (Vite), tick
   **Single-page app** and click **Save and apply**. The site's type reads "Single-page app".
3. Upload the build in the File Manager (zip upload and Extract work), then open
   `http://your-domain/some/page` and refresh: the app loads instead of a 404. Real files such as
   `/static/js/main.js` are still served as files.
4. Customers can tick it for their own static sites. It is not offered for PHP or reverse proxy
   sites, or while **Use .htaccess files** is on (put the fallback in the .htaccess file then).

### Trying signed webhooks, zero-downtime reloads, Go and Ruby apps, and PHP sites from Git

Update as usual: `git pull`, `npm install`, `npm run db:migrate` (adds the webhook secrets and the
zero-downtime setting), then restart the backend as root so this server's agent becomes v0.32.0.
Update other servers' agents from their server pages.

1. **Signed webhooks**: on an app's **Settings** tab (or a Git-deployed website's **Deployments**
   tab), **Push to deploy** shows **On, signed** or **On, unsigned**. An unsigned webhook was turned
   on before this update: click **Create a new URL**, copy the URL and the **Secret** (both shown
   once), and in GitHub edit the webhook: paste the URL, content type `application/json`, and the
   secret in **Secret**. GitLab: paste the secret in **Secret token**. A push to the branch deploys;
   GitHub's **Recent Deliveries** shows a 202. Change one character of the secret in GitHub and
   **Redeliver**: it gets a 401, the app does not deploy, and the Audit Log shows
   `application.webhook_rejected`.
2. **Zero-downtime reloads** (Node.js apps): set the start command to run a file directly, such as
   `node server.js` (not `npm start`), tick **Zero-downtime reloads** in **Settings**, save, then
   **Apply and restart**. Deploy again while running `while true; do curl -s -o /dev/null -w '%{http_code}\n' https://your-app; sleep 0.2; done`
   in a terminal: every answer stays 200, and the deployment log says `pm2 reload ... (zero downtime)`.
   **Restart** reloads the same way.
3. **Go apps**: on the server page's **App runtime** card, **Install** **Go**. Create an app with
   runtime **Go** from a Go web server that listens on `PORT` (for example
   any small `net/http` server). The
   build defaults to `go build -o app .` and the start command to `./app`. The log shows
   `go mod download`, the build, and the app answering on its port. **Scaling** is not shown: Go apps
   run as one process.
4. **Ruby apps**: **Install** **Ruby** on the same card (Ruby, Bundler and build tools). Create an
   app with runtime **Ruby** from a Rack or Rails app whose Gemfile includes `puma`. Gems install into
   the release's `vendor/bundle`, and the app runs in production (`RACK_ENV` and `RAILS_ENV`; set your
   own in the app's environment to change them). Rails apps need `SECRET_KEY_BASE` in the environment.
5. **PHP websites from Git**: **Install** **Composer** on the **App runtime** card. Create a PHP
   website (or open one), open its **Deployments** tab and connect a repository, for example a
   Laravel app. The output folder defaults to `public`. In the **Environment** tab add the app's
   settings (`APP_KEY`, `DB_DATABASE`...): they are written to the release's `.env`. Each deploy runs
   `composer install --no-dev`, switches PHP-FPM to the new release, and keeps older releases for
   **Roll back**. Files the app writes (uploads, Laravel's `storage/`) live in that release, so keep
   uploads in a database, S3, or a folder outside the release.

### Trying outgoing firewall rules, SSH port changes, keys for other accounts and panel access by address

Update as usual (`git pull`, `npm install`, `npm run db:migrate`), then restart the backend as root
so this server's agent becomes v0.34.0. Update other servers' agents from their server pages. Keep
your provider's web console (Contabo: VNC) at hand for the SSH steps, just in case.

1. **Outgoing rules**: open **Security > Firewall** (the firewall must be on). **Add rule**, choose
   **Outgoing**, click **Mail (SMTP) 25**, Action **Deny**, and add it. The table shows it with an
   **Outgoing** badge and "To anywhere". On the server, `nc -vz -w3 gmail-smtp-in.l.google.com 25`
   now times out. Delete the rule and it connects again. Try an outgoing **Deny** to the panel's own
   address and port: the agent refuses it with LOCKOUT_REFUSED.
2. **Outgoing default**: set **Outgoing connections no rule matches** to **Deny** and confirm. The
   rules table gains "VaultPanel: reach the panel", "DNS", "updates, Git, SSL" and "time" (and mail
   when email hosting is installed). The server stays Online, `apt update` still works, and
   `curl -m5 http://portquiz.net:8080` fails. Set it back to **Allow** when done.
3. **SSH port**: on **Security > SSH**, **Change port**, enter `2222` and leave **Keep port 22 open
   too** ticked. When the job finishes the card says it listens on 22 and 2222, and the firewall has
   a rule for 2222. Check `ssh -p 2222 root@YOUR_SERVER` works (open the port in Contabo's firewall
   too if you use it). Then **Close port 22**: SSH now only answers on 2222, and Fail2ban watches
   2222 (`grep port /etc/fail2ban/jail.d/vaultpanel.local`). Move back to 22
   the same way if you like. Choosing the panel's port, 80 or 443, or a port another program uses,
   is refused.
4. **Keys for other accounts**: create a user on the server (`adduser deploy`). Back on
   **Security > SSH**, pick **deploy** in the account menu next to **Add key**, add a public key, and
   `ssh deploy@YOUR_SERVER` signs in with it. `ls -la /home/deploy/.ssh` shows the folder and file
   owned by deploy, mode 700 and 600. Remove the key and it is gone from the file.
5. **Panel access by address**: open **Security > Authentication > Panel access by address**. Click
   **Add it** next to "Your address", tick **Only accept these addresses**, and **Save panel
   access**. Open the panel from another connection (your phone on mobile data): it shows "The panel
   does not accept your address", and signing in there is refused. Try saving a list without your
   own address: it is refused. With **Staff only**, hosting customers can still sign in from
   anywhere. Untick it when done. Locked out? Add `VAULTPANEL_PANEL_ACCESS=off` to `.env` and restart
   the backend.

### Trying the agent without root

Update as usual (`git pull`, `npm install`), then restart the backend as root so this server's agent
becomes v0.36.0. Update other servers' agents from their server pages. On its first start the agent
moves itself to its own user; nothing else to do.

1. On the server: `systemctl status vaultpanel-agent vaultpanel-agent-helper` shows both running, and
   `ps -o user,args -C node | grep cli.js` shows `vaultpanel-agent ... cli.js run` and
   `root ... cli.js helper`.
2. In the panel the server stays **Online**. Its **Security** tab lists **Agent privileges: The
   agent runs as vaultpanel-agent; a root helper runs only what the panel signed**.
3. Everything still works as before: restart a service, add a firewall rule, open the **Terminal**
   (`id` still says root: the helper opens the shell), deploy an app, take a backup, upload a file.
4. Restart the helper while the panel is open: `systemctl restart vaultpanel-agent-helper`. The
   agent says it reconnected (`journalctl -u vaultpanel-agent -n 5`) and jobs keep working.
5. Going back to one root service: add `"runAsRoot": true` to `/etc/vaultpanel-agent/config.json`
   and run `systemctl restart vaultpanel-agent-helper`. The Security tab then shows **Agent
   privileges** as a warning, "runAsRoot is set in the agent config". Remove the line, then
   `rm /var/lib/vaultpanel/agent-mode.json && systemctl restart vaultpanel-agent` to move it back.

## If something goes wrong

`docs/troubleshooting.md` covers the common problems. If something looks broken, tell Claude in the project chat what you clicked and what you saw.
