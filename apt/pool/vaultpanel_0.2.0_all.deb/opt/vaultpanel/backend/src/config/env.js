// Loads and validates configuration from environment variables. Nothing secret
// has a default: the panel refuses to start without it.
import path from 'node:path';
import { z } from 'zod';
import { REPO_ROOT } from '../utils/agentPackage.js';
import { loadPanelTls } from '../utils/panelTls.js';

// Its default is given as true or false, never 'true' or 'false': Zod returns a
// default as it is, without the transform, and the string 'false' is truthy.
const bool = z
  .enum(['true', 'false', '1', '0'])
  .transform((v) => v === 'true' || v === '1');

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  VAULTPANEL_HOST: z.string().default('127.0.0.1'),
  VAULTPANEL_PORT: z.coerce.number().int().min(1).max(65535).default(4000),
  // HTTPS on VAULTPANEL_PORT: a certificate and its key (PEM files). install.sh
  // makes a self-signed pair, so the panel never starts on plain HTTP.
  VAULTPANEL_TLS_CERT: z.string().default(''),
  VAULTPANEL_TLS_KEY: z.string().default(''),
  // With HTTPS on, the API also answers plain HTTP on 127.0.0.1 at this port:
  // for the agent on this server, the panel domain's NGINX and the vaultpanel
  // command. Default: VAULTPANEL_PORT + 1.
  VAULTPANEL_LOOPBACK_PORT: z.coerce.number().int().min(1).max(65535).optional(),
  // Public URL of the panel, used in agent install commands and links.
  VAULTPANEL_PUBLIC_URL: z.url().default('http://localhost:5173'),
  VAULTPANEL_CORS_ORIGINS: z.string().default(''),
  VAULTPANEL_TRUST_PROXY: z.string().default('loopback'),
  // 32 random bytes, hex or base64. Encrypts secrets at rest and signs tokens.
  VAULTPANEL_SECRET_KEY: z.string().min(32, 'VAULTPANEL_SECRET_KEY is required (32 random bytes, hex or base64)'),
  VAULTPANEL_COOKIE_SECURE: bool.default(true),
  VAULTPANEL_SESSION_TTL_HOURS: z.coerce.number().int().min(1).max(24 * 30).default(12),
  VAULTPANEL_LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  VAULTPANEL_ENROLLMENT_TTL_MINUTES: z.coerce.number().int().min(5).max(7 * 24 * 60).default(60),
  VAULTPANEL_AGENT_OFFLINE_SECONDS: z.coerce.number().int().min(30).default(90),
  VAULTPANEL_METRICS_RETENTION_DAYS: z.coerce.number().int().min(1).default(7),
  // Hourly averages behind the 7, 30 and 90 day charts.
  VAULTPANEL_METRICS_HOURLY_RETENTION_DAYS: z.coerce.number().int().min(7).default(90),
  VAULTPANEL_ALERT_HISTORY_DAYS: z.coerce.number().int().min(1).default(90),
  // How often the panel checks each website the way visitors reach it
  // (0 turns uptime checks off), and how long their results are kept.
  VAULTPANEL_UPTIME_CHECK_SECONDS: z.coerce.number().int().refine((v) => v === 0 || v >= 60, 'At least 60 seconds, or 0 to turn uptime checks off').default(300),
  VAULTPANEL_UPTIME_HISTORY_DAYS: z.coerce.number().int().min(1).max(365).default(30),
  // Allows agents to talk to the panel over plain HTTP. Development only.
  VAULTPANEL_ALLOW_INSECURE_AGENTS: bool.default(false),
  // Where the panel keeps its own files (backup copies prepared for download).
  VAULTPANEL_DATA_DIR: z.string().default(''),
  // The built web interface (frontend/dist). When set, the API serves it too,
  // so one process on one port is the whole panel (how install.sh runs it).
  VAULTPANEL_UI_DIR: z.string().default(''),
  VAULTPANEL_BACKUP_DOWNLOAD_MAX_MB: z.coerce.number().int().min(1).default(10_240),
  // Largest file the website file manager uploads (in pieces, see fileUploadService).
  VAULTPANEL_FILE_UPLOAD_MAX_MB: z.coerce.number().int().min(1).max(10_240).default(2048),
  // Largest website file the file manager downloads through the panel.
  VAULTPANEL_FILE_DOWNLOAD_MAX_MB: z.coerce.number().int().min(1).max(10_240).default(2048),
  // Webhooks may call addresses on private networks (10.x, 192.168.x...).
  // Loopback and link-local addresses are always refused.
  // Off by default: a webhook could otherwise reach services inside your
  // network. install.sh keeps it on for panels installed before this changed.
  VAULTPANEL_WEBHOOK_ALLOW_PRIVATE: bool.default(false),
  // Plugins (their manifest URL and their events) may also use loopback
  // addresses (127.0.0.1), for a plugin running on the panel's own server.
  VAULTPANEL_PLUGIN_ALLOW_LOCAL: bool.default(false),
  // Connect the server the panel runs on automatically when the panel starts
  // as root (see backend/src/cli/connectLocal.js).
  VAULTPANEL_LOCAL_AGENT: bool.default(true),
  // "off" ignores the panel's address allowlist (Security > Authentication),
  // for someone locked out after their address changed.
  VAULTPANEL_PANEL_ACCESS: z.enum(['on', 'off']).default('on'),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  REDIS_URL: z.string().min(1, 'REDIS_URL is required'),
});

export function loadConfig(env = process.env) {
  const parsed = schema.safeParse(env);
  if (!parsed.success) {
    const lines = parsed.error.issues.map((i) => `  ${i.path.join('.')}: ${i.message}`);
    throw new Error(`Invalid configuration:\n${lines.join('\n')}`);
  }
  const c = parsed.data;
  if (Boolean(c.VAULTPANEL_TLS_CERT) !== Boolean(c.VAULTPANEL_TLS_KEY)) {
    throw new Error('Invalid configuration:\n  VAULTPANEL_TLS_CERT and VAULTPANEL_TLS_KEY must be set together');
  }
  const tls = c.VAULTPANEL_TLS_CERT ? loadPanelTls(c.VAULTPANEL_TLS_CERT, c.VAULTPANEL_TLS_KEY) : null;
  const loopbackPort = tls ? (c.VAULTPANEL_LOOPBACK_PORT ?? c.VAULTPANEL_PORT + 1) : null;
  if (loopbackPort === c.VAULTPANEL_PORT || loopbackPort > 65535) {
    throw new Error('Invalid configuration:\n  VAULTPANEL_LOOPBACK_PORT must be a free port other than VAULTPANEL_PORT');
  }
  const envPublicUrl = c.VAULTPANEL_PUBLIC_URL.replace(/\/+$/, '');
  // The panel's address can also be set from the panel (Panel Domain page,
  // services/panelDomainService.js), which then wins over the environment.
  const address = { override: null };
  return Object.freeze({
    env: c.NODE_ENV,
    host: c.VAULTPANEL_HOST,
    port: c.VAULTPANEL_PORT,
    // { certPath, keyPath, certPem, pin, selfSigned, ... } when the panel serves HTTPS itself.
    tls,
    loopbackPort,
    get publicUrl() {
      return address.override ?? envPublicUrl;
    },
    envPublicUrl,
    setPublicUrlOverride(url) {
      address.override = url ? url.replace(/\/+$/, '') : null;
    },
    corsOrigins: c.VAULTPANEL_CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
    trustProxy: c.VAULTPANEL_TRUST_PROXY,
    secretKey: decodeSecretKey(c.VAULTPANEL_SECRET_KEY),
    cookieSecure: c.VAULTPANEL_COOKIE_SECURE,
    sessionTtlHours: c.VAULTPANEL_SESSION_TTL_HOURS,
    logLevel: c.VAULTPANEL_LOG_LEVEL,
    enrollmentTtlMinutes: c.VAULTPANEL_ENROLLMENT_TTL_MINUTES,
    agentOfflineSeconds: c.VAULTPANEL_AGENT_OFFLINE_SECONDS,
    metricsRetentionDays: c.VAULTPANEL_METRICS_RETENTION_DAYS,
    metricsHourlyRetentionDays: c.VAULTPANEL_METRICS_HOURLY_RETENTION_DAYS,
    alertHistoryDays: c.VAULTPANEL_ALERT_HISTORY_DAYS,
    uptimeCheckSeconds: c.VAULTPANEL_UPTIME_CHECK_SECONDS,
    uptimeHistoryDays: c.VAULTPANEL_UPTIME_HISTORY_DAYS,
    allowInsecureAgents: c.VAULTPANEL_ALLOW_INSECURE_AGENTS,
    dataDir: c.VAULTPANEL_DATA_DIR ? path.resolve(c.VAULTPANEL_DATA_DIR) : path.join(REPO_ROOT, 'data'),
    uiDir: c.VAULTPANEL_UI_DIR ? path.resolve(c.VAULTPANEL_UI_DIR) : null,
    backupDownloadMaxBytes: c.VAULTPANEL_BACKUP_DOWNLOAD_MAX_MB * 1024 * 1024,
    fileUploadMaxBytes: c.VAULTPANEL_FILE_UPLOAD_MAX_MB * 1024 * 1024,
    fileDownloadMaxBytes: c.VAULTPANEL_FILE_DOWNLOAD_MAX_MB * 1024 * 1024,
    webhookAllowPrivate: c.VAULTPANEL_WEBHOOK_ALLOW_PRIVATE,
    pluginAllowLocal: c.VAULTPANEL_PLUGIN_ALLOW_LOCAL,
    localAgent: c.VAULTPANEL_LOCAL_AGENT,
    panelAccessOff: c.VAULTPANEL_PANEL_ACCESS === 'off',
    databaseUrl: c.DATABASE_URL,
    redisUrl: c.REDIS_URL,
  });
}

export function decodeSecretKey(value) {
  const key = /^[0-9a-f]{64}$/i.test(value) ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');
  if (key.length !== 32) {
    throw new Error('VAULTPANEL_SECRET_KEY must decode to exactly 32 bytes (generate one with: openssl rand -hex 32)');
  }
  return key;
}
