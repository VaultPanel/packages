import { Router } from 'express';
import { assistantController as c } from '../controllers/assistantController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { askBody, settingsBody, testSettingsBody } from '../validators/assistantValidators.js';
import { idParam } from '../validators/common.js';

export function assistantRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/status', c.status);
  r.get('/settings', c.getSettings);
  r.put('/settings', validate({ body: settingsBody }), c.updateSettings);
  r.post('/settings/test', validate({ body: testSettingsBody }), c.testSettings);
  r.get('/conversations', c.listConversations);
  r.post('/conversations', validate({ body: askBody }), c.startConversation);
  r.get('/conversations/:id', validate({ params: idParam }), c.getConversation);
  r.delete('/conversations/:id', validate({ params: idParam }), c.removeConversation);
  r.post('/conversations/:id/messages', validate({ params: idParam, body: askBody }), c.ask);
  r.post('/conversations/:id/retry', validate({ params: idParam }), c.retry);
  r.post('/actions/:id/approve', validate({ params: idParam }), c.approveAction);
  r.post('/actions/:id/cancel', validate({ params: idParam }), c.cancelAction);
  return r;
}
