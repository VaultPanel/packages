import { randomUUID } from 'node:crypto';
import {
  ACTION_EXPIRY_MINUTES,
  ASSISTANT_ACTIONS,
  ASSISTANT_HOURLY_LIMIT,
  ASSISTANT_PROVIDERS,
  PERMISSIONS,
} from '@vaultpanel/shared';
import { AppError, forbidden, notFound } from '../utils/errors.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';
import { userActor } from './actor.js';
import { createProvider } from './assistant/providers.js';
import { SYSTEM_PROMPT } from './assistant/prompt.js';
import { createToolRunner, toolLabel, TOOL_DEFINITIONS } from './assistant/tools.js';

const CONFIG_KEY = 'assistant.config';
const API_KEY_KEY = 'assistant.api_key';
// Rounds of tool use in one answer before the assistant must reply.
const MAX_ROUNDS = 12;
// How much history is sent with each question (whole turns are kept).
const MAX_HISTORY_ROWS = 80;
// A conversation still "thinking" after this long is marked failed.
export const STUCK_AFTER_MINUTES = 10;
const MAX_CONVERSATIONS_LISTED = 100;

// Phase 9: the AI assistant. Conversations, answering questions (in the
// worker, see jobs/queues.js), proposed actions and the provider settings.
export function createAssistantService({ db, config, logger, audit, authorize, accessControl, services, enqueue = async () => {} }) {
  const keyBox = createSecretBox(deriveKey(config.secretKey, 'assistant'));

  // ---- Settings -------------------------------------------------------------

  async function readSettings() {
    const rows = await db('settings').whereIn('key', [CONFIG_KEY, API_KEY_KEY]);
    const stored = fromJson(rows.find((r) => r.key === CONFIG_KEY)?.value, {});
    const sealedKey = rows.find((r) => r.key === API_KEY_KEY)?.value ?? null;
    let apiKey = null;
    if (sealedKey) {
      try {
        apiKey = keyBox.open(sealedKey);
      } catch (err) {
        logger.error({ err }, 'assistant: the stored API key cannot be decrypted (was VAULTPANEL_SECRET_KEY changed?)');
      }
    }
    const provider = ASSISTANT_PROVIDERS[stored.provider] ? stored.provider : null;
    return {
      enabled: Boolean(stored.enabled),
      provider,
      model: stored.model ?? (provider ? ASSISTANT_PROVIDERS[provider].defaultModel : null),
      baseUrl: stored.baseUrl ?? null,
      apiKey,
      updatedAt: stored.updatedAt ?? null,
    };
  }

  function missingSetting(s) {
    if (!s.provider) return 'Choose an AI provider';
    if (!s.model) return 'Enter a model name';
    if (ASSISTANT_PROVIDERS[s.provider].keyRequired && !s.apiKey) return 'Enter an API key';
    return null;
  }

  function publicSettings(s) {
    return {
      enabled: s.enabled,
      provider: s.provider,
      model: s.model,
      baseUrl: s.baseUrl,
      hasApiKey: Boolean(s.apiKey),
      apiKeyHint: s.apiKey ? `…${s.apiKey.slice(-4)}` : null,
      missing: missingSetting(s),
      updatedAt: s.updatedAt,
    };
  }

  async function getSettings(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    return publicSettings(await readSettings());
  }

  // apiKey: a string sets it, null removes it, undefined keeps it. Switching
  // provider drops the old key unless a new one comes with the change.
  async function updateSettings(actor, input) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const current = await readSettings();
    const provider = input.provider ?? current.provider;
    if (!provider) throw new AppError(422, 'VALIDATION_ERROR', 'Some fields are invalid', [{ field: 'provider', message: 'Choose a provider' }]);
    const providerChanged = provider !== current.provider;
    let apiKey = input.apiKey === undefined ? (providerChanged ? null : current.apiKey) : input.apiKey;
    if (typeof apiKey === 'string' && !apiKey.trim()) apiKey = null;
    const next = {
      enabled: input.enabled ?? current.enabled,
      provider,
      model: input.model ?? (providerChanged ? ASSISTANT_PROVIDERS[provider].defaultModel || null : current.model),
      baseUrl: input.baseUrl === undefined ? (providerChanged ? null : current.baseUrl) : input.baseUrl || null,
      apiKey,
    };
    const missing = missingSetting(next);
    if (next.enabled && missing) {
      throw new AppError(422, 'VALIDATION_ERROR', `${missing} before turning the assistant on`, [{ field: missing.includes('key') ? 'apiKey' : missing.includes('model') ? 'model' : 'provider', message: 'Required' }]);
    }
    const now = new Date();
    await db.transaction(async (trx) => {
      const value = toJson({ enabled: next.enabled, provider: next.provider, model: next.model, baseUrl: next.baseUrl, updatedAt: now.toISOString() });
      await trx('settings').insert({ key: CONFIG_KEY, value, is_secret: false, updated_by: actor.id, updated_at: now }).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
      if (next.apiKey) {
        await trx('settings').insert({ key: API_KEY_KEY, value: keyBox.seal(next.apiKey), is_secret: true, updated_by: actor.id, updated_at: now }).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
      } else {
        await trx('settings').where({ key: API_KEY_KEY }).delete();
      }
    });
    await audit.record({
      actor,
      action: 'assistant.settings_update',
      target: { type: 'settings', id: 'assistant', label: 'AI assistant' },
      metadata: {
        enabled: next.enabled,
        provider: next.provider,
        model: next.model,
        baseUrl: next.baseUrl,
        apiKey: input.apiKey === undefined ? (providerChanged && current.apiKey ? 'removed' : 'unchanged') : next.apiKey ? 'changed' : 'removed',
      },
    });
    return publicSettings(await readSettings());
  }

  // Sends a tiny request with the saved settings (or the ones being edited).
  async function testSettings(actor, input = {}) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const saved = await readSettings();
    const provider = input.provider ?? saved.provider;
    const s = {
      provider,
      model: input.model ?? saved.model,
      baseUrl: input.baseUrl === undefined ? saved.baseUrl : input.baseUrl || null,
      apiKey: input.apiKey || (provider === saved.provider ? saved.apiKey : null),
    };
    const missing = missingSetting(s);
    if (missing) throw new AppError(409, 'ASSISTANT_NOT_CONFIGURED', `${missing} first`);
    const started = Date.now();
    await createProvider(s, { logger }).ping();
    return { ok: true, provider: s.provider, model: s.model, latencyMs: Date.now() - started };
  }

  // What anyone who may use the assistant needs to know about it.
  async function status(actor) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const s = await readSettings();
    return {
      enabled: s.enabled && !missingSetting(s),
      provider: s.provider,
      providerLabel: s.provider ? ASSISTANT_PROVIDERS[s.provider].label : null,
      model: s.model,
      canConfigure: actor.permissions.includes(PERMISSIONS.SETTINGS_MANAGE),
      hourlyLimit: ASSISTANT_HOURLY_LIMIT,
    };
  }

  // ---- Conversations -----------------------------------------------------------

  async function ownConversation(actor, id) {
    const row = await db('assistant_conversations').where({ id }).first();
    // Conversations are private: someone else's is "not found", not "forbidden".
    if (!row || row.user_id !== actor.id) throw notFound('Conversation not found');
    return row;
  }

  async function listConversations(actor) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const rows = await db('assistant_conversations').where({ user_id: actor.id }).orderBy('updated_at', 'desc').limit(MAX_CONVERSATIONS_LISTED);
    return { items: rows.map(toPublicConversation) };
  }

  async function getConversation(actor, id) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const row = await ownConversation(actor, id);
    const [messages, actions] = await Promise.all([
      db('assistant_messages').where({ conversation_id: id }).orderBy('id').select('id', 'role', 'content', 'tool_calls', 'tool_results', 'created_at'),
      db('assistant_actions').where({ conversation_id: id }).orderBy('created_at'),
    ]);
    return { ...toPublicConversation(row), items: transcript(messages, actions.map(toPublicAction)) };
  }

  async function checkCanAsk(actor) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    // The assistant reads the server side of the panel; hosting customers do not get it yet.
    if (actor.customerId) throw forbidden();
    const s = await readSettings();
    if (!s.enabled || missingSetting(s)) {
      throw new AppError(409, 'ASSISTANT_NOT_CONFIGURED', 'The AI assistant is not set up yet. An owner or admin turns it on in its settings.');
    }
    const since = new Date(Date.now() - 3_600_000);
    const { n } = await db('assistant_messages as m')
      .join('assistant_conversations as c', 'c.id', 'm.conversation_id')
      .where({ 'c.user_id': actor.id, 'm.role': 'user' })
      .where('m.created_at', '>', since)
      .count({ n: '*' })
      .first();
    if (Number(n) >= ASSISTANT_HOURLY_LIMIT) {
      throw new AppError(429, 'ASSISTANT_LIMIT', `You asked ${ASSISTANT_HOURLY_LIMIT} questions in the last hour. Wait a little before asking more.`);
    }
  }

  async function startConversation(actor, { question }) {
    await checkCanAsk(actor);
    const id = randomUUID();
    await db('assistant_conversations').insert({ id, user_id: actor.id, title: titleFrom(question), status: 'idle' });
    await audit.record({ actor, action: 'assistant.conversation_start', target: { type: 'assistant_conversation', id, label: titleFrom(question) } });
    return ask(actor, id, { question }, { checked: true });
  }

  async function ask(actor, id, { question }, { checked = false } = {}) {
    if (!checked) await checkCanAsk(actor);
    const row = await ownConversation(actor, id);
    const now = new Date();
    // Only one question at a time per conversation.
    const claimed = await db('assistant_conversations')
      .where({ id })
      .whereNot('status', 'thinking')
      .update({ status: 'thinking', activity: 'Reading your question', thinking_since: now, error_code: null, error_message: null, updated_at: now });
    if (!claimed) throw new AppError(409, 'ASSISTANT_BUSY', 'The assistant is still answering the last question');
    const context = await contextNote(actor, row);
    const [messageId] = await db('assistant_messages').insert({
      conversation_id: id,
      role: 'user',
      content: question,
      provider_message: toJson({ context }),
    });
    await queue(id, messageId);
    return getConversation(actor, id);
  }

  // Asks again after a failed answer, from where it stopped.
  async function retry(actor, id) {
    await checkCanAsk(actor);
    const row = await ownConversation(actor, id);
    if (row.status !== 'failed') throw new AppError(409, 'NOTHING_TO_RETRY', 'The last answer did not fail');
    const last = await db('assistant_messages').where({ conversation_id: id }).orderBy('id', 'desc').first('id', 'role');
    if (!last || last.role === 'assistant') throw new AppError(409, 'NOTHING_TO_RETRY', 'Ask a new question instead');
    const now = new Date();
    const claimed = await db('assistant_conversations')
      .where({ id, status: 'failed' })
      .update({ status: 'thinking', activity: 'Trying again', thinking_since: now, error_code: null, error_message: null, updated_at: now });
    if (!claimed) throw new AppError(409, 'ASSISTANT_BUSY', 'The assistant is already answering');
    await queue(id, last.id);
    return getConversation(actor, id);
  }

  async function queue(conversationId, messageId) {
    try {
      await enqueue({ conversationId, messageId });
    } catch (err) {
      logger.error({ err, conversationId }, 'assistant: could not queue the question');
      await fail(conversationId, 'QUEUE_UNAVAILABLE', 'The panel could not hand the question to its worker. Check that Redis is running.');
      throw new AppError(503, 'QUEUE_UNAVAILABLE', 'The panel could not hand the question to its worker. Check that Redis is running.');
    }
  }

  async function removeConversation(actor, id) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const row = await ownConversation(actor, id);
    await db('assistant_conversations').where({ id }).delete();
    await audit.record({ actor, action: 'assistant.conversation_delete', target: { type: 'assistant_conversation', id, label: row.title } });
  }

  // What the model is told with each question: when, who is asking, and
  // what happened to the changes it proposed earlier in this conversation.
  async function contextNote(actor, conversation) {
    const lines = [`Time: ${new Date().toISOString()}`, `Asked by: ${actor.label} (role: ${actor.roles.join(', ') || 'none'})`];
    const actions = await db('assistant_actions').where({ conversation_id: conversation.id }).whereNot('status', 'proposed').orderBy('created_at');
    if (actions.length) {
      lines.push('Changes you proposed earlier in this conversation:');
      for (const a of actions) {
        const error = a.error_message ? ` (${a.error_message})` : '';
        lines.push(`- ${ASSISTANT_ACTIONS[a.kind]?.label ?? a.kind} on ${a.target_label}: ${a.status}${error}`);
      }
    }
    return lines.join('\n');
  }

  // ---- Answering (runs in the worker) ---------------------------------------------

  async function runTurn(conversationId) {
    const conversation = await db('assistant_conversations').where({ id: conversationId }).first();
    if (!conversation || conversation.status !== 'thinking') return { skipped: true };
    try {
      const settings = await readSettings();
      const missing = missingSetting(settings);
      if (!settings.enabled || missing) throw new AppError(409, 'ASSISTANT_NOT_CONFIGURED', 'The AI assistant was turned off or is not set up');
      const actor = await actorFor(conversation);
      const provider = createProvider(settings, { logger });
      const tools = createToolRunner({ services, db, actor, propose: (kind, params, reason) => propose(actor, conversation, kind, params, reason) });

      for (let round = 0; round < MAX_ROUNDS; round += 1) {
        if (!(await stillThinking(conversationId))) return { stopped: true };
        await setActivity(conversationId, round === 0 ? 'Thinking' : 'Thinking about what it found');
        const reply = await provider.complete({ system: SYSTEM_PROMPT, tools: TOOL_DEFINITIONS, messages: await history(conversationId) });
        const toolCalls = reply.toolCalls.map((c) => ({ ...c, label: toolLabel(c.name, c.input) }));
        const [assistantId] = await db('assistant_messages').insert({
          conversation_id: conversationId,
          role: 'assistant',
          content: reply.text || (toolCalls.length ? '' : '(The assistant gave no answer.)'),
          tool_calls: toolCalls.length ? toJson(toolCalls) : null,
          provider: settings.provider,
          model: settings.model,
          provider_message: reply.providerMessage ? toJson(reply.providerMessage) : null,
          input_tokens: reply.usage.inputTokens,
          output_tokens: reply.usage.outputTokens,
        });
        if (!toolCalls.length) {
          await finish(conversationId);
          return { rounds: round + 1 };
        }
        currentMessage.set(conversationId, assistantId);
        const results = [];
        for (const call of toolCalls) {
          await setActivity(conversationId, call.label);
          const result = await tools.run(call.name, call.input);
          results.push({ id: call.id, name: call.name, content: result.content, isError: result.isError });
        }
        await db('assistant_messages').insert({ conversation_id: conversationId, role: 'tool', tool_results: toJson(results) });
      }
      await db('assistant_messages').insert({
        conversation_id: conversationId,
        role: 'assistant',
        content: `I stopped after ${MAX_ROUNDS} rounds of checks without a final answer. Ask me to continue, or narrow the question.`,
      });
      await finish(conversationId);
      return { rounds: MAX_ROUNDS };
    } catch (err) {
      const known = err instanceof AppError;
      if (!known) logger.error({ err, conversationId }, 'assistant: answering failed');
      await fail(conversationId, known ? err.code : 'ASSISTANT_FAILED', known ? err.message : 'Something went wrong while answering. The details are in the worker log.');
      return { failed: true };
    } finally {
      currentMessage.delete(conversationId);
    }
  }

  // The assistant message a proposal belongs to (the one whose tool call made it).
  const currentMessage = new Map();

  // The conversation as the provider gets it. Old turns are dropped from the
  // front, a whole question at a time, once it grows long.
  async function history(conversationId) {
    let rows = await db('assistant_messages').where({ conversation_id: conversationId }).orderBy('id', 'desc').limit(MAX_HISTORY_ROWS);
    rows = rows.reverse();
    const firstUser = rows.findIndex((r) => r.role === 'user');
    if (firstUser > 0) rows = rows.slice(firstUser);
    return rows.map((r) => {
      if (r.role === 'user') return { role: 'user', text: r.content, context: fromJson(r.provider_message, {})?.context ?? null };
      if (r.role === 'tool') return { role: 'tool', results: fromJson(r.tool_results, []) };
      return {
        role: 'assistant',
        text: r.content ?? '',
        toolCalls: fromJson(r.tool_calls, []).map(({ id, name, input }) => ({ id, name, input })),
        provider: r.provider,
        model: r.model,
        providerMessage: fromJson(r.provider_message, null),
      };
    });
  }

  // The person the conversation belongs to, as they are now: a deactivated
  // account or a lost permission stops the answer.
  async function actorFor(conversation) {
    const user = await db('users').where({ id: conversation.user_id }).whereNull('deleted_at').first();
    if (!user?.is_active) throw new AppError(403, 'FORBIDDEN', 'This account is no longer active');
    const access = await accessControl.getUserAccess(user.id);
    if (!access.permissions.includes(PERMISSIONS.ASSISTANT_USE) || access.customer) throw new AppError(403, 'FORBIDDEN', 'This account may no longer use the assistant');
    const actor = userActor(user, access, { requestId: `assistant-${conversation.id.slice(0, 8)}` });
    return { ...actor, label: `${user.email} (assistant)`, via: 'assistant' };
  }

  async function stillThinking(id) {
    const row = await db('assistant_conversations').where({ id }).first('status');
    return row?.status === 'thinking';
  }

  async function setActivity(id, activity) {
    await db('assistant_conversations').where({ id, status: 'thinking' }).update({ activity: String(activity).slice(0, 200), updated_at: new Date() });
  }

  async function finish(id) {
    await db('assistant_conversations').where({ id }).update({ status: 'idle', activity: null, thinking_since: null, updated_at: new Date() });
  }

  async function fail(id, code, message) {
    await db('assistant_conversations')
      .where({ id })
      .update({ status: 'failed', activity: null, thinking_since: null, error_code: String(code).slice(0, 64), error_message: String(message).slice(0, 1000), updated_at: new Date() });
  }

  // Maintenance: answers that never finished (the worker stopped or is not running).
  async function failStuck(now = new Date()) {
    const cutoff = new Date(now.getTime() - STUCK_AFTER_MINUTES * 60_000);
    const stuck = await db('assistant_conversations').where({ status: 'thinking' }).where('thinking_since', '<', cutoff).select('id');
    for (const { id } of stuck) {
      await fail(id, 'ASSISTANT_TIMEOUT', `No answer after ${STUCK_AFTER_MINUTES} minutes. Check that the panel's worker is running (npm run dev:worker), then try again.`);
    }
    const expired = await db('assistant_actions')
      .where({ status: 'proposed' })
      .where('created_at', '<', new Date(now.getTime() - ACTION_EXPIRY_MINUTES * 60_000))
      .update({ status: 'expired', updated_at: now });
    return { stuck: stuck.length, expired };
  }

  // ---- Proposed actions ------------------------------------------------------------

  // Resolves what an action acts on, as the person (so they must be able to
  // see it), and returns the label shown on the card.
  async function describeTarget(actor, kind, params) {
    const def = ASSISTANT_ACTIONS[kind];
    if (def.target === 'application') {
      const app = await services.applications.get(actor, params.applicationId);
      if (params.deploymentId) {
        const deployment = await services.applications.getDeployment(actor, params.deploymentId);
        if (deployment.applicationId !== app.id) throw new AppError(422, 'INVALID_ACTION_PARAMS', 'That deployment belongs to another app');
        const commit = deployment.commit?.hash ? ` (commit ${deployment.commit.hash.slice(0, 7)})` : '';
        return { id: app.id, label: `${app.name} to the deployment of ${deployment.createdAt?.slice(0, 16).replace('T', ' ')}${commit}` };
      }
      return { id: app.id, label: `${app.name} on ${app.serverName ?? 'its server'}` };
    }
    if (def.target === 'website') {
      const site = await services.websites.get(actor, params.websiteId);
      return { id: site.id, label: `${site.primaryDomain ?? site.name} on ${site.serverName ?? 'its server'}` };
    }
    const server = await services.servers.get(actor, params.serverId);
    if (params.service) return { id: server.id, label: `${params.service} on ${server.name}` };
    if (params.components) return { id: server.id, label: `${params.components.join(', ')} on ${server.name}` };
    return { id: server.id, label: server.name };
  }

  async function propose(actor, conversation, kind, params, reason) {
    const target = await describeTarget(actor, kind, params);
    const id = randomUUID();
    await db('assistant_actions').insert({
      id,
      conversation_id: conversation.id,
      message_id: currentMessage.get(conversation.id) ?? (await lastAssistantMessageId(conversation.id)),
      kind,
      params: toJson(params),
      target_type: ASSISTANT_ACTIONS[kind].target,
      target_id: target.id,
      target_label: target.label.slice(0, 200),
      reason: reason.slice(0, 1000),
    });
    await audit.record({ actor, action: 'assistant.action_propose', target: { type: ASSISTANT_ACTIONS[kind].target, id: target.id, label: target.label }, metadata: { actionId: id, kind, params } });
    return { id, targetLabel: target.label };
  }

  async function lastAssistantMessageId(conversationId) {
    const row = await db('assistant_messages').where({ conversation_id: conversationId, role: 'assistant' }).orderBy('id', 'desc').first('id');
    return row?.id ?? null;
  }

  async function ownAction(actor, id) {
    const action = await db('assistant_actions as a')
      .join('assistant_conversations as c', 'c.id', 'a.conversation_id')
      .where('a.id', id)
      .first('a.*', 'c.user_id');
    if (!action || action.user_id !== actor.id) throw notFound('Proposed change not found');
    return action;
  }

  // Runs a proposal the person approved, as them, through the same service
  // call as the matching button, so every usual check applies.
  async function approveAction(actor, id) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const action = await ownAction(actor, id);
    if (action.status !== 'proposed') throw new AppError(409, 'ACTION_NOT_PENDING', `This change is already ${action.status}`);
    const now = new Date();
    if (new Date(action.created_at) < new Date(now.getTime() - ACTION_EXPIRY_MINUTES * 60_000)) {
      await db('assistant_actions').where({ id, status: 'proposed' }).update({ status: 'expired', updated_at: now });
      throw new AppError(409, 'ACTION_EXPIRED', `This proposal is more than ${ACTION_EXPIRY_MINUTES} minutes old. Ask the assistant to check again.`);
    }
    const claimed = await db('assistant_actions').where({ id, status: 'proposed' }).update({ status: 'running', decided_by: actor.id, decided_at: now, updated_at: now });
    if (!claimed) throw new AppError(409, 'ACTION_NOT_PENDING', 'This change was already decided');
    const params = fromJson(action.params, {});
    const target = { type: action.target_type, id: action.target_id, label: action.target_label };
    try {
      const result = await executeAction(actor, action.kind, params);
      const job = result?.job ?? result;
      await db('assistant_actions').where({ id }).update({ job_id: job?.id ?? null, updated_at: new Date() });
      await audit.record({ actor, action: 'assistant.action_approve', target, metadata: { actionId: id, kind: action.kind, jobId: job?.id } });
    } catch (err) {
      const code = err.code ?? 'ACTION_FAILED';
      const message = err.status === 403 ? 'You do not have permission to do this' : (err.message ?? 'The change could not start');
      await db('assistant_actions').where({ id }).update({ status: 'failed', error_code: String(code).slice(0, 64), error_message: String(message).slice(0, 1000), updated_at: new Date() });
      await audit.record({ actor, action: 'assistant.action_approve', target, result: 'failure', metadata: { actionId: id, kind: action.kind, error: { code, message } } });
    }
    return toPublicAction(await db('assistant_actions').where({ id }).first());
  }

  async function cancelAction(actor, id) {
    await authorize(actor, PERMISSIONS.ASSISTANT_USE);
    const action = await ownAction(actor, id);
    const updated = await db('assistant_actions').where({ id, status: 'proposed' }).update({ status: 'cancelled', decided_by: actor.id, decided_at: new Date(), updated_at: new Date() });
    if (!updated) throw new AppError(409, 'ACTION_NOT_PENDING', `This change is already ${action.status}`);
    await audit.record({ actor, action: 'assistant.action_cancel', target: { type: action.target_type, id: action.target_id, label: action.target_label }, metadata: { actionId: id, kind: action.kind } });
    return toPublicAction(await db('assistant_actions').where({ id }).first());
  }

  function executeAction(actor, kind, p) {
    const { applications, websites, jobs } = services;
    switch (kind) {
      case 'application.restart': return applications.control(actor, p.applicationId, 'restart');
      case 'application.start': return applications.control(actor, p.applicationId, 'start');
      case 'application.stop': return applications.control(actor, p.applicationId, 'stop');
      case 'application.deploy': return applications.deploy(actor, p.applicationId, { trigger: 'manual' });
      case 'application.rollback': return applications.rollback(actor, p.applicationId, { deploymentId: p.deploymentId });
      case 'application.apply': return applications.apply(actor, p.applicationId);
      case 'service.restart': return jobs.create(actor, { serverId: p.serverId, type: 'SERVICE_RESTART', params: { service: p.service } });
      case 'service.start': return jobs.create(actor, { serverId: p.serverId, type: 'SERVICE_START', params: { service: p.service } });
      case 'website.enable': return websites.setEnabled(actor, p.websiteId, true);
      case 'website.retry': return websites.retry(actor, p.websiteId);
      case 'website.renew_ssl': return websites.renewSsl(actor, p.websiteId, { force: false });
      case 'server.install_software': return jobs.create(actor, { serverId: p.serverId, type: 'WEB_STACK_INSTALL', params: { components: p.components } });
      default: throw new AppError(400, 'UNKNOWN_ACTION', `Unknown action ${kind}`);
    }
  }

  // Follows the job an approved change started.
  async function onJobFinished(job, { status, error }) {
    const action = await db('assistant_actions').where({ job_id: job.id, status: 'running' }).first('id');
    if (!action) return;
    await db('assistant_actions')
      .where({ id: action.id, status: 'running' })
      .update({
        status: status === 'succeeded' ? 'succeeded' : 'failed',
        error_code: status === 'succeeded' ? null : String(error?.code ?? status).slice(0, 64),
        error_message: status === 'succeeded' ? null : String(error?.message ?? `The job ended as ${status}`).slice(0, 1000),
        updated_at: new Date(),
      });
  }

  return {
    getSettings,
    updateSettings,
    testSettings,
    status,
    listConversations,
    getConversation,
    startConversation,
    ask,
    retry,
    removeConversation,
    runTurn,
    failStuck,
    approveAction,
    cancelAction,
    onJobFinished,
  };
}

function titleFrom(question) {
  const line = question.trim().split('\n')[0].replace(/\s+/g, ' ');
  return line.length > 80 ? `${line.slice(0, 77)}…` : line;
}

function toPublicConversation(row) {
  return {
    id: row.id,
    title: row.title,
    status: row.status,
    activity: row.activity,
    error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function toPublicAction(row) {
  const def = ASSISTANT_ACTIONS[row.kind];
  return {
    id: row.id,
    kind: row.kind,
    label: def?.label ?? row.kind,
    permission: def?.permission ?? null,
    dangerous: Boolean(def?.dangerous),
    params: fromJson(row.params, {}),
    target: { type: row.target_type, id: row.target_id, label: row.target_label },
    reason: row.reason,
    status: row.status,
    jobId: row.job_id,
    error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
    decidedAt: toIso(row.decided_at),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
    messageId: row.message_id === null || row.message_id === undefined ? null : Number(row.message_id),
  };
}

// What the person sees: their questions, and for each one the assistant's
// answer with the checks it made and the changes it proposed.
function transcript(messages, actions) {
  const items = [];
  let turn = null;
  const results = new Map();
  for (const m of messages) {
    if (m.role === 'tool') for (const r of fromJson(m.tool_results, [])) results.set(r.id, r);
  }
  for (const m of messages) {
    if (m.role === 'user') {
      turn = null;
      items.push({ id: Number(m.id), role: 'user', text: m.content, createdAt: toIso(m.created_at) });
      continue;
    }
    if (m.role !== 'assistant') continue;
    if (!turn) {
      turn = { id: Number(m.id), role: 'assistant', text: '', steps: [], actions: [], createdAt: toIso(m.created_at), messageIds: [] };
      items.push(turn);
    }
    turn.messageIds.push(Number(m.id));
    if (m.content) turn.text = turn.text ? `${turn.text}\n\n${m.content}` : m.content;
    for (const call of fromJson(m.tool_calls, [])) {
      if (call.name === 'propose_action') continue;
      const result = results.get(call.id);
      turn.steps.push({ label: call.label ?? call.name, failed: Boolean(result?.isError), pending: !result });
    }
  }
  for (const action of actions) {
    const owner = items.find((i) => i.role === 'assistant' && i.messageIds.includes(action.messageId)) ?? items.filter((i) => i.role === 'assistant').at(-1);
    if (owner) owner.actions.push(action);
  }
  for (const item of items) delete item.messageIds;
  return items;
}
