import Anthropic from '@anthropic-ai/sdk';
import { ASSISTANT_PROVIDERS } from '@vaultpanel/shared';
import { AppError } from '../../utils/errors.js';

// Talks to the AI provider the owner chose. Both adapters take the same
// provider-neutral conversation and return the same shape:
//
//   messages: [{ role: 'user', text, context },
//              { role: 'assistant', text, toolCalls: [{ id, name, input }], provider, model, providerMessage },
//              { role: 'tool', results: [{ id, name, content, isError }] }]
//   complete() -> { text, toolCalls, providerMessage, stopReason, usage }
//
// Claude's replies are replayed exactly as the API returned them (thinking
// blocks included) whenever the conversation stays on the same model, and the
// history is only ever appended to, so earlier reasoning stays valid.

const REQUEST_TIMEOUT_MS = 120_000;
const MAX_OUTPUT_TOKENS = 16_000;

export function createProvider(settings, { logger } = {}) {
  if (settings.provider === 'anthropic') return anthropicProvider(settings, { logger });
  if (settings.provider === 'openai') return openAiProvider(settings);
  throw new AppError(409, 'ASSISTANT_NOT_CONFIGURED', 'Choose an AI provider in the assistant settings first');
}

// The text of a user message as the model sees it: the panel's context note
// (time, who is asking, what changed) and then the question.
function userText(message) {
  return message.context ? `<panel-context>\n${message.context}\n</panel-context>\n\n${message.text}` : message.text;
}

// ---- Claude (Anthropic) -------------------------------------------------------

// Current Claude models think adaptively; older ones (Haiku 4.5) take no thinking setting.
const ADAPTIVE_MODEL = /^claude-(opus|sonnet|fable|mythos)-(5|4-[6-9])/;
// Models that take the server-side refusal fallback on the Claude API.
const FALLBACK_MODEL = /^claude-(opus-5|fable-5|sonnet-5-5)/;
const THINKING_BINDING_BETA = 'thinking-binding-controls-2026-08-01';
const FALLBACK_BETA = 'server-side-fallback-2026-07-01';

function anthropicProvider({ model, apiKey, baseUrl }, { logger } = {}) {
  const defaultBaseUrl = ASSISTANT_PROVIDERS.anthropic.defaultBaseUrl;
  const client = new Anthropic({ apiKey: apiKey ?? '', baseURL: baseUrl || defaultBaseUrl, timeout: REQUEST_TIMEOUT_MS, maxRetries: 2 });
  const adaptive = ADAPTIVE_MODEL.test(model);
  const fallback = FALLBACK_MODEL.test(model) && (!baseUrl || baseUrl === defaultBaseUrl);

  function toApiMessages(messages) {
    const out = [];
    const push = (role, content) => {
      const last = out.at(-1);
      // Consecutive user turns (tool results, then a new question) are sent as one.
      if (last?.role === role && role === 'user') {
        last.content = [...asBlocks(last.content), ...asBlocks(content)];
      } else {
        out.push({ role, content });
      }
    };
    for (const m of messages) {
      if (m.role === 'user') push('user', [{ type: 'text', text: userText(m) }]);
      else if (m.role === 'tool') {
        push('user', m.results.map((r) => ({ type: 'tool_result', tool_use_id: r.id, content: r.content, ...(r.isError ? { is_error: true } : {}) })));
      } else if (m.provider === 'anthropic' && m.model === model && m.providerMessage?.content) {
        push('assistant', m.providerMessage.content);
      } else {
        const content = [];
        if (m.text) content.push({ type: 'text', text: m.text });
        for (const call of m.toolCalls ?? []) content.push({ type: 'tool_use', id: call.id, name: call.name, input: call.input ?? {} });
        if (content.length) push('assistant', content);
      }
    }
    return out;
  }

  async function send(body, { extras }) {
    const betas = [];
    const request = { model, max_tokens: body.maxTokens ?? MAX_OUTPUT_TOKENS, system: body.system, messages: body.messages };
    if (body.tools?.length) request.tools = body.tools;
    if (extras && adaptive) {
      request.thinking = { type: 'adaptive', block_binding: { prefix_mismatch_behavior: 'drop_block' } };
      betas.push(THINKING_BINDING_BETA);
    }
    if (extras && fallback) {
      request.fallbacks = 'default';
      betas.push(FALLBACK_BETA);
    }
    return betas.length ? client.beta.messages.create({ ...request, betas }) : client.messages.create(request);
  }

  // The thinking and fallback options are newer API features. If a gateway or
  // model rejects them, the request is retried once without them.
  async function call(body) {
    try {
      return await send(body, { extras: true });
    } catch (err) {
      if (err instanceof Anthropic.BadRequestError && (adaptive || fallback)) {
        logger?.warn({ err: err.message }, 'assistant: Claude rejected the request options; retrying without them');
        return send(body, { extras: false });
      }
      throw err;
    }
  }

  return {
    async complete({ system, tools, messages }) {
      let response;
      try {
        response = await call({
          system,
          messages: toApiMessages(messages),
          tools: tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.inputSchema })),
        });
      } catch (err) {
        throw anthropicError(err);
      }
      if (response.stop_reason === 'refusal') {
        throw new AppError(502, 'PROVIDER_REFUSED', 'Claude declined to answer this. Try asking in a different way.');
      }
      const text = response.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n\n').trim();
      const toolCalls = response.content.filter((b) => b.type === 'tool_use').map((b) => ({ id: b.id, name: b.name, input: b.input ?? {} }));
      return {
        text,
        toolCalls,
        stopReason: response.stop_reason,
        providerMessage: { role: 'assistant', content: response.content },
        usage: { inputTokens: response.usage?.input_tokens ?? null, outputTokens: response.usage?.output_tokens ?? null },
      };
    },
    async ping() {
      try {
        await client.messages.create({ model, max_tokens: 1024, messages: [{ role: 'user', content: 'Reply with the single word OK.' }] });
      } catch (err) {
        throw anthropicError(err);
      }
    },
  };
}

function asBlocks(content) {
  return typeof content === 'string' ? [{ type: 'text', text: content }] : content;
}

function anthropicError(err) {
  if (err instanceof AppError) return err;
  if (err instanceof Anthropic.AuthenticationError || err instanceof Anthropic.PermissionDeniedError) {
    return new AppError(502, 'PROVIDER_AUTH_FAILED', 'Claude refused the API key. Check the key in the assistant settings.');
  }
  if (err instanceof Anthropic.NotFoundError) {
    return new AppError(502, 'PROVIDER_MODEL_NOT_FOUND', `Claude does not know this model: ${apiMessage(err)}`);
  }
  if (err instanceof Anthropic.RateLimitError) {
    return new AppError(502, 'PROVIDER_RATE_LIMITED', 'Claude is rate limiting this API key. Wait a minute and try again.');
  }
  if (err instanceof Anthropic.APIConnectionError) {
    return new AppError(502, 'PROVIDER_UNREACHABLE', 'Could not reach the Anthropic API from this server. Check its internet connection.');
  }
  if (err instanceof Anthropic.APIError) {
    return new AppError(502, 'PROVIDER_ERROR', `Claude returned an error (${err.status ?? 'unknown'}): ${apiMessage(err)}`);
  }
  return new AppError(502, 'PROVIDER_ERROR', `The request to Claude failed: ${err.message}`);
}

function apiMessage(err) {
  return String(err.error?.error?.message ?? err.message ?? 'unknown error').slice(0, 500);
}

// ---- OpenAI-compatible ---------------------------------------------------------

function openAiProvider({ model, apiKey, baseUrl }) {
  const root = (baseUrl || ASSISTANT_PROVIDERS.openai.defaultBaseUrl).replace(/\/+$/, '');

  function toApiMessages(system, messages) {
    const out = [{ role: 'system', content: system }];
    for (const m of messages) {
      if (m.role === 'user') out.push({ role: 'user', content: userText(m) });
      else if (m.role === 'tool') {
        for (const r of m.results) out.push({ role: 'tool', tool_call_id: r.id, content: r.content });
      } else {
        const message = { role: 'assistant', content: m.text || null };
        if (m.toolCalls?.length) {
          message.tool_calls = m.toolCalls.map((c) => ({ id: c.id, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.input ?? {}) } }));
        }
        out.push(message);
      }
    }
    return out;
  }

  async function post(body) {
    let res;
    try {
      res = await fetch(`${root}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}) },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (err) {
      throw new AppError(502, 'PROVIDER_UNREACHABLE', `Could not reach ${root}: ${err.cause?.message ?? err.message}`);
    }
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const message = String(data?.error?.message ?? data?.message ?? res.statusText).slice(0, 500);
      if (res.status === 401 || res.status === 403) throw new AppError(502, 'PROVIDER_AUTH_FAILED', `The AI service refused the API key: ${message}`);
      if (res.status === 404) throw new AppError(502, 'PROVIDER_MODEL_NOT_FOUND', `The AI service does not know this model or address: ${message}`);
      if (res.status === 429) throw new AppError(502, 'PROVIDER_RATE_LIMITED', 'The AI service is rate limiting this key. Wait a minute and try again.');
      throw new AppError(502, 'PROVIDER_ERROR', `The AI service returned an error (${res.status}): ${message}`);
    }
    if (!data?.choices?.[0]?.message) throw new AppError(502, 'PROVIDER_ERROR', 'The AI service returned an answer in an unexpected format');
    return data;
  }

  return {
    async complete({ system, tools, messages }) {
      const data = await post({
        model,
        messages: toApiMessages(system, messages),
        tools: tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.inputSchema } })),
        tool_choice: 'auto',
      });
      const choice = data.choices[0];
      const toolCalls = (choice.message.tool_calls ?? []).map((c, i) => {
        let input;
        try {
          input = JSON.parse(c.function?.arguments || '{}');
        } catch {
          input = { invalidArguments: String(c.function?.arguments ?? '').slice(0, 500) };
        }
        return { id: c.id || `call_${i}`, name: c.function?.name ?? '', input };
      });
      return {
        text: String(choice.message.content ?? '').trim(),
        toolCalls,
        stopReason: choice.finish_reason ?? null,
        providerMessage: null,
        usage: { inputTokens: data.usage?.prompt_tokens ?? null, outputTokens: data.usage?.completion_tokens ?? null },
      };
    },
    async ping() {
      await post({ model, messages: [{ role: 'user', content: 'Reply with the single word OK.' }], max_tokens: 16 });
    },
  };
}
