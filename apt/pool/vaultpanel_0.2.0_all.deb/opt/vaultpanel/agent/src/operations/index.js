import { readFile } from 'node:fs/promises';
import {
  isServiceAllowed,
  isServiceStoppable,
  normalizeServiceName,
  PROTECTED_PROCESSES,
  SERVICE_NAME_PATTERN,
} from '../security/policy.js';
import { readServiceStates } from '../monitoring/services.js';
import { runCommand } from '../utils/exec.js';
import { onlyKeys, OperationError } from './errors.js';
import { AGENT_UPDATE_OPERATIONS } from './agentUpdate.js';
import { APP_OPERATIONS } from './apps.js';
import { BACKUP_OPERATIONS } from './backups.js';
import { CMS_OPERATIONS } from './cms.js';
import { CONTAINER_OPERATIONS } from './containers.js';
import { CRON_OPERATIONS } from './cron.js';
import { DATABASE_BROWSER_OPERATIONS } from './databaseBrowser.js';
import { DATABASE_OPERATIONS } from './databases.js';
import { DNS_OPERATIONS } from './dns.js';
import { MAIL_OPERATIONS } from './mail.js';
import { PHPMYADMIN_OPERATIONS } from './phpmyadmin.js';
import { PHP_VERSION_OPERATIONS } from './phpVersions.js';
import { FILE_OPERATIONS } from './files.js';
import { LOG_OPERATIONS } from './logs.js';
import { NETWORK_OPERATIONS } from './network.js';
import { SECURITY_OPERATIONS } from './security.js';
import { SELF_CHECK_OPERATIONS } from './selfCheck.js';
import { SITE_OPERATIONS } from './sites.js';
import { SITE_GIT_OPERATIONS } from './siteGit.js';
import { SSL_OPERATIONS } from './ssl.js';
import { WEB_STACK_OPERATIONS } from './webStack.js';

export { OperationError };

// The complete list of operations this agent will perform. Anything else is
// refused, whatever the panel sends. Each operation validates its own
// parameters again, independently of the panel.
//
// run(params, ctx) returns { output } or throws an OperationError.
// It may also return after(): work to do once the result has been reported
// (used by reboot, which would otherwise kill the agent before it reports).

function requireService(params, policy) {
  const service = params?.service;
  if (typeof service !== 'string' || !SERVICE_NAME_PATTERN.test(service)) {
    throw new OperationError('INVALID_PARAMS', 'service must be a valid systemd service name');
  }
  if (!isServiceAllowed(service, policy.allowedServices)) {
    throw new OperationError('NOT_ALLOWED', `This agent is not allowed to manage "${service}" (see allowedServices in the agent config)`);
  }
  return normalizeServiceName(service);
}

async function serviceState(name, ctx) {
  const [state] = await readServiceStates([name], { run: ctx.run });
  if (!state) throw new OperationError('SERVICE_NOT_FOUND', `Service "${name}" does not exist on this server`);
  return state;
}

export const OPERATIONS = {
  SERVICE_STATUS: {
    async run(params, ctx) {
      onlyKeys(params, ['service']);
      const name = requireService(params, ctx.policy);
      return { output: { service: await serviceState(name, ctx) } };
    },
  },

  SERVICE_START: {
    async run(params, ctx) {
      onlyKeys(params, ['service']);
      const name = requireService(params, ctx.policy);
      return { output: { service: await systemctlAction('start', name, ['active'], ctx) } };
    },
  },

  SERVICE_STOP: {
    async run(params, ctx) {
      onlyKeys(params, ['service']);
      const name = requireService(params, ctx.policy);
      if (!isServiceStoppable(name)) {
        throw new OperationError('NOT_ALLOWED', `Stopping ${name} would cut off remote access, so the agent refuses it (restart is allowed)`);
      }
      return { output: { service: await systemctlAction('stop', name, ['inactive', 'failed'], ctx) } };
    },
  },

  SERVICE_RESTART: {
    async run(params, ctx) {
      onlyKeys(params, ['service']);
      const name = requireService(params, ctx.policy);
      return { output: { service: await systemctlAction('restart', name, ['active'], ctx) } };
    },
  },

  SERVICE_LOGS: {
    async run(params, ctx) {
      onlyKeys(params, ['service', 'lines']);
      const name = requireService(params, ctx.policy);
      const lines = params.lines ?? 200;
      if (!Number.isInteger(lines) || lines < 10 || lines > 1000) {
        throw new OperationError('INVALID_PARAMS', 'lines must be an integer from 10 to 1000');
      }
      await serviceState(name, ctx);
      const result = await ctx.run(
        'journalctl',
        [`--unit=${name}.service`, `--lines=${lines}`, '--no-pager', '--output=short-iso', '--quiet'],
        { timeoutMs: 20_000 },
      );
      if (result.timedOut) throw new OperationError('TIMEOUT', 'journalctl did not finish in time');
      if (result.error || result.exitCode !== 0) {
        throw new OperationError('COMMAND_FAILED', result.error?.message ?? (result.stderr.trim() || 'journalctl failed'));
      }
      const entries = result.stdout
        .split('\n')
        .filter((line) => line.length)
        .slice(-lines)
        .map((line) => line.slice(0, 2000));
      return { output: { service: name, lines: entries } };
    },
  },

  PROCESS_LIST: {
    async run(params, ctx) {
      onlyKeys(params, ['limit', 'sortBy']);
      const limit = params.limit ?? 50;
      if (!Number.isInteger(limit) || limit < 1 || limit > 500) {
        throw new OperationError('INVALID_PARAMS', 'limit must be an integer from 1 to 500');
      }
      const sortBy = params.sortBy ?? 'cpu';
      if (!['cpu', 'memory'].includes(sortBy)) throw new OperationError('INVALID_PARAMS', 'sortBy must be cpu or memory');
      const result = await ctx.run(
        'ps',
        ['-eo', 'pid=,user=,pcpu=,pmem=,rss=,etimes=,comm=', `--sort=${sortBy === 'cpu' ? '-pcpu' : '-pmem'}`],
        { timeoutMs: 15_000 },
      );
      if (result.error || result.exitCode !== 0) {
        throw new OperationError('COMMAND_FAILED', result.error?.message ?? result.stderr.trim());
      }
      const processes = parsePs(result.stdout);
      return { output: { total: processes.length, sortBy, processes: processes.slice(0, limit) } };
    },
  },

  PROCESS_SIGNAL: {
    async run(params, ctx) {
      onlyKeys(params, ['pid', 'command', 'signal']);
      if (!ctx.policy.allowProcessSignals) {
        throw new OperationError('NOT_ALLOWED', 'Stopping processes is disabled in this agent config');
      }
      const { pid, command } = params;
      const signal = params.signal ?? 'TERM';
      if (!Number.isInteger(pid) || pid < 2 || pid > 4_194_304) {
        throw new OperationError('INVALID_PARAMS', 'pid must be a process ID');
      }
      if (typeof command !== 'string' || !command.length || command.length > 64) {
        throw new OperationError('INVALID_PARAMS', 'command must be the process name');
      }
      if (!['TERM', 'KILL'].includes(signal)) throw new OperationError('INVALID_PARAMS', 'signal must be TERM or KILL');

      const proc = ctx.proc ?? procFs;
      if (pid === process.pid || pid === process.ppid) {
        throw new OperationError('NOT_ALLOWED', 'The agent will not stop itself');
      }
      const info = await proc.read(pid);
      if (!info) throw new OperationError('PROCESS_NOT_FOUND', `No process with PID ${pid} is running`);
      if (info.comm !== command) {
        throw new OperationError(
          'PROCESS_CHANGED',
          `PID ${pid} now belongs to "${info.comm}", not "${command}". Refresh the process list and try again.`,
        );
      }
      // Kernel threads are children of kthreadd (PID 2).
      if (info.ppid === 2 || info.ppid === 0) {
        throw new OperationError('NOT_ALLOWED', `${info.comm} is a kernel thread`);
      }
      if (PROTECTED_PROCESSES.has(info.comm)) {
        throw new OperationError('NOT_ALLOWED', `${info.comm} is essential to the server, so the agent refuses to stop it`);
      }

      ctx.log('stdout', `Sending SIG${signal} to ${info.comm} (PID ${pid})`);
      try {
        proc.kill(pid, `SIG${signal}`);
      } catch (err) {
        if (err.code === 'ESRCH') throw new OperationError('PROCESS_NOT_FOUND', `PID ${pid} exited before the signal was sent`);
        throw new OperationError('COMMAND_FAILED', err.message);
      }
      const exited = await waitForExit(pid, info.comm, proc, ctx.waitMs ?? 5000);
      ctx.log('stdout', exited ? 'Process exited' : 'Process is still running. It may be shutting down slowly; send KILL to force it.');
      return { output: { pid, command: info.comm, signal, exited } };
    },
  },

  SERVER_REBOOT: {
    async run(params, ctx) {
      onlyKeys(params, []);
      if (!ctx.policy.allowReboot) throw new OperationError('NOT_ALLOWED', 'Reboots are disabled in this agent config');
      ctx.log('stdout', 'Reboot will start a few seconds after this result is reported');
      return {
        output: { rebootScheduled: true },
        after: () => ctx.run('systemctl', ['reboot'], { timeoutMs: 30_000 }),
      };
    },
  },

  ...WEB_STACK_OPERATIONS,
  ...PHP_VERSION_OPERATIONS,
  ...SITE_OPERATIONS,
  ...SITE_GIT_OPERATIONS,
  ...SSL_OPERATIONS,
  ...FILE_OPERATIONS,
  ...APP_OPERATIONS,
  ...DATABASE_OPERATIONS,
  ...DATABASE_BROWSER_OPERATIONS,
  ...PHPMYADMIN_OPERATIONS,
  ...CMS_OPERATIONS,
  ...DNS_OPERATIONS,
  ...MAIL_OPERATIONS,
  ...BACKUP_OPERATIONS,
  ...CRON_OPERATIONS,
  ...LOG_OPERATIONS,
  ...NETWORK_OPERATIONS,
  ...SECURITY_OPERATIONS,
  ...SELF_CHECK_OPERATIONS,
  ...CONTAINER_OPERATIONS,
  ...AGENT_UPDATE_OPERATIONS,
};

export const SUPPORTED_OPERATIONS = Object.keys(OPERATIONS);

// Runs `systemctl <verb>` and checks the unit ends up in one of the expected states.
async function systemctlAction(verb, name, expectedStates, ctx) {
  await serviceState(name, ctx);
  ctx.log('stdout', `$ systemctl ${verb} ${name}.service`);
  const result = await ctx.run('systemctl', [verb, `${name}.service`], { timeoutMs: ctx.timeoutMs, onLine: ctx.log });
  if (result.timedOut) throw new OperationError('TIMEOUT', `systemctl ${verb} did not finish in time`);
  if (result.error) throw new OperationError('COMMAND_FAILED', result.error.message);
  const state = await serviceState(name, ctx);
  if (result.exitCode !== 0 || !expectedStates.includes(state.active)) {
    throw new OperationError(
      `${verb.toUpperCase()}_FAILED`,
      `Service ${name} is ${state.active}${state.sub ? ` (${state.sub})` : ''} after ${verb}${result.stderr ? `: ${result.stderr.trim().slice(0, 500)}` : ''}`,
    );
  }
  return state;
}

// Reads a process's name and parent from /proc. Returns null if it is gone.
export const procFs = {
  async read(pid) {
    try {
      return parseProcStat(await readFile(`/proc/${pid}/stat`, 'utf8'));
    } catch {
      return null;
    }
  },
  kill: (pid, signal) => process.kill(pid, signal),
};

// /proc/<pid>/stat is "pid (comm) state ppid ...". comm may itself contain
// spaces and parentheses, so split at the last ")".
export function parseProcStat(text) {
  const open = text.indexOf('(');
  const close = text.lastIndexOf(')');
  if (open < 0 || close < open) return null;
  const rest = text.slice(close + 2).split(' ');
  return { pid: Number(text.slice(0, open).trim()), comm: text.slice(open + 1, close), state: rest[0], ppid: Number(rest[1]) };
}

async function waitForExit(pid, comm, proc, waitMs) {
  const deadline = Date.now() + waitMs;
  for (;;) {
    const info = await proc.read(pid);
    // Gone, a zombie waiting for its parent, or the PID was reused.
    if (!info || info.state === 'Z' || info.comm !== comm) return true;
    if (Date.now() >= deadline) return false;
    await new Promise((r) => setTimeout(r, 250));
  }
}

export function parsePs(text) {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [pid, user, cpu, mem, rss, etimes, ...command] = line.split(/\s+/);
      return {
        pid: Number(pid),
        user,
        cpuPercent: Number(cpu),
        memoryPercent: Number(mem),
        rssBytes: Number(rss) * 1024,
        elapsedSeconds: Number(etimes),
        command: command.join(' '),
      };
    });
}

export async function executeOperation(type, params, ctx) {
  const op = OPERATIONS[type];
  if (!op) throw new OperationError('UNSUPPORTED_OPERATION', `This agent does not support ${type}`);
  return op.run(params ?? {}, { run: runCommand, ...ctx });
}
