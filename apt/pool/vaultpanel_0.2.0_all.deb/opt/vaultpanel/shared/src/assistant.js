// The AI assistant (phase 9). It reads what the signed-in person may see
// through the panel's own services, and proposes changes as actions from the
// catalog below. A proposal does nothing until the person approves it; the
// panel then runs it through the same service (and permission check) the
// matching button uses.

import { PERMISSIONS } from './permissions.js';
import { SERVICE_NAME_PATTERN } from './operations.js';
import { WEB_STACK_COMPONENT_KEYS } from './websites.js';

export const ASSISTANT_PROVIDERS = Object.freeze({
  anthropic: {
    label: 'Claude (Anthropic)',
    description: 'Claude models through the Anthropic API. Needs an API key from console.anthropic.com.',
    defaultModel: 'claude-opus-5-5',
    models: [
      { id: 'claude-opus-5-5', label: 'Claude Opus 5.5 (recommended)' },
      { id: 'claude-sonnet-5-5', label: 'Claude Sonnet 5.5 (faster, lower cost)' },
      { id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5 (fastest, lowest cost)' },
    ],
    defaultBaseUrl: 'https://api.anthropic.com',
    keyRequired: true,
  },
  openai: {
    label: 'OpenAI-compatible',
    description: 'OpenAI, or any service with an OpenAI-compatible chat API (for example Ollama or vLLM on your own server). The model must support tool calling.',
    defaultModel: '',
    models: [],
    defaultBaseUrl: 'https://api.openai.com/v1',
    keyRequired: false,
  },
});
export const ASSISTANT_PROVIDER_KEYS = Object.freeze(Object.keys(ASSISTANT_PROVIDERS));

export const ASSISTANT_MODEL_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,99}$/;
export const ASSISTANT_MAX_QUESTION_LENGTH = 4000;
// Questions one person may ask per hour, so a stuck browser tab or script
// cannot run up the provider bill.
export const ASSISTANT_HOURLY_LIMIT = 60;

export const CONVERSATION_STATUSES = Object.freeze(['idle', 'thinking', 'failed']);

export const ACTION_STATUSES = Object.freeze({
  proposed: { label: 'Waiting for review', tone: 'accent' },
  running: { label: 'Running', tone: 'info' },
  succeeded: { label: 'Done', tone: 'success' },
  failed: { label: 'Failed', tone: 'danger' },
  cancelled: { label: 'Cancelled', tone: 'neutral' },
  expired: { label: 'Expired', tone: 'neutral' },
});
export const ACTION_STATUS_KEYS = Object.freeze(Object.keys(ACTION_STATUSES));
// A proposal older than this can no longer be approved: what it was based on
// may have changed. The person can ask again.
export const ACTION_EXPIRY_MINUTES = 60;

const uuid = { type: 'string', format: 'uuid' };

// Every change the assistant can propose. `params` is a JSON schema (the
// shape the model fills in); `permission` is what approving it needs.
export const ASSISTANT_ACTIONS = Object.freeze({
  'application.restart': {
    label: 'Restart app',
    permission: PERMISSIONS.APPS_DEPLOY,
    target: 'application',
    dangerous: false,
    params: { applicationId: uuid },
  },
  'application.start': {
    label: 'Start app',
    permission: PERMISSIONS.APPS_DEPLOY,
    target: 'application',
    dangerous: false,
    params: { applicationId: uuid },
  },
  'application.stop': {
    label: 'Stop app',
    permission: PERMISSIONS.APPS_DEPLOY,
    target: 'application',
    dangerous: true,
    params: { applicationId: uuid },
  },
  'application.deploy': {
    label: 'Deploy app again',
    permission: PERMISSIONS.APPS_DEPLOY,
    target: 'application',
    dangerous: false,
    params: { applicationId: uuid },
  },
  'application.rollback': {
    label: 'Roll back app',
    permission: PERMISSIONS.APPS_DEPLOY,
    target: 'application',
    dangerous: true,
    params: { applicationId: uuid, deploymentId: uuid },
  },
  'application.apply': {
    label: 'Apply saved settings and restart app',
    permission: PERMISSIONS.APPS_MANAGE,
    target: 'application',
    dangerous: false,
    params: { applicationId: uuid },
  },
  'service.restart': {
    label: 'Restart service',
    permission: PERMISSIONS.SERVERS_SERVICES,
    target: 'server',
    dangerous: true,
    params: { serverId: uuid, service: { type: 'string', pattern: SERVICE_NAME_PATTERN.source } },
  },
  'service.start': {
    label: 'Start service',
    permission: PERMISSIONS.SERVERS_SERVICES,
    target: 'server',
    dangerous: false,
    params: { serverId: uuid, service: { type: 'string', pattern: SERVICE_NAME_PATTERN.source } },
  },
  'website.enable': {
    label: 'Turn website on',
    permission: PERMISSIONS.WEBSITES_MANAGE,
    target: 'website',
    dangerous: false,
    params: { websiteId: uuid },
  },
  'website.retry': {
    label: 'Retry website setup',
    permission: PERMISSIONS.WEBSITES_MANAGE,
    target: 'website',
    dangerous: false,
    params: { websiteId: uuid },
  },
  'website.renew_ssl': {
    label: 'Renew SSL certificate',
    permission: PERMISSIONS.WEBSITES_MANAGE,
    target: 'website',
    dangerous: false,
    params: { websiteId: uuid },
  },
  'server.install_software': {
    label: 'Install server software',
    permission: PERMISSIONS.WEBSITES_MANAGE,
    target: 'server',
    dangerous: false,
    params: {
      serverId: uuid,
      components: { type: 'array', items: { type: 'string', enum: WEB_STACK_COMPONENT_KEYS }, minItems: 1, maxItems: WEB_STACK_COMPONENT_KEYS.length },
    },
  },
});
export const ASSISTANT_ACTION_KEYS = Object.freeze(Object.keys(ASSISTANT_ACTIONS));
