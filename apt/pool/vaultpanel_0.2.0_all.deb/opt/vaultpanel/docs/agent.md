# Server agent

The agent (`agent/`) runs on each managed server as the `vaultpanel-agent` systemd service. It uses
only Node.js built-ins, so installing it needs Node.js 20+ and nothing else.

## The panel's own server

The server the panel runs on is connected by itself. Before the API starts (`npm run dev:backend`
or `npm start`), npm runs `backend/src/cli/connectLocal.js --auto`. When that runs as root on Linux
with systemd, it:

1. adds the server to the panel (named after its hostname, marked **This server**),
2. creates the agent's identity straight in the database (no enrollment token: it can already write
   there) and writes `/etc/vaultpanel-agent/config.json` and `agent.key`,
3. installs the agent from this checkout with `scripts/install-agent.sh --registered --from agent/`,
   using the Node.js the panel runs on (so an older system Node.js does not matter).

The agent talks to the API straight over loopback (`http://127.0.0.1:<VAULTPANEL_PORT>`). Plain HTTP is
allowed there because the traffic never leaves the machine; both sides check it (the agent only for
loopback panel URLs, the panel only for requests that reach it from loopback without passing through
a proxy).

On later starts it does nothing, except update the agent when this checkout carries a newer one, so
the panel's own server never needs the upgrade command. It never adds the server twice:

- if this server was already connected by hand with **Add a server**, that server is marked as the
  panel's own instead;
- if the agent here belongs to a different panel, it is left alone (`--force` takes it over);
- if you remove the server from the panel, it is not added again (`--force` adds it back).

Run it by hand with `npm run connect-local` (as root), for example when the panel runs as a non-root
user. `VAULTPANEL_LOCAL_AGENT=false` turns the automatic run off. The web app itself never installs
anything: this is a separate short process, run before the API starts.

## Install on another server

From the server's page in the panel, copy the install command:

```sh
curl -fsSL https://panel.example.com/api/v1/agent/install.sh \
  | sudo bash -s -- --panel https://panel.example.com --token vpe_…
```

It downloads the agent to `/opt/vaultpanel-agent`, registers it (writing
`/etc/vaultpanel-agent/config.json` and `agent.key`, both mode 600) and starts the service.
The panel URL must be HTTPS; `--insecure-http` exists only for local development and the panel
must also set `VAULTPANEL_ALLOW_INSECURE_AGENTS=true` (the panel then adds it to the command).

**A panel with its own self-signed certificate** (the default for install.sh) gives a pinned command:

```sh
curl -fsSL --pinnedpubkey 'sha256//…' -k https://203.0.113.10:8090/api/v1/agent/install.sh \
  | sudo bash -s -- --panel https://203.0.113.10:8090 --token vpe_… --panel-pin 'sha256//…'
```

curl accepts only the panel's public key. The script fetches the panel's certificate
(`/api/v1/agent/panel-cert.pem`), checks it carries the pinned key, and saves it as
`/etc/vaultpanel-agent/panel-ca.pem`; registration and the agent's services
(`Environment=NODE_EXTRA_CA_CERTS=…` in their units) then trust that certificate with normal TLS
checks, host name included. `--upgrade --panel <url> --panel-pin <pin>` moves an installed agent to
a panel that turned HTTPS on, or refreshes the certificate after `vaultpanel https renew`: it keeps
the registration, saves the certificate and points `config.json` at the new address.

Commands: `vaultpanel-agent register|run|status|version|cron-run <id>`. `status` prints one telemetry snapshot
without contacting the panel.

## What it does

- **Heartbeat** every 15 s: hostname, OS, kernel, architecture, CPU cores, memory, disk, uptime;
  CPU %, load, memory, swap, disk usage of `/`, network rates, process count; usage of every real
  mounted filesystem (up to 20, skipping `/boot` and snaps); the state of the services in
  `watchServices`; the list of operations this agent version supports; and, every few minutes, the
  web stack (NGINX, PHP-FPM versions, Certbot), the certificates in `/etc/letsencrypt/live/vp-*`
  (so renewals by Certbot show in the panel), the server's own IP addresses (for DNS checks), Git,
  PM2, Python, Node.js and MariaDB versions, whether cron is installed, the state of each app's PM2
  process, and the size of each database; the server's time zone; and the backup files on disk with
  their sizes (so a backup removed by hand shows as missing in the panel).
- **Self-check** (0.39.0) every few minutes: what the panel's features need from the server (see
  **Self-check** under Operations).
- **Jobs**: long-polls the panel, runs one job at a time, streams log lines, reports the result.

## Operations

| Operation | What runs |
| --- | --- |
| `SERVICE_STATUS` | `systemctl show <unit>` |
| `SERVICE_START`, `SERVICE_STOP`, `SERVICE_RESTART` | `systemctl start\|stop\|restart <unit>`, then checks the unit reached the expected state |
| `SERVICE_LOGS` | `journalctl --unit=<unit> --lines=N --no-pager --output=short-iso` (10 to 1000 lines) |
| `PROCESS_LIST` | `ps -eo … --sort=-pcpu` (or `-pmem`) |
| `PROCESS_SIGNAL` | sends `TERM` or `KILL` to one pid (see below), then waits briefly to report whether it exited |
| `SERVER_REBOOT` | reports success, then `systemctl reboot` a few seconds later |
| `WEB_STACK_INSTALL` | `apt-get update`, then `apt-get install -y` a fixed package list for `nginx`, `php` (php-fpm, cli, mysql, curl, gd, mbstring, xml, zip, intl), `certbot`, `git` (git, openssh-client), `python` (python3, venv, pip) or `mariadb` (server and client); `apache` (0.18.0) writes `ports.conf` with `Listen 127.0.0.1:8080` before `apt-get install apache2` (keeping that file), creates the system user `vp-apache`, turns on proxy_fcgi, setenvif, rewrite, remoteip, headers and expires, turns off status, info, cgi and userdir and the default site, adds `conf-available/vaultpanel.conf` (runs as `vp-apache`, trusts X-Forwarded-For from 127.0.0.1, drops PHP_VALUE and PHP_ADMIN_VALUE before PHP-FPM, closes the sites root except per-site folders), then `apache2ctl configtest` and restarts; it refuses (`APACHE_IN_USE`) when an Apache VaultPanel did not set up is there; `pm2` is `npm install -g pm2@6` with the agent's Node.js |
| `PHP_VERSION_INSTALL` | extra PHP versions (0.17.0): one of 7.4, 8.0 to 8.5. `apt-get update`, then if no source offers `php<version>-fpm` (`apt-cache policy`) adds one repository: `ppa.launchpadcontent.net/ondrej/php` on Ubuntu (key 14AA40EC0831756756D7F66C4F4EA0AAE5267A6C from keyserver.ubuntu.com, saved as `/etc/apt/keyrings/vaultpanel-php.asc`) or `packages.sury.org/php` on Debian (`/etc/apt/keyrings/vaultpanel-php.gpg`, or `.asc` when the key comes armored), in `/etc/apt/sources.list.d/vaultpanel-php.list` for the release's codename; takes it away again if it has no packages for this release (`PHP_VERSION_UNAVAILABLE`). Installs `php<version>-` fpm, cli, mysql, curl, gd, mbstring, xml, zip, intl (and json before 8.0), then `systemctl enable --now php<version>-fpm` |
| `PHP_VERSION_REMOVE` | refuses while a website's pool is in `/etc/php/<version>/fpm/pool.d` or phpMyAdmin uses that version (`PHP_VERSION_IN_USE`); lists the installed `php<version>*` packages with `dpkg-query`, simulates `apt-get -s purge` and refuses if anything else would go with them, such as the system's `php-fpm` or phpMyAdmin (`PHP_VERSION_NEEDED`); then `apt-get purge` |
| `CREATE_SITE` | `useradd` a system user for the site (home `/var/www/<name>`, mode 0750, `www-data` added to its group), creates `public/`, `logs/`, `tmp/` and a placeholder page as that user, writes the PHP-FPM pool (`php-fpm<v> -t`), writes the NGINX site (`nginx -t`), reloads, then checks the site answers. With `htaccess` (0.18.0, PHP and static sites) it first writes `/etc/apache2/sites-available/vp-<name>.conf` (a VirtualHost on 127.0.0.1:8080 whose .htaccess files may use AuthConfig, Indexes, Limit, the Options Indexes, MultiViews and SymLinksIfOwnerMatch, and the directives in `HTACCESS_DIRECTIVES`), adds `vp-apache` to the site's group, runs `apache2ctl configtest` (a refused file is put back, `APACHE_CONFIG_INVALID`) and reloads Apache; the PHP socket then belongs to `vp-apache` and NGINX proxies `/` to Apache. Without Apache it fails with `APACHE_NOT_INSTALLED`. A domain may be a wildcard (0.37.0, `*.example.com`, one `*.` at the start only): it goes into `server_name` as it is, and into Apache's `ServerAlias`, never `ServerName` (the first plain domain, or `vp-<name>.invalid` when there is none); the health check asks for the first plain domain, or `vaultpanel-check.example.com` |
| `CREATE_NGINX_CONFIG` | rewrites the NGINX site and PHP pool for new domains, type, PHP version, port, HTTPS, enabled state or custom rules. `spa` (0.30.0, static sites only, not with `htaccess`) makes `location /` use `try_files $uri $uri/ /index.html`. `customNginx` (0.18.0, at most 8192 characters) is the one piece of text that goes into a configuration file: every statement must be a `location`, `if` or `limit_except` block or a directive from `CUSTOM_NGINX_DIRECTIVES` in `security/webRules.js` (no `root`, `alias`, `include`, logs or temp paths, no `unix:` anywhere, `proxy_pass` only to a fixed http(s) address), braces and quotes must balance, and it is placed in each server block that serves the site, before the site's own locations; `nginx -t` then decides, and a refused file is put back |
| `DELETE_SITE` | removes the NGINX site, Apache site, PHP pool and certificate (`certbot delete`); with `removeFiles`, also stops the user's processes and runs `userdel` and removes the home folder |
| `ISSUE_SSL`, `RENEW_SSL` | checks each domain reaches this server (a token file served over HTTP), then `certbot certonly --webroot` with the shared challenge folder, then switches NGINX to HTTPS. Wildcard site domains (0.37.0) are left out, since this check cannot issue them, and a site with nothing else is refused (`WILDCARD_CERT_NEEDED`); a deploy hook reloads NGINX after Certbot's own renewals. With `renewBeforeDays` (0.25.0) both write `renew_before_expiry` into the certificate's renewal file, and both turn Certbot's renewal timer (`certbot.timer` or `snap.certbot.renew.timer`) on when it is off; a masked timer is left alone |
| `ISSUE_SSL` with `wildcardZone` | (0.28.0) a certificate for the zone and `*.zone` through Let's Encrypt's DNS check: `certbot certonly --manual --preferred-challenges dns` with hooks that run `vaultpanel-agent acme-dns-hook auth\|cleanup` (a script at `acmeHookPath`, default `/usr/local/lib/vaultpanel/acme-dns-hook`). The hook adds `_acme-challenge.<name> TXT` to the DNS zone file this server serves for the name, without changing its serial, checks it with `named-checkzone`, reloads BIND and waits until `dig @127.0.0.1` answers with it; cleanup removes the line. Every site domain must be the zone or one level under it. An uploaded certificate is moved aside while Certbot runs and put back if it fails |
| `ISSUE_SSL` with `wildcardZone` and `dnsProvider` | (0.38.0) the same DNS check through the domain's DNS provider instead of a zone on this server. `dnsProvider` is `{ type: "cloudflare", apiToken }` or `{ type: "namecheap", apiUser, apiKey, clientIp, domain }`. The agent writes it to `<acmeDnsDir>/vp-<site>.json` (mode 600) and gives Certbot the hooks `acme-dns-hook auth vp-<site>` and `cleanup vp-<site>`, so renewals find it too; if Certbot fails, the file that was there comes back. The hook adds `_acme-challenge.<name> TXT` through the provider's API (Cloudflare: the nearest zone the token sees; Namecheap: `getHosts`, then `setHosts` with every record read and the domain's `EmailType`, refusing a list it cannot read exactly), then asks the zone's own name servers until they answer with it (up to 4 minutes). Issuing another way or `DELETE_SITE` removes the file |
| `INSTALL_SSL_CERT` | (0.28.0) a certificate bought elsewhere: checks the key matches (`checkPrivateKey`), it is valid now, covers every site domain (wildcards included) and the chain is in order, then moves any Let's Encrypt certificate's live, archive and renewal entries aside, writes `cert.pem`, `chain.pem`, `fullchain.pem`, `privkey.pem` (0600) and a `.vaultpanel-custom` marker into `live/vp-<site>` and switches NGINX to HTTPS. When NGINX refuses, the previous certificate comes back. `RENEW_SSL` refuses an uploaded certificate (`SSL_CUSTOM`); heartbeats report `custom: true` for it |
| `SET_SSL_RENEWAL` | (0.25.0) writes `renew_before_expiry = <renewBeforeDays> days` into every `vp-*` renewal file in `/etc/letsencrypt/renewal`, never more than two thirds of the certificate's lifetime, and turns Certbot's timer on |
| `SITE_LOGS` | reads the last lines of the site's NGINX access or error log |
| `DOCKER_STATUS` | whether Docker is installed and running (snap or package), its version and counts, from the Engine API |
| `DOCKER_INSTALL` | starts Docker if it is installed (`snap start --enable docker` for the snap, `systemctl enable --now docker.service` otherwise), or `apt-get install -y docker.io` and starts it |
| `CONTAINER_LIST`, `CONTAINER_INSPECT`, `CONTAINER_LOGS` | every container, one container's state, mounts, limits and live CPU/memory, or its last 10 to 2000 log lines (environment values are never returned, only names) |
| `CONTAINER_DEPLOY` | pulls the image, creates the container on the `vaultpanel` network with the fixed hardening below, starts it and checks it stays up; replacing one renames the old container, and puts it back if the new one fails |
| `CONTAINER_START`, `CONTAINER_STOP`, `CONTAINER_RESTART`, `CONTAINER_REMOVE` | the matching Engine API call; removing a VaultPanel container can also delete its `vp-<name>-*` volumes |
| `IMAGE_LIST`, `IMAGE_PULL`, `IMAGE_REMOVE` | images with the containers using them, a pull from a public registry, or removing an unused image by its ID |
| `FILE_LIST`, `FILE_READ`, `FILE_WRITE`, `FILE_MKDIR`, `FILE_RENAME`, `FILE_DELETE` | run in a separate process as the site's own user, inside its home folder (see below) |
| `FILE_UPLOAD` | (0.26.0) fetches a file uploaded to the panel in 8 MB pieces (`GET /agent/uploads/:id/chunks/:offset`) into `/var/cache/vaultpanel/uploads` (a folder that cannot be listed; the file has a random name), checks its size and SHA-256, then the file worker copies it into the site as the site's user. The staged copy is always deleted |
| `FILE_DOWNLOAD` | (0.27.0) the file worker reads the file as the site's user in 2 MB pieces (no links out of the site), and the agent posts each piece to `POST /agent/downloads/:id/chunks`, then reports the size and SHA-256, which the panel checks |
| `FILE_CHMOD` | (0.27.0) as the site's user: a three-digit mode (no setuid, setgid or sticky bits) on a file or folder, never the home folder; with `recursive`, folders inside get `mode` and files `fileMode`. Links are skipped, never followed |
| `FILE_EXTRACT` | (0.26.0) as the site's user: `unzip -n\|-o <archive> -d <folder>` or `tar -x [-z] --no-same-owner --no-same-permissions --skip-old-files\|--overwrite`. First reads the archive's listing to refuse one that unpacks to more than 20 GB (`maxExtractBytes` in the config) or 90% of the free disk space. Both paths are resolved inside the site first, so links out of it are refused. `unzip`, `zip` and `tar` are installed with apt when missing, unless web stack installs are turned off |
| `FILE_COMPRESS` | (0.26.0) as the site's user, in the chosen folder: `zip -r -q -y <target> ./<name>...` (links are stored as links, not followed); refuses a target that exists and removes a half-written one |
| `CREATE_APPLICATION` | creates the app's Linux user and home folder (like a site), `releases/`, `shared/`, `logs/`, and an ed25519 deploy key in `.ssh/` (skipped with a warning when `ssh-keygen` is missing) |
| `DEPLOY_GIT` | as the app's user: `git clone --depth 1 --branch <b>` into a new release folder, then the install command (`npm ci`/`npm install`, or a virtualenv and `pip install -r requirements.txt` for Python), the build command, writes `shared/.env` and `shared/ecosystem.json`, writes the `pm2-<app>` systemd unit, points `current` at the release, restarts, and waits for the port to answer (the health check). A failed health check points `current` back at the previous release |
| `ROLLBACK_APPLICATION` | points `current` at a kept release, restarts and health-checks it |
| `CONFIGURE_APPLICATION` | rewrites `.env`, `ecosystem.json` and the unit for new environment variables, start command, port or number of copies, then restarts. When only the number of copies of an app in cluster mode changed, it runs `pm2 scale <app> <n>` as the app's user instead, so the other copies keep serving (falls back to a restart if PM2 refuses) |
| (`instances`, 0.14.0) | on `DEPLOY_GIT`, `ROLLBACK_APPLICATION` and `CONFIGURE_APPLICATION`, 1 to 16 copies (only sent above 1). Node.js apps: PM2 cluster mode. The start command must be `node [options] <file> [args]` or a program that is itself a Node.js script (a `.js`/`.mjs`/`.cjs` file or a `#!...node` script, read as the app's user); anything else fails the configure stage. PM2 runs `shared/cluster-start.cjs`, written from checked values, which drops the `start <ecosystem>` arguments every copy inherits from `pm2-runtime` and loads the script (CommonJS or ES module). Python apps: one process with `WEB_CONCURRENCY=<n>`. The health check waits until every copy is online in PM2 |
| `START_APPLICATION`, `STOP_APPLICATION`, `RESTART_APPLICATION` | `systemctl start\|stop\|restart pm2-<app>` |
| `APP_STATUS`, `APP_LOGS` | the unit state and `pm2 jlist` as the app's user; the last lines of `logs/app-output.log` or `app-error.log` |
| `DELETE_APPLICATION` | stops and removes the unit; with `removeFiles`, also the Linux user and home folder |
| `CREATE_DATABASE`, `DELETE_DATABASE` | `CREATE DATABASE … utf8mb4` / `DROP DATABASE`, through the `mysql` client as root |
| `CREATE_DATABASE_USER`, `UPDATE_DATABASE_USER`, `DELETE_DATABASE_USER` | creates the user for both `localhost` and `127.0.0.1`, sets its password and grants (all, or `SELECT` only) on its databases |
| `DATABASE_TABLES`, `DATABASE_TABLE_ROWS`, `DATABASE_QUERY` | the database interface (0.12.0): lists tables, reads one page of rows with the columns, indexes and `CREATE` statement, or runs SQL. Never as root: each database has two accounts of its own (`vp-sql-<hash>-ro` with `SELECT, SHOW VIEW`, `vp-sql-<hash>-rw` with all privileges, both on that database only), and the `mysql` client runs as `nobody`, with `--sandbox` where the client has it (older clients get no backslashes or client commands), `sql_select_limit` of 1001 and `max_statement_time` of 30 seconds. `DELETE_DATABASE` drops both accounts |
| `PHPMYADMIN_SETUP`, `PHPMYADMIN_REMOVE` | installs the distribution's `phpmyadmin` package (debconf answered up front: no database of its own, no Apache), writes `/etc/phpmyadmin/conf.d/vaultpanel.inc.php` (cookie sign-in, root and empty passwords refused), and an NGINX site `vaultpanel-phpmyadmin.conf` on its own port (default 8081; not 22, 80, 443, 3306, 3307, 5173, 8090 and other panel ports) through the default PHP-FPM pool, with `setup/` and `libraries/` blocked and PHP requests rate-limited. With the panel domain's certificate it listens with TLS. Opens the port in UFW when the firewall is on, then checks it answers. Remove only deletes the NGINX site |
| `PHPMYADMIN_SIGNON` | one-click sign-in (internal, queued by the panel with a database name and a token's SHA-256). Refuses when phpMyAdmin is not served (`PHPMYADMIN_NOT_SET_UP`). Rewrites the settings (a second, `signon` server whose logout returns to the login form) and `vaultpanel-signon.php` in phpMyAdmin's folder, makes sure the database's `vp-sql-…-rw` account exists with only that database, and writes a two-minute ticket `/run/vaultpanel-phpmyadmin/<sha256>.json` (folder 730 and ticket 640, group www-data; old tickets swept). The script uses each ticket once |
| `CREATE_BACKUP` | a website or app: `tar --create` of its home folder as the site's or app's own user (an app's live release only; `tmp/`, `logs/` and `.pm2/` left out), compressed by the agent into `<backupRoot>/<site\|app>/<name>/<id>.tar.gz`; a database: `mariadb-dump --single-transaction` into `<backupRoot>/database/<name>/<id>.sql.gz`. Refused when less than `backupMinFreeBytes` is free. Reports the size and SHA-256. With `storage` (0.13.0): then uploads it to that S3-compatible bucket (one signed `PUT`, or a multipart upload above 256 MB, every body's SHA-256 in its signature) or SFTP server (OpenSSH `sftp -b -` with the job's key and pinned host key, `StrictHostKeyChecking=yes`, written as `.partial` then renamed), checks the copy's size, and removes the local file unless `keepLocal`. If the upload fails the backup is kept on the server and the reason reported |
| `RESTORE_BACKUP` | with `storage`, first fetches the backup from the bucket when it is not on the server (removed again afterwards); checks the file's SHA-256 against the one recorded, then for files: `tar --extract` as the owner into a staging folder, stops the app, swaps the staged files in (keeping `tmp/` and `logs/`), restarts and health-checks the app; for a database: drops and recreates it, then imports the dump through `mysql` |
| `DELETE_BACKUP` | removes one backup file, and with `storage` its object in the bucket |
| `UPLOAD_BACKUP` | sends a backup file to the panel in 2 MiB chunks for a download (fetched from the bucket first when it is only there); the panel checks the SHA-256 |
| `TEST_BACKUP_STORAGE` | writes a small file to an S3-compatible bucket or SFTP server, reads it back and deletes it (0.13.0). For SFTP without a pinned host key it first reads the server's keys with `ssh-keyscan` and returns them for the panel to pin; the key files live in a private temporary folder only for the call. The destination, secret key included, comes with each job and is never saved on the server; requests are signed with AWS Signature Version 4 by the agent's own code (Node built-ins only) |
| `CREATE_CRON`, `DELETE_CRON` | saves or removes the job's settings in `<cronSpecDir>/<id>.json` and rewrites `/etc/cron.d/vaultpanel` (see below) |
| `RUN_CRON` | runs a cron job once now and returns its exit code and output |
| `SECURITY_STATUS` | reads `ufw status` and the UFW rule files, `sshd -T`, root's `authorized_keys` and the administrator accounts (`/etc/passwd`, `/etc/group`, `/etc/shadow`), `fail2ban-client status sshd`, the APT periodic settings and `apt-get -s upgrade` (cached 6 hours), and failed SSH sign-ins from the journal over the last 24 hours |
| `SECURITY_TOOLS_INSTALL` | `apt-get install` of `ufw`, `fail2ban` (with `python3-systemd`) or `unattended-upgrades` |
| `FIREWALL_ENABLE`, `FIREWALL_DISABLE` | adds allow rules for the SSH ports, the panel's port and (with NGINX) 80/443, then `ufw --force enable`; `ufw disable` |
| `FIREWALL_RULE_ADD`, `FIREWALL_RULE_DELETE` | `ufw [prepend] <action> [proto P] from <src> to any [port P] [comment C]`, or for outgoing rules (0.34.0) `ufw [prepend] <action> out [proto P] from any to <dst> [port P]`; `ufw delete` of the same rule. Outgoing deny/reject rules covering the panel's address and port are refused |
| `FIREWALL_DEFAULTS` | `ufw default <deny\|reject\|allow> incoming` and (0.34.0) `outgoing`; before outgoing becomes deny or reject it adds allow-out rules for the panel, DNS, web, NTP and (with Postfix) mail |
| `SSH_CONFIGURE` | writes `/etc/ssh/sshd_config.d/00-vaultpanel.conf`, `sshd -t`, `sshd -T`, `systemctl reload ssh` |
| `SSH_KEY_ADD`, `SSH_KEY_REMOVE` | edits `/root/.ssh/authorized_keys` (mode 600); from 0.34.0 `user` names another login account, whose file is written by `keysWorker.js` running as that account (in the host's mount namespace when `/home` is read-only for the agent) |
| `SSH_PORTS_SET` | (0.34.0) checks the ports are free (`ss -ltnpH`), opens them in UFW when it is on, writes the `Port` lines of `00-vaultpanel.conf`, `sshd -t`, `sshd -T`, restarts SSH (and `ssh.socket` when socket-activated), checks SSH answers on every port or puts the old file back, then points the Fail2ban jail at the new ports |
| `LOGIN_BANNER_SET` | "VaultPanel only": removes the execute bit from the other `/etc/update-motd.d` scripts (and remembers which), sets `/etc/motd` aside as `/etc/motd.vaultpanel-saved` and puts the banner (art and VaultPanel links) there; "Last login" still shows. Turning it off restores exactly that. On by default: the agent turns it on at its first start and applies it again at each start, unless it was turned off in the panel (0.21.0). The panel's address on it follows the heartbeat reply's `panel.url` (0.23.0) |
| `FAIL2BAN_CONFIGURE`, `FAIL2BAN_UNBAN` | writes `/etc/fail2ban/jail.d/vaultpanel.local`, `fail2ban-client --test`, `systemctl enable` and `restart fail2ban`, then checks the SSH jail runs; `fail2ban-client unban <ip>` |
| `AUTO_UPDATES_CONFIGURE`, `SECURITY_UPDATES_INSTALL` | writes `/etc/apt/apt.conf.d/20auto-upgrades`; `unattended-upgrade --verbose` |
| `LISTENING_PORTS` | `ss -H -ltnp` (fixed arguments): TCP ports listening, their address and the processes holding them (at most 500) |
| `SELF_CHECK` | (0.39.0) the server self-check, read now (see **Self-check** below); the next heartbeat reads the inventory again so it carries the same report |
| `SYSTEM_LOGS` | `journalctl --output=short-iso` for everything, the kernel (`--dmesg`), authentication (auth and authpriv facilities) or cron, with a level, time range and line count (10 to 2000); a search is plain text, matched without regard to case over the newest 20 000 lines |
| `DNS_SETUP` | installs `bind9`, `bind9-utils` and `bind9-dnsutils` when `named`, `named-checkzone` or `dig` is missing, keeps the original `named.conf.options` as `named.conf.options.vaultpanel-orig` and writes an authoritative-only one (no recursion, no zone transfers, version hidden, response rate limit), adds `include "/etc/bind/vaultpanel/zones.conf";` once to `named.conf.local`, `named-checkconf`, enables and restarts `named`, and opens port 53 (TCP and UDP) in UFW when the firewall is on (0.15.0) |
| `DNS_ZONE_APPLY` | panel-internal: writes the whole zone from the panel's records to a draft file, checks it with `named-checkzone -k fail -i local`, moves it to `/etc/bind/vaultpanel/<zone>.db`, rebuilds `zones.conf` from the zone files, `named-checkconf` (undone if it fails), reloads `named`, then asks it with `dig @127.0.0.1 SOA` until it serves the new serial. A serial older than the one on disk is skipped, so a late job never rolls a zone back |
| `DNS_ZONE_REMOVE` | panel-internal: removes the zone file and its journal, rebuilds `zones.conf` and reloads `named` |
| `MAIL_SETUP` | email hosting (0.16.0): installs `postfix`, `dovecot-imapd`, `dovecot-pop3d`, `dovecot-lmtpd`, `opendkim` and `openssl` (Postfix's questions answered up front), writes Dovecot 2.3 or 2.4 settings to match the installed version (0.16.1 added 2.4, as on Ubuntu 26.04 and Debian 13; others are refused), creates the `vmail` account and `<mailRoot>` (mode 770), uses the Let's Encrypt certificate of the host name when there is one or makes a 10-year one with `openssl req -x509`, sets Postfix with `postconf -e` (virtual domains, mailboxes and forwarders from hash tables in `/etc/postfix/vaultpanel/`, delivery to Dovecot over LMTP, Dovecot sign-in, OpenDKIM on `127.0.0.1:8891`, TLS 1.2 or newer) and `postconf -M`/`-P` (ports 587 and 465: signed-in users only, sending only as their own address), checks with `postfix check`, writes `/etc/dovecot/conf.d/99-vaultpanel.conf` (IMAP 993 and POP3 995 with TLS only, passwords as SHA512-CRYPT from `/etc/dovecot/vaultpanel/users`, size limits, only the vmail account's mail) and comments out `auth-system.conf.ext` in `10-auth.conf` so Linux accounts cannot sign in, checks with `doveconf -n` (put back if refused), writes `/etc/opendkim.conf` (the original kept as `opendkim.conf.vaultpanel-orig`), restarts the three services and opens 25, 465, 587, 993 and 995 in UFW when the firewall is on |
| `MAIL_APPLY` | panel-internal: every domain, mailbox (address, SHA512-CRYPT hash, size limit, on or off) and forwarder of the server, checked again, written to the Postfix tables (`postmap`), Dovecot's user list (mode 640, group dovecot) and the list of mailboxes that are off (they receive mail but cannot sign in or send); makes a 2048-bit DKIM key per domain once (`/etc/opendkim/vaultpanel/keys/<domain>/`, owned by opendkim, mode 600) and returns its public key; removes the keys of removed domains; reloads Postfix and OpenDKIM; deletes the stored mail of the mailboxes and domains the panel lists, only inside `<mailRoot>` and never one still in use. An older change than the one on the server is skipped. The hashes are redacted from the stored job |
| `MAIL_USAGE` | panel-internal: bytes in each mailbox, from Dovecot's `maildirsize` or the files themselves |

Commands run with `spawn` and a fixed argument list, never through a shell, with a timeout.

`PROCESS_SIGNAL` carries the command name the user saw. The agent reads `/proc/<pid>/stat` and refuses
the signal if the pid now belongs to a different command (`PROCESS_CHANGED`), is a kernel thread, the
agent itself or its parent, or a protected process (`systemd`, `init`, `sshd`, `systemd-journald`,
`systemd-logind`, `systemd-udevd`, `dbus-daemon`).

Every NGINX or PHP-FPM change is written next to the old file, tested (`nginx -t`, `php-fpm -t`) and
only then reloaded. If the test fails, the previous files are put back and the job fails with the
tool's own message, so a bad change never takes other sites down. The configuration is generated by
the agent from checked values (domains, site name, PHP version, port); no text from the panel is
copied into it.

**Applications.** Install, build and start commands are split into arguments by the agent (quotes
are understood; pipes, `;`, `&&`, redirects and `$(…)` are refused) and run without a shell as the
app's user, with `$PORT` replaced by the app's port. Each app's PM2 runs under its own systemd unit
(`User=<app>`, `NoNewPrivileges`, `ProtectSystem=full`), so it restarts after crashes and starts at
boot. `.env` and `ecosystem.json` are mode 600. The newest releases (5 by default) and the previous
one are kept for rollbacks.

**Databases.** SQL is sent to the `mysql` client on stdin, never the command line, so passwords do
not show in the process list, and the agent's log replaces them with `********`. Names are checked
against strict patterns before they are quoted; `mysql`, `information_schema`, `root` and other
system names are refused.

**Backups.** Backup files are owned by root, mode 600, in folders of mode 700, so site and app
users cannot read each other's backups. Archives are made and unpacked by `tar` running as the
site's or app's own user, so a backup only reads, and a restore only writes, what that user could
anyway. A restore unpacks into a
staging folder first, so a damaged archive changes nothing. The panel can ask for a safety backup of
the current state before a restore (on by default).

**Cron jobs.** `/etc/cron.d/vaultpanel` holds one line per enabled job, with only the checked
schedule and the job's id:

```
*/5 * * * * root /usr/bin/node /opt/vaultpanel-agent/src/cli.js cron-run <id> >/dev/null 2>&1
```

The commands stay in the root-only settings file. `cron-run` runs them one after another, split into
arguments like app commands (no shell, so no pipes, redirects or `$(…)`), as the site's or app's own
user in its home folder (an app's jobs can get its `.env`), with a timeout. A run that would overlap
the previous one is skipped. The exit code, duration and last 16 KiB of output are kept in
`cronStateDir` until the agent reports them to the panel. Cron itself is installed from the server's
Software card (`WEB_STACK_INSTALL` with `cron`).

**Security.** The agent refuses what would lock people out, whatever the panel asks: the firewall
always keeps the SSH ports (from `sshd -T`) and the ports the panel names open to everyone (deny or
reject rules from everyone on them, and deleting the last rule that opens one, fail with
`LOCKOUT_REFUSED`); SSH settings and key removals must leave an administrator account (root, or a
sudo/admin/wheel member with a login shell) able to sign in with a key or a password. A change that
fails a test (`sshd -t`, `fail2ban-client --test`, the jail not starting) puts the previous file
back. Installing NGINX while the firewall is on also opens ports 80 and 443 (unless a rule blocks them
on purpose). Fail2ban reads the journal when `python3-systemd` is installed, otherwise `/var/log/auth.log`.
The heartbeat carries a short security summary, refreshed every 5 minutes.

**Self-check (0.39.0).** With the inventory, every 5 minutes, and for `SELF_CHECK`, the agent checks
what the panel's features need from the server, as root (by the root helper when there is one):

| Check | How | Fails when |
| --- | --- | --- |
| Agent files | `stat` of every file and folder of the agent's code (at most 5000) and of each folder above it | something lacks read (files) or read and enter (folders) permission for others: the agent's own user and the file manager's worker, which runs as each site's user, then cannot load it. Not checked for an agent in a home folder, whose workers start as root |
| File manager | starts `fileWorker.js` as `nobody`, exactly as for a site, and asks it to answer | it does not start or answer, as with "Cannot find module '/opt/vaultpanel-agent/src/services/fileWorker.js'" |
| NGINX, Apache configuration | `nginx -t`, `apache2ctl -t` (when installed) | the test fails; the report keeps the lines that say why (NGINX's `[emerg]` line) |
| Certificate renewal | `systemctl show` of `certbot.timer`, `snap.certbot.renew.timer` and their services; the files in `<letsencrypt>/renewal`; the `vaultpanel-reload-nginx` deploy hook | (a warning) the timer is missing, masked or stopped, its last run failed, or the hook is missing |
| Clock | `timedatectl show --property=NTPSynchronized` | (a warning) not synchronized; left out where timedatectl cannot tell |
| Failed services | `systemctl list-units --state=failed` | (a warning) any unit failed (at most 20 named) |

The report goes with the heartbeat as `selfCheck: { checkedAt, agent, agentFiles, fileWorker, nginx,
apache, certbot, clock, failedUnits }`, leaving out what was not checked. When the agent runs as its
own user and the root helper does not answer, the heartbeat says so instead: `selfCheck: { checkedAt,
agent, helper: { ok: false, error } }`. An agent that runs without root and without a helper only
reports what needs no root. The panel shows the report on the server's Overview and alerts on what
fails (shared/src/selfCheck.js).

**Disk use (0.8.0).** For hosting plans' disk limits the agent measures each folder under
`sitesRoot` with `nice -n 19 du -s -x` in the background, at most every 15 minutes, and sends the
sizes with the heartbeat (`diskUsage: { checkedAt, folders: [{ name, sizeBytes }] }`). Folders that
cannot be measured are left out. Older agents send nothing; their sites show "Not measured".

**Listening ports (0.9.0).** `LISTENING_PORTS` is used by the AI assistant to check, for example,
whether an app's port is open or taken by another process. Older agents answer `AGENT_OUTDATED`;
update them from the server page.

**Containers (0.10.0).** The agent talks to Docker's Engine API over its unix socket
(`/var/run/docker.sock`, or `dockerSocket`) with Node's own HTTP client: no `docker` command and no
shell. Every container it creates is unprivileged with no added capabilities or devices,
`no-new-privileges`, logs capped at 3 files of 10 MB, only named volumes (`vp-<container>-<volume>`,
never folders of the server), ports bound to `127.0.0.1` unless the panel asks for `0.0.0.0`, and the
labels `io.vaultpanel.managed` and `io.vaultpanel.id`. The agent checks every parameter itself as well.
Containers publishing the panel's database or Redis ports (sent by the panel for its own server), or
labelled `io.vaultpanel.protected`, can be started but never stopped, restarted or removed
(`PROTECTED_CONTAINER`). The heartbeat carries a short Docker summary: whether it runs, and each
container's name, state and published ports.

**File manager.** Each file request runs as a child process with the site user's uid and gid (never
root), so it can only touch what that user owns. On top of that, paths are resolved with `realpath`
and must stay inside the site's home folder, files are opened with `O_NOFOLLOW`, and writes go to a
temporary file renamed into place. Symbolic links are listed but never followed. When Node.js
lives in a home folder (nvm), which the site user cannot reach, the worker starts as root and
switches to the site user's groups, gid and uid before it reads the request, and checks the switch
took effect.

## Upgrading

Agents report the operations they support. Operations added after an agent was installed are refused
by the panel with `AGENT_OUTDATED`, and the server page shows an upgrade command:

```sh
curl -fsSL https://panel.example.com/api/v1/agent/install.sh \
  | sudo bash -s -- --upgrade --panel https://panel.example.com
```

`--upgrade` replaces the code in `/opt/vaultpanel-agent`, keeps `/etc/vaultpanel-agent` (identity and
policy) and restarts the service. New policy keys take their defaults until you set them.

From 0.7.0 the panel can update the agent itself (`AGENT_UPDATE`, from the server page's Update agent
button or a bulk action). The signed job names the version, size and SHA-256 of the package the panel
serves at `/api/v1/agent/package.tgz` (built the same way every time, so the hash is stable). The
agent downloads it, refuses it if the size, hash, package name or version differ, checks the new code
starts (`cli.js version`), then swaps it into `/opt/vaultpanel-agent` and keeps the old code in
`/opt/vaultpanel-agent.previous`. After reporting the result it exits, and systemd (`Restart=always`)
starts the new version. It only does this when it runs from `agentInstallDir`, so an agent started by
hand from a checkout is never overwritten. To go back, move `.previous` into place and restart the
service. Agents older than 0.7.0 need the command above once.

## Local policy (config.json)

| Key | Default | Meaning |
| --- | --- | --- |
| `allowedServices` | nginx, apache2, php*-fpm, mariadb, mysql, postgresql, redis, docker, cron, ssh, ufw, fail2ban, pm2-* … | Units that may be restarted or inspected (globs) |
| `watchServices` | common web stack units | Units reported in the heartbeat |
| `allowReboot` | `true` | Set `false` to refuse reboots |
| `allowProcessSignals` | `true` | Set `false` to refuse stopping or killing processes |
| `diskPath` | `/` | Filesystem reported as disk usage |
| `allowWebsites` | `true` | Set `false` to refuse every website, SSL and file operation |
| `allowWebStackInstall` | `true` | Set `false` to refuse installing packages |
| `sitesRoot` | `/var/www` | Where site home folders are created |
| `nginxSitesAvailable`, `nginxSitesEnabled`, `nginxConfD`, `nginxLogDir` | Debian/Ubuntu paths | NGINX layout |
| `acmeWebroot` | `/var/lib/vaultpanel/acme` | Shared folder for Let's Encrypt HTTP challenges |
| `letsencryptDir`, `phpConfRoot`, `phpRunDir`, `webServerUser` | `/etc/letsencrypt`, `/etc/php`, `/run/php`, `www-data` | Certbot, PHP-FPM and web server layout |
| `allowApplications` | `true` | Set `false` to refuse every app operation |
| `allowDatabases` | `true` | Set `false` to refuse every database operation |
| `systemdUnitDir` | `/etc/systemd/system` | Where the `pm2-<app>` units are written |
| `nodeBinDir` | the agent's own Node.js, or `/usr/local/bin` or `/usr/bin` when the agent's is in a home folder (nvm) | Node.js used to run apps and PM2 |
| `npmCacheDir` | `/var/cache/vaultpanel/npm` | npm's cache when installing PM2 (the agent's service keeps `/root` read-only) |
| `mysqlDefaultsFile` | none | A MySQL options file with root credentials, when root cannot use the unix socket |
| `deployEnv` | `{}` | Extra environment for git, npm and pip during deployments (for example `HTTPS_PROXY`) |
| `allowBackups` | `true` | Set `false` to refuse every backup and restore |
| `allowCron` | `true` | Set `false` to refuse every cron job operation |
| `backupRoot` | `/var/backups/vaultpanel` | Where backups are kept (root only) |
| `backupMinFreeBytes` | 512 MiB | Backups are refused when less than this is free in `backupRoot` |
| `allowFirewall`, `allowSshConfig`, `allowFail2ban`, `allowUpdates` | `true` | Set `false` to refuse firewall, SSH, Fail2ban or update changes |
| `allowSelfUpdate` | `true` | Set `false` to refuse updates from the panel (use the upgrade command instead) |
| `agentInstallDir` | `/opt/vaultpanel-agent` | Where the install script puts the agent; updates from the panel only run when the agent runs from here |
| `allowContainers` | `true` | Set `false` to refuse every Docker and container operation |
| `dockerSocket` | `/var/run/docker.sock` or `/run/docker.sock` | Docker's API socket |
| `allowTerminal` | `true` | Set `false` to refuse the server terminal (0.11.0); the panel then says it is turned off |
| `terminalHostNamespace` | `true` | Start terminal shells in the host's mount namespace, outside the service's sandbox (see below) |
| `runAsRoot` | `false` | Set `true` to keep the agent as one root service instead of its own user plus a root helper (0.36.0) |
| `cronFile`, `cronSpecDir`, `cronStateDir` | `/etc/cron.d/vaultpanel`, `/etc/vaultpanel-agent/cron`, `/var/lib/vaultpanel/cron` | Cron layout |
| `allowDns` | `true` | Set `false` to refuse every DNS operation |
| `bindConfDir` | `/etc/bind` | BIND's configuration folder; zones go in `<bindConfDir>/vaultpanel/` |
| `acmeDnsDir` | `/etc/vaultpanel-agent/acme-dns` | (0.38.0) DNS providers' credentials for wildcard certificates, one file per certificate (mode 600, folder 700) |
| `allowMail` | `true` | Set `false` to refuse every email operation |
| `mailRoot` | `/var/mail/vhosts` | Where mailboxes are kept (`<domain>/<name>/Maildir`) |

The agent's own units (`vaultpanel-agent`, `vaultpanel-agent-helper`) can never be restarted or stopped through a job, and `ssh`/`sshd` can never be
stopped (restart is still allowed). The server owner's policy wins over
anything the panel asks.

## Server terminal (0.11.0)

Owners can open a root shell on a server from the panel (**Terminal** in the sidebar, or the
**Terminal** tab on a server). It is not an operation, and the operation allow-list is unchanged: it
is a separate channel.

- The agent keeps one WebSocket open to the panel at `/api/v1/agent/terminal`, signed with its key
  like every other request (the signature is in the query string). It reconnects by itself.
- To open a shell, the panel sends an envelope signed with the panel key, for this server, valid for
  a minute and used once, exactly like a job. Anything else is refused.
- The shell is root's login shell on a pseudo-terminal made by `script` (util-linux). The agent's
  service is sandboxed (`ProtectHome=read-only`, `PrivateTmp`), so the shell is started in the host's
  mount namespace with `nsenter`, and sees the server as an SSH session would.
- Shells end when the browser closes, the person signs out or loses the owner role, or the agent
  restarts (so `systemctl restart vaultpanel-agent` from the terminal ends that terminal).
- It needs Node.js 22 or later (for its WebSocket client); on Node.js 20 the agent logs that the
  terminal is not available and everything else keeps working.
- Opening and closing are written to the audit log (`server.terminal.open`, `server.terminal.close`
  with the duration and amount of output).
- The panel, not the agent, records sessions as the bytes pass through it (asciicast v2 files in
  the panel's data folder). Typed keys are recorded only when the owner turns that on.

## Trust

- The agent signs every request with its private key; the panel stores only the public key.
- The panel signs every job envelope; the agent pins the panel key at registration and refuses
  envelopes that are unsigned, tampered, addressed to another server, expired or already run.
- Removing a server, or registering a new agent for it, revokes the old agent. A revoked agent stops.

## Running as its own user (0.36.0)

The install script starts the agent as root. An agent from 0.36.0 that starts as root under systemd
from `/opt/vaultpanel-agent` then moves itself to two services:

| Service | Runs as | Does |
| --- | --- | --- |
| `vaultpanel-agent` | `vaultpanel-agent` (a system user without a shell or home) | talks to the panel: heartbeat, jobs, terminal link; no capabilities, `NoNewPrivileges`, read-only system, no `/home` or `/root` |
| `vaultpanel-agent-helper` | root | runs jobs and opens terminal shells, reads what the heartbeat needs from root-only files (sites, certificates, databases, backups, Docker, the security summary, the self-check, disk use), keeps the login message; has no connection to the panel |

They talk over `/run/vaultpanel-agent-helper/helper.sock` (mode 660, group `vaultpanel-agent`), one JSON
message per line. The helper does not take the agent's word for anything that changes the server: it
checks every job and every terminal request itself, against the panel's key in the root-owned
`config.json` (signature, server, expiry, not seen before), exactly as the agent did when it ran as
root. The agent's user can read `config.json` but not change it; it owns `agent.key`. Panel calls an
operation makes while it runs (the agent package, file upload and download pieces, backup copies)
go back through the agent, which holds the key the panel knows; the package is still checked against
the size and SHA-256 in the signed job.

When the agent's Node.js is in a home folder (nvm), a copy goes to `/opt/vaultpanel-agent-node/node`
for the agent's user; the helper keeps the original, which apps use. After an update from the panel
both services start again on the new code. Going back (a rollback) to a version before 0.36.0 puts
the single root service back, since older code only works that way.

If the agent does not reach the panel as its own user within 10 minutes, the helper puts the root
service back and the server's security checks say why ("Agent privileges"). It does not try again
until `/var/lib/vaultpanel/agent-mode.json` is removed and the agent restarted. `"runAsRoot": true`
in `config.json` keeps one root service (restart `vaultpanel-agent-helper` to apply it when the agent
already runs as its own user). An agent run from a checkout (development) stays as it was started.

## Limits today

Website, app, database and security operations target Debian and Ubuntu (apt, UFW, `www-data`,
`/etc/php/<v>/fpm`). Whatever the panel signs runs as root in the helper: a panel that is broken
into can still do everything the operations allow (they are allow-listed and checked, and the
terminal is owners only). The helper's service can write `/root/.ssh` (for root's keys) while the
rest of `/root` stays read-only.
