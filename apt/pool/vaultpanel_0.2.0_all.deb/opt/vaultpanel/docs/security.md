# Security

What is implemented, and what is not yet.

## Implemented

- **The panel runs without root** (install.sh): the API and the worker run as the `vaultpanel`
  system user in a systemd sandbox (`NoNewPrivileges`, an empty capability set, `ProtectSystem=strict`
  with write access only to `/var/lib/vaultpanel/panel`, `ProtectHome`, private `/tmp` and devices,
  kernel and namespace protections, `RestrictSUIDSGID`). `.env` and the TLS key are owned by root and
  only readable by the panel's group, so a flaw in the web server cannot change its own settings or
  reach root. The one root step is connecting the panel's own server before the API starts
  (`ExecStartPre=+... connectLocal.js`), which never takes input from the network. The panel's
  files live apart from the agent's private state in `/var/lib/vaultpanel`.
- **HTTPS from the first start** (install.sh): the panel's port serves HTTPS (TLS 1.2+, Node.js
  defaults) with a self-signed ECDSA P-256 certificate made on the server, so passwords, the setup
  token and session cookies (Secure) never cross the network in clear, even before the panel has a
  domain. Plain HTTP is only on `127.0.0.1` (`VAULTPANEL_LOOPBACK_PORT`), for the local agent, the
  panel domain's NGINX and the `vaultpanel` command. HSTS is sent only where the certificate is
  trusted (a panel domain), never on an IP address or the self-signed port, so the certificate can
  always be accepted. `--http` turns this off.
- **Pinned agent installs**: when the panel uses its self-signed certificate, the install and
  upgrade commands carry the SHA-256 pin of its public key. curl downloads with `--pinnedpubkey`; the
  agent installer checks that the certificate the panel sends has that pin, saves it as
  `/etc/vaultpanel-agent/panel-ca.pem` and the agent's services trust it through `NODE_EXTRA_CA_CERTS`
  (normal TLS verification, host name included, with that certificate as the only extra trust
  anchor). A panel with another key is refused before anything is installed.
- **Panel backups**: `vaultpanel backup` (daily by timer) writes the panel's database, `.env` and
  certificate to root-only files (mode 600) with a SHA-256 checksum; restores refuse a file that no
  longer matches and take a safety backup first. They can be encrypted
  (`VAULTPANEL_BACKUP_PASSPHRASE_FILE`, AES-256 with PBKDF2). Treat backups like `.env`: they hold the
  secret key.
- **Updates**: the panel comes as the `vaultpanel` package from VaultPanel's APT repository, which the
  installer trusts only with VaultPanel's signing key (fingerprint checked when it is added); apt
  checks every package against that key, and the install command checks the installer's SHA-256.
  Each update is preceded by a backup, and `vaultpanel rollback` returns to the previous version and
  its database.
- **Passwords**: scrypt (N=2^15, r=8), minimum 12 characters. Failed sign-ins take the same time
  whether or not the account exists.
- **Brute force**: 5 failed attempts lock an account for 15 minutes; sign-in, setup, reset and
  agent registration are rate limited per IP; general API limit of 600 requests/min per IP.
- **Sessions**: random 256-bit tokens, stored hashed, HttpOnly + SameSite=Strict cookies, Secure in
  production, 12 h lifetime. Changing a password, role or active state ends sessions.
- **CSRF**: state-changing cookie requests need an HMAC-derived per-session token header.
- **Two-factor sign-in**: TOTP (RFC 6238), secret encrypted at rest, codes cannot be replayed.
  Turning it on gives 10 one-time recovery codes (stored as HMAC-SHA256 hashes, shown once; using
  one is audited and its count shown). Owners can require it for owners and admins, or for everyone
  (Security, Authentication); an account the policy covers can only set it up or sign out until it
  does, and whoever turns the policy on must use it first. Admins can turn it off for someone who
  lost their phone (that account is signed out everywhere).
- **Session list**: each person sees where they are signed in and can sign out one browser or all
  others; people with `users.manage` see everyone's sessions and can end them (not above their own
  role).
- **First-run setup**: creating the owner needs a setup token printed in the API log.
- **RBAC**: permissions checked in the service layer; denials are audited. Users can only grant roles
  at or below their own; admins cannot manage owners; the last active owner is protected.
- **Audit log**: who, what, target, result, IP, user agent, request id. The database rejects updates
  and deletes. No API can change entries.
- **Agents**: one-time hashed enrollment tokens, Ed25519 request signatures with nonce replay
  protection and a clock window, signed job envelopes, HTTPS required (except for the panel's own agent, which talks to the API
  straight over loopback and never through a proxy), allow-listed operations with
  validated parameters on both sides, no shell execution.
- **Process and service actions**: stopping or killing a process needs its own permission
  (`servers.signal`, owners and admins only) and a confirmation in the UI. The agent re-checks the
  pid still belongs to the same command and refuses kernel threads, itself and core system
  processes; `ssh` can never be stopped. Each server owner can turn signals off in the agent policy.
- **Websites**: each site runs as its own Linux user with a 0750 home folder; PHP runs in a
  per-site PHP-FPM pool as that user with `open_basedir` limited to its folder; NGINX never serves
  hidden files such as `.env` or `.git`. NGINX and PHP-FPM changes are tested before reload and
  rolled back on failure. Domains are unique across the panel.
- **File manager**: requests run on the server as the site's user, never root, confined to its home
  folder with `realpath` checks and `O_NOFOLLOW`; symbolic links are not followed. Separate
  `files.read` and `files.write` permissions. File contents are not kept in job records or the
  audit log.
- **SSL**: Let's Encrypt via Certbot with HTTP challenges; the agent first checks the domains reach
  the server so mistakes do not count against rate limits. TLS 1.2 and 1.3 only.
- **Uptime checks**: the panel's worker requests each website's front page itself (no redirects
  followed, the page is not read). It resolves the domain first and connects only to the address it
  checked, and only when that is a public address or one of the website's own server's addresses:
  a domain pointed at loopback, link-local (cloud metadata) or another private address is reported
  down without being contacted. Private networks other than the site's server follow
  `VAULTPANEL_WEBHOOK_ALLOW_PRIVATE`.
  **DNS providers** (agent 0.38.0, staff only, `dns.manage`): a Cloudflare API token or Namecheap API
  key is stored AES-256-GCM encrypted and never shown again. It reaches a server only inside the
  ISSUE_SSL job, whose parameters drop it when the job ends; the agent keeps a copy for Certbot's
  renewals in `/etc/vaultpanel-agent/acme-dns/vp-<site>.json` (mode 600, folder 700, root only),
  removed when the site is deleted or its certificate is issued another way. Give Cloudflare a token
  limited to Zone > DNS > Edit for the domains it needs. Namecheap's API has no narrower key and
  replaces all of a domain's records at once: the agent writes every record back exactly as it read
  it, with the domain's email setting, and writes nothing when it cannot read them all.
- **Applications**: each app runs as its own Linux user, under a systemd unit with
  `NoNewPrivileges` and `ProtectSystem=full`. Commands from the panel are split into arguments and
  run without a shell. Environment variables are encrypted at rest; reading them is audited and
  needs `applications.manage`. The push-to-deploy URL holds a random token that is shown once and
  stored hashed, and comes with a secret (shown once, stored encrypted): requests must carry an
  HMAC-SHA256 signature of the body made with it (GitHub, Gitea, Forgejo, Bitbucket) or the secret
  as `X-Gitlab-Token` (GitLab), so a leaked URL alone cannot deploy. Rejected requests are audited.
  Webhooks created before secrets existed work on their URL alone until a new URL is created. The
  endpoint has its own rate limit, deploys only pushes to the app's branch, and is audited as the
  webhook. Websites deployed from Git use the same webhooks.
- **Databases**: generated 24-character passwords, encrypted at rest and removed from job records
  when a job finishes; showing one is audited and needs `databases.manage`. Users are local only
  (`localhost` and `127.0.0.1`). SQL goes to the client on stdin; system databases and users are
  refused by both the panel and the agent.
- **Database interface**: browsing and SQL need `databases.manage` and run as an account that can
  reach only that one database (read-only unless "Allow changes" is ticked), never as root. The
  `mysql` client runs as `nobody` and in `--sandbox` mode, so `\!`, `source` and `tee` cannot reach
  the server; statements stop after 30 seconds and results after 1,000 rows. The SQL text is dropped
  from the job record and results are cleared after an hour; SQL run with changes allowed is in the
  audit log.
- **phpMyAdmin**: optional, set up per server by owners and admins (`servers.manage`). It is the
  distribution's package, so it gets security updates with the system. Root and empty passwords
  cannot sign in; people use a database user, which reaches only its own databases. Its setup
  folders are blocked and PHP requests are rate-limited. Over plain HTTP passwords are not
  encrypted: put the panel on a domain with a certificate to serve phpMyAdmin over HTTPS.
  **One-click sign-in** (`databases.manage`, customers on their own databases): the panel makes
  a random 256-bit token, sends only its SHA-256 to the agent and the token only to the browser
  that asked. The agent leaves a ticket in `/run/vaultpanel-phpmyadmin` (tmpfs; folder mode 730
  root:www-data, so PHP can open a ticket whose name it knows but cannot list them; ticket mode
  640) holding the database's own full-access account (`vp-sql-…-rw`, never root).
  `vaultpanel-signon.php` claims the ticket with an atomic rename, deletes it, and refuses it after
  two minutes, so each link works once. phpMyAdmin's Log out also ends the sign-in session and
  returns to the normal login form. Each sign-in is in the audit log as `database.phpmyadmin`.
- **Backups**: kept on the server they were made on, owned by root (files mode 600, folders 700).
  Archives are made and unpacked by `tar` as the site's or app's own user. Each backup's SHA-256 is
  recorded, and a restore or download refuses a file that no longer matches. A restore unpacks into
  a staging folder before replacing anything and, unless turned off, first takes a safety backup of
  the current state; restoring needs `backups.manage` and typing the name. Downloads are copied to
  the panel's data folder (mode 600), served only to users with `backups.manage`, audited, and
  deleted after 6 hours.
- **Cron jobs**: the crontab line holds only the checked schedule and the job's id; the commands
  are kept in a root-only file and run without a shell (no pipes, redirects or `$(…)`), as the
  website's or app's own user, never root, with a timeout and no overlapping runs.
- **Webhooks**: the URL and signing secret are encrypted at rest; the secret is shown once. Every
  delivery is signed with HMAC-SHA256 over the timestamp and body. Before each attempt the host is
  resolved and the request is sent to the checked address, so DNS cannot be switched after the
  check: loopback, link-local (cloud metadata), multicast and reserved addresses are always refused,
  and private networks (10.x, 172.16-31.x, 192.168.x, 100.64.x, fc00::/7) unless
  `VAULTPANEL_WEBHOOK_ALLOW_PRIVATE=true`. It is off by default, so a webhook cannot be used to reach
  services inside your network; panels installed before this default changed keep it on (install.sh
  writes `true` for them). Redirects are not followed.
- **Server logs** are read live through the agent with a fixed set of sources and a plain-text
  search; nothing is stored on the panel. Reading them needs `servers.logs`.
- **Server firewall** (UFW, through the agent): turn it on and off, set the default for incoming
  connections, add and delete allow, limit, deny and reject rules by port, protocol and source.
  Lockout protection is enforced by the agent, which knows the server: before the firewall starts it
  adds allow rules for the SSH ports (read from `sshd -T`) and, on the panel's own server, the port
  people reach the panel on (and 80/443 when NGINX is installed); it refuses deny or reject rules
  from everyone on those ports, and deleting the last rule that keeps one open. The panel refuses a
  deny or reject rule that would block the address of the person adding it. Rules added outside
  VaultPanel are listed but not changed.
  From agent 0.34.0 there are **outgoing rules** too (allow, deny or reject connections the server
  makes, by port, protocol and destination) and a default for outgoing connections. Before the
  outgoing default becomes deny or reject, the agent adds allow rules for what the server needs:
  the panel's address and port (so the agent keeps talking to the panel), DNS (53), web (80, 443,
  for updates, Git and SSL), time (123/udp) and, when Postfix is installed, mail (25, 465, 587). It
  refuses an outgoing deny or reject that covers the panel, and deleting the last outgoing rule that
  keeps the panel reachable while outgoing is not allowed.
- **SSH**: root sign-in (allowed, keys only, off), password sign-in, and sign-in attempts, written to
  `/etc/ssh/sshd_config.d/00-vaultpanel.conf`. Each change is tested with `sshd -t`, checked with
  `sshd -T` (a setting overridden elsewhere is reported), then SSH reloads; the previous file is put
  back on any failure. The agent refuses a change, or removing a key, that would leave no
  administrator account (root, or a member of sudo/admin/wheel) able to sign in. Root's
  `authorized_keys` can be listed, added to and removed from, and from agent 0.34.0 so can those of
  every account people can sign in to (a login shell and a uid from 1000). Another account's keys
  are written by a small helper that first switches to that account's own user, so a `.ssh` folder
  or key file replaced by a symbolic link cannot redirect the write; a symlinked
  `authorized_keys` is refused.
- **SSH port** (agent 0.34.0): SSH can move to another port, or listen on two while moving. The
  agent refuses the panel's port, 80 and 443, and a port another program listens on; when the
  firewall is on it opens the new port first; it writes the `Port` lines, tests with `sshd -t` and
  `sshd -T`, restarts SSH (`ssh.socket` too on systems with socket activation) and only keeps the
  change once SSH answers on every port, otherwise the old file comes back and SSH restarts.
  Fail2ban's SSH jail follows the new ports, and a port SSH stops using loses the firewall rule
  VaultPanel added for it. Open sessions stay connected.
- **Brute-force protection**: Fail2ban's SSH jail (attempts, window, block time, addresses never
  blocked; this server is always on that list), checked with `fail2ban-client --test` and rolled
  back if the jail does not start. Blocked addresses can be unblocked. Failed SSH sign-ins of the
  last 24 hours are summarized from the journal, and an address can be blocked in the firewall in
  one click.
- **Panel access by address** (Security > Authentication): when it is on, the panel only accepts
  people from the listed addresses and networks (IPv4 and IPv6, up to 50); everyone else gets a
  page saying their address is not accepted, and signing in and the browser terminal are refused
  too. With "Staff only", hosting customers still sign in from anywhere. Server agents,
  push-to-deploy hooks, billing systems, plugins and the panel's own server (loopback) are never
  blocked. The panel refuses to save a list that leaves out the address of whoever saves it. Behind
  a reverse proxy, set `VAULTPANEL_TRUST_PROXY` so the panel sees people's real addresses. Locked
  out after your address changed: set `VAULTPANEL_PANEL_ACCESS=off` in `.env` and restart the
  backend.
- **Agent without root** (0.36.0): the agent that talks to the panel runs as the `vaultpanel-agent`
  user with no capabilities; a separate root helper on a local socket runs only jobs and terminal
  sessions it has checked against the panel's signature itself, so a flaw in the agent's network
  side does not give root. If the move does not work the agent keeps running as root and the
  security checks say why. See [agent.md](agent.md#running-as-its-own-user-0360).
- **Security updates**: automatic daily security updates (`unattended-upgrades`) on or off, the
  number waiting (from `apt-get -s upgrade`), whether a restart is needed, and installing them now.
- **Security checks**: every server reports a short security summary with its heartbeat; the
  Security overview scores firewall, root sign-in, SSH passwords, Fail2ban, automatic updates and
  waiting updates for each server.
- **App isolation**: app units also get `ProtectHome=true` (apps cannot read other users' home
  folders or /root), `ProtectKernelTunables`, `ProtectKernelModules`, `ProtectControlGroups`,
  `RestrictSUIDSGID` and `LockPersonality`, plus optional CPU (`CPUQuota`) and memory (`MemoryMax`)
  limits per app.
- **Permissions**: `security.read` (see security state) and `security.manage` (change it), owners
  and admins only by default. Every change is a job and an audit log entry (`security.*`).
- **Bulk actions** (phase 7): running one operation on several servers needs `servers.bulk` (owners
  and admins) on top of the operation's own permission. Each server's part is an ordinary signed job,
  created as the person who started the action; later servers of a one-at-a-time action re-check that
  person's current access, so deactivating someone stops the rest. Only a fixed list of operations
  can be run this way.
- **Agent updates from the panel**: the update job is signed and carries the package's SHA-256; the
  agent rejects any other package and checks the new code starts before replacing the old one.
- **Hosting customers** (phase 8): the `customer` role has only website, file, app, database,
  backup, cron and job permissions, and they only ever apply inside the customer's own account:
  every list is filtered to it, every id in a URL is checked against it (others answer 404, so ids
  of other accounts cannot be probed), and a top-level allowlist refuses every other area (servers,
  users, security, logs, bulk actions...). Customers cannot start agent jobs directly, cannot point a
  reverse proxy at a port other than one of their own apps, cannot link or grant databases outside
  their account, and get the plan's CPU and memory caps on every app. Quota checks and creates run
  under a per-account lock so parallel requests cannot pass a limit. A suspended or removed account
  is signed out and cannot sign in; a user with the customer role but no account gets no permissions
  at all. The customer role cannot be given from the Users page.
- **Billing API keys**: `vpk_` keys are shown once and only their SHA-256 is stored, like session
  tokens. A key can only read and manage customers (never servers or anything else), is limited to
  120 requests a minute, records where it was last used, and is revoked in one click. Managing keys
  needs `billing.manage` (owners and admins). Sign-in links a key asks for ("Log in to VaultPanel")
  carry a random token in the URL fragment (never sent to servers or logs), stored as its SHA-256,
  that works once within two minutes for an active, unsuspended account. They skip the second
  factor, since the key can already set the account's password; invite and reset pages refuse them.
- **AI assistant** (phase 9): it has no shell and no permissions of its own. Each tool call runs
  through the panel's services as the person who asked, so it can only read what they could read in
  the panel, and their access is checked again on every question and every round (a deactivated user
  or a removed permission stops it). Server reads are fixed, allowlisted agent operations (logs,
  service state, processes, listening ports). Changes are only ever *proposed*: a fixed list of
  actions with strictly validated parameters, run only when a person approves them, with that
  person's own permissions, and audited (`assistant.action_approve`). Proposals expire after 60
  minutes. Environment variable values, database passwords and keys are never given to it (only
  names). What it reads (status, log lines, process lists) and the questions are sent to the
  provider the owner configured; use a self-hosted model through the OpenAI-compatible option if
  that data must stay on your servers. Log text is treated as data in the system prompt, and
  whatever a log line says, the worst it can do is make the model propose an action a person still
  has to approve. The API key is AES-256-GCM encrypted (key derived from `VAULTPANEL_SECRET_KEY`),
  never returned by the API, and changes to it are audited as "changed" or "removed", never with
  its value. Only `settings.manage` (owners and admins) can set the provider address, so nobody else
  can point the panel at another server. 60 questions an hour per person.
- **Containers** (phase 10): the agent uses Docker's API directly (no shell, no `docker` command)
  and creates every container unprivileged, with no added capabilities or devices,
  `no-new-privileges`, capped logs and only named volumes, so a container cannot mount the server's
  folders or the Docker socket. Ports are bound to `127.0.0.1` unless someone chooses a public port;
  the panel warns that **Docker opens public ports itself, bypassing UFW**. Host ports already used by
  SSH, the panel, apps, other containers, VaultPanel's database or Redis (and 80/443 with NGINX) are
  refused. The containers holding VaultPanel's own database and Redis cannot be stopped, restarted or
  removed from the panel. Environment variables are AES-256-GCM encrypted, only their names are shown
  without `containers.manage`, and every read of the values is audited. Deploying, changing and
  removing need `containers.manage` (owners and admins); developers can start, stop, restart and read
  logs. Images come from public registries only; an image runs whatever its author put in it, so use
  images you trust.
- **Plugins** (phase 10): a plugin is a separate program; it never runs in the panel's process,
  adds no agent operations and runs no commands. It acts only through the API with its own token
  (`vpp_`, only the SHA-256 kept), whose permissions are the scopes an owner or admin approved
  (never `full`, so never users, roles, settings or plugins), capped at the approver's own. Approval
  is all or nothing and is asked again when an update changes the manifest. Installing, updating
  and new credentials need a signed-in person (refused for API tokens and plugins). Events and page
  links are signed with a per-plugin secret (AES-256-GCM at rest), and an event is only sent when the
  plugin's permissions could read the same thing. Manifests and events use the webhook address
  rules; loopback only with `VAULTPANEL_PLUGIN_ALLOW_LOCAL`. A plugin's page is shown, in a sandboxed
  frame, only to staff who hold every permission the plugin has, so it cannot be used to do more
  than the viewer could; a page on the panel's own origin loses same-origin access. Turning a
  plugin off refuses its token at once. Everything it does is audited as `plugin:<id>`. Plugin
  directories only suggest plugins: installing one from a directory reads and approves the
  plugin's own manifest, the review warns when that asks for more than the directory listed, and an
  update always reads the installed plugin's own manifest URL, never one from a directory.
  Directories are fetched with the same address rules (up to 1 MB) and added only by a signed-in
  owner or admin.
- **DNS zones** (agent 0.15.0): BIND is set up as an authoritative-only server: recursion off
  (it never answers for other domains, so it cannot be used for amplification against third
  parties), zone transfers refused, the version hidden and responses rate-limited. Zones are written
  only from the panel's validated records (fixed types, hostname and text patterns, no `$INCLUDE` or
  other directives) and checked with `named-checkzone` before they replace the live file. Managing
  zones needs `dns.manage` (owners and admins); customers have no access.
- **Email hosting** (agent 0.16.0): mailboxes are not Linux accounts, and Dovecot's sign-in with
  Linux accounts is turned off (and only the vmail account's mail can be opened). Passwords are hashed
  with SHA512-CRYPT by the panel; neither the panel, the job queue nor the agent keeps them. IMAP,
  POP3 and sign-in for sending need TLS (1.2 or newer); ports 143 and 110 are closed. Sending through
  the server needs a signed-in mailbox, which may send only as its own address; a mailbox that is off
  cannot sign in or send. Only mail for the server's own domains is accepted from the internet (no
  open relay). DKIM keys are made on the server and only their public half leaves it.
- **HTTP**: Helmet security headers, CORS closed by default, 4 MB body limit (file uploads up to
  1 MB, base64 encoded), input validation with
  Zod on every route, parameterized queries through Knex.
- **Secrets**: all from environment variables; nothing secret has a default.

## Not yet (planned)

- Spam and virus filtering of incoming email, and limits on how much mail a mailbox may send.
- Shared rate-limit store for multiple API instances.
- Per-site resource limits for PHP sites, disk quotas and chroot/jail isolation.
- Separate DB users for migrations and runtime; operations with less than root (the agent's root
  helper runs what the panel signed).
- Limiting staff to some servers; email when a hosting account nears its limits.
- Renewing the panel's self-signed certificate without updating each agent (`vaultpanel https renew`
  keeps the key, but agents keep the old certificate until their upgrade command runs).
- Encrypting backups before they leave the server. (Copies to S3-compatible storage are signed and
  checksummed, copies over SFTP use a per-destination SSH key and a host key pinned on the first
  check, and the secret or private key is stored encrypted, but the backups themselves are not
  encrypted: use a private bucket, or a backup server only you can sign in to.)

## Reporting

Errors returned to clients never include stack traces; the request id links them to the server log.

To report a vulnerability, see [SECURITY.md](../SECURITY.md).
