# Installing VaultPanel

The installer sets up VaultPanel on a fresh server and runs it as a service that starts at boot.
As root, first update the system and make sure `curl` and `sudo` are there:

```sh
apt update && apt -y upgrade && apt -y install curl wget sudo
```

Then download the installer, check it and run it. The checksum changes with each release: copy the
command with the current one from [github.com/VaultPanel/packages](https://github.com/VaultPanel/packages)
(or [installer.vaultpanel.net](https://installer.vaultpanel.net)):

```sh
curl -sS https://installer.vaultpanel.net/v2/install.sh -o install.sh; \
echo "<checksum from github.com/VaultPanel/packages> install.sh" | \
sha256sum -c && sudo DB_ENGINE=MARIADB_12.3 bash install.sh
```

`sha256sum -c` runs the installer only when the downloaded file is exactly the published one.
`DB_ENGINE` chooses the database server for your websites and apps (see
[Database for websites and apps](#database-for-websites-and-apps)).

When it finishes it prints the panel's address and a setup token:

```
VaultPanel is installed.

  Open:          https://203.0.113.10:8090/setup
  Setup token:   15d59a807f148df64628dd4ca0abd16c
                 (creates the owner account; it stops working once you have)
  Database:      MariaDB 12.3 for websites and apps
```

Open the address, paste the token and create the owner account. The server the panel runs on is
already connected and shows as **This server**.

The panel uses **HTTPS from the start**, with a certificate the installer made for this server
(self-signed). Your browser warns about it once: check that the SHA-256 fingerprint it shows matches
the one the installer printed, then continue. For a certificate browsers trust, give the panel a
domain (see [Put the panel on a domain](#put-the-panel-on-a-domain)).

**Supported:** Ubuntu 22.04, 24.04 or 26.04, Debian 12 or 13, run as root, with systemd. 2 GB of
memory or more is recommended. A fresh server is best: the installer refuses to start if port 8090,
8091 (loopback), 3307 or 6379 is already taken by something other than VaultPanel, or port 3306 when
it installs MariaDB.

## What it does

1. Installs `curl`, `openssl`, **Node.js 22** from NodeSource (system-wide, at `/usr/bin/node`;
   a Node.js installed with nvm under `/root` is never used) and **Docker** with Docker Compose (from
   get.docker.com; an existing Docker, the snap one included, is reused).
2. Installs the **MariaDB** chosen with `DB_ENGINE` for websites and apps (port 3306), unless the
   server already has a database server (see below).
3. Adds **VaultPanel's package repository** (`installer.vaultpanel.net/apt`), after checking that its
   signing key has VaultPanel's fingerprint, `79B3 4D79 D2A7 D0DE 54A3 D906 B62A 47C2 ED27 75A6`
   (`/etc/apt/sources.list.d/vaultpanel.list`, key in `/etc/apt/keyrings/vaultpanel.asc`), and installs
   the **`vaultpanel` package**: the panel, ready to run, in `/opt/vaultpanel`. Nothing is downloaded
   from GitHub or built on the server. The package then sets the panel up (steps 4 to 10), on a new
   install and after every upgrade.
4. Creates the `vaultpanel` system user the panel runs as, and writes `/opt/vaultpanel/.env` (root
   writes it, the `vaultpanel` group may only read it) with new random secrets: the encryption key,
   the setup token, and the passwords of the panel's database and Redis.
5. Makes a self-signed certificate for the panel's port in `/etc/vaultpanel/tls/` (valid 10 years;
   the key readable by the panel, not changeable by it).
6. Starts the panel's own MariaDB (127.0.0.1:3307) and Redis (127.0.0.1:6379, with a password) in
   Docker from `docker/compose.prod.yml`. They come back after a reboot and stay separate from the
   MariaDB and Redis the panel installs for websites and apps.
7. Updates the database to the installed version.
8. Installs two systemd services that start at boot: `vaultpanel` (the web interface and API, HTTPS on
   port 8090, plain HTTP on 127.0.0.1:8091 for this server's own use) and `vaultpanel-worker`
   (background jobs). Both run as the unprivileged `vaultpanel` user in a systemd sandbox: no
   capabilities, a read-only system, and write access only to the panel's folder
   (`/var/lib/vaultpanel/panel`). Only one step runs as root: before the panel starts, it connects
   this server to itself by installing or updating the agent (`vaultpanel-agent`).
9. Schedules a daily backup of the panel itself (`vaultpanel-backup.timer`, see
   [Backing up the panel](#backing-up-the-panel)).
10. Adds the `vaultpanel` command and a login banner (below), and opens the port in `ufw` when the
   firewall is on.

Running the installer again is safe: it keeps `.env` and all data, and installs a newer package when
there is one.

### Database for websites and apps

`DB_ENGINE` chooses the database server the installer sets up for your websites, apps and the app
installer (WordPress, Joomla, Drupal, Laravel), on port 3306. The panel's own database is separate:
the MariaDB in Docker on port 3307.

| System           | `DB_ENGINE`                                       |
| ---------------- | ------------------------------------------------- |
| Ubuntu 26.04 LTS | `MARIADB_12.3`, `MARIADB_11.8`                    |
| Ubuntu 24.04 LTS | `MARIADB_12.3`, `MARIADB_11.4`, `MARIADB_10.11`   |
| Ubuntu 22.04 LTS | `MARIADB_11.4`, `MARIADB_10.11`, `MARIADB_10.6`   |
| Debian 13        | `MARIADB_12.3`, `MARIADB_11.8`                    |
| Debian 12        | `MARIADB_12.3`, `MARIADB_11.4`, `MARIADB_10.11`   |

- Without `DB_ENGINE`, a new install gets the newest MariaDB for its system (the first in its row).
  `DB_ENGINE=NONE` installs none; you can install MariaDB later from the server's Software card.
- When the system's own packages have the chosen version, they are used. Otherwise the installer
  adds MariaDB's repository (`/etc/apt/sources.list.d/vaultpanel-mariadb.list`, from deb.mariadb.org)
  after checking that its signing key has MariaDB's fingerprint,
  `177F 4010 FE56 CA33 3630 0305 F165 6F24 C74C D1D8`. Security updates then come with `apt upgrade`.
- A server that already has MariaDB or MySQL keeps it, and updating VaultPanel never changes the
  database server.
- MySQL 8.4 and 8.0 come in a later version; the installer refuses `MYSQL_8.4` and `MYSQL_8.0` until
  then.

### Options

Pass options after `bash install.sh` (or after `bash -s --` when the installer is piped from curl):

```sh
sudo DB_ENGINE=MARIADB_12.3 bash install.sh --port 9000
```

| Option               | Default                     |                                                               |
| -------------------- | --------------------------- | ------------------------------------------------------------- |
| `--db-engine <e>`    | newest MariaDB              | Database server for websites and apps, or `NONE` (above)      |
| `--port <n>`         | `8090`                      | Port the panel listens on                                     |
| `--url <address>`    | `http://<public IP>:<port>` | Address people open the panel at                              |
| `--version <vX.Y.Z>` | the newest                  | Version of the `vaultpanel` package to install                |
| `--http`             |                             | Plain HTTP instead of HTTPS (not recommended)                 |
| `--https`            |                             | Turn on HTTPS for a panel installed before it was the default |

`--port`, `--url` and `--http` choose how a **new** panel is set up; afterwards use `vaultpanel url`
and `vaultpanel https`. Each option also works as an environment variable (`DB_ENGINE`,
`VAULTPANEL_PORT`, `VAULTPANEL_URL`, `VAULTPANEL_HTTPS=on|off`, `VAULTPANEL_VERSION`), so a downloaded
copy can be run as `sudo VAULTPANEL_PORT=9000 bash install.sh`.

### Checking the installer before running it

Each release publishes its `install.sh` at installer.vaultpanel.net, with its SHA-256 in the
[VaultPanel/packages](https://github.com/VaultPanel/packages) README and in
`https://installer.vaultpanel.net/v2/install.sh.sha256`; the install command checks it. The installer
then trusts VaultPanel's package repository only with the signing key fingerprint above, and apt
checks every package against that key.

### From a copy of the repository

To try code that is not released yet on a test server, clone this (private) repository with your own
GitHub login and run the installer from the copy. It installs that copy's branch into
`/opt/vaultpanel` and builds it on the server, and later updates come from the same repository. These
options only apply then:

```sh
git clone https://github.com/VaultPanel/VaultPanel.git
sudo bash VaultPanel/install.sh
```

| Option            | Default           |                                                                    |
| ----------------- | ----------------- | ------------------------------------------------------------------ |
| `--dir <path>`    | `/opt/vaultpanel` | Where VaultPanel is installed                                      |
| `--repo <url>`    | this repository   | Git repository to install from                                     |
| `--branch <name>` |                   | Install a branch instead of a release tag, e.g. `main`             |

## The `vaultpanel` command

After the install, type `vaultpanel` on the server:

```
 __     __          _ _   ____                  _
 \ \   / /_ _ _   _| | |_|  _ \ __ _ _ __   ___| |
  \ \ / / _` | | | | | __| |_) / _` | '_ \ / _ \ |
   \ V / (_| | |_| | | |_|  __/ (_| | | | |  __/ |
    \_/ \__,_|\__,_|_|\__|_|   \__,_|_| |_|\___|_|
  Address:   https://203.0.113.10:8090
  Panel:     running    Worker: running    Agent: running
  Version:   0.2.0 (agent 0.40.0)
```

| Command                                            | What it does                                                                                          |
| -------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `vaultpanel`                                       | Address, status and version (and the setup token while no owner exists)                               |
| `vaultpanel status`                                | The panel, worker, agent, database and Redis                                                          |
| `vaultpanel logs [panel\|worker\|agent] [-f]`      | Recent log lines; `-f` keeps following                                                                |
| `vaultpanel restart`, `start`, `stop`              | Control the panel and worker                                                                          |
| `vaultpanel update [--version <vX.Y.Z>] [--force]` | Back up, then install the newest package (or the one given), update the database and restart          |
| `vaultpanel rollback`                              | Go back to the version installed before the last update, with its database                            |
| `vaultpanel backup [--dir <folder>] [--keep <n>]`  | Back up the panel's database, settings and certificate now                                            |
| `vaultpanel restore <file>`                        | Put a backup back, on this server or a new one                                                        |
| `vaultpanel https [status\|on\|off\|renew]`        | The panel's own HTTPS certificate (see below)                                                         |
| `vaultpanel url [<address>]`                       | Show or change the panel's address (see below)                                                        |
| `vaultpanel setup-token`                           | The token for creating the owner account                                                              |
| `vaultpanel version`                               | Installed version                                                                                     |
| `vaultpanel help`                                  | All of the above, plus the panel commands                                                             |

Every other command is the [VaultPanel CLI](cli.md), which works through the panel's API with an API
token: `vaultpanel login`, `vaultpanel servers list`, `vaultpanel apps deploy ...`.

When someone logs in over SSH, the login message shows the VaultPanel banner and its links (website,
documentation, best practices, the panel's address and the `vaultpanel` command), then the "Last login"
line, and nothing else: the agent hides the system's own welcome text, news and update notices by
default, and the Terminal tab shows the same banner. To get the system's message back, open the server's **Security** tab and click
**Show the system's message** on the **Login message** card.

## HTTPS on the panel's own port

A new install serves the panel over HTTPS on its port with a self-signed certificate, so passwords,
the setup token and session cookies never cross the network in clear (the same approach as Cockpit,
Webmin or Proxmox). Browsers warn about the certificate once; the installer prints its SHA-256
fingerprint so you can check it is yours. `sudo vaultpanel https` shows it again.

- **Adding servers works without a domain.** The **Add server** command carries the certificate's
  public key pin (`curl --pinnedpubkey ... -k` and `--panel-pin`). The agent installer checks it,
  saves the certificate as `/etc/vaultpanel-agent/panel-ca.pem`, and the agent trusts exactly that
  certificate. A different certificate (someone in the middle) is refused.
- **Plain HTTP stays on loopback only**, on port 8091 (`VAULTPANEL_LOOPBACK_PORT`): the agent on this
  server, the panel domain's NGINX and the `vaultpanel` command use it. It never leaves the machine.
- **No HSTS on the IP address**, so people can always accept the self-signed certificate. A panel
  domain with a trusted certificate gets HSTS.

| Command                       | What it does                                                                                                                                                                                                                          |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `vaultpanel https`            | Whether HTTPS is on, the certificate's names, expiry, fingerprint and agent pin                                                                                                                                                       |
| `sudo vaultpanel https on`    | Turn HTTPS on for a panel installed with plain HTTP (before it was the default). It prints the command to run on each other server, so their agents move to HTTPS                                                                     |
| `sudo vaultpanel https renew` | A new certificate with this server's current names and addresses (for example after the IP changed), with the same key, so the pin stays the same. Run the printed command on each other server so its agent gets the new certificate |
| `sudo vaultpanel https off`   | Back to plain HTTP (not recommended)                                                                                                                                                                                                  |

Turning HTTPS on also moves a panel domain added earlier to the loopback port automatically, so it
keeps working.

## Put the panel on a domain

The panel's own certificate is self-signed. To give it a domain with a certificate browsers trust
(Let's Encrypt):

1. Point a DNS `A` record such as `cp.example.com` at the server, and make sure ports 80 and 443 are
   open.
2. In the panel, open **System > Panel Domain**, type the domain and click **Add domain** (the port is
   already filled in: the panel's loopback port, 8091, or 8090 on a plain-HTTP panel). If NGINX or Certbot are missing, install the web stack from
   **This server**'s page first.
3. Get a certificate under **SSL certificate**: a test one first if you like, then the trusted one.
4. Under **Panel address**, click **Use https://cp.example.com**, so agent install commands, password
   reset links and deploy webhooks use the domain.

Sign in at `https://cp.example.com`. The `https://SERVER_IP:8090` address keeps working, so a DNS or
certificate mistake never locks you out; once the domain works you can close port 8090 to the outside
in the firewall. Agents on other servers must reach the panel over HTTPS once they use the domain.

`vaultpanel url https://cp.example.com` still sets the address from the server instead, and also turns
on HTTPS-only cookies for every address (the plain HTTP address then stops letting you sign in).

## Updating

```sh
sudo vaultpanel update                   # the newest version
sudo vaultpanel update --version v0.3.0  # a given version
```

It installs the newer `vaultpanel` package with apt. Before the package changes version it backs the
panel up (database, settings, certificate; label `pre-update`, the last 3 kept) and notes the version
it had; after, it updates the database and restarts. When there is nothing newer it says so and stops
(`--force` sets the same version up again). `sudo apt upgrade` updates VaultPanel the same way, with
the system's other packages.

If an update goes wrong:

```sh
sudo vaultpanel rollback
```

puts back the database from the backup taken just before the last update, then installs the version
from before it again. Changes made in the panel since that update are lost, so it asks you to type
`rollback` first. The package repository keeps the newest 5 versions.

A panel installed from a copy of the repository updates from that copy instead: `vaultpanel update`
fetches the newest release tag (or the branch it follows, `--branch main`) and builds it, and
`vaultpanel rollback` goes back to the commit it had. Or update the copy and run its installer:

```sh
git -C VaultPanel pull
sudo bash VaultPanel/install.sh
```

## Backing up the panel

Websites, apps and databases have their own backups (**Backups** in the panel). This is the backup
of **VaultPanel itself**: without it, losing the server means losing every account, setting and the
key that decrypts them.

`vaultpanel-backup.timer` makes one every day, and `sudo vaultpanel backup` makes one now. Each backup
is one file in `/var/backups/vaultpanel-panel` (root only, mode 600) with a `.sha256` checksum next to it,
holding:

- the panel's database (a `mariadb-dump`),
- `.env`, including `VAULTPANEL_SECRET_KEY`, which decrypts two-factor secrets, the agent signing key
  and every stored password,
- the HTTPS certificate and key (so agents on other servers keep trusting a restored panel),
- terminal recordings and the panel domain list.

Settings in `/opt/vaultpanel/.env` (then `vaultpanel restart` is not needed; the next backup uses
them):

| Setting                             | Default                         |                                                                                                                                                        |
| ----------------------------------- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `VAULTPANEL_BACKUP_DIR`             | `/var/backups/vaultpanel-panel` | Where backups go                                                                                                                                       |
| `VAULTPANEL_BACKUP_KEEP`            | `14`                            | Daily backups kept                                                                                                                                     |
| `VAULTPANEL_BACKUP_PASSPHRASE_FILE` |                                 | A file holding a passphrase: backups are then encrypted (AES-256, PBKDF2) as `.tar.gz.enc`                                                             |
| `VAULTPANEL_BACKUP_UPLOAD`          |                                 | A command run after each backup with the file as `$1`, to copy it off the server, e.g. `rclone copy "$1" remote:vaultpanel` or `scp "$1" backup@host:` |

**Keep a copy off the server**, somewhere only you can read: a backup on the same disk does not help
when the server is gone. Encrypt it when it goes to someone else's storage.

To restore, on the same server or on a new one installed with `install.sh`:

```sh
sudo vaultpanel restore /var/backups/vaultpanel-panel/vaultpanel-20261020-031500-scheduled.tar.gz
```

It checks the checksum, takes a safety backup of the current panel, then puts back the database,
the settings and secret key, the certificate and the panel's files, updates the database to the
installed version and restarts. The server keeps its own database and Redis passwords, so a backup
from an old server restores onto a new one. If the new server has another address, run
`sudo vaultpanel url <address>` afterwards (and `sudo vaultpanel https renew` so the certificate names
it). A backup from a newer VaultPanel needs that version first: `sudo vaultpanel update --version <it>`.

## Removing

```sh
sudo docker compose -p vaultpanel --env-file /opt/vaultpanel/.env -f /opt/vaultpanel/docker/compose.prod.yml down
sudo apt remove vaultpanel
sudo systemctl disable --now vaultpanel-agent vaultpanel-agent-helper
sudo rm -f /etc/systemd/system/vaultpanel-agent.service /etc/systemd/system/vaultpanel-agent-helper.service \
  /etc/apt/sources.list.d/vaultpanel.list /etc/apt/keyrings/vaultpanel.asc
sudo systemctl daemon-reload
```

Removing the package stops the panel and removes its services, the `vaultpanel` command and the login
banner; the other lines stop the panel's database containers and this server's agent, and remove
VaultPanel's package repository. (A panel installed from a copy of the repository has no package: stop
and remove `vaultpanel`, `vaultpanel-worker` and `vaultpanel-backup.timer` the same way as the agent.)

This keeps the panel's data. To delete it too (the database volume, settings and secrets):
`docker compose ... down -v` in the first line, then `sudo rm -rf /opt/vaultpanel /opt/vaultpanel-agent
/etc/vaultpanel /etc/vaultpanel-agent /var/lib/vaultpanel /var/backups/vaultpanel /var/backups/vaultpanel-panel` (website, app and database
backups, then the panel's own), and `sudo userdel vaultpanel`. Websites, apps and databases the panel created on the server
are left as they are, and so is the MariaDB for websites and apps. To remove that as well (it deletes their
databases): `sudo apt purge mariadb-server mariadb-client`, then
`sudo rm -f /etc/apt/sources.list.d/vaultpanel-mariadb.list /etc/apt/keyrings/vaultpanel-mariadb.asc`.
