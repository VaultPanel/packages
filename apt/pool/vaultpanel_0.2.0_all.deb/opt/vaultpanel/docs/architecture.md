# Architecture

VaultPanel follows a control plane + server agent model. This page describes how
the parts fit together; planned work is in [roadmap.md](roadmap.md).

```text
Browser ── React UI (frontend/)
              │  HTTPS (self-signed on the panel port, or a panel domain), session cookie + CSRF token
              ▼
        Express API (backend/src/server.js, as the vaultpanel user) ─── MariaDB (users, servers, jobs, audit log…)
              │                              └── Redis (agent nonces, BullMQ)
              │  HTTPS, Ed25519-signed requests      ▲
              ▼                                      │
        Agent on each server (agent/)        Worker (backend/src/worker.js)
              │  fixed commands, no shell           maintenance every 15 s
              ▼
        systemd, ps, /proc …
```

## The panel on its server (install.sh)

The API and the worker run as the unprivileged `vaultpanel` user in a systemd sandbox; only
`backend/src/cli/connectLocal.js`, which connects the panel's own server before the API starts, runs
as root. The API serves HTTPS on `VAULTPANEL_PORT` with the certificate in `VAULTPANEL_TLS_CERT`
(install.sh makes a self-signed one) and plain HTTP on `127.0.0.1:VAULTPANEL_LOOPBACK_PORT` for
callers on the same machine: the local agent, the panel domain's NGINX (a reverse-proxy website to
that port) and the `vaultpanel` command. Agent install commands carry the certificate's public key
pin while the panel's address is served by it (`utils/panelTls.js`). The panel's files are in
`/var/lib/vaultpanel/panel`; `/var/lib/vaultpanel` itself belongs to the agent. `vaultpanel backup`
(daily by timer) dumps the database with the settings and certificate; `vaultpanel update` installs
release tags, backing up first, and `vaultpanel rollback` reverses the last update.

## Repository layout

| Path | What it is |
| --- | --- |
| `shared/` | Permissions, built-in roles and the operation catalog, used by backend and frontend |
| `backend/` | Express API, service layer, worker, migrations runner |
| `frontend/` | React + Vite + Tailwind UI |
| `agent/` | Server agent, Node.js built-ins only (no dependencies) |
| `database/migrations/` | Knex migrations |
| `scripts/install-agent.sh` | Installs and registers the agent on a server |
| `docker/compose.yml` | MariaDB and Redis for development |
| `docs/` | This documentation |

Tests live next to each package (`backend/test`, `agent/test`, `shared/test`,
`frontend/src/**/*.test.js`) rather than in a top-level `tests/` folder, so each
package runs its own suite.

## Backend layers

Requests flow `routes → middleware (validation, auth, CSRF) → controllers → services → database`.

- **Controllers** are thin: they read validated input, call one service and send the response.
- **Services** (`backend/src/services`) hold all business rules, authorization and audit logging.
  They take an *actor* (a signed-in user, an agent, or the system) instead of an HTTP request, so the
  same code can serve a CLI, automation or a future AI assistant. `createServices()` wires them.
- **Authorization** happens in one place, `services/authorization.js`, which checks a permission and
  records denials in the audit log.
- Every response uses one envelope: `{ success, data, message, requestId }` or
  `{ success: false, error: { code, message, details }, requestId }`.

## Server agent and jobs

1. An admin adds a server. The panel creates a one-time enrollment token (stored hashed, expires after
   60 minutes by default) and an install command.
2. The install script downloads the agent from the panel, and `vaultpanel-agent register` generates an
   Ed25519 key pair, sends the public key with the token, and receives its agent id plus the panel's
   job-signing public key, which it pins.
3. Every later agent request is signed (method, path, timestamp, nonce, body hash). The panel checks
   the signature, a ±5 minute clock window and that the nonce was not used before.
4. The agent sends a heartbeat every 15 seconds (system info, metrics, service states) and long-polls
   `GET /api/v1/agent/jobs/next` for work. Agents connect out; servers need no inbound port.
5. A user queues an operation (`POST /api/v1/servers/:id/jobs`). The panel checks the operation is in
   the catalog, the user's permission, the parameters, and refuses duplicates of an active job.
6. When the agent claims the job, the panel sends a signed envelope. The agent verifies the signature,
   the server id and expiry, re-validates the parameters against its own allow list, runs fixed
   commands without a shell, streams logs and reports the result.

There is no endpoint that runs arbitrary commands, on the panel or the agent.

Changes to websites, apps and databases are jobs tied to their record (`jobs.resource_type/id`). The
record keeps its live settings and a `pending_action` while the job runs; when the job finishes, the
service that owns the record applies the result (or the error) before the agent's next poll is
answered, so a follow-up job (create app, then its website, then the first deploy) always sees the
result of the one before. Passwords, environment values and written file contents in job parameters are replaced with
`{ redacted: true, length }` when the job ends.

Jobs are rows in the `jobs` table: that is the durable record users see and the queue agents pull from.
BullMQ runs the panel's own background work in `worker.js`: failing jobs no agent picked up, retrying
jobs an agent claimed but never started, timing out stuck jobs, marking silent servers offline and
evaluating alert rules, rolling raw metrics up into hourly rows, and pruning old metrics, alert
history and sessions.

Alerts work like Prometheus rules: when a rule's condition becomes true an event is `pending`; if it
stays true for the rule's duration it becomes `firing` (audited as `alert.fire`); when the condition
clears it is `resolved`. A pending event whose condition clears is deleted. When a server has no
fresh data, metric and service rules are left as they are rather than resolved.

Websites follow the same job model. The panel saves the request (a new site, or a change in
`pending_spec`), queues one agent operation that does the whole change (user, folders, PHP-FPM,
NGINX, health check), and applies the result to the website row when the job finishes
(`jobs.onFinished`). Job results the panel waits on, such as file listings and log reads, are routine
jobs: they are hidden from job lists by default, and file contents are redacted from stored jobs.

Phase 5 adds three more kinds of background work, all in the maintenance pass that runs every 15
seconds: taking backups whose schedule is due (then deleting the oldest beyond the schedule's
`keepCount`), sending webhook deliveries (with retries), and deleting expired download copies.
Backups and restores are agent jobs tied to their `backups` row. Cron jobs are installed on the
server by a job, but run by the server's own cron daemon, so they keep running while the panel is
down; the agent reports each run with the next request it makes. Events for webhooks come from
three places: the backup and cron services, the audit log (alerts and servers going offline or
online) and finished deployment jobs. Each event becomes one `webhook_deliveries` row per webhook
that wants it, so a delivery survives a restart.

Phase 7 adds server groups and bulk actions (`services/serverGroupService.js`,
`services/bulkActionService.js`). A bulk action is one row in `bulk_actions` and one row per server
in `bulk_action_targets`; each server's part is an ordinary agent job linked back with
`jobs.resource_type = 'bulk_action'`. Progress moves forward from three places: the job finish
handler, the agent heartbeat (a server back after a reboot or with a new agent version) and the
maintenance pass (time limits, and anything missed). Each step locks the action row, so a rolling
action never starts two servers at once.

Phase 9 adds the AI assistant (`services/assistantService.js`, `services/assistant/`). Asking a
question saves it and puts the conversation on the `vaultpanel-assistant` BullMQ queue; the worker
answers it, so the worker must be running. The answer is a loop of at most 12 rounds: the provider
(Claude through the Anthropic SDK, or any OpenAI-compatible `/chat/completions` service) is given a
fixed system prompt and a fixed set of tools, and each tool call runs through the normal services
with an actor for the person who asked (shown in the audit log as `email (assistant)`). Reading a
log, a service's state, processes or listening ports queues an ordinary routine agent job and waits
up to a minute for it. The `propose_action` tool only stores a row in `assistant_actions`; it runs
when a person approves it, through the same service call as the matching button, as that person.
Every model reply, tool call and result is stored in order, and earlier turns are sent back exactly
as stored, so a provider can reuse its reasoning between rounds. The maintenance pass fails answers
stuck for more than 10 minutes and expires proposals after 60.

## Frontend

React Router pages in `frontend/src/pages`, a small design system in `frontend/src/components/ui`
(buttons, inputs, tables, cards, modals, drawers, tabs, badges, alerts, toasts, skeletons, empty and
error states, confirmation dialogs, log viewer, charts), state in React contexts (`stores/`) and
data loading through `hooks/useApi.js`.

The visual design ("Harbor") is defined by semantic tokens in `theme/index.css` with light and dark
values: cool gray neutrals, a blue `accent` for primary buttons, links, focus and active states,
`nav-*` tokens for the always-dark navy sidebar, tinted status colors, and an always-dark `console`
surface for logs and commands. Type is IBM Plex Sans with JetBrains Mono for identifiers and numbers,
bundled with the app (no external font requests). Cards are white with thin borders and a 12px
radius; buttons and inputs use an 8px radius; status badges are pills.

The shell (`layouts/AppLayout.jsx`) is a fixed navy sidebar and a white header. The sidebar lists
each navigation group that has pages this user can open, then a collapsed "Coming later" list of
planned pages tagged with their roadmap phase (not clickable), and a "Next up" note for the nearest
phase. The header holds the Ctrl/Cmd K command menu (`components/CommandPalette.jsx`), the
firing-alerts and running-jobs indicators, the theme switch and the account menu. On small screens
the sidebar opens as a drawer. Groups live in `layouts/navigation.js`; it lists the whole product,
and modules from later phases are shown as unavailable with their phase number and are not clickable.
