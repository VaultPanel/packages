// Phase 9: the AI assistant. Conversations belong to the person who started
// them. Messages keep the exchange in a provider-neutral form (text and tool
// calls) plus, for Claude, the exact content blocks the API returned, so a
// conversation can be replayed to the same model unchanged. Actions are
// changes the assistant proposed; nothing runs until the person approves one.
// The provider settings live in the settings table (the API key sealed).

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.createTable('assistant_conversations', (t) => {
    t.uuid('id').primary();
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    t.string('title', 120).notNullable().defaultTo('New conversation');
    // idle | thinking | failed
    t.string('status', 16).notNullable().defaultTo('idle');
    // What the assistant is doing right now, shown while it thinks.
    t.string('activity', 200);
    t.string('error_code', 64);
    t.string('error_message', 1000);
    t.datetime('thinking_since', { precision: 3 });
    ts(t, knex);
    t.index(['user_id', 'updated_at']);
    t.index(['status']);
  });

  await knex.schema.createTable('assistant_messages', (t) => {
    t.bigIncrements('id').primary();
    t.uuid('conversation_id').notNullable().references('assistant_conversations.id').onDelete('CASCADE');
    // user | assistant | tool
    t.string('role', 16).notNullable();
    t.text('content', 'mediumtext');
    // assistant: [{ id, name, input, label }]; tool: [{ id, name, content, isError }]
    t.json('tool_calls');
    t.json('tool_results');
    // The provider's own message, replayed as is to the same provider and model.
    t.string('provider', 16);
    t.string('model', 100);
    t.json('provider_message');
    t.integer('input_tokens');
    t.integer('output_tokens');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['conversation_id', 'id']);
  });

  await knex.schema.createTable('assistant_actions', (t) => {
    t.uuid('id').primary();
    t.uuid('conversation_id').notNullable().references('assistant_conversations.id').onDelete('CASCADE');
    t.bigInteger('message_id').unsigned().references('assistant_messages.id').onDelete('SET NULL');
    t.string('kind', 64).notNullable();
    t.json('params').notNullable();
    // What it acts on, as shown on the card.
    t.string('target_type', 32).notNullable();
    t.uuid('target_id');
    t.string('target_label', 200).notNullable().defaultTo('');
    // The assistant's one-line reason for proposing it.
    t.string('reason', 1000).notNullable().defaultTo('');
    // proposed | running | succeeded | failed | cancelled | expired
    t.string('status', 16).notNullable().defaultTo('proposed');
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.uuid('decided_by').references('users.id').onDelete('SET NULL');
    t.datetime('decided_at', { precision: 3 });
    t.string('error_code', 64);
    t.string('error_message', 1000);
    ts(t, knex);
    t.index(['conversation_id']);
    t.index(['job_id']);
    t.index(['status', 'created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('assistant_actions');
  await knex.schema.dropTableIfExists('assistant_messages');
  await knex.schema.dropTableIfExists('assistant_conversations');
  await knex('settings').whereIn('key', ['assistant.config', 'assistant.api_key']).delete();
}
