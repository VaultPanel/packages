#!/usr/bin/env bash
# The "vaultpanel" command on a server installed with install.sh
# (/usr/local/bin/vaultpanel links here).
#
# Server commands look after the panel on this server: its address, status,
# logs, restarts and updates. Every other command goes to the VaultPanel CLI
# (cli/bin/vaultpanel.js), which talks to a panel's API: vaultpanel login,
# vaultpanel servers list, and so on.
set -euo pipefail

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
DIR="$(cd "$(dirname "$SELF")/.." && pwd)"
ENV_FILE="$DIR/.env"
NODE=/usr/bin/node
[[ -x "$NODE" ]] || NODE="$(command -v node)"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; DIM=$'\e[2m'; BLUE=$'\e[34m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; RED=$'\e[31m'; RESET=$'\e[0m'
else
  BOLD=""; DIM=""; BLUE=""; GREEN=""; YELLOW=""; RED=""; RESET=""
fi

fail() { echo "${RED}error:${RESET} $*" >&2; exit 1; }
need_root() { [[ "$(id -u)" -eq 0 ]] || fail "run it as root: sudo vaultpanel $*"; }
env_get() { [[ -r "$ENV_FILE" ]] && sed -n "s/^$1=//p" "$ENV_FILE" | tail -n 1; }

env_set() {
  local tmp
  tmp="$(mktemp)"
  if grep -q "^$1=" "$ENV_FILE"; then
    awk -v k="$1" -v v="$2" 'BEGIN { FS = OFS = "=" } $1 == k { print k "=" v; next } { print }' "$ENV_FILE" > "$tmp"
  else
    cat "$ENV_FILE" > "$tmp"
    echo "$1=$2" >> "$tmp"
  fi
  cat "$tmp" > "$ENV_FILE"
  rm -f "$tmp"
}

banner() {
  echo "${BLUE}${BOLD}"
  cat <<'ART'
 __     __          _ _   ____                  _
 \ \   / /_ _ _   _| | |_|  _ \ __ _ _ __   ___| |
  \ \ / / _` | | | | | __| |_) / _` | '_ \ / _ \ |
   \ V / (_| | |_| | | |_|  __/ (_| | | | |  __/ |
    \_/ \__,_|\__,_|_|\__|_|   \__,_|_| |_|\___|_|
ART
  echo -n "${RESET}"
}

# The panel on this server, for checks: its plain HTTP loopback port when it
# serves HTTPS itself, else its own port.
local_url() {
  local loopback port
  loopback="$(env_get VAULTPANEL_LOOPBACK_PORT)"
  port="$(env_get VAULTPANEL_PORT)"
  if [[ -n "$(env_get VAULTPANEL_TLS_CERT)" && -n "$loopback" ]]; then echo "http://127.0.0.1:$loopback"; else echo "http://127.0.0.1:${port:-8090}"; fi
}

version() {
  local agent
  agent="$(sed -n '/.*"version": *"\([^"]*\)".*/{s//\1/p;q}' "$DIR/agent/package.json")"
  local code
  if [[ -f "$DIR/VERSION" ]]; then
    code="$(cat "$DIR/VERSION")"
  else
    code="$(git -C "$DIR" describe --tags --exact-match HEAD 2>/dev/null || git -C "$DIR" rev-parse --short HEAD 2>/dev/null || echo unknown)"
  fi
  echo "$code (agent $agent)"
}

state() {
  if systemctl is-active --quiet "$1"; then echo "${GREEN}running${RESET}"; else echo "${RED}$(systemctl is-active "$1" 2>/dev/null || echo stopped)${RESET}"; fi
}

# "needs setup", "ready" or "" (panel not answering).
setup_state() {
  local body
  body="$(curl -fsS --max-time 3 "$(local_url)/api/v1/auth/setup" 2>/dev/null || true)"
  case "$body" in
    *'"needsSetup":true'*) echo "needs setup" ;;
    *'"needsSetup":false'*) echo "ready" ;;
  esac
}

cmd_info() {
  local url setup
  url="$(env_get VAULTPANEL_PUBLIC_URL)"
  setup="$(setup_state)"
  banner
  echo "  Address:   ${BOLD}${url:-unknown (run as root)}${RESET}"
  echo "  Panel:     $(state vaultpanel)    Worker: $(state vaultpanel-worker)    Agent: $(state vaultpanel-agent)"
  echo "  Version:   $(version)"
  if [[ "$setup" == "needs setup" ]]; then
    echo
    echo "  ${YELLOW}No owner account yet.${RESET} Open ${BOLD}$url/setup${RESET}"
    if [[ "$(id -u)" -eq 0 ]]; then echo "  Setup token: ${BOLD}$(env_get VAULTPANEL_SETUP_TOKEN)${RESET}"; else echo "  Setup token: sudo vaultpanel setup-token"; fi
  elif [[ -z "$setup" ]] && systemctl is-active --quiet vaultpanel; then
    echo "  ${DIM}The panel is starting...${RESET}"
  fi
  echo
  echo "  ${DIM}vaultpanel help${RESET} lists what this command can do."
}

cmd_status() {
  echo "VaultPanel $(version)"
  echo "  vaultpanel         $(state vaultpanel)"
  echo "  vaultpanel-worker  $(state vaultpanel-worker)"
  echo "  vaultpanel-agent   $(state vaultpanel-agent)"
  local health
  health="$(curl -sS --max-time 3 "$(local_url)/api/v1/health" 2>/dev/null || true)"
  case "$health" in
    *'"status":"ok"'*) echo "  database, redis    ${GREEN}ok${RESET}" ;;
    *'"database"'*) echo "  database, redis    ${RED}${health}${RESET}" ;;
    *) echo "  database, redis    ${YELLOW}unknown (the panel is not answering)${RESET}" ;;
  esac
  if [[ "$(id -u)" -eq 0 && -f "$DIR/docker/compose.prod.yml" ]]; then
    echo
    docker compose -p vaultpanel --env-file "$ENV_FILE" -f "$DIR/docker/compose.prod.yml" ps --format 'table {{.Service}}\t{{.Status}}' 2>/dev/null || true
  fi
}

cmd_logs() {
  local unit=vaultpanel follow=()
  for arg in "$@"; do
    case "$arg" in
      api|panel) unit=vaultpanel ;;
      worker) unit=vaultpanel-worker ;;
      agent) unit=vaultpanel-agent ;;
      -f|--follow) follow=(-f) ;;
      *) fail "usage: vaultpanel logs [panel|worker|agent] [-f]" ;;
    esac
  done
  # The panel logs JSON lines; pino-pretty (installed with it) makes them readable.
  local pretty="$DIR/node_modules/.bin/pino-pretty"
  if [[ "$unit" != vaultpanel-agent && -x "$pretty" && -t 1 ]]; then
    journalctl -u "$unit" -n 100 --no-pager -o cat "${follow[@]}" | "$NODE" "$pretty" --translateTime SYS:standard --ignore pid,hostname,req,res
  else
    exec journalctl -u "$unit" -n 100 --no-pager -o cat "${follow[@]}"
  fi
}

cmd_services() {
  local action="$1"
  need_root "$action"
  case "$action" in
    start)
      docker compose -p vaultpanel --env-file "$ENV_FILE" -f "$DIR/docker/compose.prod.yml" up -d >/dev/null
      systemctl start vaultpanel vaultpanel-worker ;;
    stop) systemctl stop vaultpanel-worker vaultpanel ;;
    restart) systemctl restart vaultpanel vaultpanel-worker ;;
  esac
  echo "VaultPanel: ${action} done. Panel $(state vaultpanel), worker $(state vaultpanel-worker)."
}

cmd_update() {
  need_root update
  if [[ ! -d "$DIR/.git" ]]; then update_package "$@"; return; fi
  local args=(--dir "$DIR") force=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --force) force=1; shift ;;
      --version) [[ -n "${2:-}" ]] || fail "usage: vaultpanel update [--version <vX.Y.Z|latest>] [--force]"; args+=(--version "$2"); shift 2 ;;
      --branch) [[ -n "${2:-}" ]] || fail "usage: vaultpanel update --branch <name>"; args+=(--branch "$2"); shift 2 ;;
      *) fail "usage: vaultpanel update [--version <vX.Y.Z|latest>] [--branch <name>] [--force]" ;;
    esac
  done
  [[ -n "$force" ]] || args+=(--if-newer)
  echo "Checking for a new VaultPanel (installed: $(version))..."
  # The installer finds the version, backs the panel up, switches the code,
  # then hands over to the new version's own installer (packages, build,
  # database, restart). Without --force it stops when nothing changed.
  VAULTPANEL_SKIP_PACKAGES=1 exec bash "$DIR/install.sh" "${args[@]}"
}

# A panel installed from VaultPanel's packages updates with apt: the package
# backs the panel up first (its preinst runs prepare-upgrade) and sets the new
# version up (its postinst).
update_package() {
  local want=vaultpanel force="" version=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --force) force=1; shift ;;
      --version) [[ -n "${2:-}" ]] || fail "usage: vaultpanel update [--version <vX.Y.Z>] [--force]"; version="${2#v}"; shift 2 ;;
      --branch) fail "--branch only works for a panel installed from a copy of the repository" ;;
      *) fail "usage: vaultpanel update [--version <vX.Y.Z>] [--force]" ;;
    esac
  done
  echo "Checking for a new VaultPanel (installed: $(version))..."
  apt-get update -qq || fail "could not read the package lists (apt-get update)"
  local installed candidate
  installed="$(dpkg-query -W -f='${Version}' vaultpanel 2>/dev/null)" || fail "the vaultpanel package is not installed"
  if [[ -n "$version" ]]; then
    grep -qxF "$version" <<< "$(apt-cache madison vaultpanel | awk '{ print $3 }')" || fail "version $version is not in VaultPanel's package repository"
    want="vaultpanel=$version"
    candidate="$version"
  else
    candidate="$(apt-cache policy vaultpanel | awk '/Candidate:/ { print $2 }')"
  fi
  if [[ "$candidate" == "$installed" && -z "$force" ]]; then
    echo "VaultPanel is up to date ($installed). To set it up again anyway: sudo vaultpanel update --force"
    return 0
  fi
  if dpkg --compare-versions "$candidate" lt "$installed"; then
    fail "$candidate is older than the installed $installed. To go back to the version before the last update: sudo vaultpanel rollback"
  fi
  local args=(-y -q)
  [[ "$candidate" != "$installed" ]] || args+=(--reinstall)
  exec apt-get install "${args[@]}" "$want"
}

# Before the vaultpanel package changes version (its preinst): a backup of the
# panel, and a note of the version being replaced, for "vaultpanel rollback".
cmd_prepare_upgrade() {
  need_root prepare-upgrade
  local replaced="${1:-}" file
  [[ -n "$replaced" ]] || fail "usage: vaultpanel prepare-upgrade <version being replaced>"
  echo "$replaced" > "$DIR/.package-previous"
  rm -f "$DIR/.package-previous-backup"
  echo "Backing up VaultPanel $replaced before the update..."
  if file="$(cmd_backup --label pre-update --keep 3 --quiet)"; then
    echo "$file" > "$DIR/.package-previous-backup"
    echo "backup: $file"
  else
    echo "${YELLOW}The backup before the update failed; updating anyway (vaultpanel rollback cannot bring the database back).${RESET}" >&2
  fi
}

# Back to the version installed before the last update, with the database as
# it was then (the backup taken just before that update).
cmd_rollback() {
  need_root rollback
  local yes=""
  [[ "${1:-}" != "--yes" && "${1:-}" != "-y" ]] || yes=1
  if [[ ! -d "$DIR/.git" ]]; then rollback_package "$yes"; return; fi
  local previous_file="$DIR/.git/vaultpanel-previous" backup_note="$DIR/.git/vaultpanel-previous-backup"
  [[ -s "$previous_file" ]] || fail "no earlier version is recorded (vaultpanel rollback works after a vaultpanel update)"
  local previous backup="" label
  previous="$(cat "$previous_file")"
  git -C "$DIR" cat-file -e "$previous^{commit}" 2>/dev/null || fail "the earlier version ($previous) is no longer in $DIR"
  label="$(git -C "$DIR" describe --tags --exact-match "$previous" 2>/dev/null || git -C "$DIR" rev-parse --short "$previous")"
  [[ ! -s "$backup_note" ]] || backup="$(cat "$backup_note")"
  echo "Rolling back from $(version) to $label."
  if [[ -n "$backup" && -f "$backup" ]]; then
    echo "The database goes back to the backup taken before the update ($backup):"
    echo "${YELLOW}changes made in the panel since then are lost.${RESET}"
  else
    echo "${YELLOW}No backup from before the update was found, so the database stays as it is.${RESET}"
    echo "If the newer version changed the database, the older one may not start."
  fi
  if [[ -z "$yes" ]]; then
    read -r -p "Type rollback to continue: " answer < /dev/tty
    [[ "$answer" == rollback ]] || fail "cancelled"
  fi
  systemctl stop vaultpanel-worker vaultpanel
  local current
  current="$(git -C "$DIR" rev-parse HEAD)"
  git -C "$DIR" -c advice.detachedHead=false checkout --quiet --force --detach "$previous"
  echo "$current" > "$previous_file"
  rm -f "$backup_note"
  if [[ -n "$backup" && -f "$backup" ]]; then cmd_restore --yes --no-start "$backup"; fi
  VAULTPANEL_SKIP_PACKAGES=1 exec bash "$DIR/install.sh" --dir "$DIR" --no-fetch
}

# The same for a panel installed from VaultPanel's packages: the database
# goes back first, then apt installs the earlier package, which sets it up.
rollback_package() {
  local yes="$1" previous installed backup=""
  [[ -s "$DIR/.package-previous" ]] || fail "no earlier version is recorded (vaultpanel rollback works after a vaultpanel update)"
  previous="$(cat "$DIR/.package-previous")"
  installed="$(dpkg-query -W -f='${Version}' vaultpanel 2>/dev/null)" || fail "the vaultpanel package is not installed"
  [[ "$previous" != "$installed" ]] || fail "VaultPanel $installed is already the version before the last update"
  apt-get update -qq || fail "could not read the package lists (apt-get update)"
  grep -qxF "$previous" <<< "$(apt-cache madison vaultpanel | awk '{ print $3 }')" || fail "VaultPanel $previous is no longer in VaultPanel's package repository (it keeps the newest few)"
  [[ ! -s "$DIR/.package-previous-backup" ]] || backup="$(cat "$DIR/.package-previous-backup")"
  echo "Rolling back from $installed to $previous."
  if [[ -n "$backup" && -f "$backup" ]]; then
    echo "The database goes back to the backup taken before the update ($backup):"
    echo "${YELLOW}changes made in the panel since then are lost.${RESET}"
  else
    echo "${YELLOW}No backup from before the update was found, so the database stays as it is.${RESET}"
    echo "If the newer version changed the database, the older one may not start."
  fi
  if [[ -z "$yes" ]]; then
    read -r -p "Type rollback to continue: " answer < /dev/tty
    [[ "$answer" == rollback ]] || fail "cancelled"
  fi
  systemctl stop vaultpanel-worker vaultpanel
  if [[ -n "$backup" && -f "$backup" ]]; then cmd_restore --yes --no-start "$backup"; fi
  exec apt-get install -y -q --allow-downgrades "vaultpanel=$previous"
}

# ---- Backups of the panel itself ---------------------------------------------
#
# A backup is one .tar.gz (or .tar.gz.enc) holding:
#   database.sql   the panel's MariaDB database (mariadb-dump)
#   env            the .env file (VAULTPANEL_SECRET_KEY decrypts the rest)
#   tls/           the panel's HTTPS certificate and key (agents pin it)
#   data/          terminal recordings and the panel domain list
#   VERSION        the code version it came from
# Files are root's (mode 600). With VAULTPANEL_BACKUP_PASSPHRASE_FILE set they
# are encrypted with openssl (AES-256, PBKDF2). VAULTPANEL_BACKUP_UPLOAD, if
# set, is a command run with the file as $1 (rclone, scp, aws s3 cp...).

# Temporary folders, removed when the command ends however it ends.
TEMP_DIRS=()
trap 'rm -rf "${TEMP_DIRS[@]}"' EXIT
# temp_dir <variable>: a new folder in that variable (not in $(...), which
# would run in a subshell and lose track of it).
temp_dir() {
  local d
  d="$(mktemp -d)"
  TEMP_DIRS+=("$d")
  printf -v "$1" '%s' "$d"
}

compose() {
  docker compose -p vaultpanel --env-file "$ENV_FILE" -f "$DIR/docker/compose.prod.yml" "$@"
}

has_compose_db() {
  [[ -f "$DIR/docker/compose.prod.yml" && -n "$(compose ps -q mariadb 2>/dev/null)" ]]
}

cmd_backup() {
  need_root backup
  local label="manual" keep="" quiet="" dir=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --label) label="${2:-}"; shift 2 ;;
      --keep) keep="${2:-}"; shift 2 ;;
      --dir) dir="${2:-}"; shift 2 ;;
      --quiet) quiet=1; shift ;;
      *) fail "usage: vaultpanel backup [--dir <folder>] [--keep <n>] [--label <name>]" ;;
    esac
  done
  [[ "$label" =~ ^[a-z0-9-]{1,32}$ ]] || fail "--label may use a-z, 0-9 and -"
  [[ -n "$dir" ]] || dir="$(env_get VAULTPANEL_BACKUP_DIR)"
  dir="${dir:-/var/backups/vaultpanel-panel}"
  [[ -z "$keep" ]] || [[ "$keep" =~ ^[0-9]+$ ]] || fail "--keep must be a number"
  if [[ -z "$keep" && "$label" == scheduled ]]; then keep="$(env_get VAULTPANEL_BACKUP_KEEP)"; fi
  has_compose_db || fail "the panel's MariaDB container is not running (vaultpanel backup works with the database install.sh set up; back up your own database otherwise)"

  local work stamp name file
  temp_dir work
  stamp="$(date -u +%Y%m%d-%H%M%S)"
  name="vaultpanel-$stamp-$label"
  mkdir -p "$work/$name/tls" "$work/$name/data"
  chmod 700 "$work/$name"

  [[ -n "$quiet" ]] || echo "Dumping the database..."
  # The root password stays inside the container (no command line shows it).
  compose exec -T mariadb sh -c 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" exec mariadb-dump -uroot --single-transaction --routines --triggers --events --hex-blob --add-drop-database --databases "$MARIADB_DATABASE"' \
    > "$work/$name/database.sql" || fail "the database dump failed"
  [[ -s "$work/$name/database.sql" ]] || fail "the database dump is empty"
  cp "$ENV_FILE" "$work/$name/env"
  local cert key
  cert="$(env_get VAULTPANEL_TLS_CERT)"; key="$(env_get VAULTPANEL_TLS_KEY)"
  [[ -z "$cert" || ! -f "$cert" ]] || cp "$cert" "$work/$name/tls/panel.crt"
  [[ -z "$key" || ! -f "$key" ]] || cp "$key" "$work/$name/tls/panel.key"
  local data
  data="$(env_get VAULTPANEL_DATA_DIR)"
  if [[ -n "$data" && -d "$data" ]]; then
    # Download and upload copies are temporary; recordings and settings are not.
    [[ ! -d "$data/terminal-recordings" ]] || cp -a "$data/terminal-recordings" "$work/$name/data/"
    [[ ! -f "$data/panel-hosts.json" ]] || cp -a "$data/panel-hosts.json" "$work/$name/data/"
  fi
  { echo "created=$(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo "version=$(version)"; echo "commit=$(git -C "$DIR" rev-parse HEAD 2>/dev/null || echo unknown)"; echo "host=$(hostname)"; } > "$work/$name/VERSION"

  umask 077
  mkdir -p "$dir"
  chmod 700 "$dir"
  file="$dir/$name.tar.gz"
  tar -czf "$file.part" -C "$work" "$name" || fail "could not write $file"
  local passfile
  passfile="$(env_get VAULTPANEL_BACKUP_PASSPHRASE_FILE)"
  if [[ -n "$passfile" ]]; then
    [[ -r "$passfile" ]] || fail "VAULTPANEL_BACKUP_PASSPHRASE_FILE ($passfile) cannot be read"
    openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 -salt -pass "file:$passfile" -in "$file.part" -out "$file.enc.part" || fail "encrypting the backup failed"
    rm -f "$file.part"
    file="$file.enc"
    mv "$file.part" "$file"
  else
    mv "$file.part" "$file"
  fi
  chmod 600 "$file"
  sha256sum "$file" | sed "s|  .*/|  |" > "$file.sha256"
  chmod 600 "$file.sha256"
  rm -rf "$work"

  if [[ -n "$keep" && "$keep" -gt 0 ]]; then
    local old
    # Newest first; everything after the first $keep with this label goes.
    while IFS= read -r old; do
      rm -f "$old" "$old.sha256"
    done < <(ls -1t "$dir"/vaultpanel-*-"$label".tar.gz "$dir"/vaultpanel-*-"$label".tar.gz.enc 2>/dev/null | tail -n +"$((keep + 1))")
  fi

  local upload
  upload="$(env_get VAULTPANEL_BACKUP_UPLOAD)"
  if [[ -n "$upload" ]]; then
    bash -c "$upload" vaultpanel-backup "$file" >&2 || echo "${YELLOW}warning:${RESET} the backup was made, but VAULTPANEL_BACKUP_UPLOAD failed" >&2
  fi
  if [[ -n "$quiet" ]]; then echo "$file"; else
    echo "Backup written: ${BOLD}$file${RESET} ($(du -h "$file" | cut -f1))"
    echo "${DIM}It holds the panel's secret key: keep a copy off this server, somewhere only you can read.${RESET}"
  fi
}

# Puts a backup back: the database, the secret key and other settings, the
# HTTPS certificate and the panel's files. This server keeps its own database
# and Redis passwords and ports, so a backup can be restored on a new server
# that was set up with install.sh (disaster recovery).
cmd_restore() {
  need_root restore
  local yes="" start=1 file=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --yes|-y) yes=1; shift ;;
      --no-start) start=""; shift ;;
      -*) fail "usage: vaultpanel restore <backup file> [--yes]" ;;
      *) file="$1"; shift ;;
    esac
  done
  [[ -n "$file" && -f "$file" ]] || fail "usage: vaultpanel restore <backup file> [--yes]  (backups are in $(env_get VAULTPANEL_BACKUP_DIR))"
  if [[ -f "$file.sha256" ]]; then
    (cd "$(dirname "$file")" && sha256sum -c --quiet "$(basename "$file").sha256") || fail "$file does not match its checksum ($file.sha256)"
  fi
  local work
  temp_dir work
  local archive="$file"
  if [[ "$file" == *.enc ]]; then
    local passfile
    passfile="$(env_get VAULTPANEL_BACKUP_PASSPHRASE_FILE)"
    if [[ -n "$passfile" && -r "$passfile" ]]; then
      openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 -pass "file:$passfile" -in "$file" -out "$work/backup.tar.gz" || fail "could not decrypt $file with $passfile"
    else
      openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 -in "$file" -out "$work/backup.tar.gz" || fail "could not decrypt $file"
    fi
    archive="$work/backup.tar.gz"
  fi
  tar -xzf "$archive" -C "$work" || fail "$file is not a VaultPanel backup"
  local root
  root="$(find "$work" -mindepth 1 -maxdepth 1 -type d -name 'vaultpanel-*' -print -quit)"
  [[ -n "$root" && -s "$root/database.sql" && -f "$root/env" ]] || fail "$file is not a VaultPanel backup (database.sql or env is missing)"

  echo "Backup: $(sed -n 's/^created=//p' "$root/VERSION") from $(sed -n 's/^host=//p' "$root/VERSION"), version $(sed -n 's/^version=//p' "$root/VERSION")"
  echo "${YELLOW}This replaces the panel's database, settings and certificate with the backup's.${RESET}"
  if [[ -z "$yes" ]]; then
    read -r -p "Type restore to continue: " answer < /dev/tty
    [[ "$answer" == restore ]] || fail "cancelled"
  fi
  has_compose_db || compose up -d >/dev/null
  local tries=0
  until compose exec -T mariadb sh -c 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" mariadb -uroot -e "select 1"' >/dev/null 2>&1; do
    tries=$((tries + 1)); [[ $tries -le 60 ]] || fail "the panel's MariaDB did not start"; sleep 2
  done
  systemctl stop vaultpanel-worker vaultpanel 2>/dev/null || true

  # A safety copy of what is here now, unless it is the rollback's own restore.
  if [[ -n "$start" ]]; then
    local safety
    safety="$(cmd_backup --label before-restore --keep 3 --quiet)" && echo "Safety backup of the current panel: $safety"
  fi

  echo "Restoring the database..."
  # The dump is for the database named in this server's settings.
  compose exec -T mariadb sh -c 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" exec mariadb -uroot' < "$root/database.sql" || fail "the database restore failed"
  compose exec -T mariadb sh -c 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" exec mariadb -uroot -e "GRANT ALL PRIVILEGES ON \`$MARIADB_DATABASE\`.* TO \`$MARIADB_USER\`@\`%\`; FLUSH PRIVILEGES;"' >/dev/null 2>&1 || true

  echo "Restoring the settings..."
  # Everything from the backup except what belongs to this server's own
  # database, Redis, folders and certificate paths.
  local keep_keys="VAULTPANEL_DB_ROOT_PASSWORD VAULTPANEL_DB_PASSWORD VAULTPANEL_REDIS_PASSWORD VAULTPANEL_DB_PORT VAULTPANEL_REDIS_PORT DATABASE_URL REDIS_URL VAULTPANEL_DATA_DIR VAULTPANEL_UI_DIR VAULTPANEL_TLS_CERT VAULTPANEL_TLS_KEY VAULTPANEL_BACKUP_DIR VAULTPANEL_BACKUP_PASSPHRASE_FILE VAULTPANEL_BACKUP_UPLOAD"
  local merged="$work/env.merged" key value
  grep -v -E "^($(echo "$keep_keys" | tr ' ' '|'))=" "$root/env" > "$merged" || true
  for key in $keep_keys; do
    value="$(env_get "$key")"
    [[ -z "$value" ]] || echo "$key=$value" >> "$merged"
  done
  cat "$merged" > "$ENV_FILE"

  local cert keyfile
  cert="$(env_get VAULTPANEL_TLS_CERT)"; keyfile="$(env_get VAULTPANEL_TLS_KEY)"
  if [[ -f "$root/tls/panel.crt" && -f "$root/tls/panel.key" ]]; then
    cert="${cert:-/etc/vaultpanel/tls/panel.crt}"; keyfile="${keyfile:-/etc/vaultpanel/tls/panel.key}"
    mkdir -p "$(dirname "$cert")"
    install -m 644 -o root -g vaultpanel "$root/tls/panel.crt" "$cert"
    install -m 640 -o root -g vaultpanel "$root/tls/panel.key" "$keyfile"
    grep -q '^VAULTPANEL_TLS_CERT=' "$ENV_FILE" || { echo "VAULTPANEL_TLS_CERT=$cert" >> "$ENV_FILE"; echo "VAULTPANEL_TLS_KEY=$keyfile" >> "$ENV_FILE"; }
    echo "The panel's certificate came back too, so agents on other servers keep trusting it."
  fi

  local data
  data="$(env_get VAULTPANEL_DATA_DIR)"
  if [[ -n "$data" && -d "$root/data" ]]; then
    mkdir -p "$data"
    cp -a "$root/data/." "$data/"
    chown -R vaultpanel:vaultpanel "$data" 2>/dev/null || true
  fi
  # Queued work and agent nonces belong to the state that was replaced.
  compose exec -T redis sh -c 'redis-cli -a "$REDIS_PASSWORD" --no-auth-warning FLUSHALL' >/dev/null 2>&1 || true

  if [[ -n "$start" ]]; then
    echo "Updating the database to this version..."
    (cd "$DIR" && npm run db:migrate --silent >/dev/null) \
      || fail "the database update failed. If the backup comes from a newer VaultPanel, update first: sudo vaultpanel update --version <that version>, then restore again"
    systemctl start vaultpanel vaultpanel-worker
    echo "Restored. Panel $(state vaultpanel), worker $(state vaultpanel-worker)."
    echo "${DIM}If this server's address differs from the old one: sudo vaultpanel url <new address>${RESET}"
  fi
}

# ---- HTTPS on the panel's own port ---------------------------------------------

cmd_https() {
  local action="${1:-status}"
  case "$action" in
    status)
      local cert
      cert="$(env_get VAULTPANEL_TLS_CERT)"
      if [[ -z "$cert" ]]; then
        echo "HTTPS is ${RED}off${RESET}: the panel uses plain HTTP on port $(env_get VAULTPANEL_PORT). Turn it on: sudo vaultpanel https on"
        return
      fi
      [[ -r "$cert" ]] || fail "run it as root: sudo vaultpanel https"
      echo "HTTPS is ${GREEN}on${RESET} at $(env_get VAULTPANEL_PUBLIC_URL)"
      echo "  Certificate:  $cert"
      openssl x509 -in "$cert" -noout -subject -enddate -ext subjectAltName 2>/dev/null | sed 's/^/  /'
      echo "  SHA-256:      $(openssl x509 -in "$cert" -noout -fingerprint -sha256 | sed 's/.*=//')"
      echo "  Agent pin:    $(cert_pin "$cert")"
      ;;
    on)
      need_root https on
      echo "Turning on HTTPS (this rebuilds and restarts the panel)..."
      VAULTPANEL_SKIP_PACKAGES=1 bash "$DIR/install.sh" --dir "$DIR" --no-fetch --https
      echo
      echo "Agents on other servers that used plain HTTP must move to HTTPS. On each, run:"
      echo "  ${BOLD}$(agent_upgrade_command)${RESET}"
      ;;
    off)
      need_root https off
      VAULTPANEL_SKIP_PACKAGES=1 exec bash "$DIR/install.sh" --dir "$DIR" --no-fetch --http
      ;;
    renew)
      need_root https renew
      local cert key
      cert="$(env_get VAULTPANEL_TLS_CERT)"; key="$(env_get VAULTPANEL_TLS_KEY)"
      [[ -n "$cert" && -f "$key" ]] || fail "HTTPS is off (sudo vaultpanel https on)"
      # The same key, so the agents' pin stays the same; a new certificate
      # with this server's current names and addresses, valid 10 years.
      local san host addr
      host="$(hostname -f 2>/dev/null || hostname)"
      san="DNS:localhost,IP:127.0.0.1,IP:::1,DNS:$host"
      for addr in $(hostname -I 2>/dev/null) $(sed -E 's|^https?://||; s|/.*$||; s|:[0-9]+$||' <<< "$(env_get VAULTPANEL_PUBLIC_URL)"); do
        [[ ",$san," == *":$addr,"* ]] && continue
        if [[ "$addr" =~ ^[0-9.]+$ || "$addr" == *:* ]]; then san="$san,IP:$addr"; else san="$san,DNS:$addr"; fi
      done
      # A common name may be at most 64 characters (see install.sh).
      local cn="VaultPanel $host" err
      (( ${#cn} <= 64 )) || cn="VaultPanel"
      if ! err="$(openssl req -x509 -key "$key" -days 3650 -subj "/CN=$cn" \
        -addext "subjectAltName=$san" -addext "basicConstraints=critical,CA:FALSE" \
        -addext "keyUsage=critical,digitalSignature" -addext "extendedKeyUsage=serverAuth" \
        -out "$cert.new" 2>&1 >/dev/null)"; then
        fail "openssl could not make the certificate: $(tail -n 2 <<< "$err" | tr '\n' ' ')"
      fi
      chown root:vaultpanel "$cert.new"; chmod 644 "$cert.new"; mv "$cert.new" "$cert"
      systemctl restart vaultpanel vaultpanel-worker
      echo "New certificate in place (same key, so the pin did not change), panel restarted."
      echo "Agents on other servers keep the old certificate until you run, on each:"
      echo "  ${BOLD}$(agent_upgrade_command)${RESET}"
      ;;
    *) fail "usage: vaultpanel https [status|on|off|renew]" ;;
  esac
}

cert_pin() {
  "$NODE" -e 'const c=new (require("node:crypto").X509Certificate)(require("node:fs").readFileSync(process.argv[1]));process.stdout.write("sha256//"+require("node:crypto").createHash("sha256").update(c.publicKey.export({type:"spki",format:"der"})).digest("base64"))' "$1"
}

agent_upgrade_command() {
  local url pin
  url="$(env_get VAULTPANEL_PUBLIC_URL)"
  pin="$(cert_pin "$(env_get VAULTPANEL_TLS_CERT)")"
  echo "curl -fsSL --pinnedpubkey '$pin' -k $url/api/v1/agent/install.sh | sudo bash -s -- --upgrade --panel $url --panel-pin '$pin'"
}

cmd_url() {
  if [[ $# -eq 0 ]]; then
    env_get VAULTPANEL_PUBLIC_URL || fail "run it as root: sudo vaultpanel url"
    return
  fi
  need_root url
  local url="${1%/}"
  [[ "$url" =~ ^https?://[^/[:space:]]+$ ]] || fail "give the address people open the panel at, like https://panel.example.com"
  if [[ -n "$(env_get VAULTPANEL_TLS_CERT)" && "$url" == http://*:"$(env_get VAULTPANEL_PORT)" ]]; then
    fail "port $(env_get VAULTPANEL_PORT) serves HTTPS: use https://${url#http://} (or turn HTTPS off first: sudo vaultpanel https off)"
  fi
  env_set VAULTPANEL_PUBLIC_URL "$url"
  if [[ "$url" == https://* ]]; then
    env_set VAULTPANEL_COOKIE_SECURE true
    env_set VAULTPANEL_ALLOW_INSECURE_AGENTS false
  else
    env_set VAULTPANEL_COOKIE_SECURE false
    env_set VAULTPANEL_ALLOW_INSECURE_AGENTS true
  fi
  systemctl restart vaultpanel vaultpanel-worker
  echo "The panel's address is now $url (restarted)."
  local cert host
  cert="$(env_get VAULTPANEL_TLS_CERT)"
  host="$(sed -E 's|^https?://||; s|:[0-9]+$||; s|^\[(.*)\]$|\1|' <<< "$url")"
  if [[ -n "$cert" && "$url" == https://*:"$(env_get VAULTPANEL_PORT)" ]] && [[ "$(openssl x509 -in "$cert" -noout -checkhost "$host" 2>/dev/null)" != *'does match'* ]] && [[ "$(openssl x509 -in "$cert" -noout -checkip "$host" 2>/dev/null)" != *'does match'* ]]; then
    echo "${YELLOW}The panel's certificate does not name $host yet.${RESET} Agents check it: run sudo vaultpanel https renew"
  fi
  if [[ "$url" == https://* ]]; then
    echo "Sign-in cookies are now HTTPS only, so sign in at $url, not at the plain HTTP address."
    echo "Other servers' agents must reach the panel over HTTPS from now on."
  fi
}

cmd_help() {
  cat <<EOF
${BOLD}vaultpanel${RESET}: VaultPanel on this server ($DIR)

Server commands:
  vaultpanel                   Address, status and version
  vaultpanel status            Status of the panel, worker, agent and database
  vaultpanel logs [panel|worker|agent] [-f]
                               Recent log lines (-f keeps following)
  vaultpanel restart           Restart the panel and worker      (root)
  vaultpanel start | stop      Start or stop them                (root)
  vaultpanel update [--force] [--version <vX.Y.Z>]
                               Update to the latest release (backs up first) (root)
  vaultpanel rollback          Back to the version before the last update   (root)
  vaultpanel backup [--dir <folder>] [--keep <n>]
                               Back up the panel's database, settings and certificate (root)
  vaultpanel restore <file>    Put a backup back (also on a new server)     (root)
  vaultpanel https [status|on|off|renew]
                               The panel's own HTTPS certificate
  vaultpanel url [<address>]   Show or change the panel's address, e.g.
                               vaultpanel url https://panel.example.com  (root)
  vaultpanel setup-token       The token for creating the owner account (root)
  vaultpanel version           Installed version

Panel commands (sign in first: vaultpanel login --url $(env_get VAULTPANEL_PUBLIC_URL 2>/dev/null || echo '<address>')):
EOF
  "$NODE" "$DIR/cli/bin/vaultpanel.js" --help 2>/dev/null | awk '/^Commands:/ { p = 1; next } p && /^$/ { exit } p' || true
  echo
  echo "More on panel commands: vaultpanel <command> --help, and $DIR/docs/cli.md"
}

# Everything runs from this function, called on one line with exit: an update or
# rollback replaces this file while it runs, and bash must never read on in it.
dispatch() {
  case "${1:-}" in
    ""|info) cmd_info ;;
    status) cmd_status ;;
    logs|log) shift; cmd_logs "$@" ;;
    start|stop|restart) cmd_services "$1" ;;
    update|upgrade) shift; cmd_update "$@" ;;
    rollback) shift; cmd_rollback "$@" ;;
    prepare-upgrade) shift; cmd_prepare_upgrade "$@" ;;
    backup) shift; cmd_backup "$@" ;;
    restore) shift; cmd_restore "$@" ;;
    https|tls) shift; cmd_https "$@" ;;
    url|address) shift; cmd_url "$@" ;;
    setup-token)
      need_root setup-token
      if [[ "$(setup_state)" == "ready" ]]; then echo "The owner account already exists, so the setup token no longer works. Sign in at $(env_get VAULTPANEL_PUBLIC_URL)."; else env_get VAULTPANEL_SETUP_TOKEN; fi ;;
    version|--version|-v) echo "VaultPanel $(version)" ;;
    help|--help|-h) cmd_help ;;
    motd)
      banner
      url="$(env_get VAULTPANEL_PUBLIC_URL)"
      echo
      echo " * Website:         https://www.vaultpanel.net"
      echo " * Documentation:   https://docs.vaultpanel.net"
      echo " * Best Practices:  https://docs.vaultpanel.net/best-practices"
      echo " * VaultPanel:      ${BOLD}${url%/}/${RESET}   ${DIM}(panel $(state vaultpanel))${RESET}"
      echo " * VaultPanel CLI:  vaultpanel"
      echo
      ;;
    *) exec "$NODE" "$DIR/cli/bin/vaultpanel.js" "$@" ;;
  esac
}

dispatch "$@"; exit $?
