import { readFileSync } from 'node:fs';
import { VaultPanel, VaultPanelError } from '@vaultpanel/sdk';
import { parseArgs } from './args.js';
import { resolveProfile } from './config.js';
import { COMMANDS, ALIASES, findCommand } from './commands/index.js';
import { commandHelp, groupHelp, topHelp } from './help.js';
import { createOutput } from './output.js';
import { CliError } from './errors.js';

const version = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;

// The whole CLI, as a function, so the tests can run commands without
// spawning a process. Returns the exit code.
export async function run(argv, { env = process.env, stdout = process.stdout, stderr = process.stderr, client, ask } = {}) {
  const { positional, flags } = parseArgs(argv);
  const out = createOutput({ json: Boolean(flags.json), quiet: Boolean(flags.quiet), stdout, stderr });

  if (flags.version) {
    out.raw(version);
    return 0;
  }

  const [groupName, maybeCommand, ...rest] = positional;
  if (!groupName) {
    out.raw(topHelp());
    return flags.help ? 0 : 1;
  }

  const key = ALIASES[groupName] ?? groupName;
  const group = COMMANDS[key];
  if (group && !group.run && (!maybeCommand || (flags.help && !group.commands[maybeCommand]))) {
    out.raw(groupHelp(key, group));
    return maybeCommand || flags.help ? 0 : 1;
  }

  const found = findCommand(groupName, maybeCommand);
  if (found.error) {
    out.error(found.error);
    return 1;
  }
  const { command, path } = found;
  if (flags.help) {
    out.raw(commandHelp(path, command));
    return 0;
  }

  // Commands that only touch the config file (login, logout, profiles) run
  // without a client; everything else needs a panel and a token.
  const profile = resolveProfile({ flags, env });
  // login builds its own client from what was typed, so it is handed a way to
  // make one (which the tests replace).
  const connect = (options) => client ?? new VaultPanel({ userAgent: `vaultpanel-cli/${version}`, ...options });
  let panel = client ?? null;
  if (command.needsClient !== false && !panel) {
    if (!profile.baseUrl || !profile.token) {
      out.error(
        profile.baseUrl
          ? 'No API token. Create one in the panel under Users & Access > API Tokens, then run: vaultpanel login'
          : 'Which panel? Run: vaultpanel login --url https://panel.example.com (or set VAULTPANEL_URL and VAULTPANEL_TOKEN)',
      );
      return 1;
    }
    panel = new VaultPanel({ baseUrl: profile.baseUrl, token: profile.token, userAgent: `vaultpanel-cli/${version}` });
  }

  try {
    await command.run({
      panel,
      out,
      flags,
      env,
      profile,
      connect,
      ask,
      // The positional arguments after the command itself.
      args: group?.run ? positional.slice(1) : rest,
      version,
    });
    return 0;
  } catch (err) {
    return report(err, out, profile);
  }
}

function report(err, out, profile) {
  if (err instanceof CliError) {
    out.error(err.message);
    if (err.hint) out.info(err.hint);
    return err.exitCode;
  }
  if (err instanceof VaultPanelError) {
    out.error(err.message);
    if (err.isValidationError) {
      for (const [field, message] of Object.entries(err.fieldErrors)) out.error(`  ${field}: ${message}`);
    }
    if (err.status === 401) out.info(`The token for profile "${profile.name}" is not valid any more. Make a new one in the panel and run: vaultpanel login`);
    if (err.status === 403) out.info("The token's scopes do not cover this. Make one with wider scopes, or ask an owner.");
    if (err.requestId) out.info(`Request id ${err.requestId} (quote it when reporting a problem).`);
    return err.status === 401 || err.status === 403 ? 3 : 2;
  }
  out.error(err?.message ?? String(err));
  return 1;
}

export { version };
