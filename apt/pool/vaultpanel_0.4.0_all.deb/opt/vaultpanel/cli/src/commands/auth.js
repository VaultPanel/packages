import { createInterface } from 'node:readline/promises';
import { isApiToken } from '@vaultpanel/sdk';
import { configPath, readConfig, removeProfile, resolveProfile, saveProfile, writeConfig } from '../config.js';
import { relative } from '../output.js';
import { CliError } from '../errors.js';

// Reads the token without echoing it, so it does not end up in the terminal
// or in the shell history.
async function askHidden(question, { input = process.stdin, output = process.stdout } = {}) {
  const rl = createInterface({ input, output, terminal: true });
  const onKeypress = (char) => {
    // Rewrite the line as asterisks while typing.
    if (char === '\r' || char === '\n') return;
    output.write(`\u001b[2K\u001b[200D${question}${'*'.repeat(rl.line.length)}`);
  };
  input.on('data', onKeypress);
  try {
    const answer = await rl.question(question);
    output.write('\n');
    return answer.trim();
  } finally {
    input.off('data', onKeypress);
    rl.close();
  }
}

export const authCommands = {
  summary: 'Sign in, see who you are and manage API tokens',
  commands: {
    login: {
      summary: 'Save a panel URL and API token as a profile',
      usage: 'vaultpanel login [--url https://panel.example.com] [--token vpt_...] [--profile name]',
      details: 'Make the token in the panel under Users & Access > API Tokens. Without --token the CLI asks for it without showing it.',
      needsClient: false,
      async run({ out, flags, env, connect, ask = askHidden }) {
        const name = flags.profile ?? env.VAULTPANEL_PROFILE ?? 'default';
        const existing = readConfig(env).profiles[name] ?? {};
        const url = flags.url ?? existing.url;
        if (!url) throw new CliError('Which panel? Pass --url https://panel.example.com');
        const token = flags.token ?? (await ask('API token: '));
        if (!isApiToken(token)) {
          throw new CliError('That does not look like an API token. They start with vpt_ and are made under Users & Access > API Tokens.');
        }
        // Check it before saving, so a typo is caught here and not in a script.
        const panel = connect({ baseUrl: url, token });
        const me = await panel.me();
        saveProfile(name, { url: panel.baseUrl, token }, env);
        out.success(`Signed in to ${panel.baseUrl} as ${me.user.email} (token "${me.apiToken?.name ?? 'unknown'}", profile "${name}")`);
        out.data({ profile: name, url: panel.baseUrl, user: me.user, apiToken: me.apiToken });
      },
    },
    logout: {
      summary: 'Forget a saved profile (the token stays valid until revoked in the panel)',
      usage: 'vaultpanel logout [--profile name]',
      needsClient: false,
      run({ out, flags, env }) {
        const name = flags.profile ?? env.VAULTPANEL_PROFILE ?? readConfig(env).defaultProfile ?? 'default';
        if (!removeProfile(name, env)) throw new CliError(`No profile called "${name}" in ${configPath(env)}`);
        out.success(`Profile "${name}" forgotten. Revoke the token in the panel if it should stop working.`);
      },
    },
    whoami: {
      summary: 'Who the token belongs to and what it may do',
      usage: 'vaultpanel whoami',
      async run({ panel, out, profile }) {
        const me = await panel.me();
        out.data(me);
        if (out.json) return;
        out.detail({
          Panel: panel.baseUrl,
          Profile: profile.name,
          'Signed in as': `${me.user.name} <${me.user.email}>`,
          Roles: me.user.roles,
          Token: me.apiToken ? `${me.apiToken.name} (${me.apiToken.scopes.join(', ')})` : 'none (a browser session)',
          Permissions: `${me.permissions.length} permission${me.permissions.length === 1 ? '' : 's'}`,
        });
      },
    },
    profiles: {
      summary: 'List saved profiles',
      usage: 'vaultpanel profiles [--use name]',
      needsClient: false,
      run({ out, flags, env }) {
        const config = readConfig(env);
        if (flags.use) {
          if (!config.profiles[flags.use]) throw new CliError(`No profile called "${flags.use}"`);
          config.defaultProfile = flags.use;
          writeConfig(config, env);
          out.success(`Default profile is now "${flags.use}"`);
          return;
        }
        const rows = Object.entries(config.profiles).map(([name, p]) => ({ name, url: p.url, default: name === config.defaultProfile }));
        out.table(rows, [
          { header: 'Profile', value: (r) => r.name },
          { header: 'Panel', value: (r) => r.url },
          { header: 'Default', value: (r) => r.default },
        ]);
        if (!rows.length && !out.json) out.info(`No profiles yet. Run: vaultpanel login --url https://panel.example.com`);
      },
    },
    tokens: {
      summary: 'List your API tokens (create and revoke them in the panel)',
      usage: 'vaultpanel tokens [--all] [--scopes]',
      async run({ panel, out, flags }) {
        if (flags.scopes) {
          const { items: rows } = await panel.apiTokens.scopes();
          return out.table(rows, [
            { header: 'Scope', value: (r) => r.key },
            { header: 'Name', value: (r) => r.label },
            { header: 'What it allows', value: (r) => r.description },
          ]);
        }
        const data = await panel.apiTokens.list(flags.all ? { all: 'true' } : undefined);
        return out.table(data.items, [
          { header: 'Name', value: (t) => t.name },
          { header: 'Token', value: (t) => `${t.prefix}…` },
          { header: 'Owner', value: (t) => t.user.email },
          { header: 'Scopes', value: (t) => t.scopes },
          { header: 'Last used', value: (t) => relative(t.lastUsedAt) },
          { header: 'State', value: (t) => (t.revokedAt ? 'revoked' : t.expired ? 'expired' : 'active') },
        ]);
      },
    },
  },
};

export { askHidden, resolveProfile };
