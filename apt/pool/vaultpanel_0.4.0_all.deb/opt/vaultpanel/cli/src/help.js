import { COMMANDS } from './commands/index.js';

const GLOBAL_FLAGS = [
  ['--url <url>', "The panel's URL (or VAULTPANEL_URL)"],
  ['--token <token>', 'An API token (or VAULTPANEL_TOKEN)'],
  ['--profile <name>', 'Which saved profile to use'],
  ['--json, -j', 'Print the API reply as JSON, for scripts and jq'],
  ['--quiet, -q', 'Only print what was asked for'],
  ['--help, -h', 'This help, or help for one command'],
  ['--version, -v', "The tool's version"],
];

export function topHelp() {
  const lines = [
    'vaultpanel — manage servers, websites, apps, databases and containers from the terminal',
    '',
    'Usage:',
    '  vaultpanel <command> [subcommand] [arguments] [flags]',
    '',
    'Getting started:',
    '  1. In the panel, open Users & Access > API Tokens and create a token.',
    '  2. vaultpanel login --url https://panel.example.com',
    '  3. vaultpanel whoami',
    '',
    'Commands:',
  ];
  const width = Math.max(...Object.keys(COMMANDS).map((name) => name.length));
  for (const [name, group] of Object.entries(COMMANDS)) {
    lines.push(`  ${name.padEnd(width)}  ${group.summary}`);
  }
  lines.push('', 'Flags:');
  const flagWidth = Math.max(...GLOBAL_FLAGS.map(([flag]) => flag.length));
  for (const [flag, what] of GLOBAL_FLAGS) lines.push(`  ${flag.padEnd(flagWidth)}  ${what}`);
  lines.push('', 'Help for one command:', '  vaultpanel servers --help', '  vaultpanel apps deploy --help');
  return lines.join('\n');
}

export function groupHelp(name, group) {
  const lines = [`vaultpanel ${name} — ${group.summary}`, '', 'Commands:'];
  const width = Math.max(...Object.keys(group.commands).map((c) => c.length));
  for (const [command, spec] of Object.entries(group.commands)) {
    lines.push(`  ${command.padEnd(width)}  ${spec.summary}`);
  }
  lines.push('', `Help for one of them: vaultpanel ${name} ${Object.keys(group.commands)[0]} --help`);
  return lines.join('\n');
}

export function commandHelp(path, command) {
  const lines = [`vaultpanel ${path} — ${command.summary}`, '', 'Usage:', `  ${command.usage ?? `vaultpanel ${path}`}`];
  if (command.details) lines.push('', command.details);
  return lines.join('\n');
}
