import { createHmac, timingSafeEqual } from 'node:crypto';

// Helpers for plugin authors (see https://docs.vaultpanel.net/developers/plugins). A plugin gets two
// credentials when it is installed: a token (vpp_...) for calling the API
// with `new VaultPanel({ token })`, and a signing secret (whsec_...) that the
// panel signs two things with:
//   - every event it sends to the plugin's webhookUrl, and
//   - the link that opens the plugin's page inside the panel.
// Both checks below run in constant time and refuse old signatures, so a
// captured request or link cannot be replayed later.

const DEFAULT_TOLERANCE_SECONDS = 300;

function hmac(secret, value) {
  return createHmac('sha256', secret).update(value).digest('hex');
}

function sameHex(a, b) {
  const left = Buffer.from(String(a ?? ''));
  const right = Buffer.from(String(b ?? ''));
  return left.length === right.length && timingSafeEqual(left, right);
}

const header = (headers, name) => {
  if (!headers) return undefined;
  if (typeof headers.get === 'function') return headers.get(name) ?? undefined;
  const key = Object.keys(headers).find((k) => k.toLowerCase() === name.toLowerCase());
  const value = key ? headers[key] : undefined;
  return Array.isArray(value) ? value[0] : value;
};

/**
 * Checks an event the panel sent. Pass the raw request body (the exact
 * bytes, before JSON.parse) and the request headers.
 *
 *   const event = verifyEvent({ body: rawBody, headers: req.headers, secret });
 *   if (!event) return res.writeHead(401).end();
 *
 * Returns the parsed event ({ id, event, occurredAt, data }) or null.
 */
export function verifyEvent({ body, headers, secret, toleranceSeconds = DEFAULT_TOLERANCE_SECONDS, now = Date.now() }) {
  if (!secret) throw new Error('verifyEvent needs the plugin signing secret');
  const raw = Buffer.isBuffer(body) ? body.toString('utf8') : String(body ?? '');
  const timestamp = header(headers, 'x-vaultpanel-timestamp');
  const signature = header(headers, 'x-vaultpanel-signature');
  if (!timestamp || !signature?.startsWith('sha256=')) return null;
  if (!/^\d+$/.test(timestamp) || Math.abs(now / 1000 - Number(timestamp)) > toleranceSeconds) return null;
  if (!sameHex(signature.slice('sha256='.length), hmac(secret, `${timestamp}.${raw}`))) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Checks the link the panel opened the plugin's page with. Pass the request
 * URL (or its query string, or a URLSearchParams).
 *
 *   const viewer = verifyLaunch(req.url, secret);
 *   if (!viewer) return res.writeHead(403).end('Open this page from VaultPanel');
 *
 * Returns { plugin, user: { id, email, roles }, panelUrl, theme, issuedAt }
 * or null.
 */
export function verifyLaunch(input, secret, { maxAgeSeconds = DEFAULT_TOLERANCE_SECONDS, now = Date.now() } = {}) {
  if (!secret) throw new Error('verifyLaunch needs the plugin signing secret');
  const search = input instanceof URLSearchParams ? input : new URLSearchParams(String(input ?? '').replace(/^[^?]*\?/, '').replace(/^\?/, ''));
  const params = Object.fromEntries([...search].filter(([key]) => key.startsWith('vp_')));
  if (!params.vp_sig || !params.vp_ts || !/^\d+$/.test(params.vp_ts)) return null;
  const age = now / 1000 - Number(params.vp_ts);
  if (age > maxAgeSeconds || age < -60) return null;
  if (!sameHex(params.vp_sig, hmac(secret, launchSigningString(params)))) return null;
  return {
    plugin: params.vp_plugin,
    user: { id: params.vp_user, email: params.vp_email, roles: params.vp_roles ? params.vp_roles.split(',') : [] },
    panelUrl: params.vp_panel,
    theme: params.vp_theme === 'dark' ? 'dark' : 'light',
    issuedAt: new Date(Number(params.vp_ts) * 1000),
  };
}

// Every vp_ parameter but the signature, sorted, as key=value joined by "&".
// The same as pluginLaunchSigningString in the panel (shared/src/plugins.js).
export function launchSigningString(params) {
  return Object.keys(params)
    .filter((key) => key.startsWith('vp_') && key !== 'vp_sig')
    .sort()
    .map((key) => `${key}=${params[key]}`)
    .join('&');
}
