import { HttpClient } from './client.js';
import { VaultPanelError } from './errors.js';
import { buildResources, FINAL_JOB_STATUSES } from './resources.js';

export { VaultPanelError };

// What an API token looks like (vpt_ and 43 more characters). Checking the
// shape first catches a pasted password or a truncated copy before any call.
export const API_TOKEN_PATTERN = /^vpt_[A-Za-z0-9_-]{40,80}$/;
export function isApiToken(value) {
  return typeof value === 'string' && API_TOKEN_PATTERN.test(value);
}
export { HttpClient };
// For plugin authors: check the events and page links the panel signs.
export { launchSigningString, verifyEvent, verifyLaunch } from './plugin.js';

/**
 * A client for the VaultPanel REST API.
 *
 *   import { VaultPanel } from '@vaultpanel/sdk';
 *
 *   const panel = new VaultPanel({ baseUrl: 'https://panel.example.com', token: process.env.VAULTPANEL_TOKEN });
 *   const { items } = await panel.servers.list();
 *   const { job } = await panel.applications.deploy(appId);
 *   await panel.jobs.wait(job.id);
 *
 * The token is an API token made in the panel under Users & Access > API Tokens. It
 * acts as the person who made it, narrowed to the scopes it was given, so the
 * SDK can never do more than that person can.
 */
export class VaultPanel {
  constructor(options = {}) {
    // Environment defaults only where there is an environment (Node, Deno,
    // Bun); in a browser both must be passed.
    const env = globalThis.process?.env ?? {};
    const { baseUrl = env.VAULTPANEL_URL, token = env.VAULTPANEL_TOKEN, ...rest } = options;
    this.http = new HttpClient({ baseUrl, token, ...rest });
    Object.assign(this, buildResources(this.http, this));
  }

  get baseUrl() {
    return this.http.baseUrl;
  }

  // Who the token belongs to and what it may do.
  me() {
    return this.http.request('GET', '/auth/me');
  }

  // Any endpoint, for anything the resources above do not wrap yet:
  //   await panel.request('POST', '/servers/ID/jobs', { body: { ... } });
  request(method, path, options) {
    return this.http.request(method, path, options);
  }

  // The whole envelope: { success, data, message, requestId }.
  raw(method, path, options) {
    return this.http.request(method, path, { ...options, raw: true });
  }

  // Walks a paginated list endpoint, yielding one item at a time.
  async *paginate(path, query = {}) {
    let page = query.page ?? 1;
    for (;;) {
      const data = await this.http.request('GET', path, { query: { ...query, page } });
      const items = data?.items ?? [];
      for (const item of items) yield item;
      const pagination = data?.pagination;
      if (!pagination || page >= pagination.totalPages || items.length === 0) return;
      page += 1;
    }
  }

  // Every item of a paginated list endpoint.
  async listAll(path, query = {}) {
    const all = [];
    for await (const item of this.paginate(path, query)) all.push(item);
    return all;
  }

  // Waits for a background job (deployment, website creation, backup...) to
  // finish. Long operations run in the panel's queue, so the API answers with
  // a job and the real outcome arrives later.
  async waitForJob(id, { timeoutMs = 600_000, intervalMs = 2_000, onProgress } = {}) {
    const jobId = typeof id === 'object' ? (id?.job?.id ?? id?.id) : id;
    if (!jobId) throw new VaultPanelError('No job id to wait for', { code: 'CONFIG' });
    const deadline = Date.now() + timeoutMs;
    let lastLogId = 0;
    for (;;) {
      const data = await this.http.request('GET', `/jobs/${jobId}`, { query: { afterLogId: lastLogId } });
      const job = data?.job ?? data;
      for (const line of data?.logs ?? []) lastLogId = Math.max(lastLogId, Number(line.id ?? 0));
      onProgress?.(job, data?.logs ?? []);
      if (FINAL_JOB_STATUSES.has(job?.status)) return { job, logs: data?.logs ?? [] };
      if (Date.now() >= deadline) {
        throw new VaultPanelError(`Job ${jobId} was still ${job?.status ?? 'running'} after ${Math.round(timeoutMs / 1000)}s`, {
          code: 'JOB_WAIT_TIMEOUT',
          details: { jobId, status: job?.status ?? null },
        });
      }
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
    }
  }
}

export function createClient(options) {
  return new VaultPanel(options);
}

export default VaultPanel;
