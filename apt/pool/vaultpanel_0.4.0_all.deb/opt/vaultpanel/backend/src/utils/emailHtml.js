// The HTML part of the emails the panel sends (services/panelEmailService.js):
// one layout for invites, password resets, alerts and test messages. Every
// message also has a plain text part, so mail apps that do not show HTML
// lose nothing.
//
// Email clients support little CSS: the layout is tables with inline styles,
// the button is a coloured table cell (it shows in Outlook too), there are no
// images (many apps block them), and the dark styles only apply where the
// app supports them. Every value is escaped.

export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

const FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
const MONO = "ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace";

// The colour of the small label above the title.
const TONES = {
  danger: '#b91c1c',
  warning: '#a35200',
  success: '#15803d',
  info: '#1d4ed8',
};

// Only http(s) links go into an href.
const safeUrl = (url) => (/^https?:\/\//i.test(String(url ?? '')) ? String(url) : null);
const hostOf = (url) => String(url ?? '').replace(/^https?:\/\//i, '').replace(/\/+$/, '');

/**
 * @param {object} message
 * @param {string} message.title          the heading
 * @param {string} [message.preheader]    the preview line mail apps show next to the subject
 * @param {string} [message.eyebrow]      a short label above the title
 * @param {'danger'|'warning'|'success'|'info'} [message.tone]  the label's colour
 * @param {string[]} [message.paragraphs]
 * @param {{ label: string, url: string }} [message.button]
 * @param {Array<[string, string]>} [message.details]  label and value pairs
 * @param {string} [message.link]         a link to repeat in full under the button
 * @param {string} [message.note]         small print under the content
 * @param {string} [message.footer]       why the person gets this email
 * @param {string} message.panelUrl       the panel's address, in the footer
 */
export function renderEmail({ title, preheader, eyebrow, tone = 'info', paragraphs = [], button, details = [], detailsFirst = false, link, note, footer, panelUrl }) {
  const buttonUrl = safeUrl(button?.url);
  const linkUrl = safeUrl(link);
  const panel = safeUrl(panelUrl);
  const toneKey = TONES[tone] ? tone : 'info';
  const shownDetails = details.filter(([, value]) => value !== null && value !== undefined && value !== '');

  // Each block gets its bottom margin when it is drawn: the last one sits
  // flush with the card's padding.
  const blocks = [];
  if (eyebrow) {
    blocks.push(
      (mb = 10) =>
        `<p class="vp-tone-${toneKey}" style="margin:0 0 ${mb}px;font-size:12px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;color:${TONES[toneKey]};">${escapeHtml(eyebrow)}</p>`,
    );
  }
  blocks.push((mb = 18) => `<h1 class="vp-text" style="margin:0 0 ${mb}px;font-size:22px;line-height:1.3;font-weight:600;color:#18181b;">${escapeHtml(title)}</h1>`);
  for (const text of paragraphs) {
    blocks.push((mb = 16) => `<p class="vp-text" style="margin:0 0 ${mb}px;font-size:15px;line-height:1.6;color:#3f3f46;">${escapeHtml(text)}</p>`);
  }
  const buttonBlock =
    buttonUrl &&
    ((mb = 28) =>
      `<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:8px 0 ${mb}px;"><tr>` +
      `<td align="center" bgcolor="#2563eb" style="border-radius:8px;background:#2563eb;">` +
      `<a href="${escapeHtml(buttonUrl)}" target="_blank" rel="noopener" style="display:inline-block;padding:13px 24px;font-family:${FONT};font-size:15px;font-weight:600;line-height:1;color:#ffffff;text-decoration:none;border-radius:8px;">${escapeHtml(button.label)}</a>` +
      `</td></tr></table>`);
  const detailsBlock =
    shownDetails.length > 0 &&
    ((mb = 24) => {
      const rows = shownDetails
        .map(
          ([label, value]) =>
            `<tr><td class="vp-muted vp-rule" valign="top" style="padding:11px 16px 11px 0;width:34%;border-bottom:1px solid #e4e4e7;font-size:13px;line-height:1.5;color:#71717a;">${escapeHtml(label)}</td>` +
            `<td class="vp-text vp-rule" valign="top" style="padding:11px 0;border-bottom:1px solid #e4e4e7;font-size:13px;line-height:1.5;color:#18181b;word-break:break-word;">${escapeHtml(value)}</td></tr>`,
        )
        .join('');
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="vp-rule" style="margin:0 0 ${mb}px;border-top:1px solid #e4e4e7;">${rows}</table>`;
    });
  // Alerts read better with what happened first, then the button.
  for (const block of detailsFirst ? [detailsBlock, buttonBlock] : [buttonBlock, detailsBlock]) if (block) blocks.push(block);
  if (linkUrl) {
    blocks.push((mb = 8) => `<p class="vp-muted" style="margin:0 0 ${mb}px;font-size:13px;line-height:1.5;color:#71717a;">If the button does not work, copy this link into your browser:</p>`);
    blocks.push(
      (mb = 24) =>
        `<p style="margin:0 0 ${mb}px;"><a href="${escapeHtml(linkUrl)}" target="_blank" rel="noopener" class="vp-code" style="display:block;padding:11px 13px;background:#f4f4f5;border:1px solid #e4e4e7;border-radius:6px;font-family:${MONO};font-size:12px;line-height:1.5;color:#18181b;text-decoration:none;word-break:break-all;">${escapeHtml(linkUrl)}</a></p>`,
    );
  }
  if (note) blocks.push((mb = 0) => `<p class="vp-muted" style="margin:0 0 ${mb}px;font-size:13px;line-height:1.55;color:#71717a;">${escapeHtml(note)}</p>`);
  const parts = blocks.map((block, i) => (i === blocks.length - 1 ? block(0) : block()));

  const footerLines = [];
  if (footer) footerLines.push(escapeHtml(footer));
  footerLines.push(panel ? `Sent by VaultPanel at <a href="${escapeHtml(panel)}" target="_blank" rel="noopener" class="vp-muted" style="color:#71717a;text-decoration:underline;">${escapeHtml(hostOf(panel))}</a>` : 'Sent by VaultPanel');

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="supported-color-schemes" content="light dark">
<title>${escapeHtml(title)}</title>
<style>
@media (prefers-color-scheme: dark) {
  .vp-bg { background:#000000 !important; }
  .vp-card { background:#0a0a0a !important; border-color:#262626 !important; }
  .vp-text { color:#ededed !important; }
  .vp-muted { color:#a1a1a1 !important; }
  .vp-rule { border-color:#262626 !important; }
  .vp-code { background:#141414 !important; border-color:#262626 !important; color:#ededed !important; }
  .vp-tone-danger { color:#f87171 !important; }
  .vp-tone-warning { color:#fbbf24 !important; }
  .vp-tone-success { color:#4ade80 !important; }
  .vp-tone-info { color:#7aa2ff !important; }
}
@media (max-width: 600px) {
  .vp-pad { padding:28px 22px !important; }
}
</style>
</head>
<body class="vp-bg" style="margin:0;padding:0;background:#f4f4f5;-webkit-text-size-adjust:100%;">
<div style="display:none;max-height:0;max-width:0;overflow:hidden;opacity:0;mso-hide:all;">${escapeHtml(preheader ?? '')}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="vp-bg" style="background:#f4f4f5;">
<tr><td align="center" style="padding:32px 12px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;font-family:${FONT};">
<tr><td style="padding:0 4px 20px;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
<td width="28" height="28" align="center" valign="middle" bgcolor="#2f6bff" style="width:28px;height:28px;border-radius:7px;background:#2f6bff;font-family:${FONT};font-size:15px;font-weight:700;line-height:28px;color:#ffffff;">V</td>
<td class="vp-text" style="padding-left:10px;font-family:${FONT};font-size:17px;font-weight:600;color:#18181b;">VaultPanel</td>
</tr></table>
</td></tr>
<tr><td class="vp-card" style="background:#ffffff;border:1px solid #e4e4e7;border-radius:12px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
<td class="vp-pad" style="padding:36px 40px;font-family:${FONT};">
${parts.join('\n')}
</td></tr></table>
</td></tr>
<tr><td class="vp-muted" align="center" style="padding:20px 12px 0;font-family:${FONT};font-size:12px;line-height:1.6;color:#71717a;">
${footerLines.join('<br>')}
</td></tr>
</table>
</td></tr>
</table>
</body>
</html>`;
}

// The label colour for a panel event (the same events webhooks carry).
export function toneOfEvent(event) {
  const e = String(event ?? '');
  if (/(fail|fired|offline|down|expired|error)/.test(e)) return 'danger';
  if (/(expiring|warn)/.test(e)) return 'warning';
  if (/(succeeded|success|resolved|online|\.up$|renewed|restored|completed)/.test(e)) return 'success';
  return 'info';
}
