import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { PERMISSIONS, certificateCovers } from '@vaultpanel/shared';
import { getSetting } from '../models/settingModel.js';
import { toPublicCertificate } from '../models/websiteModel.js';
import { AppError } from '../utils/errors.js';
import { systemActor } from './actor.js';
import { fromJson, toJson } from '../utils/json.js';

// The panel's own domain (Panel Domain page): VaultPanel on a name such as
// cp.example.com with a Let's Encrypt certificate.
//
// It is an ordinary reverse proxy website on This server (the server the
// panel runs on), pointing at the port the panel listens on, so NGINX, the
// certificate and its renewal all go through the agent's normal website
// operations. The panel's IP address and port keep working alongside it, so a
// DNS or certificate mistake never locks anyone out.
//
// Once the domain has a trusted certificate it can become the panel's
// address: the one used in agent install commands, password reset links and
// deploy webhooks (config.publicUrl).

export const PANEL_SITE_NAME = 'vaultpanel-web';
const DOMAIN_KEY = 'panel.domain';
const ADDRESS_KEY = 'panel.public_url';
const SETTINGS_TARGET = { type: 'settings', id: 'panel-domain', label: 'Panel domain' };

// The Vite dev server reads this list to accept the domain (vite.config.js).
export function panelHostsFile(config) {
  return path.join(config.dataDir, 'panel-hosts.json');
}

async function writeHostsFile(config, domain, logger) {
  try {
    await mkdir(config.dataDir, { recursive: true });
    await writeFile(panelHostsFile(config), `${JSON.stringify({ hosts: domain ? [domain] : [] })}\n`);
  } catch (err) {
    logger?.warn({ err }, 'could not write the panel hosts file');
  }
}

// Whether the panel domain can be given out: its website is active and has a
// browser-trusted certificate (not a staging one) that covers the domain and
// has not expired.
function domainReady(site, cert, domain) {
  return Boolean(
    site?.status === 'active' &&
      domain &&
      cert?.status === 'active' &&
      !cert.isStaging &&
      cert.state !== 'expired' &&
      certificateCovers(cert.domains, domain),
  );
}

// The address to give people: in emails and in invite and password reset
// links. That is the panel domain as soon as it is ready, whether or not it
// was also made the panel's address (which moves agent install commands too,
// and other servers must be able to reach it first). Otherwise the panel's
// configured address, such as its IP address and port.
export async function peopleUrl({ db, config, logger }) {
  try {
    if (await getSetting(db, ADDRESS_KEY)) return config.publicUrl;
    const panel = fromJson(await getSetting(db, DOMAIN_KEY), null);
    if (panel?.websiteId && panel.domain && !panel.removing) {
      const [site, certificate] = await Promise.all([
        db('websites').where({ id: panel.websiteId }).first(),
        db('ssl_certificates').where({ website_id: panel.websiteId }).first(),
      ]);
      if (domainReady(site, toPublicCertificate(certificate), panel.domain)) return `https://${panel.domain}`;
    }
  } catch (err) {
    logger?.warn({ err }, 'could not check the panel domain; using the panel address');
  }
  return config.publicUrl;
}

// Loads the address set on the Panel Domain page into the config. The API
// calls it at startup (and the service on every change, with writeHosts so
// the Vite dev server learns the domain); the worker calls it regularly,
// since it cannot hear about changes.
export async function loadPanelAddress({ db, config, logger }, { writeHosts = false } = {}) {
  const [address, stored] = await Promise.all([getSetting(db, ADDRESS_KEY), getSetting(db, DOMAIN_KEY)]);
  config.setPublicUrlOverride?.(address);
  if (writeHosts) await writeHostsFile(config, fromJson(stored, null)?.domain ?? null, logger);
  return address;
}

export function createPanelDomainService({ db, config, logger, audit, authorize, websites, hosting }) {
  async function save(key, value, actor) {
    const now = new Date();
    await db('settings').insert({ key, value, is_secret: false, updated_by: actor?.id ?? null, updated_at: now }).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
  }

  async function stored() {
    return fromJson(await getSetting(db, DOMAIN_KEY), null);
  }

  async function setAddress(url, actor) {
    if (url) await save(ADDRESS_KEY, url, actor);
    else await db('settings').where({ key: ADDRESS_KEY }).delete();
    config.setPublicUrlOverride?.(url);
  }

  async function clear() {
    await db('settings').whereIn('key', [DOMAIN_KEY, ADDRESS_KEY]).delete();
    config.setPublicUrlOverride?.(null);
    await writeHostsFile(config, null, logger);
  }

  function localServer() {
    return db('servers').where({ is_local: true }).whereNull('deleted_at').orderBy('created_at').first();
  }

  // The port NGINX passes the domain on to: the panel's own port when it
  // serves the web interface itself (install.sh), else the port of its
  // configured address (the Vite dev server, 5173).
  function defaultPort() {
    // With HTTPS on its own port, NGINX talks to the panel's plain HTTP
    // loopback port instead (NGINX terminates TLS for the domain).
    if (config.loopbackPort) return config.loopbackPort;
    if (config.uiDir) return config.port;
    try {
      const url = new URL(config.envPublicUrl ?? config.publicUrl);
      if (url.port) return Number(url.port);
    } catch {
      // validated at startup
    }
    return 5173;
  }

  async function website(actor, panel) {
    if (!panel?.websiteId) return null;
    try {
      return await websites.get(actor, panel.websiteId);
    } catch (err) {
      if (err.status === 404) return null;
      throw err;
    }
  }

  async function state(actor) {
    let panel = await stored();
    let site = await website(actor, panel);
    if (panel && !site) {
      // The website is gone (removed from this page or with its server).
      await clear();
      panel = null;
      site = null;
    }
    if (site?.customerId && (await hosting?.releaseToStaff('website', site.id))) {
      // Older panels let staff give it to a hosting customer.
      site = await website(actor, panel);
    }
    const server = await localServer();
    const address = await getSetting(db, ADDRESS_KEY);
    const cert = site?.ssl;
    return {
      domain: panel?.domain ?? null,
      // Remove was clicked: the website is being deleted, or deleting it
      // failed (then Remove can be tried again, or Save keeps the domain).
      removing: Boolean(panel?.removing),
      website: site,
      server: server
        ? {
            id: server.id,
            name: server.name,
            status: server.status,
            publicIp: server.public_ip,
            ipAddresses: fromJson(server.ip_addresses, []),
            webStack: fromJson(server.web_stack, null),
          }
        : null,
      defaultPort: defaultPort(),
      address: {
        current: config.publicUrl,
        environment: config.envPublicUrl ?? config.publicUrl,
        usesDomain: Boolean(address),
        // A browser-trusted certificate is needed: agents on other servers
        // refuse untrusted ones.
        canUseDomain: domainReady(site, cert, panel?.domain),
      },
    };
  }

  async function get(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    return state(actor);
  }

  // Puts the panel on a domain, or moves it to another one.
  async function set(actor, { domain, proxyPort }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const port = proxyPort ?? defaultPort();
    const panel = await stored();
    const site = await website(actor, panel);
    let job;
    if (site && !site.provisioned) {
      // The first attempt to create it failed: try again, or start over.
      if (site.primaryDomain !== domain || site.proxyPort !== port) {
        throw new AppError(409, 'PANEL_WEBSITE_FAILED', 'Setting up the current domain failed. Try it again, or remove it before adding another domain.');
      }
      ({ job } = await websites.retry(actor, site.id));
    } else if (site) {
      if (site.primaryDomain === domain && site.proxyPort === port && !panel.removing) return { ...(await state(actor)), job: null };
      // The certificate will not cover the new domain, so the address goes
      // back to the IP until it has one.
      if (site.primaryDomain !== domain) await setAddress(null, actor);
      ({ job } = await websites.update(actor, site.id, { domains: [domain], proxyPort: port }, { fromPanel: true }));
    } else {
      const server = await localServer();
      if (!server) {
        throw new AppError(409, 'NO_LOCAL_SERVER', 'The server VaultPanel runs on is not connected as "This server", so there is nowhere to put the domain. Start the panel as root once so it connects its own server.');
      }
      const created = await websites.create(actor, { serverId: server.id, name: PANEL_SITE_NAME, type: 'proxy', domains: [domain], proxyPort: port });
      job = created.job;
      await save(DOMAIN_KEY, toJson({ websiteId: created.website.id, domain }), actor);
    }
    if (site) await save(DOMAIN_KEY, toJson({ websiteId: site.id, domain }), actor);
    await writeHostsFile(config, domain, logger);
    await audit.record({ actor, action: 'panel.domain_set', target: SETTINGS_TARGET, metadata: { domain, previous: panel?.domain ?? null, proxyPort: port, jobId: job?.id ?? null } });
    return { ...(await state(actor)), job };
  }

  // Makes https://<domain> the panel's address, or goes back to the one in
  // the environment (.env).
  async function useDomain(actor, { use }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const current = await state(actor);
    if (use) {
      if (!current.address.canUseDomain) {
        throw new AppError(409, 'PANEL_DOMAIN_NOT_READY', 'The domain needs a trusted certificate first (not a staging one). Issue a certificate, then try again.');
      }
      await setAddress(`https://${current.domain}`, actor);
    } else {
      await setAddress(null, actor);
    }
    await audit.record({ actor, action: use ? 'panel.address_domain' : 'panel.address_environment', target: SETTINGS_TARGET, metadata: { address: config.publicUrl } });
    return state(actor);
  }

  // Takes the panel off its domain: removes the website (NGINX block and
  // certificate) from This server. The IP address keeps working. The setting
  // stays (marked removing) until the website is really gone, so it stays
  // off the lists of websites meanwhile, and if deleting it fails.
  async function remove(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const panel = await stored();
    const site = await website(actor, panel);
    let job = null;
    if (site) {
      ({ job } = await websites.remove(actor, site.id, { removeFiles: true }, { fromPanel: true }));
      await setAddress(null, actor);
      await save(DOMAIN_KEY, toJson({ websiteId: site.id, domain: panel.domain, removing: true }), actor);
      await writeHostsFile(config, null, logger);
    } else {
      await clear();
    }
    if (panel) await audit.record({ actor, action: 'panel.domain_remove', target: SETTINGS_TARGET, metadata: { domain: panel.domain, jobId: job?.id ?? null } });
    return { ...(await state(actor)), job };
  }

  // Called when the API starts. A panel domain added while the panel used
  // plain HTTP sends requests to the panel's port; once that port is HTTPS
  // (vaultpanel https on), the domain moves to the loopback port so it keeps
  // working. Returns the job, or null when nothing needed to change.
  async function followPanelPort() {
    if (!config.loopbackPort) return null;
    const panel = await stored();
    if (!panel?.websiteId || panel.removing) return null;
    const actor = systemActor('panel https');
    const site = await website(actor, panel);
    if (!site?.provisioned || site.proxyPort !== config.port) return null;
    const { job } = await websites.update(actor, site.id, { domains: [panel.domain], proxyPort: config.loopbackPort }, { fromPanel: true });
    await audit.record({ actor, action: 'panel.domain_set', target: SETTINGS_TARGET, metadata: { domain: panel.domain, proxyPort: config.loopbackPort, previousProxyPort: config.port, reason: 'https', jobId: job?.id ?? null } });
    logger?.info({ domain: panel.domain, port: config.loopbackPort }, 'panel domain now points at the loopback port');
    return job;
  }

  return { get, set, useDomain, remove, followPanelPort };
}
