import { randomUUID } from 'node:crypto';
import { isIP } from 'node:net';
import nodemailer from 'nodemailer';
import {
  PANEL_EMAIL_DEFAULT_EVENTS,
  PANEL_EMAIL_MAX_ATTEMPTS,
  PANEL_EMAIL_SECURITY,
  PERMISSIONS,
  WEBHOOK_EVENTS,
} from '@vaultpanel/shared';
import { AppError, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { renderEmail, toneOfEvent } from '../utils/emailHtml.js';
import { fromJson, toJson } from '../utils/json.js';
import { addSeconds, toIso } from '../utils/time.js';
import { peopleUrl } from './panelDomainService.js';
import { summarize } from './webhookService.js';

// Email the panel sends itself (System > Panel Email), through an SMTP server the
// owner enters: invite and password reset links, alerts, and test messages.
// This is not the email hosting on servers (Web > Email, mailService.js),
// although a mailbox made there can be the account the panel sends from.
//
// Every message is stored in email_messages with its body sealed, since a
// reset link in it signs someone in. Links are sent at once so whoever
// issued them knows whether the email went; alerts are sent by the worker
// (deliver(), every maintenance run). Failures are retried with backoff.

const CONFIG_KEY = 'email.config';
const PASSWORD_KEY = 'email.password';
const SETTINGS_TARGET = { type: 'settings', id: 'email', label: 'Panel email' };
const RETRY_SECONDS = [60, 5 * 60, 30 * 60];
const KEPT_DAYS = 30;
const SUBJECT_MAX = 200;

const clean = (value, max = 500) =>
  String(value ?? '')
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001f\u007f]+/g, ' ')
    .trim()
    .slice(0, max);

function transportOptions(s) {
  return {
    host: s.host,
    port: s.port,
    secure: s.security === 'tls',
    requireTLS: s.security === 'starttls',
    ignoreTLS: s.security === 'none',
    auth: s.username ? { user: s.username, pass: s.password ?? '' } : undefined,
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
    socketTimeout: 20_000,
    // Certificates are checked against the host name (not for an IP address).
    tls: isIP(s.host) ? {} : { servername: s.host },
  };
}

// Turns an SMTP or network error into a sentence the owner can act on.
export function explainSmtpError(err) {
  const code = err?.code;
  const detail = clean(err?.response || err?.message || 'unknown error', 300);
  if (code === 'EAUTH') return `The mail server refused the user name or password (${detail})`;
  if (code === 'ESOCKET' && /ENOTFOUND|EAI_AGAIN/.test(err?.message ?? '')) return 'The mail server name could not be found (check the host)';
  if (code === 'ESOCKET' && /ECONNREFUSED/.test(err?.message ?? '')) return 'The mail server refused the connection (check the host and port)';
  if (code === 'ETIMEDOUT' || code === 'ECONNECTION' || /timeout/i.test(err?.message ?? '')) {
    return 'The mail server did not answer in time. Check the host and port, and whether your hosting provider blocks outgoing mail ports';
  }
  if (/wrong version number|ssl3_get_record|EPROTO/i.test(err?.message ?? '')) return 'TLS failed. Try the other security option for this port (SSL/TLS for 465, STARTTLS for 587)';
  if (/self.signed|unable to verify|certificate/i.test(err?.message ?? '')) return `The mail server's certificate is not trusted for this host name (${detail})`;
  if (code === 'EENVELOPE' || err?.responseCode >= 500) return `The mail server refused the message (${detail})`;
  return detail;
}

export function createPanelEmailService({ db, config, logger, audit, authorize, createTransport = nodemailer.createTransport }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'panel-email'));

  // ---- Settings -------------------------------------------------------------

  async function readSettings() {
    const rows = await db('settings').whereIn('key', [CONFIG_KEY, PASSWORD_KEY]);
    const stored = fromJson(rows.find((r) => r.key === CONFIG_KEY)?.value, {});
    const sealed = rows.find((r) => r.key === PASSWORD_KEY)?.value ?? null;
    let password = null;
    if (sealed) {
      try {
        password = box.open(sealed);
      } catch (err) {
        logger.error({ err }, 'panel email: the stored SMTP password cannot be decrypted (was VAULTPANEL_SECRET_KEY changed?)');
      }
    }
    const security = PANEL_EMAIL_SECURITY[stored.security] ? stored.security : 'starttls';
    const alerts = stored.alerts ?? {};
    return {
      enabled: Boolean(stored.enabled),
      host: stored.host ?? null,
      port: stored.port ?? PANEL_EMAIL_SECURITY[security].port,
      security,
      username: stored.username ?? null,
      password,
      fromAddress: stored.fromAddress ?? null,
      fromName: stored.fromName ?? 'VaultPanel',
      alerts: {
        events: Array.isArray(alerts.events) ? alerts.events.filter((e) => WEBHOOK_EVENTS[e]) : [...PANEL_EMAIL_DEFAULT_EVENTS],
        toAdmins: alerts.toAdmins ?? true,
        extra: Array.isArray(alerts.extra) ? alerts.extra : [],
      },
      updatedAt: stored.updatedAt ?? null,
    };
  }

  function missingSetting(s) {
    if (!s.host) return 'Enter the mail server (SMTP host)';
    if (!s.port) return 'Enter the port';
    if (!s.fromAddress) return 'Enter the address emails come from';
    if (s.username && !s.password) return 'Enter the password';
    return null;
  }

  const ready = (s) => s.enabled && !missingSetting(s);

  function publicSettings(s) {
    return {
      enabled: s.enabled,
      host: s.host,
      port: s.port,
      security: s.security,
      username: s.username,
      hasPassword: Boolean(s.password),
      fromAddress: s.fromAddress,
      fromName: s.fromName,
      alerts: s.alerts,
      missing: missingSetting(s),
      ready: ready(s),
      updatedAt: s.updatedAt,
    };
  }

  async function getSettings(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    return publicSettings(await readSettings());
  }

  // Whether the panel can send email now (the login page's "Forgot
  // password?" and the invite messages depend on it).
  async function isReady() {
    return ready(await readSettings());
  }

  // Fields left out keep their value. password: a string sets it, null
  // removes it. A new host drops the old password unless one comes along.
  function merge(current, input) {
    const hostChanged = input.host !== undefined && input.host !== current.host;
    let password = input.password === undefined ? (hostChanged ? null : current.password) : input.password;
    if (typeof password === 'string' && !password) password = null;
    return {
      enabled: input.enabled ?? current.enabled,
      host: input.host === undefined ? current.host : input.host || null,
      port: input.port ?? current.port,
      security: input.security ?? current.security,
      username: input.username === undefined ? current.username : input.username || null,
      password,
      fromAddress: input.fromAddress === undefined ? current.fromAddress : input.fromAddress || null,
      fromName: input.fromName === undefined ? current.fromName : input.fromName || 'VaultPanel',
      alerts: { ...current.alerts, ...(input.alerts ?? {}) },
    };
  }

  async function updateSettings(actor, input) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const current = await readSettings();
    const next = merge(current, input);
    const missing = missingSetting(next);
    if (next.enabled && missing) {
      const field = /password/i.test(missing) ? 'password' : /port/i.test(missing) ? 'port' : /from/i.test(missing) ? 'fromAddress' : 'host';
      throw validationError([{ field, message: 'Required' }], `${missing} before turning email on`);
    }
    const now = new Date();
    await db.transaction(async (trx) => {
      const { password, ...rest } = next;
      const value = toJson({ ...rest, updatedAt: now.toISOString() });
      await trx('settings').insert({ key: CONFIG_KEY, value, is_secret: false, updated_by: actor.id, updated_at: now }).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
      if (password) {
        await trx('settings').insert({ key: PASSWORD_KEY, value: box.seal(password), is_secret: true, updated_by: actor.id, updated_at: now }).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
      } else {
        await trx('settings').where({ key: PASSWORD_KEY }).delete();
      }
    });
    await audit.record({
      actor,
      action: 'email.settings_update',
      target: SETTINGS_TARGET,
      metadata: {
        enabled: next.enabled,
        host: next.host,
        port: next.port,
        security: next.security,
        username: next.username,
        fromAddress: next.fromAddress,
        alerts: next.alerts,
        password: input.password === undefined ? (next.password === current.password ? 'unchanged' : 'removed') : next.password ? 'changed' : 'removed',
      },
    });
    return publicSettings(await readSettings());
  }

  // Sends a test email with the saved settings, or with the ones being
  // edited (not saved by this). The result comes back at once.
  async function sendTest(actor, { to, settings: draft = {} }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const s = merge(await readSettings(), draft);
    const missing = missingSetting(s);
    if (missing) throw new AppError(422, 'EMAIL_NOT_SET_UP', missing);
    const panelUrl = await peopleUrl({ db, config, logger });
    const server = `${s.host}:${s.port} (${PANEL_EMAIL_SECURITY[s.security].label})`;
    const [id] = await queue(
      [to],
      {
        purpose: 'test',
        subject: 'Test email from VaultPanel',
        text: [
          'This is a test email from VaultPanel.',
          '',
          `It was sent through ${server} from ${s.fromAddress}, at the request of ${actor.label}.`,
          '',
          `If you can read this, the panel can send invites, password reset links and alerts. Panel: ${panelUrl}`,
        ].join('\n'),
        html: renderEmail({
          preheader: 'If you can read this, VaultPanel can send invites, password reset links and alerts.',
          eyebrow: 'Test email',
          tone: 'success',
          title: 'Panel email works',
          paragraphs: ['If you can read this, VaultPanel can send invites, password reset links and alerts.'],
          details: [
            ['Mail server', server],
            ['Sent from', s.fromAddress],
            ['Requested by', actor.label],
            ['Panel', panelUrl],
          ],
          button: { label: 'Open VaultPanel', url: panelUrl },
          footer: 'Sent from System > Panel Email in VaultPanel.',
          panelUrl,
        }),
      },
      { pending: false },
    );
    const result = await attempt(id, { settings: s, retry: false });
    await audit.record({ actor, action: 'email.test', target: SETTINGS_TARGET, result: result.sent ? 'success' : 'failure', metadata: { to, host: s.host, port: s.port, error: result.error ?? null } });
    if (!result.sent) throw new AppError(502, 'EMAIL_SEND_FAILED', result.error);
    return { message: await toPublicMessage(id) };
  }

  // ---- Messages ---------------------------------------------------------------

  async function toPublicMessage(id) {
    const row = await db('email_messages').where({ id }).first();
    return row && publicMessage(row);
  }

  function publicMessage(row) {
    return {
      id: row.id,
      to: row.to_address,
      subject: row.subject,
      purpose: row.purpose,
      event: row.event,
      status: row.status,
      attempts: row.attempts,
      error: row.error,
      nextAttemptAt: toIso(row.next_attempt_at),
      sentAt: toIso(row.sent_at),
      createdAt: toIso(row.created_at),
    };
  }

  async function listMessages(actor, { limit = 50 } = {}) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const rows = await db('email_messages').orderBy('created_at', 'desc').limit(Math.min(Number(limit) || 50, 200));
    return { items: rows.map(publicMessage) };
  }

  // Stores one message per recipient. pending: false leaves it for the
  // caller to send now (no retries from the worker until it fails once).
  async function queue(recipients, { purpose, subject, text, html = null, event = null }, { pending = true } = {}) {
    const now = new Date();
    const rows = [...new Set(recipients.map((r) => String(r).trim().toLowerCase()).filter(Boolean))].map((to) => ({
      id: randomUUID(),
      to_address: to.slice(0, 254),
      subject: clean(subject, SUBJECT_MAX),
      // The HTML part is optional: messages stored before it existed go out as text.
      body_encrypted: box.seal(toJson(html ? { text, html } : { text })),
      purpose,
      event,
      status: 'pending',
      attempts: 0,
      next_attempt_at: pending ? now : null,
      created_at: now,
      updated_at: now,
    }));
    if (rows.length) await db('email_messages').insert(rows);
    return rows.map((r) => r.id);
  }

  // One try at sending a stored message. A message another process is
  // already trying (its attempts changed) is left alone.
  async function attempt(id, { settings, retry = true } = {}) {
    const row = await db('email_messages').where({ id }).first();
    if (!row || row.status !== 'pending') return { sent: row?.status === 'sent', skipped: true };
    const now = new Date();
    const attempts = row.attempts + 1;
    const claimed = await db('email_messages')
      .where({ id, status: 'pending', attempts: row.attempts })
      .update({ attempts, next_attempt_at: addSeconds(now, 120), updated_at: now });
    if (!claimed) return { sent: false, skipped: true };

    const s = settings ?? (await readSettings());
    let error = null;
    if (!settings && !ready(s)) error = 'Panel email is turned off or not set up';
    else {
      try {
        const body = fromJson(box.open(row.body_encrypted), {});
        const transport = createTransport(transportOptions(s));
        try {
          await transport.sendMail({
            from: { name: clean(s.fromName, 100) || 'VaultPanel', address: s.fromAddress },
            to: row.to_address,
            subject: row.subject,
            text: body.text ?? '',
            ...(body.html ? { html: body.html } : {}),
            headers: { 'Auto-Submitted': 'auto-generated', 'X-VaultPanel-Purpose': row.purpose },
          });
        } finally {
          transport.close?.();
        }
      } catch (err) {
        error = explainSmtpError(err);
      }
    }

    const finished = new Date();
    if (!error) {
      await db('email_messages').where({ id }).update({ status: 'sent', error: null, sent_at: finished, next_attempt_at: null, updated_at: finished });
      return { sent: true };
    }
    const giveUp = !retry || attempts >= PANEL_EMAIL_MAX_ATTEMPTS;
    await db('email_messages')
      .where({ id })
      .update({
        status: giveUp ? 'failed' : 'pending',
        error,
        next_attempt_at: giveUp ? null : addSeconds(finished, RETRY_SECONDS[Math.min(attempts - 1, RETRY_SECONDS.length - 1)]),
        updated_at: finished,
      });
    logger.info({ emailId: id, purpose: row.purpose, attempts, error }, 'panel email not sent');
    return { sent: false, error };
  }

  // Sends the messages that are due. Run by the worker.
  async function deliver(now = new Date()) {
    const due = await db('email_messages').where({ status: 'pending' }).where('next_attempt_at', '<=', now).orderBy('next_attempt_at').limit(25);
    if (!due.length) return 0;
    const s = await readSettings();
    let sent = 0;
    for (const row of due) {
      const result = await attempt(row.id, { settings: ready(s) ? s : undefined });
      if (result.sent) sent += 1;
    }
    return sent;
  }

  async function prune(now = new Date()) {
    return db('email_messages').whereNot('status', 'pending').where('created_at', '<', addSeconds(now, -KEPT_DAYS * 86_400)).delete();
  }

  // ---- What the panel sends ------------------------------------------------------

  // An invite or password reset link for one person, sent now. Returns null
  // when panel email is not set up (the link is then handed over by hand).
  async function sendLink({ user, purpose, url, expiresAt, by = null }) {
    const s = await readSettings();
    if (!ready(s)) return null;
    // The panel domain once it has a trusted certificate, else the IP and port
    // (the link was made the same way: userService).
    const panelUrl = await peopleUrl({ db, config, logger });
    const hello = user.name ? `Hello ${clean(user.name, 100)},` : 'Hello,';
    const expires = `${new Date(expiresAt).toISOString().slice(0, 16).replace('T', ' ')} UTC`;
    const creator = by ? clean(by, 254) : null;
    const message =
      purpose === 'invite'
        ? {
            subject: 'Your VaultPanel account',
            text: [
              hello,
              '',
              `${creator ? `${creator} created` : 'An account was created'} a VaultPanel account for you (${user.email}) at ${panelUrl}.`,
              '',
              'Open this link to choose your password and sign in:',
              url,
              '',
              `The link works once and expires on ${expires}.`,
            ].join('\n'),
            html: renderEmail({
              preheader: 'Choose a password to sign in to VaultPanel.',
              eyebrow: 'Welcome',
              title: 'Your VaultPanel account is ready',
              paragraphs: [hello, `${creator ? `${creator} created` : 'An account was created'} a VaultPanel account for you. Choose a password to sign in.`],
              button: { label: 'Choose your password', url },
              details: [
                ['Account', user.email],
                ['Panel', panelUrl],
                ['Link expires', expires],
              ],
              link: url,
              note: `The link works once. Afterwards, sign in at ${panelUrl} with your email address and the password you chose.`,
              footer: 'You get this email because a VaultPanel account was created for you.',
              panelUrl,
            }),
          }
        : {
            subject: 'Reset your VaultPanel password',
            text: [
              hello,
              '',
              `Someone asked to reset the password of your VaultPanel account (${user.email}) at ${panelUrl}.`,
              '',
              'Open this link to choose a new password:',
              url,
              '',
              `The link works once and expires on ${expires}. If you did not ask for this, ignore this email; your password stays the same.`,
            ].join('\n'),
            html: renderEmail({
              preheader: 'Use this link to choose a new password. It works once.',
              eyebrow: 'Password reset',
              title: 'Reset your password',
              paragraphs: [hello, 'Someone asked to reset the password of your VaultPanel account. Choose a new one with the button below.'],
              button: { label: 'Choose a new password', url },
              details: [
                ['Account', user.email],
                ['Panel', panelUrl],
                ['Link expires', expires],
              ],
              link: url,
              note: 'The link works once. If you did not ask for this, ignore this email: your password stays the same.',
              footer: 'You get this email because a password reset was asked for your VaultPanel account.',
              panelUrl,
            }),
          };
    const [id] = await queue([user.email], { purpose, ...message }, { pending: false });
    const result = await attempt(id, { settings: s });
    return { to: user.email, sent: result.sent, error: result.error ?? null };
  }

  async function adminAddresses() {
    const rows = await db('users as u')
      .join('user_roles as ur', 'ur.user_id', 'u.id')
      .join('roles as r', 'r.id', 'ur.role_id')
      .whereIn('r.name', ['owner', 'admin'])
      .where('u.is_active', true)
      .whereNull('u.deleted_at')
      .distinct('u.email');
    return rows.map((r) => r.email);
  }

  // Panel events (the same ones webhooks carry), emailed to the chosen
  // people when the event is ticked on the Email page.
  async function onEvent(event, data) {
    if (!WEBHOOK_EVENTS[event]) return 0;
    const s = await readSettings();
    if (!ready(s) || !s.alerts.events.includes(event)) return 0;
    const recipients = [...(s.alerts.toAdmins ? await adminAddresses() : []), ...s.alerts.extra];
    if (!recipients.length) return 0;
    const summary = clean(summarize(event, data ?? {}), 1000);
    const panelUrl = await peopleUrl({ db, config, logger });
    const time = `${new Date().toISOString().replace('T', ' ').slice(0, 19)} UTC`;
    const serverName = data?.server?.name ? clean(data.server.name, 100) : null;
    const openUrl = `${panelUrl}${eventPath(event, data)}`;
    const why = 'You get this email because of the alert settings on System > Panel Email in VaultPanel.';
    const lines = [summary, '', `Event: ${WEBHOOK_EVENTS[event]} (${event})`, `Time: ${time}`];
    if (serverName) lines.push(`Server: ${serverName}`);
    lines.push('', `Open the panel: ${openUrl}`, '', why);
    const html = renderEmail({
      preheader: summary,
      eyebrow: WEBHOOK_EVENTS[event],
      tone: toneOfEvent(event),
      title: summary,
      details: [
        ['Event', `${WEBHOOK_EVENTS[event]} (${event})`],
        ['Server', serverName],
        ['Time', time],
      ],
      detailsFirst: true,
      button: { label: 'Open in VaultPanel', url: openUrl },
      footer: why,
      panelUrl,
    });
    const ids = await queue(recipients, { purpose: 'alert', event, subject: `[VaultPanel] ${summary}`, text: lines.join('\n'), html });
    return ids.length;
  }

  return { getSettings, updateSettings, sendTest, listMessages, isReady, sendLink, onEvent, deliver, prune };
}

function eventPath(event, data) {
  if (event.startsWith('alert.')) return '/alerts';
  if (event.startsWith('server.') && data?.server?.id) return `/servers/${data.server.id}`;
  if (event.startsWith('deployment.') && data?.application?.id) return `/apps/${data.application.id}`;
  if (event.startsWith('backup.') || event.startsWith('restore.')) return '/backups';
  if (event.startsWith('cron.')) return '/cron-jobs';
  if (event.startsWith('ssl.')) return data?.website?.id ? `/websites/${data.website.id}` : '/ssl';
  return '';
}
