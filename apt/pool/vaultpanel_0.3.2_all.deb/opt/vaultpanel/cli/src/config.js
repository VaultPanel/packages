import { chmodSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';

// Where the CLI keeps its profiles. A profile is a panel URL and an API
// token; the file is written with 0600 because the token is a credential.
export function configPath(env = process.env) {
  if (env.VAULTPANEL_CONFIG) return env.VAULTPANEL_CONFIG;
  const base = env.XDG_CONFIG_HOME || join(env.HOME || homedir(), '.config');
  return join(base, 'vaultpanel', 'config.json');
}

export function readConfig(env = process.env) {
  try {
    const parsed = JSON.parse(readFileSync(configPath(env), 'utf8'));
    return { profiles: {}, defaultProfile: 'default', ...parsed };
  } catch {
    return { profiles: {}, defaultProfile: 'default' };
  }
}

export function writeConfig(config, env = process.env) {
  const path = configPath(env);
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  writeFileSync(path, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
  chmodSync(path, 0o600);
  return path;
}

export function saveProfile(name, profile, env = process.env) {
  const config = readConfig(env);
  config.profiles[name] = { ...config.profiles[name], ...profile };
  config.defaultProfile ??= name;
  writeConfig(config, env);
  return configPath(env);
}

export function removeProfile(name, env = process.env) {
  const config = readConfig(env);
  if (!config.profiles[name]) return false;
  delete config.profiles[name];
  if (config.defaultProfile === name) config.defaultProfile = Object.keys(config.profiles)[0] ?? 'default';
  writeConfig(config, env);
  return true;
}

// What to connect with, in order: flags, environment, the chosen profile.
// VAULTPANEL_URL and VAULTPANEL_TOKEN make the CLI usable in CI without a
// config file at all.
export function resolveProfile({ flags = {}, env = process.env } = {}) {
  const config = readConfig(env);
  const name = flags.profile ?? env.VAULTPANEL_PROFILE ?? config.defaultProfile ?? 'default';
  const stored = config.profiles[name] ?? {};
  const baseUrl = flags.url ?? env.VAULTPANEL_URL ?? stored.url ?? null;
  const token = flags.token ?? env.VAULTPANEL_TOKEN ?? stored.token ?? null;
  return { name, baseUrl, token, stored, known: Object.keys(config.profiles) };
}
