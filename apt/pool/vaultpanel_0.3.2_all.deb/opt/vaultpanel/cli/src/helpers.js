import { relative } from './output.js';
import { CliError } from './errors.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Commands take names, not ids: "vaultpanel apps deploy api" is what someone
// types. A UUID is used as-is; anything else is looked up by name, and an
// ambiguous name is an error rather than a guess.
export async function resolveByName(panel, { kind, value, list, label = (item) => item.name }) {
  if (!value) throw new CliError(`Which ${kind}? Give its name or id.`);
  if (UUID.test(value)) return { id: value, name: value };
  const data = await list();
  const items = data.items ?? data ?? [];
  const matches = items.filter((item) => label(item)?.toLowerCase() === value.toLowerCase());
  const loose = matches.length ? matches : items.filter((item) => label(item)?.toLowerCase().includes(value.toLowerCase()));
  if (loose.length === 0) throw new CliError(`No ${kind} called "${value}". Try: vaultpanel ${kind}s list`);
  if (loose.length > 1) {
    throw new CliError(`More than one ${kind} matches "${value}": ${loose.map(label).join(', ')}. Use the full name or the id.`);
  }
  return loose[0];
}

export const resolveServer = (panel, value) =>
  resolveByName(panel, { kind: 'server', value, list: () => panel.servers.list({ pageSize: 100 }) });

export const resolveWebsite = (panel, value) =>
  resolveByName(panel, { kind: 'website', value, list: () => panel.websites.list({ pageSize: 100 }) });

export const resolveApplication = (panel, value) =>
  resolveByName(panel, { kind: 'app', value, list: () => panel.applications.list({ pageSize: 100 }) });

export const resolveDatabase = (panel, value) =>
  resolveByName(panel, { kind: 'database', value, list: () => panel.databases.list({ pageSize: 100 }) });

export const resolveContainer = (panel, value) =>
  resolveByName(panel, { kind: 'container', value, list: () => panel.containers.list({ pageSize: 100 }) });

export const resolveCronJob = (panel, value) =>
  resolveByName(panel, { kind: 'cron job', value, list: () => panel.cronJobs.list({ pageSize: 100 }) });

export function printJob(out, job, data = {}) {
  if (out.json) return out.data(data);
  out.detail({
    Job: job.id,
    Operation: job.type,
    Status: job.status,
    Server: job.server?.name ?? '-',
    Started: job.startedAt ? relative(job.startedAt) : 'not yet',
    Finished: job.finishedAt ? relative(job.finishedAt) : '-',
    ...(job.error ? { Error: job.error } : {}),
  });
  const logs = data.logs ?? [];
  if (logs.length) {
    out.info('');
    for (const line of logs) out.raw(`  ${line.message ?? line.line ?? JSON.stringify(line)}`);
  }
  return undefined;
}

// Follows a job and exits non-zero if it does not succeed, so a script can
// rely on the exit code.
export async function watchJob(panel, out, jobId, { timeoutMs = 900_000 } = {}) {
  const seen = new Set();
  const { job, logs } = await panel.jobs.wait(jobId, {
    timeoutMs,
    onProgress: (current, lines) => {
      for (const line of lines ?? []) {
        if (seen.has(line.id)) continue;
        seen.add(line.id);
        if (!out.json) out.raw(`  ${line.message ?? ''}`);
      }
      if (!out.json && current?.status && !seen.has(`status:${current.status}`)) {
        seen.add(`status:${current.status}`);
        out.info(`… ${current.status}`);
      }
    },
  });
  if (out.json) return out.data({ job, logs });
  if (job.status === 'succeeded') out.success(`${job.type} succeeded`);
  else {
    out.error(`${job.type} ${job.status}${job.error ? `: ${job.error}` : ''}`);
    throw new CliError(`Job ${job.id} ${job.status}`, { exitCode: 2 });
  }
  return undefined;
}
