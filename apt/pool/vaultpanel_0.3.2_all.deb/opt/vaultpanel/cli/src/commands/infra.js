import { asList, asNumber } from '../args.js';
import { bytes, relative } from '../output.js';
import { CliError } from '../errors.js';
import { resolveServer, printJob, watchJob } from '../helpers.js';

export const serverCommands = {
  summary: 'Servers, their state and the operations they can run',
  commands: {
    list: {
      summary: 'List servers',
      usage: 'vaultpanel servers list [--search text] [--status connected]',
      async run({ panel, out, flags }) {
        const data = await panel.servers.list({ search: flags.search, status: flags.status, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (s) => s.name },
          { header: 'Status', value: (s) => s.status },
          { header: 'Agent', value: (s) => s.agentVersion },
          { header: 'CPU', value: (s) => (s.metrics?.cpuPercent == null ? '-' : `${Math.round(s.metrics.cpuPercent)}%`) },
          { header: 'Memory', value: (s) => (s.metrics?.memoryUsedBytes == null ? '-' : `${bytes(s.metrics.memoryUsedBytes)} / ${bytes(s.metrics.memoryTotalBytes)}`) },
          { header: 'Last seen', value: (s) => relative(s.lastSeenAt) },
          { header: 'Id', value: (s) => s.id },
        ]);
      },
    },
    show: {
      summary: 'One server in detail',
      usage: 'vaultpanel servers show <server>',
      async run({ panel, out, args }) {
        const server = await resolveServer(panel, args[0]);
        const data = await panel.servers.get(server.id);
        const s = data.server ?? data;
        out.data(data);
        if (out.json) return;
        out.detail({
          Name: s.name,
          Id: s.id,
          Status: s.status,
          Agent: s.agentVersion,
          OS: s.system?.os ? `${s.system.os.name} ${s.system.os.version}` : '-',
          Hostname: s.system?.hostname,
          Addresses: s.addresses,
          'Last seen': relative(s.lastSeenAt),
        });
      },
    },
    add: {
      summary: 'Add a server and print the agent install command',
      usage: 'vaultpanel servers add <name>',
      async run({ panel, out, args }) {
        if (!args[0]) throw new CliError('What should the server be called? vaultpanel servers add <name>');
        const data = await panel.servers.create({ name: args[0] });
        out.data(data);
        if (out.json) return;
        out.success(`Server "${data.server.name}" added`);
        out.info('');
        out.info('Run this on the server, as root, to install the agent:');
        out.info(`  ${data.enrollment?.installCommand ?? '(see the server page in the panel)'}`);
      },
    },
    remove: {
      summary: 'Remove a server from the panel',
      usage: 'vaultpanel servers remove <server> --force',
      async run({ panel, out, args, flags }) {
        const server = await resolveServer(panel, args[0]);
        if (!flags.force) throw new CliError(`This removes "${server.name}" from the panel. Add --force to go ahead.`);
        await panel.servers.remove(server.id);
        out.success(`Server "${server.name}" removed`);
      },
    },
    operations: {
      summary: 'The operations an agent can run',
      usage: 'vaultpanel servers operations',
      async run({ panel, out }) {
        const data = await panel.jobs.operations();
        return out.table(data.items ?? data.operations ?? [], [
          { header: 'Operation', value: (o) => o.type ?? o.name },
          { header: 'What it does', value: (o) => o.description ?? '-' },
        ]);
      },
    },
    run: {
      summary: 'Run one allowlisted operation on a server',
      usage: 'vaultpanel servers run <server> <OPERATION> [--params \'{"service":"nginx"}\'] [--watch]',
      details: 'See vaultpanel servers operations for the catalog. Nothing else can be run: the agent has no shell.',
      async run({ panel, out, args, flags }) {
        const server = await resolveServer(panel, args[0]);
        const type = args[1]?.toUpperCase();
        if (!type) throw new CliError('Which operation? vaultpanel servers run <server> <OPERATION>');
        let params = {};
        if (flags.params) {
          try {
            params = JSON.parse(flags.params);
          } catch {
            throw new CliError('--params must be JSON, for example --params \'{"service":"nginx"}\'');
          }
        }
        const data = await panel.servers.runOperation(server.id, { type, params });
        const job = data.job ?? data;
        out.info(`${type} on ${server.name}: job ${job.id}`);
        return flags.watch ? watchJob(panel, out, job.id) : printJob(out, job, data);
      },
    },
    reboot: {
      summary: 'Reboot a server',
      usage: 'vaultpanel servers reboot <server> --force [--watch]',
      async run({ panel, out, args, flags }) {
        const server = await resolveServer(panel, args[0]);
        if (!flags.force) throw new CliError(`This reboots "${server.name}". Add --force to go ahead.`);
        const data = await panel.servers.runOperation(server.id, { type: 'SERVER_REBOOT', params: {} });
        const job = data.job ?? data;
        out.info(`Rebooting ${server.name}: job ${job.id}`);
        return flags.watch ? watchJob(panel, out, job.id) : printJob(out, job, data);
      },
    },
    groups: {
      summary: 'List server groups',
      usage: 'vaultpanel servers groups',
      async run({ panel, out }) {
        const data = await panel.servers.groups.list();
        return out.table(data.items ?? [], [
          { header: 'Group', value: (g) => g.name },
          { header: 'Servers', value: (g) => g.serverCount ?? g.servers?.length ?? 0 },
          { header: 'Id', value: (g) => g.id },
        ]);
      },
    },
    services: {
      summary: 'Check or restart a service on a server',
      usage: 'vaultpanel servers services <server> [--restart nginx] [--names nginx,php8.3-fpm] [--watch]',
      async run({ panel, out, args, flags }) {
        const server = await resolveServer(panel, args[0]);
        if (flags.restart) {
          const data = await panel.servers.runOperation(server.id, { type: 'SERVICE_RESTART', params: { service: flags.restart } });
          const job = data.job ?? data;
          out.info(`Restarting ${flags.restart} on ${server.name}: job ${job.id}`);
          return flags.watch ? watchJob(panel, out, job.id) : printJob(out, job, data);
        }
        const names = asList(flags.names);
        const data = await panel.servers.runOperation(server.id, { type: 'SERVICE_STATUS', params: names ? { services: names } : {} });
        const job = data.job ?? data;
        return watchJob(panel, out, job.id);
      },
    },
  },
};

export const jobCommands = {
  summary: 'Background jobs: deployments, website creation, backups, operations',
  commands: {
    list: {
      summary: 'List jobs',
      usage: 'vaultpanel jobs list [--status running] [--server <server>]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.jobs.list({ status: flags.status, serverId, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Job', value: (j) => j.id },
          { header: 'Operation', value: (j) => j.type },
          { header: 'Status', value: (j) => j.status },
          { header: 'Server', value: (j) => j.server?.name ?? '-' },
          { header: 'Started', value: (j) => relative(j.startedAt ?? j.createdAt) },
        ]);
      },
    },
    show: {
      summary: 'One job with its log',
      usage: 'vaultpanel jobs show <job id>',
      async run({ panel, out, args }) {
        if (!args[0]) throw new CliError('Which job? vaultpanel jobs show <job id>');
        const data = await panel.jobs.get(args[0]);
        return printJob(out, data.job ?? data, data);
      },
    },
    watch: {
      summary: 'Follow a job until it finishes',
      usage: 'vaultpanel jobs watch <job id>',
      async run({ panel, out, args }) {
        if (!args[0]) throw new CliError('Which job? vaultpanel jobs watch <job id>');
        return watchJob(panel, out, args[0]);
      },
    },
    cancel: {
      summary: 'Cancel a queued job',
      usage: 'vaultpanel jobs cancel <job id>',
      async run({ panel, out, args }) {
        if (!args[0]) throw new CliError('Which job? vaultpanel jobs cancel <job id>');
        await panel.jobs.cancel(args[0]);
        out.success('Job cancelled');
      },
    },
  },
};
