import { readFileSync } from 'node:fs';
import { relative } from '../output.js';
import { CliError } from '../errors.js';

export const apiCommand = {
  summary: 'Call any API endpoint directly',
  usage: 'vaultpanel api <METHOD> <path> [--data \'{"name":"x"}\'] [--data-file file.json] [--query key=value]',
  details: 'The path is relative to /api/v1, so "vaultpanel api GET /servers" calls /api/v1/servers. Prints the whole reply envelope.',
  async run({ panel, out, args, flags }) {
    const method = (args[0] ?? '').toUpperCase();
    const path = args[1];
    if (!method || !path) throw new CliError('vaultpanel api <METHOD> <path>, for example: vaultpanel api GET /servers');
    if (!['GET', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(method)) throw new CliError(`${method} is not a method the API uses`);
    let body;
    const source = flags.dataFile ? readFileSync(flags.dataFile, 'utf8') : flags.data;
    if (source) {
      try {
        body = JSON.parse(source);
      } catch {
        throw new CliError('The body must be JSON, for example --data \'{"name":"x"}\'');
      }
    }
    const query = {};
    for (const pair of [].concat(flags.query ?? []).filter((v) => typeof v === 'string')) {
      const eq = pair.indexOf('=');
      if (eq === -1) throw new CliError(`--query expects key=value, got "${pair}"`);
      query[pair.slice(0, eq)] = pair.slice(eq + 1);
    }
    const envelope = await panel.raw(method, path, { body, query: Object.keys(query).length ? query : undefined });
    out.raw(JSON.stringify(envelope, null, 2));
  },
};

export const dashboardCommand = {
  summary: 'The dashboard numbers: servers, websites, apps, alerts',
  usage: 'vaultpanel dashboard',
  async run({ panel, out }) {
    const data = await panel.dashboard();
    out.data(data);
    if (out.json) return;
    const counts = data.counts ?? data.totals ?? {};
    out.detail({
      Servers: `${counts.servers?.connected ?? counts.servers ?? '-'}${counts.servers?.total ? ` of ${counts.servers.total} connected` : ''}`,
      Websites: counts.websites?.total ?? counts.websites ?? '-',
      Applications: counts.applications?.total ?? counts.applications ?? '-',
      Databases: counts.databases?.total ?? counts.databases ?? '-',
      Containers: counts.containers?.total ?? counts.containers ?? '-',
      'Firing alerts': data.alerts?.firing ?? '-',
    });
  },
};

export const alertCommands = {
  summary: 'Alerts that are firing',
  commands: {
    list: {
      summary: 'Firing and recent alerts',
      usage: 'vaultpanel alerts list [--status firing]',
      async run({ panel, out, flags }) {
        const data = await panel.alerts.events({ status: flags.status ?? 'firing' });
        return out.table(data.items, [
          { header: 'When', value: (a) => relative(a.startedAt ?? a.createdAt) },
          { header: 'Alert', value: (a) => a.rule?.name ?? a.name },
          { header: 'Server', value: (a) => a.server?.name },
          { header: 'Status', value: (a) => a.status },
          { header: 'Value', value: (a) => a.value },
          { header: 'Id', value: (a) => a.id },
        ]);
      },
    },
    acknowledge: {
      summary: 'Acknowledge a firing alert',
      usage: 'vaultpanel alerts acknowledge <alert id>',
      async run({ panel, out, args }) {
        if (!args[0]) throw new CliError('Which alert? vaultpanel alerts acknowledge <alert id>');
        await panel.alerts.acknowledge(args[0]);
        out.success('Alert acknowledged');
      },
    },
  },
};
