import { asList, asNumber } from '../args.js';
import { bytes, relative } from '../output.js';
import { CliError } from '../errors.js';
import { printJob, resolveApplication, resolveServer, resolveWebsite, watchJob } from '../helpers.js';

export const websiteCommands = {
  summary: 'Websites, their domains and SSL certificates',
  commands: {
    list: {
      summary: 'List websites',
      usage: 'vaultpanel websites list [--server <server>] [--search text]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.websites.list({ serverId, search: flags.search, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (w) => w.name },
          { header: 'Type', value: (w) => w.type },
          { header: 'Domains', value: (w) => w.domains?.map((d) => d.name ?? d) },
          { header: 'Status', value: (w) => w.status },
          { header: 'SSL', value: (w) => (w.certificate ? w.certificate.status : 'off') },
          { header: 'Disk', value: (w) => bytes(w.diskBytes) },
        ]);
      },
    },
    show: {
      summary: 'One website in detail',
      usage: 'vaultpanel websites show <website>',
      async run({ panel, out, args }) {
        const site = await resolveWebsite(panel, args[0]);
        const data = await panel.websites.get(site.id);
        const w = data.website ?? data;
        out.data(data);
        if (out.json) return;
        out.detail({
          Name: w.name,
          Id: w.id,
          Type: w.type,
          Server: w.server?.name,
          Domains: w.domains?.map((d) => d.name ?? d),
          Root: w.documentRoot,
          Status: w.status,
          SSL: w.certificate ? `${w.certificate.status}${w.certificate.expiresAt ? `, renews ${relative(w.certificate.expiresAt)}` : ''}` : 'off',
        });
      },
    },
    create: {
      summary: 'Create a website',
      usage: 'vaultpanel websites create <name> --server <server> --domains a.example.com,b.example.com [--type static|php|proxy] [--php 8.3] [--watch]',
      async run({ panel, out, args, flags }) {
        const name = args[0];
        if (!name) throw new CliError('What should the website be called? vaultpanel websites create <name> --server <server> --domains ...');
        const domains = asList(flags.domains);
        if (!domains?.length) throw new CliError('Which domains? --domains site.example.com');
        const server = await resolveServer(panel, flags.server);
        const data = await panel.websites.create({
          name,
          serverId: server.id,
          type: flags.type ?? 'static',
          domains,
          phpVersion: flags.php,
          proxyPort: asNumber(flags.proxyPort, 'proxy-port'),
        });
        const job = data.job;
        out.info(`Creating ${name} on ${server.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    ssl: {
      summary: "Get or renew a Let's Encrypt certificate",
      usage: 'vaultpanel websites ssl <website> [--staging] [--renew] [--watch]',
      async run({ panel, out, args, flags }) {
        const site = await resolveWebsite(panel, args[0]);
        const data = flags.renew ? await panel.websites.renewSsl(site.id, {}) : await panel.websites.issueSsl(site.id, { staging: Boolean(flags.staging) });
        const job = data.job;
        out.info(`${flags.renew ? 'Renewing' : 'Issuing'} the certificate for ${site.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    logs: {
      summary: "A website's access or error log",
      usage: 'vaultpanel websites logs <website> [--kind error|access] [--lines 100]',
      async run({ panel, out, args, flags }) {
        const site = await resolveWebsite(panel, args[0]);
        const data = await panel.websites.logs(site.id, { kind: flags.kind ?? 'error', lines: asNumber(flags.lines, 'lines') ?? 100 });
        const job = data.job;
        if (job) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    enable: {
      summary: 'Turn a website on',
      usage: 'vaultpanel websites enable <website>',
      async run({ panel, out, args }) {
        const site = await resolveWebsite(panel, args[0]);
        await panel.websites.enable(site.id);
        out.success(`${site.name} turned on`);
      },
    },
    disable: {
      summary: 'Turn a website off',
      usage: 'vaultpanel websites disable <website>',
      async run({ panel, out, args }) {
        const site = await resolveWebsite(panel, args[0]);
        await panel.websites.disable(site.id);
        out.success(`${site.name} turned off`);
      },
    },
    delete: {
      summary: 'Delete a website',
      usage: 'vaultpanel websites delete <website> --force [--keep-files]',
      async run({ panel, out, args, flags }) {
        const site = await resolveWebsite(panel, args[0]);
        if (!flags.force) throw new CliError(`This deletes "${site.name}". Add --force to go ahead.`);
        const data = await panel.websites.remove(site.id, flags.keepFiles ? { keepFiles: 'true' } : undefined);
        out.success(`${site.name} deleted`);
        out.data(data ?? null);
      },
    },
  },
};

export const appCommands = {
  summary: 'Applications: deploy, roll back, restart and read logs',
  commands: {
    list: {
      summary: 'List applications',
      usage: 'vaultpanel apps list [--server <server>]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.applications.list({ serverId, search: flags.search, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (a) => a.name },
          { header: 'Runtime', value: (a) => `${a.runtime}${a.runtimeVersion ? ` ${a.runtimeVersion}` : ''}` },
          { header: 'Process', value: (a) => a.process?.status ?? a.status },
          { header: 'Branch', value: (a) => a.branch },
          { header: 'Deployed', value: (a) => relative(a.lastDeployedAt) },
          { header: 'Port', value: (a) => a.port },
        ]);
      },
    },
    show: {
      summary: 'One application in detail',
      usage: 'vaultpanel apps show <app>',
      async run({ panel, out, args }) {
        const app = await resolveApplication(panel, args[0]);
        const data = await panel.applications.get(app.id);
        const a = data.application ?? data;
        out.data(data);
        if (out.json) return;
        out.detail({
          Name: a.name,
          Id: a.id,
          Server: a.server?.name,
          Runtime: `${a.runtime}${a.runtimeVersion ? ` ${a.runtimeVersion}` : ''}`,
          Repository: a.repositoryUrl,
          Branch: a.branch,
          Port: a.port,
          Process: a.process ? `${a.process.status}${a.process.restarts != null ? `, ${a.process.restarts} restarts` : ''}` : a.status,
          'Last deployed': relative(a.lastDeployedAt),
        });
      },
    },
    deploy: {
      summary: 'Deploy the current branch',
      usage: 'vaultpanel apps deploy <app> [--watch]',
      async run({ panel, out, args, flags }) {
        const app = await resolveApplication(panel, args[0]);
        const data = await panel.applications.deploy(app.id);
        const job = data.job ?? data.deployment?.job;
        out.info(`Deploying ${app.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    rollback: {
      summary: 'Roll back to the previous release, or a named one',
      usage: 'vaultpanel apps rollback <app> [--release <id>] [--watch]',
      async run({ panel, out, args, flags }) {
        const app = await resolveApplication(panel, args[0]);
        const data = await panel.applications.rollback(app.id, flags.release ? { deploymentId: flags.release } : {});
        const job = data.job;
        out.info(`Rolling ${app.name} back${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    restart: {
      summary: 'Restart, start or stop an application',
      usage: 'vaultpanel apps restart <app> [--stop] [--start] [--watch]',
      async run({ panel, out, args, flags }) {
        const app = await resolveApplication(panel, args[0]);
        const action = flags.stop ? 'stop' : flags.start ? 'start' : 'restart';
        const data = await panel.applications[action](app.id);
        const job = data.job;
        out.info(`${action === 'restart' ? 'Restarting' : action === 'stop' ? 'Stopping' : 'Starting'} ${app.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    logs: {
      summary: "An application's output or error log",
      usage: 'vaultpanel apps logs <app> [--kind out|error] [--lines 100]',
      async run({ panel, out, args, flags }) {
        const app = await resolveApplication(panel, args[0]);
        const data = await panel.applications.logs(app.id, { kind: flags.kind ?? 'out', lines: asNumber(flags.lines, 'lines') ?? 100 });
        const job = data.job;
        if (job) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    env: {
      summary: 'Read or set environment variables',
      usage: 'vaultpanel apps env <app> [--set KEY=value --set OTHER=value] [--unset KEY]',
      details: 'Setting a variable replaces that one and leaves the rest alone. The app needs a deploy or apply afterwards.',
      async run({ panel, out, args, flags }) {
        const app = await resolveApplication(panel, args[0]);
        const sets = [].concat(flags.set ?? []).filter((v) => typeof v === 'string');
        const unsets = [].concat(flags.unset ?? []).filter((v) => typeof v === 'string');
        if (!sets.length && !unsets.length) {
          const data = await panel.applications.environment(app.id);
          const variables = data.variables ?? data;
          return out.table(Object.entries(variables).map(([key, value]) => ({ key, value })), [
            { header: 'Variable', value: (r) => r.key },
            { header: 'Value', value: (r) => r.value },
          ]);
        }
        const current = (await panel.applications.environment(app.id)).variables ?? {};
        const next = { ...current };
        for (const pair of sets) {
          const eq = pair.indexOf('=');
          if (eq === -1) throw new CliError(`--set expects KEY=value, got "${pair}"`);
          next[pair.slice(0, eq)] = pair.slice(eq + 1);
        }
        for (const key of unsets) delete next[key];
        await panel.applications.setEnvironment(app.id, { variables: next });
        out.success(`Environment saved for ${app.name}. Deploy or apply to use it.`);
        return undefined;
      },
    },
    deployments: {
      summary: 'Deployment history',
      usage: 'vaultpanel apps deployments [--app <app>]',
      async run({ panel, out, flags }) {
        const applicationId = flags.app ? (await resolveApplication(panel, flags.app)).id : undefined;
        const data = await panel.deployments.list({ applicationId, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'When', value: (d) => relative(d.createdAt) },
          { header: 'App', value: (d) => d.application?.name },
          { header: 'Status', value: (d) => d.status },
          { header: 'Commit', value: (d) => d.commitHash?.slice(0, 8) },
          { header: 'Trigger', value: (d) => d.trigger },
          { header: 'Id', value: (d) => d.id },
        ]);
      },
    },
  },
};

export { printJob };
