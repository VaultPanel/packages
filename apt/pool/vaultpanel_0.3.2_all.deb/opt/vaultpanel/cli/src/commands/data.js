import { asList, asNumber } from '../args.js';
import { bytes, relative } from '../output.js';
import { CliError } from '../errors.js';
import { resolveContainer, resolveCronJob, resolveDatabase, resolveServer, watchJob } from '../helpers.js';

export const databaseCommands = {
  summary: 'MariaDB databases and their users',
  commands: {
    list: {
      summary: 'List databases',
      usage: 'vaultpanel databases list [--server <server>]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.databases.list({ serverId, search: flags.search, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (d) => d.name },
          { header: 'Server', value: (d) => d.server?.name },
          { header: 'Status', value: (d) => d.status },
          { header: 'Size', value: (d) => bytes(d.sizeBytes) },
          { header: 'Users', value: (d) => d.users?.length ?? 0 },
        ]);
      },
    },
    create: {
      summary: 'Create a database, and a user for it',
      usage: 'vaultpanel databases create <name> --server <server> [--user name] [--watch]',
      async run({ panel, out, args, flags }) {
        if (!args[0]) throw new CliError('What should the database be called? vaultpanel databases create <name> --server <server>');
        const server = await resolveServer(panel, flags.server);
        const data = await panel.databases.create({ name: args[0], serverId: server.id, createUser: flags.user ? { name: flags.user } : undefined });
        const job = data.job;
        out.info(`Creating ${args[0]} on ${server.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        if (!out.json && data.credentials?.password) out.info(`Password for ${data.credentials.user}: ${data.credentials.password} (shown once)`);
        return undefined;
      },
    },
    delete: {
      summary: 'Delete a database',
      usage: 'vaultpanel databases delete <database> --force',
      async run({ panel, out, args, flags }) {
        const database = await resolveDatabase(panel, args[0]);
        if (!flags.force) throw new CliError(`This deletes "${database.name}" and its data. Add --force to go ahead.`);
        await panel.databases.remove(database.id);
        out.success(`${database.name} deleted`);
      },
    },
    users: {
      summary: 'List database users',
      usage: 'vaultpanel databases users [--database <database>]',
      async run({ panel, out, flags }) {
        const databaseId = flags.database ? (await resolveDatabase(panel, flags.database)).id : undefined;
        const data = await panel.databases.users.list({ databaseId, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'User', value: (u) => u.name },
          { header: 'Database', value: (u) => u.database?.name },
          { header: 'Host', value: (u) => u.host },
          { header: 'Access', value: (u) => u.privileges ?? u.access },
        ]);
      },
    },
  },
};

export const containerCommands = {
  summary: 'Docker containers VaultPanel deploys',
  commands: {
    list: {
      summary: 'List containers',
      usage: 'vaultpanel containers list [--server <server>] [--all]',
      details: '--all also lists containers on the server that VaultPanel did not deploy.',
      async run({ panel, out, flags }) {
        if (flags.all) {
          const server = await resolveServer(panel, flags.server);
          const data = await panel.containers.onServer.list(server.id);
          const job = data.job;
          if (job) return watchJob(panel, out, job.id);
          return out.data(data);
        }
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.containers.list({ serverId, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (c) => c.name },
          { header: 'Image', value: (c) => c.image },
          { header: 'Server', value: (c) => c.server?.name },
          { header: 'State', value: (c) => c.state ?? c.status },
          { header: 'Ports', value: (c) => c.spec?.ports?.map((p) => `${p.host}:${p.container}`) },
          { header: 'Updated', value: (c) => relative(c.updatedAt) },
        ]);
      },
    },
    deploy: {
      summary: 'Deploy a container from a public image',
      usage: 'vaultpanel containers deploy <name> --server <server> --image redis:7 [--ports 6379:6379] [--env KEY=value] [--memory 512] [--watch]',
      async run({ panel, out, args, flags }) {
        if (!args[0]) throw new CliError('What should the container be called? vaultpanel containers deploy <name> --server <server> --image ...');
        if (!flags.image) throw new CliError('Which image? --image redis:7');
        const server = await resolveServer(panel, flags.server);
        const ports = (asList(flags.ports) ?? []).map((pair) => {
          const [host, container] = pair.split(':');
          return { host: Number(host), container: Number(container ?? host) };
        });
        const environment = {};
        for (const pair of [].concat(flags.env ?? []).filter((v) => typeof v === 'string')) {
          const eq = pair.indexOf('=');
          if (eq === -1) throw new CliError(`--env expects KEY=value, got "${pair}"`);
          environment[pair.slice(0, eq)] = pair.slice(eq + 1);
        }
        const data = await panel.containers.create({
          name: args[0],
          serverId: server.id,
          image: flags.image,
          ports,
          environment,
          memoryMb: asNumber(flags.memory, 'memory'),
          cpuPercent: asNumber(flags.cpu, 'cpu'),
        });
        const job = data.job;
        out.info(`Deploying ${args[0]} on ${server.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    restart: {
      summary: 'Restart, start or stop a container',
      usage: 'vaultpanel containers restart <container> [--start] [--stop] [--watch]',
      async run({ panel, out, args, flags }) {
        const container = await resolveContainer(panel, args[0]);
        const action = flags.stop ? 'stop' : flags.start ? 'start' : 'restart';
        const data = await panel.containers[action](container.id);
        const job = data.job;
        out.info(`${action} ${container.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    logs: {
      summary: "A container's output",
      usage: 'vaultpanel containers logs <container> [--lines 100]',
      async run({ panel, out, args, flags }) {
        const container = await resolveContainer(panel, args[0]);
        const full = await panel.containers.get(container.id);
        const c = full.container ?? full;
        const data = await panel.containers.onServer.logs(c.server?.id ?? c.serverId, c.name, { lines: asNumber(flags.lines, 'lines') ?? 100 });
        const job = data.job;
        if (job) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    remove: {
      summary: 'Remove a container',
      usage: 'vaultpanel containers remove <container> --force [--delete-volumes]',
      async run({ panel, out, args, flags }) {
        const container = await resolveContainer(panel, args[0]);
        if (!flags.force) throw new CliError(`This removes "${container.name}". Add --force to go ahead.`);
        const data = await panel.containers.remove(container.id, flags.deleteVolumes ? { deleteVolumes: 'true' } : undefined);
        const job = data?.job;
        out.info(`Removing ${container.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data ?? null);
        return undefined;
      },
    },
  },
};

export const backupCommands = {
  summary: 'Backups and restores',
  commands: {
    list: {
      summary: 'List backups',
      usage: 'vaultpanel backups list [--server <server>] [--status]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.backups.list({ serverId, status: flags.status, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'When', value: (b) => relative(b.createdAt) },
          { header: 'What', value: (b) => `${b.resourceType} ${b.resourceName}` },
          { header: 'Status', value: (b) => b.status },
          { header: 'Size', value: (b) => bytes(b.sizeBytes) },
          { header: 'Trigger', value: (b) => b.trigger },
          { header: 'Id', value: (b) => b.id },
        ]);
      },
    },
    create: {
      summary: 'Back up a website, app or database now',
      usage: 'vaultpanel backups create --type website|application|database --resource <name or id> [--watch]',
      async run({ panel, out, flags }) {
        const type = flags.type;
        if (!type) throw new CliError('What should be backed up? --type website|application|database');
        const resolvers = { website: 'resolveWebsite', application: 'resolveApplication', database: 'resolveDatabase' };
        if (!resolvers[type]) throw new CliError('--type must be website, application or database');
        const helpers = await import('../helpers.js');
        const resource = await helpers[resolvers[type]](panel, flags.resource);
        const data = await panel.backups.create({ resourceType: type, resourceId: resource.id });
        const job = data.job;
        out.info(`Backing up ${resource.name ?? resource.id}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    restore: {
      summary: 'Restore a backup',
      usage: 'vaultpanel backups restore <backup id> --force [--watch]',
      async run({ panel, out, args, flags }) {
        if (!args[0]) throw new CliError('Which backup? vaultpanel backups restore <backup id>');
        if (!flags.force) throw new CliError('Restoring replaces what is there now. Add --force to go ahead.');
        const data = await panel.backups.restore(args[0], {});
        const job = data.job;
        out.info(`Restoring${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
  },
};

export const cronCommands = {
  summary: 'Cron jobs',
  commands: {
    list: {
      summary: 'List cron jobs',
      usage: 'vaultpanel cron list [--server <server>]',
      async run({ panel, out, flags }) {
        const serverId = flags.server ? (await resolveServer(panel, flags.server)).id : undefined;
        const data = await panel.cronJobs.list({ serverId, pageSize: asNumber(flags.pageSize, 'page-size') });
        return out.table(data.items, [
          { header: 'Name', value: (c) => c.name },
          { header: 'Schedule', value: (c) => c.schedule },
          { header: 'Server', value: (c) => c.server?.name },
          { header: 'State', value: (c) => (c.isActive === false ? 'paused' : 'active') },
          { header: 'Last run', value: (c) => relative(c.lastRunAt) },
          { header: 'Result', value: (c) => c.lastStatus },
        ]);
      },
    },
    run: {
      summary: 'Run a cron job now',
      usage: 'vaultpanel cron run <cron job> [--watch]',
      async run({ panel, out, args, flags }) {
        const cron = await resolveCronJob(panel, args[0]);
        const data = await panel.cronJobs.run(cron.id);
        const job = data.job;
        out.info(`Running ${cron.name}${job ? `: job ${job.id}` : ''}`);
        if (job && flags.watch) return watchJob(panel, out, job.id);
        out.data(data);
        return undefined;
      },
    },
    runs: {
      summary: 'The run history of a cron job',
      usage: 'vaultpanel cron runs <cron job>',
      async run({ panel, out, args }) {
        const cron = await resolveCronJob(panel, args[0]);
        const data = await panel.cronJobs.runs(cron.id, {});
        return out.table(data.items, [
          { header: 'When', value: (r) => relative(r.startedAt ?? r.createdAt) },
          { header: 'Status', value: (r) => r.status },
          { header: 'Exit code', value: (r) => r.exitCode },
          { header: 'Took', value: (r) => (r.durationMs == null ? '-' : `${Math.round(r.durationMs / 100) / 10}s`) },
        ]);
      },
    },
  },
};
