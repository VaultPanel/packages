import { authCommands } from './auth.js';
import { jobCommands, serverCommands } from './infra.js';
import { appCommands, websiteCommands } from './web.js';
import { backupCommands, containerCommands, cronCommands, databaseCommands } from './data.js';
import { alertCommands, apiCommand, dashboardCommand } from './misc.js';

// Every command the CLI has, as groups. A group with a `commands` object has
// subcommands (vaultpanel servers list); a group with `run` is a command of
// its own (vaultpanel dashboard).
export const COMMANDS = {
  login: authCommands.commands.login,
  logout: authCommands.commands.logout,
  whoami: authCommands.commands.whoami,
  profiles: authCommands.commands.profiles,
  tokens: authCommands.commands.tokens,
  dashboard: dashboardCommand,
  servers: serverCommands,
  websites: websiteCommands,
  apps: appCommands,
  databases: databaseCommands,
  containers: containerCommands,
  backups: backupCommands,
  cron: cronCommands,
  alerts: alertCommands,
  jobs: jobCommands,
  api: apiCommand,
};

// Short names people reach for.
export const ALIASES = {
  server: 'servers',
  site: 'websites',
  sites: 'websites',
  website: 'websites',
  app: 'apps',
  applications: 'apps',
  db: 'databases',
  database: 'databases',
  container: 'containers',
  docker: 'containers',
  backup: 'backups',
  job: 'jobs',
  alert: 'alerts',
  token: 'tokens',
  me: 'whoami',
};

export function findCommand(groupName, commandName) {
  const key = ALIASES[groupName] ?? groupName;
  const group = COMMANDS[key];
  if (!group) return { error: `There is no "${groupName}" command. Run vaultpanel --help to see what there is.` };
  if (group.run) return { command: group, path: key, args: commandName ? [commandName] : [] };
  const name = commandName ?? 'list';
  const command = group.commands[name];
  if (!command) {
    return { error: `"${key} ${commandName ?? ''}".trim() is not a command. Try: ${Object.keys(group.commands).map((c) => `${key} ${c}`).join(', ')}` };
  }
  return { command, path: `${key} ${name}`, group: key };
}
