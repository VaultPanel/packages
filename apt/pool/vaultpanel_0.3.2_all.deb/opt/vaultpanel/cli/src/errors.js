// A problem with how the command was used, as opposed to something the panel
// refused. These print without a stack trace.
export class CliError extends Error {
  constructor(message, { exitCode = 1, hint = null } = {}) {
    super(message);
    this.name = 'CliError';
    this.exitCode = exitCode;
    this.hint = hint;
  }
}
