// A small argument parser: long flags (--name value, --name=value, --flag),
// short -j/-h, and everything else positional. No dependencies, so the CLI
// stays a single install-free tool.
export function parseArgs(argv) {
  const positional = [];
  const flags = {};
  let i = 0;
  while (i < argv.length) {
    const arg = argv[i];
    if (arg === '--') {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (arg.startsWith('--')) {
      const [name, inline] = splitFlag(arg.slice(2));
      if (inline !== undefined) flags[name] = inline;
      else if (isBooleanLike(argv[i + 1])) flags[name] = true;
      else {
        flags[name] = argv[i + 1];
        i += 1;
      }
    } else if (/^-[a-zA-Z]+$/.test(arg)) {
      for (const letter of arg.slice(1)) flags[SHORT[letter] ?? letter] = true;
    } else {
      positional.push(arg);
    }
    i += 1;
  }
  return { positional, flags };
}

const SHORT = { j: 'json', h: 'help', q: 'quiet', f: 'force', w: 'watch', v: 'version' };

function splitFlag(text) {
  const eq = text.indexOf('=');
  return eq === -1 ? [camel(text), undefined] : [camel(text.slice(0, eq)), text.slice(eq + 1)];
}

// --dry-run becomes dryRun, so flags read like the API's fields.
function camel(name) {
  return name.replace(/-([a-z0-9])/g, (_, c) => c.toUpperCase());
}

// "--json -q" and "--json --quiet": the next argument is another flag, not a
// value, so the flag before it is a plain true.
const isBooleanLike = (next) => next === undefined || (next.startsWith('-') && next.length > 1);

// Flag values arrive as strings; the API wants real types.
export function asNumber(value, field) {
  if (value === undefined || value === null) return undefined;
  const n = Number(value);
  if (!Number.isFinite(n)) throw new Error(`--${field} must be a number`);
  return n;
}

export function asBoolean(value) {
  if (value === undefined) return undefined;
  if (value === true || value === 'true' || value === 'yes' || value === '1') return true;
  if (value === false || value === 'false' || value === 'no' || value === '0') return false;
  return Boolean(value);
}

export function asList(value) {
  if (value === undefined) return undefined;
  return String(value)
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}
