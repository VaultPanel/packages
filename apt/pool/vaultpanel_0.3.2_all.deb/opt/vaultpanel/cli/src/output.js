// How the CLI prints. Human-readable tables by default; --json prints the
// data the API returned, so the tool can be piped into jq.
const COLOURS = { reset: '\u001b[0m', dim: '\u001b[2m', bold: '\u001b[1m', red: '\u001b[31m', green: '\u001b[32m', yellow: '\u001b[33m' };

export function createOutput({ json = false, quiet = false, stdout = process.stdout, stderr = process.stderr, colour } = {}) {
  const useColour = colour ?? (stdout.isTTY === true && !process.env.NO_COLOR);
  const paint = (text, name) => (useColour && COLOURS[name] ? `${COLOURS[name]}${text}${COLOURS.reset}` : String(text));
  const write = (line = '') => stdout.write(`${line}\n`);

  return {
    json,
    // The machine-readable form of whatever a command produced.
    data(value) {
      if (json) write(JSON.stringify(value, null, 2));
      return value;
    },
    table(rows, columns) {
      if (json) return write(JSON.stringify(rows, null, 2));
      if (!rows?.length) return write(paint('Nothing to show.', 'dim'));
      const cells = rows.map((row) => columns.map((c) => format(c.value(row))));
      const widths = columns.map((c, i) => Math.max(c.header.length, ...cells.map((row) => visibleLength(row[i]))));
      write(paint(columns.map((c, i) => c.header.toUpperCase().padEnd(widths[i])).join('  '), 'dim'));
      for (const row of cells) write(row.map((cell, i) => pad(cell, widths[i])).join('  ').trimEnd());
      return undefined;
    },
    detail(fields) {
      if (json) return write(JSON.stringify(fields, null, 2));
      const width = Math.max(...Object.keys(fields).map((k) => k.length));
      for (const [key, value] of Object.entries(fields)) {
        write(`${paint(`${key}:`.padEnd(width + 1), 'dim')} ${format(value)}`);
      }
      return undefined;
    },
    info(message) {
      if (!json && !quiet) write(message);
    },
    success(message) {
      if (!json && !quiet) write(`${paint('✓', 'green')} ${message}`);
    },
    warn(message) {
      if (!json) stderr.write(`${paint('!', 'yellow')} ${message}\n`);
    },
    error(message) {
      stderr.write(`${paint('✗', 'red')} ${message}\n`);
    },
    raw: write,
    paint,
  };
}

function format(value) {
  if (value === null || value === undefined || value === '') return '-';
  if (value === true) return 'yes';
  if (value === false) return 'no';
  if (Array.isArray(value)) return value.length ? value.join(', ') : '-';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

// eslint-disable-next-line no-control-regex -- colour codes do not count toward a column's width
const ANSI = /\u001b\[[0-9;]*m/g;
const visibleLength = (text) => String(text).replace(ANSI, '').length;
const pad = (text, width) => `${text}${' '.repeat(Math.max(0, width - visibleLength(text)))}`;

// "3 minutes ago" is friendlier than a timestamp in a table.
export function relative(iso, now = Date.now()) {
  if (!iso) return '-';
  const seconds = Math.round((now - new Date(iso).getTime()) / 1000);
  if (!Number.isFinite(seconds)) return '-';
  const future = seconds < 0;
  const steps = [
    [60, 'second'],
    [60, 'minute'],
    [24, 'hour'],
    [7, 'day'],
    [4.345, 'week'],
    [12, 'month'],
  ];
  let value = Math.abs(seconds);
  let unit = 'second';
  for (const [size, name] of steps) {
    if (value < size) {
      unit = name;
      break;
    }
    value /= size;
    unit = name;
  }
  if (value >= 12 && unit === 'month') {
    value /= 12;
    unit = 'year';
  }
  const rounded = Math.max(1, Math.round(value));
  const plural = rounded === 1 ? unit : `${unit}s`;
  return future ? `in ${rounded} ${plural}` : `${rounded} ${plural} ago`;
}

export function bytes(value) {
  if (value === null || value === undefined) return '-';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let n = Number(value);
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n >= 10 || i === 0 ? Math.round(n) : n.toFixed(1)} ${units[i]}`;
}
