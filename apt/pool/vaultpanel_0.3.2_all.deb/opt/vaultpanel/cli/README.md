# vaultpanel

The command-line tool for [VaultPanel](https://github.com/VaultPanel/VaultPanel), a web control panel
for Linux servers. List servers, create websites, deploy apps, run containers, take backups and
follow jobs from a terminal or a CI pipeline.

```bash
npm install -g @vaultpanel/cli
vaultpanel login --url https://panel.example.com  # paste an API token when asked
vaultpanel servers list
vaultpanel apps deploy api --watch
```

Or without installing: `npx @vaultpanel/cli servers list`.

Needs Node.js 22 or newer and an API token, made in the panel under **Users > API Tokens**. The
token acts as the person who made it, limited to the scopes ticked when it was created, so the tool
can never do more than they can.

## In CI

```bash
export VAULTPANEL_URL=https://panel.example.com
export VAULTPANEL_TOKEN=vpt_…       # a token with the Deploy scope
npx @vaultpanel/cli apps deploy api --watch
```

`--watch` follows the job and exits non-zero if it fails. Exit codes: 0 worked, 1 used wrongly,
2 the panel refused or the job failed, 3 the token is not valid or not allowed.

## Commands

`whoami`, `tokens`, `dashboard`, `servers`, `websites`, `apps`, `databases`, `containers`,
`backups`, `cron`, `alerts`, `jobs`, and `api <METHOD> <path>` for any endpoint. Run
`vaultpanel --help`, or `vaultpanel <command> --help` for one of them. `--json` prints the API's
answer for `jq`.

Full guide: [docs/cli.md](https://github.com/VaultPanel/VaultPanel/blob/main/docs/cli.md).

MIT licensed.
