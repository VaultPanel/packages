# Changelog

All notable changes to VaultPanel. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and versions follow
[Semantic Versioning](https://semver.org/). Releases are the `vX.Y.Z` tags; the agent keeps its own
version (`agent/package.json`).

## [Unreleased]

## [0.3.0] - 2026-11-10

### Added

- **A free AI model on the panel's own server** (agent 0.41.0). **System > Assistant Settings** has a
  third choice, **Free model on this server**: pick a small open model from the list (it shows each
  one's download size and the memory it needs next to the server's free memory and disk) and click
  **Install**. The agent installs Ollama (a fixed release, checked against its SHA-256), runs it as
  its own service on `127.0.0.1:21434`, and downloads the model, with the progress shown as it
  goes. The assistant then answers with no API key and nothing leaves the server, more slowly and
  more simply than Claude. Only the panel and root can reach the model: a firewall rule refuses
  websites, apps and other accounts on the server. Models, or Ollama itself, can be removed again
  from the same page.

### Changed

- **Each AI provider keeps its own settings.** Switching the assistant between Claude, an
  OpenAI-compatible service and the free model on this server keeps each one's model, address and
  API key, so switching back needs nothing again (before, switching deleted the saved key).

## [0.2.1] - 2026-11-10

### Changed

- **The sidebar follows the usual control-panel order**: Overview and the AI Assistant first; then
  Infrastructure, Web, Applications and Data & Files; then **Monitoring** (a new section with
  Monitoring, Alerts, Logs and Jobs, which were under Infrastructure) and Automation; then Security,
  Hosting and Users & Access; installed plugins' pages; and **System** last, which now also holds
  **Assistant Settings**. Pages name the section they are in above their title.

## [0.2.0] - 2026-11-09

### Security

- **The panel no longer runs as root.** `vaultpanel` and `vaultpanel-worker` run as the new
  unprivileged `vaultpanel` user inside a systemd sandbox (`ProtectSystem=strict`, no capabilities,
  `NoNewPrivileges`, private `/tmp` and devices). Only connecting the panel's own server (the
  `connectLocal.js` step before the API starts) runs as root. `.env` and the TLS key are readable,
  not writable, by the panel.
- **HTTPS from the first start.** New installs serve the panel over HTTPS on its own port with a
  self-signed certificate (like Cockpit, Webmin or Proxmox), so passwords and the setup token never
  cross the network in clear. Plain HTTP stays available on `127.0.0.1` only (`VAULTPANEL_LOOPBACK_PORT`)
  for the local agent, the panel domain's NGINX and the `vaultpanel` command. HSTS is only sent where
  the certificate is trusted (a panel domain), never on an IP address or the self-signed port.
- **Pinned agent installs.** With the self-signed certificate, the "Add server" and upgrade
  commands carry the certificate's public key pin (`curl --pinnedpubkey`, `--panel-pin`). The agent
  installer checks the pin, saves the certificate as `/etc/vaultpanel-agent/panel-ca.pem` and the
  agent trusts exactly it (`NODE_EXTRA_CA_CERTS`), so servers can be added safely without a domain.
  Adding a server to a default install used to need a domain or a hand-edited command.
- **Webhooks and plugins no longer reach private networks by default**
  (`VAULTPANEL_WEBHOOK_ALLOW_PRIVATE=false`). Panels installed earlier keep their previous behaviour.
- The panel's files moved from `/var/lib/vaultpanel` (which also holds the agent's private state) to
  `/var/lib/vaultpanel/panel`, owned by the panel's user.
- **True/false settings left out of `.env` were read as on.** Their defaults came through as the
  text `"false"`, which counts as true. Every panel that install.sh set up lacks
  `VAULTPANEL_PLUGIN_ALLOW_LOCAL`, so its plugins could reach the panel's own server and private
  networks; a panel without `VAULTPANEL_ALLOW_INSECURE_AGENTS` or
  `VAULTPANEL_WEBHOOK_ALLOW_PRIVATE` in `.env` accepted agents over plain HTTP or let webhooks reach
  private networks. Settings left out take their documented defaults again.
- **Agent downloads are rate limited**: 60 a minute per address for the agent's install script,
  package and the panel's certificate, which need no sign-in. The package is built for each
  download, so endless requests could keep the panel busy. A server installing or updating its
  agent downloads each once.

### Added

- **Choose the database for websites and apps when installing.** `DB_ENGINE` (or `--db-engine`)
  installs MariaDB 12.3, 11.8, 11.4, 10.11 or 10.6, as each system offers them (see the README), on
  port 3306: from the system's own packages when they have that version, else from MariaDB's
  repository, whose signing key is checked against MariaDB's fingerprint. A new install gets the
  newest MariaDB for its system unless `DB_ENGINE=NONE`; a server that has a database server keeps
  it, and updates never change it. The summary shows it. MySQL 8.4 and 8.0 come later.
- **VaultPanel installs from packages, like CloudPanel.** Each release builds the `vaultpanel`
  package (`vaultpanel_X.Y.Z_all.deb`: the panel ready to run, with its Node.js packages and the
  built web interface) and publishes it, signed with VaultPanel's key (fingerprint
  `79B34D79D2A7D0DE54A3D906B62A47C2ED2775A6`), to VaultPanel's APT repository on the public site
  https://installer.vaultpanel.net (the VaultPanel/packages repository, GitHub Pages), with that
  release's installer at `v2/install.sh`, the WHMCS module and a README with the install command and
  the installer's checksum. The installer sets up Node.js, Docker and MariaDB, adds the repository
  after checking its key's fingerprint and runs `apt install vaultpanel`; servers no longer download
  from GitHub or build anything. The package sets the panel up on install and on every upgrade
  (`install.sh --configure`), backs it up before an upgrade, and removes its services when removed.
  `vaultpanel update` and `apt upgrade` install newer packages; `vaultpanel rollback` restores the
  backup and installs the previous version again (the repository keeps the newest 5). Installing
  from a copy of the repository, which stays git based, is for trying unreleased code. The Release
  workflow builds the package, installs it on a fresh runner from a signed copy of the site
  following the published install command (the Package workflow, also run for changes to
  packaging), and only then publishes it; pre-releases are not published. Shell scripts and the
  package's scripts keep LF line endings in Windows checkouts (`.gitattributes`).
- **Ubuntu 26.04 LTS** is supported by the installer.
- **Back up a website's or app's database from its page.** **Back up now** asks what to back up:
  on the Backups page **Website files**, **App files** or a **Database**; on a website's or app's
  Backups tab its **Files** or one of its **Databases**. That tab now lists the backups and
  schedules of its databases with its own, each marked Files or with the database's name, and
  **Add schedule** schedules either. Databases can be linked to the website that uses it, as they
  can to an app: **For website** when creating one, or **Link** on the Databases page. Databases
  made by the app installer (WordPress, Joomla, Drupal, Laravel) are linked to their website,
  including those installed before. API: `websiteId` on `POST`/`PATCH /databases` (a link left out
  of `PATCH` is now kept) and `GET /databases`, `includeDatabases=true` on `GET /backups` and
  `GET /backup-schedules`. No agent update needed.
- **Server self-check** (agent 0.39.0). Every 5 minutes each agent checks what the panel's features
  need from its server: the root helper answers, everyone can read the agent's code, the file
  manager's worker starts as a site user, `nginx -t` and `apache2ctl -t` pass, Certbot's renewal
  timer runs, the clock is synchronized and no systemd unit has failed. The server's Overview shows
  them on a **Self-check** card, with **Check now** and the command that fixes each failure. A new
  default alert rule, **Server self-check failed**, sends the usual alert emails and webhooks when a
  check fails for 10 minutes; warnings (agent running as root, Certbot timer, clock, failed units)
  only show on the card.
- **WHMCS module** (`integrations/whmcs`). Sell VaultPanel hosting from WHMCS: each service is a
  VaultPanel account that WHMCS creates, suspends, unsuspends, upgrades, terminates and sets the
  password of, with a plan dropdown read from the panel, **Log in to VaultPanel** (single sign-on),
  disk usage in WHMCS, a client-area overview and an admin tab. The billing API gains
  `GET /billing/accounts` (accounts with usage) and `POST /billing/accounts/{ref}/login`, a sign-in
  link that works once within two minutes (opened on the new `/sso` page).
- **Website uptime monitoring.** The panel checks every website the way visitors reach it, every 5
  minutes by default (`VAULTPANEL_UPTIME_CHECK_SECONDS`): over HTTPS when the certificate covers the
  domain, judging the certificate it serves like a browser. A failure is checked again 10 seconds
  later before the website counts as down. The website's Overview shows Up or Down, uptime over 24
  hours, 7 and 30 days, response time, the served certificate's expiry and recent downtime, with
  **Check now** and a switch to turn monitoring off; the Websites list marks sites that are down. A
  new default alert rule, **Website down**, sends the usual alert emails and webhooks. History is
  kept 30 days (`VAULTPANEL_UPTIME_HISTORY_DAYS`).
- **Wildcard certificates through Cloudflare or Namecheap** (agent 0.38.0). Domains whose DNS is
  at Cloudflare or Namecheap get Let's Encrypt wildcard certificates without moving their DNS to
  the panel: staff save the provider's API credentials once under **Web > DNS Zones > DNS
  providers** (stored encrypted), then choose it under **Check DNS through** on a website's SSL
  tab. The agent adds the check record through the provider's API, waits until the domain's name
  servers serve it, and keeps the credentials root-only so Certbot's renewals work too. For
  Namecheap, whose API replaces all records at once, every record and the email setting are written
  back exactly as read, and nothing is written when they cannot all be read.
- **Wildcard website domains** (agent 0.37.0). A website or app can list `*.example.com` among its
  domains to serve every subdomain that no other site lists (exact names still win, so
  `admin.example.com` can be a site of its own). A Let's Encrypt wildcard certificate covers it; a
  normal certificate covers the site's other domains and leaves the wildcard out. Wildcards over a
  registry suffix (`*.co.uk`) are refused, and a hosting customer's wildcard keeps other accounts
  off the names under it.
- `vaultpanel backup`, `vaultpanel restore` and a daily `vaultpanel-backup.timer`: the panel's
  database, settings, secret key, HTTPS certificate and terminal recordings in one archive, with
  retention, checksums, optional encryption (`VAULTPANEL_BACKUP_PASSPHRASE_FILE`) and an optional
  copy-off-the-server command (`VAULTPANEL_BACKUP_UPLOAD`). Restores work on a new server for disaster
  recovery (the new server keeps its own database passwords).
- Versioned installs: `install.sh --version vX.Y.Z` (default: the latest release), `vaultpanel update
[--version ...]`, which backs the panel up first, and `vaultpanel rollback`, which goes back to the
  previous version and its database.
- `vaultpanel https [status|on|off|renew]` to manage the panel's own certificate, and `install.sh
--https` / `--http`.
- A Release workflow that publishes tagged versions with `SHA256SUMS` and build provenance.
- End-to-end smoke tests (Playwright) and test coverage in CI; Dependabot, CodeQL and `npm audit`.
- `LICENSE`, `SECURITY.md`, `CONTRIBUTING.md`, issue and pull request templates.

### Changed

- **VaultPanel is proprietary, under the VaultPanel License** (`LICENSE`): free to install and use,
  also to host customers, but not to copy, change, resell or redistribute. Its source code is
  private; the public VaultPanel/packages repository holds the installer, the packages and the
  issues. Versions published while the repository was public stay under the license they came with
  (MIT, then for a short time AGPL-3.0). The SDK, the CLI, the WHMCS module and the example plugin
  stay MIT, with their own `LICENSE` files; the WHMCS module is now downloaded from
  installer.vaultpanel.net. Security reports go to VaultPanel/packages.
- **NodePanel is now VaultPanel** (agent 0.40.0). The new name is used everywhere: the interface,
  emails, login banners and docs; the `vaultpanel` command and CLI; the `@vaultpanel/*` packages;
  the `vaultpanel` user, services (`vaultpanel`, `vaultpanel-worker`, `vaultpanel-agent`,
  `vaultpanel-agent-helper`, `vaultpanel-backup.timer`) and folders (`/opt/vaultpanel`,
  `/opt/vaultpanel-agent`, `/etc/vaultpanel-agent`, `/var/lib/vaultpanel`…); `VAULTPANEL_*`
  settings; the `vaultpanel` database and Docker project; the `X-VaultPanel-*` headers of agents,
  webhooks and plugins; `io.vaultpanel.*` container labels; the `vaultpanel` DKIM selector; and the
  WHMCS module (`modules/servers/vaultpanel`). The short prefixes changed with it: tokens and keys
  start with `vpt_`, `vpk_`, `vpe_` and `vpp_`, plugin links carry `vp_*` parameters, and the
  accounts the agent creates are named `vp-…`. Nothing converts a NodePanel install, its agents or
  its tokens: remove NodePanel, install VaultPanel and add each server again.
- Agent install commands for a plain-HTTP panel that accepts HTTP agents now include
  `--insecure-http`, so they work as copied.
- A panel domain set up while the panel used plain HTTP is moved to the loopback port automatically
  when HTTPS is turned on.

### Fixed

- A new panel's address opened the sign-in page, with no account to sign in with yet. It now opens
  the setup page, where the owner account is created.
- Searching a list (websites, apps, databases, users, servers, backups, the audit log…) for text
  with a backslash (`\`) in it found the wrong things: the backslash changed the search. Found by
  CodeQL, as were a few other escapes and checks made stricter.
- Invite and password-reset pages only accept invite and reset links (`password_reset_tokens` now
  also holds one-time sign-in links, which must never set a password).
- The file manager failed on the panel's own server with "Cannot find module
  '/opt/vaultpanel-agent/src/services/fileWorker.js'". The panel's `UMask=0077` reached the agent
  installer it runs, leaving `/opt/vaultpanel-agent` readable by root only, so the worker (which runs
  as the site's user) and the agent's own user could not load it. The installer now sets `umask 022`
  and makes the agent's code readable by everyone, updates from the panel do the same (agent
  0.37.0), and the panel installs its own server's agent again when it starts and finds it readable
  by root only.
- Docs that still listed email for invites, password resets and alerts as not built (it is:
  **System > Panel Email**).
