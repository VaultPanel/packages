// Phase 6: server security (firewall, SSH, Fail2ban, updates) and sign-in
// security for the panel. Shared by the panel (validation), the UI (labels,
// forms, the security checks) and, through its own copies, the agent.

// ---- Addresses ------------------------------------------------------------------

const IPV4_PART = '(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)';
const IPV4 = new RegExp(`^${IPV4_PART}(?:\\.${IPV4_PART}){3}$`);

export function isIPv4(value) {
  return typeof value === 'string' && IPV4.test(value);
}

export function isIPv6(value) {
  if (typeof value !== 'string' || value.length > 45 || !value.includes(':')) return false;
  let text = value;
  let groups = 8;
  const lastColon = text.lastIndexOf(':');
  if (text.slice(lastColon + 1).includes('.')) {
    if (!isIPv4(text.slice(lastColon + 1))) return false;
    text = `${text.slice(0, lastColon + 1)}0:0`;
  }
  const halves = text.split('::');
  if (halves.length > 2) return false;
  const parts = (half) => (half === '' ? [] : half.split(':'));
  const head = parts(halves[0]);
  const tail = halves.length === 2 ? parts(halves[1]) : [];
  const all = [...head, ...tail];
  if (!all.every((g) => /^[0-9a-fA-F]{1,4}$/.test(g))) return false;
  return halves.length === 2 ? all.length < groups : all.length === groups;
}

// An address or a network: 203.0.113.7, 203.0.113.0/24, 2001:db8::/32.
export function isAddressOrNetwork(value) {
  if (typeof value !== 'string') return false;
  const [address, prefix, extra] = value.split('/');
  if (extra !== undefined) return false;
  const v4 = isIPv4(address);
  if (!v4 && !isIPv6(address)) return false;
  if (prefix === undefined) return true;
  if (!/^\d{1,3}$/.test(prefix)) return false;
  return Number(prefix) <= (v4 ? 32 : 128);
}

// Whether an address falls inside an address or network (both strings),
// IPv4 or IPv6. An IPv4 address written as ::ffff:203.0.113.7 counts as IPv4.
export function addressInNetwork(address, network) {
  if (!address || !network) return false;
  if (network === 'any') return true;
  const plain = address.replace(/^::ffff:(?=\d+\.)/i, '');
  const [base, prefix] = network.split('/');
  const v4 = isIPv4(plain);
  if (v4 !== isIPv4(base)) return false;
  if (!v4 && (!isIPv6(plain) || !isIPv6(base))) return false;
  const width = v4 ? 32 : 128;
  const bits = prefix === undefined ? width : Number(prefix);
  const shift = BigInt(width - bits);
  return ipToBigInt(plain) >> shift === ipToBigInt(base) >> shift;
}

function ipToBigInt(ip) {
  if (isIPv4(ip)) return ip.split('.').reduce((n, part) => (n << 8n) + BigInt(part), 0n);
  let text = ip;
  // An IPv4 tail (::ffff:1.2.3.4) becomes two groups.
  const last = text.lastIndexOf(':');
  if (text.slice(last + 1).includes('.')) {
    const [a, b, c, d] = text.slice(last + 1).split('.').map(Number);
    text = `${text.slice(0, last + 1)}${((a << 8) | b).toString(16)}:${((c << 8) | d).toString(16)}`;
  }
  const [head, tail] = text.split('::');
  const left = head ? head.split(':') : [];
  const right = tail ? tail.split(':') : [];
  const groups = tail === undefined ? left : [...left, ...Array(8 - left.length - right.length).fill('0'), ...right];
  return groups.reduce((n, g) => (n << 16n) + BigInt(parseInt(g, 16)), 0n);
}

// ---- Panel access by address (0.34.0) -----------------------------------------------

export const PANEL_ACCESS_SCOPES = Object.freeze({
  everyone: { label: 'Everyone', description: 'Staff and hosting customers can only use the panel from these addresses' },
  staff: { label: 'Staff only', description: 'Staff can only use the panel from these addresses; hosting customers sign in from anywhere' },
});
export const PANEL_ACCESS_SCOPE_KEYS = Object.freeze(Object.keys(PANEL_ACCESS_SCOPES));
export const PANEL_ACCESS_MAX_ADDRESSES = 50;
export const PANEL_ACCESS_NOTE_PATTERN = /^[A-Za-z0-9 .,:_()/+'-]{0,60}$/;

// ---- Firewall (UFW) -------------------------------------------------------------

export const FIREWALL_ACTIONS = Object.freeze({
  allow: { label: 'Allow', description: 'Let connections in' },
  limit: { label: 'Limit', description: 'Allow, but block an address that opens 6 or more connections in 30 seconds (good for SSH)' },
  deny: { label: 'Deny', description: 'Drop connections silently' },
  reject: { label: 'Reject', description: 'Refuse connections and tell the sender' },
});
export const FIREWALL_ACTION_KEYS = Object.freeze(Object.keys(FIREWALL_ACTIONS));
export const FIREWALL_PROTOCOLS = Object.freeze({ tcp: 'TCP', udp: 'UDP', any: 'TCP and UDP' });
export const FIREWALL_PROTOCOL_KEYS = Object.freeze(Object.keys(FIREWALL_PROTOCOLS));
export const FIREWALL_INCOMING_POLICIES = Object.freeze({
  deny: { label: 'Deny', description: 'Block everything that no rule allows (recommended)' },
  reject: { label: 'Reject', description: 'Refuse everything that no rule allows' },
  allow: { label: 'Allow', description: 'Let everything in that no rule blocks' },
});
export const FIREWALL_INCOMING_POLICY_KEYS = Object.freeze(Object.keys(FIREWALL_INCOMING_POLICIES));
export const FIREWALL_OUTGOING_POLICIES = Object.freeze({
  allow: { label: 'Allow', description: 'The server may connect anywhere that no rule blocks (usual)' },
  deny: { label: 'Deny', description: 'The server may only connect where a rule allows' },
  reject: { label: 'Reject', description: 'Like Deny, but programs are told at once instead of waiting' },
});
export const FIREWALL_OUTGOING_POLICY_KEYS = Object.freeze(Object.keys(FIREWALL_OUTGOING_POLICIES));
export const FIREWALL_DIRECTIONS = Object.freeze({ in: 'Incoming', out: 'Outgoing' });
export const FIREWALL_DIRECTION_KEYS = Object.freeze(Object.keys(FIREWALL_DIRECTIONS));
// What the agent keeps allowed when outgoing connections are denied by
// default, so the server can still reach the panel, look up names, install
// updates, keep its clock right and send mail.
export const FIREWALL_OUTGOING_KEPT = Object.freeze([
  { label: 'the panel', ports: null },
  { label: 'DNS', ports: '53' },
  { label: 'web (updates, Git, Let\'s Encrypt)', ports: '80,443' },
  { label: 'time (NTP)', ports: '123' },
  { label: 'mail, if a mail server is installed', ports: '25,465,587' },
]);
// UFW accepts at most 15 ports in one rule (a range counts as two).
export const FIREWALL_MAX_PORTS = 15;
export const FIREWALL_COMMENT_PATTERN = /^[A-Za-z0-9 .,:_()/+-]{0,60}$/;
export const FIREWALL_COMMENT_MESSAGE = 'Letters, digits, spaces and . , : _ ( ) / + - only (60 at most)';
// Shared ports that are often opened. Shown as shortcuts in the rule form.
export const FIREWALL_PRESETS = Object.freeze([
  { label: 'SSH', port: '22', protocol: 'tcp' },
  { label: 'HTTP', port: '80', protocol: 'tcp' },
  { label: 'HTTPS', port: '443', protocol: 'tcp' },
  { label: 'Web (HTTP and HTTPS)', port: '80,443', protocol: 'tcp' },
  { label: 'MySQL / MariaDB', port: '3306', protocol: 'tcp' },
  { label: 'PostgreSQL', port: '5432', protocol: 'tcp' },
]);

// Parses "22", "80,443" or "6000:6007" into [{ from, to }], or returns null.
export function parsePortSpec(spec) {
  if (typeof spec !== 'string' || !/^[0-9:,]{1,100}$/.test(spec)) return null;
  const ranges = [];
  let count = 0;
  for (const part of spec.split(',')) {
    const bounds = part.split(':');
    if (bounds.length > 2 || bounds.some((b) => !/^[1-9]\d{0,4}$/.test(b))) return null;
    const [from, to = from] = bounds.map(Number);
    if (from > 65535 || to > 65535 || to < from || (bounds.length === 2 && to === from)) return null;
    ranges.push({ from, to });
    count += bounds.length;
  }
  return count <= FIREWALL_MAX_PORTS ? ranges : null;
}

export function portSpecMessage(spec) {
  return parsePortSpec(spec) ? null : `A port (22), a list (80,443) or a range (6000:6007), up to ${FIREWALL_MAX_PORTS} ports`;
}

export function sourceMessage(source) {
  return source === 'any' || isAddressOrNetwork(source) ? null : 'Must be "any", an IP address or a network such as 203.0.113.0/24';
}

// Whether a rule (as the agent reports it) covers a TCP port.
export function ruleCoversPort(rule, port) {
  if (rule.protocol === 'udp') return false;
  if (!rule.port) return true;
  const ranges = parsePortSpec(rule.port);
  return Boolean(ranges?.some((r) => port >= r.from && port <= r.to));
}

// ---- SSH ---------------------------------------------------------------------------

export const SSH_ROOT_LOGIN = Object.freeze({
  yes: { label: 'Allowed', description: 'Root can sign in with a password or a key' },
  'prohibit-password': { label: 'Keys only', description: 'Root can sign in only with an SSH key' },
  no: { label: 'Not allowed', description: 'Root cannot sign in over SSH; use another user and sudo' },
});
export const SSH_ROOT_LOGIN_KEYS = Object.freeze(Object.keys(SSH_ROOT_LOGIN));
export const SSH_MAX_AUTH_TRIES_MIN = 1;
export const SSH_MAX_AUTH_TRIES_MAX = 10;
export const SSH_KEY_TYPES = Object.freeze([
  'ssh-ed25519',
  'ssh-rsa',
  'ecdsa-sha2-nistp256',
  'ecdsa-sha2-nistp384',
  'ecdsa-sha2-nistp521',
  'sk-ssh-ed25519@openssh.com',
  'sk-ecdsa-sha2-nistp256@openssh.com',
]);
// One public key line: type, base64 data and an optional comment. Options
// in front of the key (from=, command=…) are not accepted.
export const SSH_PUBLIC_KEY_PATTERN = new RegExp(
  `^(?:${SSH_KEY_TYPES.map((t) => t.replace(/[\\.@-]/g, '\\$&')).join('|')}) [A-Za-z0-9+/]{40,16000}={0,3}(?: [\\x20-\\x7e]{1,100})?$`,
);
export const SSH_PUBLIC_KEY_MESSAGE = 'Paste one public key, for example the contents of ~/.ssh/id_ed25519.pub';
// OpenSSH SHA256 fingerprints: "SHA256:" and 43 base64 characters.
export const SSH_FINGERPRINT_PATTERN = /^SHA256:[A-Za-z0-9+/]{43}$/;
// A Linux account name the panel may manage SSH keys for.
export const SSH_USER_PATTERN = /^[a-z_][a-z0-9_-]{0,31}$/;
// SSH may listen on two ports at once while you move it to a new one.
export const SSH_MAX_PORTS = 2;
// Ports SSH may not move to: they belong to websites and the panel's usual services.
export const SSH_RESERVED_PORTS = Object.freeze([80, 443]);
export function sshPortMessage(port) {
  if (!Number.isInteger(port) || port < 1 || port > 65535) return 'A port from 1 to 65535';
  if (SSH_RESERVED_PORTS.includes(port)) return `Port ${port} is for websites`;
  return null;
}

// ---- Fail2ban ------------------------------------------------------------------------

export const FAIL2BAN_LIMITS = Object.freeze({
  maxRetry: { min: 1, max: 20, default: 5 },
  findTimeMinutes: { min: 1, max: 1440, default: 10 },
  banTimeMinutes: { min: 1, max: 43_200, default: 60 },
});
export const FAIL2BAN_MAX_IGNORE = 20;

// ---- Software ----------------------------------------------------------------------

export const SECURITY_TOOLS = Object.freeze({
  ufw: { label: 'UFW firewall', description: 'Uncomplicated Firewall, the standard firewall on Ubuntu' },
  fail2ban: { label: 'Fail2ban', description: 'Blocks addresses that keep failing to sign in over SSH' },
  'unattended-upgrades': { label: 'Automatic updates', description: 'Installs security updates every day' },
});
export const SECURITY_TOOL_KEYS = Object.freeze(Object.keys(SECURITY_TOOLS));

// ---- Security checks -----------------------------------------------------------------

// What the panel checks on each server, from the summary the agent reports
// with its heartbeat. Returns [{ key, label, status: ok | warning | info, detail, fix }].
export function securityChecks(summary) {
  if (!summary) return [];
  const checks = [];
  const { firewall, ssh, fail2ban, updates, agent } = summary;
  if (firewall) {
    checks.push({
      key: 'firewall',
      label: 'Firewall',
      status: firewall.active ? (firewall.incoming === 'allow' ? 'warning' : 'ok') : 'warning',
      detail: !firewall.installed
        ? 'UFW is not installed'
        : !firewall.active
          ? 'The firewall is off: every listening port can be reached'
          : firewall.incoming === 'allow'
            ? 'The firewall is on but lets in everything no rule blocks'
            : `On, ${firewall.rules} rule${firewall.rules === 1 ? '' : 's'}`,
      fix: 'firewall',
    });
  }
  if (ssh?.installed) {
    const rootPasswords = ssh.permitRootLogin === 'yes' && ssh.passwordAuthentication;
    checks.push({
      key: 'ssh_root',
      label: 'Root sign-in over SSH',
      status: rootPasswords ? 'warning' : 'ok',
      detail: rootPasswords
        ? 'Root can sign in with a password, the account attackers try first'
        : ssh.permitRootLogin === 'no'
          ? 'Root cannot sign in over SSH'
          : 'Root can sign in only with a key',
      fix: 'ssh',
    });
    checks.push({
      key: 'ssh_passwords',
      label: 'SSH passwords',
      status: ssh.passwordAuthentication ? 'warning' : 'ok',
      detail: ssh.passwordAuthentication ? 'Password sign-in is on; SSH keys are much harder to guess' : 'Only SSH keys are accepted',
      fix: 'ssh',
    });
  }
  if (fail2ban) {
    const on = fail2ban.active && fail2ban.sshd;
    checks.push({
      key: 'fail2ban',
      label: 'Brute-force protection',
      status: on ? 'ok' : 'warning',
      detail: !fail2ban.installed
        ? 'Fail2ban is not installed'
        : on
          ? `Fail2ban watches SSH${fail2ban.banned ? `, ${fail2ban.banned} address${fail2ban.banned === 1 ? '' : 'es'} blocked now` : ''}`
          : 'Fail2ban is installed but not protecting SSH',
      fix: 'fail2ban',
    });
  }
  if (updates) {
    checks.push({
      key: 'auto_updates',
      label: 'Automatic security updates',
      status: updates.automatic ? 'ok' : 'warning',
      detail: updates.automatic ? 'Security updates install every day' : updates.installed ? 'Installed but turned off' : 'Not installed',
      fix: 'updates',
    });
    if (Number.isInteger(updates.pendingSecurity)) {
      checks.push({
        key: 'pending_updates',
        label: 'Waiting security updates',
        status: updates.pendingSecurity > 0 ? 'warning' : 'ok',
        detail: updates.pendingSecurity > 0 ? `${updates.pendingSecurity} security update${updates.pendingSecurity === 1 ? '' : 's'} not installed yet` : 'None',
        fix: 'updates',
      });
    }
    if (updates.rebootRequired) {
      checks.push({ key: 'reboot', label: 'Restart needed', status: 'info', detail: 'Installed updates take full effect after a restart', fix: null });
    }
  }
  // Agents 0.36.0 and later run as their own user, with a root helper for
  // what the panel signed.
  if (agent?.user) {
    const root = agent.user === 'root';
    checks.push({
      key: 'agent_user',
      label: 'Agent privileges',
      status: root ? 'warning' : 'ok',
      detail: root
        ? `The agent runs as root${agent.reason ? `: ${agent.reason}` : ''}`
        : `The agent runs as ${agent.user}; a root helper runs only what the panel signed`,
      fix: null,
    });
  }
  return checks;
}

// ---- Panel sign-in -----------------------------------------------------------------

export const TWO_FACTOR_POLICIES = Object.freeze({
  off: { label: 'Optional', description: 'Each person decides whether to use two-factor sign-in' },
  admins: { label: 'Owners and admins', description: 'Owners and admins must use two-factor sign-in' },
  all: { label: 'Everyone', description: 'Every account must use two-factor sign-in' },
});
export const TWO_FACTOR_POLICY_KEYS = Object.freeze(Object.keys(TWO_FACTOR_POLICIES));

export function twoFactorRequiredFor(policy, roles = []) {
  if (policy === 'all') return true;
  if (policy === 'admins') return roles.some((r) => r === 'owner' || r === 'admin');
  return false;
}

// Recovery codes: ten one-time codes such as "7kq3m-x9t2p".
export const RECOVERY_CODE_COUNT = 10;
export const RECOVERY_CODE_PATTERN = /^[a-z0-9]{5}-?[a-z0-9]{5}$/i;

// ---- App resource limits -----------------------------------------------------------

// CPU as a percentage of one core (200 = two cores), memory in MiB.
export const APP_CPU_LIMIT = Object.freeze({ min: 10, max: 6400 });
export const APP_MEMORY_LIMIT_MB = Object.freeze({ min: 64, max: 262_144 });
// How many copies of an app run on its server (PM2 cluster mode for Node.js,
// WEB_CONCURRENCY workers for Python). The limits above cover all copies.
export const APP_INSTANCES = Object.freeze({ min: 1, max: 16 });
