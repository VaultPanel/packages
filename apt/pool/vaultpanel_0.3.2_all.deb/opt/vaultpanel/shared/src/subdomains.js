// Subdomains and the name servers customers see. Shared by the panel
// (checks, automatic DNS zones) and the UI (forms).

import { DOMAIN_PATTERN, SITE_NAME_PATTERN, isReservedSiteName } from './websites.js';

// What goes before the parent domain: one or more labels, such as blog or
// shop.eu. "www" alone is left to the parent site (it is usually one of its
// domains).
export const SUBDOMAIN_PATTERN = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/;
export const SUBDOMAIN_MESSAGE = 'Use letters, digits and dashes, such as blog or shop';

export function subdomainProblems(name, parent) {
  const value = String(name ?? '').trim().toLowerCase();
  if (!value) return [{ field: 'name', message: 'Enter the subdomain, such as blog' }];
  if (!SUBDOMAIN_PATTERN.test(value)) return [{ field: 'name', message: SUBDOMAIN_MESSAGE }];
  if (value === 'www') return [{ field: 'name', message: `www.${parent} belongs with ${parent}: add it to that website’s domains instead` }];
  if (!DOMAIN_PATTERN.test(`${value}.${parent}`)) return [{ field: 'name', message: 'The full name is too long' }];
  return [];
}

// Second-level suffixes under which people register domains (example.co.uk).
// Not the full public suffix list: it decides only when VaultPanel adds a DNS
// zone for a customer's domain by itself, so a miss means no zone is added.
const SECOND_LEVEL = new Set([
  'co.uk', 'org.uk', 'me.uk', 'ltd.uk', 'plc.uk', 'net.uk', 'ac.uk', 'gov.uk',
  'com.au', 'net.au', 'org.au', 'co.nz', 'net.nz', 'org.nz', 'co.za', 'org.za',
  'com.br', 'net.br', 'org.br', 'co.in', 'net.in', 'org.in', 'firm.in', 'co.jp', 'ne.jp', 'or.jp',
  'com.tr', 'net.tr', 'org.tr', 'com.mx', 'org.mx', 'com.ar', 'com.co', 'com.pe', 'com.cn', 'net.cn', 'org.cn',
  'com.hk', 'com.sg', 'com.my', 'com.ph', 'com.pk', 'com.ng', 'com.eg', 'com.sa', 'com.ua', 'co.il', 'co.kr', 'or.kr',
  'co.id', 'co.th', 'com.vn', 'com.tw', 'com.af', 'org.af', 'net.af', 'co.ke', 'co.tz', 'co.ug',
]);

// Whether a name is a registered domain itself (example.com,
// example.co.uk), not a name under one (blog.example.com).
export function isRegisteredDomain(domain) {
  const labels = String(domain ?? '').toLowerCase().split('.');
  if (labels.length === 2) return true;
  return labels.length === 3 && SECOND_LEVEL.has(labels.slice(1).join('.'));
}

// Whether a name is a suffix people register domains under (co.uk), so a
// website's wildcard over it (*.co.uk) would catch other people's domains.
export function isDomainSuffix(domain) {
  return SECOND_LEVEL.has(String(domain ?? '').toLowerCase());
}

// The names a domain sits under, nearest first (a.b.example.com:
// b.example.com, example.com). Single labels (com) are left out.
export function parentDomains(domain) {
  const labels = String(domain ?? '').split('.');
  const out = [];
  for (let i = 1; i < labels.length - 1; i += 1) out.push(labels.slice(i).join('.'));
  return out;
}

// A site name for a domain, unique among taken: blog.example.com ->
// blog-example-com (then blog-example-com-2...). Null when none fits.
export function siteNameForDomain(domain, taken = []) {
  let base = String(domain ?? '')
    .toLowerCase()
    .replace(/^www\./, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^[^a-z]+/, '')
    .slice(0, 29)
    .replace(/-+$/, '');
  if (base.length < 3) base = `${base || 'sub'}-site`;
  const used = new Set(taken);
  for (let i = 1; i < 100; i += 1) {
    const name = i === 1 ? base : `${base}-${i}`;
    if (SITE_NAME_PATTERN.test(name) && !isReservedSiteName(name) && !used.has(name)) return name;
  }
  return null;
}
