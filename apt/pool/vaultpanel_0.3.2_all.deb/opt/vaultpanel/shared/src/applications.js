// Node.js and Python applications deployed from Git and kept running by PM2.
// Shared by the panel (validation), the agent (which keeps its own copy of
// the patterns and re-checks everything) and the UI (forms, labels).

export const APP_RUNTIMES = Object.freeze({
  node: {
    label: 'Node.js',
    description: 'Runs with the server’s Node.js. Dependencies are installed with npm.',
    defaultStartCommand: 'npm start',
  },
  python: {
    label: 'Python',
    description: 'Runs in its own virtual environment. Dependencies come from requirements.txt.',
    defaultStartCommand: 'gunicorn app:app',
  },
  go: {
    label: 'Go',
    description: 'Built with the server’s Go into one program. Modules come from go.mod.',
    defaultBuildCommand: 'go build -o app .',
    defaultStartCommand: './app',
  },
  ruby: {
    label: 'Ruby',
    description: 'Gems from the Gemfile are installed with Bundler into the release. Runs in production mode.',
    defaultStartCommand: 'bundle exec puma -b tcp://127.0.0.1:$PORT',
  },
});
// Go and Ruby apps need this agent version.
export const NEW_RUNTIMES_MIN_AGENT_VERSION = '0.32.0';
// Runtimes that run as one process (no PM2 copies; Puma and Go handle
// concurrency themselves).
export const SINGLE_PROCESS_RUNTIMES = Object.freeze(['go', 'ruby']);
// Zero-downtime reloads: Node.js apps in PM2 cluster mode, from this agent version.
export const ZERO_DOWNTIME_MIN_AGENT_VERSION = '0.32.0';
export const APP_RUNTIME_KEYS = Object.freeze(Object.keys(APP_RUNTIMES));

// creating: the agent is setting up the app's user and folders.
// ready: set up; it may or may not have a release running (see the process state).
// deploying, updating, deleting: a change is running.
// failed: the setup itself failed (retry it or delete the app).
export const APP_STATUSES = Object.freeze(['creating', 'ready', 'deploying', 'updating', 'deleting', 'failed']);
export const APP_BUSY_STATUSES = Object.freeze(['creating', 'deploying', 'updating', 'deleting']);

// The process as the agent last saw it (systemd unit pm2-<name>).
export const APP_PROCESS_STATES = Object.freeze(['running', 'stopped', 'failed', 'starting', 'unknown']);

export const DEPLOYMENT_STATUSES = Object.freeze(['queued', 'running', 'succeeded', 'failed', 'cancelled']);
export const DEPLOYMENT_TRIGGERS = Object.freeze(['manual', 'create', 'webhook', 'rollback']);

// The stages a deployment goes through, in order. A failed deployment names
// the stage it stopped at.
export const DEPLOY_STAGES = Object.freeze({
  prepare: 'Prepare the app user and folders',
  fetch: 'Clone the repository',
  install: 'Install dependencies',
  build: 'Build',
  configure: 'Write the environment and process configuration',
  start: 'Switch to the new release and start it',
  health_check: 'Check the app answers',
});
export const DEPLOY_STAGE_KEYS = Object.freeze(Object.keys(DEPLOY_STAGES));
// Agent error codes that tell which stage a deployment failed at.
export const DEPLOY_ERROR_STAGES = Object.freeze({
  PREPARE_FAILED: 'prepare',
  CLONE_FAILED: 'fetch',
  INSTALL_FAILED: 'install',
  BUILD_FAILED: 'build',
  CONFIGURE_FAILED: 'configure',
  START_FAILED: 'start',
  HEALTH_CHECK_FAILED: 'health_check',
});

// Git repositories: https://host/path, ssh://[user@]host[:port]/path or
// user@host:path. No credentials in the URL (use the app's deploy key for
// private repositories), and nothing a Git remote helper could run.
export const REPOSITORY_URL_PATTERN =
  /^(?:https:\/\/[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?\/[A-Za-z0-9_~][A-Za-z0-9._~/-]*|ssh:\/\/(?:[a-z0-9_][a-z0-9_.-]*@)?[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?\/[A-Za-z0-9_~][A-Za-z0-9._~/-]*|[a-z0-9_][a-z0-9_.-]*@[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?:[A-Za-z0-9_~][A-Za-z0-9._~/-]*)$/i;
export const REPOSITORY_URL_MESSAGE = 'Use an https:// or SSH Git URL, such as https://github.com/you/app.git or git@github.com:you/app.git, without a password in it';
export const MAX_REPOSITORY_URL_LENGTH = 500;

// A branch name Git accepts (a practical subset of git check-ref-format).
export const BRANCH_PATTERN = /^(?![-/.])(?!.*(?:\.\.|\/\/|@\{|\/\.|\.lock$|\.$|\/$))[A-Za-z0-9._/-]{1,200}$/;
export const BRANCH_MESSAGE = 'Enter a branch name such as main';

// Ports apps listen on, on 127.0.0.1. Ports below 1024 need root.
export const APP_PORT_MIN = 1024;
export const APP_PORT_MAX = 65535;
// Ports the server's own services usually take.
export const RESERVED_APP_PORTS = Object.freeze([3306, 5432, 6379, 11211, 27017]);

export const ENV_KEY_PATTERN = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;
export const ENV_KEY_MESSAGE = 'Use letters, digits and underscores, not starting with a digit';
// Set by VaultPanel for every app, so they cannot be set by hand.
export const RESERVED_ENV_KEYS = Object.freeze(['PORT', 'PATH', 'HOME', 'USER', 'PM2_HOME']);
export const MAX_ENV_VARS = 100;
export const MAX_ENV_VALUE_LENGTH = 8192;
// How environment variables travel to the agent: "KEY=value".
export const ENV_ENTRY_PATTERN = /^[A-Za-z_][A-Za-z0-9_]{0,127}=[^\0]*$/;

// Commands (install, build, start) run as the app's user without a shell:
// one command per line, arguments split like a shell would, but no pipes,
// redirects, globs or variables except $PORT.
export const MAX_COMMAND_LINES = 10;
export const MAX_COMMAND_LENGTH = 500;
export const COMMAND_TEXT_PATTERN = /^[^\0\r]*$/;

export const RELEASE_ID_PATTERN = /^[0-9]{14}-[a-f0-9]{6}$/;
export const DEFAULT_KEEP_RELEASES = 5;
export const MAX_KEEP_RELEASES = 20;
export const APP_LOG_KINDS = Object.freeze(['output', 'error']);

// Splits one command line into its arguments. Returns { argv } or { error }.
export function splitCommand(line) {
  const argv = [];
  let current = '';
  let inWord = false;
  let quote = null;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quote) {
      if (ch === quote) quote = null;
      else if (ch === '\\' && quote === '"' && (line[i + 1] === '"' || line[i + 1] === '\\')) current += line[++i];
      else current += ch;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      inWord = true;
    } else if (ch === ' ' || ch === '\t') {
      if (inWord) argv.push(current);
      current = '';
      inWord = false;
    } else if (ch === '\\') {
      if (i + 1 < line.length) current += line[++i];
      inWord = true;
    } else if ('|&;<>`'.includes(ch) || (ch === '$' && line[i + 1] === '(')) {
      return { error: `Commands run without a shell, so "${ch === '$' ? '$(' : ch}" is not supported. Put each command on its own line.` };
    } else {
      current += ch;
      inWord = true;
    }
  }
  if (quote) return { error: 'A quote is not closed' };
  if (inWord) argv.push(current);
  if (!argv.length) return { error: 'Empty command' };
  return { argv };
}

// Splits a multi-line command field into commands. Blank lines and lines
// starting with # are skipped. Returns { commands: [argv...] } or { error }.
export function parseCommands(text) {
  if (typeof text !== 'string' || !COMMAND_TEXT_PATTERN.test(text)) return { error: 'Commands must be plain text' };
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith('#'));
  if (lines.length > MAX_COMMAND_LINES) return { error: `Up to ${MAX_COMMAND_LINES} commands` };
  const commands = [];
  for (const [i, line] of lines.entries()) {
    if (line.length > MAX_COMMAND_LENGTH) return { error: `Line ${i + 1} is longer than ${MAX_COMMAND_LENGTH} characters` };
    const { argv, error } = splitCommand(line);
    if (error) return { error: lines.length > 1 ? `Line ${i + 1}: ${error}` : error };
    commands.push(argv);
  }
  return { commands };
}

// Problems with an app definition that per-field checks cannot see.
// Returns [{ field, message }].
export function applicationProblems({ startCommand, installCommand, buildCommand, port }) {
  const problems = [];
  for (const [field, value, required] of [
    ['startCommand', startCommand, true],
    ['installCommand', installCommand, false],
    ['buildCommand', buildCommand, false],
  ]) {
    if (value === undefined || value === null) continue;
    const parsed = parseCommands(value);
    if (parsed.error) problems.push({ field, message: parsed.error });
    else if (field === 'startCommand' && parsed.commands.length !== 1) {
      problems.push({ field, message: required && !parsed.commands.length ? 'Enter the command that starts the app' : 'The start command is a single line' });
    }
  }
  if (port !== undefined && port !== null && RESERVED_APP_PORTS.includes(port)) {
    problems.push({ field: 'port', message: `Port ${port} is usually taken by a database or cache. Choose another.` });
  }
  return problems;
}

export function envProblems(entries) {
  const problems = [];
  const seen = new Set();
  for (const [i, { key, value }] of entries.entries()) {
    if (!ENV_KEY_PATTERN.test(key ?? '')) problems.push({ field: `env.${i}.key`, message: ENV_KEY_MESSAGE });
    else if (RESERVED_ENV_KEYS.includes(key)) problems.push({ field: `env.${i}.key`, message: `${key} is set by VaultPanel` });
    else if (seen.has(key)) problems.push({ field: `env.${i}.key`, message: `${key} is listed twice` });
    seen.add(key);
    if (typeof value !== 'string' || value.length > MAX_ENV_VALUE_LENGTH || value.includes('\0')) {
      problems.push({ field: `env.${i}.value`, message: `Values are text up to ${MAX_ENV_VALUE_LENGTH} characters` });
    }
  }
  if (entries.length > MAX_ENV_VARS) problems.push({ field: 'env', message: `Up to ${MAX_ENV_VARS} variables` });
  return problems;
}
