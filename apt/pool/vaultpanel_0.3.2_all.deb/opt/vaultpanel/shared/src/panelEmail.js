// Email the panel sends itself (System > Panel Email): the SMTP connection, and
// which events are emailed to whom.

export const PANEL_EMAIL_SECURITY = Object.freeze({
  tls: { label: 'SSL/TLS', description: 'Encrypted from the start (usually port 465)', port: 465 },
  starttls: { label: 'STARTTLS', description: 'Plain connection upgraded to TLS, required (usually port 587)', port: 587 },
  none: { label: 'None', description: 'No encryption (only for a mail server on this machine or network)', port: 25 },
});
export const PANEL_EMAIL_SECURITY_KEYS = Object.freeze(Object.keys(PANEL_EMAIL_SECURITY));

// Events emailed when nothing else was chosen: the ones that need someone.
export const PANEL_EMAIL_DEFAULT_EVENTS = Object.freeze(['backup.failed', 'restore.failed', 'cron.failed', 'deployment.failed', 'alert.firing', 'server.offline']);

export const PANEL_EMAIL_MAX_RECIPIENTS = 10;
export const PANEL_EMAIL_MAX_ATTEMPTS = 4;

export const PANEL_EMAIL_PURPOSES = Object.freeze({
  test: 'Test',
  invite: 'Invite',
  reset: 'Password reset',
  alert: 'Alert',
});
