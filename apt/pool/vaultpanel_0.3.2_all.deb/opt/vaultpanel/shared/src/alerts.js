// What an alert rule can watch. Shared by the panel (validation, evaluation)
// and the UI (forms, labels).
//
// kind 'metric' compares the latest agent sample with a threshold;
// 'offline' fires while the agent is not reporting; 'service' fires while a
// watched service is failed, or stopped although enabled at boot; 'website'
// fires while a website on the server fails the panel's uptime checks;
// 'selfcheck' fires while one of the server's self-checks fails (selfCheck.js).
export const ALERT_METRICS = Object.freeze({
  cpu_percent: { label: 'CPU usage', kind: 'metric', unit: '%', min: 1, max: 100 },
  memory_percent: { label: 'Memory usage', kind: 'metric', unit: '%', min: 1, max: 100 },
  disk_percent: { label: 'Disk usage', kind: 'metric', unit: '%', min: 1, max: 100 },
  swap_percent: { label: 'Swap usage', kind: 'metric', unit: '%', min: 1, max: 100 },
  load_per_core: { label: 'Load per CPU core', kind: 'metric', unit: '', min: 0.1, max: 100 },
  server_offline: { label: 'Server offline', kind: 'offline' },
  service_down: { label: 'Service down', kind: 'service' },
  website_down: { label: 'Website down', kind: 'website' },
  self_check_failed: { label: 'Server self-check failed', kind: 'selfcheck' },
});

export const ALERT_METRIC_KEYS = Object.freeze(Object.keys(ALERT_METRICS));
export const ALERT_SEVERITIES = Object.freeze(['warning', 'critical']);
// pending: the condition holds but not yet for the rule's duration.
export const ALERT_EVENT_STATUSES = Object.freeze(['pending', 'firing', 'resolved']);
// Longest a condition can be required to hold before an alert fires.
export const ALERT_MAX_DURATION_SECONDS = 24 * 3600;
