// DNS zones served by BIND on the panel's own servers. Shared by the panel
// (validation, default records), the UI (forms, labels) and, through its
// own copy (agent/src/security/dnsRules.js), the agent.

import { isIPv4, isIPv6 } from './security.js';

export const DNS_RECORD_TYPES = Object.freeze({
  A: { label: 'A', description: 'Points a name at an IPv4 address', valueLabel: 'IPv4 address', placeholder: '203.0.113.10' },
  AAAA: { label: 'AAAA', description: 'Points a name at an IPv6 address', valueLabel: 'IPv6 address', placeholder: '2001:db8::10' },
  CNAME: { label: 'CNAME', description: 'Makes a name an alias of another name', valueLabel: 'Target name', placeholder: 'example.com' },
  MX: { label: 'MX', description: 'The mail server for the name', valueLabel: 'Mail server', placeholder: 'mail.example.com', priority: true },
  TXT: { label: 'TXT', description: 'Text, such as SPF, DKIM, DMARC or a site verification', valueLabel: 'Text', placeholder: 'v=spf1 a mx ~all' },
  NS: { label: 'NS', description: 'A name server for the name', valueLabel: 'Name server', placeholder: 'ns1.example.com' },
  SRV: { label: 'SRV', description: 'Where a service runs (priority, weight, port and host)', valueLabel: 'Target host', placeholder: 'sip.example.com', priority: true, weight: true, port: true },
  CAA: { label: 'CAA', description: 'Which certificate authorities may issue certificates', valueLabel: 'Value', placeholder: 'letsencrypt.org', tag: true },
});
export const DNS_RECORD_TYPE_KEYS = Object.freeze(Object.keys(DNS_RECORD_TYPES));
export const DNS_CAA_TAGS = Object.freeze(['issue', 'issuewild', 'iodef']);

// creating: the first apply runs; active: on the server (later changes apply
// on their own); failed: the first apply failed; deleting: being removed.
export const DNS_ZONE_STATUSES = Object.freeze(['creating', 'active', 'failed', 'deleting']);
// What public DNS says about the zone's name servers.
export const DNS_DELEGATION_STATUSES = Object.freeze(['ok', 'partial', 'elsewhere', 'unresolved', 'error']);

export const DNS_TTL = Object.freeze({ min: 60, max: 604_800, default: 3600 });
export const MAX_DNS_RECORDS = 500;
export const MAX_DNS_TXT_LENGTH = 2048;
export const MAX_DNS_NAMESERVERS = 4;

// One label: letters, digits, dashes and underscores (_dmarc, _sip._tcp).
const LABEL = '[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9])?';
// A record's name inside its zone: @ for the zone itself, a name such as www
// or _dmarc, or a wildcard (* or *.dev).
export const DNS_RECORD_NAME_PATTERN = new RegExp(`^(?=.{1,200}$)(?:@|\\*|(?:\\*\\.)?${LABEL}(?:\\.${LABEL})*)$`);
export const DNS_RECORD_NAME_MESSAGE = 'Use @ for the domain itself, or a name such as www, mail or _dmarc';
// A full host name a record points at, without the final dot.
export const DNS_HOSTNAME_PATTERN = new RegExp(`^(?=.{3,253}$)${LABEL}(?:\\.${LABEL})+$`);
export const DNS_HOSTNAME_MESSAGE = 'Enter a full host name such as mail.example.com';
// Printable ASCII; the agent quotes and splits it into 255-character strings.
export const DNS_TXT_PATTERN = /^[\x20-\x7E]{1,2048}$/;
export const DNS_TXT_MESSAGE = 'Printable characters only, up to 2048';
export const DNS_CAA_VALUE_PATTERN = /^[A-Za-z0-9.:;/=_@+-]{1,255}$/;
// The zone's contact address (SOA record).
export const DNS_EMAIL_PATTERN = /^[a-z0-9](?:[a-z0-9._+-]{0,62}[a-z0-9])?@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]*[a-z0-9]$/;

// A full name such as www.example.com, from a record name and its zone.
export function dnsFullName(name, zone) {
  return name === '@' ? zone : `${name}.${zone}`;
}

// A record name relative to its zone, from what someone typed: "@", "www",
// "www.example.com" or "www.example.com." all work.
export function dnsRelativeName(input, zone) {
  const name = String(input ?? '').trim().toLowerCase().replace(/\.$/, '');
  if (name === '' || name === '@' || name === zone) return '@';
  if (name.endsWith(`.${zone}`)) return name.slice(0, -zone.length - 1);
  return name;
}

// A host name as stored: lowercase, without the final dot.
export const dnsHostname = (value) => String(value ?? '').trim().toLowerCase().replace(/\.$/, '');

// Problems with one record. Returns [{ field, message }].
export function dnsRecordProblems(record) {
  const problems = [];
  const add = (field, message) => problems.push({ field, message });
  const type = DNS_RECORD_TYPES[record.type];
  if (!type) return [{ field: 'type', message: `Use one of ${DNS_RECORD_TYPE_KEYS.join(', ')}` }];
  if (!DNS_RECORD_NAME_PATTERN.test(record.name ?? '')) add('name', DNS_RECORD_NAME_MESSAGE);
  if (record.ttl !== null && record.ttl !== undefined && (!Number.isInteger(record.ttl) || record.ttl < DNS_TTL.min || record.ttl > DNS_TTL.max)) {
    add('ttl', `From ${DNS_TTL.min} to ${DNS_TTL.max} seconds`);
  }
  const value = record.value ?? '';
  switch (record.type) {
    case 'A':
      if (!isIPv4(value)) add('value', 'Enter an IPv4 address such as 203.0.113.10');
      break;
    case 'AAAA':
      if (!isIPv6(value)) add('value', 'Enter an IPv6 address such as 2001:db8::10');
      break;
    case 'TXT':
      if (!DNS_TXT_PATTERN.test(value)) add('value', DNS_TXT_MESSAGE);
      break;
    case 'CAA':
      if (!DNS_CAA_TAGS.includes(record.tag)) add('tag', `Use ${DNS_CAA_TAGS.join(', ')}`);
      if (!DNS_CAA_VALUE_PATTERN.test(value)) add('value', 'Enter a value such as letsencrypt.org or mailto:security@example.com');
      break;
    default:
      if (!DNS_HOSTNAME_PATTERN.test(value)) add('value', DNS_HOSTNAME_MESSAGE);
  }
  const int16 = (field, min = 0) => {
    const v = record[field];
    if (!Number.isInteger(v) || v < min || v > 65535) add(field, `From ${min} to 65535`);
  };
  if (type.priority) int16('priority');
  if (type.weight) int16('weight');
  if (type.port) int16('port', 1);
  if (record.type === 'CNAME' && record.name === '@') add('name', 'The domain itself cannot be an alias (CNAME); use an A record');
  return problems;
}

// Problems across the records of one zone. Returns [{ field, message }].
export function dnsZoneProblems(records) {
  const problems = [];
  if (records.length > MAX_DNS_RECORDS) problems.push({ field: 'records', message: `A zone can have up to ${MAX_DNS_RECORDS} records` });
  if (!records.some((r) => r.type === 'NS' && r.name === '@')) {
    problems.push({ field: 'records', message: 'The zone needs at least one NS record for @ (its name servers)' });
  }
  const names = new Map();
  for (const r of records) {
    const list = names.get(r.name) ?? [];
    list.push(r);
    names.set(r.name, list);
  }
  for (const [name, list] of names) {
    if (list.some((r) => r.type === 'CNAME') && list.length > 1) {
      problems.push({ field: 'records', message: `${name} has a CNAME record, so it cannot have other records` });
    }
  }
  const seen = new Set();
  for (const r of records) {
    const key = [r.name, r.type, r.value, r.priority ?? '', r.weight ?? '', r.port ?? '', r.tag ?? ''].join('|');
    if (seen.has(key)) problems.push({ field: 'records', message: `${r.name} ${r.type} ${r.value} is listed twice` });
    seen.add(key);
  }
  return problems;
}

// DNS hosted elsewhere, where the agent adds Let's Encrypt's check record
// through the provider's API for wildcard certificates (agent 0.38.0).
// Namecheap turns its API on only for some accounts (20 domains, or $50 on
// the account or spent in two years) and answers only the IPv4 addresses
// whitelisted there.
export const DNS_PROVIDER_TYPES = Object.freeze({
  cloudflare: {
    label: 'Cloudflare',
    secretLabel: 'API token',
    secretHint: 'A token with the Zone > DNS > Edit permission for your domains (My Profile > API Tokens > Create Token > Edit zone DNS).',
  },
  namecheap: {
    label: 'Namecheap',
    userLabel: 'API user',
    userHint: 'Your Namecheap user name.',
    secretLabel: 'API key',
    secretHint: 'Profile > Tools > Namecheap API Access. Whitelist the IPv4 address of each server that issues certificates there.',
  },
});
export const DNS_PROVIDER_TYPE_KEYS = Object.freeze(Object.keys(DNS_PROVIDER_TYPES));
export const DNS_PROVIDER_MIN_AGENT_VERSION = '0.38.0';
export const DNS_PROVIDER_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9 ._()-]{0,59}$/;
export const CLOUDFLARE_TOKEN_PATTERN = /^[A-Za-z0-9_-]{20,200}$/;
export const NAMECHEAP_USER_PATTERN = /^[A-Za-z0-9_.-]{2,64}$/;
export const NAMECHEAP_KEY_PATTERN = /^[A-Za-z0-9]{16,64}$/;

// Zone serials are YYYYMMDDnn and only ever grow.
export function nextDnsSerial(current, now = new Date()) {
  const day = Number(`${now.getUTCFullYear()}${String(now.getUTCMonth() + 1).padStart(2, '0')}${String(now.getUTCDate()).padStart(2, '0')}00`);
  return Math.max(Number(current ?? 0) + 1, day);
}

// The records a new zone starts with: its name servers (with their
// addresses when they are inside the zone), the domain and www pointing at
// the server, and optionally the mail records.
export function defaultDnsRecords({ domain, ipv4 = null, ipv6 = null, nameservers = null, mail = true }) {
  const records = [];
  const ns = nameservers?.length ? nameservers : [`ns1.${domain}`, `ns2.${domain}`];
  for (const host of ns) records.push({ name: '@', type: 'NS', value: host });
  const pointAt = (name) => {
    if (ipv4) records.push({ name, type: 'A', value: ipv4 });
    if (ipv6) records.push({ name, type: 'AAAA', value: ipv6 });
  };
  pointAt('@');
  pointAt('www');
  for (const host of ns) if (host.endsWith(`.${domain}`)) pointAt(host.slice(0, -domain.length - 1));
  if (mail) {
    pointAt('mail');
    records.push({ name: '@', type: 'MX', value: `mail.${domain}`, priority: 10 });
    records.push({ name: '@', type: 'TXT', value: 'v=spf1 a mx ~all' });
  }
  return records;
}
