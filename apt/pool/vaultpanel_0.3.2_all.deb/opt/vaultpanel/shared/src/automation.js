// Phase 5: backups, cron jobs, logs and webhooks. Shared by the panel
// (validation), the UI (labels, forms) and, through its own copies, the agent.

// ---- Backups ----------------------------------------------------------------

// What can be backed up. The agent names them site, app and database.
// choiceLabel is what "Back up now" offers; a website's or app's own Backups
// tab also offers the databases linked to it.
export const BACKUP_RESOURCES = Object.freeze({
  website: {
    label: 'Website',
    choiceLabel: 'Website files',
    agentKind: 'site',
    description: 'Every file in the site’s folder (temporary files left out)',
  },
  application: {
    label: 'App',
    choiceLabel: 'App files',
    agentKind: 'app',
    description: 'The live release, shared files, .env and deploy key (older releases, logs and PM2 state left out)',
  },
  database: {
    label: 'Database',
    choiceLabel: 'Database',
    agentKind: 'database',
    description: 'A compressed SQL dump of the whole database (tables, views, routines, triggers and events)',
  },
});
export const BACKUP_RESOURCE_TYPES = Object.freeze(Object.keys(BACKUP_RESOURCES));
export const BACKUP_AGENT_KINDS = Object.freeze(['site', 'app', 'database']);

// creating: the agent is writing it. completed: on the server, checksum known.
// failed: it was never written. deleting: its file is being removed.
// missing: the file is no longer on the server (removed by hand).
export const BACKUP_STATUSES = Object.freeze(['creating', 'completed', 'failed', 'deleting', 'missing']);
export const BACKUP_TRIGGERS = Object.freeze({
  manual: 'Backed up by hand',
  schedule: 'Scheduled',
  pre_restore: 'Safety copy before a restore',
});
export const RESTORE_STATUSES = Object.freeze(['running', 'succeeded', 'failed']);

// Where backups are kept: on their server, or in S3-compatible storage or
// on another server over SFTP, set up by the owner (Backups > Storage). A copy can always be downloaded
// through the panel.
export const BACKUP_STORAGE = Object.freeze({
  server: { label: 'On the server', description: 'In /var/backups/vaultpanel, readable by root only', available: true },
  s3: { label: 'S3-compatible storage', description: 'Amazon S3, Backblaze B2, Wasabi, MinIO…', available: true },
  sftp: { label: 'Another server (SFTP)', description: 'Copies to a server you choose', available: true },
});

// Ready-made settings for well-known S3-compatible services. {region} in an
// endpoint is replaced by the region typed in.
export const BACKUP_STORAGE_PROVIDERS = Object.freeze({
  aws: { label: 'Amazon S3', endpoint: 'https://s3.{region}.amazonaws.com', region: 'us-east-1', pathStyle: false, regionHint: 'Such as us-east-1 or eu-central-1' },
  b2: { label: 'Backblaze B2', endpoint: 'https://s3.{region}.backblazeb2.com', region: 'us-west-004', pathStyle: false, regionHint: 'The part of the bucket’s S3 endpoint after "s3.", such as us-west-004' },
  wasabi: { label: 'Wasabi', endpoint: 'https://s3.{region}.wasabisys.com', region: 'us-east-1', pathStyle: false, regionHint: 'Such as us-east-1 or eu-central-2' },
  r2: { label: 'Cloudflare R2', endpoint: 'https://ACCOUNT_ID.r2.cloudflarestorage.com', region: 'auto', pathStyle: true, regionHint: 'R2 uses auto' },
  other: { label: 'MinIO or another S3-compatible service', endpoint: '', region: 'us-east-1', pathStyle: true, regionHint: 'us-east-1 unless the service says otherwise' },
});
export const BACKUP_STORAGE_PROVIDER_KEYS = Object.freeze(Object.keys(BACKUP_STORAGE_PROVIDERS));

// The endpoint of a provider for a region ('' when it has to be typed in).
export function storageEndpointFor(provider, region) {
  const template = BACKUP_STORAGE_PROVIDERS[provider]?.endpoint ?? '';
  return template.includes('{region}') ? template.replace('{region}', region || 'us-east-1') : template;
}

// Checked again by the agent (agent/src/security/automationRules.js).
export const STORAGE_REGION_PATTERN = /^[a-z0-9-]{1,40}$/;
export const STORAGE_BUCKET_PATTERN = /^[A-Za-z0-9][A-Za-z0-9.-]{1,61}[A-Za-z0-9]$/;
export const STORAGE_ACCESS_KEY_PATTERN = /^[A-Za-z0-9+/=._-]{3,128}$/;
export const STORAGE_SECRET_PATTERN = /^[\x21-\x7e]{1,256}$/;
export const STORAGE_KEY_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,15}$/;
export const STORAGE_KEY_MAX_LENGTH = 512;
// The folder in the bucket backups go into (empty for the top).
export const STORAGE_PREFIX_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,7}$/;
export const STORAGE_TEST_STATUSES = Object.freeze(['passed', 'failed']);
export const BACKUP_STORAGE_TYPES = Object.freeze(['s3', 'sftp']);

// Another server over SFTP (checked again by the agent).
export const SFTP_HOST_PATTERN = /^(?:(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?|[0-9A-Fa-f:]{2,39})$/;
export const SFTP_USER_PATTERN = /^[A-Za-z_][A-Za-z0-9_.-]{0,31}$/;
export const SFTP_PATH_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))\/?[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,15}$/;
export const SFTP_PRIVATE_KEY_PATTERN = /^-----BEGIN OPENSSH PRIVATE KEY-----\n[A-Za-z0-9+/=\n]{20,4000}-----END OPENSSH PRIVATE KEY-----\n?$/;
export const SFTP_KNOWN_HOSTS_PATTERN = /^(?:(?:\[[A-Za-z0-9.:-]+\]:\d{1,5}|[A-Za-z0-9.:-]+) (?:ssh-ed25519|ecdsa-sha2-nistp(?:256|384|521)|ssh-rsa) [A-Za-z0-9+/]+={0,2}(?:\n|$)){1,3}$/;

export const MAX_BACKUP_KEEP = 100;
export const BACKUP_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const SHA256_PATTERN = /^[0-9a-f]{64}$/;
// A site, app or database name, as the agent receives it with its kind.
export const BACKUP_NAME_PATTERN = /^[a-z][a-z0-9_-]{1,63}$/;
// Panel copies made for downloading are kept this long.
export const BACKUP_DOWNLOAD_HOURS = 6;

// ---- Cron jobs ---------------------------------------------------------------

// A cron job runs as a website's or an app's own Linux user, never as root.
export const CRON_OWNER_TYPES = Object.freeze({
  website: { label: 'Website' },
  application: { label: 'App' },
});
export const CRON_OWNER_TYPE_KEYS = Object.freeze(Object.keys(CRON_OWNER_TYPES));
// creating | active | updating | deleting | failed, as for databases.
export const CRON_JOB_STATUSES = Object.freeze(['creating', 'active', 'updating', 'deleting', 'failed']);
export const CRON_JOB_BUSY_STATUSES = Object.freeze(['creating', 'updating', 'deleting']);
export const CRON_RUN_STATUSES = Object.freeze({
  succeeded: 'Succeeded',
  failed: 'Failed',
  timed_out: 'Timed out',
  skipped: 'Skipped (still running)',
});
export const CRON_RUN_TRIGGERS = Object.freeze(['schedule', 'manual']);
export const CRON_TIMEOUT_MIN = 10;
export const CRON_TIMEOUT_MAX = 24 * 3600;
export const CRON_NAME_PATTERN = /^[^\p{Cc}]{1,100}$/u;
// The folder a job starts in, inside the site or app (empty for its home).
export const CRON_WORKING_DIR_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,4}$/;
export const CRON_WORKING_DIR_MESSAGE = 'A folder inside the site or app, such as current or public';
// How much of a run's output is kept.
export const CRON_OUTPUT_MAX_BYTES = 16 * 1024;
export const CRON_RUNS_KEPT = 50;

// ---- Logs --------------------------------------------------------------------

// Server-wide logs read from the systemd journal. Website, app and service
// logs have their own operations.
export const LOG_SOURCES = Object.freeze({
  journal: { label: 'System journal', description: 'Everything the server logs' },
  kernel: { label: 'Kernel', description: 'Kernel messages (dmesg)' },
  auth: { label: 'Sign-ins and sudo', description: 'SSH logins, sudo and other authentication' },
  cron: { label: 'Cron', description: 'What the cron daemon started' },
});
export const LOG_SOURCE_KEYS = Object.freeze(Object.keys(LOG_SOURCES));
// journalctl priorities, most to least severe. A filter shows that level and worse.
export const LOG_PRIORITIES = Object.freeze({
  emerg: 'Emergency',
  alert: 'Alert',
  crit: 'Critical',
  err: 'Error',
  warning: 'Warning',
  notice: 'Notice',
  info: 'Info',
  debug: 'Debug',
});
export const LOG_PRIORITY_KEYS = Object.freeze(Object.keys(LOG_PRIORITIES));
export const LOG_SEARCH_PATTERN = /^[^\p{Cc}]{1,200}$/u;

// ---- Webhooks ----------------------------------------------------------------

export const WEBHOOK_EVENTS = Object.freeze({
  'backup.failed': 'A backup failed',
  'backup.succeeded': 'A backup finished',
  'restore.succeeded': 'A restore finished',
  'restore.failed': 'A restore failed',
  'cron.failed': 'A cron job failed or timed out',
  'deployment.succeeded': 'A deployment went live',
  'deployment.failed': 'A deployment failed',
  'alert.firing': 'An alert started firing',
  'alert.resolved': 'An alert resolved',
  'server.offline': 'A server went offline',
  'server.online': 'A server came back online',
  'ssl.expiring': 'An SSL certificate is close to expiring',
  'ssl.expired': 'An SSL certificate expired',
  'ssl.renew_failed': 'Automatic SSL renewal failed',
});
export const WEBHOOK_EVENT_KEYS = Object.freeze(Object.keys(WEBHOOK_EVENTS));
export const WEBHOOK_FORMATS = Object.freeze({
  json: { label: 'JSON (signed)', description: 'The event as JSON, signed with HMAC-SHA256 in X-VaultPanel-Signature' },
  slack: { label: 'Slack', description: 'A message for a Slack incoming webhook' },
  discord: { label: 'Discord', description: 'A message for a Discord channel webhook' },
});
export const WEBHOOK_FORMAT_KEYS = Object.freeze(Object.keys(WEBHOOK_FORMATS));
export const WEBHOOK_DELIVERY_STATUSES = Object.freeze(['pending', 'succeeded', 'failed']);
export const WEBHOOK_MAX_ATTEMPTS = 4;
