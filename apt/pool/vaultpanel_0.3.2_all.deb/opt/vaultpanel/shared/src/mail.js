// Email hosting on the panel's own servers: Postfix receives and sends,
// Dovecot keeps the mailboxes (IMAP and POP3), OpenDKIM signs outgoing mail.
// Shared by the panel (validation, DNS records), the UI (forms, labels) and,
// through its own copy (agent/src/security/mailRules.js), the agent.

// The part before the @: lower-case letters, digits, dots, dashes, plus and
// underscores; no dot at either end or two in a row.
export const MAIL_LOCAL_PART_PATTERN = /^(?=.{1,64}$)[a-z0-9_+-]+(?:\.[a-z0-9_+-]+)*$/;
export const MAIL_LOCAL_PART_MESSAGE = 'Use lower-case letters, digits, dots, dashes, plus and underscores, such as info or first.last';
const DOMAIN = '(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?';
// A full address, here or anywhere else (a forwarder's destination).
export const MAIL_ADDRESS_PATTERN = new RegExp(`^(?=.{6,254}$)[a-z0-9_+-]+(?:\\.[a-z0-9_+-]+)*@${DOMAIN}$`);
export const MAIL_ADDRESS_MESSAGE = 'Enter an email address such as name@example.com';
// SHA512-CRYPT, the form Dovecot checks passwords against. The panel hashes
// passwords; the agent only ever sees the hash.
export const MAIL_PASSWORD_HASH_PATTERN = /^\$6\$(?:rounds=\d{4,9}\$)?[./0-9A-Za-z]{1,16}\$[./0-9A-Za-z]{86}$/;
export const MAIL_DKIM_SELECTOR_PATTERN = /^[a-z0-9]{1,32}$/;
export const MAIL_DKIM_SELECTOR = 'vaultpanel';

export const MAIL_PASSWORD = Object.freeze({ min: 10, max: 128 });
// Mailbox size in MB; 0 means no limit.
export const MAIL_QUOTA_MB = Object.freeze({ min: 0, max: 1_048_576, default: 1024 });
export const MAX_MAIL_DOMAINS = 200;
export const MAX_MAILBOXES = 2000;
export const MAX_MAIL_FORWARDERS = 2000;
export const MAX_FORWARDER_DESTINATIONS = 20;

// active: on the server (changes apply on their own); deleting: being removed.
export const MAIL_DOMAIN_STATUSES = Object.freeze(['active', 'deleting']);
// A mail server's set-up state in the panel.
export const MAIL_SERVER_STATUSES = Object.freeze(['setting_up', 'active', 'failed']);

// What mail clients connect to (shown on the domain page).
export const MAIL_CLIENT_PORTS = Object.freeze({
  imap: { port: 993, security: 'SSL/TLS' },
  pop3: { port: 995, security: 'SSL/TLS' },
  smtp: { port: 587, security: 'STARTTLS' },
  smtps: { port: 465, security: 'SSL/TLS' },
});
// Ports the agent opens in the firewall: SMTP from other mail servers, then
// the ports for mail clients.
export const MAIL_FIREWALL_PORTS = Object.freeze([25, 465, 587, 993, 995]);

export function mailAddress(localPart, domain) {
  return `${localPart}@${domain}`;
}

export function splitMailAddress(address) {
  const at = String(address).lastIndexOf('@');
  return at < 0 ? { localPart: String(address), domain: '' } : { localPart: address.slice(0, at), domain: address.slice(at + 1) };
}

// The DKIM record's text, from the public key the agent reported (base64 of
// the key in SubjectPublicKeyInfo form).
export function dkimRecordValue(publicKey) {
  return `v=DKIM1; k=rsa; p=${publicKey}`;
}

// The records a mail domain needs in its DNS zone, relative to the domain:
// mail for it goes to the server's mail host name, which may send for it
// (SPF), signs for it (DKIM), and receivers are told what to do with mail
// that fails both (DMARC, report only to start with).
export function mailDnsRecords({ domain, hostname, dkimSelector = MAIL_DKIM_SELECTOR, dkimPublicKey = null }) {
  const records = [
    { name: '@', type: 'MX', value: hostname, priority: 10, purpose: 'mx' },
    { name: '@', type: 'TXT', value: hostname === domain || hostname.endsWith(`.${domain}`) ? 'v=spf1 mx ~all' : `v=spf1 mx a:${hostname} ~all`, purpose: 'spf' },
  ];
  if (dkimPublicKey) records.push({ name: `${dkimSelector}._domainkey`, type: 'TXT', value: dkimRecordValue(dkimPublicKey), purpose: 'dkim' });
  records.push({ name: '_dmarc', type: 'TXT', value: 'v=DMARC1; p=none', purpose: 'dmarc' });
  return records;
}

// Which kind of TXT record a value is, so a new SPF, DKIM or DMARC record
// replaces the old one instead of being added next to it.
export function mailTxtKind(value) {
  const v = String(value ?? '').trim().toLowerCase();
  if (v.startsWith('v=spf1')) return 'spf';
  if (v.startsWith('v=dkim1')) return 'dkim';
  if (v.startsWith('v=dmarc1')) return 'dmarc';
  return null;
}
