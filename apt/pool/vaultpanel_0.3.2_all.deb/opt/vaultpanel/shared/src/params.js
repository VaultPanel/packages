// A small, dependency-free validator for operation parameters. Each field spec
// is { type: 'string' | 'integer' | 'boolean' | 'array' | 'object', required, pattern, enum, min, max, maxLength, check }.
// Arrays take { items: <field spec>, minItems, maxItems, unique }; objects
// take { fields: <spec> }, checked the same way (unknown keys rejected).
// It is intentionally strict: unknown fields are rejected.

export function validateParams(spec, input) {
  const errors = [];
  const value = {};
  const params = input ?? {};

  if (typeof params !== 'object' || Array.isArray(params)) {
    return { ok: false, errors: [{ field: '', message: 'Parameters must be an object' }] };
  }

  for (const key of Object.keys(params)) {
    if (!Object.hasOwn(spec, key)) errors.push({ field: key, message: 'Unknown parameter' });
  }

  for (const [field, rule] of Object.entries(spec)) {
    const raw = params[field];
    if (raw === undefined || raw === null || raw === '') {
      if (rule.required) errors.push({ field, message: 'Required' });
      else if (rule.default !== undefined) value[field] = rule.default;
      continue;
    }
    const message = checkField(rule, raw);
    if (message) errors.push({ field, message });
    else value[field] = raw;
  }

  return errors.length ? { ok: false, errors } : { ok: true, value };
}

function checkField(rule, raw) {
  switch (rule.type) {
    case 'string':
      if (typeof raw !== 'string') return 'Must be a string';
      if (rule.maxLength && raw.length > rule.maxLength) return `Must be at most ${rule.maxLength} characters`;
      if (rule.pattern && !rule.pattern.test(raw)) return rule.patternMessage ?? 'Invalid format';
      if (rule.enum && !rule.enum.includes(raw)) return `Must be one of: ${rule.enum.join(', ')}`;
      // check: a function for rules a pattern cannot express (port lists, addresses).
      return rule.check ? rule.check(raw) : null;
    case 'integer':
      if (!Number.isInteger(raw)) return 'Must be an integer';
      if (rule.min !== undefined && raw < rule.min) return `Must be at least ${rule.min}`;
      if (rule.max !== undefined && raw > rule.max) return `Must be at most ${rule.max}`;
      return null;
    case 'boolean':
      return typeof raw === 'boolean' ? null : 'Must be true or false';
    case 'array': {
      if (!Array.isArray(raw)) return 'Must be a list';
      if (rule.minItems !== undefined && raw.length < rule.minItems) return `Must have at least ${rule.minItems} item${rule.minItems === 1 ? '' : 's'}`;
      if (rule.maxItems !== undefined && raw.length > rule.maxItems) return `Must have at most ${rule.maxItems} items`;
      if (rule.unique && new Set(raw).size !== raw.length) return 'Items must be unique';
      for (const item of raw) {
        const message = checkField(rule.items, item);
        // Objects name themselves in their own messages.
        if (message) return item && typeof item === 'object' ? message : `${String(item).slice(0, 60)}: ${message}`;
      }
      return null;
    }
    case 'object': {
      const nested = validateParams(rule.fields, raw);
      // check: rules across fields (which are required for which type).
      if (nested.ok) return rule.check ? rule.check(raw) : null;
      const [first] = nested.errors;
      return first.field ? `${first.field}: ${first.message}` : first.message;
    }
    default:
      return 'Unsupported parameter type';
  }
}
