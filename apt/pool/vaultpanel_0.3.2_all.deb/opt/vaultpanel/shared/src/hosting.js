// Hosting plans, customers, quotas and the billing API (phase 8). Shared by
// the panel (validation, quota checks) and the UI (forms, labels).

import { APP_CPU_LIMIT, APP_MEMORY_LIMIT_MB } from './security.js';

// What a plan can limit. Counts are per customer; a missing (null) limit
// means unlimited. column is the hosting_plans column that stores it.
export const PLAN_LIMITS = Object.freeze({
  websites: { label: 'Websites', column: 'max_websites', unit: '', max: 10_000, description: 'Websites, not counting the ones apps get for their domains' },
  subdomains: { label: 'Subdomains', column: 'max_subdomains', unit: '', max: 10_000, description: 'Subdomains of the account’s own domains, each served as its own site' },
  applications: { label: 'Apps', column: 'max_applications', unit: '', max: 10_000, description: 'Node.js and Python apps' },
  databases: { label: 'Databases', column: 'max_databases', unit: '', max: 10_000, description: 'MariaDB databases' },
  databaseUsers: { label: 'Database users', column: 'max_database_users', unit: '', max: 10_000, description: 'MariaDB users' },
  cronJobs: { label: 'Cron jobs', column: 'max_cron_jobs', unit: '', max: 10_000, description: 'Scheduled commands' },
  diskMb: { label: 'Disk space', column: 'disk_mb', unit: 'MB', max: 100_000_000, description: 'Website and app folders plus databases' },
});
export const PLAN_LIMIT_KEYS = Object.freeze(Object.keys(PLAN_LIMITS));
// The limits that count records (diskMb is measured instead).
export const PLAN_COUNT_KEYS = Object.freeze(PLAN_LIMIT_KEYS.filter((k) => k !== 'diskMb'));

// Caps on each app of the plan's customers, applied as the app's CPU and
// memory limits (systemd, from phase 6). null: no cap.
export const PLAN_APP_CAPS = Object.freeze({
  appMemoryMb: { label: 'Memory per app', column: 'app_memory_mb', unit: 'MB', field: 'memoryLimitMb', min: APP_MEMORY_LIMIT_MB.min, max: APP_MEMORY_LIMIT_MB.max },
  appCpuPercent: { label: 'CPU per app', column: 'app_cpu_percent', unit: '%', field: 'cpuLimitPercent', min: APP_CPU_LIMIT.min, max: APP_CPU_LIMIT.max },
});
export const PLAN_APP_CAP_KEYS = Object.freeze(Object.keys(PLAN_APP_CAPS));

// How often the billing system charges for a plan. VaultPanel only stores the
// price and cycle to show them and hand them to billing systems; it does not
// take payments.
export const BILLING_CYCLES = Object.freeze({
  monthly: { label: 'Monthly', short: '/mo', months: 1 },
  quarterly: { label: 'Every 3 months', short: '/3 mo', months: 3 },
  yearly: { label: 'Yearly', short: '/yr', months: 12 },
  free: { label: 'Free', short: '', months: null },
});
export const BILLING_CYCLE_KEYS = Object.freeze(Object.keys(BILLING_CYCLES));

// A plan's price spread over one month, in cents: 0 for free plans, null
// when no price is set. Used by the financial report.
export function monthlyPriceCents(plan) {
  if (plan.billingCycle === 'free') return 0;
  if (plan.priceCents === null || plan.priceCents === undefined) return null;
  return Math.round(plan.priceCents / (BILLING_CYCLES[plan.billingCycle]?.months ?? 1));
}

// How many months the financial report can cover.
export const REPORT_MONTHS = Object.freeze({ min: 1, max: 36, default: 12 });
export const CURRENCY_PATTERN = /^[A-Z]{3}$/;

export const PLAN_NAME_PATTERN = /^[\p{L}\p{N}][\p{L}\p{N} ._()&+-]{0,59}$/u;
export const PLAN_NAME_MESSAGE = 'Use letters, numbers, spaces and . _ - + ( ) &';

// active: can sign in and use the account.
// suspended: cannot sign in; websites are turned off and apps stopped.
// terminated: everything the account owned was deleted; kept for the record.
export const CUSTOMER_STATUSES = Object.freeze({
  active: { label: 'Active' },
  suspended: { label: 'Suspended' },
  terminated: { label: 'Removed' },
});
export const CUSTOMER_STATUS_KEYS = Object.freeze(Object.keys(CUSTOMER_STATUSES));

// The id a billing system gives the account (WHMCS service id, Blesta
// service id...), so it can find the account again.
export const EXTERNAL_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,99}$/;
export const EXTERNAL_ID_MESSAGE = 'Letters, digits and . _ : - (up to 100)';

// What a customer can own, and the table each lives in.
export const CUSTOMER_RESOURCE_TYPES = Object.freeze({
  website: { label: 'Website' },
  application: { label: 'App' },
  database: { label: 'Database' },
  database_user: { label: 'Database user' },
});
export const CUSTOMER_RESOURCE_TYPE_KEYS = Object.freeze(Object.keys(CUSTOMER_RESOURCE_TYPES));

// API keys for billing systems. Shown once when created; only a hash is kept.
export const API_KEY_PREFIX = 'vpk_';
export const API_KEY_PATTERN = /^vpk_[A-Za-z0-9_-]{40,80}$/;
export const API_KEY_SCOPES = Object.freeze({
  billing: { label: 'Billing', description: 'List plans, and create, suspend, unsuspend, change the plan of and remove customer accounts' },
});
export const API_KEY_SCOPE_KEYS = Object.freeze(Object.keys(API_KEY_SCOPES));
export const MAX_API_KEYS = 50;

// Usage as a share of a limit: null when unlimited.
export function usageRatio(used, limit) {
  if (limit === null || limit === undefined) return null;
  if (limit <= 0) return used > 0 ? 1 : 0;
  return used / limit;
}

// The limits a usage report goes over. usage: { websites: n, ..., diskMb: n }.
export function overLimits(usage, limits) {
  return PLAN_LIMIT_KEYS.filter((key) => limits[key] !== null && limits[key] !== undefined && (usage[key] ?? 0) > limits[key]);
}

// Each customer has their own app ports on their server: as many as their
// plan allows apps (with no app limit, one more than the apps they have).
// Their apps can only listen on these ports, and nobody else's app can take
// them. Ports are picked from this range, skipping any already in use.
export const CUSTOMER_PORT_RANGE = Object.freeze({ min: 10000, max: 19999 });
