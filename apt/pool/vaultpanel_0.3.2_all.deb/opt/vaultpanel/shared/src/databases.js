// Databases and database users. MySQL / MariaDB today; the engine column
// leaves room for PostgreSQL and Redis later.

export const DATABASE_ENGINES = Object.freeze({
  mariadb: { label: 'MySQL / MariaDB', description: 'Databases and users, created by the agent', available: true },
  postgresql: { label: 'PostgreSQL', description: 'Planned for a later phase', available: false },
  redis: { label: 'Redis', description: 'Planned for a later phase', available: false },
});

export const DATABASE_NAME_PATTERN = /^[a-z][a-z0-9_]{1,63}$/;
export const DATABASE_NAME_MESSAGE = 'Use 2 to 64 lowercase letters, digits and underscores, starting with a letter';
export const DATABASE_USER_PATTERN = /^[a-z][a-z0-9_]{1,31}$/;
export const DATABASE_USER_MESSAGE = 'Use 2 to 32 lowercase letters, digits and underscores, starting with a letter';
// Letters, digits and symbols that need no quoting anywhere (no quotes,
// backslashes, spaces or $).
export const DATABASE_PASSWORD_PATTERN = /^[A-Za-z0-9!#%+,.:=?@^_~-]{12,72}$/;
export const DATABASE_PASSWORD_MESSAGE = 'Use 12 to 72 letters, digits or the symbols ! # % + , . : = ? @ ^ _ ~ -';

export const RESERVED_DATABASE_NAMES = Object.freeze(['mysql', 'information_schema', 'performance_schema', 'sys', 'test', 'phpmyadmin']);
export const RESERVED_DATABASE_USERS = Object.freeze(['root', 'mysql', 'debian_sys_maint', 'admin', 'vaultpanel', 'mariadb', 'phpmyadmin']);

export const DATABASE_PRIVILEGES = Object.freeze({
  all: { label: 'Full access', description: 'Read, write and change the structure (tables, indexes)' },
  readonly: { label: 'Read only', description: 'SELECT only' },
});
export const DATABASE_PRIVILEGE_KEYS = Object.freeze(Object.keys(DATABASE_PRIVILEGES));

export const DATABASE_STATUSES = Object.freeze(['creating', 'active', 'updating', 'deleting', 'failed']);
export const DATABASE_BUSY_STATUSES = Object.freeze(['creating', 'updating', 'deleting']);
export const MAX_USER_DATABASES = 50;

export function isReservedDatabaseName(name) {
  return RESERVED_DATABASE_NAMES.includes(String(name));
}

export function isReservedDatabaseUser(name) {
  return RESERVED_DATABASE_USERS.includes(String(name));
}

// The database interface (agent 0.12.0): tables, rows and SQL in one
// database, run by the agent as an account that can reach only that database.
export const DATABASE_OBJECT_NAME_PATTERN = /^[^\p{Cc}]*[^\p{Cc}\s]$/u;
export const DATABASE_OBJECT_NAME_MESSAGE = 'Must be a table or column name';
export const MAX_QUERY_LENGTH = 100_000;
export const MAX_QUERY_ROWS = 1000;
export const DATABASE_PAGE_SIZES = Object.freeze([25, 50, 100, 250]);
