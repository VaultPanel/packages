import { PERMISSIONS } from './permissions.js';
import { API_TOKEN_SCOPES, permissionsForScopes } from './tokens.js';
import { WEBHOOK_EVENTS } from './automation.js';

// Plugins (phase 10, part 3) add features and connect outside services
// without changing the panel's code. A plugin is a separate program, run
// wherever its author likes. It describes itself in a manifest; an owner or
// admin installs it and approves the permissions the manifest asks for. From
// then on the plugin:
//   - calls the public REST API with its own token (vpp_...), limited to the
//     approved permissions, like an API token;
//   - receives the panel events it subscribed to, signed like webhooks;
//   - can show its own page inside the panel.
// A plugin never runs inside the panel, never adds agent operations and
// never runs commands on a server: everything it does goes through the API,
// its permission checks and the audit log.
export const PLUGIN_TOKEN_PREFIX = 'vpp_';
export const PLUGIN_TOKEN_PATTERN = /^vpp_[A-Za-z0-9_-]{40,80}$/;
export const PLUGIN_MANIFEST_VERSION = 1;
export const PLUGIN_SLUG_PATTERN = /^[a-z][a-z0-9-]{1,62}[a-z0-9]$/;
export const MAX_PLUGINS = 50;
// A signed link to a plugin's page is good for this long.
export const PLUGIN_LAUNCH_MAX_AGE_SECONDS = 300;

// The token scopes a plugin may ask for. "Everything" is left out: a plugin
// can never manage users, roles, panel settings or other plugins.
export const PLUGIN_SCOPE_KEYS = Object.freeze(Object.keys(API_TOKEN_SCOPES).filter((key) => key !== 'full'));

// Events a plugin may receive, and the permission its approved scopes must
// include for each, so an event never tells a plugin about something it could
// not read through the API.
export const PLUGIN_EVENT_PERMISSIONS = Object.freeze({
  'backup.failed': PERMISSIONS.BACKUPS_READ,
  'backup.succeeded': PERMISSIONS.BACKUPS_READ,
  'restore.succeeded': PERMISSIONS.BACKUPS_READ,
  'restore.failed': PERMISSIONS.BACKUPS_READ,
  'cron.failed': PERMISSIONS.CRON_READ,
  'deployment.succeeded': PERMISSIONS.APPS_READ,
  'deployment.failed': PERMISSIONS.APPS_READ,
  'alert.firing': PERMISSIONS.ALERTS_READ,
  'alert.resolved': PERMISSIONS.ALERTS_READ,
  'server.offline': PERMISSIONS.SERVERS_READ,
  'server.online': PERMISSIONS.SERVERS_READ,
  'ssl.expiring': PERMISSIONS.WEBSITES_READ,
  'ssl.expired': PERMISSIONS.WEBSITES_READ,
  'ssl.renew_failed': PERMISSIONS.WEBSITES_READ,
});
export const PLUGIN_EVENT_KEYS = Object.freeze(Object.keys(WEBHOOK_EVENTS).filter((key) => PLUGIN_EVENT_PERMISSIONS[key]));

// Icons a plugin's page may use in the sidebar.
export const PLUGIN_PAGE_ICONS = Object.freeze(['plug', 'activity', 'gauge', 'bell', 'server', 'globe', 'app', 'database', 'shield', 'card', 'briefcase', 'users', 'logs', 'zap', 'sparkles', 'package', 'layers', 'containers', 'automation']);

// What a plugin may do once approved: everything its scopes cover. Admins and
// owners, the only ones who may install plugins, hold every permission, and
// the service also caps it to the approver's own permissions.
export function pluginPermissions(scopes, approverPermissions) {
  const owned = new Set(approverPermissions ?? []);
  return permissionsForScopes(scopes).filter((permission) => owned.has(permission));
}

// Events the manifest asks for that its permissions do not cover.
export function eventsNotCovered(events, permissions) {
  const granted = new Set(permissions ?? []);
  return (events ?? []).filter((event) => !granted.has(PLUGIN_EVENT_PERMISSIONS[event]));
}

// The string a page launch is signed over: every vp_ parameter but the
// signature, sorted by name, as key=value pairs joined by "&".
export function pluginLaunchSigningString(params) {
  return Object.keys(params)
    .filter((key) => key.startsWith('vp_') && key !== 'vp_sig')
    .sort()
    .map((key) => `${key}=${params[key]}`)
    .join('&');
}

// Plugin directories: lists of plugins, published as JSON at a URL by
// whoever maintains them (a plugin author, a hosting company, a team). An
// owner or admin adds a directory's URL; the panel reads it and lists its
// plugins to install. Installing from a directory is the same as installing
// by manifest URL: the plugin's own manifest is read and approved as usual,
// so a directory can suggest a plugin but never grant it anything.
// See docs/plugins.md#plugin-directories.
export const PLUGIN_DIRECTORY_VERSION = 1;
export const MAX_PLUGIN_DIRECTORIES = 10;
export const MAX_PLUGIN_DIRECTORY_ENTRIES = 500;
// Directories are read again in the background after this long.
export const PLUGIN_DIRECTORY_REFRESH_HOURS = 12;
// "hosted": its author runs it and the entry has its manifest URL.
// "self-hosted": you run it yourself (see its setupUrl), then install it with
// the manifest URL of your copy.
export const PLUGIN_HOSTING = Object.freeze(['hosted', 'self-hosted']);

// Compares versions such as "1.2.10" and "1.10.0" part by part, numbers as
// numbers (a leading "v" and anything after "-" or "+" are ignored for the
// order). Returns -1, 0 or 1. Versions that are not dotted numbers compare
// as text, so a change still shows as "different".
export function compareVersions(a, b) {
  const parts = (v) => String(v ?? '').trim().replace(/^v/i, '').split(/[-+]/)[0].split('.');
  const pa = parts(a);
  const pb = parts(b);
  const numeric = [...pa, ...pb].every((p) => /^\d+$/.test(p));
  if (!numeric) return String(a) === String(b) ? 0 : String(a) < String(b) ? -1 : 1;
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const x = Number(pa[i] ?? 0);
    const y = Number(pb[i] ?? 0);
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}
