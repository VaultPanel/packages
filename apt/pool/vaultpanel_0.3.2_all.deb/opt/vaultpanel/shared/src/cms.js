// One-click app installer: WordPress, Joomla, Drupal and Laravel on a PHP
// website. The panel creates the database and its user (counted against a
// hosting customer's plan like any other), then the agent downloads the
// app from its own project, checks it, puts it in the site and runs its
// installer.
//
// "docroot" apps go inside the site's document root (or a folder of it).
// "project" apps get a folder of their own at the top of the site, and the
// site's document root becomes that project's public folder, so their code
// and settings (.env, vendor/) are never served.

export const CMS_APPS = Object.freeze({
  wordpress: {
    label: 'WordPress',
    description: 'Blogs and websites. The most used CMS.',
    kind: 'docroot',
    minPhp: '7.4',
    admin: true,
    adminPath: 'wp-admin/',
    source: 'wordpress.org, checked against its published SHA-1',
  },
  joomla: {
    label: 'Joomla',
    description: 'Websites and portals with users, menus and extensions.',
    kind: 'docroot',
    minPhp: '8.1',
    admin: true,
    adminPath: 'administrator/',
    source: 'The Joomla project’s GitHub releases, checked against their SHA-256',
  },
  drupal: {
    label: 'Drupal',
    description: 'Structured content sites. Installed with Composer and Drush.',
    kind: 'project',
    minPhp: '8.1',
    admin: true,
    adminPath: 'user/login',
    publicDir: 'web',
    defaultFolder: 'drupal',
    source: 'drupal/recommended-project through Composer',
  },
  laravel: {
    label: 'Laravel',
    description: 'A PHP framework starter app, ready for your own code.',
    kind: 'project',
    minPhp: '8.2',
    admin: false,
    publicDir: 'public',
    defaultFolder: 'laravel',
    source: 'laravel/laravel through Composer',
  },
});
export const CMS_APP_KEYS = Object.freeze(Object.keys(CMS_APPS));

export const CMS_INSTALL_STATUSES = Object.freeze(['waiting', 'installing', 'installed', 'removing', 'failed']);
export const CMS_BUSY_STATUSES = Object.freeze(['waiting', 'installing', 'removing']);

// A folder the user picks: inside the document root for WordPress and
// Joomla ("blog" installs at /blog), or the project folder for Drupal and
// Laravel. Lowercase, up to three levels, no hidden folders.
export const CMS_PATH_PATTERN = /^[a-z0-9_-][a-z0-9._-]{0,63}(?:\/[a-z0-9_-][a-z0-9._-]{0,63}){0,2}$/;
export const CMS_PATH_MESSAGE = 'Use lowercase letters, digits, dots, dashes and underscores, up to three folders deep (for example blog)';
// Folders at the top of a site that are not the app's to take.
export const CMS_RESERVED_FOLDERS = Object.freeze(['tmp', 'logs', 'releases', 'shared', 'current']);

// Where the app's files go, relative to the site's home folder (document
// root plus folder, or the project folder). The agent's copy is in cmsRules.js.
export const CMS_DIRECTORY_PATTERN = /^[A-Za-z0-9_-][A-Za-z0-9._-]{0,63}(?:\/[A-Za-z0-9_-][A-Za-z0-9._-]{0,63}){0,7}$/;
export const CMS_ADMIN_USER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{2,59}$/;
export const CMS_ADMIN_USER_MESSAGE = 'Use 3 to 60 letters, digits, dots, dashes and underscores';
// Printable characters without spaces.
export const CMS_ADMIN_PASSWORD_PATTERN = /^[\x21-\x7E]{12,128}$/;
export const CMS_ADMIN_PASSWORD_MESSAGE = 'Use 12 to 128 characters without spaces';
export const CMS_TITLE_PATTERN = /^[^\p{Cc}]{1,100}$/u;
export const CMS_URL_PATTERN = /^https?:\/\/[a-z0-9.-]{4,253}(?:\/[a-z0-9._-]+){0,8}\/?$/;

// A version as the projects publish them (6.8.3, 5.3.3...), shown on the
// installed app.
export const CMS_VERSION_PATTERN = /^[0-9]{1,3}(?:\.[0-9]{1,4}){0,3}$/;

// PHP versions compare as numbers per part (8.10 > 8.9).
export function phpAtLeast(version, minimum) {
  const a = String(version).split('.').map(Number);
  const b = String(minimum).split('.').map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const x = a[i] ?? 0;
    const y = b[i] ?? 0;
    if (x !== y) return x > y;
  }
  return true;
}
