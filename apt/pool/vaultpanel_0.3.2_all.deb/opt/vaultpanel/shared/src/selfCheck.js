// The server self-check: what must hold on a server for the panel's features
// to work, from the report agents 0.39.0 and later send every few minutes
// (agent/src/operations/selfCheck.js) or on demand (SELF_CHECK). Shared by
// the panel (the "Server self-check failed" alert) and the UI (the card on
// the server's Overview).
//
// Returns [{ key, label, status, detail }]. status 'error': something the
// panel does fails now, or would at the next restart (the alert fires);
// 'warning': worth fixing, nothing fails yet; 'ok'; 'info': nothing to judge.
export const SELF_CHECK_MIN_AGENT_VERSION = '0.39.0';
export const SELF_CHECK_STATUSES = Object.freeze(['ok', 'warning', 'error', 'info']);

const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

export function selfChecks(report) {
  if (!report) return [];
  const checks = [];
  const { helper, agent, agentFiles, fileWorker, nginx, apache, certbot, clock, failedUnits } = report;

  if (helper && !helper.ok) {
    checks.push({
      key: 'helper',
      label: 'Root helper',
      status: 'error',
      detail: `The agent's root helper does not answer (${helper.error}), so no job, file request or terminal can run. On the server: sudo systemctl restart vaultpanel-agent-helper`,
    });
  }
  if (agent?.user) {
    // A reason comes with root, or with an agent that has no root helper.
    const limited = agent.user === 'root' || agent.reason;
    checks.push({
      key: 'agent_user',
      label: 'Agent privileges',
      status: limited ? 'warning' : 'ok',
      detail: limited ? `The agent runs as ${agent.user}${agent.reason ? `: ${agent.reason}` : ''}` : `The agent runs as ${agent.user}; a root helper runs only what the panel signed`,
    });
  }
  if (agentFiles) {
    const inside = agentFiles.example && (agentFiles.example === agentFiles.dir || agentFiles.example.startsWith(`${agentFiles.dir}/`));
    checks.push({
      key: 'agent_files',
      label: 'Agent files',
      status: agentFiles.unreadable ? 'error' : 'ok',
      detail: agentFiles.unreadable
        ? `${plural(agentFiles.unreadable, 'file or folder', 'files or folders')} only root can read, such as ${agentFiles.example}. The file manager and the agent's own user need to read the agent's code. On the server: ${
            inside ? `sudo chmod -R u=rwX,go=rX ${agentFiles.dir}` : `sudo chmod o+x ${agentFiles.example}`
          }`
        : `Everyone can read the agent's code in ${agentFiles.dir}`,
    });
  }
  if (fileWorker) {
    checks.push({
      key: 'file_worker',
      label: 'File manager',
      status: fileWorker.ok ? 'ok' : 'error',
      detail: fileWorker.ok ? 'Its worker starts as a site user and answers' : `Its worker does not start as a site user, so the file manager fails for every website: ${fileWorker.error}`,
    });
  }
  for (const [key, label, test, result] of [
    ['nginx', 'NGINX configuration', 'nginx -t', nginx],
    ['apache', 'Apache configuration', 'apache2ctl -t', apache],
  ]) {
    if (!result) continue;
    const server = key === 'nginx' ? 'NGINX' : 'Apache';
    checks.push({
      key,
      label,
      status: result.ok ? 'ok' : 'error',
      detail: result.ok
        ? `${test} passes`
        : `${test} fails: ${result.error}. Website changes cannot be applied, and ${server} would not start again after a restart, until this is fixed.`,
    });
  }
  if (certbot) checks.push(certbotCheck(certbot));
  if (clock) {
    checks.push({
      key: 'clock',
      label: 'Clock',
      status: clock.synchronized ? 'ok' : 'warning',
      detail: clock.synchronized
        ? 'Kept in time by a time server'
        : "Not synchronized with a time server. Certificates, cron jobs and the agent's signed requests need the right time. On the server: sudo timedatectl set-ntp true",
    });
  }
  if (failedUnits) {
    checks.push({
      key: 'failed_units',
      label: 'Failed services',
      status: failedUnits.length ? 'warning' : 'ok',
      detail: failedUnits.length ? `${plural(failedUnits.length, 'systemd unit')} failed: ${failedUnits.join(', ')}. On the server: systemctl --failed` : 'No systemd unit has failed',
    });
  }
  return checks;
}

function certbotCheck({ renewals, timer, state, lastRunFailed, reloadHook }) {
  const base = { key: 'certbot', label: 'Certificate renewal' };
  if (!renewals) return { ...base, status: 'info', detail: "No Let's Encrypt certificate on this server yet" };
  const problems = [];
  // The panel renews due certificates itself when Certbot does not
  // (sslRenewalService), so none of this is an error.
  if (!timer) problems.push('No Certbot renewal timer is installed; the panel renews certificates itself a day into their renewal window.');
  else if (state === 'masked') problems.push(`${timer} is masked; the panel renews certificates itself a day into their renewal window.`);
  else if (state !== 'active') problems.push(`${timer} is not running. Issuing or renewing a certificate from the panel turns it back on, or on the server: sudo systemctl enable --now ${timer}`);
  if (lastRunFailed && timer) problems.push(`Certbot's last renewal run failed. On the server: sudo journalctl -u ${timer.replace(/\.timer$/, '.service')}`);
  if (reloadHook === false) problems.push('NGINX does not load renewed certificates until it reloads: the vaultpanel-reload-nginx hook is missing. Renewing a certificate from the panel puts it back.');
  if (problems.length) return { ...base, status: 'warning', detail: problems.join(' ') };
  return { ...base, status: 'ok', detail: `${timer} renews ${plural(renewals, 'certificate')}` };
}
