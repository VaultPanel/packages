// Multi-server management (phase 7): server groups and bulk actions.

export const SERVER_GROUP_NAME_PATTERN = /^[\p{L}\p{N}][\p{L}\p{N} ._()&-]{0,59}$/u;
export const SERVER_GROUP_NAME_MESSAGE = 'Use letters, numbers, spaces and . _ - ( ) &';
export const SERVER_GROUP_COLORS = Object.freeze(['blue', 'green', 'amber', 'red', 'purple', 'teal', 'gray']);
export const MAX_GROUP_SERVERS = 500;
export const MAX_BULK_SERVERS = 200;

// The operations a bulk action can run, and how each one is checked after
// its job succeeds. "reboot": the server must come back with a newer boot
// time. "agentVersion": the server must report the new agent version.
// verifyMinutes is how long to wait for that before calling the server failed.
export const BULK_OPERATIONS = Object.freeze({
  SERVICE_RESTART: { label: 'Restart a service', description: 'Restart the same systemd service on every server.', needsService: true },
  SERVICE_START: { label: 'Start a service', description: 'Start a stopped systemd service on every server.', needsService: true },
  SERVICE_STATUS: { label: 'Check a service', description: 'Read the state of a systemd service on every server.', needsService: true },
  SECURITY_UPDATES_INSTALL: {
    label: 'Install security updates',
    description: 'Install waiting security updates with unattended-upgrades (Ubuntu and Debian).',
    defaultMode: 'rolling',
  },
  AGENT_UPDATE: {
    label: 'Update the agent',
    description: 'Install the agent version this panel serves. Servers already on it are skipped.',
    verify: 'agentVersion',
    verifyMinutes: 3,
  },
  SERVER_REBOOT: {
    label: 'Reboot',
    description: 'Restart the servers. One at a time is safer: each server must be back online before the next one reboots.',
    defaultMode: 'rolling',
    verify: 'reboot',
    verifyMinutes: 10,
  },
});
export const BULK_OPERATION_TYPES = Object.freeze(Object.keys(BULK_OPERATIONS));

export const BULK_MODES = Object.freeze({
  parallel: { label: 'All at once' },
  rolling: { label: 'One server at a time' },
});
export const BULK_MODE_KEYS = Object.freeze(Object.keys(BULK_MODES));

export const BULK_ACTION_STATUSES = Object.freeze(['running', 'succeeded', 'failed', 'cancelled']);
export const BULK_TARGET_STATUSES = Object.freeze(['waiting', 'running', 'verifying', 'succeeded', 'failed', 'skipped', 'cancelled']);
export const BULK_TARGET_FINAL_STATUSES = Object.freeze(['succeeded', 'failed', 'skipped', 'cancelled']);
