// Cron expressions: the five-field schedules used by cron jobs on servers and
// by the panel's own backup schedules. Shared by the panel (validation, next
// run times) and the UI (presets, descriptions, previews). The agent keeps
// its own, stricter check of what it writes into /etc/cron.d.
//
// Fields: minute hour day-of-month month day-of-week, with *, lists (1,15),
// ranges (1-5), steps (*/10, 0-30/5) and names (JAN, MON). As in Vixie cron,
// when both day fields are restricted a day matches either of them.

const MONTH_NAMES = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
const DAY_NAMES = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

const FIELDS = [
  { key: 'minute', label: 'minute', min: 0, max: 59 },
  { key: 'hour', label: 'hour', min: 0, max: 23 },
  { key: 'dayOfMonth', label: 'day of month', min: 1, max: 31 },
  { key: 'month', label: 'month', min: 1, max: 12, names: MONTH_NAMES, nameBase: 1 },
  // 7 is also Sunday.
  { key: 'dayOfWeek', label: 'day of week', min: 0, max: 7, names: DAY_NAMES, nameBase: 0 },
];

export const CRON_MACROS = Object.freeze({
  '@yearly': '0 0 1 1 *',
  '@annually': '0 0 1 1 *',
  '@monthly': '0 0 1 * *',
  '@weekly': '0 0 * * 0',
  '@daily': '0 0 * * *',
  '@midnight': '0 0 * * *',
  '@hourly': '0 * * * *',
});

export const CRON_PRESETS = Object.freeze([
  { label: 'Every 5 minutes', expression: '*/5 * * * *' },
  { label: 'Every 15 minutes', expression: '*/15 * * * *' },
  { label: 'Every hour', expression: '0 * * * *' },
  { label: 'Every day at 03:00', expression: '0 3 * * *' },
  { label: 'Every Sunday at 03:00', expression: '0 3 * * 0' },
  { label: 'On the 1st of every month at 03:00', expression: '0 3 1 * *' },
]);

// Characters a schedule may contain at all (checked before parsing).
export const CRON_EXPRESSION_PATTERN = /^(?:@[a-z]{5,8}|[0-9A-Za-z*,/-]+(?: [0-9A-Za-z*,/-]+){4})$/;
export const CRON_EXPRESSION_MESSAGE = 'Use five fields (minute hour day month weekday), such as 0 3 * * *';

function parseValue(text, field) {
  if (/^[0-9]{1,2}$/.test(text)) return Number(text);
  if (field.names) {
    const i = field.names.indexOf(text.toUpperCase());
    if (i >= 0) return i + field.nameBase;
  }
  return null;
}

function parseField(text, field) {
  const values = new Set();
  for (const part of text.split(',')) {
    const match = /^(\*|[0-9A-Za-z]+(?:-[0-9A-Za-z]+)?)(?:\/([0-9]{1,2}))?$/.exec(part);
    if (!match) return { error: `"${part}" is not a valid ${field.label}` };
    const [, range, stepText] = match;
    const step = stepText === undefined ? 1 : Number(stepText);
    if (step < 1) return { error: `The step in "${part}" must be at least 1` };
    let from;
    let to;
    if (range === '*') {
      from = field.min;
      to = field.max === 7 ? 6 : field.max;
    } else {
      const [a, b] = range.split('-');
      from = parseValue(a, field);
      to = b === undefined ? (stepText === undefined ? from : null) : parseValue(b, field);
      // "5/10" (a start without a range) is not portable between cron versions.
      if (to === null && b === undefined) return { error: `Write "${a}-${field.max}/${stepText}" instead of "${part}"` };
      if (from === null || to === null) return { error: `"${part}" is not a valid ${field.label}` };
      if (from < field.min || to > field.max || from > field.max || to < field.min) {
        return { error: `The ${field.label} must be from ${field.min} to ${field.max}` };
      }
      if (from > to) return { error: `"${part}" goes backwards` };
    }
    for (let v = from; v <= to; v += step) values.add(field.key === 'dayOfWeek' && v === 7 ? 0 : v);
  }
  return { values };
}

// Returns { ok: true, expression, fields } with the normalized five-field
// expression (macros expanded, names as numbers), or { ok: false, error }.
export function parseCron(input) {
  const text = String(input ?? '').trim().replace(/\s+/g, ' ');
  if (!text) return { ok: false, error: 'Enter a schedule' };
  const expanded = text.startsWith('@') ? CRON_MACROS[text.toLowerCase()] : text;
  if (!expanded) return { ok: false, error: `Unknown schedule "${text}". Use @hourly, @daily, @weekly, @monthly or five fields.` };
  if (!CRON_EXPRESSION_PATTERN.test(expanded)) return { ok: false, error: CRON_EXPRESSION_MESSAGE };
  const parts = expanded.split(' ');
  const fields = {};
  for (const [i, field] of FIELDS.entries()) {
    const parsed = parseField(parts[i], field);
    if (parsed.error) return { ok: false, error: parsed.error };
    fields[field.key] = parsed.values;
    // Names become numbers: not every cron accepts names in ranges or lists.
    if (field.names) parts[i] = parts[i].replace(/[A-Za-z]+/g, (word) => String(parseValue(word, field)));
  }
  fields.dayOfMonthAny = parts[2].startsWith('*');
  fields.dayOfWeekAny = parts[4].startsWith('*');
  return { ok: true, expression: parts.join(' '), fields };
}

export function isValidCron(input) {
  return parseCron(input).ok;
}

// ---- Time zones -------------------------------------------------------------

const formatters = new Map();
function formatterFor(timeZone) {
  let f = formatters.get(timeZone);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone,
      hourCycle: 'h23',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
    });
    formatters.set(timeZone, f);
  }
  return f;
}

export function isValidTimeZone(timeZone) {
  if (typeof timeZone !== 'string' || !timeZone || timeZone.length > 64) return false;
  try {
    formatterFor(timeZone);
    return true;
  } catch {
    return false;
  }
}

// The wall-clock time in a zone at an instant.
function wallTime(ms, timeZone) {
  const parts = {};
  for (const { type, value } of formatterFor(timeZone).formatToParts(new Date(ms))) parts[type] = Number(value);
  return { year: parts.year, month: parts.month, day: parts.day, hour: parts.hour % 24, minute: parts.minute };
}

// The instant a wall-clock time happens in a zone, or null when the clock
// skips it (the hour lost to daylight saving time).
function instantOf({ year, month, day, hour, minute }, timeZone) {
  const asUtc = Date.UTC(year, month - 1, day, hour, minute);
  let guess = asUtc;
  for (let i = 0; i < 3; i += 1) {
    const w = wallTime(guess, timeZone);
    const offset = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute) - guess;
    const next = asUtc - offset;
    if (next === guess) break;
    guess = next;
  }
  const check = wallTime(guess, timeZone);
  if (check.year !== year || check.month !== month || check.day !== day || check.hour !== hour || check.minute !== minute) return null;
  return guess;
}

function dayMatches(fields, year, month, day) {
  if (!fields.month.has(month)) return false;
  const dow = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  const domOk = fields.dayOfMonth.has(day);
  const dowOk = fields.dayOfWeek.has(dow);
  if (fields.dayOfMonthAny || fields.dayOfWeekAny) return domOk && dowOk;
  return domOk || dowOk;
}

// The next `count` times (as Dates) an expression fires after `from`, in a
// time zone. Searches up to five years ahead (February 29th schedules).
export function nextCronRuns(input, { from = new Date(), timeZone = 'UTC', count = 1 } = {}) {
  const parsed = typeof input === 'object' && input?.fields ? input : parseCron(input);
  if (!parsed.ok) throw new Error(parsed.error);
  const { fields } = parsed;
  const startMs = Math.floor(new Date(from).getTime() / 60_000) * 60_000 + 60_000;
  const start = wallTime(startMs, timeZone);
  const hours = [...fields.hour].sort((a, b) => a - b);
  const minutes = [...fields.minute].sort((a, b) => a - b);
  const runs = [];
  const startDay = Date.UTC(start.year, start.month - 1, start.day);
  for (let i = 0; i < 366 * 5 && runs.length < count; i += 1) {
    const date = new Date(startDay + i * 86_400_000);
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth() + 1;
    const day = date.getUTCDate();
    if (!dayMatches(fields, year, month, day)) continue;
    for (const hour of hours) {
      if (i === 0 && hour < start.hour) continue;
      for (const minute of minutes) {
        if (i === 0 && hour === start.hour && minute < start.minute) continue;
        // A time the clock skips (daylight saving) runs when the clock resumes, as cron does.
        const at = instantOf({ year, month, day, hour, minute }, timeZone) ?? (hour < 23 ? instantOf({ year, month, day, hour: hour + 1, minute: 0 }, timeZone) : null);
        if (at === null || at < startMs) continue;
        if (runs.length && at <= runs.at(-1).getTime()) continue;
        runs.push(new Date(at));
        if (runs.length >= count) return runs;
      }
    }
  }
  return runs;
}

export function nextCronRun(input, options = {}) {
  return nextCronRuns(input, { ...options, count: 1 })[0] ?? null;
}

// ---- Descriptions -----------------------------------------------------------

const pad = (n) => String(n).padStart(2, '0');
const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// A short English description of common schedules ("Every day at 03:00"),
// or null for anything more involved.
export function describeCron(input) {
  const parsed = parseCron(input);
  if (!parsed.ok) return null;
  const [min, hour, dom, mon, dow] = parsed.expression.split(' ');
  const everyDay = dom === '*' && mon === '*' && dow === '*';
  const step = (f) => /^\*\/([0-9]+)$/.exec(f)?.[1];
  const single = (f) => (/^[0-9]{1,2}$/.test(f) ? Number(f) : null);
  if (everyDay && min === '*' && hour === '*') return 'Every minute';
  if (everyDay && step(min) && hour === '*') return `Every ${step(min)} minutes`;
  if (everyDay && single(min) !== null && hour === '*') return single(min) === 0 ? 'Every hour' : `Every hour at :${pad(single(min))}`;
  if (everyDay && single(min) !== null && step(hour)) return `Every ${step(hour)} hours at :${pad(single(min))}`;
  const at = single(min) !== null && single(hour) !== null ? `${pad(single(hour))}:${pad(single(min))}` : null;
  if (!at) return null;
  if (everyDay) return `Every day at ${at}`;
  if (dom === '*' && mon === '*' && single(dow) !== null) return `Every ${WEEKDAYS[single(dow) % 7]} at ${at}`;
  if (dom === '*' && mon === '*' && dow === '1-5') return `Weekdays at ${at}`;
  if (single(dom) !== null && mon === '*' && dow === '*') return `On day ${single(dom)} of every month at ${at}`;
  return null;
}
