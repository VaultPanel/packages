// Permission keys are "<area>.<action>". Routes check permissions, never role
// names, so roles can change without touching route code.
export const PERMISSIONS = Object.freeze({
  DASHBOARD_VIEW: 'dashboard.view',
  USERS_READ: 'users.read',
  USERS_MANAGE: 'users.manage',
  ROLES_READ: 'roles.read',
  AUDIT_READ: 'audit.read',
  SERVERS_READ: 'servers.read',
  SERVERS_MANAGE: 'servers.manage',
  SERVERS_SERVICES: 'servers.services',
  SERVERS_PROCESSES: 'servers.processes',
  SERVERS_REBOOT: 'servers.reboot',
  SERVERS_SIGNAL: 'servers.signal',
  SERVERS_BULK: 'servers.bulk',
  SERVERS_TERMINAL: 'servers.terminal',
  ALERTS_READ: 'alerts.read',
  ALERTS_ACKNOWLEDGE: 'alerts.acknowledge',
  ALERTS_MANAGE: 'alerts.manage',
  WEBSITES_READ: 'websites.read',
  WEBSITES_MANAGE: 'websites.manage',
  WEBSITES_LOGS: 'websites.logs',
  FILES_READ: 'files.read',
  FILES_WRITE: 'files.write',
  APPS_READ: 'applications.read',
  APPS_MANAGE: 'applications.manage',
  APPS_DEPLOY: 'applications.deploy',
  APPS_LOGS: 'applications.logs',
  DATABASES_READ: 'databases.read',
  DATABASES_MANAGE: 'databases.manage',
  BACKUPS_READ: 'backups.read',
  BACKUPS_CREATE: 'backups.create',
  BACKUPS_MANAGE: 'backups.manage',
  CRON_READ: 'cron.read',
  CRON_RUN: 'cron.run',
  CRON_MANAGE: 'cron.manage',
  SERVERS_LOGS: 'servers.logs',
  WEBHOOKS_MANAGE: 'webhooks.manage',
  SECURITY_READ: 'security.read',
  SECURITY_MANAGE: 'security.manage',
  JOBS_READ: 'jobs.read',
  JOBS_CANCEL: 'jobs.cancel',
  SETTINGS_MANAGE: 'settings.manage',
  CUSTOMERS_READ: 'customers.read',
  CUSTOMERS_MANAGE: 'customers.manage',
  PLANS_MANAGE: 'plans.manage',
  BILLING_MANAGE: 'billing.manage',
  ASSISTANT_USE: 'assistant.use',
  CONTAINERS_READ: 'containers.read',
  CONTAINERS_OPERATE: 'containers.operate',
  CONTAINERS_LOGS: 'containers.logs',
  CONTAINERS_MANAGE: 'containers.manage',
  PLUGINS_MANAGE: 'plugins.manage',
  DNS_READ: 'dns.read',
  DNS_MANAGE: 'dns.manage',
  MAIL_READ: 'mail.read',
  MAIL_MANAGE: 'mail.manage',
});

export const PERMISSION_DESCRIPTIONS = Object.freeze({
  'dashboard.view': 'View the dashboard',
  'users.read': 'View users and their roles',
  'users.manage': 'Invite, update, deactivate users and issue password reset links',
  'roles.read': 'View roles and their permissions',
  'audit.read': 'View the audit log',
  'servers.read': 'View servers, their status and metrics',
  'servers.manage': 'Add, rename and remove servers, manage server groups, update agents and issue enrollment tokens',
  'servers.services': 'Check, start, stop and restart services and read their logs',
  'servers.processes': 'List running processes on a server',
  'servers.reboot': 'Reboot a server',
  'servers.signal': 'Stop or kill processes on a server',
  'servers.bulk': 'Run an operation on several servers at once (each server still needs the permission for the operation itself)',
  'servers.terminal': 'Open a root terminal on a server from the browser (owners only; every session is in the audit log)',
  'alerts.read': 'View alerts and alert rules',
  'alerts.acknowledge': 'Acknowledge firing alerts',
  'alerts.manage': 'Create, change and delete alert rules',
  'websites.read': 'View websites, domains and SSL certificates',
  'websites.manage': 'Create, change and delete websites, their domains and SSL certificates, and install the web stack',
  'websites.logs': 'Read website access and error logs',
  'files.read': 'Browse and download website files',
  'files.write': 'Upload, edit, rename and delete website files',
  'applications.read': 'View applications, their deployments and process state',
  'applications.manage': 'Create, change and delete applications, and view and change their environment variables',
  'applications.deploy': 'Deploy, roll back, start, stop and restart applications',
  'applications.logs': 'Read application output and error logs',
  'databases.read': 'View databases and database users',
  'databases.manage': 'Create and delete databases and database users, change access and view passwords',
  'backups.read': 'View backups, backup schedules and restores',
  'backups.create': 'Back up websites, apps and databases now',
  'backups.manage': 'Restore, download and delete backups, and manage backup schedules',
  'cron.read': 'View cron jobs and their run history',
  'cron.run': 'Run a cron job now',
  'cron.manage': 'Create, change and delete cron jobs',
  'servers.logs': 'Read system, kernel, sign-in and cron logs on servers',
  'webhooks.manage': 'Create, change and delete webhooks and see their deliveries',
  'security.read': 'View firewall rules, SSH settings, Fail2ban and update status of servers',
  'security.manage': 'Change firewall rules, SSH settings, SSH keys, Fail2ban and automatic updates, and install security updates',
  'jobs.read': 'View jobs and their logs',
  'jobs.cancel': 'Cancel queued jobs',
  'settings.manage': 'Change panel settings',
  'customers.read': 'View customers, their hosting plans and what they use',
  'customers.manage': 'Create customers, change their plan, suspend, unsuspend and remove them, and move websites, apps and databases to them',
  'plans.manage': 'Create, change and delete hosting plans',
  'billing.manage': 'Create and revoke the API keys billing systems use',
  'assistant.use': 'Ask the AI assistant, which reads what you are allowed to see and proposes changes for you to approve',
  'containers.read': 'View Docker, containers and images on servers',
  'containers.operate': 'Start, stop and restart containers',
  'containers.logs': 'Read the output of containers',
  'containers.manage': 'Install Docker, deploy, change and remove containers, pull and remove images, and view container environment variables',
  'plugins.manage': 'Install, approve, turn off and remove plugins, and see the events sent to them',
  'dns.read': 'View DNS zones and their records',
  'dns.manage': 'Set up DNS servers, and create, change and delete DNS zones and records',
  'mail.read': 'View email domains, mailboxes and forwarders',
  'mail.manage': 'Set up mail servers, and create, change and delete email domains, mailboxes and forwarders',
});

export const ALL_PERMISSIONS = Object.freeze(Object.values(PERMISSIONS));

// A terminal is a root shell, beyond anything the allow-listed operations can
// do, so only owners get it: not admins, and never through an API token
// scope, a plugin or the AI assistant.
export const OWNER_ONLY_PERMISSIONS = Object.freeze(['servers.terminal']);

// Customers (phase 8) sign in to manage their own hosting account. Their role
// gives the permissions below, but only ever over websites, apps, databases,
// backups and cron jobs their account owns: the panel scopes every query and
// refuses anything on the server itself. The role is given only by creating
// a customer, never from the Users page.
export const CUSTOMER_ROLE = 'customer';
export const CUSTOMER_PERMISSIONS = Object.freeze([
  'websites.read',
  'websites.manage',
  'websites.logs',
  'files.read',
  'files.write',
  'applications.read',
  'applications.manage',
  'applications.deploy',
  'applications.logs',
  'databases.read',
  'databases.manage',
  'backups.read',
  'backups.create',
  'backups.manage',
  'cron.read',
  'cron.run',
  'cron.manage',
  'jobs.read',
]);

// Built-in roles. "rank" orders roles so that an actor can only grant roles at
// or below their own (owners alone manage owners).
export const ROLES = Object.freeze({
  owner: {
    rank: 40,
    description: 'Full control of the panel, including other owners and the server terminal',
    permissions: ALL_PERMISSIONS,
  },
  admin: {
    rank: 30,
    description: 'Manage servers, users (except owners) and settings',
    permissions: ALL_PERMISSIONS.filter((key) => !OWNER_ONLY_PERMISSIONS.includes(key)),
  },
  developer: {
    rank: 20,
    description: 'View servers, websites, DNS zones, email, apps, containers and databases, deploy and restart apps, start, stop and restart containers, back up, run cron jobs, run routine operations such as service restarts, work on website files, and ask the AI assistant',
    permissions: [
      'dashboard.view',
      'servers.read',
      'servers.services',
      'servers.processes',
      'websites.read',
      'websites.logs',
      'files.read',
      'files.write',
      'applications.read',
      'applications.deploy',
      'applications.logs',
      'databases.read',
      'backups.read',
      'backups.create',
      'cron.read',
      'cron.run',
      'jobs.read',
      'alerts.read',
      'alerts.acknowledge',
      'assistant.use',
      'containers.read',
      'containers.operate',
      'containers.logs',
      'dns.read',
      'mail.read',
    ],
  },
  viewer: {
    rank: 10,
    description: 'Read-only access to servers, websites, DNS zones, email, apps, containers, databases, backups, cron jobs and jobs, and the AI assistant',
    permissions: ['dashboard.view', 'servers.read', 'websites.read', 'applications.read', 'databases.read', 'backups.read', 'cron.read', 'jobs.read', 'alerts.read', 'assistant.use', 'containers.read', 'dns.read', 'mail.read'],
  },
  customer: {
    rank: 5,
    description: 'A hosting customer: manages only the websites, apps, databases, backups and cron jobs of their own account, within their plan',
    permissions: CUSTOMER_PERMISSIONS,
  },
});

export const ROLE_NAMES = Object.freeze(Object.keys(ROLES));
// Roles given from the Users page: everything but the customer role.
export const STAFF_ROLE_NAMES = Object.freeze(ROLE_NAMES.filter((name) => name !== CUSTOMER_ROLE));

export function roleRank(roleName) {
  return ROLES[roleName]?.rank ?? 0;
}

export function hasPermission(permissionList, permission) {
  return Array.isArray(permissionList) && permissionList.includes(permission);
}
