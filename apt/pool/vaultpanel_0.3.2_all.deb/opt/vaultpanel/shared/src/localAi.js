// The AI assistant's free model on the panel's own server (agent 0.41.0):
// Ollama, installed by the agent, on a loopback port only the panel and root
// may reach. Port 21434 is outside the ports hosting customers get
// (CUSTOMER_PORT_RANGE, 10000-19999), so no customer app is ever given it.
export const LOCAL_AI = Object.freeze({
  port: 21434,
  apiUrl: 'http://127.0.0.1:21434',
  // The context Ollama is set up with (its own default on a CPU is 4096,
  // too small for the assistant's tools and a few log reads).
  contextTokens: 8192,
});

const GiB = 1024 ** 3;

// The models the panel offers: small, free to use commercially (Apache 2.0),
// able to call tools, and light enough for a CPU. downloadBytes is what
// Ollama's registry lists; memoryBytes is about what the model needs loaded,
// with its context. `thinks`: the model reasons before answering unless told
// not to, which is too slow on a CPU, so the panel turns it off. The agent
// keeps its own list of the same models (agent/src/operations/localAi.js).
export const LOCAL_AI_MODELS = Object.freeze([
  {
    id: 'qwen3.5:2b-q4_K_M',
    label: 'Qwen3.5 2B',
    description: 'The smallest and fastest. Simple answers; for servers with 4 GB of memory.',
    downloadBytes: 1_945_781_358,
    memoryBytes: 2.5 * GiB,
    license: 'Apache 2.0',
    thinks: false,
    recommendable: true,
  },
  {
    id: 'granite4.1:3b',
    label: 'IBM Granite 4.1 3B',
    description: 'Good at using the panel’s tools for its size. Text only.',
    downloadBytes: 2_099_520_281,
    memoryBytes: 3.5 * GiB,
    license: 'Apache 2.0',
    thinks: false,
    recommendable: true,
  },
  {
    id: 'qwen3.5:4b',
    label: 'Qwen3.5 4B',
    description: 'Better answers, a little slower. For servers with 8 GB of memory.',
    downloadBytes: 3_324_173_934,
    memoryBytes: 4.5 * GiB,
    license: 'Apache 2.0',
    thinks: true,
    recommendable: true,
  },
  {
    id: 'qwen3.5:9b',
    label: 'Qwen3.5 9B',
    description: 'The best answers here, but slow without a strong CPU. For servers with 16 GB of memory.',
    downloadBytes: 6_550_825_550,
    memoryBytes: 8 * GiB,
    license: 'Apache 2.0',
    thinks: true,
    recommendable: false,
  },
]);
export const LOCAL_AI_MODEL_IDS = Object.freeze(LOCAL_AI_MODELS.map((m) => m.id));

// Memory left for the rest of the panel's server (the panel, its database,
// Redis, the agent, websites) when choosing a model for it.
export const LOCAL_AI_MEMORY_RESERVE_BYTES = 1.25 * GiB;

// The model to suggest for a server with this much memory: the largest of
// the recommendable ones that leaves the reserve free, or the smallest.
export function suggestedLocalModel(totalMemoryBytes) {
  const candidates = LOCAL_AI_MODELS.filter((m) => m.recommendable);
  if (!totalMemoryBytes) return candidates[0].id;
  const fitting = candidates.filter((m) => m.memoryBytes + LOCAL_AI_MEMORY_RESERVE_BYTES <= totalMemoryBytes);
  return (fitting.at(-1) ?? candidates[0]).id;
}
