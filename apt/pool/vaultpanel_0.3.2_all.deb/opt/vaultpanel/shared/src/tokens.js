import { OWNER_ONLY_PERMISSIONS, PERMISSIONS } from './permissions.js';

// API tokens (phase 10) let scripts, the command-line tool and the SDK call
// the REST API without a browser session. A token belongs to the person who
// made it and always acts as them: what it may do is the overlap of their
// permissions and the scopes it was given, so a token can never do more than
// its owner. The token itself is shown once; only its SHA-256 is kept.
//
// Billing systems use a different credential (vpk_ keys, phase 8): those
// belong to the panel rather than to a person and only manage customers.
export const API_TOKEN_PREFIX = 'vpt_';
export const API_TOKEN_PATTERN = /^vpt_[A-Za-z0-9_-]{40,80}$/;
export const MAX_API_TOKENS_PER_USER = 25;
export const MAX_API_TOKEN_DAYS = 3650;

const P = PERMISSIONS;

// Scopes are groups of permissions, so a token can be given what a script
// needs and nothing more.
export const API_TOKEN_SCOPES = Object.freeze({
  read: {
    label: 'Read',
    description: 'View servers, websites, DNS zones, email, apps, databases, containers, backups, cron jobs, alerts and jobs',
    permissions: [
      P.DASHBOARD_VIEW,
      P.SERVERS_READ,
      P.WEBSITES_READ,
      P.DNS_READ,
      P.MAIL_READ,
      P.APPS_READ,
      P.DATABASES_READ,
      P.CONTAINERS_READ,
      P.BACKUPS_READ,
      P.CRON_READ,
      P.ALERTS_READ,
      P.JOBS_READ,
      P.SECURITY_READ,
      P.USERS_READ,
      P.ROLES_READ,
      P.CUSTOMERS_READ,
    ],
  },
  logs: {
    label: 'Logs',
    description: 'Read website, app, container and server logs',
    permissions: [P.WEBSITES_LOGS, P.APPS_LOGS, P.CONTAINERS_LOGS, P.SERVERS_LOGS, P.AUDIT_READ],
  },
  deploy: {
    label: 'Deploy',
    description: 'Deploy, roll back, start, stop and restart apps and containers, and run cron jobs now',
    permissions: [P.APPS_DEPLOY, P.CONTAINERS_OPERATE, P.CRON_RUN, P.JOBS_READ, P.APPS_READ, P.CONTAINERS_READ],
  },
  manage: {
    label: 'Manage hosting',
    description: 'Create, change and delete websites, DNS zones, email, apps, databases, containers, backups and cron jobs',
    permissions: [
      P.WEBSITES_MANAGE,
      P.DNS_MANAGE,
      P.MAIL_MANAGE,
      P.FILES_READ,
      P.FILES_WRITE,
      P.APPS_MANAGE,
      P.DATABASES_MANAGE,
      P.CONTAINERS_MANAGE,
      P.BACKUPS_CREATE,
      P.BACKUPS_MANAGE,
      P.CRON_MANAGE,
      P.WEBHOOKS_MANAGE,
      P.ALERTS_MANAGE,
      P.ALERTS_ACKNOWLEDGE,
      P.JOBS_CANCEL,
    ],
  },
  servers: {
    label: 'Servers',
    description: 'Run server operations: services, processes, security settings and reboots',
    permissions: [P.SERVERS_MANAGE, P.SERVERS_SERVICES, P.SERVERS_PROCESSES, P.SERVERS_SIGNAL, P.SERVERS_REBOOT, P.SERVERS_BULK, P.SECURITY_MANAGE],
  },
  customers: {
    label: 'Customers',
    description: 'Create, change, suspend and remove hosting customers and plans',
    permissions: [P.CUSTOMERS_MANAGE, P.PLANS_MANAGE],
  },
  full: {
    label: 'Everything',
    description: 'Everything the person who owns the token may do, including panel settings and users (but not the server terminal, which opens only in the browser)',
    permissions: Object.freeze(Object.values(PERMISSIONS).filter((key) => !OWNER_ONLY_PERMISSIONS.includes(key))),
  },
});

export const API_TOKEN_SCOPE_KEYS = Object.freeze(Object.keys(API_TOKEN_SCOPES));

// The permissions a set of scopes asks for, before the owner's own
// permissions are applied.
export function permissionsForScopes(scopes) {
  const asked = new Set();
  for (const scope of scopes ?? []) {
    for (const permission of API_TOKEN_SCOPES[scope]?.permissions ?? []) asked.add(permission);
  }
  return [...asked];
}

// What a token may actually do: the overlap of its scopes and its owner's
// permissions, so narrowing a role narrows their tokens too.
export function tokenPermissions(scopes, ownerPermissions) {
  const owned = new Set(ownerPermissions ?? []);
  return permissionsForScopes(scopes).filter((permission) => owned.has(permission));
}
