// Docker containers (phase 10). Shared by the panel, the agent's catalog
// checks and the UI.
//
// A container VaultPanel deploys is described only by the fields below. The
// agent builds the Docker configuration from them itself, so there is no way
// to ask for a privileged container, the host's network, extra capabilities,
// devices, or a folder of the host mounted inside: data lives in Docker
// volumes the container owns.

// Names of containers VaultPanel deploys (also their name in Docker).
export const CONTAINER_NAME_PATTERN = /^[a-z][a-z0-9-]{1,30}[a-z0-9]$/;
export const CONTAINER_NAME_MESSAGE = 'Use 3 to 32 lowercase letters, digits and dashes, starting with a letter';

// Docker's own container IDs (full or the 12-character short form).
export const CONTAINER_ID_PATTERN = /^[a-f0-9]{12,64}$/;

// An image reference: [registry[:port]/]path[:tag][@sha256:digest].
const COMPONENT = '[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*';
export const IMAGE_REF_PATTERN = new RegExp(
  `^(?:[a-z0-9]+(?:[.-][a-z0-9]+)*(?::[0-9]{1,5})?/)?${COMPONENT}(?:/${COMPONENT})*(?::[A-Za-z0-9_][A-Za-z0-9_.-]{0,127})?(?:@sha256:[a-f0-9]{64})?$`,
);
export const IMAGE_REF_MESSAGE = 'Enter an image such as nginx:1.27, ghcr.io/owner/app:latest or redis';
export const MAX_IMAGE_REF_LENGTH = 255;

// Docker's image IDs ("sha256:" and 64 hex digits).
export const IMAGE_ID_PATTERN = /^sha256:[a-f0-9]{64}$/;

// Published ports, as "<address>:<host port>:<container port>/<protocol>".
// 127.0.0.1 keeps a port on the server itself (put a website in front of
// it); 0.0.0.0 opens it to everyone. Docker publishes ports past UFW, so a
// public port is reachable even when the firewall has no rule for it.
export const PORT_BIND_ADDRESSES = Object.freeze({
  '127.0.0.1': { label: 'This server only', description: 'Reachable from the server itself, for a website (reverse proxy) or another app' },
  '0.0.0.0': { label: 'Public', description: 'Reachable from the internet. Docker opens it even when the firewall has no rule for it' },
});
export const PORT_MAPPING_PATTERN = /^(127\.0\.0\.1|0\.0\.0\.0):(\d{1,5}):(\d{1,5})\/(tcp|udp)$/;
export const MAX_CONTAINER_PORTS = 10;

export function parsePortMapping(value) {
  const match = PORT_MAPPING_PATTERN.exec(String(value));
  if (!match) return null;
  const hostPort = Number(match[2]);
  const containerPort = Number(match[3]);
  if (hostPort < 1 || hostPort > 65535 || containerPort < 1 || containerPort > 65535) return null;
  return { address: match[1], hostPort, containerPort, protocol: match[4] };
}

export function formatPortMapping({ address = '127.0.0.1', hostPort, containerPort, protocol = 'tcp' }) {
  return `${address}:${hostPort}:${containerPort}/${protocol}`;
}

export function portMappingMessage(value) {
  return parsePortMapping(value) ? null : 'Must be address:hostPort:containerPort/protocol, such as 127.0.0.1:8080:80/tcp';
}

// Volumes, as "<volume>:<path in the container>" with ":ro" for read-only.
// The volume is the container's own: Docker names it vp-<container>-<volume>.
export const VOLUME_NAME_PATTERN = /^[a-z][a-z0-9-]{0,30}$/;
export const CONTAINER_PATH_PATTERN = /^\/[A-Za-z0-9._@+-]+(?:\/[A-Za-z0-9._@+-]+)*$/;
export const MAX_CONTAINER_VOLUMES = 10;

export function parseVolumeMapping(value) {
  const parts = String(value).split(':');
  if (parts.length < 2 || parts.length > 3) return null;
  const [volume, path, mode] = parts;
  if (!VOLUME_NAME_PATTERN.test(volume)) return null;
  if (path.length > 200 || !CONTAINER_PATH_PATTERN.test(path) || path.split('/').some((p) => p === '..' || p === '.')) return null;
  if (mode !== undefined && mode !== 'ro') return null;
  return { volume, path, readOnly: mode === 'ro' };
}

export function formatVolumeMapping({ volume, path, readOnly = false }) {
  return `${volume}:${path}${readOnly ? ':ro' : ''}`;
}

export function volumeMappingMessage(value) {
  return parseVolumeMapping(value) ? null : 'Must be volume:/path/in/container (add :ro for read-only), such as data:/var/lib/data';
}

// The Docker volume a container's volume is stored in.
export function dockerVolumeName(container, volume) {
  return `vp-${container}-${volume}`;
}

export const RESTART_POLICIES = Object.freeze({
  'unless-stopped': { label: 'Unless stopped', description: 'Starts again after a crash or a reboot, unless you stopped it' },
  always: { label: 'Always', description: 'Starts again after a crash or a reboot, even if you stopped it' },
  'on-failure': { label: 'On failure', description: 'Starts again only after it exits with an error' },
  no: { label: 'Never', description: 'Stays stopped when it exits' },
});
export const RESTART_POLICY_KEYS = Object.freeze(Object.keys(RESTART_POLICIES));

export const CONTAINER_CPU_PERCENT = Object.freeze({ min: 5, max: 6400 });
export const CONTAINER_MEMORY_MB = Object.freeze({ min: 32, max: 262_144 });
export const CONTAINER_HEALTH_SECONDS = Object.freeze({ min: 3, max: 300, default: 10 });

// The command the container runs, when it should not be the image's own:
// one line, split into arguments like a shell would (quotes group words; see
// splitCommand in applications.js) but never run through one.
export const CONTAINER_COMMAND_PATTERN = /^[^\0\r\n]*$/;
export const MAX_CONTAINER_COMMAND_LENGTH = 1000;
export const MAX_CONTAINER_COMMAND_ARGS = 100;

// The Docker network VaultPanel's containers share: they reach each other by
// name (a "db" container is the host "db").
export const CONTAINER_NETWORK = 'vaultpanel';

// Labels on the containers VaultPanel deploys.
export const CONTAINER_LABELS = Object.freeze({
  managed: 'io.vaultpanel.managed',
  id: 'io.vaultpanel.id',
  // Containers VaultPanel itself depends on (its own MariaDB and Redis): the
  // panel and the agent refuse to stop, restart or remove them.
  protected: 'io.vaultpanel.protected',
});

// Container records in the panel.
// deploying: being created or recreated; active: deployed (its live state
// comes from Docker); failed: the first deployment failed; removing.
export const CONTAINER_STATUSES = Object.freeze(['deploying', 'active', 'failed', 'removing']);
export const CONTAINER_BUSY_STATUSES = Object.freeze(['deploying', 'removing']);

// States Docker reports for a container.
export const CONTAINER_STATES = Object.freeze(['created', 'running', 'paused', 'restarting', 'removing', 'exited', 'dead']);

// Actions on any container on a server, including ones VaultPanel did not deploy.
export const CONTAINER_ACTIONS = Object.freeze({
  start: { operation: 'CONTAINER_START', label: 'Start' },
  stop: { operation: 'CONTAINER_STOP', label: 'Stop' },
  restart: { operation: 'CONTAINER_RESTART', label: 'Restart' },
});
export const CONTAINER_ACTION_KEYS = Object.freeze(Object.keys(CONTAINER_ACTIONS));
