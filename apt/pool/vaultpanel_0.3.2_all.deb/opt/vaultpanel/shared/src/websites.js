// Websites, domains, SSL and site files. Shared by the panel (validation),
// the agent (which re-checks everything) and the UI (forms, labels).

export const SITE_TYPES = Object.freeze({
  static: { label: 'Static site', description: 'HTML, CSS, JavaScript and other files served as they are' },
  php: { label: 'PHP site', description: 'PHP through its own PHP-FPM pool, running as the site user' },
  proxy: { label: 'Reverse proxy', description: 'Forwards requests to an app listening on a local port, such as a Node.js app' },
});
export const SITE_TYPE_KEYS = Object.freeze(Object.keys(SITE_TYPES));

// A site's name is also its Linux user and the name of its directory, PHP
// pool, NGINX file and certificate, so it follows Linux user name rules:
// 3 to 32 characters, lowercase letters, digits and dashes.
export const SITE_NAME_PATTERN = /^[a-z][a-z0-9-]{1,30}[a-z0-9]$/;
export const SITE_NAME_MESSAGE = 'Use 3 to 32 lowercase letters, digits and dashes, starting with a letter';

// Names that collide with system accounts or would be confusing as one.
export const RESERVED_SITE_NAMES = Object.freeze([
  'root', 'daemon', 'bin', 'sys', 'sync', 'games', 'man', 'lp', 'mail', 'news', 'uucp', 'proxy', 'www-data',
  'backup', 'list', 'irc', 'gnats', 'nobody', 'systemd-network', 'systemd-resolve', 'messagebus', 'syslog',
  'sshd', 'ubuntu', 'debian', 'admin', 'nginx', 'apache', 'mysql', 'mariadb', 'postgres', 'redis', 'vaultpanel',
  'vaultpanel-agent', 'docker', 'certbot', 'letsencrypt', 'php', 'default', 'html', 'localhost', 'operator',
]);

// Lowercase DNS host names with at least two labels.
export const DOMAIN_PATTERN = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
export const DOMAIN_MESSAGE = 'Enter a domain such as example.com or blog.example.com';
// A website's domains may also be a wildcard: *.example.com serves every
// name under example.com that no site lists itself (NGINX prefers exact
// names). HTTPS for it needs a wildcard certificate (DNS check) or an
// uploaded one; Let's Encrypt's HTTP check cannot issue it.
export const SITE_DOMAIN_PATTERN = /^(?=.{4,253}$)(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
export const SITE_DOMAIN_MESSAGE = 'Enter a domain such as example.com, blog.example.com or *.example.com';
// Agents that serve wildcard domains.
export const WILDCARD_SITE_MIN_AGENT_VERSION = '0.37.0';
export const MAX_SITE_DOMAINS = 20;

export function isWildcardDomain(domain) {
  return String(domain ?? '').startsWith('*.');
}

// Where the site's public files live, relative to its home directory.
export const DOCUMENT_ROOT_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,4}$/;
export const DOCUMENT_ROOT_MESSAGE = 'A folder inside the site, such as public or current/public';
export const DEFAULT_DOCUMENT_ROOT = 'public';

export const PHP_VERSION_PATTERN = /^[5-9]\.[0-9]$/;
// PHP versions staff can add to a server next to the system's own. Versions
// the distribution does not ship come from the ondrej/php repository
// (Ubuntu) or packages.sury.org (Debian).
export const PHP_VERSIONS = Object.freeze(['7.4', '8.0', '8.1', '8.2', '8.3', '8.4', '8.5']);

export const WEBSITE_STATUSES = Object.freeze(['creating', 'active', 'updating', 'disabled', 'deleting', 'failed']);
export const SSL_STATUSES = Object.freeze(['pending', 'active', 'failed', 'inactive']);
// How early certificates renew and when the panel warns, set on the SSL
// Certificates page (setting ssl.renewal). Let's Encrypt certificates last
// 90 days, so renewing more than 60 days early would renew on every run.
export const SSL_RENEW_BEFORE_MIN = 7;
export const SSL_RENEW_BEFORE_MAX = 60;
export const SSL_RENEW_BEFORE_DEFAULT = 30;
// A certificate counts as expiring within this many days. It renews long
// before, so reaching this means renewal failed. Must be below renewBeforeDays.
export const SSL_WARN_MIN = 1;
export const SSL_WARN_DEFAULT = 14;
export const SSL_EXPIRING_DAYS = SSL_WARN_DEFAULT;
export const SSL_RENEWAL_DEFAULTS = Object.freeze({ renewBeforeDays: SSL_RENEW_BEFORE_DEFAULT, warnDays: SSL_WARN_DEFAULT });
// Agents that set renew_before_expiry and keep Certbot's timer on.
export const SSL_RENEWAL_MIN_AGENT_VERSION = '0.25.0';
// Uploaded certificates and wildcard certificates (INSTALL_SSL_CERT,
// ISSUE_SSL wildcardZone).
export const SSL_UPLOAD_MIN_AGENT_VERSION = '0.28.0';
export const MAX_CERT_PEM_LENGTH = 64 * 1024;
export const MAX_KEY_PEM_LENGTH = 16 * 1024;
export const SSL_SOURCES = Object.freeze(['letsencrypt', 'custom']);

// Whether a certificate's names cover a domain: the name itself, or a
// wildcard (*.example.com) one level above it. The agent has a copy.
export function certificateCovers(names, domain) {
  return (names ?? []).some((n) => n === domain || (n.startsWith('*.') && domain.endsWith(n.slice(1)) && domain.length > n.length - 1 && !domain.slice(0, domain.length - n.length + 1).includes('.')));
}

// The names a wildcard certificate could be for, given a site's domains:
// each zone such that every domain is it or one level under it
// (example.com for example.com, www.example.com, shop.example.com and
// *.example.com). Longest first; empty when no single wildcard certificate
// covers them.
export function wildcardZonesFor(domains) {
  if (!Array.isArray(domains) || !domains.length) return [];
  const candidates = new Set();
  for (const d of domains) {
    if (!isWildcardDomain(d)) candidates.add(d);
    const dot = d.indexOf('.');
    if (dot > 0 && d.slice(dot + 1).includes('.')) candidates.add(d.slice(dot + 1));
  }
  return [...candidates].filter((zone) => domains.every((d) => certificateCovers([zone, `*.${zone}`], d))).sort((x, y) => y.length - x.length);
}

// Problems with a renewal setting, or [] when it is fine.
export function sslRenewalProblems({ renewBeforeDays, warnDays }) {
  const problems = [];
  if (!Number.isInteger(renewBeforeDays) || renewBeforeDays < SSL_RENEW_BEFORE_MIN || renewBeforeDays > SSL_RENEW_BEFORE_MAX) {
    problems.push({ field: 'renewBeforeDays', message: `Enter a whole number of days from ${SSL_RENEW_BEFORE_MIN} to ${SSL_RENEW_BEFORE_MAX}` });
  }
  if (!Number.isInteger(warnDays) || warnDays < SSL_WARN_MIN) problems.push({ field: 'warnDays', message: 'Enter a whole number of days, at least 1' });
  else if (Number.isInteger(renewBeforeDays) && warnDays >= renewBeforeDays) {
    problems.push({ field: 'warnDays', message: 'Warn later than renewal starts: fewer days than the renewal window' });
  }
  return problems;
}

// Software the agent can install. group sorts them on the server page;
// optional ones are not part of "Install all missing", and agents that do not
// report them cannot install them.
export const WEB_STACK_COMPONENTS = Object.freeze({
  nginx: { label: 'NGINX', description: 'Web server and reverse proxy', group: 'web' },
  php: { label: 'PHP-FPM', description: 'PHP with common extensions (MySQL, cURL, GD, mbstring, XML, ZIP)', group: 'web' },
  certbot: { label: 'Certbot', description: 'Free SSL certificates from Let’s Encrypt, renewed automatically', group: 'web' },
  apache: { label: 'Apache', description: 'Reads .htaccess files. Runs behind NGINX on 127.0.0.1:8080 for the websites that turn .htaccess on', group: 'web', optional: true },
  git: { label: 'Git', description: 'Clones app repositories for deployments', group: 'apps' },
  pm2: { label: 'PM2', description: 'Keeps Node.js and Python apps running (installed with npm)', group: 'apps' },
  python: { label: 'Python', description: 'Python 3 with venv and pip, for Python apps', group: 'apps' },
  go: { label: 'Go', description: 'The Go compiler, for Go apps', group: 'apps', optional: true },
  ruby: { label: 'Ruby', description: 'Ruby with Bundler and build tools for gems, for Ruby apps', group: 'apps', optional: true },
  composer: { label: 'Composer', description: 'PHP dependencies for PHP websites deployed from Git', group: 'apps', optional: true },
  mariadb: { label: 'MariaDB', description: 'MySQL-compatible database server', group: 'databases' },
  cron: { label: 'Cron', description: 'Runs cron jobs on their schedule', group: 'automation' },
});
export const WEB_STACK_COMPONENT_KEYS = Object.freeze(Object.keys(WEB_STACK_COMPONENTS));

// Paths in the file manager are relative to the site's home directory: no
// leading slash, no empty, "." or ".." segments, no control characters.
// The empty string is the home directory itself.
export const FILE_PATH_PATTERN = /^(?:(?!\.{1,2}(?:\/|$))[^/\p{Cc}]+(?:\/(?!$)|$))*$/u;
export const FILE_PATH_MESSAGE = 'Must be a path inside the site';
export const MAX_FILE_PATH_LENGTH = 1024;
// Largest file the file manager opens, saves or uploads in one go.
export const MAX_FILE_BYTES = 1024 * 1024;
// Larger files go up in pieces (FILE_UPLOAD): the panel keeps the pieces
// and the server's agent fetches them. The panel's own limit is set with
// VAULTPANEL_FILE_UPLOAD_MAX_MB; this is the most any agent takes.
export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024 * 1024;
export const UPLOAD_CHUNK_BYTES = 8 * 1024 * 1024;
// Files bigger than MAX_FILE_BYTES are opened and downloaded through the
// panel (FILE_DOWNLOAD); the editor opens text files up to this size.
export const MAX_EDIT_BYTES = 10 * 1024 * 1024;
// Permissions in the file manager: three octal digits (no setuid, setgid, sticky).
export const FILE_MODE_PATTERN = /^[0-7]{3}$/;
// Archives the file manager unpacks (FILE_EXTRACT) and the most items one
// zip is made from (FILE_COMPRESS).
export const ARCHIVE_FILE_PATTERN = /\.(zip|tar\.gz|tgz|tar)$/i;
export const MAX_COMPRESS_NAMES = 200;
// One file or folder name inside a folder.
export const FILE_NAME_PATTERN = /^(?!\.{1,2}$)[^/\p{Cc}]{1,255}$/u;
export const FILE_LOG_KINDS = Object.freeze(['access', 'error']);

export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function isReservedSiteName(name) {
  return RESERVED_SITE_NAMES.includes(String(name));
}

// Problems with a site definition that a per-field check cannot see.
// Returns [{ field, message }].
export function siteSpecProblems({ name, type, domains, phpVersion, proxyPort }) {
  const problems = [];
  if (name && isReservedSiteName(name)) problems.push({ field: 'name', message: 'This name is reserved for the system' });
  if (type === 'php' && !phpVersion) problems.push({ field: 'phpVersion', message: 'Choose a PHP version' });
  if (type === 'proxy' && !proxyPort) problems.push({ field: 'proxyPort', message: 'Enter the port the app listens on' });
  if (Array.isArray(domains) && new Set(domains).size !== domains.length) {
    problems.push({ field: 'domains', message: 'Each domain can be listed once' });
  }
  return problems;
}

// Custom NGINX rules staff can add to a site's server block. Only these
// directives are accepted (the agent keeps its own copy and checks again):
// nothing that reads or writes files outside the site, loads code, or talks
// to a local socket.
export const MAX_CUSTOM_NGINX_LENGTH = 8192;
export const CUSTOM_NGINX_BLOCKS = Object.freeze(['location', 'if', 'limit_except']);
export const CUSTOM_NGINX_DIRECTIVES = Object.freeze([
  'absolute_redirect', 'add_header', 'add_trailer', 'allow', 'autoindex', 'break', 'charset', 'client_body_timeout',
  'client_max_body_size', 'default_type', 'deny', 'error_page', 'etag', 'expires', 'fastcgi_buffer_size', 'fastcgi_buffers',
  'fastcgi_param', 'fastcgi_read_timeout', 'gzip', 'gzip_comp_level', 'gzip_min_length', 'gzip_proxied', 'gzip_types',
  'gzip_vary', 'if_modified_since', 'index', 'internal', 'keepalive_timeout', 'limit_rate', 'limit_rate_after',
  'log_not_found', 'merge_slashes', 'port_in_redirect', 'proxy_buffering', 'proxy_cache_bypass', 'proxy_connect_timeout',
  'proxy_hide_header', 'proxy_http_version', 'proxy_pass', 'proxy_pass_header', 'proxy_read_timeout', 'proxy_redirect',
  'proxy_send_timeout', 'proxy_set_header', 'return', 'rewrite', 'satisfy', 'send_timeout', 'server_name_in_redirect',
  'set', 'sub_filter', 'sub_filter_once', 'sub_filter_types', 'try_files', 'valid_referers',
]);

// The first problem with custom NGINX rules, or null. Reads them the way
// NGINX does: statements end with ";", blocks open with "{" and close with
// "}", quotes group words and "#" starts a comment.
export function customNginxProblem(text) {
  if (typeof text !== 'string') return 'Must be text';
  if (text.length > MAX_CUSTOM_NGINX_LENGTH) return `At most ${MAX_CUSTOM_NGINX_LENGTH} characters`;
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(text)) return 'Contains control characters';
  let depth = 0;
  let words = [];
  let word = '';
  let quote = null;
  let comment = false;
  const endWord = () => {
    if (word) words.push(word);
    word = '';
  };
  const check = (opensBlock) => {
    const [name, ...args] = words;
    words = [];
    if (!name) return opensBlock ? 'A "{" has no directive before it' : null;
    const allowed = opensBlock ? CUSTOM_NGINX_BLOCKS : CUSTOM_NGINX_DIRECTIVES;
    if (!allowed.includes(name)) return `${opensBlock ? 'Blocks' : 'The directive'} "${name.slice(0, 40)}" ${opensBlock ? 'are' : 'is'} not allowed in custom rules`;
    if (args.some((a) => /unix:/i.test(a))) return 'Unix sockets are not allowed in custom rules';
    // A fixed http(s) address, so a variable cannot turn it into a socket.
    if (name === 'proxy_pass' && !/^https?:\/\/[A-Za-z0-9.:[\]-]+(?:\/\S*)?$/.test(args[0] ?? '')) return 'proxy_pass needs a fixed http:// or https:// address';
    return null;
  };
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (comment) {
      if (c === '\n') comment = false;
      continue;
    }
    if (quote) {
      if (c === '\\' && i + 1 < text.length) {
        word += c + text[i + 1];
        i += 1;
      } else if (c === quote) {
        quote = null;
        word += c;
      } else word += c;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      word += c;
    } else if (c === '#' && !word) comment = true;
    else if (/\s/.test(c)) endWord();
    else if (c === ';' || c === '{') {
      endWord();
      const problem = check(c === '{');
      if (problem) return problem;
      if (c === '{') depth += 1;
    } else if (c === '}') {
      endWord();
      if (words.length) return `"${words[0].slice(0, 40)}" is missing its ";"`;
      if (depth === 0) return 'A "}" closes a block that was never opened';
      depth -= 1;
    } else word += c;
  }
  endWord();
  if (quote) return 'A quote is never closed';
  if (words.length) return `"${words[0].slice(0, 40)}" is missing its ";"`;
  if (depth) return 'A "{" is never closed';
  return null;
}

// ---- Static websites deployed from Git ------------------------------------

// A static site deployed from Git serves "current", a link to the live
// release's output folder. Its old document root (usually public) is kept
// and served again if Git deploy is turned off.
export const SITE_GIT_DOCUMENT_ROOT = 'current';
export const SITE_GIT_MIN_AGENT_VERSION = '0.22.0';
// Environment variables for the install and build.
export const SITE_GIT_ENV_MIN_AGENT_VERSION = '0.24.0';
// PHP websites deployed from Git need this agent version.
export const SITE_GIT_PHP_MIN_AGENT_VERSION = '0.32.0';
// The folder in the repository that is served after the build, such as
// dist or build. Empty: the repository itself.
export const SITE_OUTPUT_DIR_PATTERN = DOCUMENT_ROOT_PATTERN;
export const SITE_OUTPUT_DIR_MESSAGE = 'A folder inside the repository, such as dist or build. Leave it empty to serve the repository as it is.';
// The stages a site deployment goes through, in order.
export const SITE_DEPLOY_STAGES = Object.freeze({
  prepare: 'Prepare the site folders',
  fetch: 'Clone the repository',
  install: 'Install dependencies',
  build: 'Build',
  publish: 'Find the output folder and publish it',
  health_check: 'Check the site answers',
});
// Agent error codes that tell which stage a site deployment failed at.
export const SITE_DEPLOY_ERROR_STAGES = Object.freeze({
  PREPARE_FAILED: 'prepare',
  CLONE_FAILED: 'fetch',
  INSTALL_FAILED: 'install',
  BUILD_FAILED: 'build',
  OUTPUT_NOT_FOUND: 'publish',
  PUBLISH_FAILED: 'publish',
  HEALTH_CHECK_FAILED: 'health_check',
});
