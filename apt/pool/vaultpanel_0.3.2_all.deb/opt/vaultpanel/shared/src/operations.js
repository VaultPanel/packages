// The catalog of operations the panel can ask a server agent to perform.
// The agent keeps its own independent allowlist and re-validates everything;
// this catalog drives the panel side (authorization, validation, UI).
//
// An operation with available: false belongs to a later roadmap phase. The
// panel refuses to queue it and the UI shows it as unavailable.

import { PERMISSIONS } from './permissions.js';
import {
  DOCUMENT_ROOT_MESSAGE,
  DOCUMENT_ROOT_PATTERN,
  DOMAIN_MESSAGE,
  DOMAIN_PATTERN,
  EMAIL_PATTERN,
  FILE_LOG_KINDS,
  FILE_MODE_PATTERN,
  FILE_NAME_PATTERN,
  FILE_PATH_MESSAGE,
  FILE_PATH_PATTERN,
  MAX_COMPRESS_NAMES,
  MAX_FILE_BYTES,
  MAX_FILE_PATH_LENGTH,
  MAX_UPLOAD_BYTES,
  MAX_CERT_PEM_LENGTH,
  MAX_CUSTOM_NGINX_LENGTH,
  MAX_KEY_PEM_LENGTH,
  MAX_SITE_DOMAINS,
  PHP_VERSION_PATTERN,
  PHP_VERSIONS,
  SITE_DOMAIN_MESSAGE,
  SITE_DOMAIN_PATTERN,
  SITE_NAME_MESSAGE,
  SITE_NAME_PATTERN,
  SITE_OUTPUT_DIR_MESSAGE,
  SITE_OUTPUT_DIR_PATTERN,
  SITE_TYPE_KEYS,
  SSL_RENEW_BEFORE_MAX,
  SSL_RENEW_BEFORE_MIN,
  WEB_STACK_COMPONENT_KEYS,
} from './websites.js';
import {
  APP_LOG_KINDS,
  APP_PORT_MAX,
  APP_PORT_MIN,
  APP_RUNTIME_KEYS,
  BRANCH_MESSAGE,
  BRANCH_PATTERN,
  COMMAND_TEXT_PATTERN,
  ENV_ENTRY_PATTERN,
  MAX_COMMAND_LENGTH,
  MAX_COMMAND_LINES,
  MAX_ENV_VALUE_LENGTH,
  MAX_ENV_VARS,
  MAX_KEEP_RELEASES,
  MAX_REPOSITORY_URL_LENGTH,
  RELEASE_ID_PATTERN,
  REPOSITORY_URL_MESSAGE,
  REPOSITORY_URL_PATTERN,
} from './applications.js';
import {
  DATABASE_NAME_MESSAGE,
  DATABASE_NAME_PATTERN,
  DATABASE_PASSWORD_MESSAGE,
  DATABASE_PASSWORD_PATTERN,
  DATABASE_PRIVILEGE_KEYS,
  DATABASE_USER_MESSAGE,
  DATABASE_OBJECT_NAME_MESSAGE,
  DATABASE_OBJECT_NAME_PATTERN,
  DATABASE_USER_PATTERN,
  MAX_QUERY_LENGTH,
  MAX_USER_DATABASES,
} from './databases.js';
import {
  BACKUP_AGENT_KINDS,
  BACKUP_ID_PATTERN,
  BACKUP_NAME_PATTERN,
  STORAGE_ACCESS_KEY_PATTERN,
  STORAGE_BUCKET_PATTERN,
  STORAGE_KEY_MAX_LENGTH,
  STORAGE_KEY_PATTERN,
  STORAGE_REGION_PATTERN,
  STORAGE_SECRET_PATTERN,
  SFTP_HOST_PATTERN,
  SFTP_KNOWN_HOSTS_PATTERN,
  SFTP_PATH_PATTERN,
  SFTP_PRIVATE_KEY_PATTERN,
  SFTP_USER_PATTERN,
  CRON_TIMEOUT_MAX,
  CRON_TIMEOUT_MIN,
  CRON_WORKING_DIR_MESSAGE,
  CRON_WORKING_DIR_PATTERN,
  LOG_PRIORITY_KEYS,
  LOG_SEARCH_PATTERN,
  LOG_SOURCE_KEYS,
  SHA256_PATTERN,
} from './automation.js';
import { CRON_EXPRESSION_MESSAGE, CRON_EXPRESSION_PATTERN } from './cron.js';
import { LOCAL_AI_MODEL_IDS } from './localAi.js';
import {
  CONTAINER_COMMAND_PATTERN,
  CONTAINER_CPU_PERCENT,
  CONTAINER_HEALTH_SECONDS,
  CONTAINER_ID_PATTERN,
  CONTAINER_MEMORY_MB,
  CONTAINER_NAME_MESSAGE,
  CONTAINER_NAME_PATTERN,
  IMAGE_ID_PATTERN,
  IMAGE_REF_MESSAGE,
  IMAGE_REF_PATTERN,
  MAX_CONTAINER_COMMAND_ARGS,
  MAX_CONTAINER_COMMAND_LENGTH,
  MAX_CONTAINER_PORTS,
  MAX_CONTAINER_VOLUMES,
  MAX_IMAGE_REF_LENGTH,
  portMappingMessage,
  RESTART_POLICY_KEYS,
  volumeMappingMessage,
} from './containers.js';
import {
  APP_CPU_LIMIT,
  APP_INSTANCES,
  APP_MEMORY_LIMIT_MB,
  FAIL2BAN_LIMITS,
  FAIL2BAN_MAX_IGNORE,
  FIREWALL_ACTION_KEYS,
  FIREWALL_COMMENT_MESSAGE,
  FIREWALL_COMMENT_PATTERN,
  FIREWALL_DIRECTION_KEYS,
  FIREWALL_INCOMING_POLICY_KEYS,
  FIREWALL_OUTGOING_POLICY_KEYS,
  FIREWALL_PROTOCOL_KEYS,
  isAddressOrNetwork,
  isIPv4,
  portSpecMessage,
  SECURITY_TOOL_KEYS,
  sourceMessage,
  SSH_FINGERPRINT_PATTERN,
  SSH_MAX_AUTH_TRIES_MAX,
  SSH_MAX_AUTH_TRIES_MIN,
  SSH_MAX_PORTS,
  SSH_PUBLIC_KEY_MESSAGE,
  SSH_PUBLIC_KEY_PATTERN,
  SSH_ROOT_LOGIN_KEYS,
  SSH_USER_PATTERN,
  sshPortMessage,
} from './security.js';
import {
  CLOUDFLARE_TOKEN_PATTERN,
  DNS_CAA_TAGS,
  DNS_EMAIL_PATTERN,
  DNS_PROVIDER_TYPE_KEYS,
  DNS_RECORD_TYPE_KEYS,
  DNS_TTL,
  dnsRecordProblems,
  MAX_DNS_RECORDS,
  MAX_DNS_TXT_LENGTH,
  NAMECHEAP_KEY_PATTERN,
  NAMECHEAP_USER_PATTERN,
} from './dns.js';
import {
  MAIL_ADDRESS_MESSAGE,
  MAIL_ADDRESS_PATTERN,
  MAIL_DKIM_SELECTOR_PATTERN,
  MAIL_PASSWORD_HASH_PATTERN,
  MAIL_QUOTA_MB,
  MAX_FORWARDER_DESTINATIONS,
  MAX_MAIL_DOMAINS,
  MAX_MAIL_FORWARDERS,
  MAX_MAILBOXES,
} from './mail.js';
import {
  CMS_ADMIN_PASSWORD_MESSAGE,
  CMS_ADMIN_PASSWORD_PATTERN,
  CMS_ADMIN_USER_MESSAGE,
  CMS_ADMIN_USER_PATTERN,
  CMS_APP_KEYS,
  CMS_DIRECTORY_PATTERN,
  CMS_TITLE_PATTERN,
  CMS_URL_PATTERN,
} from './cms.js';

// systemd unit names: letters, digits and :-_.@ with an optional .service suffix.
export const SERVICE_NAME_PATTERN = /^[a-zA-Z0-9][a-zA-Z0-9:_.@-]{0,99}$/;

const serviceParam = {
  service: {
    type: 'string',
    required: true,
    maxLength: 100,
    pattern: SERVICE_NAME_PATTERN,
    patternMessage: 'Must be a valid systemd service name',
  },
};

// Process names as `ps -o comm=` prints them: printable, no control characters.
export const PROCESS_COMMAND_PATTERN = /^\P{Cc}{1,64}$/u;
export const PROCESS_SIGNALS = Object.freeze(['TERM', 'KILL']);

const siteName = { type: 'string', required: true, maxLength: 32, pattern: SITE_NAME_PATTERN, patternMessage: SITE_NAME_MESSAGE };
const renewBeforeDays = { type: 'integer', min: SSL_RENEW_BEFORE_MIN, max: SSL_RENEW_BEFORE_MAX };

// Everything the agent needs to build a site's NGINX server block and PHP
// pool. The agent renders the configuration itself from these fields; the
// only configuration text is a site's checked custom NGINX rules.
const siteSpec = {
  name: siteName,
  type: { type: 'string', required: true, enum: SITE_TYPE_KEYS },
  domains: {
    type: 'array',
    required: true,
    minItems: 1,
    maxItems: MAX_SITE_DOMAINS,
    unique: true,
    // Agents from WILDCARD_SITE_MIN_AGENT_VERSION: *.example.com.
    items: { type: 'string', maxLength: 253, pattern: SITE_DOMAIN_PATTERN, patternMessage: SITE_DOMAIN_MESSAGE },
  },
  documentRoot: { type: 'string', maxLength: 200, pattern: DOCUMENT_ROOT_PATTERN, patternMessage: DOCUMENT_ROOT_MESSAGE, default: 'public' },
  phpVersion: { type: 'string', maxLength: 4, pattern: PHP_VERSION_PATTERN, patternMessage: 'Must be a PHP version such as 8.3' },
  proxyPort: { type: 'integer', min: 1, max: 65535 },
  enabled: { type: 'boolean', default: true },
  ssl: { type: 'boolean', default: false },
  forceHttps: { type: 'boolean', default: false },
  // Staff-written NGINX directives; the agent checks each one (customNginxProblem).
  customNginx: { type: 'string', maxLength: MAX_CUSTOM_NGINX_LENGTH },
  // Apache behind NGINX serves the site, so its .htaccess files apply.
  htaccess: { type: 'boolean' },
  // Static sites: paths with no file are answered with index.html.
  spa: { type: 'boolean' },
};

const filePath = (required = false) => ({
  type: 'string',
  required,
  maxLength: MAX_FILE_PATH_LENGTH,
  pattern: FILE_PATH_PATTERN,
  patternMessage: FILE_PATH_MESSAGE,
  ...(required ? {} : { default: '' }),
});

// ---- Applications and databases (phase 4) ---------------------------------

// An application's name is its Linux user and home folder, like a site's.
const appName = siteName;
const commandText = (required = false) => ({
  type: 'string',
  required,
  maxLength: MAX_COMMAND_LINES * (MAX_COMMAND_LENGTH + 1),
  pattern: COMMAND_TEXT_PATTERN,
  patternMessage: 'Must be plain text',
});
// What the agent needs to run an app: how to start it, its port and its
// environment ("KEY=value" entries).
const appProcess = {
  name: appName,
  runtime: { type: 'string', required: true, enum: APP_RUNTIME_KEYS },
  startCommand: commandText(true),
  port: { type: 'integer', min: APP_PORT_MIN, max: APP_PORT_MAX },
  env: {
    type: 'array',
    maxItems: MAX_ENV_VARS,
    items: { type: 'string', maxLength: MAX_ENV_VALUE_LENGTH + 130, pattern: ENV_ENTRY_PATTERN, patternMessage: 'Must be KEY=value' },
    default: [],
  },
  healthCheckSeconds: { type: 'integer', min: 5, max: 300, default: 30 },
  // Resource limits (phase 6), enforced by systemd on the app's unit.
  cpuPercent: { type: 'integer', min: APP_CPU_LIMIT.min, max: APP_CPU_LIMIT.max },
  memoryMb: { type: 'integer', min: APP_MEMORY_LIMIT_MB.min, max: APP_MEMORY_LIMIT_MB.max },
  // Copies of the app (agent 0.14.0 and later; only sent when above 1).
  instances: { type: 'integer', min: APP_INSTANCES.min, max: APP_INSTANCES.max },
  // Node.js apps reloaded by PM2 without downtime (agent 0.32.0 and later;
  // only sent when on).
  zeroDowntime: { type: 'boolean' },
};
const releaseId = { type: 'string', required: true, maxLength: 21, pattern: RELEASE_ID_PATTERN, patternMessage: 'Must be a release id' };
const siteOutputDir = { type: 'string', maxLength: 200, pattern: SITE_OUTPUT_DIR_PATTERN, patternMessage: SITE_OUTPUT_DIR_MESSAGE };
const databaseName = { type: 'string', required: true, maxLength: 64, pattern: DATABASE_NAME_PATTERN, patternMessage: DATABASE_NAME_MESSAGE };
const databaseObject = (required) => ({ type: 'string', required, maxLength: 64, pattern: DATABASE_OBJECT_NAME_PATTERN, patternMessage: DATABASE_OBJECT_NAME_MESSAGE });
const databaseUser = { type: 'string', required: true, maxLength: 32, pattern: DATABASE_USER_PATTERN, patternMessage: DATABASE_USER_MESSAGE };
const databasePassword = (required) => ({ type: 'string', required, maxLength: 72, pattern: DATABASE_PASSWORD_PATTERN, patternMessage: DATABASE_PASSWORD_MESSAGE });
const databaseGrants = {
  databases: {
    type: 'array',
    maxItems: MAX_USER_DATABASES,
    unique: true,
    items: { type: 'string', maxLength: 64, pattern: DATABASE_NAME_PATTERN, patternMessage: DATABASE_NAME_MESSAGE },
    default: [],
  },
  privileges: { type: 'string', enum: DATABASE_PRIVILEGE_KEYS, default: 'all' },
};

// ---- Backups and cron jobs (phase 5) -------------------------------------
const dnsZone = { type: 'string', required: true, maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE };
const dnsRecord = {
  type: 'object',
  fields: {
    name: { type: 'string', required: true, maxLength: 200 },
    type: { type: 'string', required: true, enum: DNS_RECORD_TYPE_KEYS },
    ttl: { type: 'integer', min: DNS_TTL.min, max: DNS_TTL.max },
    value: { type: 'string', required: true, maxLength: MAX_DNS_TXT_LENGTH },
    priority: { type: 'integer', min: 0, max: 65535 },
    weight: { type: 'integer', min: 0, max: 65535 },
    port: { type: 'integer', min: 1, max: 65535 },
    tag: { type: 'string', enum: DNS_CAA_TAGS },
  },
  check: (record) => {
    const [problem] = dnsRecordProblems(record);
    return problem ? `${record.name} ${record.type}: ${problem.message}` : null;
  },
};

// ---- Email hosting ------------------------------------------------------
const mailHostname = { type: 'string', required: true, maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE };
const mailAddress = { type: 'string', maxLength: 254, pattern: MAIL_ADDRESS_PATTERN, patternMessage: MAIL_ADDRESS_MESSAGE };
const mailState = {
  hostname: mailHostname,
  // Raised by the panel on every change; the agent never goes back to an
  // older one.
  serial: { type: 'integer', required: true, min: 1, max: Number.MAX_SAFE_INTEGER },
  domains: {
    type: 'array',
    required: true,
    maxItems: MAX_MAIL_DOMAINS,
    items: {
      type: 'object',
      fields: {
        domain: { type: 'string', required: true, maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE },
        selector: { type: 'string', required: true, maxLength: 32, pattern: MAIL_DKIM_SELECTOR_PATTERN, patternMessage: 'Must be lower-case letters and digits' },
      },
    },
  },
  mailboxes: {
    type: 'array',
    required: true,
    maxItems: MAX_MAILBOXES,
    items: {
      type: 'object',
      fields: {
        address: { ...mailAddress, required: true },
        hash: { type: 'string', required: true, maxLength: 140, pattern: MAIL_PASSWORD_HASH_PATTERN, patternMessage: 'Must be a SHA512-CRYPT hash' },
        quotaMb: { type: 'integer', required: true, min: MAIL_QUOTA_MB.min, max: MAIL_QUOTA_MB.max },
        enabled: { type: 'boolean', required: true },
      },
    },
  },
  forwarders: {
    type: 'array',
    required: true,
    maxItems: MAX_MAIL_FORWARDERS,
    items: {
      type: 'object',
      fields: {
        address: { ...mailAddress, required: true },
        destinations: { type: 'array', required: true, minItems: 1, maxItems: MAX_FORWARDER_DESTINATIONS, unique: true, items: mailAddress },
      },
    },
  },
  // Mailboxes (addresses) and domains whose stored mail is deleted.
  purge: {
    type: 'array',
    maxItems: MAX_MAILBOXES,
    unique: true,
    items: { type: 'string', maxLength: 254, check: (v) => (MAIL_ADDRESS_PATTERN.test(v) || DOMAIN_PATTERN.test(v) ? null : 'Must be an address or a domain') },
    default: [],
  },
};

const backupTarget = {
  backupId: { type: 'string', required: true, maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be a backup id' },
  kind: { type: 'string', required: true, enum: BACKUP_AGENT_KINDS },
  name: { type: 'string', required: true, maxLength: 64, pattern: BACKUP_NAME_PATTERN, patternMessage: 'Must be a site, app or database name' },
};
// A storage destination (S3-compatible, or another server over SFTP), with
// the object or file a job reads or writes. Filled by the panel from a saved
// destination; redacted once the job ends.
function checkStorageEndpoint(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    return 'Must be an http(s) address';
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || (url.pathname !== '/' && url.pathname !== '')) {
    return 'Must be an http(s) address with no path';
  }
  return null;
}
const STORAGE_FIELDS = {
  s3: ['endpoint', 'region', 'bucket', 'accessKeyId', 'secretAccessKey', 'pathStyle'],
  sftp: ['host', 'port', 'username', 'privateKey', 'knownHosts', 'path'],
};
const STORAGE_REQUIRED = {
  s3: ['endpoint', 'region', 'bucket', 'accessKeyId', 'secretAccessKey'],
  sftp: ['host', 'port', 'username', 'privateKey'],
};
function checkStorageFields(value) {
  for (const field of STORAGE_REQUIRED[value.type]) if (value[field] === undefined) return `${field}: Required`;
  const other = value.type === 's3' ? 'sftp' : 's3';
  const stray = STORAGE_FIELDS[other].find((f) => value[f] !== undefined);
  return stray ? `${stray}: Unknown parameter` : null;
}
const backupStorage = {
  type: 'object',
  check: checkStorageFields,
  fields: {
    type: { type: 'string', required: true, enum: ['s3', 'sftp'] },
    endpoint: { type: 'string', maxLength: 255, check: checkStorageEndpoint },
    region: { type: 'string', maxLength: 40, pattern: STORAGE_REGION_PATTERN, patternMessage: 'Must be a region name' },
    bucket: { type: 'string', maxLength: 63, pattern: STORAGE_BUCKET_PATTERN, patternMessage: 'Must be a bucket name' },
    accessKeyId: { type: 'string', maxLength: 128, pattern: STORAGE_ACCESS_KEY_PATTERN, patternMessage: 'Must be an access key ID' },
    secretAccessKey: { type: 'string', maxLength: 256, pattern: STORAGE_SECRET_PATTERN, patternMessage: 'Must be a secret key' },
    pathStyle: { type: 'boolean' },
    host: { type: 'string', maxLength: 253, pattern: SFTP_HOST_PATTERN, patternMessage: 'Must be a host name or IP address' },
    port: { type: 'integer', min: 1, max: 65535 },
    username: { type: 'string', maxLength: 32, pattern: SFTP_USER_PATTERN, patternMessage: 'Must be a user name' },
    privateKey: { type: 'string', maxLength: 5000, pattern: SFTP_PRIVATE_KEY_PATTERN, patternMessage: 'Must be an OpenSSH private key' },
    // Pinned on the first check; a check without it reads and returns it.
    knownHosts: { type: 'string', maxLength: 4000, pattern: SFTP_KNOWN_HOSTS_PATTERN, patternMessage: 'Must be known_hosts lines' },
    path: { type: 'string', maxLength: 200, pattern: SFTP_PATH_PATTERN, patternMessage: 'Must be a folder' },
    key: { type: 'string', required: true, maxLength: STORAGE_KEY_MAX_LENGTH, pattern: STORAGE_KEY_PATTERN, patternMessage: 'Must be an object key' },
    keepLocal: { type: 'boolean' },
  },
};
// A DNS provider the agent adds Let's Encrypt's check record to, filled by the
// panel from a saved provider; redacted once the job ends. Namecheap also
// needs the domain as registered there and the address the server calls from.
const DNS_PROVIDER_FIELDS = { cloudflare: ['apiToken'], namecheap: ['apiUser', 'apiKey', 'clientIp', 'domain'] };
function checkDnsProviderFields(value) {
  const fields = DNS_PROVIDER_FIELDS[value.type];
  for (const field of fields) if (value[field] === undefined) return `${field}: Required`;
  const stray = Object.keys(value).find((k) => k !== 'type' && !fields.includes(k));
  return stray ? `${stray}: Unknown parameter` : null;
}
const dnsProvider = {
  type: 'object',
  check: checkDnsProviderFields,
  fields: {
    type: { type: 'string', required: true, enum: DNS_PROVIDER_TYPE_KEYS },
    apiToken: { type: 'string', maxLength: 200, pattern: CLOUDFLARE_TOKEN_PATTERN, patternMessage: 'Must be a Cloudflare API token' },
    apiUser: { type: 'string', maxLength: 64, pattern: NAMECHEAP_USER_PATTERN, patternMessage: 'Must be a Namecheap user name' },
    apiKey: { type: 'string', maxLength: 64, pattern: NAMECHEAP_KEY_PATTERN, patternMessage: 'Must be a Namecheap API key' },
    clientIp: { type: 'string', maxLength: 15, check: (v) => (isIPv4(v) ? null : 'Must be an IPv4 address') },
    domain: { type: 'string', maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE },
  },
};
// ---- Security (phase 6) ------------------------------------------------------
// TCP ports the agent must keep reachable, whatever a change asks: the panel
// adds the port people use to reach it when it runs on this server. The agent
// adds the SSH ports itself.
const protectedPorts = {
  type: 'array',
  maxItems: 10,
  unique: true,
  items: { type: 'integer', min: 1, max: 65535 },
  default: [],
};
const firewallRule = {
  action: { type: 'string', required: true, enum: FIREWALL_ACTION_KEYS },
  protocol: { type: 'string', enum: FIREWALL_PROTOCOL_KEYS, default: 'tcp' },
  // Empty: every port (only with a source address).
  port: { type: 'string', maxLength: 100, check: portSpecMessage },
  source: { type: 'string', maxLength: 50, check: sourceMessage, default: 'any' },
  // Outgoing rules (agent 0.34.0) name where to instead of from where.
  // No defaults, so agents before 0.34.0 get the same parameters as before.
  direction: { type: 'string', enum: FIREWALL_DIRECTION_KEYS },
  destination: { type: 'string', maxLength: 50, check: sourceMessage },
};
const sshUser = { type: 'string', maxLength: 32, pattern: SSH_USER_PATTERN, patternMessage: 'Must be a Linux account name' };
const addressList = (max) => ({
  type: 'array',
  maxItems: max,
  unique: true,
  items: { type: 'string', maxLength: 50, check: (v) => (isAddressOrNetwork(v) ? null : 'Must be an IP address or network') },
  default: [],
});

const cronId = { type: 'string', required: true, maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be a cron job id' };

// ---- Containers (phase 10) ---------------------------------------------------
// A container by Docker ID, or a container VaultPanel deployed by its name.
const containerRef = {
  type: 'string',
  required: true,
  maxLength: 64,
  check: (v) => (CONTAINER_ID_PATTERN.test(v) || CONTAINER_NAME_PATTERN.test(v) ? null : 'Must be a container ID or name'),
};
// Host ports of containers VaultPanel itself depends on (its own MariaDB and
// Redis, when they run in Docker on this server): the agent refuses to stop,
// restart or remove a container that publishes one.
const protectedHostPorts = protectedPorts;
const managedId = { type: 'string', maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be a container record id' };
const imageRef = { type: 'string', required: true, maxLength: MAX_IMAGE_REF_LENGTH, pattern: IMAGE_REF_PATTERN, patternMessage: IMAGE_REF_MESSAGE };
const containerSpec = {
  id: { ...managedId, required: true },
  name: { type: 'string', required: true, maxLength: 32, pattern: CONTAINER_NAME_PATTERN, patternMessage: CONTAINER_NAME_MESSAGE },
  image: imageRef,
  ports: { type: 'array', maxItems: MAX_CONTAINER_PORTS, unique: true, items: { type: 'string', maxLength: 40, check: portMappingMessage }, default: [] },
  env: {
    type: 'array',
    maxItems: MAX_ENV_VARS,
    items: { type: 'string', maxLength: MAX_ENV_VALUE_LENGTH + 130, pattern: ENV_ENTRY_PATTERN, patternMessage: 'Must be KEY=value' },
    default: [],
  },
  volumes: { type: 'array', maxItems: MAX_CONTAINER_VOLUMES, unique: true, items: { type: 'string', maxLength: 240, check: volumeMappingMessage }, default: [] },
  restartPolicy: { type: 'string', enum: RESTART_POLICY_KEYS, default: 'unless-stopped' },
  memoryMb: { type: 'integer', min: CONTAINER_MEMORY_MB.min, max: CONTAINER_MEMORY_MB.max },
  cpuPercent: { type: 'integer', min: CONTAINER_CPU_PERCENT.min, max: CONTAINER_CPU_PERCENT.max },
  // The arguments of the command (the panel splits the line it was given).
  command: {
    type: 'array',
    maxItems: MAX_CONTAINER_COMMAND_ARGS,
    items: { type: 'string', maxLength: MAX_CONTAINER_COMMAND_LENGTH, pattern: CONTAINER_COMMAND_PATTERN, patternMessage: 'Must be one line of text' },
  },
  healthCheckSeconds: { type: 'integer', min: CONTAINER_HEALTH_SECONDS.min, max: CONTAINER_HEALTH_SECONDS.max, default: CONTAINER_HEALTH_SECONDS.default },
};

// Flags used below:
// internal: queued only by panel services (websites, files), which fill the
//   parameters from their own records. The generic job endpoint refuses them.
// routine: read-only lookups (listing files, reading logs). Hidden from job
//   lists unless asked for, so they don't bury real changes.
// redactParams: parameters dropped from the stored job once it finishes and
//   never written to the audit log (file contents).
// transientOutput: the result is cleared an hour after the job finishes.
export const OPERATIONS = Object.freeze({
  SERVICE_STATUS: {
    label: 'Check service status',
    available: true,
    permission: PERMISSIONS.SERVERS_SERVICES,
    params: serviceParam,
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  SERVICE_START: {
    label: 'Start service',
    available: true,
    permission: PERMISSIONS.SERVERS_SERVICES,
    params: serviceParam,
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  SERVICE_STOP: {
    label: 'Stop service',
    available: true,
    permission: PERMISSIONS.SERVERS_SERVICES,
    params: serviceParam,
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  SERVICE_LOGS: {
    label: 'Read service logs',
    available: true,
    permission: PERMISSIONS.SERVERS_SERVICES,
    params: {
      ...serviceParam,
      lines: { type: 'integer', min: 10, max: 1000, default: 200 },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  SERVICE_RESTART: {
    label: 'Restart service',
    available: true,
    permission: PERMISSIONS.SERVERS_SERVICES,
    params: serviceParam,
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  PROCESS_LIST: {
    label: 'List processes',
    available: true,
    permission: PERMISSIONS.SERVERS_PROCESSES,
    params: {
      limit: { type: 'integer', min: 1, max: 500, default: 50 },
      sortBy: { type: 'string', enum: ['cpu', 'memory'], default: 'cpu' },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  PROCESS_SIGNAL: {
    label: 'Stop process',
    available: true,
    permission: PERMISSIONS.SERVERS_SIGNAL,
    params: {
      pid: { type: 'integer', required: true, min: 2, max: 4_194_304 },
      // The name the user saw. The agent refuses if the PID now belongs to a
      // different program (PIDs are reused).
      command: {
        type: 'string',
        required: true,
        maxLength: 64,
        pattern: PROCESS_COMMAND_PATTERN,
        patternMessage: 'Must be a process name',
      },
      signal: { type: 'string', enum: PROCESS_SIGNALS, default: 'TERM' },
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 30,
  },
  // Phase 9: which TCP ports the server listens on, and the programs behind them.
  LISTENING_PORTS: {
    label: 'List listening ports',
    available: true,
    routine: true,
    permission: PERMISSIONS.SERVERS_PROCESSES,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  // Agents from SELF_CHECK_MIN_AGENT_VERSION: the server's self-check, read
  // now rather than with the next inventory (shared/src/selfCheck.js).
  SELF_CHECK: {
    label: 'Run server self-check',
    available: true,
    routine: true,
    permission: PERMISSIONS.SERVERS_READ,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 120,
  },
  SERVER_REBOOT: {
    label: 'Reboot server',
    available: true,
    permission: PERMISSIONS.SERVERS_REBOOT,
    params: {},
    dangerous: true,
    retryable: false,
    timeoutSeconds: 60,
  },
  // Phase 7. The panel fills the parameters with the package it serves; the
  // agent downloads it, checks the hash, installs it and restarts itself.
  AGENT_UPDATE: {
    label: 'Update agent',
    available: true,
    internal: true,
    permission: PERMISSIONS.SERVERS_MANAGE,
    params: {
      version: { type: 'string', required: true, maxLength: 32, pattern: /^\d+\.\d+\.\d+$/, patternMessage: 'Must be a version such as 0.7.0' },
      sha256: { type: 'string', required: true, maxLength: 64, pattern: SHA256_PATTERN, patternMessage: 'Must be a SHA-256 hash' },
      size: { type: 'integer', required: true, min: 1, max: 50 * 1024 * 1024 },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 300,
  },
  // The AI assistant's free model on the panel's own server (Ollama). Queued
  // only by the assistant's settings (System > Assistant Settings), for the
  // panel's own server: the panel passes its own user id, the only one
  // (with root) that may reach the model.
  LOCAL_AI_INSTALL: {
    label: 'Install the assistant’s model',
    available: true,
    internal: true,
    permission: PERMISSIONS.SETTINGS_MANAGE,
    params: {
      model: { type: 'string', required: true, enum: LOCAL_AI_MODEL_IDS },
      panelUid: { type: 'integer', required: true, min: 0, max: 2 ** 31 - 2 },
    },
    dangerous: false,
    retryable: false,
    // Ollama and the model (several GB together) are downloaded.
    timeoutSeconds: 3600,
  },
  LOCAL_AI_REMOVE: {
    label: 'Remove the assistant’s model',
    available: true,
    internal: true,
    permission: PERMISSIONS.SETTINGS_MANAGE,
    params: { model: { type: 'string', required: true, enum: LOCAL_AI_MODEL_IDS } },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  LOCAL_AI_UNINSTALL: {
    label: 'Remove Ollama and its models',
    available: true,
    internal: true,
    permission: PERMISSIONS.SETTINGS_MANAGE,
    params: {},
    dangerous: true,
    retryable: false,
    timeoutSeconds: 300,
  },

  // ---- Web (phase 3) -------------------------------------------------------
  WEB_STACK_INSTALL: {
    label: 'Install web stack',
    available: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      components: {
        type: 'array',
        required: true,
        minItems: 1,
        maxItems: WEB_STACK_COMPONENT_KEYS.length,
        unique: true,
        items: { type: 'string', enum: WEB_STACK_COMPONENT_KEYS },
      },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1200,
  },
  PHP_VERSION_INSTALL: {
    label: 'Install PHP version',
    available: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: { version: { type: 'string', required: true, enum: PHP_VERSIONS } },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1200,
  },
  PHP_VERSION_REMOVE: {
    label: 'Remove PHP version',
    available: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: { version: { type: 'string', required: true, enum: PHP_VERSIONS } },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 600,
  },
  CREATE_SITE: {
    label: 'Create website',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: siteSpec,
    dangerous: false,
    retryable: false,
    timeoutSeconds: 300,
  },
  CREATE_NGINX_CONFIG: {
    label: 'Apply website configuration',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: siteSpec,
    dangerous: false,
    retryable: false,
    timeoutSeconds: 180,
  },
  DELETE_SITE: {
    label: 'Delete website',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      name: siteName,
      phpVersion: siteSpec.phpVersion,
      removeFiles: { type: 'boolean', default: false },
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 300,
  },
  ISSUE_SSL: {
    label: 'Issue SSL certificate',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      ...siteSpec,
      email: { type: 'string', required: true, maxLength: 254, pattern: EMAIL_PATTERN, patternMessage: 'Enter a valid email address' },
      staging: { type: 'boolean', default: false },
      verifyDns: { type: 'boolean', default: true },
      // Agents from SSL_RENEWAL_MIN_AGENT_VERSION: renew_before_expiry.
      renewBeforeDays,
      // Agents from SSL_UPLOAD_MIN_AGENT_VERSION: a certificate for the zone
      // and *.zone, checked through the zone this server serves.
      wildcardZone: { type: 'string', maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE },
      // Agents from DNS_PROVIDER_MIN_AGENT_VERSION: checked through the DNS
      // provider of the domain instead (with wildcardZone).
      dnsProvider,
    },
    redactParams: ['dnsProvider'],
    dangerous: false,
    retryable: false,
    // A provider's records can take minutes to reach its name servers.
    timeoutSeconds: 900,
  },
  INSTALL_SSL_CERT: {
    label: 'Install uploaded SSL certificate',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      ...siteSpec,
      certificate: { type: 'string', required: true, maxLength: MAX_CERT_PEM_LENGTH },
      privateKey: { type: 'string', required: true, maxLength: MAX_KEY_PEM_LENGTH },
    },
    redactParams: ['privateKey'],
    dangerous: false,
    retryable: false,
    timeoutSeconds: 180,
  },
  RENEW_SSL: {
    label: 'Renew SSL certificate',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: { name: siteName, force: { type: 'boolean', default: false }, renewBeforeDays },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 420,
  },
  SET_SSL_RENEWAL: {
    label: 'Set SSL renewal window',
    available: true,
    internal: true,
    permission: PERMISSIONS.SETTINGS_MANAGE,
    params: { renewBeforeDays: { ...renewBeforeDays, required: true } },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 120,
  },
  SITE_LOGS: {
    label: 'Read website logs',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.WEBSITES_LOGS,
    params: {
      name: siteName,
      log: { type: 'string', required: true, enum: FILE_LOG_KINDS },
      lines: { type: 'integer', min: 10, max: 2000, default: 200 },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  FILE_LIST: {
    label: 'List files',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.FILES_READ,
    params: { name: siteName, path: filePath() },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  FILE_READ: {
    label: 'Open file',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.FILES_READ,
    params: { name: siteName, path: filePath(true) },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  FILE_WRITE: {
    label: 'Save file',
    available: true,
    internal: true,
    redactParams: ['content'],
    permission: PERMISSIONS.FILES_WRITE,
    params: {
      name: siteName,
      path: filePath(true),
      // Base64 of at most MAX_FILE_BYTES bytes.
      content: { type: 'string', maxLength: Math.ceil(MAX_FILE_BYTES / 3) * 4 },
      encoding: { type: 'string', enum: ['utf8', 'base64'], default: 'utf8' },
      overwrite: { type: 'boolean', default: true },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  FILE_MKDIR: {
    label: 'Create folder',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: { name: siteName, path: filePath(true) },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 30,
  },
  FILE_RENAME: {
    label: 'Rename or move file',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: { name: siteName, from: filePath(true), to: filePath(true) },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 30,
  },
  FILE_UPLOAD: {
    label: 'Upload file',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: {
      name: siteName,
      path: filePath(true),
      // The agent fetches the file from the panel in pieces and checks it.
      uploadId: { type: 'string', required: true, maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be an upload id' },
      size: { type: 'integer', required: true, min: 0, max: MAX_UPLOAD_BYTES },
      sha256: { type: 'string', required: true, maxLength: 64, pattern: /^[0-9a-f]{64}$/, patternMessage: 'Must be a SHA-256 checksum' },
      overwrite: { type: 'boolean', default: false },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 3600,
  },
  FILE_DOWNLOAD: {
    label: 'Download file',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.FILES_READ,
    params: {
      name: siteName,
      path: filePath(true),
      // The agent sends the file to the panel in pieces for this download.
      downloadId: { type: 'string', required: true, maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be a download id' },
      maxBytes: { type: 'integer', min: 1, max: MAX_UPLOAD_BYTES },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 3600,
  },
  FILE_CHMOD: {
    label: 'Change permissions',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: {
      name: siteName,
      path: filePath(true),
      mode: { type: 'string', required: true, maxLength: 3, pattern: FILE_MODE_PATTERN, patternMessage: 'Must be three digits from 0 to 7, such as 755' },
      // Also everything inside a folder: folders get mode, files fileMode.
      recursive: { type: 'boolean', default: false },
      fileMode: { type: 'string', maxLength: 3, pattern: FILE_MODE_PATTERN, patternMessage: 'Must be three digits from 0 to 7, such as 644' },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 300,
  },
  FILE_EXTRACT: {
    label: 'Extract archive',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: {
      name: siteName,
      // A .zip, .tar.gz, .tgz or .tar file (ARCHIVE_FILE_PATTERN, checked by the panel and the agent).
      path: filePath(true),
      // A missing folder is created; empty is the home folder.
      to: filePath(),
      overwrite: { type: 'boolean', default: false },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  FILE_COMPRESS: {
    label: 'Compress to zip',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: {
      name: siteName,
      folder: filePath(),
      names: {
        type: 'array',
        required: true,
        minItems: 1,
        maxItems: MAX_COMPRESS_NAMES,
        unique: true,
        items: { type: 'string', maxLength: 255, pattern: FILE_NAME_PATTERN, patternMessage: 'Must be a name in the folder' },
      },
      // A .zip file that does not exist yet.
      to: filePath(true),
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  FILE_DELETE: {
    label: 'Delete file',
    available: true,
    internal: true,
    permission: PERMISSIONS.FILES_WRITE,
    params: { name: siteName, path: filePath(true) },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },

  // ---- Static websites deployed from Git -------------------------------------
  SITE_GIT_SETUP: {
    label: 'Set up Git deploy for a website',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: { name: siteName },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  DEPLOY_SITE_GIT: {
    label: 'Deploy website from Git',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      ...siteSpec,
      repository: { type: 'string', required: true, maxLength: MAX_REPOSITORY_URL_LENGTH, pattern: REPOSITORY_URL_PATTERN, patternMessage: REPOSITORY_URL_MESSAGE },
      branch: { type: 'string', required: true, maxLength: 200, pattern: BRANCH_PATTERN, patternMessage: BRANCH_MESSAGE },
      installCommand: commandText(),
      buildCommand: commandText(),
      outputDir: siteOutputDir,
      releaseId,
      keepReleases: { type: 'integer', min: 1, max: MAX_KEEP_RELEASES, default: 5 },
      // Variables for the install and build (agent 0.24.0; only sent when set).
      env: { ...appProcess.env, default: undefined },
    },
    redactParams: ['env'],
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  ROLLBACK_SITE_GIT: {
    label: 'Roll back website',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: { ...siteSpec, releaseId, outputDir: siteOutputDir },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 300,
  },

  // ---- Applications (phase 4) ---------------------------------------------
  CREATE_APPLICATION: {
    label: 'Set up application',
    available: true,
    internal: true,
    permission: PERMISSIONS.APPS_MANAGE,
    params: { name: appName, runtime: appProcess.runtime },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  DEPLOY_GIT: {
    label: 'Deploy from Git',
    available: true,
    internal: true,
    redactParams: ['env'],
    permission: PERMISSIONS.APPS_DEPLOY,
    params: {
      ...appProcess,
      repository: { type: 'string', required: true, maxLength: MAX_REPOSITORY_URL_LENGTH, pattern: REPOSITORY_URL_PATTERN, patternMessage: REPOSITORY_URL_MESSAGE },
      branch: { type: 'string', required: true, maxLength: 200, pattern: BRANCH_PATTERN, patternMessage: BRANCH_MESSAGE },
      installCommand: commandText(),
      buildCommand: commandText(),
      releaseId,
      keepReleases: { type: 'integer', min: 1, max: MAX_KEEP_RELEASES, default: 5 },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  ROLLBACK_APPLICATION: {
    label: 'Roll back application',
    available: true,
    internal: true,
    redactParams: ['env'],
    permission: PERMISSIONS.APPS_DEPLOY,
    params: { ...appProcess, releaseId },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 600,
  },
  CONFIGURE_APPLICATION: {
    label: 'Apply application settings',
    available: true,
    internal: true,
    redactParams: ['env'],
    permission: PERMISSIONS.APPS_MANAGE,
    params: { ...appProcess, restart: { type: 'boolean', default: true } },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 600,
  },
  START_APPLICATION: {
    label: 'Start application',
    available: true,
    internal: true,
    permission: PERMISSIONS.APPS_DEPLOY,
    params: { name: appName, port: appProcess.port, healthCheckSeconds: appProcess.healthCheckSeconds },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 360,
  },
  STOP_APPLICATION: {
    label: 'Stop application',
    available: true,
    internal: true,
    permission: PERMISSIONS.APPS_DEPLOY,
    params: { name: appName },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  RESTART_APPLICATION: {
    label: 'Restart application',
    available: true,
    internal: true,
    permission: PERMISSIONS.APPS_DEPLOY,
    params: { name: appName, port: appProcess.port, healthCheckSeconds: appProcess.healthCheckSeconds, zeroDowntime: appProcess.zeroDowntime },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 360,
  },
  DELETE_APPLICATION: {
    label: 'Delete application',
    available: true,
    internal: true,
    permission: PERMISSIONS.APPS_MANAGE,
    params: {
      name: appName,
      removeFiles: { type: 'boolean', default: false },
      // Also removes the NGINX site of the same name (the app's domains).
      removeSite: { type: 'boolean', default: false },
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 300,
  },
  APP_STATUS: {
    label: 'Read application status',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.APPS_READ,
    params: { name: appName },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  APP_LOGS: {
    label: 'Read application logs',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.APPS_LOGS,
    params: {
      name: appName,
      log: { type: 'string', required: true, enum: APP_LOG_KINDS },
      lines: { type: 'integer', min: 10, max: 2000, default: 200 },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },

  // ---- Databases (phase 4) ------------------------------------------------
  CREATE_DATABASE: {
    label: 'Create database',
    available: true,
    internal: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { name: databaseName },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  DELETE_DATABASE: {
    label: 'Delete database',
    available: true,
    internal: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { name: databaseName },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 300,
  },
  CREATE_DATABASE_USER: {
    label: 'Create database user',
    available: true,
    internal: true,
    redactParams: ['password'],
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { username: databaseUser, password: databasePassword(true), ...databaseGrants },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  UPDATE_DATABASE_USER: {
    label: 'Change database user',
    available: true,
    internal: true,
    redactParams: ['password'],
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { username: databaseUser, password: databasePassword(false), ...databaseGrants },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  DELETE_DATABASE_USER: {
    label: 'Delete database user',
    available: true,
    internal: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { username: databaseUser },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 60,
  },

  // The database interface. Reads and SQL run as an account limited to the
  // one database (read-only unless allowChanges); results are cleared after
  // an hour and the SQL text is dropped from the stored job.
  DATABASE_TABLES: {
    label: 'List tables',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: { name: databaseName },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 60,
  },
  DATABASE_TABLE_ROWS: {
    label: 'Browse table',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: {
      name: databaseName,
      table: databaseObject(true),
      page: { type: 'integer', min: 1, max: 1_000_000, default: 1 },
      pageSize: { type: 'integer', min: 1, max: 500, default: 50 },
      orderBy: databaseObject(false),
      order: { type: 'string', enum: ['asc', 'desc'], default: 'asc' },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 60,
  },
  DATABASE_QUERY: {
    label: 'Run SQL',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    redactParams: ['sql'],
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: {
      name: databaseName,
      sql: { type: 'string', required: true, maxLength: MAX_QUERY_LENGTH },
      allowChanges: { type: 'boolean', default: false },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 90,
  },

  // phpMyAdmin from the distribution's package, served by NGINX on its own
  // port (HTTPS with the panel domain's certificate when given).
  PHPMYADMIN_SETUP: {
    label: 'Set up phpMyAdmin',
    available: true,
    permission: PERMISSIONS.SERVERS_MANAGE,
    params: {
      port: { type: 'integer', min: 1024, max: 65535, default: 8081 },
      // The panel domain and its certificate, for HTTPS.
      domain: { type: 'string', maxLength: 253, pattern: DOMAIN_PATTERN, patternMessage: DOMAIN_MESSAGE },
      certName: { type: 'string', maxLength: 64, pattern: /^vp-[a-z0-9][a-z0-9-]{0,62}$/, patternMessage: 'Must be a VaultPanel certificate name' },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 900,
  },
  // One-click sign-in: leaves a two-minute, one-time ticket for the token
  // whose SHA-256 is given. Queued by the panel (databases.manage, the
  // database's owner), which keeps the token itself.
  PHPMYADMIN_SIGNON: {
    label: 'Open in phpMyAdmin',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.DATABASES_MANAGE,
    params: {
      name: databaseName,
      tokenHash: { type: 'string', required: true, pattern: /^[a-f0-9]{64}$/, patternMessage: 'Must be a SHA-256 in hex' },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  PHPMYADMIN_REMOVE: {
    label: 'Turn off phpMyAdmin',
    available: true,
    permission: PERMISSIONS.SERVERS_MANAGE,
    params: {},
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },

  // ---- App installer (agent 0.20.0) ----------------------------------------
  // Puts WordPress, Joomla, Drupal or Laravel in a website, with the database
  // the panel created for it. Queued by the panel from its own records.
  CMS_INSTALL: {
    label: 'Install app',
    available: true,
    internal: true,
    redactParams: ['databasePassword', 'adminPassword'],
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      app: { type: 'string', required: true, enum: CMS_APP_KEYS },
      site: siteName,
      phpVersion: { type: 'string', required: true, pattern: PHP_VERSION_PATTERN, patternMessage: 'Must be a PHP version such as 8.3' },
      directory: { type: 'string', required: true, maxLength: 300, pattern: CMS_DIRECTORY_PATTERN, patternMessage: 'Must be a folder inside the site' },
      url: { type: 'string', required: true, maxLength: 400, pattern: CMS_URL_PATTERN, patternMessage: 'Must be the address of the app' },
      databaseName: databaseName,
      databaseUser: databaseUser,
      databasePassword: databasePassword(true),
      title: { type: 'string', maxLength: 100, pattern: CMS_TITLE_PATTERN, patternMessage: 'At most 100 characters' },
      adminUser: { type: 'string', maxLength: 60, pattern: CMS_ADMIN_USER_PATTERN, patternMessage: CMS_ADMIN_USER_MESSAGE },
      adminEmail: { type: 'string', maxLength: 254, pattern: EMAIL_PATTERN, patternMessage: 'Must be an email address' },
      adminPassword: { type: 'string', maxLength: 128, pattern: CMS_ADMIN_PASSWORD_PATTERN, patternMessage: CMS_ADMIN_PASSWORD_MESSAGE },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  CMS_REMOVE: {
    label: 'Remove installed app',
    available: true,
    internal: true,
    permission: PERMISSIONS.WEBSITES_MANAGE,
    params: {
      site: siteName,
      directory: { type: 'string', required: true, maxLength: 300, pattern: CMS_DIRECTORY_PATTERN, patternMessage: 'Must be a folder inside the site' },
      // Emptied and kept (the site's document root) instead of removed.
      keepFolder: { type: 'boolean', default: false },
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 600,
  },

  // ---- DNS zones -----------------------------------------------------------
  // BIND as an authoritative name server (never a resolver for others).
  DNS_SETUP: {
    label: 'Set up the DNS server',
    available: true,
    permission: PERMISSIONS.DNS_MANAGE,
    params: {},
    dangerous: false,
    retryable: false,
    timeoutSeconds: 900,
  },
  // The whole zone, written from the panel's records each time.
  DNS_ZONE_APPLY: {
    label: 'Apply DNS zone',
    available: true,
    internal: true,
    permission: PERMISSIONS.DNS_MANAGE,
    params: {
      zone: dnsZone,
      serial: { type: 'integer', required: true, min: 1, max: 4_294_967_295 },
      ttl: { type: 'integer', required: true, min: DNS_TTL.min, max: DNS_TTL.max },
      email: { type: 'string', required: true, maxLength: 254, pattern: DNS_EMAIL_PATTERN, patternMessage: 'Must be an email address' },
      records: { type: 'array', required: true, minItems: 1, maxItems: MAX_DNS_RECORDS, items: dnsRecord },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 120,
  },
  DNS_ZONE_REMOVE: {
    label: 'Remove DNS zone',
    available: true,
    internal: true,
    permission: PERMISSIONS.DNS_MANAGE,
    params: { zone: dnsZone },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 120,
  },

  // ---- Email hosting ---------------------------------------------------------
  // Postfix, Dovecot and OpenDKIM, set up by the panel's mail service.
  MAIL_SETUP: {
    label: 'Set up the mail server',
    available: true,
    internal: true,
    permission: PERMISSIONS.MAIL_MANAGE,
    params: { hostname: mailHostname },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 900,
  },
  // Every domain, mailbox and forwarder on the server, written from the
  // panel's records each time. Mailboxes carry password hashes only.
  MAIL_APPLY: {
    label: 'Apply email settings',
    available: true,
    internal: true,
    permission: PERMISSIONS.MAIL_MANAGE,
    params: mailState,
    dangerous: false,
    retryable: true,
    timeoutSeconds: 180,
    redactParams: ['mailboxes'],
  },
  // How much mail each mailbox holds.
  MAIL_USAGE: {
    label: 'Check mailbox sizes',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.MAIL_READ,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 120,
  },

  // ---- Backups (phase 5) ---------------------------------------------------
  CREATE_BACKUP: {
    label: 'Back up',
    available: true,
    internal: true,
    permission: PERMISSIONS.BACKUPS_CREATE,
    // storage: also copy it there (agent 0.13.0 and later).
    params: { ...backupTarget, storage: backupStorage },
    redactParams: ['storage'],
    dangerous: false,
    retryable: false,
    timeoutSeconds: 3600,
  },
  RESTORE_BACKUP: {
    label: 'Restore backup',
    available: true,
    internal: true,
    permission: PERMISSIONS.BACKUPS_MANAGE,
    params: {
      ...backupTarget,
      sha256: { type: 'string', required: true, maxLength: 64, pattern: SHA256_PATTERN, patternMessage: 'Must be a SHA-256 checksum' },
      // A copy of the current state is made first, under this id.
      safetyBackupId: { type: 'string', maxLength: 36, pattern: BACKUP_ID_PATTERN, patternMessage: 'Must be a backup id' },
      // Apps: checked after the restore, as after a deployment.
      port: { type: 'integer', min: APP_PORT_MIN, max: APP_PORT_MAX },
      healthCheckSeconds: appProcess.healthCheckSeconds,
      // Where to fetch the backup from when it is not on the server.
      storage: backupStorage,
    },
    redactParams: ['storage'],
    dangerous: true,
    retryable: false,
    timeoutSeconds: 3600,
  },
  DELETE_BACKUP: {
    label: 'Delete backup',
    available: true,
    internal: true,
    permission: PERMISSIONS.BACKUPS_MANAGE,
    params: { ...backupTarget, storage: backupStorage },
    redactParams: ['storage'],
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  UPLOAD_BACKUP: {
    label: 'Prepare backup download',
    available: true,
    internal: true,
    permission: PERMISSIONS.BACKUPS_MANAGE,
    params: {
      ...backupTarget,
      sha256: { type: 'string', required: true, maxLength: 64, pattern: SHA256_PATTERN, patternMessage: 'Must be a SHA-256 checksum' },
      storage: backupStorage,
    },
    redactParams: ['storage'],
    dangerous: false,
    retryable: false,
    timeoutSeconds: 3600,
  },
  TEST_BACKUP_STORAGE: {
    label: 'Check backup storage',
    available: true,
    internal: true,
    permission: PERMISSIONS.SETTINGS_MANAGE,
    params: { storage: { ...backupStorage, required: true } },
    redactParams: ['storage'],
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },

  // ---- Cron jobs (phase 5) -------------------------------------------------
  CREATE_CRON: {
    label: 'Save cron job',
    available: true,
    internal: true,
    permission: PERMISSIONS.CRON_MANAGE,
    params: {
      id: cronId,
      user: siteName,
      schedule: { type: 'string', required: true, maxLength: 100, pattern: CRON_EXPRESSION_PATTERN, patternMessage: CRON_EXPRESSION_MESSAGE },
      commands: commandText(true),
      workingDir: { type: 'string', maxLength: 200, pattern: CRON_WORKING_DIR_PATTERN, patternMessage: CRON_WORKING_DIR_MESSAGE },
      timeoutSeconds: { type: 'integer', min: CRON_TIMEOUT_MIN, max: CRON_TIMEOUT_MAX, default: 3600 },
      enabled: { type: 'boolean', default: true },
      // Apps: also load the app's .env, as its process gets.
      appEnv: { type: 'boolean', default: false },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  DELETE_CRON: {
    label: 'Delete cron job',
    available: true,
    internal: true,
    permission: PERMISSIONS.CRON_MANAGE,
    params: { id: cronId },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 60,
  },
  RUN_CRON: {
    label: 'Run cron job now',
    available: true,
    internal: true,
    permission: PERMISSIONS.CRON_RUN,
    params: { id: cronId },
    dangerous: false,
    retryable: false,
    // A run started by hand stops after an hour, whatever the job's own limit.
    timeoutSeconds: 3660,
  },

  // ---- Logs (phase 5) --------------------------------------------------------
  SYSTEM_LOGS: {
    label: 'Read system logs',
    available: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.SERVERS_LOGS,
    params: {
      source: { type: 'string', required: true, enum: LOG_SOURCE_KEYS },
      priority: { type: 'string', enum: LOG_PRIORITY_KEYS, default: 'debug' },
      search: { type: 'string', maxLength: 200, pattern: LOG_SEARCH_PATTERN, patternMessage: 'Must be plain text' },
      sinceMinutes: { type: 'integer', min: 1, max: 60 * 24 * 31 },
      lines: { type: 'integer', min: 10, max: 2000, default: 300 },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 60,
  },

  // ---- Security (phase 6) --------------------------------------------------
  SECURITY_STATUS: {
    label: 'Read security status',
    available: true,
    routine: true,
    permission: PERMISSIONS.SECURITY_READ,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 90,
  },
  SECURITY_TOOLS_INSTALL: {
    label: 'Install security software',
    available: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      components: {
        type: 'array',
        required: true,
        minItems: 1,
        maxItems: SECURITY_TOOL_KEYS.length,
        unique: true,
        items: { type: 'string', enum: SECURITY_TOOL_KEYS },
      },
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1200,
  },
  FIREWALL_ENABLE: {
    label: 'Turn on firewall',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: { protectedPorts },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  FIREWALL_DISABLE: {
    label: 'Turn off firewall',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {},
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  FIREWALL_RULE_ADD: {
    label: 'Add firewall rule',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      ...firewallRule,
      comment: { type: 'string', maxLength: 60, pattern: FIREWALL_COMMENT_PATTERN, patternMessage: FIREWALL_COMMENT_MESSAGE },
      protectedPorts,
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  FIREWALL_RULE_DELETE: {
    label: 'Delete firewall rule',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      ...firewallRule,
      // Rules added for an application profile (such as OpenSSH) by hand.
      app: { type: 'string', maxLength: 64, pattern: /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/, patternMessage: 'Must be a UFW application name' },
      protectedPorts,
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  FIREWALL_DEFAULTS: {
    label: 'Change firewall default',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      incoming: { type: 'string', enum: FIREWALL_INCOMING_POLICY_KEYS },
      outgoing: { type: 'string', enum: FIREWALL_OUTGOING_POLICY_KEYS },
      protectedPorts,
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  SSH_CONFIGURE: {
    label: 'Change SSH settings',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      permitRootLogin: { type: 'string', required: true, enum: SSH_ROOT_LOGIN_KEYS },
      passwordAuthentication: { type: 'boolean', required: true },
      maxAuthTries: { type: 'integer', required: true, min: SSH_MAX_AUTH_TRIES_MIN, max: SSH_MAX_AUTH_TRIES_MAX },
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  SSH_KEY_ADD: {
    label: 'Add SSH key',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: { key: { type: 'string', required: true, maxLength: 16_200, pattern: SSH_PUBLIC_KEY_PATTERN, patternMessage: SSH_PUBLIC_KEY_MESSAGE }, user: sshUser },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  SSH_KEY_REMOVE: {
    label: 'Remove SSH key',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      fingerprint: { type: 'string', required: true, maxLength: 60, pattern: SSH_FINGERPRINT_PATTERN, patternMessage: 'Must be a SHA256 key fingerprint' },
      user: sshUser,
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 60,
  },
  // Agent 0.34.0: the ports SSH listens on (two while moving to a new one).
  SSH_PORTS_SET: {
    label: 'Change SSH port',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      ports: { type: 'array', required: true, minItems: 1, maxItems: SSH_MAX_PORTS, unique: true, items: { type: 'integer', min: 1, max: 65535, check: sshPortMessage } },
      protectedPorts,
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 180,
  },
  // Login message (agent 0.21.0): only the VaultPanel banner, or the system's own.
  LOGIN_BANNER_SET: {
    label: 'Change login message',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      vaultpanelOnly: { type: 'boolean', required: true },
      serverName: { type: 'string', maxLength: 100 },
      panelUrl: { type: 'string', maxLength: 300 },
    },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 60,
  },
  FAIL2BAN_CONFIGURE: {
    label: 'Change Fail2ban settings',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {
      enabled: { type: 'boolean', required: true },
      maxRetry: { type: 'integer', min: FAIL2BAN_LIMITS.maxRetry.min, max: FAIL2BAN_LIMITS.maxRetry.max, default: FAIL2BAN_LIMITS.maxRetry.default },
      findTimeMinutes: { type: 'integer', min: FAIL2BAN_LIMITS.findTimeMinutes.min, max: FAIL2BAN_LIMITS.findTimeMinutes.max, default: FAIL2BAN_LIMITS.findTimeMinutes.default },
      banTimeMinutes: { type: 'integer', min: FAIL2BAN_LIMITS.banTimeMinutes.min, max: FAIL2BAN_LIMITS.banTimeMinutes.max, default: FAIL2BAN_LIMITS.banTimeMinutes.default },
      ignoreIps: addressList(FAIL2BAN_MAX_IGNORE),
    },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  FAIL2BAN_UNBAN: {
    label: 'Unblock address',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: { ip: { type: 'string', required: true, maxLength: 45, check: (v) => (isAddressOrNetwork(v) && !v.includes('/') ? null : 'Must be an IP address') } },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  AUTO_UPDATES_CONFIGURE: {
    label: 'Change automatic updates',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: { enabled: { type: 'boolean', required: true } },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 60,
  },
  SECURITY_UPDATES_INSTALL: {
    label: 'Install security updates',
    available: true,
    internal: true,
    permission: PERMISSIONS.SECURITY_MANAGE,
    params: {},
    dangerous: true,
    retryable: false,
    timeoutSeconds: 3600,
  },

  // ---- Containers (phase 10) ----------------------------------------------
  // The agent talks to Docker through its API socket, never a shell.
  DOCKER_STATUS: {
    label: 'Read Docker status',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.CONTAINERS_READ,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  DOCKER_INSTALL: {
    label: 'Install or start Docker',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_MANAGE,
    params: {},
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1200,
  },
  CONTAINER_LIST: {
    label: 'List containers',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.CONTAINERS_READ,
    params: { protectedPorts: protectedHostPorts },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  CONTAINER_INSPECT: {
    label: 'Read container details',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.CONTAINERS_READ,
    params: { container: containerRef, protectedPorts: protectedHostPorts },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  CONTAINER_LOGS: {
    label: 'Read container logs',
    available: true,
    internal: true,
    routine: true,
    transientOutput: true,
    permission: PERMISSIONS.CONTAINERS_LOGS,
    params: { container: containerRef, lines: { type: 'integer', min: 10, max: 2000, default: 200 } },
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  CONTAINER_DEPLOY: {
    label: 'Deploy container',
    available: true,
    internal: true,
    redactParams: ['env'],
    permission: PERMISSIONS.CONTAINERS_MANAGE,
    params: { ...containerSpec, pull: { type: 'boolean', default: true } },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  CONTAINER_START: {
    label: 'Start container',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_OPERATE,
    params: { container: containerRef, protectedPorts: protectedHostPorts },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 120,
  },
  CONTAINER_STOP: {
    label: 'Stop container',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_OPERATE,
    params: { container: containerRef, protectedPorts: protectedHostPorts },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },
  CONTAINER_RESTART: {
    label: 'Restart container',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_OPERATE,
    params: { container: containerRef, protectedPorts: protectedHostPorts },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 180,
  },
  CONTAINER_REMOVE: {
    label: 'Remove container',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_MANAGE,
    params: {
      container: containerRef,
      // Containers VaultPanel deployed: removing one that is already gone succeeds.
      id: managedId,
      // Also delete its volumes (only those VaultPanel made for it).
      removeVolumes: { type: 'boolean', default: false },
      protectedPorts: protectedHostPorts,
    },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 180,
  },
  IMAGE_LIST: {
    label: 'List images',
    available: true,
    internal: true,
    routine: true,
    permission: PERMISSIONS.CONTAINERS_READ,
    params: {},
    dangerous: false,
    retryable: true,
    timeoutSeconds: 30,
  },
  IMAGE_PULL: {
    label: 'Pull image',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_MANAGE,
    params: { image: imageRef },
    dangerous: false,
    retryable: false,
    timeoutSeconds: 1800,
  },
  IMAGE_REMOVE: {
    label: 'Remove image',
    available: true,
    internal: true,
    permission: PERMISSIONS.CONTAINERS_MANAGE,
    params: { image: { type: 'string', required: true, maxLength: 71, pattern: IMAGE_ID_PATTERN, patternMessage: 'Must be an image ID' } },
    dangerous: true,
    retryable: false,
    timeoutSeconds: 120,
  },

  // Later parts of phase 10. Defined here so the job system, permissions and
  // UI can refer to them; they cannot be queued yet.
  PLUGIN_INSTALL: { label: 'Install plugin', available: false, phase: 10 },
});

export const OPERATION_TYPES = Object.freeze(Object.keys(OPERATIONS));

// What agents older than 0.2.0 support. They do not report their operations,
// so the panel assumes this list for them.
export const LEGACY_AGENT_OPERATIONS = Object.freeze(['SERVICE_STATUS', 'SERVICE_RESTART', 'PROCESS_LIST', 'SERVER_REBOOT']);

export const AVAILABLE_OPERATION_TYPES = Object.freeze(
  OPERATION_TYPES.filter((type) => OPERATIONS[type].available),
);

export const ROUTINE_OPERATION_TYPES = Object.freeze(OPERATION_TYPES.filter((type) => OPERATIONS[type].routine));

// The parameters of a job as they may be shown or stored for the long term:
// redacted fields are replaced by their size.
export function redactJobParams(type, params) {
  const fields = OPERATIONS[type]?.redactParams;
  if (!fields || !params || typeof params !== 'object') return params;
  const copy = { ...params };
  for (const field of fields) {
    if (typeof copy[field] === 'string') copy[field] = { redacted: true, length: copy[field].length };
    else if (Array.isArray(copy[field])) copy[field] = { redacted: true, count: copy[field].length };
    else if (copy[field] && typeof copy[field] === 'object') copy[field] = { redacted: true };
  }
  return copy;
}

export const JOB_STATUSES = Object.freeze([
  'queued', // waiting for the agent to pick it up
  'dispatched', // handed to the agent, not yet started
  'running',
  'succeeded',
  'failed',
  'timed_out',
  'cancelled',
]);

export const ACTIVE_JOB_STATUSES = Object.freeze(['queued', 'dispatched', 'running']);
export const FINAL_JOB_STATUSES = Object.freeze(['succeeded', 'failed', 'timed_out', 'cancelled']);

export const SERVER_STATUSES = Object.freeze(['pending', 'online', 'offline', 'disabled']);
