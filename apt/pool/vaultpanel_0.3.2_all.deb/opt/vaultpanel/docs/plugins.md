# Plugins

Phase 10, part 3. A plugin adds a feature to VaultPanel or connects it to an outside service (a
status page, a chat bot, an inventory, a billing or ticketing system) without changing the panel's
code.

A plugin is a **separate program**, run wherever its author likes: on the panel's server, on
another server or as a hosted service. It works with the panel in three ways, and only these:

1. It **calls the public REST API** with its own token (`vpp_…`), limited to the permissions an
   owner or admin approved when installing it.
2. It **receives panel events** (deployments, alerts, backups, servers going offline) at its
   `webhookUrl`, signed with its own secret.
3. It can **show a page inside the panel**, listed in the sidebar and opened with a signed link that
   tells the plugin who is looking.

A plugin never runs inside the panel's process, never adds agent operations and never runs commands
on a server itself. Anything it changes, it changes through the same API, permission checks, job
queue and audit log as a person using the panel.

## Installing

**Plugins** (in the sidebar) **→ Install plugin**, or pick one on the **Directory** tab (see
[Plugin directories](#plugin-directories)), then either the plugin's manifest URL (the panel fetches it)
or the manifest pasted as JSON. The panel shows what the plugin asks for in words: each permission
scope, the events, its page, and warnings (plain `http`, server operations, customer management).
Approving installs it and shows the plugin's **token** and **signing secret** once; give both to
the plugin. Only their SHA-256 (the token) and an encrypted copy (the secret) are kept.

Installing, updating and making new credentials need `plugins.manage` (owners and admins) and a
person signed in to the panel: they are refused for API tokens and for plugins. Listing, turning a
plugin on or off, removing it and its events also work with a `full` API token.

| On the plugin's page | Does |
| --- | --- |
| Turn off / on | Off: its token is refused (401), it receives no events and its page is hidden. On again restores it |
| Events | Every event sent to it, with the response; **Send test event**; **Send again** |
| Settings → Update | Reads the manifest URL again (or a pasted manifest), shows what changed and asks for approval again |
| Settings → Make new credentials | A new token and secret; the old ones stop working at once |
| Settings → Remove | Deletes the plugin, its token and its events. What it already did in the panel stays |

## The manifest

```json
{
  "manifestVersion": 1,
  "id": "status-board",
  "name": "Status Board",
  "version": "1.0.0",
  "description": "Every server at a glance, with the latest deployments and alerts.",
  "author": "Example Ltd",
  "homepage": "https://example.com/status-board",
  "permissions": ["read"],
  "events": ["server.offline", "server.online", "deployment.failed"],
  "webhookUrl": "https://status.example.com/events",
  "page": { "title": "Status board", "url": "https://status.example.com/", "icon": "activity" }
}
```

| Field | Rules |
| --- | --- |
| `manifestVersion` | `1` |
| `id` | 3 to 64 lowercase letters, digits and dashes, starting with a letter. Unique per panel; an update must keep it |
| `name`, `version` | Up to 100 and 32 characters |
| `description`, `author`, `homepage` | Optional |
| `permissions` | Scopes, as for API tokens: `read`, `logs`, `deploy`, `manage`, `servers`, `customers`. Not `full`: a plugin can never manage users, roles, panel settings or plugins |
| `events` | Any of the events below. Needs `webhookUrl` |
| `webhookUrl` | Where events are POSTed |
| `page` | Optional. `title` (up to 60), `url`, `icon` (one of `plug`, `activity`, `gauge`, `bell`, `server`, `globe`, `app`, `database`, `shield`, `card`, `briefcase`, `users`, `logs`, `zap`, `sparkles`, `package`, `layers`, `containers`, `automation`) |

Unknown fields are refused, so a misspelt permission is an error rather than silently ignored. A
manifest fetched by URL may be up to 64 KB.

The scopes are defined in `shared/src/tokens.js`; what each covers is listed in
[api.md](api.md#api-tokens). Each event needs a permission its scopes include, so a plugin never
hears about something it could not read through the API:

| Events | Need |
| --- | --- |
| `server.offline`, `server.online` | `servers.read` |
| `alert.firing`, `alert.resolved` | `alerts.read` |
| `deployment.succeeded`, `deployment.failed` | `applications.read` |
| `backup.succeeded`, `backup.failed`, `restore.succeeded`, `restore.failed` | `backups.read` |
| `cron.failed` | `cron.read` |
| `ssl.expiring`, `ssl.expired`, `ssl.renew_failed` | `websites.read` |

All of them are covered by `read`.

## Calling the API

Send the token as a Bearer token, exactly like an API token:

```js
import { VaultPanel } from '@vaultpanel/sdk';

const panel = new VaultPanel({ baseUrl: 'https://panel.example.com', token: process.env.VAULTPANEL_PLUGIN_TOKEN });
const { items } = await panel.servers.list();
```

`GET /auth/me` returns `{ user: null, plugin: { id, slug, name, scopes }, permissions }`. Every
call is audited with the actor `plugin:<id>`; a refused call is audited as `authz.denied`. A plugin
cannot use the rest of `/auth`, create API tokens, or read or change plugins. Jobs it starts show
as queued by `plugin:<id>`.

## Receiving events

Each event is a `POST` to `webhookUrl` with a JSON body:

```json
{ "id": "delivery id", "event": "server.offline", "occurredAt": "2026-10-05T18:00:00.000Z", "data": { "server": { "id": "…", "name": "web-1" } } }
```

and these headers:

| Header | Value |
| --- | --- |
| `X-VaultPanel-Event` | The event |
| `X-VaultPanel-Delivery` | The delivery id (the same on every retry) |
| `X-VaultPanel-Timestamp` | Unix seconds |
| `X-VaultPanel-Signature` | `sha256=` + HMAC-SHA256 of `<timestamp>.<raw body>` with the signing secret |
| `X-VaultPanel-Plugin` | The plugin's id |

Answer with any 2xx. Anything else (or no answer within 10 seconds) is tried again after 1, 5 and
30 minutes. **Send test event** sends `webhook.test`. Check the signature before trusting an event:

```js
import { verifyEvent } from '@vaultpanel/sdk';

const event = verifyEvent({ body: rawBody, headers: req.headers, secret: process.env.VAULTPANEL_PLUGIN_SECRET });
if (!event) return res.writeHead(401).end();
```

`verifyEvent` refuses a timestamp more than 5 minutes away, so a captured request cannot be
replayed later.

## The page in the panel

A plugin's page is listed in the sidebar under **Plugins** for people who may do **everything the
plugin may do** (in practice, a plugin with `read` shows to owners and admins), so nobody gains
anything by going through a plugin's page. Hosting customers never see plugin pages.

The panel shows the page in a sandboxed frame at `/plugin-pages/<id>`, and opens it with these
query parameters added to the page URL:

| Parameter | Value |
| --- | --- |
| `vp_plugin` | The plugin's id |
| `vp_user`, `vp_email`, `vp_roles` | Who is looking (roles comma-separated) |
| `vp_panel` | The panel's public URL |
| `vp_theme` | `light` or `dark`, to match the panel |
| `vp_ts` | Unix seconds |
| `vp_sig` | HMAC-SHA256, with the signing secret, of every `vp_` parameter but `vp_sig`, sorted by name, as `key=value` joined by `&` |

```js
import { verifyLaunch } from '@vaultpanel/sdk';

const viewer = verifyLaunch(req.url, process.env.VAULTPANEL_PLUGIN_SECRET);
if (!viewer) return res.writeHead(403).end('Open this page from VaultPanel');
// viewer: { plugin, user: { id, email, roles }, panelUrl, theme, issuedAt }
```

A link is good for 5 minutes; a page that stays open should start its own session once it has
checked the link (the example below does). The frame may run scripts, forms, pop-ups and downloads.
A page on the panel's own address is shown without same-origin access, so it cannot reach the
panel's session; host plugin pages on their own address.

## Addresses

The panel fetches manifests and sends events only to public addresses, and to private networks
while `VAULTPANEL_WEBHOOK_ALLOW_PRIVATE` is on (the default). Loopback (`127.0.0.1`) is refused
unless `VAULTPANEL_PLUGIN_ALLOW_LOCAL=true`, which lets a plugin on the panel's own server use it.
Link-local and cloud metadata addresses are always refused. The address is checked after DNS
resolution and the request goes to that same address.

The page URL is opened by people's browsers, so it must be an address they can reach (on a VPS,
usually its public IP or a domain).

## Example: Status Board

`examples/status-board-plugin/server.js` is a complete plugin with no dependencies beyond the SDK: it
serves its manifest, checks and keeps the latest events, and shows every server's state and those
events on its page. Run it from the repository root:

```sh
PLUGIN_PUBLIC_URL=http://YOUR_SERVER_IP:4100 node examples/status-board-plugin/server.js
```

Install it with the manifest URL it prints, then restart it with the credentials:

```sh
VAULTPANEL_PLUGIN_TOKEN=vpp_… VAULTPANEL_PLUGIN_SECRET=whsec_… \
PLUGIN_PUBLIC_URL=http://YOUR_SERVER_IP:4100 node examples/status-board-plugin/server.js
```

It calls the panel at `VAULTPANEL_URL` (default `http://127.0.0.1:4000`, the backend on the same
server) and listens on `PORT` (default 4100). When the panel cannot reach the plugin at its public
address, set `PLUGIN_EVENTS_URL=http://127.0.0.1:4100` (the manifest and events then use it, while
the page keeps the public address) and `VAULTPANEL_PLUGIN_ALLOW_LOCAL=true` in the panel's `.env`.

## Plugin directories

A directory is a list of plugins, published as JSON at a URL by whoever maintains it: a plugin
author, a hosting company, a team. **Plugins → Directory → Add directory** takes its URL. The panel
reads it at once (nothing is saved if it cannot), then again every 12 hours, and keeps the last good
copy, so its plugins stay listed while it is unreachable. Up to 10 directories. No directory is
built in.

The Directory tab lists every directory's plugins with search and categories. **Install** on a
hosted plugin reads its manifest URL and opens the usual review; for a plugin you run yourself it
links to how to run it and asks for the manifest URL of your copy. A directory only suggests: what
is approved is always the plugin's own manifest, and the review warns when that asks for more
permissions or events than the directory listed. When a directory lists a newer version of an
installed plugin, the plugin shows "available" on the Installed tab and its page; **Settings →
Update** reads the plugin's own manifest URL again and asks for approval again as usual. Removing a
directory leaves the plugins installed from it installed.

```json
{
  "directoryVersion": 1,
  "name": "Example Ltd plugins",
  "description": "Plugins we maintain for our customers.",
  "homepage": "https://example.com/plugins",
  "plugins": [
    {
      "id": "status-board",
      "name": "Status Board",
      "version": "1.1.0",
      "description": "Every server at a glance.",
      "author": "Example Ltd",
      "hosting": "hosted",
      "manifestUrl": "https://status.example.com/manifest.json",
      "permissions": ["read"],
      "events": ["server.offline", "server.online"],
      "icon": "activity",
      "categories": ["monitoring"]
    },
    {
      "id": "ticket-bridge",
      "name": "Ticket Bridge",
      "version": "0.3.0",
      "hosting": "self-hosted",
      "setupUrl": "https://example.com/plugins/ticket-bridge#run-it",
      "permissions": ["read", "logs"]
    }
  ]
}
```

| Field | Rules |
| --- | --- |
| `directoryVersion` | `1` |
| `name` | Up to 100 characters. `description` and `homepage` are optional |
| `plugins` | Up to 500 entries |
| `plugins[].id`, `name`, `version` | As in the manifest. One entry per `id`; a repeat is left out |
| `plugins[].hosting` | `hosted` (its author runs it; needs `manifestUrl`) or `self-hosted` (you run it; needs `setupUrl` or `homepage`). Default `hosted` |
| `plugins[].permissions`, `events` | What it asks for, as in its manifest, to help choose |
| `plugins[].icon` | One of the page icons above. Default `plug` |
| `plugins[].categories` | Up to 5 short words |
| `description`, `author`, `homepage`, `setupUrl` | Optional |

The file may be up to 1 MB and is fetched with the same address rules as manifests. An entry that
breaks these rules is left out and shown, with the reason, under its directory; the rest are
listed. Other fields are ignored, so newer directories still work. The example plugin serves a
directory listing itself at `/directory.json`.

## API

All under `/api/v1/plugins`, with `plugins.manage` unless noted.

| Method | Path | Does |
| --- | --- | --- |
| GET | `/plugins` | Installed plugins (`{ items, max }`), never their credentials |
| GET | `/plugins/pages` | Any signed-in person: the plugin pages they may open (for the sidebar) |
| POST | `/plugins/preview` `{ manifestUrl \| manifest }` | Checks a manifest and explains it: `{ manifest, manifestUrl, review: { scopes, permissions, notGranted, events, eventsNotCovered, warnings }, installed }` |
| POST | `/plugins` `{ manifestUrl \| manifest, approvedPermissions }` | Installs it. `approvedPermissions` must equal the manifest's `permissions`. Returns `{ plugin, credentials: { token, signingSecret } }`, the only time they are shown. In the panel only |
| GET | `/plugins/:id` | `{ plugin, manifest, review }` |
| PUT | `/plugins/:id/manifest` `{ manifestUrl? \| manifest?, approvedPermissions }` | Updates it; with neither, fetches its manifest URL again. Same `id` required. In the panel only |
| POST | `/plugins/:id/enable`, `/plugins/:id/disable` | Turns it on or off |
| POST | `/plugins/:id/rotate-credentials` | New token and secret. In the panel only |
| DELETE | `/plugins/:id` | Removes it |
| GET | `/plugins/:id/deliveries?status=&page=` | Events sent to it |
| POST | `/plugins/:id/test`, `/plugins/:id/deliveries/:deliveryId/redeliver` | Sends a test event now, or one again |
| GET | `/plugins/:id/launch?theme=` | Any signed-in person who may see its page: `{ plugin, url, origin }` with the signed link |
| GET | `/plugins/directory` | `{ directories, items, categories, max }`: each item is a directory entry with `directory`, `installed` (`{ id, version, enabled }` or null) and `updateAvailable` |
| POST | `/plugins/directory/sources` `{ url }` | Reads and adds a directory. In the panel only |
| POST | `/plugins/directory/sources/:directoryId/refresh` | Reads it again (422 with the reason when it cannot; the last good copy stays) |
| POST | `/plugins/directory/refresh` | Reads every directory again; answers like `GET /plugins/directory` |
| DELETE | `/plugins/directory/sources/:directoryId` | Removes it. Plugins installed from it stay |

`GET /plugins` and `GET /plugins/:id` add `update` (`{ version, directory }` when a directory lists a
newer version, else null), and `POST /plugins/preview` adds `listedIn` (each directory entry for the
same `id`, with `extraPermissions` and `extraEvents` the manifest asks for beyond it).

Errors: 422 `VALIDATION_ERROR` with fields under `manifest.` (the manifest), `directory.` (a
directory) or `approvedPermissions`; 422 `MANIFEST_UNREACHABLE`, `DIRECTORY_UNREACHABLE`; 409
`DIRECTORY_ADDED`, `TOO_MANY_DIRECTORIES` (up to 10); 409 `PLUGIN_INSTALLED` (same `id`),
`TOO_MANY_PLUGINS` (up to 50), `NO_EVENTS`, `PLUGIN_DISABLED`; 403 when installing with a token or
approving permissions your account lacks. A plugin's events webhook does not appear on the
Webhooks page, and changing it there answers 409 `PLUGIN_WEBHOOK`.
