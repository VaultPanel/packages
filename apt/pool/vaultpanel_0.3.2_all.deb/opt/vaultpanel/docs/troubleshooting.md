# Troubleshooting

**The API exits with "Invalid configuration".** A required variable is missing or malformed; the
message lists which. `VAULTPANEL_SECRET_KEY` must decode to 32 bytes (`openssl rand -hex 32`).

**Setup says the token is invalid.** Use the token from the most recent API start log line
"No accounts exist yet…". It changes on every restart unless `VAULTPANEL_SETUP_TOKEN` is set.

**The browser warns that the connection is not private.** The panel uses its own self-signed
certificate on its port (install.sh does this so it is never plain HTTP). Check that the SHA-256
fingerprint the browser shows matches `sudo vaultpanel https`, then continue. For a certificate
browsers trust, give the panel a domain (**System > Panel Domain**).

**The panel does not start after an update: "Cannot read the panel's TLS certificate or key".** The
files named by `VAULTPANEL_TLS_CERT` and `VAULTPANEL_TLS_KEY` are missing or not readable by the
`vaultpanel` group. `sudo vaultpanel https on` makes a new certificate and fixes the permissions
(agents on other servers then need their upgrade command, which it prints).

**"port 8091 (the panel's loopback port) is already in use".** Set another port in
`/opt/vaultpanel/.env` (`VAULTPANEL_LOOPBACK_PORT=8095`) and run the installer again
(`sudo vaultpanel update --force`).

**Agents on other servers went Offline after `vaultpanel https on` or `https renew`.** They still talk
plain HTTP, or trust the old certificate. Run the command `vaultpanel https on` (or `renew`) printed
on each of them; `sudo vaultpanel https` shows the pin again. It keeps their registration.

**An agent install stops with "does not match the pin in the install command".** The panel answering
at that address does not have the certificate the command was made for: the certificate was
replaced, or something between the servers intercepts the connection. Copy a new install command
from the panel and check the address.

**The panel cannot write a file ("EACCES" or "read-only file system" in `vaultpanel logs`).** The panel
runs as the `vaultpanel` user and may only write to `VAULTPANEL_DATA_DIR` (`/var/lib/vaultpanel/panel`).
Running the installer again (`sudo vaultpanel update --force`) puts the ownership right; a
`VAULTPANEL_DATA_DIR` set by hand elsewhere must belong to `vaultpanel`.

**`vaultpanel backup` says the MariaDB container is not running.** Start it with `sudo vaultpanel
start`. Backups need the panel's database from install.sh; a panel on your own database server is
backed up with your own database backups (plus `.env` and `/etc/vaultpanel/tls`).

**`vaultpanel restore` fails at "the database update failed".** The backup comes from a newer
VaultPanel than the one installed. Install that version first (`sudo vaultpanel update --version
<version>`; the backup's version is printed at the start), then restore again.

**`vaultpanel rollback` says no earlier version is recorded.** Rollback goes back one
`vaultpanel update`. To go to any release: `sudo vaultpanel update --version vX.Y.Z` (then restore a
backup from that time if the database changed in between).

**The panel's own server does not show up.** Look for lines starting with `[vaultpanel]` where the
API starts; they say why. Common ones: "Run npm run db:migrate", "Start the panel as root once, or
run: sudo npm run connect-local", "connected to another panel" (add `-- --force` to take it over)
and "removed from the panel" (same). `VAULTPANEL_LOCAL_AGENT=false` turns it off.

**A server stays "Waiting for agent".** Check the install command output on the server. Tokens are
single use and expire (60 minutes by default); create a new one under the server's Settings tab.
"Agents must connect over HTTPS" means the panel URL is plain HTTP.

**A server shows Offline.** The agent has not reported for 90 seconds. On the server:
`systemctl status vaultpanel-agent` and `journalctl -u vaultpanel-agent`. `CLOCK_SKEW` errors mean the
server clock is off by more than 5 minutes; enable NTP. `AGENT_REVOKED` means the server was removed
or re-registered; run the install command again with a new token.

**A job failed with AGENT_UNREACHABLE.** The agent did not pick the job up within 5 minutes.
**NOT_ALLOWED** means the agent's `allowedServices` or `allowReboot` setting refuses it; edit
`/etc/vaultpanel-agent/config.json` and restart the agent. **TIMEOUT** means the command did not finish
in time; the job page shows the output collected so far.

**A job failed with AGENT_OUTDATED.** The server's agent predates that operation. Run the upgrade
command shown on the server's page; it keeps the agent's registration.

**PROCESS_CHANGED** means the process exited and its pid was reused before the job ran. Refresh the
process list and try again.

**An alert never fires.** A metric must stay over the threshold for the rule's whole duration, and
the server must be online with fresh telemetry; while it is offline only the "server offline" rule
is evaluated. Rules are checked every 15 seconds by the worker, so `npm run worker` must be running.

**A website stays "Failed".** Its page shows the agent's message and a link to the log. Common
causes: `NGINX_NOT_INSTALLED` or `PHP_NOT_INSTALLED` (install them from the server's Websites tab,
Web stack card); `NGINX_CONFIG_INVALID` (NGINX refused the new configuration, often because another
site or a hand-edited file is broken; run `nginx -t` on the server); `SITE_USER_CONFLICT` (a Linux user
with the site's name already exists for something else; pick another site name). Fix the cause and
use **Try again**.

**The site is created but "Not answering".** For a reverse proxy, start your app on the port shown;
NGINX answers 502 until something listens there. For PHP, check the PHP-FPM service on the server's
Services tab.

**Certificate requests fail with DOMAIN_NOT_REACHABLE.** Let's Encrypt was not asked: the agent could
not fetch a test file through the domain. Check on the Domains tab that each domain points at this
server and that port 80 is open (`ufw allow 80,443/tcp`). Use the staging option while testing to avoid Let's Encrypt's
rate limits (5 failures per hour per domain).

**Certificate requests fail with ACME_NOT_SERVED.** This server's own NGINX could not serve the
Let's Encrypt check file (often HTTP 403). Agents before 0.12.1 could leave `/var/lib/vaultpanel`
closed (0700) when a cron job ran before the first certificate, so NGINX could not reach
`/var/lib/vaultpanel/acme`; update the agent and issue again (it opens the folder for traversal), or
run `chmod 711 /var/lib/vaultpanel`. Otherwise run `nginx -t` and read `/var/log/nginx/error.log`.

**The file manager says OUTSIDE_SITE.** The path goes through a symbolic link to somewhere outside the
site's folder. The file manager never follows such links; use SFTP as the server owner instead.

**The file manager fails with "Cannot find module '/opt/vaultpanel-agent/src/services/fileWorker.js'".**
The file worker runs as the site's user, which cannot read the agent's folder. On the panel's own
server, agents installed by the panel before 0.37.0 were left readable by root only (the panel's
`UMask=0077` reached the agent installer). Fix it with `sudo chmod -R u=rwX,go=rX /opt/vaultpanel-agent`.
A panel from agent 0.37.0 also installs its own server's agent again when it starts and finds it that
way. If **Security** then says the agent runs as
root because it could not start as its own user, let it try again:
`sudo rm /var/lib/vaultpanel/agent-mode.json && sudo systemctl restart vaultpanel-agent`.

**The server's Self-check card shows a failed check** (agent 0.39.0; the **Server self-check
failed** alert fires for the ones marked as failed after 10 minutes). Each says what to run; in short:

- **Root helper** does not answer: see HELPER_UNAVAILABLE below.
- **Agent files** only root can read: `sudo chmod -R u=rwX,go=rX /opt/vaultpanel-agent` (or `sudo
  chmod o+x` on the folder above it that the check names). Until then the file manager fails as in
  the entry above.
- **File manager**: its worker did not start as a site user; the message is the worker's own. After
  fixing the agent files, **Check now** should pass.
- **NGINX configuration** or **Apache configuration**: `sudo nginx -t` (or `sudo apache2ctl -t`) shows
  the file and line. NGINX keeps serving with the configuration it loaded, but every website change
  is refused until the test passes, and NGINX would not start after a restart. A file VaultPanel
  wrote (`vp-<site>.conf`) is rewritten by saving the website's settings again.
- **Certificate renewal** (a warning): `sudo systemctl enable --now certbot.timer`, or issue or renew
  a certificate from the panel, which turns the timer back on. The panel renews due certificates
  itself in any case, a day into their renewal window.
- **Clock** (a warning): `sudo timedatectl set-ntp true`.
- **Failed services** (a warning): `systemctl --failed`, then `journalctl -u <unit>` for each.

**WEBSITE_BUSY** means another change to the same website is still running. Wait for it (the website
page shows it) and try again.

**An app stays "Failed".** The Deployments tab shows which stage failed and its log. `fetch` (`CLONE_FAILED`): the
repository URL or branch is wrong, or a private repository needs the app's deploy key added to the
repository (Settings tab). `install` or `build`: run the same command in the repository locally.
`start` with `HEALTH_CHECK_FAILED`: the app did not listen on its port in time; it must listen on
`process.env.PORT` (Node.js) or `$PORT` (Python), and the previous release keeps running. Use
**Deploy** again once fixed.

**Installing PM2 fails with EROFS (read-only file system).** Agents before 0.5.1 let npm use
`/root/.npm`, which the agent's service keeps read-only. Update the agent (restart the panel for its
own server, or run the upgrade command on the server page) and install again. **NODE_IN_HOME_FOLDER**
means the only Node.js on the server lives under `/root` or `/home` (for example through nvm), which
app users cannot read and the agent cannot write to. Install Node.js system-wide:
`curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt-get install -y nodejs`.
From agent 0.5.2 the agent then uses it for apps and PM2 without being reinstalled.

**SOFTWARE_MISSING** when creating an app or database means Git, PM2, Python or MariaDB is not
installed. Install it from the server's Software card. **AGENT_OUTDATED** means the agent is older
than 0.4.0; run the upgrade command on the server page.

**The app runs but its domain shows 502.** The linked website points NGINX at the app's port. If you
changed the port, use **Apply** on the app so the app and NGINX move together.

**A command field says it uses shell syntax.** Install, build and start commands run without a
shell, so `&&`, `|`, `;` and `>` are refused. Put the steps on separate lines, or in a script in your
repository. `CONFIGURE_FAILED` saying a program is not installed means the start command's program
(for example `gunicorn`) is not in the app's dependencies.

**`connect ECONNREFUSED 127.0.0.1:3307`** from `npm run db:migrate` or the backend: the panel's own
MariaDB is not running. If it runs in Docker, bring the containers up with
`docker compose -f docker/compose.yml up -d`, wait until `docker compose -f docker/compose.yml ps`
shows MariaDB healthy, then migrate and restart the backend. The containers restart on their own
after a reboot as long as Docker itself starts at boot: `systemctl enable docker` for Docker's own
packages, or `snap services docker` for the snap. If `docker` is not installed at all, point
`DATABASE_URL` at a MariaDB you run yourself instead.

**DATABASE_PORT_IN_USE**: MariaDB on the server cannot start because something else holds port
3306, usually the panel's own development MariaDB in Docker from an older `docker/compose.yml`.
Pull the latest code, set `DATABASE_URL` in `.env` to port 3307, run
`docker compose -f docker/compose.yml up -d`, restart the backend and worker, then try again. The
agent starts MariaDB itself when it finds it stopped.

**DATABASE_SERVER_NOT_INSTALLED** or **DATABASE_SERVER_DOWN**: install MariaDB from the Software
card, or start the `mariadb` service on the Services tab. If root cannot sign in over the socket,
set `mysqlDefaultsFile` in the agent config.

**APPLICATION_BUSY** from a webhook means a deployment is already running; the next push deploys.

**BACKUP_DISK_FULL**: less than 512 MB is free where backups are kept (`/var/backups/vaultpanel`).
Delete old backups, lower a schedule's "keep" count, or change `backupMinFreeBytes` in the agent
config. **BACKUP_CORRUPT** means the file on the server no longer matches the checksum taken when it
was made, so it is not restored; use another backup. A backup shown as **Missing** was removed from
the server by hand.

**BACKUP_TOO_LARGE** on a download: the backup is bigger than `VAULTPANEL_BACKUP_DOWNLOAD_MAX_MB`
(10 GB by default). Copy it from the server with `scp` instead.

**A restored app does not start.** The files are back but the health check failed; the restore
fails with `HEALTH_CHECK_FAILED`. Restore the safety copy taken just before, or deploy again.

**A cron job shows "Cron is not installed".** Install Cron from the Scheduler card on the server's
Automation tab, then save the job again. A job with no runs: check the schedule's next run on the
Cron Jobs page is in the server's time zone (shown in the form).

**A webhook delivery says "which webhooks may not reach".** Webhooks never call the panel's own
machine, link-local or cloud metadata addresses. Private network addresses (10.x, 192.168.x) are
allowed unless `VAULTPANEL_WEBHOOK_ALLOW_PRIVATE=false`.

**AGENT_OUTDATED** on Backups, Cron Jobs or Logs means the agent is older than 0.5.0; run the upgrade
command on the server page.

**LOCKOUT_REFUSED** is VaultPanel protecting your way in: a firewall rule that would block SSH, the
panel or your own address, or an SSH change that would leave no administrator able to sign in. Add
the replacement first (another rule for the port, or your SSH key), then try again.

**Locked out of SSH anyway** (for example by a rule added with `ufw` by hand): use your provider's
web console (Contabo: VNC in the customer panel), then `ufw allow 22/tcp` or `ufw disable`; for SSH
settings remove `/etc/ssh/sshd_config.d/00-vaultpanel.conf` and run `systemctl reload ssh`.

**The panel stopped loading after turning on the firewall**: VaultPanel opens the port in
`VAULTPANEL_PUBLIC_URL` on the panel's own server. If you open the panel on a different port (or the
backend's 4000 directly), add a rule for it, or fix `VAULTPANEL_PUBLIC_URL`.

**A server went Offline after setting outgoing connections to Deny.** The agent keeps the panel's
address reachable, but resolves it once, when the default changes. If the panel's IP address
changed since, add an outgoing allow rule for the new address and port from the server's console
(`ufw allow out to <panel IP> port <port> proto tcp`), or `ufw default allow outgoing`. Programs
that reach other services (a remote database, an API on another port) need their own outgoing
allow rules.

**After changing the SSH port you cannot connect.** Use `ssh -p <port>`. A firewall at your hosting
provider (security groups, Contabo's firewall) may need the port opened too. Keep the old port open
in VaultPanel until you have signed in on the new one. **PORT_IN_USE**: another program listens on
that port; pick another. **SSH_NOT_LISTENING**: SSH did not answer on the new port, so the old
setting came back; `journalctl -u ssh` says why (SELinux or AppArmor rules for `sshd` can refuse
other ports). **SSHD_OVERRIDDEN**: a `Port` line elsewhere in `/etc/ssh/sshd_config` or its
`sshd_config.d` folder wins; remove it, then try again.

**"Agent privileges: The agent runs as root"** in the security checks: the reason follows. "did not
reach the panel as the vaultpanel-agent user" means the move to its own user was undone after 10
minutes; `journalctl -u vaultpanel-agent -u vaultpanel-agent-helper` shows why (often a firewall or
proxy setting that only root had). Fix it, then `rm /var/lib/vaultpanel/agent-mode.json && systemctl
restart vaultpanel-agent`. "runs from ..." means the agent was not installed by the install script
(a development checkout); that one stays as it was started.

**HELPER_UNAVAILABLE**: the agent runs as its own user but its root helper is not answering.
`systemctl status vaultpanel-agent-helper` and `journalctl -u vaultpanel-agent-helper`; `systemctl
restart vaultpanel-agent-helper` starts it again. To go back to one root service, add `"runAsRoot":
true` to `/etc/vaultpanel-agent/config.json` and restart the helper.

**IP_NOT_ALLOWED / "The panel does not accept your address".** Panel access by address is on and
your address is not on the list. From an allowed address, add yours (Security > Authentication).
Locked out completely: on the panel's server set `VAULTPANEL_PANEL_ACCESS=off` in `.env`, restart
the backend, fix the list, then remove the line and restart again. Behind a reverse proxy (or
Cloudflare) everyone appears with the proxy's address unless `VAULTPANEL_TRUST_PROXY` is set.

**JAIL_FAILED** from Fail2ban: the SSH jail did not start. Usually `python3-systemd` is missing
(`apt install python3-systemd`), then save again. `/var/log/fail2ban.log` has the details.

**SSHD_OVERRIDDEN**: a line in `/etc/ssh/sshd_config` above its `Include /etc/ssh/sshd_config.d/*.conf`
line sets the same option, and sshd uses the first value it reads. Remove or comment out that line
and save again. VaultPanel's file is `00-vaultpanel.conf`, read before other drop-ins such as
`50-cloud-init.conf`. **SSHD_CONFIG_INVALID** shows what `sshd -t` said; the previous settings stay.

**KEYS_NOT_WRITABLE**: the agent's service cannot write `/root/.ssh`. Update the agent (0.6.0 adds
`ReadWritePaths=-/root/.ssh` to its unit).

**"Set up two-factor sign-in" on every page**: an owner required it for your role. Set it up, or ask
an owner to change the policy under Security, Authentication. Lost your phone and recovery codes:
an owner or admin can turn it off for you (Users, Edit). Locked-out owners can use the command from
the testing guide's "Locked out" section.

**AGENT_OUTDATED** on the Security pages: the agent is older than 0.6.0; update it.

**Any error in the UI** shows a request id. Search the API log for it.

**The assistant keeps "thinking" and never answers.** Answers are written by the worker, so
`npm run dev:worker` (or `npm run worker -w @vaultpanel/backend`) must be running. After 10 minutes the
question is marked failed and **Try again** appears.

**The assistant says the provider rejected the key, or the model was not found.** Open **Assistant
Settings** and use **Test connection**. For Ollama and similar services choose the OpenAI-compatible
provider, give the address ending in `/v1` (for example `http://127.0.0.1:11434/v1`) and a model
that supports tool calling.

**The assistant says a server's agent is too old to list ports.** Update the agent from that
server's page (agent 0.9.0 adds listening ports).

**A website fails with "Could not start the file worker: spawn … EACCES".** Agents before 0.9.1
could not run file requests when Node.js is installed in a home folder (nvm puts it in
`/root/.nvm`), because the site's user cannot reach it. Update the agent from the server's page;
for "This server", restart the backend as root and it updates itself. Then use **Try again** on the
website.

**Containers says "Update the agent to manage containers".** Containers need agent 0.10.0. For
"This server", restart the backend as root and it updates itself; other servers update from their
page.

**Docker shows "Stopped", or deploying fails with `DOCKER_NOT_RUNNING`.** Click **Start Docker** on
the Containers page. By hand: for the snap (`which docker` shows `/snap/bin/docker`) run
`snap start --enable docker` and check with `snap services docker`; `systemctl start docker` does
not work for the snap. For Ubuntu's package run `systemctl enable --now docker`.

**A deployment fails with "Could not pull … toomanyrequests".** Docker Hub limits anonymous pulls
(100 per 6 hours per IP). Wait, or use the same image from a mirror such as
`mirror.gcr.io/library/nginx:alpine`. Private registries are not supported yet.

**A deployment fails with `CONTAINER_EXITED` or "did not stay up".** The container stopped during its
health check. The error shows its last output; the usual causes are a missing environment variable,
a wrong command, or too little memory. If it replaced a running container, the old one was started
again and keeps running.

**A port is refused with "is used by …".** Another app, container, SSH, the panel or VaultPanel's own
database already uses that host port on the server. Pick another host port; the port inside the
container can stay the same.

**A public port is reachable even though the firewall does not allow it.** Docker adds its own
iptables rules for published ports, ahead of UFW. Keep ports on "This server only" and add a domain
for them as a website (proxy) instead, or remove the public port.
