# JavaScript SDK

`@vaultpanel/sdk` is a client for the [REST API](api.md): one small class over `fetch`, with a method
per thing the panel manages. It is the `sdk` workspace of this repository, and the
[command-line tool](cli.md) is built on it.

## Use it

```bash
npm install @vaultpanel/sdk  # once published (see publishing.md); inside this repository the workspace is linked
```

```js
import { VaultPanel } from '@vaultpanel/sdk';

const panel = new VaultPanel({
  baseUrl: 'https://panel.example.com',   // or VAULTPANEL_URL
  token: process.env.VAULTPANEL_TOKEN,    // an API token: Users > API Tokens
});

const { items } = await panel.servers.list();
const { job } = await panel.applications.deploy(appId);
await panel.jobs.wait(job.id);
```

The token acts as the person who made it, narrowed to its scopes, so the SDK can never do more than
that person can. `baseUrl` may be given with or without `/api/v1` and with or without a trailing
slash.

`isApiToken(value)` checks that a string looks like an API token before any call.

Options: `timeoutMs` (30s), `retries` (2; GETs only, for 429 and 502/503/504), `userAgent`,
`fetch` (your own, for tests), `onRequest`.

## What it covers

`servers` (and `servers.groups`), `bulkActions`, `websites`, `domains`, `certificates`,
`applications`, `deployments`, `databases` (and `databases.users`), `containers` (and
`containers.onServer`), `backups` (and `backups.schedules`), `cronJobs`, `webhooks`, `alerts`,
`monitoring`, `security`, `jobs`, `users`, `auditLog`, `apiTokens`, `hosting`, `subdomains`, `dns`
(zones and records), `mail` (domains, mailboxes, forwarders), `cms`, `backups.storage`, `dashboard()`,
`health()` and `me()`.

Each method returns the `data` of the reply envelope. Anything not wrapped yet is still reachable:

```js
await panel.request('POST', `/servers/${id}/jobs`, { body: { type: 'SERVICE_RESTART', params: { service: 'nginx' } } });
const envelope = await panel.raw('GET', '/websites');   // { success, data, message, requestId }
```

## Lists

List endpoints return `{ items, pagination }`. To walk every page:

```js
for await (const site of panel.paginate('/websites', { pageSize: 50 })) console.log(site.name);
const all = await panel.listAll('/servers');
```

## Jobs

Long operations answer with a job. `jobs.wait` polls until it finishes and gives back the job and
its log; it throws `JOB_WAIT_TIMEOUT` rather than letting a script carry on as if the work had
succeeded.

```js
const { job, logs } = await panel.jobs.wait(id, {
  timeoutMs: 600_000,
  intervalMs: 2_000,
  onProgress: (job, lines) => lines.forEach((l) => console.log(l.message)),
});
if (job.status !== 'succeeded') throw new Error(job.error ?? job.status);
```

## Errors

Every failure throws a `VaultPanelError` carrying what the panel said:

```js
import { VaultPanelError } from '@vaultpanel/sdk';

try {
  await panel.websites.create({ name: '', serverId });
} catch (err) {
  if (err instanceof VaultPanelError) {
    err.status;        // 422
    err.code;          // 'VALIDATION_ERROR'
    err.fieldErrors;   // { name: 'Required' }
    err.requestId;     // quote this when reporting a problem
    err.isAuthError;   // 401 or 403: the token is gone, or its scopes are too narrow
  }
}
```

`code` is `NETWORK` when the panel could not be reached, `TIMEOUT` when it did not answer in time,
and `BAD_RESPONSE` when something that is not the API answered (usually the wrong URL).

## For plugin authors

`verifyEvent({ body, headers, secret })` checks an event the panel sent to a plugin and returns it
(or `null`), and `verifyLaunch(url, secret)` checks the signed link a plugin's page is opened with
and returns who is looking (or `null`). Both refuse signatures older than 5 minutes. A plugin calls
the API with `new VaultPanel({ token: 'vpp_…' })`. See [plugins.md](plugins.md).

See also: [API](api.md) · [Command-line tool](cli.md) · [Plugins](plugins.md)
