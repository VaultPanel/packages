# API

Base path `/api/v1`. JSON in, JSON out. Every response has a request id (also in the
`X-Request-Id` header; a valid incoming `X-Request-Id` is reused).

```json
{ "success": true, "data": {}, "message": "OK", "requestId": "…" }
{ "success": false, "error": { "code": "VALIDATION_ERROR", "message": "…", "details": [{ "field": "email", "message": "…" }] }, "requestId": "…" }
```

Common error codes: `UNAUTHENTICATED` 401, `FORBIDDEN` 403, `NOT_FOUND` 404, `CONFLICT` 409,
`VALIDATION_ERROR` 422, `RATE_LIMITED` 429, `INTERNAL_ERROR` 500.

**Authentication.** Browser calls use the `vp_session` cookie (HttpOnly, SameSite=Strict, Secure
in production). State-changing calls must send the session's CSRF token in `X-CSRF-Token`; it is
returned by sign-in and `GET /auth/me`.

Scripts, the [command-line tool](cli.md) and the [SDK](sdk.md) send an API token instead:
`Authorization: Bearer vpt_…`. No cookie is involved, so no CSRF token is needed. A token acts as
the person who created it, narrowed to its scopes, and is refused on `/auth` apart from
`GET /auth/me` (see [API tokens](#api-tokens)). Billing systems use their own `vpk_` keys on
`/billing` (see [Hosting and billing](#hosting-and-billing)).

**Lists** accept `page`, `pageSize` (max 100), `sort`, `order` (`asc`/`desc`) and per-endpoint
filters, and return `{ items, pagination: { page, pageSize, total, totalPages } }`.

## Auth

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/auth/setup` | `{ needsSetup, passwordResetByEmail }` (the second says whether the sign-in page offers "Forgot password?") |
| POST | `/auth/setup` | `{ setupToken, name, email, password }` creates the first owner |
| POST | `/auth/login` | `{ email, password }` → session, or `{ twoFactorRequired, challengeToken }` |
| POST | `/auth/login/2fa` | `{ challengeToken, code }` |
| POST | `/auth/logout` | |
| GET | `/auth/me` | user, permissions, CSRF token |
| POST | `/auth/password` | `{ currentPassword, newPassword }`; signs out other sessions |
| POST | `/auth/2fa/setup`, `/auth/2fa/enable`, `/auth/2fa/disable` | TOTP management |
| POST | `/auth/password-reset/request` | `{ email }` → 202 with the same answer whether or not the address has an account; the reset link is emailed. 409 `EMAIL_OFF` when panel email is not set up. At most one email per account every 5 minutes |
| POST | `/auth/password-reset/inspect`, `/auth/password-reset/complete` | invite and reset links |

## API tokens

Phase 10, `/api-tokens`. A token (`vpt_` + 43 characters) belongs to one person and is shown once;
only its SHA-256 is kept. What it may do is the overlap of its scopes and its owner's permissions,
so a token can never do more than its owner, and it stops working the moment the owner is
deactivated, suspended or has their roles narrowed. Everyone manages their own tokens; `users.manage`
also lists and revokes everyone's.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api-tokens?all=true` | Your tokens; `all=true` needs `users.manage` and returns everyone's. Never includes the token itself |
| GET | `/api-tokens/scopes` | The scopes this panel offers: `{ items: [{ key, label, description, permissions }] }` (`permissions` is a count) |
| POST | `/api-tokens` | `{ name, scopes, expiresInDays? }` → `{ apiToken, token }`. The only place the token is shown. Refused for a request made with a token |
| POST | `/api-tokens/:id/revoke` | Your own token, or anyone's with `users.manage`. Takes effect at once |

Scopes (`shared/src/tokens.js`): `read`, `logs`, `deploy`, `manage`, `servers`, `customers`,
`full`. Creating a token whose scopes cover none of the owner's permissions is refused (403), and
scopes it does not have are simply left out. Up to 25 active tokens per person
(409 `TOO_MANY_TOKENS`). A revoked or expired token answers 401 `UNAUTHENTICATED`.

Every call a token makes is audited as its owner, with the token named in the actor label
(`ada@example.com (token: deploy script)`), and the token's last use and address are recorded.

## Users, roles, audit

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/users` (`search`, `role`, `status`) | `users.read` |
| POST | `/users` `{ email, name, role }` → user + invite link + `email` | `users.manage` |
| GET/PATCH | `/users/:id` `{ name?, role?, isActive? }` | `users.read` / `users.manage` |
| POST | `/users/:id/password-reset` → reset link + `email` | `users.manage` |
| GET | `/roles` | `roles.read` |
| GET | `/audit-logs` (`action` prefix, `actorId`, `targetType`, `targetId`, `result`, `from`, `to`) | `audit.read` |
| GET | `/dashboard` | `dashboard.view` (sections depend on other permissions) |

Invite and reset links (users, and customers under Hosting) also come back with `email`:
`null` when panel email is not set up, else `{ to, sent, error }`. The link is returned either way,
to hand over if the email does not arrive.

## Panel email

`/settings/email`, needs `settings.manage`. The SMTP server the panel sends its own email through
(invites, password resets, alerts). Not the email hosting under `/mail`.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/settings/email` → `{ enabled, host, port, security, username, hasPassword, fromAddress, fromName, alerts: { events, toAdmins, extra }, missing, ready, updatedAt }` | The password is never returned |
| PUT | `/settings/email` (any of the fields above, plus `password`) | Fields left out keep their value; `password: null` removes it; a new host drops the old password unless one comes along; turning on without host, port and from address is 422 |
| POST | `/settings/email/test` `{ to, settings? }` → `{ message }` | Sends one email now with the saved settings, or with `settings` merged over them (not saved). 502 `EMAIL_SEND_FAILED` with the reason |
| GET | `/settings/email/messages` (`limit`) | The last emails sent (30 days kept): to, subject, kind, status, error. Never the body |

`security`: `tls` (465), `starttls` (587, TLS required) or `none`. `alerts.events` are webhook event
names; ticked events are emailed to every active owner and admin (`toAdmins`) and up to 10 more
addresses. Alerts are sent by the worker and retried up to 4 times.

## Servers and jobs

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/servers` (`search`, `status`, `groupId`); each server lists its `groups` and `agentUpdateAvailable` | `servers.read` |
| POST | `/servers` `{ name }` → server + enrollment token + install command | `servers.manage` |
| GET/PATCH/DELETE | `/servers/:id` | `servers.read` / `servers.manage` |
| POST | `/servers/:id/enrollment-tokens` | `servers.manage` |
| GET | `/servers/:id/metrics?range=1h\|6h\|24h\|7d\|30d\|90d` | `servers.read` |
| POST | `/servers/:id/jobs` `{ type, params }` → 202 job | per operation |
| PUT | `/servers/:id/groups` `{ groupIds }` → the server's groups | `servers.manage` |
| POST | `/servers/:id/agent-update` → 202 `AGENT_UPDATE` job (agents 0.7.0+) | `servers.manage` |
| GET | `/jobs` (`serverId`, `status`, `type`, `includeRoutine`), `/jobs/:id?afterLogId=` | `jobs.read` |
| POST | `/jobs/:id/cancel` (queued jobs only) | `jobs.cancel` |
| GET | `/jobs/operations` | signed in |

Operations available now: `SERVICE_STATUS`, `SERVICE_START`, `SERVICE_STOP`, `SERVICE_RESTART`,
`SERVICE_LOGS` (`servers.services`), `PROCESS_LIST` (`servers.processes`), `PROCESS_SIGNAL`
(`servers.signal`), `SERVER_REBOOT` (`servers.reboot`), `WEB_STACK_INSTALL` (`websites.manage`). Others in the catalog return
`409 OPERATION_UNAVAILABLE` until their phase. Duplicate active jobs return `409 DUPLICATE_OPERATION`
with the existing `jobId`. An operation the server's agent does not report supporting returns
`409 AGENT_OUTDATED`; `GET /servers/:id` then includes `agentUpdate.command` to upgrade it.

Each server carries `selfCheck`, the last self-check report its agent sent (agents 0.39.0 and later,
every few minutes; null before), which `selfChecks()` in `@vaultpanel/shared` turns into checks
(`ok`, `warning`, `error`, `info`). `SELF_CHECK` (`servers.read`, routine) reads it again now; the job's
output is `{ selfCheck }`.

Routine requests (file listing and reading, log reads) are left out of `/jobs` unless
`includeRoutine=true`.

Metrics: `1h`, `6h` and `24h` return raw 15-second samples (averaged down to at most 240
points); `7d`, `30d` and `90d` return hourly rollups with `cpuPercentMax` and `samples`. The response
says which with `resolution: "raw" | "hour"`.

## Server groups and bulk actions

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/server-groups` → groups with their servers and a `summary` (counts by status, firing alerts, agents to update, CPU/memory/disk average and highest) | `servers.read` |
| POST | `/server-groups` `{ name, description?, color?, serverIds? }` | `servers.manage` |
| GET/PATCH/DELETE | `/server-groups/:id` (deleting a group leaves its servers) | `servers.read` / `servers.manage` |
| GET | `/bulk-actions` (`status`, `groupId`), `/bulk-actions/:id` (with one target per server) | `jobs.read` |
| POST | `/bulk-actions` `{ type, params, serverIds \| groupId, mode?, stopOnFailure? }` → 202 | `servers.bulk` and the operation's own permission |
| POST | `/bulk-actions/:id/cancel` | `servers.bulk` |

Bulk operations: `SERVICE_RESTART`, `SERVICE_START`, `SERVICE_STATUS` (with `params.service`),
`SECURITY_UPDATES_INSTALL`, `AGENT_UPDATE` (the panel fills in the version and hash) and
`SERVER_REBOOT`. `mode` is `parallel` (default) or `rolling` (default for reboots and updates);
`stopOnFailure` applies to `rolling`. Servers that are offline, have no agent, run an agent that
cannot do the operation, or (for agent updates) are already current are `skipped` with the reason;
when no server can run it the request fails with `409 NOTHING_TO_RUN`. A target goes `waiting` →
`running` → `succeeded` or `failed`; reboots and agent updates go through `verifying` until the
server reports a newer boot time or the new agent version (10 and 3 minutes at most). The panel's
own server (`isLocal`) always runs last. For `SERVER_REBOOT` it also waits until every other server
is done, even in `parallel` mode, and its reboot is given 24 hours to be confirmed, since the panel
is down until it is started again there.

## Websites, domains and SSL

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/websites` (`search`, `serverId`, `status`, `subdomains=true` for subdomain sites only) | `websites.read` |
| POST | `/websites` `{ serverId, name, type, domains, documentRoot?, phpVersion?, proxyPort? }` → 202 website + job. A domain may be a wildcard one level deep (`*.example.com`, agent 0.37.0, else `AGENT_OUTDATED`): it serves every name under `example.com` that no site lists itself, since NGINX prefers exact names. Not over a registry suffix (`*.co.uk`); for a hosting customer, a wildcard on another account's site counts as that account's, like its domain | `websites.manage` |
| GET | `/websites/:id` → website with domains, certificate, health and recent jobs | `websites.read` |
| PATCH | `/websites/:id` `{ type?, domains?, documentRoot?, phpVersion?, proxyPort?, forceHttps? }` | `websites.manage` |
| DELETE | `/websites/:id?removeFiles=true\|false` | `websites.manage` |
| POST | `/websites/:id/enable`, `/disable`, `/retry` | `websites.manage` |
| POST | `/websites/:id/ssl` `{ email, staging?, verifyDns?, forceHttps?, wildcard?, dnsProviderId? }`: with `wildcard`, one certificate for the domain and `*.domain`, checked through a DNS zone on the site's server (`DNS_ZONE_MISSING`, `WILDCARD_NOT_POSSIBLE` when the domains do not fit one). With `dnsProviderId` (staff with `dns.read`, agent 0.38.0), the wildcard certificate is checked through that DNS provider instead and no zone on the server is needed; the certificate's `dnsProviderId` shows it. Without it, the site's wildcard domains are left out of the certificate (listed in `uncoveredDomains`); a site whose domains are all wildcards always asks for a wildcard certificate | `websites.manage` |
| POST | `/websites/:id/ssl/upload` `{ certificate, privateKey, forceHttps? }`: installs a certificate (PEM, with its chain) bought elsewhere; the key is dropped from the stored job. Uploaded certificates show `provider: "custom"` and are not renewed (`SSL_CUSTOM`) | `websites.manage` |
| POST | `/websites/:id/ssl/renew` `{ force? }`; DELETE `/websites/:id/ssl` | `websites.manage` |
| POST | `/websites/:id/logs` `{ log: access\|error, lines }` → 202 job | `websites.logs` |
| POST | `/websites/:id/dns-check`; `/domains/:id/dns-check` | `websites.read` |
| GET | `/websites/:id/uptime` → `{ uptime: { enabled, intervalSeconds, status (up\|down\|null), since, checkedAt, message, responseMs, url, certificateValidTo, day, week, month (uptime %), averageMs, incidents[] } }`. Websites are checked from the panel every `VAULTPANEL_UPTIME_CHECK_SECONDS` (300): the primary domain (or the first that is not a wildcard) over HTTPS when the certificate covers it. Down means no answer, HTTP 5xx, or a certificate browsers refuse, twice in a row 10 seconds apart. List and detail responses carry `uptime: { enabled, status, since, checkedAt, message }` | `websites.read` |
| PUT | `/websites/:id/uptime` `{ enabled }`: off forgets the status and ends open downtime, so its alert resolves | `websites.manage` |
| POST | `/websites/:id/uptime/check` → the same as GET after one check now (`UPTIME_NOT_CHECKED` while monitoring is off or the website is disabled) | `websites.manage` |
| GET | `/subdomains/parents` → the domains a subdomain can go under (the account's own, for a customer) | `websites.read` |
| POST | `/subdomains` `{ parentDomain, name, type: static\|php, documentRoot?, phpVersion? }` → 202 website + job. A site of its own on the parent's server, owned by the parent's account and counted against its plan's `subdomains`. When a panel zone holds the name, an A (and AAAA) record is added once the site exists and removed when it is deleted | `websites.manage` |
| POST | `/websites/:id/files/list\|read` `{ path }` → 202 job | `files.read` |
| POST | `/websites/:id/files/write\|mkdir\|rename\|delete` → 202 job | `files.write` |
| POST | `/websites/:id/files/extract` `{ path, to, overwrite }` → 202 job: unpacks a `.zip`, `.tar.gz`, `.tgz` or `.tar` into `to` (created when missing; empty = the home folder) | `files.write` |
| POST | `/websites/:id/files/chmod` `{ path, mode, recursive, fileMode }` → 202 job: permissions as three octal digits; with `recursive`, folders inside get `mode` and files `fileMode`; links are skipped | `files.write` |
| POST | `/websites/:id/files/downloads` `{ path }` → 202 `FILE_DOWNLOAD` job with `downloadId`: the agent sends the file to the panel (up to `VAULTPANEL_FILE_DOWNLOAD_MAX_MB`, default 2048) | `files.read` |
| GET | `/websites/:id/files/downloads/:downloadId` → `{ ready, size, sha256 }`; `.../file` → the file (`?inline=1` without `Content-Disposition`), only for the person who asked, for an hour | `files.read` |
| POST | `/websites/:id/files/compress` `{ folder, names[], to }` → 202 job: makes the zip `to` from up to 200 files and folders in `folder` | `files.write` |
| POST | `/websites/:id/files/uploads` `{ path, size, overwrite }` → 201 `{ uploadId, chunkBytes }`: starts a large upload (up to `VAULTPANEL_FILE_UPLOAD_MAX_MB`, default 2048) | `files.write` |
| PUT | `/websites/:id/files/uploads/:uploadId/chunks/:offset` (raw `application/octet-stream`, up to 8 MB, in order) → `{ received, size }` | `files.write` |
| POST | `/websites/:id/files/uploads/:uploadId/finish` → 202 `FILE_UPLOAD` job: the agent fetches the file from the panel, checks its SHA-256 and saves it as the site's user | `files.write` |
| GET | `/domains` (`search`, `serverId`) | `websites.read` |
| GET | `/ssl-certificates` (`serverId`, `status` incl. `expiring`, `expired`) | `websites.read` |
| GET | `/ssl-certificates/renewal`: `renewBeforeDays`, `warnDays`, limits, servers with certificates | `websites.read` |
| PUT | `/ssl-certificates/renewal` `{ renewBeforeDays (7-60), warnDays (< renewBeforeDays) }`: applies the window on every server whose agent can | `settings.manage` |

Types: `static`, `php` (needs `phpVersion` installed on the server), `proxy` (needs `proxyPort`).
The first domain is the primary one. Site names are 3 to 32 lowercase letters, digits and dashes and
become the Linux user and folder name.

Changes return `202` with the job that carries them out. The website keeps its current settings
until the job succeeds (`pendingAction` shows what is running); a failed change leaves them as they
were and sets `lastError`. A change while another is running returns `409 WEBSITE_BUSY`. File and log
requests are jobs too: poll `GET /jobs/:id` for the output. File paths are relative to the site's
home folder; `..`, absolute paths and control characters are refused. Files up to 1 MB can be read
or written (`encoding: utf8 | base64`). Written file contents are dropped from the stored job when it
finishes and never reach the audit log; file read results are deleted an hour after the job.

`WEB_STACK_INSTALL` `{ components: [nginx, php, certbot] }` (permission `websites.manage`) installs
the web stack through `POST /servers/:id/jobs`. The other website operations can only be started
through the endpoints above (`400 OPERATION_NOT_DIRECT`).

## Applications and deployments

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/applications` (`search`, `serverId`, `runtime`, `status`) | `applications.read` |
| GET | `/applications/suggest-port?serverId=` → `{ port, pool }`: for staff a free port from 3000 (skipping customers' ports) and `pool: null`; for a hosting customer the first of their free ports, with `pool: { ports, free }` | `applications.read` |
| POST | `/applications` `{ serverId, name, runtime: node\|python, repositoryUrl, branch?, installCommand?, buildCommand?, startCommand?, port, keepReleases?, healthCheckSeconds?, env?, domains?, deployNow? }` → 202 app + jobs | `applications.manage` (+ `websites.manage` with domains) |
| GET | `/applications/:id` → app with process state, website, deploy key, webhook state, recent deployments and jobs | `applications.read` |
| PATCH | `/applications/:id` (same fields; saved at once, process settings need Apply) | `applications.manage` |
| DELETE | `/applications/:id?removeFiles=true\|false` (also deletes its linked website) | `applications.manage` |
| GET, PUT | `/applications/:id/environment` `{ variables: [{ key, value }] }` (reads are audited) | `applications.manage` |
| POST | `/applications/:id/deploy`; `/rollback` `{ deploymentId }` | `applications.deploy` |
| POST | `/applications/:id/start\|stop\|restart` | `applications.deploy` |
| POST | `/applications/:id/apply` (env, start command and port go live, restart) | `applications.manage` |
| POST | `/applications/:id/scale` `{ instances }` (1 to 16 copies; a running app changes now, in place when only the count changes) | `applications.manage` |
| POST | `/applications/:id/status` (refresh the process state) | `applications.read` |
| POST | `/applications/:id/logs` `{ log: output\|error, lines }` → 202 job | `applications.logs` |
| POST | `/applications/:id/website` `{ domains }` (creates the linked proxy website) | `applications.manage` + `websites.manage` |
| POST, DELETE | `/applications/:id/webhook` (POST returns the URL once; again for a new one) | `applications.manage` |
| GET | `/deployments` (`applicationId`, `serverId`, `status`); `/deployments/:id` with stages and log | `applications.read` |
| POST | `/hooks/deploy/:token` (no session; the token is the credential) | none |

Apps and websites share names on a server: the name is the Linux user and the folder under
`/var/www`. A change while another is running returns `409 APPLICATION_BUSY`. Creating or deploying
needs Git, PM2 (and Python for Python apps) on the server (`409 SOFTWARE_MISSING`). The webhook
deploys on a push to the app's branch, ignores other branches and events (`X-GitHub-Event`,
`X-Gitlab-Event`, `X-Gitea-Event`) with `200 { ignored: true }`, and is limited to 30 requests a
minute per IP.

## Databases

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/databases` (`search`, `serverId`, `applicationId`, `websiteId`); `/databases/:id` with its users, `application` and `website` | `databases.read` |
| POST | `/databases` `{ serverId, name, applicationId?, websiteId?, createUser?, username?, privileges?, addToAppEnv? }` → 202 database, user, generated password (once), env keys added | `databases.manage` (+ `applications.manage` to add env) |
| PATCH | `/databases/:id` `{ applicationId?, websiteId? }` links the database to the app and the website that use it (on the same server and account); `null` unlinks, a link left out is kept. DELETE `/databases/:id`; POST `/databases/:id/retry` | `databases.manage` |
| GET | `/database-users` (`search`, `serverId`) | `databases.read` |
| POST | `/database-users` `{ serverId, username, password?, privileges: all\|readonly, databaseIds }` | `databases.manage` |
| PATCH | `/database-users/:id` `{ password?, generatePassword?, privileges?, databaseIds? }`; DELETE | `databases.manage` |
| POST | `/database-users/:id/password` → password and connection URL (audited) | `databases.manage` |

`WEB_STACK_INSTALL` also takes `git`, `pm2`, `python` and `mariadb` components.

## DNS zones

Zones are served by BIND on one of the panel's servers (staff only). Customers see the name servers
and their own domains' zones through `GET /hosting/me/dns` and `POST /hosting/me/dns/zones/:id/check`.

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/dns/zones` (`search`, `serverId`); `/dns/zones/:id` with its records and name servers | `dns.read` |
| POST | `/dns/zones` `{ serverId, domain, ipv4?, ipv6?, nameservers?, includeMail?, soaEmail?, defaultTtl? }` → 202 zone with default records (NS, A for `@` and `www`, name server glue, and with `includeMail` a `mail` A record, MX and SPF) | `dns.manage` |
| PATCH | `/dns/zones/:id` `{ soaEmail?, defaultTtl? }`; DELETE `/dns/zones/:id` | `dns.manage` |
| POST | `/dns/zones/:id/apply` (send the zone to the server again) | `dns.manage` |
| PUT | `/dns/servers/:id/customers` `{ nameservers, autoZones }`: the name servers customers on the server see, and whether each new customer domain gets a zone there (removed with the account) | `dns.manage` |
| POST | `/dns/zones/:id/check` → what public DNS lists as the domain's name servers: `ok`, `partial`, `elsewhere`, `unresolved` or `error` | `dns.read` |
| POST | `/dns/zones/:id/records` `{ name, type, value, ttl?, priority?, weight?, port?, tag? }` | `dns.manage` |
| PATCH, DELETE | `/dns/zones/:id/records/:recordId` | `dns.manage` |
| GET | `/dns/providers` → DNS providers (`cloudflare`, `namecheap`) with how many active certificates renew through each; `/dns/providers/:id`. Secrets are never returned; customers get an empty list | `dns.read` |
| POST | `/dns/providers` `{ name, type, username?, secret }` → 201: `secret` is a Cloudflare API token (Zone > DNS > Edit) or a Namecheap API key, with `username` the Namecheap user name | `dns.manage` |
| PUT | `/dns/providers/:id` `{ name, type, username?, secret? }`: the type cannot change, and a blank `secret` keeps the saved one. Servers keep their copy until a certificate is issued again | `dns.manage` |
| DELETE | `/dns/providers/:id`: refused while active certificates renew through it (`DNS_PROVIDER_IN_USE`) | `dns.manage` |

Record types: A, AAAA, CNAME, MX, TXT, NS, SRV and CAA. Every change raises the zone's serial and
sends the whole zone to the server (`DNS_ZONE_APPLY`); a zone whose records would not load is refused
before it is sent. `DNS_SETUP` (run from the DNS Zones page, `dns.manage`) installs BIND on a server.

## Email

Email hosting with Postfix, Dovecot and OpenDKIM on the panel's servers (staff only).

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/mail/servers`: every server with its mail server (host name, state, certificate, last checks) | `mail.read` |
| POST | `/mail/servers` `{ serverId, hostname }` sets up (or sets up again) the mail server; adds an A record for the host name when the panel runs its DNS | `mail.manage` |
| POST | `/mail/servers/:serverId/apply` (send the settings again); `/mail/servers/:serverId/check` (host name and reverse DNS in public DNS, `mail.read`); `/mail/servers/:serverId/usage` (mailbox sizes, `mail.read`) | `mail.manage` |
| GET | `/mail/domains` (`search`, `serverId`); `/mail/domains/:id` with mailboxes, forwarders, the DNS records it needs and mail app settings | `mail.read` |
| POST | `/mail/domains` `{ serverId, domain, addDnsRecords? }` → 202; with `addDnsRecords` (default) the MX, SPF and DMARC records go into the panel's zone for the domain, replacing its MX and SPF, and the DKIM record once the key exists | `mail.manage` |
| DELETE | `/mail/domains/:id?deleteMail=true` | `mail.manage` |
| POST | `/mail/domains/:id/dns` (put the records into the zone now) | `mail.manage` and `dns.manage` |
| POST | `/mail/domains/:id/check` (the records in public DNS) | `mail.read` |
| POST | `/mail/domains/:id/mailboxes` `{ localPart, password?, displayName?, quotaMb? }` → the generated password once when none is given | `mail.manage` |
| PATCH | `/mail/domains/:id/mailboxes/:itemId` `{ password?, generatePassword?, displayName?, quotaMb?, enabled? }`; DELETE with `?deleteMail=true` | `mail.manage` |
| POST, PATCH, DELETE | `/mail/domains/:id/forwarders` `{ localPart, destinations }`, `/mail/domains/:id/forwarders/:itemId` | `mail.manage` |

Mailbox passwords are hashed (SHA512-CRYPT) by the panel and never stored or sent to the agent. Every
change raises the mail server's serial and sends all its domains, mailboxes and forwarders (`MAIL_APPLY`).

## Monitoring and alerts

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/monitoring/overview` → every server with latest metrics, fullest filesystem, service problems, 1 h trend, firing alerts | `servers.read` |
| GET | `/monitoring/services` (`state` = `all`\|`running`\|`problem`, `search`) | `servers.read` |
| GET | `/alerts/summary` → `{ firing, unacknowledged, bySeverity }` | `alerts.read` |
| GET | `/alerts/events` (`status` = `pending`\|`firing`\|`resolved`\|`open`, `serverId`, `severity`) | `alerts.read` |
| POST | `/alerts/events/:id/acknowledge` (firing, not yet acknowledged) | `alerts.acknowledge` |
| GET | `/alerts/rules` | `alerts.read` |
| POST/PATCH/DELETE | `/alerts/rules`, `/alerts/rules/:id` `{ name, metric, threshold, durationSeconds, severity, serverId?, serviceName?, isEnabled? }` | `alerts.manage` |

Rule metrics: `cpu_percent`, `memory_percent`, `disk_percent` (checked per filesystem),
`swap_percent`, `load_per_core`, `server_offline`, `service_down` (no threshold; `serviceName`
optional) and `website_down` (no threshold: one alert per website on the server that fails the
panel's uptime checks, with the website's address as the subject). A rule without `serverId`
applies to every server.

## Backups, cron jobs, logs and webhooks

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/backups` (`search`, `serverId`, `resourceType`, `resourceId`, `status`; with a website or app, `includeDatabases=true` adds the backups of the databases linked to it); `/backups/:id` with its restores | `backups.read` |
| POST | `/backups` `{ resourceType: website\|application\|database, resourceId }` → 202 backup and job | `backups.create` |
| DELETE | `/backups/:id` (deletes the file on the server) | `backups.manage` |
| POST | `/backups/:id/restore` `{ safetyBackup = true }` → 202 restore, safety backup and job. Puts the backup back in place of the current files or data | `backups.manage` |
| POST | `/backups/:id/download` → `{ ready }`, or a job that copies the file to the panel; then GET `/backups/:id/download` sends it (kept 6 h) | `backups.manage` |
| GET | `/backup-schedules` (`serverId`, `resourceType`, `resourceId`, `includeDatabases`) | `backups.read` |
| PUT | `/backup-schedules` `{ resourceType, resourceId, schedule, timezone = UTC, keepCount = 7, enabled }` (one per resource); DELETE `/backup-schedules/:id` | `backups.manage` |
| GET | `/cron-jobs` (`search`, `serverId`, `ownerType`, `ownerId`, `status`); `/cron-jobs/:id`; `/cron-jobs/:id/runs` (`status`) | `cron.read` |
| POST/PATCH/DELETE | `/cron-jobs`, `/cron-jobs/:id` `{ ownerType: website\|application, ownerId, name, schedule, commands, workingDir?, timeoutSeconds, enabled, appEnv? }` → 202 with the job | `cron.manage` |
| POST | `/cron-jobs/:id/run` → 202 job; the run is recorded in its history | `cron.run` |
| GET | `/webhooks`; `/webhooks/:id` (with its URL); `/webhooks/:id/deliveries` (`status`) | `webhooks.manage` |
| POST | `/webhooks` `{ name, url, format: json\|slack\|discord, events, enabled }` → the webhook and its signing secret (shown once) | `webhooks.manage` |
| PATCH/DELETE | `/webhooks/:id` `{ …, rotateSecret? }`; POST `/webhooks/:id/test`; POST `/webhooks/:id/deliveries/:deliveryId/redeliver` | `webhooks.manage` |

Server logs are an operation: `POST /servers/:id/jobs` with `SYSTEM_LOGS`
`{ source: journal|kernel|auth|cron, priority, sinceMinutes?, lines, search? }` (`servers.logs`).
`WEB_STACK_INSTALL` also takes the `cron` component.

Webhook events: `backup.succeeded`, `backup.failed`, `restore.succeeded`, `restore.failed`,
`cron.failed`, `deployment.succeeded`, `deployment.failed`, `alert.firing`, `alert.resolved`,
`server.offline`, `server.online`, `ssl.expiring`, `ssl.expired`, `ssl.renew_failed`. A `json` delivery is a POST of
`{ id, event, occurredAt, data }` with the headers `X-VaultPanel-Event`,
`X-VaultPanel-Delivery`, `X-VaultPanel-Timestamp` and
`X-VaultPanel-Signature: sha256=<HMAC-SHA256 of "<timestamp>.<body>" with the secret>`. `slack` and
`discord` send an unsigned chat message instead (the URL itself is the secret). A delivery that does not get a 2xx answer within 10 s is
retried after 1 minute, 5 minutes and 30 minutes.

## Security

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/security/overview`: every server with its reported summary, checks and score | `security.read` |
| GET | `/security/servers/:id`: summary, checks, `protectedPorts` (the panel's port on its own server) and `yourAddress` | `security.read` |
| PUT | `/security/servers/:id/firewall` `{ enabled }` → 202 job | `security.manage` |
| POST | `/security/servers/:id/firewall/rules` `{ action: allow\|limit\|deny\|reject, direction: in\|out = in, protocol: tcp\|udp\|any, port?, source = any, destination = any, comment? }` (outgoing rules use `destination`, agent 0.34.0) → 202 job; 409 `LOCKOUT_REFUSED` when it would block your own address | `security.manage` |
| POST | `/security/servers/:id/firewall/rules/delete` `{ action, direction?, protocol, port, source, destination?, app? }` → 202 job | `security.manage` |
| PUT | `/security/servers/:id/firewall/default` `{ incoming?: deny\|reject\|allow, outgoing?: allow\|deny\|reject }` → 202 job | `security.manage` |
| PUT | `/security/servers/:id/ssh/ports` `{ ports: [1-2 ports] }` → 202 job; 422 for the panel's port; 409 `AGENT_OUTDATED` before agent 0.34.0 | `security.manage` |
| PUT | `/security/servers/:id/ssh` `{ permitRootLogin: yes\|prohibit-password\|no, passwordAuthentication, maxAuthTries }` → 202 job | `security.manage` |
| POST | `/security/servers/:id/ssh/keys` `{ key, user? }`; `/security/servers/:id/ssh/keys/delete` `{ fingerprint, user? }` → 202 job (`user` other than root needs agent 0.34.0) | `security.manage` |
| GET, PUT | `/security/panel-access` `{ enabled, scope: everyone\|staff, addresses: [{ address, note? }] }`: panel access by address; 409 `LOCKOUT_REFUSED` when your own address is not listed. Requests from other addresses get 403 `IP_NOT_ALLOWED` | `settings.manage` |
| PUT | `/security/servers/:id/fail2ban` `{ enabled, maxRetry, findTimeMinutes, banTimeMinutes, ignoreIps }`; POST `/security/servers/:id/fail2ban/unban` `{ ip }` → 202 job | `security.manage` |
| PUT | `/security/servers/:id/updates` `{ enabled }`; POST `/security/servers/:id/updates/install` → 202 job | `security.manage` |
| GET/PUT | `/security/authentication` (`{ twoFactorPolicy: off\|admins\|all }`): the policy and each user's two-factor state, recovery codes left and sessions; 409 `TWO_FACTOR_REQUIRED_FIRST` | `settings.manage` |
| GET | `/security/sessions`; DELETE `/security/sessions/:id` | `users.manage` |
| POST | `/users/:id/2fa/reset`: turns off someone else's two-factor sign-in and signs them out | `users.manage` |

The full live state of one server is the `SECURITY_STATUS` operation (`POST /servers/:id/jobs`,
`security.read`); `SECURITY_TOOLS_INSTALL` `{ components: [ufw, fail2ban, unattended-upgrades] }`
installs the tools (`security.manage`). The other security operations can only be started through
the routes above, which add the panel's checks.

Sign-in additions: `POST /auth/login/2fa` takes `{ challengeToken, code }` or
`{ challengeToken, recoveryCode }`; `POST /auth/2fa/enable` returns `{ recoveryCodes }`;
`POST /auth/2fa/recovery-codes` `{ password, code }` makes new ones; `GET /auth/sessions`,
`DELETE /auth/sessions/:id` and `POST /auth/sessions/sign-out-others` manage your own sessions.
`GET /auth/me` and sign-in responses include `twoFactorSetupRequired`; while it is true every other
route answers 403 `TWO_FACTOR_SETUP_REQUIRED`. `PATCH /applications/:id` also takes
`cpuLimitPercent` (10 to 6400, 100 = one core) and `memoryLimitMb` (64 to 262144), or `null`.

## Hosting and billing

Phase 8. Staff routes under `/hosting`; a hosting customer (role `customer`) can only call `/auth`,
`/hosting/me`, and the website, domain, certificate, app, deployment, database, backup, cron and job
routes, and there only sees and changes what their account owns (anything else is 404). Their
creates are checked against their plan and refused with 409 `QUOTA_REACHED`
(`details: { kind, limit, used }`), and land on their account's server (409 `NO_SERVER` when it has
none). Sign-in replies and `GET /auth/me` carry `customer: { id }` (null for staff); a suspended or
removed account's sign-in is refused with 403 `ACCOUNT_SUSPENDED`.

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/hosting/me` → `{ customer, plan, usage, appCaps, ports, server }` (`ports`: the account's own app ports, each with the app on it or null) | a customer |
| GET | `/hosting/me/dns` → `{ nameservers, autoZones, zones }`: the name servers to set at the registrar, and the account's domains the panel answers for (with their name servers and last public DNS check) | a customer |
| POST | `/hosting/me/dns/zones/:id/check` → that zone, checked against public DNS | a customer |
| GET | `/hosting/plans`, `/hosting/plans/:id` | `customers.read` |
| POST/PATCH | `/hosting/plans`, `/hosting/plans/:id` `{ name, description?, isActive?, priceCents?, currency?, billingCycle?, serverGroupId?, limits?, appCaps? }` | `plans.manage` |
| DELETE | `/hosting/plans/:id` (409 `PLAN_IN_USE` while a customer is on it) | `plans.manage` |
| GET | `/hosting/customers` (`search`, `status`, `planId`, `serverId`; removed ones only with `status=terminated`), `/hosting/customers/:id` (with `planDetail`, `resources` and `ports`) | `customers.read` |
| POST | `/hosting/customers` `{ name, email, planId, company?, serverId?, externalId?, password?, notes? }` → `{ customer, inviteUrl, inviteExpiresAt }` | `customers.manage` |
| PATCH | `/hosting/customers/:id` `{ name?, email?, company?, serverId?, externalId?, notes? }` | `customers.manage` |
| POST | `/hosting/customers/:id/plan` `{ planId }`, `/suspend` `{ reason? }`, `/unsuspend`, `/terminate`, `/password-reset` | `customers.manage` |
| POST/DELETE | `/hosting/customers/:id/resources` `{ type, resourceId }`, `/hosting/customers/:id/resources/:type/:resourceId`: move an existing website, app, database or database user into or out of the account | `customers.manage` |
| GET/POST | `/hosting/api-keys` `{ name, scopes: ["billing"] }` → `{ apiKey, key }` (the key is only in this reply) | `billing.manage` |
| POST | `/hosting/api-keys/:id/revoke` | `billing.manage` |

`limits` has `websites`, `applications`, `databases`, `databaseUsers`, `cronJobs` and `diskMb`;
`appCaps` has `appMemoryMb` and `appCpuPercent`. `null` means unlimited (or no cap). A customer's
`usage` has the counts, `diskBytes`/`diskMb`, the plan's `limits` and `over` (the limits it is over,
for example after moving to a smaller plan; nothing is deleted then, new things are refused).
Suspending turns the account's websites off, stops its apps, pauses its cron jobs and signs it out;
unsuspending turns back on exactly what suspending turned off. Removing deletes every website, app,
database and database user it owns (with their files and backups) and closes its sign-in; calling
it again retries anything left. Suspend, unsuspend and remove return `{ customer, warnings }`.

`GET /hosting/reports/financial?months=12` (1 to 36, `customers.read`) is the financial report:
expected amounts from plan prices, never payments (VaultPanel takes none). It returns `summary`
(active and suspended accounts, accounts added and removed in the period, and per currency
`monthlyCents`, `yearlyCents`, `atRiskCents` for suspended accounts and `payingAccounts`), `plans`
(accounts per plan with `monthlyCents`, the price spread over a month, and `monthlyTotalCents`) and
`history`, one entry per month with `newAccounts`, `removedAccounts`, `suspensions` and
`accountsAtEnd`, plus `monthlyByCurrency`, which prices those accounts at their current plan.

### Billing API

`/billing`, for billing systems. Send an API key: `Authorization: Bearer vpk_...`. No cookie or
CSRF token; 120 requests a minute per address. `{ref}` is the account's id or its `externalId`.

| Method | Path | Does |
| --- | --- | --- |
| GET | `/billing/plans` | Plans offered for new accounts |
| GET | `/billing/accounts` (`page`, `pageSize` up to 100, `search`, `status`, `planId`, `serverId`) | Accounts with their `usage` (`diskMb`, counts, `limits`), removed ones only with `status=terminated`; for usage syncs |
| POST | `/billing/accounts` `{ name, email, plan, company?, externalId?, serverId?, password? }` | Create (plan by name or id); 409 `EXTERNAL_ID_TAKEN` with `details.customerId` when the externalId exists |
| GET | `/billing/accounts/{ref}` | The account with usage and resources |
| POST | `/billing/accounts/{ref}/suspend` `{ reason? }`, `/unsuspend` | Suspend or unsuspend |
| POST | `/billing/accounts/{ref}/plan` `{ plan }` | Change plan |
| POST | `/billing/accounts/{ref}/password` `{ password? }` | Set the password, or without one get `{ resetUrl, expiresAt }` |
| POST | `/billing/accounts/{ref}/login` | `{ url, expiresAt }`: a sign-in link for the account's owner ("Log in to VaultPanel"), `<panel>/sso#token=…`, that works once within two minutes. It signs in without the second factor (the key can already set the password). 409 `ACCOUNT_SUSPENDED` for a suspended account |
| DELETE | `/billing/accounts/{ref}` | Remove the account and everything it owns |

Every call is in the audit log with the key as the actor. The `/sso` page sends the link's token to
`POST /auth/sso { token }`, which signs in like `/auth/login` (`LOGIN_LINK_INVALID` when it is used,
expired or unknown; `ACCOUNT_SUSPENDED` when the account was suspended since). Invite and reset
links (`/auth/password-reset/*`) never accept a sign-in link's token.

A ready-made WHMCS module that uses this API is in
[integrations/whmcs](../integrations/whmcs/README.md).

## AI assistant

Phase 9, `/assistant`. Settings need `settings.manage`; everything else needs `assistant.use`
(owners, admins, developers and viewers; never hosting customers). Conversations belong to the
person who started them; anyone else gets 404.

| Method | Path | Does |
| --- | --- | --- |
| GET | `/assistant/status` → `{ enabled, provider, providerLabel, model, canConfigure, hourlyLimit }` | Whether questions can be asked |
| GET | `/assistant/settings` → `{ enabled, provider, model, baseUrl, hasApiKey, apiKeyHint, providers, updatedAt }` | The chosen provider's settings, and in `providers` each provider's own `{ model, baseUrl, hasApiKey, apiKeyHint }` (keys are never returned) |
| PUT | `/assistant/settings` `{ enabled?, provider?, model?, baseUrl?, apiKey? }` | Save the settings of `provider` (or the chosen one) and choose it. Each provider keeps its own model, address and key, so switching back needs nothing again; `apiKey: null` removes that provider's key, leaving it out keeps it. `local` (the model on the panel's server) takes only a `model` the panel installs. Turning on without a model, or without a key for Claude, is 422 |
| POST | `/assistant/settings/test` `{ provider, model, baseUrl?, apiKey? }` → `{ ok, provider, model, latencyMs }` | Send one short request with these settings (that provider's saved key is used when none is given) |
| GET | `/assistant/local-model` → `{ server, problem, installed, running, version, models, memory, diskFreeBytes, lastJob, catalog }` | The free model on the panel's own server: whether it can be installed (`problem` says why not), Ollama's state, the installed models `[{ id, sizeBytes }]`, the server's memory and free disk, the last install or removal job, and the models the panel offers |
| POST | `/assistant/local-model/install` `{ model }`, `/assistant/local-model/remove` `{ model }`, `/assistant/local-model/uninstall` | 202 with the job on the panel's own server (`LOCAL_AI_INSTALL`, `LOCAL_AI_REMOVE`, `LOCAL_AI_UNINSTALL`). Only models from `catalog`; 409 `LOCAL_SERVER_MISSING` or `LOCAL_MODEL_UNAVAILABLE` (not connected, offline, or an agent before 0.41.0), 409 `LOCAL_MODEL_IN_USE` for the model the assistant answers with |
| GET | `/assistant/conversations`, `/assistant/conversations/:id` | List, or one conversation with its transcript and proposed actions |
| POST | `/assistant/conversations` `{ question }`, `/assistant/conversations/:id/messages` `{ question }` | Ask (up to 4000 characters). Returns at once with status `thinking`; poll the conversation until it is `idle` or `failed` |
| POST | `/assistant/conversations/:id/retry` | Ask again after a `failed` answer |
| DELETE | `/assistant/conversations/:id` | Delete it with its messages and actions |
| POST | `/assistant/actions/:id/approve`, `/assistant/actions/:id/cancel` | Run or dismiss a proposed action |

Errors: 409 `ASSISTANT_NOT_CONFIGURED` (off, or no provider), 409 `ASSISTANT_BUSY` (still answering
the last question), 429 `ASSISTANT_LIMIT` (60 questions an hour per person), 409
`ACTION_EXPIRED` / `ACTION_NOT_PENDING`. A failed conversation carries `error: { code, message }`
with codes such as `PROVIDER_AUTH_FAILED`, `PROVIDER_MODEL_NOT_FOUND`, `PROVIDER_RATE_LIMITED`,
`PROVIDER_UNREACHABLE`, `PROVIDER_REFUSED` and `ASSISTANT_TIMEOUT`.

Approving runs the action through the same service call as the matching button in the panel, as the
person approving, so their own permission is checked (403 when they lack it). The action's `status`
goes `proposed` → `running` → `succeeded` or `failed` (with its `jobId`), or `cancelled`/`expired`.

## Containers

Phase 10, `/containers`. Reading needs `containers.read` (owners, admins, developers, viewers),
start/stop/restart `containers.operate` (developers and up), logs `containers.logs` (developers and
up), and deploying, changing, removing, installing Docker and images `containers.manage` (owners and
admins). Hosting customers have no access. The server's agent must be 0.10.0 or newer
(`AGENT_OUTDATED` otherwise).

| Method | Path | Does |
| --- | --- | --- |
| GET | `/containers/servers` | Every server with what its agent last said about Docker (`docker: { installed, running, source, version }`), container counts and whether its agent supports containers |
| GET | `/containers?serverId=&search=&page=` | Containers VaultPanel deployed |
| POST | `/containers` `{ serverId, name, image, ports, volumes, env, restartPolicy, memoryMb?, cpuPercent?, command?, healthCheckSeconds }` | Deploy (202 with `{ container, job }`). `ports`: `[{ address: '127.0.0.1'\|'0.0.0.0', hostPort, containerPort, protocol }]`; `volumes`: `[{ volume, path, readOnly }]`; `env`: `[{ key, value }]` |
| GET, PATCH, DELETE | `/containers/:id` | One container; change it (any of the fields above plus `pull`; `env` replaces every variable), which deploys a replacement; remove it (`?removeVolumes=true` also deletes its volumes) |
| GET | `/containers/:id/environment` | Variable values (`containers.manage`; every read is audited) |
| POST | `/containers/:id/redeploy` `{ pull }`, `/containers/:id/start\|stop\|restart` | Deploy again with the same settings, or act on it |
| POST | `/containers/servers/:serverId/docker/status`, `/docker/install` | Read Docker's state, or install/start it |
| POST | `/containers/servers/:serverId/containers/list` | Every container Docker runs there, VaultPanel's or not |
| POST | `/containers/servers/:serverId/containers/:ref/logs` `{ lines }`, `/inspect`, `/start`, `/stop`, `/restart`, `/remove` | Any container by Docker ID (12 to 64 hex) or name; removing one VaultPanel deployed removes its record too |
| POST | `/containers/servers/:serverId/images/list`, `/images/pull` `{ image }`, `/images/remove` `{ imageId }` | Images |

The server-level requests return the queued job (202); its `output` holds the answer when it
succeeds. A deployment keeps the change in `pending` until its job succeeds; if the new container
does not stay up for `healthCheckSeconds`, the agent puts the old one back and the record keeps the
old settings with `lastError`. Host ports are checked against apps, other containers, SSH, the
panel's own port, VaultPanel's database and Redis, and 80/443 when NGINX is installed (422 with the
field). Errors: 409 `DOCKER_NOT_INSTALLED`, `DOCKER_NOT_RUNNING`, `CONTAINER_BUSY` (a deployment or
removal is running), `PROTECTED_CONTAINER` (VaultPanel's own database or Redis container).

## Plugins

Phase 10, `/plugins`, `plugins.manage` (owners and admins). Installing from a manifest, approving
its permissions, its events, its page in the panel and the plugin's own `vpp_` token: see
[plugins.md](plugins.md#api). A plugin's token is sent like an API token
(`Authorization: Bearer vpp_…`) and acts with the approved scopes only; `GET /auth/me` answers with
`plugin` instead of `user`. Plugin directories are under `/plugins/directory`: see
[plugins.md](plugins.md#plugin-directories).

## Agent endpoints

`/agent/install.sh`, `/agent/package.tgz`, `POST /agent/register` (enrollment token), and the signed
endpoints `POST /agent/heartbeat`, `GET /agent/jobs/next`, `POST /agent/jobs/:id/start|logs|result`, `POST /agent/backups/:id/chunks` (a backup copied for a
download), `GET /agent/uploads/:id/chunks/:offset` (a file uploaded in the file manager, while its `FILE_UPLOAD` job runs), `POST /agent/downloads/:id/chunks` (a site file sent for a download, while its `FILE_DOWNLOAD` job runs) and `POST /agent/cron-runs` (results of runs started by cron).
See [agent.md](agent.md).

`GET /health` reports database and Redis status (503 when either is down).
