# Development

Requirements: Node.js 22+, MariaDB 10.6+ (or MySQL 8) and Redis 6.2+. Docker can provide both.

```sh
docker compose -f docker/compose.yml up -d   # MariaDB on 127.0.0.1:3307 + Redis (creates vaultpanel and vaultpanel_test)
cp .env.example .env                          # then set VAULTPANEL_SECRET_KEY=$(openssl rand -hex 32)
npm install
npm run db:migrate
npm run dev:backend     # API on http://127.0.0.1:4000 (prints the setup token)
npm run dev:worker      # background maintenance
npm run dev:frontend    # UI on http://localhost:5173, proxies /api to the backend
```

Open http://localhost:5173/setup and create the owner with the setup token from the API log.

Started as root on Linux with systemd, `npm run dev:backend` connects the machine it runs on as a
server by itself and installs the agent as a service (see [agent.md](agent.md#the-panels-own-server)).
Set `VAULTPANEL_LOCAL_AGENT=false` in `.env` to stop that. To run an agent by hand instead, without
installing a service, add a server in the UI, then:

```sh
node agent/src/cli.js register --panel http://localhost:5173 --token vpe_… --config ./tmp/agent.json --insecure-http
node agent/src/cli.js run --config ./tmp/agent.json
```

## Checks

```sh
npm run lint
npm test        # needs MariaDB and Redis; uses .env.test (database vaultpanel_test, Redis db 15)
npm run build
npm run test:coverage   # the same tests, with a coverage summary per package
npm run test:e2e        # end-to-end smoke tests in a browser, see e2e/README.md
```

The backend suite rebuilds `vaultpanel_test` from scratch; never point `.env.test` at real data. The
end-to-end tests use their own databases (`vaultpanel_e2e`, `vaultpanel_e2e_tls`).

To try the panel with HTTPS as install.sh runs it, make a certificate and set
`VAULTPANEL_TLS_CERT`, `VAULTPANEL_TLS_KEY` (and optionally `VAULTPANEL_LOOPBACK_PORT`) in `.env`;
`e2e/scripts/start-panel.js https` shows the whole setup.

## Conventions

JavaScript (ES modules) only. Business rules live in services, not controllers. New operations are
added in three places: the catalog (`shared/src/operations.js`), the agent
(`agent/src/operations/index.js`) and a test; a backend test fails if the panel offers an operation the
agent does not implement.

The panel's development MariaDB is published on port 3307, not 3306, so a MariaDB installed on the
same server for apps (from the Software card) can use the standard port. Checkouts from before this
change: set `DATABASE_URL` in `.env` to port 3307, then run
`docker compose -f docker/compose.yml up -d` and restart the backend and worker.

The MariaDB and Redis containers restart after a reboot as long as Docker starts at boot
(`systemctl enable docker` for Docker's own packages; the snap starts at boot by itself).
