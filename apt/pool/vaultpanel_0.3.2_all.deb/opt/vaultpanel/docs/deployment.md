# Deploying the panel

The easy way is the one-command installer: see [install.md](install.md). It does everything below
for you on Ubuntu or Debian. This page is the manual way, for other systems or a custom setup.

1. Provision MariaDB and Redis. Create a database and user for the panel.
2. Build: `npm ci && npm run build` (UI files land in `frontend/dist`).
3. Configure environment variables (see `.env.example`): a fresh `VAULTPANEL_SECRET_KEY`,
   `VAULTPANEL_PUBLIC_URL=https://panel.example.com`, `VAULTPANEL_COOKIE_SECURE=true`,
   `VAULTPANEL_ALLOW_INSECURE_AGENTS=false`, `VAULTPANEL_TRUST_PROXY` set to your proxy address,
   `DATABASE_URL`, `REDIS_URL`.
4. `npm run db:migrate`.
5. Run two processes under systemd (or similar): `npm start -w @vaultpanel/backend` and
   `npm run worker -w @vaultpanel/backend`. Run them as an unprivileged user, not root (install.sh
   uses a `vaultpanel` user with a systemd sandbox; see its `install_services`), with write access
   only to `VAULTPANEL_DATA_DIR`. To serve HTTPS from the API itself instead of NGINX, set
   `VAULTPANEL_TLS_CERT` and `VAULTPANEL_TLS_KEY`; it then also answers plain HTTP on
   `127.0.0.1:VAULTPANEL_LOOPBACK_PORT` (default: the port + 1) for the local agent.
6. Put NGINX in front with TLS: serve `frontend/dist` (with `try_files $uri /index.html`) and proxy
   `/api/` to the API on 127.0.0.1:4000. Or set `VAULTPANEL_UI_DIR=/path/to/frontend/dist` and the API
   serves the interface itself, so NGINX only proxies everything to it (how the installer runs it). Allow at least 60 s read timeout for agent long polls.
7. Open `/setup` and create the owner with the setup token from the API log.
8. The server the panel runs on connects itself when the API starts as root (see
   [agent.md](agent.md#the-panels-own-server)). If the API runs as another user, run
   `sudo npm run connect-local` once from the panel's folder. Have NGINX send `X-Forwarded-For` to the
   API (`proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;`), so requests it forwards are
   never mistaken for the local agent's.

**Upgrading.** Pull the new version, `npm ci && npm run build`, `npm run db:migrate`, then restart
both processes. The panel's own agent is updated when the API starts. If a release adds agent operations, each server page shows the one-line
`--upgrade` command for its agent (see [agent.md](agent.md#upgrading)).

Back up the database and keep `VAULTPANEL_SECRET_KEY` safe; without it, two-factor secrets and the
agent signing key cannot be decrypted. With install.sh's layout, `vaultpanel backup` and
`vaultpanel restore` do this (see [install.md](install.md#backing-up-the-panel)).
