# Publishing

## Releases of VaultPanel

Servers install and update from **VaultPanel's package repository**, like CloudPanel's. This
repository is private: a release builds the `vaultpanel` package here and publishes it to the public
[VaultPanel/packages](https://github.com/VaultPanel/packages) repository, which GitHub Pages serves at
https://installer.vaultpanel.net:

| On the site               | What it is                                                                           |
| ------------------------- | ------------------------------------------------------------------------------------ |
| `apt/`                    | The APT repository: the newest 5 versions of the package, signed by VaultPanel's key |
| `v2/install.sh`           | The installer of the latest release, and `install.sh.sha256`                         |
| `downloads/`              | The WHMCS module (MIT) and its `SHA256SUMS`                                          |
| `README.md`, `index.html` | The install command with the installer's checksum, filled in for each release        |

The scripts are in `packaging/` (`build-deb.sh`, `apt-repo.sh`, `publish-site.sh`, `test-install.sh`,
the package's `debian/` files and the site's templates).

### Once

1. **The public repository.** On GitHub, create `VaultPanel/packages`, **public** and empty. In its
   **Settings > Pages**: _Deploy from a branch_, branch `main`, folder `/ (root)`; custom domain
   `installer.vaultpanel.net`, then **Enforce HTTPS** once GitHub offers it. Turn on **Issues**, and
   **Private vulnerability reporting** under **Settings > Security**: that is where users report
   problems. Recommended: verify `vaultpanel.net` in the organization's **Settings > Pages**, so no
   one else can serve its subdomains from GitHub Pages.
2. **DNS** for vaultpanel.net: a record `installer` CNAME `vaultpanel.github.io`.
3. **The deploy key** lets this repository's Release workflow push to VaultPanel/packages, and to
   nothing else. In VaultPanel/packages, **Settings > Deploy keys > Add deploy key**: title
   "VaultPanel release workflow", the deploy key's public part (`ssh-ed25519 ...`), **Allow write
   access** ticked.
4. **Two secrets** in this repository, under **Settings > Secrets and variables > Actions > New
   repository secret**:
   - `VAULTPANEL_PACKAGES_SIGNING_KEY`: the package-signing key's secret part, the whole
     `-----BEGIN PGP PRIVATE KEY BLOCK-----` text. Its public part is
     `packaging/vaultpanel-packages.asc`, fingerprint `79B34D79D2A7D0DE54A3D906B62A47C2ED2775A6`,
     which `install.sh` trusts.
   - `PACKAGES_DEPLOY_KEY`: the deploy key's secret part, the whole
     `-----BEGIN OPENSSH PRIVATE KEY-----` text.

   **Keep a copy of the signing key somewhere safe**, such as a password manager. Servers trust exactly
   this key: losing it means a new key, a new `install.sh`, and putting the new key on every server
   by hand.

5. Make this repository **private** (**Settings > General > Danger Zone > Change visibility**).

### Each release

1. Move the **Unreleased** notes in `CHANGELOG.md` under a new `## [X.Y.Z] - YYYY-MM-DD` heading and
   merge that to `main`. Raise `agent/package.json` too when the agent changed (servers' agents are
   updated from the panel when its version is newer).
2. Tag the commit and push the tag:

   ```sh
   git tag -a v0.2.0 -m "VaultPanel v0.2.0"
   git push origin v0.2.0
   ```

The **Release** workflow then runs lint, every test and the build. The **Package** workflow builds
`vaultpanel_0.2.0_all.deb` and installs it on a fresh runner from a signed copy of the site, following
the published install command, then checks an upgrade and `vaultpanel update`. Only then does the
package go to VaultPanel/packages, and the release, with the package, appears in this repository.
Servers get it with `sudo vaultpanel update` or `apt upgrade`.

A pre-release tag such as `v1.0.0-rc.1` is built and checked but not published, so servers never get
it by accident. Never move or delete a published tag.

The **Package** workflow also runs by hand (**Actions > Package > Run workflow**) and when
`install.sh`, `packaging/` or `scripts/vaultpanel.sh` change on `main`, so problems show up before a
release. On GitHub's free plan a private repository has 2,000 Actions minutes a month; a package check
takes about 10 of them.

## The SDK and CLI on npm

`@vaultpanel/sdk` and `@vaultpanel/cli` are ready to publish: MIT licensed, each with its own README
and LICENSE, and the CLI depends only on the SDK. Nothing is published until the repository owner
does the steps below.

### Once

1. Sign in at [npmjs.com](https://www.npmjs.com) and create a free organization named `vaultpanel`
   (the `@vaultpanel` scope; the unscoped name `vaultpanel` is taken by someone else).
2. Under your npm account, **Access Tokens > Generate New Token**, type **Automation** (or a granular
   token with publish rights on `@vaultpanel`).
3. In GitHub, **Settings > Secrets and variables > Actions > New repository secret**, named
   `NPM_TOKEN`, holding that token.

### Each release

1. Raise `version` in `sdk/package.json` and/or `cli/package.json` (npm never accepts the same
   version twice). When the CLI needs a newer SDK, raise its `@vaultpanel/sdk` range too, then run
   `npm install` so the lockfile follows, and merge the change.
2. In GitHub, **Actions > Publish SDK and CLI to npm > Run workflow**. Leave **Dry run** ticked first
   to see what would be packed, then run it again unticked.

The workflow lints, runs the SDK and CLI tests, checks the CLI stands alone, then publishes the SDK
before the CLI and skips any version already on npm.

To publish from your own computer instead: `npm login`, then
`npm publish -w @vaultpanel/sdk && npm publish -w @vaultpanel/cli`.

npm only accepts provenance (which commit each version was built from) from public repositories,
so with this repository private the SDK and CLI are published without it.

See also: [SDK](sdk.md) · [Command-line tool](cli.md)
