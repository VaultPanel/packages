# Roadmap

| Phase | Scope | State |
| --- | --- | --- |
| 0 | Architecture, monorepo, database layer, CI, docs | Done |
| 1 | Sign-in, 2FA, users, roles and permissions, audit log, dashboard, agent registration, job system | Foundation done (see below) |
| 2 | Server management and monitoring: richer metrics, service management, process actions, alerts | Done, except notifications (see below) |
| 3 | Websites, domains, NGINX, PHP-FPM, SSL, file manager | Done, except the items below |
| 4 | Node.js/Python apps, databases, Git deployment, PM2 | Done, except the items below |
| 5 | Backups, cron jobs, automation, logs | Done, except the items below |
| 6 | Security hardening, isolation, firewall, auditing | Done, except the items below |
| 7 | Multi-server management: server groups, bulk actions, agent updates from the panel | Done, except the items below |
| 8 | Hosting plans, customers, quotas, a billing API for WHMCS, Blesta and similar | Done, except the items below |
| 9 | AI assistant: questions answered from the panel's own data, fixes proposed for approval | Done, except the items below |
| 10 | Containers, plugins, CLI, SDKs, API tokens, scaling | Parts 1 to 3 (containers; API tokens, CLI and SDK; plugins) done; scaling an app on its own server done; across servers not started (see below) |

## Left in Phase 1

- Custom roles

Recovery codes and the session list came with Phase 6. Invite and password reset links are emailed
when panel email is set up (**System > Panel Email**), with "Forgot password?" on the sign-in page.

## Left in Phase 2

Nothing: alerts are sent by email from **System > Panel Email** (pick the events and who gets them),
and by webhook (JSON, Slack, Discord, from Phase 5).

Done since: website uptime monitoring from the panel (status, certificate as served, uptime
percentages, downtime history and a **Website down** alert rule). Not built: checks from more than
one location, custom paths, expected text or status codes per website, a public status page, and
alerting customers about their own websites.

Done since (agent 0.39.0): a **server self-check** on each server's Overview (root helper, agent
files, the file manager's worker, `nginx -t`, `apache2ctl -t`, Certbot's timer, clock, failed units)
with a **Server self-check failed** alert rule. Not built: repairing a failed check from the panel.

## Left in Phase 3

- DNS zone management (records are created at your DNS provider; the panel checks they point at the
  right server)
- Apache, and per-site resource limits (CPU, memory, disk quotas) for PHP sites (apps got CPU and
  memory limits in Phase 6)

## Left in Phase 4

- PostgreSQL and Redis (shown as "Coming later" on the Databases page)
- Database import and export, and remote (non-local) database access (a web SQL client came later: open a database on the Databases page)
- Docker-based apps (several copies of an app came later: the app's **Scaling** card, see "Scaling
  apps" below; Go and Ruby apps, PHP websites from Git, signed webhooks and zero-downtime reloads for
  Node.js apps came with agent 0.32.0)
- Zero-downtime reloads for Python, Go and Ruby apps (Node.js apps have them); shared folders that
  survive deploys for PHP sites deployed from Git (uploads, Laravel's `storage/`)

## Left in Phase 5

- Backup storage off the server came later: Backups > Storage holds S3-compatible buckets (Amazon
  S3, Backblaze B2, Wasabi, Cloudflare R2, MinIO) and other servers over SFTP
- Restoring a backup into a new website, app or database, or onto another server (restores go back
  in place)
- Encrypted backups, and backups of the whole server or of mail
- One backup holding a website's or app's files and its database together (its Backups tab backs
  up and restores each on its own)
- Cron jobs as root or with shell features (pipes, redirects); a wrapper script in the site folder
  can do those as the site's user
- Shipping logs to an outside service, and log files other than the journal, NGINX and app logs

## Left in Phase 6

- Running operations with less than root: the agent runs as its own user from 0.36.0, but what the
  panel signs still runs as root in its helper. Narrower helpers per kind of operation (packages,
  NGINX, users, systemd) are not built
- Firewall: routed traffic, and editing rules added outside VaultPanel (they are listed, but changed
  with `ufw` on the server). firewalld (RHEL, Fedora) is not supported; UFW only. Outgoing rules and
  the outgoing default came with agent 0.34.0
- SSH: limiting SSH to some addresses (VaultPanel keeps SSH open to everyone so it can never lock you
  out). Changing the SSH port and keys for accounts other than root came with agent 0.34.0
- Email alerts about sign-ins (restricting the panel to some IP addresses came later: Security >
  Authentication > Panel access by address)
- Disk quotas and chroot isolation for sites; separate database users for migrations and runtime
- Viewing the packages a security update would install before installing it

## Left in Phase 7

- Limiting users to some servers or groups (every user with a permission has it on every server);
  this comes with teams and customers in Phase 8
- Moving or copying a website, app or database to another server, and restoring a backup onto
  another server
- Bulk actions for more operations (installing software, firewall rules, SSH keys on many servers),
  scheduled bulk actions, and webhooks when a bulk action finishes
- Private networking between servers, load balancing an app across servers, and database
  replication
- Rolling back an agent update from the panel (the previous version is kept on the server in
  `/opt/vaultpanel-agent.previous`)

## Left in Phase 8

- Limiting staff users to some servers or groups (every staff user with a permission still has it on
  every server; customers only ever see their own account)
- Taking payments, invoices and tax inside VaultPanel. A billing system (WHMCS, Blesta, your own)
  charges customers and calls the [billing API](api.md#hosting-and-billing). A WHMCS module is in
  [integrations/whmcs](../integrations/whmcs/README.md) (create, suspend, upgrade, terminate,
  password, single sign-on, disk usage); there is no Blesta module yet
- Email: welcome messages, and warnings when an account nears or passes a limit (invite and reset
  links are emailed when panel email is set up)
- Bandwidth limits, mail accounts, FTP accounts, and subdomain or addon-domain counts as separate
  limits
- Hard disk quotas enforced by the file system: the disk limit stops new websites, apps and
  databases once reached (folders are measured about every 15 minutes), but a site can still grow
  past it until it is measured
- Customers adding their own SSH keys, changing PHP versions server-wide, or seeing server logs and
  metrics; resellers (customers with their own customers)
- Moving a customer to another server with their sites (the account's server can be changed; it only
  affects where new things are created)

## Left in Phase 9

- Hosting customers cannot use the assistant (staff only for now)
- Answers appear when they are complete, not word by word
- One provider and key for the whole panel; no per-user keys or spending limits beyond 60 questions
  an hour per person
- The assistant reads status, logs, processes and listening ports, but not website files, database
  contents, firewall rules or backups, and its proposals cover restarts, starts, stops, deploys,
  rollbacks, re-applying settings, retrying websites, renewing certificates and installing
  software, not editing files or settings
- A proposed action that nobody approves within 60 minutes expires

## Phase 10, part 1: Docker containers

Done: installing or starting Docker from the panel (Ubuntu's package, or the snap when that is what
the server has), deploying images from public registries with ports, named volumes, environment
variables, restart policy and CPU/memory limits, replacing a container with an automatic rollback
when the new one does not stay up, start/stop/restart, logs and live details, every container Docker
runs (including ones started by hand or by Compose), and images (pull, remove). The containers
VaultPanel's own database and Redis run in are refused for stop, restart and removal.

## Phase 10, part 2: API tokens, the command-line tool and the SDK

Done: API tokens (Users > API Tokens) that let scripts call the REST API as the person who made
them, narrowed to scopes (`read`, `logs`, `deploy`, `manage hosting`, `servers`, `customers`,
`everything`), optionally expiring, shown once and revocable at any time; a `@vaultpanel/sdk`
JavaScript client for the whole API, with pagination and job waiting; and the `vaultpanel`
command-line tool built on it, with profiles, named lookups, `--watch` for jobs, `--json` output
and meaningful exit codes. See [api.md](api.md#api-tokens), [sdk.md](sdk.md) and [cli.md](cli.md).

The SDK and CLI are ready to publish to npm as `@vaultpanel/sdk` and `@vaultpanel/cli` (MIT, a
manual GitHub workflow; see [publishing.md](publishing.md)) but are not published yet.

Not built: a Python SDK,
tokens that belong to the panel rather than to a person, and per-token IP allowlists.

## Phase 10, part 3: plugins

Done: plugins as separate programs that work with the panel through its API. An owner or admin
installs one from its manifest (by URL or pasted), sees what it asks for in words and approves it;
the plugin then gets its own `vpp_` token with the approved scopes, receives the panel events it
subscribed to (signed, retried, with a delivery history and a test button) and can add a page to
the sidebar, opened in a sandboxed frame with a signed link that says who is looking. Plugins can
be turned off, updated (with approval again when the manifest changes), given new credentials and
removed. The SDK has `verifyEvent` and `verifyLaunch` for plugin authors, and
`examples/status-board-plugin` is a working example. See [plugins.md](plugins.md).

Plugin directories: an owner or admin adds the URL of a directory (a JSON list of plugins published
by a plugin author, a hosting company or a team), browses and searches its plugins on
**Plugins → Directory** and installs one through the usual review and approval of its own
manifest. Directories are read again every 12 hours, and installed plugins show when a directory
lists a newer version. No directory is built in. See [plugins.md](plugins.md#plugin-directories).

Not built: a central VaultPanel marketplace (ratings, reviews, paid plugins), plugins adding panels to existing pages (only pages
of their own), settings forms the panel draws for a plugin, more events (website and app changes,
sign-ins), and plugins running inside the panel's process (not planned: they stay outside on
purpose).

## One-command installer

Done: `install.sh` installs VaultPanel on a fresh Ubuntu or Debian server with one command (Node.js
22, Docker, the panel's own MariaDB and Redis with generated passwords, the built interface served
by the API on port 8090, systemd services that start at boot, This server connected). Running it
again updates in place. The `vaultpanel` command on the server shows the address and status, reads
logs, restarts, updates and changes the panel's address, and passes everything else to the CLI; an
SSH login shows the VaultPanel banner. See [install.md](install.md).

Done since: the panel runs as its own unprivileged `vaultpanel` user in a systemd sandbox; HTTPS from
the first start with a self-signed certificate and agent installs pinned to it (`vaultpanel https`);
daily backups of the panel itself with restore on a new server (`vaultpanel backup`, `vaultpanel
restore`); releases (`vX.Y.Z` tags with `SHA256SUMS` and provenance), `--version`, updates that back
up first, and `vaultpanel rollback`. See [install.md](install.md).

Not built: a trusted certificate straight from the installer (a panel domain gives one, see
install.md), other Linux distributions, uninstalling with one command, copying panel backups to the
S3 or SFTP storage set up in **Backups > Storage** (`VAULTPANEL_BACKUP_UPLOAD` runs any command
instead), and installing without git (the installer clones the repository, so it must be public for
the one-line command).

## Server terminal

Done (agent 0.11.0): owners open a root shell on any server from the panel, under **Terminal** in the
sidebar or a server's **Terminal** tab. It runs through the agent's own signed WebSocket, not the
operation allow-list, and works over the dev server, the installed panel and the panel domain. Copy
and paste work over plain HTTP. Opening and closing are in the audit log. See [agent.md](agent.md).

Done: sessions are recorded in the panel (asciicast v2, screen by default, typed keys when turned
on) with retention and a size limit, and owners replay or download them under **Terminal > Sessions
and recordings**.

Not built: giving the terminal to admins or other roles,
shells as a user other than root, and uploading files by dragging them onto the terminal.

## Scaling apps

Done on one server (agent 0.14.0): an app's **Scaling** card sets how many copies run, from 1 to 16.
Node.js apps run them in PM2 cluster mode: the copies share the app's port and PM2 spreads connections
between them; changing only the number adds or removes copies while the others keep serving. The
start command must run a Node.js file (`node server.js`, `node_modules/.bin/next start`), not
`npm start`. Python apps get `WEB_CONCURRENCY`, which Gunicorn and Uvicorn use as their number of
workers. The app's CPU and memory limits cover all copies together. See [api.md](api.md).

Not built: running one app on several servers with a load balancer in front, scaling automatically
on load, zero-downtime restarts and deployments (`pm2 reload`), and a per-plan limit on copies for
hosting customers (their plan's CPU and memory caps still cover all copies).

## DNS zones

Done (agent 0.15.0): **Web > DNS Zones** serves domains from the panel's own servers with BIND, like
cPanel or CyberPanel. **Set up DNS** installs BIND on a server as an authoritative-only name server and
opens port 53. A new zone starts with NS, A (`@`, `www`), name server glue and, if asked, mail
records; records of type A, AAAA, CNAME, MX, TXT, NS, SRV and CAA can then be added, edited and
removed. Each change is checked with `named-checkzone` before it goes live, and the page shows when
the server serves the latest version. **Check now** asks public DNS whether the registrar points the
domain at these name servers.

Done (agent 0.38.0): **DNS providers** on the same page hold Cloudflare and Namecheap API credentials,
so domains whose DNS stays there get Let's Encrypt wildcard certificates; renewals go through the
provider too.

Not built: secondary name servers on a second panel server (zone transfers), DNSSEC, importing a zone
file or from another provider, customers managing their own zones, other DNS providers
(DigitalOcean, Route 53…), managing a provider's records from the panel beyond the certificate check,
checking a provider's credentials when they are saved, and email hosting (next).

## Email hosting

Done (agent 0.16.0): **Web > Email** hosts email on the panel's own servers. **Set up email** installs
Postfix, Dovecot and OpenDKIM with a mail host name (such as `mail.example.com`). Each domain gets
mailboxes (IMAP and POP3, size limits, on or off) and forwarders; mailbox passwords are hashed by the
panel. Outgoing mail is DKIM-signed, and when VaultPanel runs the domain's DNS its MX, SPF, DKIM and
DMARC records are added to the zone. **Check DNS** looks up the host name and the server's reverse DNS,
and a domain's DNS records tab can ask public DNS for its records.

Not built: webmail (such as Roundcube), spam and virus filtering (such as Rspamd), autoresponders and
filters, catch-all addresses, sending limits, customers managing their own email, mail backups, and
plan quotas for mailboxes.

## PHP versions per website

Done (agent 0.17.0): a server's **Websites** tab has a **PHP versions** card where staff install PHP
7.4 and 8.0 to 8.5 next to the system's own (from the ondrej/php repository on Ubuntu or
packages.sury.org on Debian when the system lacks the version) and remove versions no site uses. Each
PHP website, a customer's included, picks one of the installed versions when it is created, in its
settings, or on the **PHP version** card of its Overview.

Not built: per-plan lists of allowed PHP versions, per-site php.ini settings, and choosing extra PHP
extensions.

## Custom NGINX rules

Done (agent 0.18.0): staff add NGINX rules to a website on its Settings tab (redirects, rewrites,
headers, extra locations, caching), the vhost equivalent of cPanel's .htaccess. Only a fixed list of
directives is accepted, checked in the panel and again by the agent, and `nginx -t` must pass.
Customers cannot edit them. NGINX does not read .htaccess files.

## .htaccess files

Done (agent 0.18.0): Apache can be installed from a server's Web stack card. It listens on
127.0.0.1:8080 only, behind NGINX, which keeps ports 80 and 443 and the certificates. A website's
Settings tab has **Use .htaccess files** (customers can turn it on too): NGINX then passes the site to
Apache, which reads its .htaccess files and hands PHP to the site's own PHP-FPM pool. .htaccess files
may rewrite (WordPress and Laravel rules work), redirect, set headers and caching, protect folders
with a password and change indexes; `SetHandler`, `SetEnv`, `FollowSymLinks` and PHP settings sent
with a request are refused. Apache runs as its own user `vp-apache`, which is in the groups of
.htaccess sites only and owns only their PHP sockets, so one site's .htaccess cannot reach another
site's files or the default PHP pool.

Not built: letting customers write their own NGINX rules, `php_value` lines in .htaccess, and Apache
modules beyond rewrite, headers, expires and the basics.

## Single-page apps

Done (agent 0.30.0): a static website's Settings tab has **Single-page app** (customers too). NGINX
then answers addresses with no file of their own with `index.html`, so React, Vue and Angular
routes survive a refresh.

## Left in Phase 10

- Private registries (logging in to Docker Hub accounts, GHCR or your own registry)
- Docker Compose files and multi-container stacks; building images from a Git repository
- Mounting folders of the server (bind mounts) and choosing other networks
- Backups of container volumes; moving containers between servers
- Container metrics history and alerts (live CPU and memory show on a container's page)
- Running one app across several servers with a load balancer, and scaling on load

## First full target

One Node.js application deployed end to end on the owner's own server (domain, reverse proxy,
SSL, process manager, database), in Phases 3 and 4. Reached in Phase 4: see "Trying Phase 4" in the
testing guide.
