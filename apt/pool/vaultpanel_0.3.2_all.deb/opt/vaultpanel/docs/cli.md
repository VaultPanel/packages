# Command-line tool

`vaultpanel` does from a terminal what the panel does in a browser: list servers, create websites,
deploy applications, run containers, take backups and follow jobs. It talks to the REST API with an
API token, so it needs no access to the server itself and can never do more than the person whose
token it carries.

It lives in the `cli` workspace of this repository and is built on the [SDK](sdk.md).

## Install

The packages are ready for npm but not published yet ([publishing.md](publishing.md)). Once they
are, on any computer with Node.js 22 or newer:

```bash
npm install -g @vaultpanel/cli  # then: vaultpanel --help
npx @vaultpanel/cli --help      # or without installing
```

Until then, from a clone of this repository:

```bash
git clone https://github.com/VaultPanel/VaultPanel.git
cd VaultPanel
npm install
npm link -w @vaultpanel/cli     # then: vaultpanel --help
```

The CLI depends only on `@vaultpanel/sdk`. It asks the panel which token scopes exist
(`GET /api-tokens/scopes`), so an older CLI still describes a newer panel correctly.

## Sign in

Create a token in the panel under **Users > API Tokens**, tick what it should be allowed to do,
then:

```bash
vaultpanel login --url https://panel.example.com
# API token: (pasted, not shown)
vaultpanel whoami
```

`login` checks the token against the panel before saving it in
`~/.config/vaultpanel/config.json` (mode 0600). More than one panel:

```bash
vaultpanel login --url https://staging.example.com --profile staging
vaultpanel servers list --profile staging
vaultpanel profiles --use staging     # make it the default
vaultpanel logout --profile staging   # forget it (the token stays valid until revoked)
```

In CI, skip the config file entirely:

```bash
export VAULTPANEL_URL=https://panel.example.com
export VAULTPANEL_TOKEN=vpt_…
vaultpanel apps deploy api --watch
```

`VAULTPANEL_CONFIG` moves the config file; `--url` and `--token` override everything.

## Commands

Run `vaultpanel --help` for the list, `vaultpanel servers --help` for one group and
`vaultpanel apps deploy --help` for one command.

| Command                                                                          | Does                                                                                     |
| -------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| `whoami`, `tokens [--all] [--scopes]`                                            | Who the token belongs to and what it may do; your tokens, or the scopes you can give one |
| `dashboard`                                                                      | The dashboard numbers                                                                    |
| `servers list\|show\|add\|remove\|groups`                                        | Servers. `add` prints the agent install command                                          |
| `servers operations`, `servers run <server> <OPERATION> --params '{…}'`          | The agent's allowlisted operations, and running one                                      |
| `servers services <server> [--restart nginx]`, `servers reboot <server> --force` | Services and reboots                                                                     |
| `websites list\|show\|create\|ssl\|logs\|enable\|disable\|delete`                | Websites, certificates and logs                                                          |
| `apps list\|show\|deploy\|rollback\|restart\|logs\|env\|deployments`             | Applications                                                                             |
| `databases list\|create\|delete\|users`                                          | MariaDB databases and their users                                                        |
| `containers list\|deploy\|restart\|logs\|remove`                                 | Docker containers                                                                        |
| `backups list\|create\|restore`                                                  | Backups and restores                                                                     |
| `cron list\|run\|runs`                                                           | Cron jobs                                                                                |
| `alerts list\|acknowledge`                                                       | Alerts                                                                                   |
| `jobs list\|show\|watch\|cancel`                                                 | Background jobs                                                                          |
| `api <METHOD> <path>`                                                            | Any endpoint, printing the whole reply envelope                                          |

Things are named, not numbered: `vaultpanel apps deploy api` finds the app called `api` (an id works
too). A name that matches more than one thing is an error rather than a guess.

Anything that deletes, removes or reboots needs `--force`, so a typo in a script does not take a
site down.

## Jobs

Long operations (deployments, website creation, SSL, backups, container deployments) run in the
panel's queue. Those commands print the job id; `--watch` follows it, prints its log and exits
non-zero if it does not succeed:

```bash
vaultpanel apps deploy api --watch
vaultpanel jobs watch 2f6c…
```

## Output

Tables by default; `--json` prints what the API returned, for `jq`:

```bash
vaultpanel servers list --json | jq -r '.[] | select(.status != "connected") | .name'
vaultpanel api GET /websites --query 'serverId=…' | jq '.data.items | length'
```

## Exit codes

| Code | Means                                                            |
| ---- | ---------------------------------------------------------------- |
| 0    | It worked                                                        |
| 1    | The command was used wrongly, or something local failed          |
| 2    | The panel refused the request, or a watched job failed           |
| 3    | The token is not valid any more, or its scopes do not cover this |

## Examples

Deploy on every green build:

```bash
#!/usr/bin/env bash
set -euo pipefail
export VAULTPANEL_URL=https://panel.example.com
export VAULTPANEL_TOKEN="$VAULTPANEL_DEPLOY_TOKEN"   # scopes: deploy
vaultpanel apps deploy api --watch
```

Back up every website before a risky change:

```bash
for site in $(vaultpanel websites list --json | jq -r '.[].name'); do
  vaultpanel backups create --type website --resource "$site" --watch
done
```

Restart a service on one server:

```bash
vaultpanel servers services web-1 --restart nginx --watch
```

See also: [API](api.md) · [SDK](sdk.md) · [Testing guide](testing-vaultpanel.md)
