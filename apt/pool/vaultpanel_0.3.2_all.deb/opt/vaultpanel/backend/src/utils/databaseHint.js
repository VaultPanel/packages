// What to do when the panel cannot reach its own database, for the backend
// and migration logs. Returns null when there is nothing specific to say.
export function databaseHint(err, databaseUrl = '') {
  const code = err?.code ?? err?.errors?.[0]?.code;
  if (!['ECONNREFUSED', 'ER_ACCESS_DENIED_ERROR'].includes(code)) return null;
  if (/:3306\//.test(databaseUrl)) {
    return "docker/compose.yml now publishes the panel's MariaDB on 127.0.0.1:3307, leaving 3306 for the server's own MariaDB. If you use it, change DATABASE_URL in .env to port 3307.";
  }
  if (code === 'ECONNREFUSED') {
    return "Nothing answers at DATABASE_URL. If the panel's MariaDB runs in Docker, start it with: docker compose -f docker/compose.yml up -d (and make sure Docker itself starts at boot).";
  }
  return null;
}
