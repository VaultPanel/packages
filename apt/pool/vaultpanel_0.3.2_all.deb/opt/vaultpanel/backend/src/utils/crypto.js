import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  hkdfSync,
  randomBytes,
  timingSafeEqual,
} from 'node:crypto';

// Derives independent subkeys from the master secret so one key is never used
// for two purposes.
export function deriveKey(masterKey, purpose) {
  return Buffer.from(hkdfSync('sha256', masterKey, Buffer.alloc(0), `vaultpanel:${purpose}`, 32));
}

// AES-256-GCM for secrets at rest. Format: v1.<iv>.<tag>.<ciphertext> (base64).
export function createSecretBox(key) {
  if (key.length !== 32) throw new Error('Secret box key must be 32 bytes');
  return {
    seal(plaintext) {
      const iv = randomBytes(12);
      const cipher = createCipheriv('aes-256-gcm', key, iv);
      const ct = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
      return ['v1', iv.toString('base64'), cipher.getAuthTag().toString('base64'), ct.toString('base64')].join('.');
    },
    open(sealed) {
      const [version, iv, tag, ct] = String(sealed).split('.');
      if (version !== 'v1' || !iv || !tag || !ct) throw new Error('Unsupported sealed value');
      const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64'));
      decipher.setAuthTag(Buffer.from(tag, 'base64'));
      return Buffer.concat([decipher.update(Buffer.from(ct, 'base64')), decipher.final()]).toString('utf8');
    },
  };
}

export function sha256Hex(value) {
  return createHash('sha256').update(value).digest('hex');
}

export function hmacHex(key, value) {
  return createHmac('sha256', key).update(value).digest('hex');
}

export function newToken(bytes = 32) {
  return randomBytes(bytes).toString('base64url');
}

export function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && timingSafeEqual(left, right);
}

// Stable JSON (sorted keys) so equal objects hash equally.
export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`)
      .join(',')}}`;
  }
  return JSON.stringify(value);
}
