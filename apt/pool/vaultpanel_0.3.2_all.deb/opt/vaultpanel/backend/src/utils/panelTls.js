import { createHash, createPrivateKey, X509Certificate } from 'node:crypto';
import { readFileSync } from 'node:fs';
import path from 'node:path';

// The certificate the panel serves HTTPS with on its own port (VAULTPANEL_TLS_CERT
// and VAULTPANEL_TLS_KEY). install.sh makes a self-signed one, so the panel is
// HTTPS from its first start, like Cockpit, Webmin or Proxmox. Browsers warn
// about it once; agents on other servers trust exactly this certificate,
// because their install command carries its public key pin (agentPinFor).
export function loadPanelTls(certPath, keyPath) {
  const certFile = path.resolve(certPath);
  const keyFile = path.resolve(keyPath);
  let certPem;
  let keyPem;
  try {
    certPem = readFileSync(certFile, 'utf8');
    keyPem = readFileSync(keyFile, 'utf8');
  } catch (err) {
    throw new Error(`Cannot read the panel's TLS certificate or key (${err.code ?? err.message}). Check VAULTPANEL_TLS_CERT and VAULTPANEL_TLS_KEY, or run: sudo vaultpanel https on`, { cause: err });
  }
  let cert;
  try {
    cert = new X509Certificate(certPem);
  } catch {
    throw new Error(`${certFile} is not a PEM certificate (VAULTPANEL_TLS_CERT)`);
  }
  try {
    const key = createPrivateKey(keyPem);
    if (!cert.checkPrivateKey(key)) throw new Error('mismatch');
  } catch {
    throw new Error(`The key in ${keyFile} does not belong to the certificate in ${certFile} (VAULTPANEL_TLS_KEY)`);
  }
  return Object.freeze({
    certPath: certFile,
    keyPath: keyFile,
    certPem,
    keyPem,
    pin: spkiPin(cert),
    selfSigned: cert.issuer === cert.subject && cert.verify(cert.publicKey),
    validTo: new Date(cert.validTo).toISOString(),
    fingerprint256: cert.fingerprint256,
  });
}

// The pin curl's --pinnedpubkey and the agent's install script expect:
// sha256// plus the base64 SHA-256 of the certificate's public key (SPKI).
export function spkiPin(certOrPem) {
  const cert = typeof certOrPem === 'string' ? new X509Certificate(certOrPem) : certOrPem;
  const spki = cert.publicKey.export({ type: 'spki', format: 'der' });
  return `sha256//${createHash('sha256').update(spki).digest('base64')}`;
}

// The pin agents need to reach the panel at its current address, or null when
// that address is not served by the panel's own certificate: plain HTTP, or a
// domain behind NGINX with a trusted (Let's Encrypt) certificate.
export function agentPinFor(config) {
  if (!config.tls?.selfSigned) return null;
  let url;
  try {
    url = new URL(config.publicUrl);
  } catch {
    return null;
  }
  if (url.protocol !== 'https:') return null;
  const port = Number(url.port || 443);
  return port === config.port ? config.tls.pin : null;
}

// curl options for downloading from the panel: a pinned public key instead of
// a certificate authority, when the panel uses its self-signed certificate.
export function curlTlsOptions(pin) {
  return pin ? `--pinnedpubkey '${pin}' -k ` : '';
}
