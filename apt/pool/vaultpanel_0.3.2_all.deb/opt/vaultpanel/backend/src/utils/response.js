// Every API response has the same envelope:
// { success, data, message, requestId } or { success: false, error, requestId }.
export function sendOk(res, data = null, { message = 'OK', status = 200 } = {}) {
  return res.status(status).json({ success: true, data, message, requestId: res.locals.requestId });
}

export function sendError(res, status, error) {
  return res.status(status).json({ success: false, error, requestId: res.locals.requestId });
}
