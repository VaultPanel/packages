import { createHash, generateKeyPairSync, randomBytes } from 'node:crypto';

// Ed25519 key pairs in OpenSSH's own formats, made with Node's crypto (no
// ssh-keygen needed): the private key as an "OPENSSH PRIVATE KEY" block
// (unencrypted, as ssh-keygen -N '' writes it) and the public key as one
// authorized_keys line.

function sshString(buf) {
  const data = Buffer.isBuffer(buf) ? buf : Buffer.from(buf);
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  return Buffer.concat([len, data]);
}

const uint32 = (n) => {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n);
  return b;
};

export function sshFingerprint(blob) {
  return `SHA256:${createHash('sha256').update(blob).digest('base64').replace(/=+$/, '')}`;
}

export function generateSshKeyPair(comment = 'vaultpanel-backups') {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');
  const pub = Buffer.from(publicKey.export({ format: 'jwk' }).x, 'base64url');
  const seed = Buffer.from(privateKey.export({ format: 'jwk' }).d, 'base64url');
  const pubBlob = Buffer.concat([sshString('ssh-ed25519'), sshString(pub)]);
  const check = randomBytes(4);
  let priv = Buffer.concat([check, check, sshString('ssh-ed25519'), sshString(pub), sshString(Buffer.concat([seed, pub])), sshString(comment)]);
  const pad = [];
  for (let i = 1; (priv.length + pad.length) % 8 !== 0; i += 1) pad.push(i);
  priv = Buffer.concat([priv, Buffer.from(pad)]);
  const body = Buffer.concat([Buffer.from('openssh-key-v1\0'), sshString('none'), sshString('none'), sshString(''), uint32(1), sshString(pubBlob), sshString(priv)]);
  const lines = body.toString('base64').match(/.{1,70}/g).join('\n');
  return {
    privateKey: `-----BEGIN OPENSSH PRIVATE KEY-----\n${lines}\n-----END OPENSSH PRIVATE KEY-----\n`,
    publicKey: `ssh-ed25519 ${pubBlob.toString('base64')} ${comment}`,
    fingerprint: sshFingerprint(pubBlob),
  };
}
