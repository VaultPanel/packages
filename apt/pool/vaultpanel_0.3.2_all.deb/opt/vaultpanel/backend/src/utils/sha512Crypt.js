import { createHash, randomBytes } from 'node:crypto';

// SHA512-CRYPT ($6$), the password hash Dovecot checks mailbox passwords
// against (glibc's crypt, specified at https://akkadia.org/drepper/SHA-crypt.txt).
// The panel hashes mailbox passwords so the agent and the job queue never
// see them.

const ITOA64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const DEFAULT_ROUNDS = 5000;

const sha512 = (...parts) => {
  const h = createHash('sha512');
  for (const p of parts) h.update(p);
  return h.digest();
};

function repeatTo(digest, length) {
  const out = Buffer.alloc(length);
  for (let i = 0; i < length; i += 64) digest.copy(out, i, 0, Math.min(64, length - i));
  return out;
}

function encode64(b2, b1, b0, n) {
  let w = (b2 << 16) | (b1 << 8) | b0;
  let out = '';
  for (let i = 0; i < n; i += 1) {
    out += ITOA64[w & 0x3f];
    w >>= 6;
  }
  return out;
}

const ORDER = [
  [0, 21, 42], [22, 43, 1], [44, 2, 23], [3, 24, 45], [25, 46, 4], [47, 5, 26], [6, 27, 48],
  [28, 49, 7], [50, 8, 29], [9, 30, 51], [31, 52, 10], [53, 11, 32], [12, 33, 54], [34, 55, 13],
  [56, 14, 35], [15, 36, 57], [37, 58, 16], [59, 17, 38], [18, 39, 60], [40, 61, 19], [62, 20, 41],
];

export function sha512Crypt(password, salt = randomSalt(), rounds = DEFAULT_ROUNDS) {
  const key = Buffer.from(String(password), 'utf8');
  const s = Buffer.from(String(salt).slice(0, 16), 'utf8');
  const r = Math.min(999_999_999, Math.max(1000, rounds));

  const b = sha512(key, s, key);
  const a = createHash('sha512').update(key).update(s);
  a.update(repeatTo(b, key.length));
  for (let n = key.length; n > 0; n >>= 1) a.update(n & 1 ? b : key);
  let digest = a.digest();

  const dp = createHash('sha512');
  for (let i = 0; i < key.length; i += 1) dp.update(key);
  const p = repeatTo(dp.digest(), key.length);
  const ds = createHash('sha512');
  for (let i = 0; i < 16 + digest[0]; i += 1) ds.update(s);
  const sBytes = repeatTo(ds.digest(), s.length);

  for (let i = 0; i < r; i += 1) {
    const c = createHash('sha512');
    c.update(i & 1 ? p : digest);
    if (i % 3) c.update(sBytes);
    if (i % 7) c.update(p);
    c.update(i & 1 ? digest : p);
    digest = c.digest();
  }

  let out = '';
  for (const [x, y, z] of ORDER) out += encode64(digest[x], digest[y], digest[z], 4);
  out += encode64(0, 0, digest[63], 2);
  return `$6$${r === DEFAULT_ROUNDS ? '' : `rounds=${r}$`}${s.toString('utf8')}$${out}`;
}

export function randomSalt() {
  const bytes = randomBytes(16);
  let salt = '';
  for (const byte of bytes) salt += ITOA64[byte & 0x3f];
  return salt;
}
