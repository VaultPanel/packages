import { hmacHex, safeEqual } from './crypto.js';

// Push-to-deploy webhooks are signed with a secret VaultPanel gives out with
// the webhook URL, so a leaked URL alone cannot start a deployment.
//
//   GitHub, Gitea, Forgejo, Bitbucket: an HMAC-SHA256 of the body, in
//     X-Hub-Signature-256 ("sha256=<hex>"), X-Gitea-Signature or
//     X-Forgejo-Signature ("<hex>"), or X-Hub-Signature ("sha256=<hex>").
//   GitLab: the secret itself, in X-Gitlab-Token.
//
// get(name) reads a request header. rawBody is the body exactly as received.
// Returns { ok: true, method } or { ok: false, reason }.
export function checkHookSignature({ secret, get, rawBody }) {
  const gitlabToken = get('x-gitlab-token');
  if (gitlabToken !== undefined && gitlabToken !== null) {
    return safeEqual(gitlabToken, secret) ? { ok: true, method: 'gitlab-token' } : { ok: false, reason: 'The X-Gitlab-Token header does not match this webhook’s secret' };
  }
  const prefixed = get('x-hub-signature-256') ?? (/^sha256=/.test(get('x-hub-signature') ?? '') ? get('x-hub-signature') : null);
  const bare = get('x-gitea-signature') ?? get('x-forgejo-signature') ?? null;
  const signature = prefixed ? String(prefixed).replace(/^sha256=/, '') : bare;
  if (!signature) {
    return { ok: false, reason: 'This webhook needs a signature. Set its secret in your Git host (GitHub: Secret; GitLab: Secret token).' };
  }
  if (typeof rawBody !== 'string') return { ok: false, reason: 'Send the webhook with content type application/json' };
  const expected = hmacHex(secret, rawBody);
  return safeEqual(String(signature).toLowerCase(), expected) ? { ok: true, method: 'hmac-sha256' } : { ok: false, reason: 'The signature does not match this webhook’s secret' };
}

// Event names that mean a push: GitHub and Gitea "push", GitLab "Push Hook",
// Bitbucket "repo:push".
export const PUSH_EVENTS = Object.freeze(['push', 'push hook', 'repo:push']);

// The ref a push updated: "ref" for GitHub, GitLab and Gitea; Bitbucket
// lists the changed branches instead. Null when the body does not say.
export function pushedRef(body) {
  if (typeof body?.ref === 'string') return body.ref;
  const change = Array.isArray(body?.push?.changes) ? body.push.changes.find((c) => c?.new?.type === 'branch') : null;
  return typeof change?.new?.name === 'string' ? `refs/heads/${change.new.name}` : null;
}
