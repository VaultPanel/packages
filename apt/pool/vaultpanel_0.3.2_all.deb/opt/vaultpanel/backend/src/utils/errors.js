// AppError carries an HTTP status and a stable machine-readable code. The
// error handler turns it into the standard error response; anything else
// becomes a 500 with the details logged but not exposed.
export class AppError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (message, details) => new AppError(400, 'BAD_REQUEST', message, details);
export const unauthenticated = (message = 'Sign in required') => new AppError(401, 'UNAUTHENTICATED', message);
export const forbidden = (message = 'You do not have permission to do this') =>
  new AppError(403, 'FORBIDDEN', message);
export const notFound = (message = 'Not found') => new AppError(404, 'NOT_FOUND', message);
export const conflict = (message, details) => new AppError(409, 'CONFLICT', message, details);
export const validationError = (details, message = 'Some fields are invalid') =>
  new AppError(422, 'VALIDATION_ERROR', message, details);
export const tooManyRequests = (message = 'Too many requests, try again later') =>
  new AppError(429, 'RATE_LIMITED', message);
