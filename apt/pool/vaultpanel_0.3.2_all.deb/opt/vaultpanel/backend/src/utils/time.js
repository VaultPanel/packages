export const addMinutes = (date, minutes) => new Date(date.getTime() + minutes * 60_000);
export const addSeconds = (date, seconds) => new Date(date.getTime() + seconds * 1000);
export const toIso = (value) => (value ? new Date(value).toISOString() : null);
