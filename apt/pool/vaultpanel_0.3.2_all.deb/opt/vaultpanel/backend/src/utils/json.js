// MariaDB stores JSON as LONGTEXT and returns strings; MySQL and PostgreSQL
// return parsed values. Normalize both ways here.
export function fromJson(value, fallback = null) {
  if (value === null || value === undefined) return fallback;
  if (typeof value !== 'string') return value;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

export function toJson(value) {
  return value === undefined ? null : JSON.stringify(value);
}
