import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const here = path.dirname(fileURLToPath(import.meta.url));
export const REPO_ROOT = path.resolve(here, '../../..');

// The agent version this panel serves from /api/v1/agent/package.tgz.
export const LATEST_AGENT_VERSION = readAgentVersion();

function readAgentVersion() {
  try {
    return JSON.parse(readFileSync(path.join(REPO_ROOT, 'agent/package.json'), 'utf8')).version;
  } catch {
    return null;
  }
}

// Compares dotted numeric versions ("0.2.0"); anything unparsable sorts first.
export function compareVersions(a, b) {
  const parse = (v) => String(v ?? '').split(/[.+-]/).slice(0, 3).map((n) => Number.parseInt(n, 10) || 0);
  const [x, y] = [parse(a), parse(b)];
  for (let i = 0; i < 3; i += 1) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}

export function agentPackageAvailable() {
  return existsSync(path.join(REPO_ROOT, 'agent/src/cli.js'));
}

// The agent package (agent/package.json and agent/src as a .tgz). It is built
// the same way every time (sorted entries, fixed times and owners, no gzip
// timestamp), so the same source always gives the same bytes and hash: an
// update job carries the hash, and the agent refuses a package that differs.
export async function buildAgentPackage() {
  const files = ['agent/package.json', 'agent/src'];
  let tarball;
  try {
    tarball = await runTar(['--sort=name', '--mtime=@0', '--owner=0', '--group=0', '--numeric-owner', '--format=gnu', '-cf', '-', '-C', REPO_ROOT, ...files]);
  } catch {
    // tar without the GNU options (BSD tar): a working package, but not a
    // reproducible one.
    tarball = await runTar(['-cf', '-', '-C', REPO_ROOT, ...files]);
  }
  const buffer = gzipSync(tarball, { level: 9 });
  return {
    buffer,
    size: buffer.length,
    sha256: createHash('sha256').update(buffer).digest('hex'),
    version: readAgentVersion(),
  };
}

function runTar(args) {
  return new Promise((resolve, reject) => {
    const tar = spawn('tar', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const chunks = [];
    let stderr = '';
    tar.stdout.on('data', (c) => chunks.push(c));
    tar.stderr.on('data', (c) => {
      stderr += c;
    });
    tar.on('error', reject);
    tar.on('close', (code) => (code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error(stderr.trim() || `tar exited with ${code}`))));
  });
}
