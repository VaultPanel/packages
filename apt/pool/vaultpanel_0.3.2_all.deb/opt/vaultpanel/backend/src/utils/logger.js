import pino from 'pino';

// Field paths that must never reach the logs.
const REDACT = [
  'req.headers.cookie',
  'req.headers.authorization',
  'req.headers["x-csrf-token"]',
  'req.headers["x-vaultpanel-signature"]',
  'res.headers["set-cookie"]',
  '*.password',
  '*.currentPassword',
  '*.newPassword',
  '*.token',
  '*.setupToken',
  '*.secret',
  '*.privateKey',
];

export function createLogger({ level = 'info', name = 'vaultpanel' } = {}) {
  return pino({ name, level, redact: { paths: REDACT, censor: '[redacted]' } });
}
