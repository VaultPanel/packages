import { z } from 'zod';

export const MAX_PAGE_SIZE = 100;

// Query schema shared by list endpoints. sortable is the allowlist of columns.
export function listQuerySchema(sortable, defaultSort, extra = {}, defaultOrder = 'desc') {
  return z.object({
    page: z.coerce.number().int().min(1).default(1),
    pageSize: z.coerce.number().int().min(1).max(MAX_PAGE_SIZE).default(25),
    sort: z.enum(sortable).default(defaultSort),
    order: z.enum(['asc', 'desc']).default(defaultOrder),
    ...extra,
  });
}

export async function paginate(query, { page, pageSize, sort, order }, sortColumns = {}) {
  const countRow = await query.clone().clearSelect().clearOrder().count({ total: '*' }).first();
  const total = Number(countRow?.total ?? 0);
  const rows = await query
    .clone()
    .orderBy(sortColumns[sort] ?? sort, order)
    .limit(pageSize)
    .offset((page - 1) * pageSize);
  return {
    rows,
    pagination: { page, pageSize, total, totalPages: Math.max(1, Math.ceil(total / pageSize)) },
  };
}
