import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const MIGRATIONS_DIR = path.resolve(here, '../../../database/migrations');

// Builds a Knex config from a URL such as mysql://user:pass@host:3306/db.
// postgres:// URLs are accepted so PostgreSQL support can be added later.
export function knexConfig(databaseUrl) {
  const url = new URL(databaseUrl);
  const protocol = url.protocol.replace(':', '');
  if (protocol === 'mysql' || protocol === 'mariadb') {
    return {
      client: 'mysql2',
      connection: {
        host: url.hostname,
        port: Number(url.port || 3306),
        user: decodeURIComponent(url.username),
        password: decodeURIComponent(url.password),
        database: url.pathname.replace(/^\//, ''),
        timezone: 'Z',
        dateStrings: false,
        supportBigNumbers: true,
        bigNumberStrings: false,
        charset: 'utf8mb4',
      },
      pool: { min: 0, max: 10 },
      migrations: { directory: MIGRATIONS_DIR, loadExtensions: ['.js'], tableName: 'knex_migrations' },
    };
  }
  if (protocol === 'postgres' || protocol === 'postgresql') {
    return {
      client: 'pg',
      connection: databaseUrl,
      pool: { min: 0, max: 10 },
      migrations: { directory: MIGRATIONS_DIR, loadExtensions: ['.js'], tableName: 'knex_migrations' },
    };
  }
  throw new Error(`Unsupported DATABASE_URL protocol "${protocol}" (use mysql://)`);
}
