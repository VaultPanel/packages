import http from 'node:http';
import https from 'node:https';
import { loadConfig } from './config/env.js';
import { createContext } from './context.js';
import { createApp } from './app.js';
import { databaseHint } from './utils/databaseHint.js';
import { attachTerminalSockets } from './routes/terminalSockets.js';
import { loadPanelAddress } from './services/panelDomainService.js';
import { loadSslRenewal } from './models/sslRenewalModel.js';

const config = loadConfig();
const ctx = createContext(config);
const app = createApp(ctx);

// HTTPS on the panel's port when it has a certificate (install.sh makes a
// self-signed one), plain HTTP otherwise (development).
const server = config.tls ? https.createServer({ cert: config.tls.certPem, key: config.tls.keyPem }, app) : http.createServer(app);
// With HTTPS on, plain HTTP stays available on 127.0.0.1 only: for the agent
// on this server, the panel domain's NGINX and the vaultpanel command. Nothing
// there leaves the machine.
const loopback = config.loopbackPort ? http.createServer(app) : null;
const servers = [server, loopback].filter(Boolean);

server.listen(config.port, config.host, async () => {
  ctx.logger.info({ host: config.host, port: config.port, https: Boolean(config.tls) }, 'VaultPanel API listening');
  if (config.tls?.selfSigned) ctx.logger.info({ pin: config.tls.pin, validTo: config.tls.validTo }, 'serving HTTPS with a self-signed certificate');
  try {
    await ctx.services.auth.ensureSetupToken({ log: true });
    // Terminal sessions that were open when the panel last stopped.
    await ctx.services.terminalRecordings.closeOrphans();
    // The address set on the Panel Domain page, if any.
    await loadPanelAddress(ctx, { writeHosts: true });
    // A panel domain set up before HTTPS was turned on still points NGINX at
    // the panel's port over HTTP; move it to the loopback port.
    await ctx.services.panelDomain.followPanelPort().catch((err) => ctx.logger.warn({ err }, 'could not point the panel domain at the loopback port'));
    // How early certificates renew and when they count as expiring.
    await loadSslRenewal(ctx.db);
  } catch (err) {
    ctx.logger.error({ err }, 'could not check setup state (is the database migrated?)');
    const hint = databaseHint(err, config.databaseUrl);
    if (hint) ctx.logger.warn(hint);
  }
});
loopback?.listen(config.loopbackPort, '127.0.0.1', () => {
  ctx.logger.info({ host: '127.0.0.1', port: config.loopbackPort }, 'VaultPanel API also listening on loopback (plain HTTP)');
});
for (const s of servers) {
  // Agent long-polls hold requests for ~20s; keep sockets open longer than that.
  s.keepAliveTimeout = 65_000;
  s.on('error', (err) => {
    ctx.logger.fatal({ err }, 'VaultPanel API could not listen');
    process.exit(1);
  });
}
// The server terminal's WebSockets (agents and browsers).
attachTerminalSockets(servers, app, { logger: ctx.logger });

async function shutdown(signal) {
  ctx.logger.info({ signal }, 'shutting down');
  ctx.services.terminals.stop();
  for (const s of servers) s.close();
  await ctx.close();
  process.exit(0);
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
