import { CMS_APPS } from '@vaultpanel/shared';
import { toIso } from '../utils/time.js';

export function toPublicCmsInstall(row) {
  const app = CMS_APPS[row.app];
  const base = row.url.replace(/\/$/, '');
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    websiteId: row.website_id,
    websiteName: row.website_name ?? undefined,
    websiteDomain: row.website_domain ?? undefined,
    customerId: row.customer_id ?? null,
    app: row.app,
    appLabel: app?.label ?? row.app,
    kind: app?.kind ?? null,
    version: row.version ?? null,
    directory: row.directory,
    path: row.url_path ?? '',
    url: row.url,
    adminUrl: app?.admin ? `${base}/${app.adminPath}` : null,
    title: row.title ?? null,
    adminUser: row.admin_user ?? null,
    adminEmail: row.admin_email ?? null,
    database: row.database_id && !row.database_deleted_at ? { id: row.database_id, name: row.database_name ?? null } : null,
    databaseUser: row.database_user_id && !row.database_user_deleted_at ? { id: row.database_user_id, username: row.database_username ?? null } : null,
    status: row.status,
    lastJobId: row.last_job_id ?? null,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    installedAt: toIso(row.installed_at),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
