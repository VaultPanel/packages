import { PLAN_APP_CAPS, PLAN_LIMITS } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

const numberOrNull = (v) => (v === null || v === undefined ? null : Number(v));

export function toPublicPlan(row, { customerCount } = {}) {
  if (!row) return null;
  const limits = {};
  for (const [key, def] of Object.entries(PLAN_LIMITS)) limits[key] = numberOrNull(row[def.column]);
  const appCaps = {};
  for (const [key, def] of Object.entries(PLAN_APP_CAPS)) appCaps[key] = numberOrNull(row[def.column]);
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    isActive: Boolean(row.is_active),
    priceCents: numberOrNull(row.price_cents),
    currency: row.currency,
    billingCycle: row.billing_cycle,
    serverGroup: row.server_group_id ? { id: row.server_group_id, name: row.server_group_name ?? null } : null,
    limits,
    appCaps,
    customerCount: customerCount ?? (row.customer_count === undefined ? undefined : Number(row.customer_count)),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicCustomer(row, { usage, user } = {}) {
  if (!row) return null;
  const suspended = fromJson(row.suspended_resources, null);
  return {
    id: row.id,
    name: row.name,
    company: row.company,
    email: row.email,
    externalId: row.external_id,
    status: row.status,
    suspendReason: row.suspend_reason,
    suspendedAt: toIso(row.suspended_at),
    // What suspending turned off (unsuspending turns it back on).
    suspendedResources: suspended
      ? { websites: suspended.websites?.length ?? 0, applications: suspended.applications?.length ?? 0, cronJobs: suspended.cronJobs?.length ?? 0 }
      : null,
    terminatedAt: toIso(row.terminated_at),
    notes: row.notes,
    createdVia: row.created_via,
    plan: row.plan_name !== undefined ? { id: row.plan_id, name: row.plan_name } : { id: row.plan_id },
    server: row.server_id ? { id: row.server_id, name: row.server_name ?? null, status: row.server_status ?? null } : null,
    userId: row.user_id,
    user: user ?? undefined,
    usage: usage ?? undefined,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicApiKey(row) {
  return {
    id: row.id,
    name: row.name,
    prefix: row.prefix,
    scopes: fromJson(row.scopes, []),
    createdBy: row.created_by ? { id: row.created_by, email: row.created_by_email ?? null } : null,
    lastUsedAt: toIso(row.last_used_at),
    lastUsedIp: row.last_used_ip,
    revokedAt: toIso(row.revoked_at),
    createdAt: toIso(row.created_at),
  };
}
