import { describeCron } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

const numberOrNull = (value) => (value === null || value === undefined ? null : Number(value));

export function toPublicBackup(row, { now = new Date() } = {}) {
  const downloadReady = Boolean(row.download_path && row.download_ready_until && new Date(row.download_ready_until) > now);
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    resource: {
      type: row.resource_type,
      id: row.resource_id,
      name: row.resource_name,
      // False once the website, app or database was deleted.
      exists: row.resource_exists === undefined ? undefined : Boolean(Number(row.resource_exists)),
    },
    status: row.status,
    trigger: row.trigger,
    scheduleId: row.schedule_id,
    filePath: row.file_path,
    // False when the backup is kept only in its storage.
    localCopy: row.local_copy === undefined ? true : Boolean(row.local_copy),
    storage: row.storage_id
      ? { id: row.storage_id, name: row.storage_name ?? null, key: row.storage_key ?? null, stored: Boolean(row.storage_key), error: row.storage_error ?? null }
      : null,
    sizeBytes: numberOrNull(row.size_bytes),
    sha256: row.sha256,
    releaseId: row.release_id,
    jobId: row.job_id,
    error: row.error ? { code: row.error_code, message: row.error } : null,
    completedAt: toIso(row.completed_at),
    lastRestoredAt: toIso(row.last_restored_at),
    download: { ready: downloadReady, until: downloadReady ? toIso(row.download_ready_until) : null, jobId: row.download_job_id },
    createdBy: row.created_by ? { id: row.created_by, email: row.created_by_email ?? null } : null,
    createdAt: toIso(row.created_at),
  };
}

export function toPublicRestore(row) {
  return {
    id: row.id,
    backupId: row.backup_id,
    jobId: row.job_id,
    safetyBackupId: row.safety_backup_id,
    status: row.status,
    error: row.error ? { code: row.error_code, message: row.error } : null,
    requestedBy: row.requested_by ? { id: row.requested_by, email: row.requested_by_email ?? null } : null,
    createdAt: toIso(row.created_at),
    finishedAt: toIso(row.finished_at),
  };
}

export function toPublicSchedule(row) {
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    resource: { type: row.resource_type, id: row.resource_id, name: row.resource_name ?? null },
    schedule: row.schedule,
    description: describeCron(row.schedule),
    timezone: row.timezone,
    keepCount: row.keep_count,
    storage: row.storage_id ? { id: row.storage_id, name: row.storage_name ?? null } : null,
    lastStorageError: row.last_storage_error ?? null,
    enabled: Boolean(row.enabled),
    nextRunAt: row.enabled ? toIso(row.next_run_at) : null,
    lastRunAt: toIso(row.last_run_at),
    lastBackupId: row.last_backup_id,
    lastBackupStatus: row.last_backup_status ?? null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicCronJob(row) {
  const pending = fromJson(row.pending_spec, null);
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    serverTimezone: row.server_timezone ?? null,
    owner: { type: row.owner_type, id: row.owner_id, name: row.user_name },
    name: row.name,
    schedule: row.schedule,
    description: describeCron(row.schedule),
    commands: row.commands,
    workingDir: row.working_dir ?? '',
    timeoutSeconds: row.timeout_seconds,
    enabled: Boolean(row.enabled),
    appEnv: Boolean(row.app_env),
    status: row.status,
    pending: pending ?? null,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    lastRun: row.last_run_at
      ? { at: toIso(row.last_run_at), status: row.last_run_status, exitCode: row.last_run_exit_code, durationMs: row.last_run_duration_ms }
      : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicCronRun(row, { withOutput = true } = {}) {
  return {
    id: Number(row.id),
    cronJobId: row.cron_job_id,
    trigger: row.trigger,
    status: row.status,
    exitCode: row.exit_code,
    startedAt: toIso(row.started_at),
    finishedAt: toIso(row.finished_at),
    durationMs: row.duration_ms,
    ...(withOutput ? { output: row.output ?? '', outputTruncated: Boolean(row.output_truncated) } : {}),
    jobId: row.job_id,
  };
}

export function toPublicWebhook(row) {
  return {
    id: row.id,
    name: row.name,
    // Chat webhook URLs are secrets: lists show where they go, not the URL.
    host: row.url_host,
    format: row.format,
    events: fromJson(row.events, []),
    enabled: Boolean(row.enabled),
    lastDelivery: row.last_delivery_at ? { at: toIso(row.last_delivery_at), status: row.last_delivery_status } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicDelivery(row) {
  return {
    id: row.id,
    webhookId: row.webhook_id,
    event: row.event,
    status: row.status,
    attempts: row.attempts,
    nextAttemptAt: row.status === 'pending' ? toIso(row.next_attempt_at) : null,
    responseStatus: row.response_status,
    error: row.error,
    durationMs: row.duration_ms,
    payload: fromJson(row.payload, null),
    createdAt: toIso(row.created_at),
    deliveredAt: toIso(row.delivered_at),
  };
}
