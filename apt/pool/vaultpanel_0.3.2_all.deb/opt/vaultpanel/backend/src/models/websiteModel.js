import { SITE_GIT_DOCUMENT_ROOT, certificateCovers } from '@vaultpanel/shared';
import { sslRenewal } from './sslRenewalModel.js';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicDomain(row) {
  return {
    id: row.id,
    websiteId: row.website_id,
    domain: row.domain,
    isPrimary: Boolean(row.is_primary),
    dns: row.dns_checked_at
      ? { status: row.dns_status, addresses: fromJson(row.dns_addresses, []), checkedAt: toIso(row.dns_checked_at) }
      : null,
    createdAt: toIso(row.created_at),
  };
}

// state adds what the stored status cannot know: whether an active
// certificate has expired or is close to it.
export function toPublicCertificate(row, now = new Date()) {
  if (!row) return null;
  const notAfter = row.not_after ? new Date(row.not_after) : null;
  const daysLeft = notAfter ? Math.floor((notAfter - now) / 86_400_000) : null;
  let state = row.status;
  if (row.status === 'active' && notAfter) {
    if (notAfter <= now) state = 'expired';
    else if (daysLeft < sslRenewal().warnDays) state = 'expiring';
  }
  return {
    id: row.id,
    websiteId: row.website_id,
    serverId: row.server_id,
    certName: row.cert_name,
    provider: row.provider,
    // The DNS provider (DNS Zones page) its wildcard check goes through.
    dnsProviderId: row.dns_provider_id ?? null,
    status: row.status,
    state,
    daysLeft,
    domains: fromJson(row.domains, []),
    issuer: row.issuer,
    isStaging: Boolean(row.is_staging),
    email: row.email,
    notBefore: toIso(row.not_before),
    notAfter: toIso(row.not_after),
    issuedAt: toIso(row.issued_at),
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicWebsite(row, { domains = [], certificate = null, application = null } = {}) {
  const sorted = [...domains].sort((a, b) => Number(b.is_primary) - Number(a.is_primary) || a.domain.localeCompare(b.domain));
  const cert = toPublicCertificate(certificate);
  return {
    id: row.id,
    serverId: row.server_id,
    customerId: row.customer_id ?? null,
    // The parent domain, for a site added on the Subdomains page.
    subdomainOf: row.subdomain_of ?? null,
    // DNS records VaultPanel added for the site (subdomains), taken out again
    // when the site is deleted.
    dnsRecords: fromJson(row.dns_records, []),
    serverName: row.server_name ?? undefined,
    serverStatus: row.server_status ?? undefined,
    name: row.name,
    type: row.type,
    primaryDomain: sorted[0]?.domain ?? null,
    domains: sorted.map(toPublicDomain),
    documentRoot: row.document_root,
    phpVersion: row.php_version,
    proxyPort: row.proxy_port,
    customNginx: row.custom_nginx ?? '',
    htaccess: Boolean(row.htaccess),
    spa: Boolean(row.spa),
    isEnabled: Boolean(row.is_enabled),
    forceHttps: Boolean(row.force_https),
    status: row.status,
    pendingAction: row.pending_action,
    provisioned: Boolean(row.provisioned_at),
    health: row.health_checked_at
      ? { status: row.health_status, message: row.health_message, checkedAt: toIso(row.health_checked_at) }
      : null,
    // The panel's own checks, the way visitors reach the site (GET /websites/:id/uptime has more).
    uptime: {
      enabled: Boolean(row.uptime_enabled ?? true),
      status: row.uptime_status ?? null,
      since: toIso(row.uptime_since),
      checkedAt: toIso(row.uptime_checked_at),
      message: row.uptime_message ?? null,
    },
    ssl: cert,
    // The app this site serves (a reverse proxy to the app's port).
    application,
    // Git deploy of a static site; null while the site is managed with the file manager.
    git: row.git_repository_url
      ? {
          repositoryUrl: row.git_repository_url,
          branch: row.git_branch,
          installCommand: row.git_install_command ?? null,
          buildCommand: row.git_build_command ?? null,
          outputDir: row.git_output_dir ?? '',
          keepReleases: row.git_keep_releases,
          deployKey: row.git_deploy_public_key ?? null,
          live: row.document_root === SITE_GIT_DOCUMENT_ROOT,
          previousDocumentRoot: row.git_previous_document_root ?? null,
          currentDeploymentId: row.git_current_deployment_id ?? null,
          currentReleaseId: row.git_current_release_id ?? null,
          currentCommit: row.git_current_commit ?? null,
          lastDeployedAt: toIso(row.git_last_deployed_at),
          webhook: { enabled: Boolean(row.git_webhook_token_hash), signed: Boolean(row.git_webhook_secret_encrypted), createdAt: toIso(row.git_webhook_created_at) },
        }
      : null,
    // Domains the active certificate does not cover (added after it was issued).
    uncoveredDomains: cert?.status === 'active' ? sorted.map((d) => d.domain).filter((d) => !certificateCovers(cert.domains, d)) : [],
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicSiteDeployment(row) {
  let status = row.status;
  if (status === 'queued' && ['dispatched', 'running'].includes(row.job_status)) status = 'running';
  const started = row.started_at ?? row.job_started_at;
  return {
    id: row.id,
    websiteId: row.website_id,
    serverId: row.server_id,
    jobId: row.job_id,
    kind: row.kind,
    trigger: row.trigger,
    status,
    releaseId: row.release_id,
    sourceDeploymentId: row.source_deployment_id ?? null,
    repositoryUrl: row.repository_url,
    branch: row.branch,
    outputDir: row.output_dir ?? '',
    commit: row.commit_hash ? { hash: row.commit_hash, message: row.commit_message, author: row.commit_author } : null,
    failedStage: row.failed_stage ?? null,
    error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
    releaseAvailable: Boolean(row.release_available),
    isCurrent: Boolean(row.current_deployment_id && row.current_deployment_id === row.id),
    requestedBy: row.requested_by ? { id: row.requested_by, email: row.requested_by_email ?? null } : null,
    stages: fromJson(row.job_output, null)?.stages ?? null,
    startedAt: toIso(started),
    finishedAt: toIso(row.finished_at),
    durationMs: started && row.finished_at ? new Date(row.finished_at) - new Date(started) : null,
    createdAt: toIso(row.created_at),
  };
}
