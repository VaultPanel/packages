import { LEGACY_AGENT_OPERATIONS } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicServer(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    status: row.status,
    // The server the panel itself runs on, connected automatically.
    isLocal: Boolean(row.is_local),
    hostname: row.hostname,
    publicIp: row.public_ip,
    os: {
      name: row.os_name,
      version: row.os_version,
      kernel: row.kernel_version,
      architecture: row.architecture,
    },
    cpuCores: row.cpu_cores,
    memoryTotalBytes: numberOrNull(row.memory_total_bytes),
    diskTotalBytes: numberOrNull(row.disk_total_bytes),
    uptimeSeconds: numberOrNull(row.uptime_seconds),
    // The server's own time zone (cron jobs run in it); null before agent 0.5.0.
    timezone: row.timezone ?? null,
    agentVersion: row.agent_version,
    lastSeenAt: toIso(row.last_seen_at),
    services: fromJson(row.services_snapshot, []),
    filesystems: fromJson(row.filesystems_snapshot, []),
    agentOperations: agentOperations(row),
    webStack: fromJson(row.web_stack, null),
    // The agent's last self-check report (agent 0.39.0; shared/src/selfCheck.js).
    selfCheck: fromJson(row.self_check, null),
    ipAddresses: fromJson(row.ip_addresses, []),
    // What hosting customers on this server are told about DNS.
    customerDns: { nameservers: fromJson(row.customer_nameservers, []), autoZones: Boolean(row.customer_dns_zones) },
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicMetric(row) {
  if (!row) return null;
  return {
    collectedAt: toIso(row.collected_at),
    cpuPercent: numberOrNull(row.cpu_percent),
    load: [numberOrNull(row.load_1), numberOrNull(row.load_5), numberOrNull(row.load_15)],
    memoryUsedBytes: numberOrNull(row.memory_used_bytes),
    memoryTotalBytes: numberOrNull(row.memory_total_bytes),
    swapUsedBytes: numberOrNull(row.swap_used_bytes),
    swapTotalBytes: numberOrNull(row.swap_total_bytes),
    diskUsedBytes: numberOrNull(row.disk_used_bytes),
    diskTotalBytes: numberOrNull(row.disk_total_bytes),
    netRxBytesPerSec: numberOrNull(row.net_rx_bytes_per_sec),
    netTxBytesPerSec: numberOrNull(row.net_tx_bytes_per_sec),
    processCount: numberOrNull(row.process_count),
    uptimeSeconds: numberOrNull(row.uptime_seconds),
  };
}

export function findServer(db, id) {
  return db('servers').where({ id }).whereNull('deleted_at').first();
}

function numberOrNull(value) {
  return value === null || value === undefined ? null : Number(value);
}

// Operations the server's agent can run. Agents before 0.2.0 do not report
// them, so they get the operations those versions shipped with.
export function agentOperations(row) {
  return fromJson(row.agent_operations, null) ?? [...LEGACY_AGENT_OPERATIONS];
}
