import { dnsFullName } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicDnsRecord(row, domain) {
  return {
    id: row.id,
    name: row.name,
    fullName: dnsFullName(row.name, domain),
    type: row.type,
    ttl: row.ttl ?? null,
    value: row.value,
    priority: row.priority ?? null,
    weight: row.weight ?? null,
    port: row.port ?? null,
    tag: row.tag ?? null,
  };
}

// The zone's own name servers (NS records for @) with the addresses the
// zone gives the ones inside it: what to enter at the domain's registrar.
export function zoneNameservers(domain, records) {
  return records
    .filter((r) => r.type === 'NS' && r.name === '@')
    .map((r) => {
      const inZone = r.value === domain || r.value.endsWith(`.${domain}`);
      const name = inZone ? (r.value === domain ? '@' : r.value.slice(0, -domain.length - 1)) : null;
      return {
        host: r.value,
        inZone,
        addresses: inZone ? records.filter((a) => a.name === name && (a.type === 'A' || a.type === 'AAAA')).map((a) => a.value) : [],
      };
    });
}

export function toPublicDnsZone(row, { records = null, recordCount = null, applying = false } = {}) {
  const serial = Number(row.serial);
  const applied = row.applied_serial === null || row.applied_serial === undefined ? null : Number(row.applied_serial);
  const publicRecords = records ? records.map((r) => toPublicDnsRecord(r, row.domain)) : undefined;
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    domain: row.domain,
    // The hosting account the zone was added for automatically, if any.
    customerId: row.customer_id ?? null,
    status: row.status,
    defaultTtl: row.default_ttl,
    soaEmail: row.soa_email,
    serial,
    appliedSerial: applied,
    appliedAt: toIso(row.applied_at),
    // Changes the server does not have yet (they are applied on their own).
    pending: applied === null || applied < serial,
    applying,
    recordCount: recordCount ?? publicRecords?.length ?? null,
    ...(records ? { records: publicRecords, nameservers: zoneNameservers(row.domain, records) } : {}),
    delegation: row.delegation_status
      ? {
          status: row.delegation_status,
          nameservers: fromJson(row.delegation_nameservers, []),
          detail: row.delegation_detail ?? null,
          checkedAt: toIso(row.delegation_checked_at),
        }
      : null,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
