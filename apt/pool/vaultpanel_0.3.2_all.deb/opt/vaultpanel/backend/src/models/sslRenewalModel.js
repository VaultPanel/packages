import { SSL_RENEWAL_DEFAULTS, sslRenewalProblems } from '@vaultpanel/shared';
import { getSetting } from './settingModel.js';
import { fromJson } from '../utils/json.js';

// The SSL renewal setting (SSL Certificates page). Kept in memory, read at
// start, after a change, and by the worker on every run, so turning a
// certificate into its public form needs no query.
export const SSL_RENEWAL_KEY = 'ssl.renewal';

let current = { ...SSL_RENEWAL_DEFAULTS };

export function sslRenewal() {
  return current;
}

export function setSslRenewal(value) {
  current = normalizeSslRenewal(value);
  return current;
}

export function normalizeSslRenewal(value) {
  const merged = { ...SSL_RENEWAL_DEFAULTS, ...(value && typeof value === 'object' ? value : {}) };
  const picked = { renewBeforeDays: merged.renewBeforeDays, warnDays: merged.warnDays };
  return sslRenewalProblems(picked).length ? { ...SSL_RENEWAL_DEFAULTS } : picked;
}

export async function loadSslRenewal(db) {
  return setSslRenewal(fromJson(await getSetting(db, SSL_RENEWAL_KEY), null));
}
