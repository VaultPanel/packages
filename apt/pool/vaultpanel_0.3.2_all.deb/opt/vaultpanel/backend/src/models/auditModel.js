import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicAuditEntry(row) {
  return {
    id: Number(row.id),
    occurredAt: toIso(row.occurred_at),
    actor: { type: row.actor_type, id: row.actor_id, label: row.actor_label },
    action: row.action,
    target: row.target_type ? { type: row.target_type, id: row.target_id, label: row.target_label } : null,
    result: row.result,
    ip: row.ip,
    userAgent: row.user_agent,
    requestId: row.request_id,
    metadata: fromJson(row.metadata, {}),
  };
}
