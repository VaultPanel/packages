import { toIso } from '../utils/time.js';

export const USER_TABLE = 'users';

// The shape of a user that leaves the API. Never includes hashes or secrets.
export function toPublicUser(row, roles = []) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    isActive: Boolean(row.is_active),
    twoFactorEnabled: Boolean(row.totp_enabled),
    roles,
    lastLoginAt: toIso(row.last_login_at),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function findUserByEmail(db, email) {
  return db(USER_TABLE).where({ email: normalizeEmail(email) }).whereNull('deleted_at').first();
}

export function findUserById(db, id) {
  return db(USER_TABLE).where({ id }).whereNull('deleted_at').first();
}

export function normalizeEmail(email) {
  return String(email).trim().toLowerCase();
}

// Returns { [userId]: ['admin', ...] } for the given users.
export async function rolesByUser(db, userIds) {
  if (!userIds.length) return {};
  const rows = await db('user_roles as ur')
    .join('roles as r', 'r.id', 'ur.role_id')
    .whereIn('ur.user_id', userIds)
    .select('ur.user_id', 'r.name');
  const map = Object.fromEntries(userIds.map((id) => [id, []]));
  for (const row of rows) map[row.user_id].push(row.name);
  return map;
}
