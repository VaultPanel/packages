import { toIso } from '../utils/time.js';

export function toPublicDatabase(row, { users = [] } = {}) {
  return {
    id: row.id,
    serverId: row.server_id,
    customerId: row.customer_id ?? null,
    serverName: row.server_name ?? undefined,
    engine: row.engine,
    name: row.name,
    charset: row.charset,
    collation: row.collation,
    status: row.status,
    sizeBytes: row.size_bytes === null || row.size_bytes === undefined ? null : Number(row.size_bytes),
    sizeCheckedAt: toIso(row.size_checked_at),
    application: row.application_id ? { id: row.application_id, name: row.application_name ?? null } : null,
    website: row.website_id ? { id: row.website_id, name: row.website_name ?? null } : null,
    users,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicDatabaseUser(row, { databases = [] } = {}) {
  return {
    id: row.id,
    serverId: row.server_id,
    customerId: row.customer_id ?? null,
    serverName: row.server_name ?? undefined,
    engine: row.engine,
    username: row.username,
    privileges: row.privileges,
    status: row.status,
    // Hosts it can connect from: the server itself, by socket or TCP.
    hosts: ['localhost', '127.0.0.1'],
    databases,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
