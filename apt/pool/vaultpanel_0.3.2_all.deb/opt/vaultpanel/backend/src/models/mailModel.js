import { MAIL_CLIENT_PORTS } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicMailServer(row, { applying = false, settingUp = false } = {}) {
  if (!row) return null;
  const serial = Number(row.serial);
  const applied = row.applied_serial === null || row.applied_serial === undefined ? null : Number(row.applied_serial);
  return {
    id: row.id,
    serverId: row.server_id,
    hostname: row.hostname,
    status: row.status,
    tls: row.tls ?? null,
    serial,
    appliedSerial: applied,
    appliedAt: toIso(row.applied_at),
    // Changes the server does not have yet (they are applied on their own).
    pending: row.status === 'active' && (applied === null || applied < serial),
    applying,
    settingUp,
    checks: fromJson(row.checks, null),
    checkedAt: toIso(row.checked_at),
    lastJobId: row.last_job_id ?? null,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicMailbox(row) {
  return {
    id: row.id,
    domainId: row.domain_id,
    localPart: row.local_part,
    address: row.address,
    displayName: row.display_name ?? null,
    quotaMb: row.quota_mb,
    enabled: Boolean(row.enabled),
    usedBytes: row.used_bytes === null || row.used_bytes === undefined ? null : Number(row.used_bytes),
    usageCheckedAt: toIso(row.usage_checked_at),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicForwarder(row) {
  return {
    id: row.id,
    domainId: row.domain_id,
    localPart: row.local_part,
    address: row.address,
    destinations: fromJson(row.destinations, []),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

// What mail clients need: the server's host name, ports and security.
export function clientSettings(hostname) {
  return {
    hostname,
    incoming: [
      { protocol: 'IMAP', port: MAIL_CLIENT_PORTS.imap.port, security: MAIL_CLIENT_PORTS.imap.security },
      { protocol: 'POP3', port: MAIL_CLIENT_PORTS.pop3.port, security: MAIL_CLIENT_PORTS.pop3.security },
    ],
    outgoing: [
      { protocol: 'SMTP', port: MAIL_CLIENT_PORTS.smtp.port, security: MAIL_CLIENT_PORTS.smtp.security },
      { protocol: 'SMTP', port: MAIL_CLIENT_PORTS.smtps.port, security: MAIL_CLIENT_PORTS.smtps.security },
    ],
    username: 'The full email address',
  };
}

export function toPublicMailDomain(row, { mailboxCount = null, forwarderCount = null, extra = {} } = {}) {
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    hostname: row.hostname ?? null,
    domain: row.domain,
    status: row.status,
    autoDns: Boolean(row.auto_dns),
    dkimSelector: row.dkim_selector,
    dkimReady: Boolean(row.dkim_public_key),
    mailboxCount,
    forwarderCount,
    createdAt: toIso(row.created_at),
    ...extra,
  };
}
