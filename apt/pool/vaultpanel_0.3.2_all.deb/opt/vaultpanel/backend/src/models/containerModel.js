import { parsePortMapping, parseVolumeMapping } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

// spec is stored as the agent takes it (ports and volumes as strings); the
// API gives them as objects.
export function publicSpec(spec) {
  return {
    ports: (spec.ports ?? []).map(parsePortMapping).filter(Boolean),
    volumes: (spec.volumes ?? []).map(parseVolumeMapping).filter(Boolean),
    restartPolicy: spec.restartPolicy ?? 'unless-stopped',
    memoryMb: spec.memoryMb ?? null,
    cpuPercent: spec.cpuPercent ?? null,
    command: spec.command ?? null,
    healthCheckSeconds: spec.healthCheckSeconds ?? null,
  };
}

export function toPublicContainer(row, { envKeys = [] } = {}) {
  const pendingSpec = fromJson(row.pending_spec, null);
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    name: row.name,
    image: row.image,
    ...publicSpec(fromJson(row.spec, {})),
    // Names only; values come from GET /containers/:id/environment.
    envKeys,
    status: row.status,
    // What Docker last reported (running, exited... or missing).
    state: row.state ?? null,
    stateDetail: row.state_detail ?? null,
    stateCheckedAt: toIso(row.state_checked_at),
    dockerId: row.docker_id ?? null,
    deployedAt: toIso(row.deployed_at),
    // A change being deployed.
    pending: row.pending_image || pendingSpec ? { image: row.pending_image ?? row.image, ...(pendingSpec ? publicSpec(pendingSpec) : {}) } : null,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
