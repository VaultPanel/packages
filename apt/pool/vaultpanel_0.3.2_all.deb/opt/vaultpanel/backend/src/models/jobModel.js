import { redactJobParams } from '@vaultpanel/shared';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export function toPublicJob(row) {
  if (!row) return null;
  return {
    id: row.id,
    type: row.type,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    status: row.status,
    params: redactJobParams(row.type, fromJson(row.params, {})),
    resource: row.resource_type ? { type: row.resource_type, id: row.resource_id } : null,
    requestedBy: row.requested_by
      ? { id: row.requested_by, email: row.requested_by_email ?? undefined }
      : { type: row.requested_by_type },
    attempts: row.attempts,
    maxAttempts: row.max_attempts,
    timeoutSeconds: row.timeout_seconds,
    requestId: row.request_id,
    output: fromJson(row.output, null),
    error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
    expiresAt: toIso(row.expires_at),
    dispatchedAt: toIso(row.dispatched_at),
    startedAt: toIso(row.started_at),
    finishedAt: toIso(row.finished_at),
    durationMs:
      row.started_at && row.finished_at ? new Date(row.finished_at) - new Date(row.started_at) : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicJobLog(row) {
  return { id: Number(row.id), stream: row.stream, message: row.message, loggedAt: toIso(row.logged_at) };
}
