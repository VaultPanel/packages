import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

// Settings saved after the running configuration was written (start command,
// port, environment) apply on the next deploy, restart with new settings, or
// "Apply changes".
export function configPending(row) {
  if (!row.current_release_id || !row.config_changed_at) return false;
  return !row.config_applied_at || new Date(row.config_changed_at) > new Date(row.config_applied_at);
}

export function toPublicApplication(row, { website = null, envKeys = null } = {}) {
  return {
    id: row.id,
    serverId: row.server_id,
    customerId: row.customer_id ?? null,
    serverName: row.server_name ?? undefined,
    serverStatus: row.server_status ?? undefined,
    name: row.name,
    runtime: row.runtime,
    repositoryUrl: row.repository_url,
    branch: row.branch,
    installCommand: row.install_command,
    buildCommand: row.build_command,
    startCommand: row.start_command,
    port: row.port,
    keepReleases: row.keep_releases,
    healthCheckSeconds: row.health_check_seconds,
    // Resource limits (null: none). CPU in percent of one core, memory in MiB.
    cpuLimitPercent: row.cpu_limit_percent ?? null,
    memoryLimitMb: row.memory_limit_mb ?? null,
    // Copies of the app that run on its server.
    instances: row.instances ?? 1,
    zeroDowntime: Boolean(row.zero_downtime),
    status: row.status,
    pendingAction: row.pending_action,
    provisioned: Boolean(row.provisioned_at),
    current: row.current_release_id
      ? { deploymentId: row.current_deployment_id, releaseId: row.current_release_id, commit: row.current_commit, deployedAt: toIso(row.last_deployed_at) }
      : null,
    configPending: configPending(row),
    process: row.process_state
      ? { state: row.process_state, ...fromJson(row.process_info, {}), checkedAt: toIso(row.process_checked_at) }
      : null,
    deployKey: row.deploy_public_key ?? null,
    webhook: { enabled: Boolean(row.webhook_token_hash), signed: Boolean(row.webhook_secret_encrypted), createdAt: toIso(row.webhook_created_at) },
    websiteId: row.website_id ?? null,
    primaryDomain: row.primary_domain ?? null,
    website,
    envKeys,
    lastJobId: row.last_job_id,
    lastError: row.last_error ? { code: row.last_error_code, message: row.last_error } : null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

// A deployment's status follows its job while the job runs.
export function toPublicDeployment(row) {
  let status = row.status;
  if (status === 'queued' && ['dispatched', 'running'].includes(row.job_status)) status = 'running';
  const started = row.started_at ?? row.job_started_at;
  return {
    id: row.id,
    applicationId: row.application_id,
    applicationName: row.application_name ?? undefined,
    serverId: row.server_id,
    serverName: row.server_name ?? undefined,
    jobId: row.job_id,
    kind: row.kind,
    trigger: row.trigger,
    status,
    releaseId: row.release_id,
    sourceDeploymentId: row.source_deployment_id,
    repositoryUrl: row.repository_url,
    branch: row.branch,
    commit: row.commit_hash ? { hash: row.commit_hash, message: row.commit_message, author: row.commit_author } : null,
    failedStage: row.failed_stage,
    error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
    releaseAvailable: Boolean(row.release_available),
    isCurrent: row.current_deployment_id ? row.current_deployment_id === row.id : undefined,
    stages: fromJson(row.job_output, null)?.stages ?? null,
    requestedBy: row.requested_by ? { id: row.requested_by, email: row.requested_by_email ?? undefined } : null,
    startedAt: toIso(started),
    finishedAt: toIso(row.finished_at),
    durationMs: started && row.finished_at ? new Date(row.finished_at) - new Date(started) : null,
    createdAt: toIso(row.created_at),
  };
}
