export async function getSetting(db, key) {
  const row = await db('settings').where({ key }).first();
  return row ? row.value : null;
}

// Inserts the value only if the key is missing; returns the stored value.
// Used for generated secrets so concurrent processes agree on one value.
export async function getOrCreateSetting(db, key, create, { isSecret = false } = {}) {
  const existing = await getSetting(db, key);
  if (existing !== null) return existing;
  const value = await create();
  await db('settings').insert({ key, value, is_secret: isSecret }).onConflict('key').ignore();
  return getSetting(db, key);
}
