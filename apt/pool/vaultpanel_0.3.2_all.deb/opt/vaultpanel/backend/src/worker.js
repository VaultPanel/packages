import { loadConfig } from './config/env.js';
import { createContext } from './context.js';
import { scheduleMaintenance, startAssistantWorker, startMaintenanceWorker } from './jobs/queues.js';
import { loadPanelAddress } from './services/panelDomainService.js';

// Background worker process: offline detection, job timeouts and retries,
// data retention, and the AI assistant's answers. Run one alongside the API
// (npm run worker).
const config = loadConfig();
const ctx = createContext(config);
// The address set on the Panel Domain page (used in links the worker sends),
// read again every minute since it is changed in the API process.
const refreshAddress = () => loadPanelAddress(ctx).catch((err) => ctx.logger.warn({ err }, 'could not read the panel address'));
await refreshAddress();
const addressTimer = setInterval(refreshAddress, 60_000);
const queue = await scheduleMaintenance(config.redisUrl);
const worker = startMaintenanceWorker(config.redisUrl, ctx);
const assistantWorker = startAssistantWorker(config.redisUrl, ctx);
ctx.logger.info('VaultPanel worker started');

async function shutdown(signal) {
  ctx.logger.info({ signal }, 'worker shutting down');
  clearInterval(addressTimer);
  await worker.close();
  await assistantWorker.close();
  await queue.close();
  await ctx.close();
  process.exit(0);
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
