import { rateLimit } from 'express-rate-limit';
import { sendError } from '../utils/response.js';

// In-memory limits per panel process. A shared Redis store is needed once the
// API runs as several instances (Phase 7).
function limiter({ windowMs, limit, message, keyGenerator }) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    keyGenerator,
    handler: (req, res) => sendError(res, 429, { code: 'RATE_LIMITED', message }),
  });
}

export const createRateLimits = ({ disabled = false } = {}) => {
  const pass = (req, res, next) => next();
  if (disabled) return { api: pass, login: pass, setup: pass, passwordReset: pass, agentRegister: pass, agentDownload: pass, hooks: pass, billing: pass };
  return {
    api: limiter({ windowMs: 60_000, limit: 600, message: 'Too many requests, slow down' }),
    login: limiter({ windowMs: 15 * 60_000, limit: 20, message: 'Too many sign-in attempts, try again later' }),
    setup: limiter({ windowMs: 15 * 60_000, limit: 10, message: 'Too many attempts, try again later' }),
    passwordReset: limiter({ windowMs: 15 * 60_000, limit: 20, message: 'Too many attempts, try again later' }),
    agentRegister: limiter({ windowMs: 60 * 60_000, limit: 30, message: 'Too many registration attempts' }),
    // The agent's install script and package need no sign-in, and the package
    // is built on each request. A server installing or updating its agent
    // fetches each once.
    agentDownload: limiter({ windowMs: 60_000, limit: 60, message: 'Too many downloads, slow down' }),
    hooks: limiter({ windowMs: 60_000, limit: 30, message: 'Too many webhook calls' }),
    billing: limiter({ windowMs: 60_000, limit: 120, message: 'Too many billing API calls, slow down' }),
  };
};
