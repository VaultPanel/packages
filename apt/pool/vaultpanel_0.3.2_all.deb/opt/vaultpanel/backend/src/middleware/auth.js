import { AppError, forbidden, unauthenticated } from '../utils/errors.js';
import { requestMeta } from './requestId.js';

export const SESSION_COOKIE = 'vp_session';
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// Resolves the session cookie (if any) to req.actor. An API token resolved
// earlier (middleware/apiTokenAuth.js) wins over the cookie.
export function loadSession() {
  return async (req, res, next) => {
    try {
      if (req.actor?.tokenId) return next();
      const token = req.cookies?.[SESSION_COOKIE];
      req.actor = null;
      if (token) {
        const session = await req.app.locals.services.auth.resolveSession(token, requestMeta(req, res));
        if (session) req.actor = session.actor;
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

export function requireAuth() {
  return (req, res, next) => next(req.actor ? undefined : unauthenticated());
}

// An account the two-factor policy covers, without two-factor sign-in on,
// may only use /auth (to set it up, or sign out) until it turns it on.
export function requireTwoFactorSetup() {
  return (req, res, next) => {
    if (!req.actor?.twoFactorSetupRequired) return next();
    next(new AppError(403, 'TWO_FACTOR_SETUP_REQUIRED', 'Turn on two-factor sign-in to continue (required for your account)'));
  };
}

// Cookie-authenticated, state-changing requests must carry the session's
// CSRF token in X-CSRF-Token (on top of the SameSite=Strict cookie).
export function csrfProtection() {
  return (req, res, next) => {
    // An API token sends no cookie, so there is nothing for another site to
    // ride on and no CSRF token to check.
    if (SAFE_METHODS.has(req.method) || !req.actor || req.actor.tokenId) return next();
    const ok = req.app.locals.services.auth.verifyCsrf(req.actor.sessionId, req.get('x-csrf-token'));
    next(ok ? undefined : forbidden('Missing or invalid CSRF token. Reload the page and try again.'));
  };
}

// Cookies are Secure when the setting says so, and always on HTTPS requests:
// with a panel domain, people sign in at https://<domain> while the plain
// HTTP address of the server keeps working for those who use it.
function secureCookie(res, config) {
  return Boolean(config.cookieSecure || res.req?.secure);
}

export function setSessionCookie(res, config, token, expiresAt) {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: secureCookie(res, config),
    sameSite: 'strict',
    path: '/',
    expires: expiresAt,
  });
}

export function clearSessionCookie(res, config) {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, secure: secureCookie(res, config), sameSite: 'strict', path: '/' });
}
