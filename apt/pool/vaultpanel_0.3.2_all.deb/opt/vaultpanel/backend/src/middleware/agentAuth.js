import { AppError } from '../utils/errors.js';
import { isLoopback } from '../services/agentService.js';
import { requestMeta } from './requestId.js';

const FORWARDING_HEADERS = ['x-forwarded-for', 'x-forwarded-proto', 'x-real-ip', 'forwarded', 'via'];

// Agent endpoints require TLS (unless explicitly allowed for development).
// Plain HTTP over loopback is allowed too: that is the agent on the panel's
// own server talking straight to the API, and the traffic never leaves the
// machine. A request a proxy forwarded does not count, wherever it came from.
export function requireAgentTransport() {
  return (req, res, next) => {
    const { allowInsecureAgents } = req.app.locals.config;
    if (req.secure || allowInsecureAgents || isDirectLoopback(req)) return next();
    next(new AppError(403, 'INSECURE_TRANSPORT', 'Agents must connect over HTTPS'));
  };
}

export function isDirectLoopback(req) {
  if (!req.socket?.remoteAddress || !isLoopback(req.socket.remoteAddress)) return false;
  if (FORWARDING_HEADERS.some((h) => req.get(h))) return false;
  const host = (req.get('host') ?? '').replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
  return host === 'localhost' || isLoopback(host);
}

// Verifies the Ed25519 request signature and sets req.agent.
export function agentAuth() {
  return async (req, res, next) => {
    try {
      req.agent = await req.app.locals.services.agents.authenticate(
        {
          agentId: req.get('x-vaultpanel-agent-id'),
          timestamp: req.get('x-vaultpanel-timestamp'),
          nonce: req.get('x-vaultpanel-nonce'),
          signature: req.get('x-vaultpanel-signature'),
          method: req.method,
          path: req.originalUrl,
          rawBody: req.rawBody ?? '',
        },
        requestMeta(req, res),
      );
      next();
    } catch (err) {
      next(err);
    }
  };
}
