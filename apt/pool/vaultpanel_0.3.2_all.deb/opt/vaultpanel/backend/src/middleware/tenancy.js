import { forbidden, notFound } from '../utils/errors.js';
import { ownerOf } from '../services/tenancy.js';

// The parts of the API a hosting customer can reach at all. Everything else
// (servers, users, security, monitoring...) is refused before any handler
// runs, on top of the permission checks.
const CUSTOMER_AREAS = new Set([
  'auth',
  'api-tokens',
  'hosting',
  'websites',
  'subdomains',
  'domains',
  'ssl-certificates',
  'applications',
  'deployments',
  'databases',
  'database-users',
  'backups',
  'backup-schedules',
  'cron-jobs',
  'jobs',
  'cms',
]);

export function customerAreas() {
  return (req, res, next) => {
    if (!req.actor?.customerId) return next();
    const area = req.path.split('/')[1] ?? '';
    next(CUSTOMER_AREAS.has(area) ? undefined : forbidden());
  };
}

// router.param handler: an :id in the URL must belong to the customer making
// the request (others read as not found). Staff requests pass through.
export function ownedParam(kind) {
  return async (req, res, next, id) => {
    try {
      if (!req.actor?.customerId) return next();
      const owner = await ownerOf(req.app.locals.db, kind, id);
      next(owner && owner === req.actor.customerId ? undefined : notFound());
    } catch (err) {
      next(err);
    }
  };
}
