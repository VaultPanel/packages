import { randomUUID } from 'node:crypto';

const VALID = /^[A-Za-z0-9._-]{8,64}$/;

// Every request gets an id that appears in logs, the audit log and the
// response, so a user-visible error can be traced end to end.
export function requestId() {
  return (req, res, next) => {
    const incoming = req.get('x-request-id');
    const id = incoming && VALID.test(incoming) ? incoming : randomUUID();
    res.locals.requestId = id;
    res.set('X-Request-Id', id);
    next();
  };
}

export function requestMeta(req, res) {
  return { ip: req.ip, userAgent: req.get('user-agent') ?? null, requestId: res.locals.requestId };
}
