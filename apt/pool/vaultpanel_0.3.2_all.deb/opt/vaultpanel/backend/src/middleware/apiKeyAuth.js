import { unauthenticated } from '../utils/errors.js';
import { requestMeta } from './requestId.js';

// Billing systems authenticate with an API key: "Authorization: Bearer vpk_...".
// No cookie is involved, so there is no CSRF token either.
export function requireApiKey() {
  return async (req, res, next) => {
    try {
      const header = req.get('authorization') ?? '';
      const match = header.match(/^Bearer\s+(\S+)$/i);
      const actor = match ? await req.app.locals.services.apiKeys.resolve(match[1], requestMeta(req, res)) : null;
      if (!actor) return next(unauthenticated('A valid API key is required (Authorization: Bearer vpk_...)'));
      req.actor = actor;
      next();
    } catch (err) {
      next(err);
    }
  };
}
