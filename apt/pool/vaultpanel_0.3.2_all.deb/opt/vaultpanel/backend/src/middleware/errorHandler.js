import { ZodError } from 'zod';
import { AppError } from '../utils/errors.js';
import { sendError } from '../utils/response.js';
import { zodToValidationError } from './validate.js';

export function notFoundHandler() {
  return (req, res) => sendError(res, 404, { code: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` });
}

// Turns any error into the standard error response. Unexpected errors are
// logged with the request id and reported to the client without internals.
export function errorHandler(logger) {
  // eslint-disable-next-line no-unused-vars
  return (err, req, res, next) => {
    let error = err;
    if (err instanceof ZodError) error = zodToValidationError(err);
    else if (err?.type === 'entity.parse.failed') error = new AppError(400, 'BAD_JSON', 'Request body is not valid JSON');
    else if (err?.type === 'entity.too.large') error = new AppError(413, 'PAYLOAD_TOO_LARGE', 'Request body is too large');

    if (error instanceof AppError) {
      if (error.status >= 500) logger.error({ err, requestId: res.locals.requestId }, error.message);
      return sendError(res, error.status, { code: error.code, message: error.message, details: error.details });
    }

    logger.error({ err, requestId: res.locals.requestId }, 'unhandled error');
    return sendError(res, 500, {
      code: 'INTERNAL_ERROR',
      message: 'Something went wrong on the server. Quote the request id when reporting it.',
    });
  };
}
