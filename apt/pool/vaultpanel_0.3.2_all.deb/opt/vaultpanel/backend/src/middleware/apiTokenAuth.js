import { API_TOKEN_PREFIX, PLUGIN_TOKEN_PREFIX } from '@vaultpanel/shared';
import { forbidden, unauthenticated } from '../utils/errors.js';
import { requestMeta } from './requestId.js';

// Scripts, the command-line tool and the SDK authenticate with
// "Authorization: Bearer vpt_...", and plugins with "Bearer vpp_...". A token request carries no cookie, so
// there is no CSRF token either; everything else (permissions, tenancy,
// validation, audit log) is the same as for a browser request.
//
// Runs before loadSession(): when a token is present it wins, so a tool is
// never silently affected by a session cookie that happens to be around.
export function loadApiToken() {
  return async (req, res, next) => {
    try {
      const token = bearerToken(req);
      if (!token) return next();
      const { services } = req.app.locals;
      if (token.startsWith(PLUGIN_TOKEN_PREFIX)) {
        const plugin = await services.plugins.resolve(token, requestMeta(req, res));
        if (!plugin) return next(unauthenticated('The plugin token is not valid. It may have been replaced, or the plugin removed.'));
        if (plugin.disabled) return next(unauthenticated('This plugin is turned off in the panel'));
        req.actor = plugin.actor;
        return next();
      }
      const resolved = await services.apiTokens.resolve(token, requestMeta(req, res));
      if (!resolved) return next(unauthenticated('The API token is not valid, has expired or was revoked'));
      req.actor = resolved.actor;
      next();
    } catch (err) {
      next(err);
    }
  };
}

// Sign-in, password changes and two-factor settings stay interactive: a token
// may read who it belongs to and nothing else under /auth.
export function rejectApiToken(message = 'This can only be done while signed in to the panel, not with an API token') {
  return (req, res, next) => next(req.actor?.tokenId ? forbidden(message) : undefined);
}

export function bearerToken(req) {
  const match = (req.get('authorization') ?? '').match(/^Bearer\s+(\S+)$/i);
  const value = match?.[1];
  return value?.startsWith(API_TOKEN_PREFIX) || value?.startsWith(PLUGIN_TOKEN_PREFIX) ? value : null;
}
