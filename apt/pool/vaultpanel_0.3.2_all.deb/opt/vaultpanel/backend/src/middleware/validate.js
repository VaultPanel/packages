import { ZodError } from 'zod';
import { validationError } from '../utils/errors.js';

// Validates and coerces req.body / req.query / req.params with a Zod schema.
// The parsed values land on req.valid.body / .query / .params.
export function validate(schemas) {
  return (req, res, next) => {
    req.valid ??= {};
    try {
      for (const part of ['params', 'query', 'body']) {
        if (schemas[part]) req.valid[part] = schemas[part].parse(req[part] ?? {});
      }
      next();
    } catch (err) {
      next(err instanceof ZodError ? zodToValidationError(err) : err);
    }
  };
}

export function zodToValidationError(err) {
  return validationError(err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })));
}
