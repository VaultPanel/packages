// Refuses API requests from addresses the panel does not accept, when an
// owner or admin turned that on (services/panelAccessService.js). Runs after
// the session is known: with the scope "staff", hosting customers are let
// through, and so is someone not signed in yet (a staff member is stopped
// when they sign in). Plugins use their own approved token.
export function panelAccess() {
  return async (req, res, next) => {
    try {
      const actor = req.actor;
      if (actor?.type === 'plugin') return next();
      const customer = actor ? Boolean(actor.customerId) : true;
      await req.app.locals.services.panelAccess.assertAllowed(req.ip, { customer });
      next();
    } catch (err) {
      next(err);
    }
  };
}
