import { Router } from 'express';
import { tokenController as c } from '../controllers/tokenController.js';
import { requireAuth } from '../middleware/auth.js';
import { rejectApiToken } from '../middleware/apiTokenAuth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import { createTokenBody, tokenListQuery } from '../validators/tokenValidators.js';

export function tokenRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: tokenListQuery }), c.list);
  r.get('/scopes', c.scopes);
  // A token cannot mint or revoke tokens: that is done in the panel, by a
  // person who has just signed in.
  r.post('/', rejectApiToken('Create API tokens in the panel, under Users > API Tokens'), validate({ body: createTokenBody }), c.create);
  r.post('/:id/revoke', rejectApiToken('Revoke API tokens in the panel, under Users > API Tokens'), validate({ params: idParam }), c.revoke);
  return r;
}
