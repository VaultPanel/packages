import { Router } from 'express';
import { systemController } from '../controllers/systemController.js';
import { loadApiToken } from '../middleware/apiTokenAuth.js';
import { csrfProtection, loadSession, requireAuth, requireTwoFactorSetup } from '../middleware/auth.js';
import { panelAccess } from '../middleware/panelAccess.js';
import { customerAreas } from '../middleware/tenancy.js';
import { agentRoutes } from './agentRoutes.js';
import { applicationRoutes, deploymentRoutes, hookRoutes } from './applicationRoutes.js';
import { alertRoutes, monitoringRoutes } from './alertRoutes.js';
import { assistantRoutes } from './assistantRoutes.js';
import { authRoutes } from './authRoutes.js';
import { cmsRoutes } from './cmsRoutes.js';
import { containerRoutes } from './containerRoutes.js';
import { backupRoutes, backupScheduleRoutes, backupStorageRoutes, cronRoutes, webhookRoutes } from './automationRoutes.js';
import { databaseRoutes, databaseUserRoutes } from './databaseRoutes.js';
import { dnsRoutes } from './dnsRoutes.js';
import { mailRoutes } from './mailRoutes.js';
import { bulkActionRoutes, serverGroupRoutes } from './fleetRoutes.js';
import { billingRoutes, hostingRoutes } from './hostingRoutes.js';
import { jobRoutes } from './jobRoutes.js';
import { pluginRoutes } from './pluginRoutes.js';
import { securityRoutes } from './securityRoutes.js';
import { serverRoutes } from './serverRoutes.js';
import { settingsRoutes } from './settingsRoutes.js';
import { terminalSessionRoutes } from './terminalSessionRoutes.js';
import { subdomainRoutes } from './subdomainRoutes.js';
import { tokenRoutes } from './tokenRoutes.js';
import { auditRoutes, roleRoutes, userRoutes } from './userRoutes.js';
import { certificateRoutes, domainRoutes, websiteRoutes } from './websiteRoutes.js';

export function apiRoutes(limits) {
  const api = Router();
  api.get('/health', systemController.health);

  // Agents authenticate by signature, not by cookie.
  api.use('/agent', agentRoutes(limits));
  // Git push webhooks authenticate by the token in their URL.
  api.use('/hooks', hookRoutes(limits));
  // Billing systems authenticate with an API key.
  api.use('/billing', billingRoutes(limits));

  // Everything below is the browser and API surface. A request carrying an
  // API token (Authorization: Bearer vpt_...) is resolved first and skips the
  // cookie and CSRF checks; everything after that is identical.
  api.use(limits.api, loadApiToken(), loadSession(), csrfProtection());
  // Only from approved addresses, when that is turned on.
  api.use(panelAccess());
  api.use('/auth', authRoutes(limits));
  // Past this point, an account the two-factor policy covers must have it on.
  api.use(requireTwoFactorSetup());
  // Hosting customers reach only their own websites, apps, databases...
  api.use(customerAreas());
  api.use('/api-tokens', tokenRoutes());
  api.use('/users', userRoutes());
  api.use('/roles', roleRoutes());
  api.use('/audit-logs', auditRoutes());
  api.use('/servers', serverRoutes());
  api.use('/terminal-sessions', terminalSessionRoutes());
  api.use('/server-groups', serverGroupRoutes());
  api.use('/bulk-actions', bulkActionRoutes());
  api.use('/jobs', jobRoutes());
  api.use('/alerts', alertRoutes());
  api.use('/monitoring', monitoringRoutes());
  api.use('/websites', websiteRoutes());
  api.use('/subdomains', subdomainRoutes());
  api.use('/domains', domainRoutes());
  api.use('/ssl-certificates', certificateRoutes());
  api.use('/dns', dnsRoutes());
  api.use('/mail', mailRoutes());
  api.use('/applications', applicationRoutes());
  api.use('/deployments', deploymentRoutes());
  api.use('/cms', cmsRoutes());
  api.use('/databases', databaseRoutes());
  api.use('/database-users', databaseUserRoutes());
  api.use('/backups', backupRoutes());
  api.use('/backup-schedules', backupScheduleRoutes());
  api.use('/backup-storage', backupStorageRoutes());
  api.use('/cron-jobs', cronRoutes());
  api.use('/webhooks', webhookRoutes());
  api.use('/security', securityRoutes());
  api.use('/hosting', hostingRoutes());
  api.use('/assistant', assistantRoutes());
  api.use('/containers', containerRoutes());
  api.use('/plugins', pluginRoutes());
  api.use('/settings', settingsRoutes());
  api.get('/dashboard', requireAuth(), systemController.dashboard);
  return api;
}
