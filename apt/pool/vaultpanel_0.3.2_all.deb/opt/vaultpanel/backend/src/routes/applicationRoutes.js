import { Router } from 'express';
import { applicationController as c, deploymentController } from '../controllers/applicationController.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  addWebsiteBody,
  appLogsBody,
  applicationListQuery,
  controlParam,
  createApplicationBody,
  deleteApplicationQuery,
  deploymentListQuery,
  envBody,
  rollbackBody,
  scaleBody,
  suggestPortQuery,
  updateApplicationBody,
  webhookParam,
} from '../validators/applicationValidators.js';

export function applicationRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('application'));
  r.get('/', validate({ query: applicationListQuery }), c.list);
  r.post('/', validate({ body: createApplicationBody }), c.create);
  r.get('/suggest-port', validate({ query: suggestPortQuery }), c.suggestPort);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateApplicationBody }), c.update);
  r.delete('/:id', validate({ params: idParam, query: deleteApplicationQuery }), c.remove);
  r.get('/:id/environment', validate({ params: idParam }), c.getEnv);
  r.put('/:id/environment', validate({ params: idParam, body: envBody }), c.setEnv);
  r.post('/:id/deploy', validate({ params: idParam }), c.deploy);
  r.post('/:id/rollback', validate({ params: idParam, body: rollbackBody }), c.rollback);
  r.post('/:id/apply', validate({ params: idParam }), c.apply);
  r.post('/:id/scale', validate({ params: idParam, body: scaleBody }), c.scale);
  r.post('/:id/status', validate({ params: idParam }), c.refresh);
  r.post('/:id/logs', validate({ params: idParam, body: appLogsBody }), c.logs);
  r.post('/:id/website', validate({ params: idParam, body: addWebsiteBody }), c.addWebsite);
  r.post('/:id/webhook', validate({ params: idParam }), c.enableWebhook);
  r.delete('/:id/webhook', validate({ params: idParam }), c.disableWebhook);
  r.post('/:id/:action', validate({ params: controlParam }), c.control);
  return r;
}

export function deploymentRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('deployment'));
  r.get('/', validate({ query: deploymentListQuery }), deploymentController.list);
  r.get('/:id', validate({ params: idParam }), deploymentController.get);
  return r;
}

// Push-to-deploy. No session or CSRF token: the secret token in the URL is
// the credential, and it can only start a deployment of its own app.
export function hookRoutes(limits) {
  const r = Router();
  r.post('/deploy/:token', limits.hooks, validate({ params: webhookParam }), c.hook);
  return r;
}
