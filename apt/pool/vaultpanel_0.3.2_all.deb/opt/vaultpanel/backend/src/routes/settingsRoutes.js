import { Router } from 'express';
import { panelDomainController as c } from '../controllers/panelDomainController.js';
import { panelEmailController as mail } from '../controllers/panelEmailController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { panelAddressBody, panelDomainBody } from '../validators/panelDomainValidators.js';
import { emailMessagesQuery, emailSettingsBody, emailTestBody } from '../validators/panelEmailValidators.js';

// Settings of the panel itself.
export function settingsRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/panel-domain', c.get);
  r.put('/panel-domain', validate({ body: panelDomainBody }), c.set);
  r.put('/panel-domain/address', validate({ body: panelAddressBody }), c.useDomain);
  r.delete('/panel-domain', c.remove);
  // Email the panel sends (System > Panel Email).
  r.get('/email', mail.get);
  r.put('/email', validate({ body: emailSettingsBody }), mail.update);
  r.post('/email/test', validate({ body: emailTestBody }), mail.test);
  r.get('/email/messages', validate({ query: emailMessagesQuery }), mail.messages);
  return r;
}
