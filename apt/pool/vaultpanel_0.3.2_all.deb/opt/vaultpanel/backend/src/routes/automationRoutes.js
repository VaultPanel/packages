import { Router } from 'express';
import { backupController as b, backupScheduleController as bs, backupStorageController as st, cronController as c, webhookController as w } from '../controllers/automationController.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import {
  backupListQuery,
  createBackupBody,
  createCronBody,
  createWebhookBody,
  cronListQuery,
  cronRunsQuery,
  deliveryListQuery,
  deliveryParams,
  restoreBackupBody,
  saveScheduleBody,
  saveStorageBody,
  scheduleListQuery,
  testStorageBody,
  updateCronBody,
  updateWebhookBody,
  webhookListQuery,
} from '../validators/automationValidators.js';
import { idParam } from '../validators/common.js';

export function backupRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('backup'));
  r.get('/', validate({ query: backupListQuery }), b.list);
  r.post('/', validate({ body: createBackupBody }), b.create);
  r.get('/:id', validate({ params: idParam }), b.get);
  r.delete('/:id', validate({ params: idParam }), b.remove);
  r.post('/:id/restore', validate({ params: idParam, body: restoreBackupBody }), b.restore);
  r.post('/:id/download', validate({ params: idParam }), b.prepareDownload);
  r.get('/:id/download', validate({ params: idParam }), b.download);
  return r;
}

export function backupScheduleRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('backup_schedule'));
  r.get('/', validate({ query: scheduleListQuery }), bs.list);
  // One schedule per website, app or database: PUT creates or replaces it.
  r.put('/', validate({ body: saveScheduleBody }), bs.save);
  r.delete('/:id', validate({ params: idParam }), bs.remove);
  return r;
}

// S3-compatible destinations for backups. Staff only (customers are kept out
// of /backup-storage by customerAreas).
export function backupStorageRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', st.list);
  r.post('/', validate({ body: saveStorageBody }), st.create);
  r.get('/:id', validate({ params: idParam }), st.get);
  r.put('/:id', validate({ params: idParam, body: saveStorageBody }), st.update);
  r.delete('/:id', validate({ params: idParam }), st.remove);
  r.post('/:id/test', validate({ params: idParam, body: testStorageBody }), st.test);
  return r;
}

export function cronRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('cron_job'));
  r.get('/', validate({ query: cronListQuery }), c.list);
  r.post('/', validate({ body: createCronBody }), c.create);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateCronBody }), c.update);
  r.delete('/:id', validate({ params: idParam }), c.remove);
  r.post('/:id/run', validate({ params: idParam }), c.run);
  r.get('/:id/runs', validate({ params: idParam, query: cronRunsQuery }), c.runs);
  return r;
}

export function webhookRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: webhookListQuery }), w.list);
  r.post('/', validate({ body: createWebhookBody }), w.create);
  r.get('/:id', validate({ params: idParam }), w.get);
  r.patch('/:id', validate({ params: idParam, body: updateWebhookBody }), w.update);
  r.delete('/:id', validate({ params: idParam }), w.remove);
  r.post('/:id/test', validate({ params: idParam }), w.test);
  r.get('/:id/deliveries', validate({ params: idParam, query: deliveryListQuery }), w.deliveries);
  r.post('/:id/deliveries/:deliveryId/redeliver', validate({ params: deliveryParams }), w.redeliver);
  return r;
}
