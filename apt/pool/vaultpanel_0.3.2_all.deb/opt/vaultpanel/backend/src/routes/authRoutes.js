import { Router } from 'express';
import { authController as c } from '../controllers/authController.js';
import { rejectApiToken } from '../middleware/apiTokenAuth.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import * as v from '../validators/authValidators.js';
import { idParam } from '../validators/common.js';

export function authRoutes(limits) {
  const r = Router();
  r.get('/setup', c.setupStatus);
  r.post('/setup', limits.setup, validate({ body: v.setupBody }), c.setup);
  r.post('/login', limits.login, validate({ body: v.loginBody }), c.login);
  r.post('/login/2fa', limits.login, validate({ body: v.twoFactorLoginBody }), c.loginTwoFactor);
  r.post('/sso', limits.login, validate({ body: v.resetTokenBody }), c.sso);
  r.post('/password-reset/request', limits.passwordReset, validate({ body: v.resetRequestBody }), c.requestPasswordReset);
  r.post('/password-reset/inspect', limits.passwordReset, validate({ body: v.resetTokenBody }), c.inspectResetToken);
  r.post('/password-reset/complete', limits.passwordReset, validate({ body: v.resetPasswordBody }), c.resetPassword);

  r.use(requireAuth());
  // A token may ask who it belongs to and what it can do; signing in and out,
  // passwords, two-factor settings and sessions stay interactive.
  r.get('/me', c.me);
  r.use(rejectApiToken());
  r.post('/logout', c.logout);
  r.post('/password', limits.login, validate({ body: v.changePasswordBody }), c.changePassword);
  r.post('/2fa/setup', c.beginTotpSetup);
  r.post('/2fa/enable', limits.login, validate({ body: v.enableTotpBody }), c.enableTotp);
  r.post('/2fa/disable', limits.login, validate({ body: v.disableTotpBody }), c.disableTotp);
  r.post('/2fa/recovery-codes', limits.login, validate({ body: v.disableTotpBody }), c.regenerateRecoveryCodes);
  r.get('/sessions', c.listSessions);
  r.post('/sessions/sign-out-others', c.revokeOtherSessions);
  r.delete('/sessions/:id', validate({ params: idParam }), c.revokeSession);
  return r;
}
