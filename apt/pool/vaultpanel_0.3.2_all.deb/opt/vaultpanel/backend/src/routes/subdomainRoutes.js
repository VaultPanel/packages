import { Router } from 'express';
import { subdomainController as c } from '../controllers/subdomainController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { createSubdomainBody } from '../validators/websiteValidators.js';

// Subdomains of the account's own domains. They are websites, so they are
// listed (GET /websites?subdomains=true), changed and deleted there.
export function subdomainRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/parents', c.parents);
  r.post('/', validate({ body: createSubdomainBody }), c.create);
  return r;
}
