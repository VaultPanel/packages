import { Router } from 'express';
import { databaseController as c, databaseUserController as u } from '../controllers/databaseController.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  createDatabaseBody,
  createDatabaseUserBody,
  databaseListQuery,
  databaseUserListQuery,
  queryBody,
  tableRowsBody,
  updateDatabaseBody,
  updateDatabaseUserBody,
} from '../validators/databaseValidators.js';

export function databaseRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('database'));
  r.get('/', validate({ query: databaseListQuery }), c.list);
  r.post('/', validate({ body: createDatabaseBody }), c.create);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateDatabaseBody }), c.update);
  r.delete('/:id', validate({ params: idParam }), c.remove);
  r.post('/:id/retry', validate({ params: idParam }), c.retry);
  r.post('/:id/tables', validate({ params: idParam }), c.tables);
  r.post('/:id/rows', validate({ params: idParam, body: tableRowsBody }), c.rows);
  r.post('/:id/query', validate({ params: idParam, body: queryBody }), c.query);
  r.post('/:id/phpmyadmin', validate({ params: idParam }), c.phpmyadmin);
  return r;
}

export function databaseUserRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('database_user'));
  r.get('/', validate({ query: databaseUserListQuery }), u.list);
  r.post('/', validate({ body: createDatabaseUserBody }), u.create);
  r.patch('/:id', validate({ params: idParam, body: updateDatabaseUserBody }), u.update);
  r.delete('/:id', validate({ params: idParam }), u.remove);
  r.post('/:id/password', validate({ params: idParam }), u.password);
  return r;
}
