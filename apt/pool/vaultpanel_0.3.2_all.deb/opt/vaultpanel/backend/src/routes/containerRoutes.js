import { Router } from 'express';
import { containerController as c } from '../controllers/containerController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import * as v from '../validators/containerValidators.js';

// Docker containers (phase 10). /containers/:id are the containers VaultPanel
// deployed; /containers/servers/:serverId/... reach every container on a
// server and Docker itself. Reads and changes on the server are jobs for its
// agent (202 with the job); the agent talks to Docker's API, never a shell.
export function containerRoutes() {
  const r = Router();
  r.use(requireAuth());

  const server = (path = '') => `/servers/:serverId${path}`;
  r.get('/servers', c.servers);
  r.post(server('/docker/status'), validate({ params: v.serverParams }), c.dockerStatus);
  r.post(server('/docker/install'), validate({ params: v.serverParams }), c.installDocker);
  r.post(server('/containers/list'), validate({ params: v.serverParams }), c.listLive);
  r.post(server('/containers/:ref/logs'), validate({ params: v.serverContainerParams, body: v.logsBody }), c.logs);
  r.post(server('/containers/:ref/inspect'), validate({ params: v.serverContainerParams }), c.inspect);
  r.post(server('/containers/:ref/remove'), validate({ params: v.serverContainerParams }), c.removeLive);
  r.post(server('/containers/:ref/:action'), validate({ params: v.serverActionParams }), c.act);
  r.post(server('/images/list'), validate({ params: v.serverParams }), c.listImages);
  r.post(server('/images/pull'), validate({ params: v.serverParams, body: v.pullImageBody }), c.pullImage);
  r.post(server('/images/remove'), validate({ params: v.serverParams, body: v.removeImageBody }), c.removeImage);

  r.get('/', validate({ query: v.containerListQuery }), c.list);
  r.post('/', validate({ body: v.createContainerBody }), c.create);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: v.updateContainerBody }), c.update);
  r.delete('/:id', validate({ params: idParam, query: v.removeQuery }), c.remove);
  r.get('/:id/environment', validate({ params: idParam }), c.env);
  r.post('/:id/redeploy', validate({ params: idParam, body: v.redeployBody }), c.redeploy);
  r.post('/:id/:action', validate({ params: v.containerActionParams }), c.actOn);
  return r;
}
