import { Router } from 'express';
import { securityController as c } from '../controllers/securityController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import * as v from '../validators/securityValidators.js';

// Server security (each change is a job for the server's agent) and the
// panel's sign-in policy and sessions. Reading the full state of one server
// is the SECURITY_STATUS operation (POST /servers/:id/jobs).
export function securityRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/overview', c.overview);
  r.get('/authentication', c.authentication);
  r.put('/authentication', validate({ body: v.twoFactorPolicyBody }), c.setTwoFactorPolicy);
  r.get('/panel-access', c.panelAccess);
  r.put('/panel-access', validate({ body: v.panelAccessBody }), c.setPanelAccess);
  r.get('/sessions', c.sessions);
  r.delete('/sessions/:id', validate({ params: idParam }), c.revokeSession);

  const server = (path) => `/servers/:id${path}`;
  r.get(server(''), validate({ params: idParam }), c.server);
  r.put(server('/firewall'), validate({ params: idParam, body: v.firewallStateBody }), c.setFirewall);
  r.post(server('/firewall/rules'), validate({ params: idParam, body: v.firewallRuleBody }), c.addRule);
  r.post(server('/firewall/rules/delete'), validate({ params: idParam, body: v.firewallRuleDeleteBody }), c.deleteRule);
  r.put(server('/firewall/default'), validate({ params: idParam, body: v.firewallDefaultBody }), c.setFirewallDefault);
  r.put(server('/ssh'), validate({ params: idParam, body: v.sshSettingsBody }), c.configureSsh);
  r.post(server('/ssh/keys'), validate({ params: idParam, body: v.sshKeyBody }), c.addSshKey);
  r.post(server('/ssh/keys/delete'), validate({ params: idParam, body: v.sshKeyDeleteBody }), c.removeSshKey);
  r.put(server('/ssh/ports'), validate({ params: idParam, body: v.sshPortsBody }), c.setSshPorts);
  r.put(server('/login-banner'), validate({ params: idParam, body: v.loginBannerBody }), c.setLoginBanner);
  r.put(server('/fail2ban'), validate({ params: idParam, body: v.fail2banBody }), c.configureFail2ban);
  r.post(server('/fail2ban/unban'), validate({ params: idParam, body: v.unbanBody }), c.unban);
  r.put(server('/updates'), validate({ params: idParam, body: v.autoUpdatesBody }), c.setAutoUpdates);
  r.post(server('/updates/install'), validate({ params: idParam }), c.installUpdates);
  return r;
}
