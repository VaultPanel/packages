import { Router } from 'express';
import { mailController as c } from '../controllers/mailController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  createDomainBody,
  createForwarderBody,
  createMailboxBody,
  domainListQuery,
  itemParams,
  removeQuery,
  serverIdParam,
  setupServerBody,
  updateForwarderBody,
  updateMailboxBody,
} from '../validators/mailValidators.js';

// Email hosting: mail servers, domains, mailboxes and forwarders (staff only:
// hosting customers do not reach /mail).
export function mailRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/servers', c.listServers);
  r.post('/servers', validate({ body: setupServerBody }), c.setupServer);
  r.post('/servers/:serverId/apply', validate({ params: serverIdParam }), c.applyServer);
  r.post('/servers/:serverId/check', validate({ params: serverIdParam }), c.checkServer);
  r.post('/servers/:serverId/usage', validate({ params: serverIdParam }), c.usage);
  r.get('/domains', validate({ query: domainListQuery }), c.listDomains);
  r.post('/domains', validate({ body: createDomainBody }), c.createDomain);
  r.get('/domains/:id', validate({ params: idParam }), c.getDomain);
  r.delete('/domains/:id', validate({ params: idParam, query: removeQuery }), c.removeDomain);
  r.post('/domains/:id/dns', validate({ params: idParam }), c.addDnsRecords);
  r.post('/domains/:id/check', validate({ params: idParam }), c.checkDns);
  r.post('/domains/:id/mailboxes', validate({ params: idParam, body: createMailboxBody }), c.createMailbox);
  r.patch('/domains/:id/mailboxes/:itemId', validate({ params: itemParams, body: updateMailboxBody }), c.updateMailbox);
  r.delete('/domains/:id/mailboxes/:itemId', validate({ params: itemParams, query: removeQuery }), c.removeMailbox);
  r.post('/domains/:id/forwarders', validate({ params: idParam, body: createForwarderBody }), c.createForwarder);
  r.patch('/domains/:id/forwarders/:itemId', validate({ params: itemParams, body: updateForwarderBody }), c.updateForwarder);
  r.delete('/domains/:id/forwarders/:itemId', validate({ params: itemParams }), c.removeForwarder);
  return r;
}
