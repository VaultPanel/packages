import { Router } from 'express';
import { userController as c } from '../controllers/userController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { auditListQuery } from '../services/auditService.js';
import { userListQuery } from '../services/userService.js';
import { idParam } from '../validators/common.js';
import { inviteUserBody, updateUserBody } from '../validators/userValidators.js';

export function userRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: userListQuery }), c.list);
  r.post('/', validate({ body: inviteUserBody }), c.invite);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateUserBody }), c.update);
  r.post('/:id/password-reset', validate({ params: idParam }), c.issuePasswordReset);
  r.post('/:id/2fa/reset', validate({ params: idParam }), c.resetTwoFactor);
  return r;
}

export function roleRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', c.listRoles);
  return r;
}

export function auditRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: auditListQuery }), c.listAudit);
  return r;
}
