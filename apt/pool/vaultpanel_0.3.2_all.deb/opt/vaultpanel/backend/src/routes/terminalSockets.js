import { randomUUID } from 'node:crypto';
import { WebSocketServer } from 'ws';
import { isDirectLoopback } from '../middleware/agentAuth.js';

export const AGENT_TERMINAL_PATH = '/api/v1/agent/terminal';
export const BROWSER_TERMINAL_PATH = '/api/v1/terminal/connect';
const MAX_FRAME = 1024 * 1024;

// WebSocket endpoints of the server terminal (see services/terminalService.js):
//   /api/v1/agent/terminal    an agent's link, signed like its other requests
//   /api/v1/terminal/connect  a browser, with the one-time ticket from
//                             POST /servers/:id/terminal
// They work wherever the API does: straight on the API port, through Vite's
// dev proxy (5173) and through NGINX (the panel domain), which pass upgrades on.
// `server` may be one HTTP(S) server or several (HTTPS and its loopback twin).
export function attachTerminalSockets(server, app, { logger } = {}) {
  const { services, config } = app.locals;
  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_FRAME });
  services.terminals.start();

  for (const s of Array.isArray(server) ? server : [server]) s.on('upgrade', onUpgrade);

  function onUpgrade(req, socket, head) {
    // Gives the raw request Express's helpers (req.ip, req.secure, req.get)
    // with the app's trust proxy setting.
    Object.setPrototypeOf(req, app.request);
    const url = new URL(req.url, 'http://panel.invalid');
    if (url.pathname === AGENT_TERMINAL_PATH) return upgradeAgent(req, socket, head, url);
    if (url.pathname === BROWSER_TERMINAL_PATH) return upgradeBrowser(req, socket, head, url);
    refuse(socket, 404, 'Not Found');
  }

  async function upgradeAgent(req, socket, head, url) {
    const meta = { ip: req.ip, userAgent: req.get('user-agent') ?? null, requestId: randomUUID() };
    try {
      if (!(req.secure || config.allowInsecureAgents || isDirectLoopback(req))) return refuse(socket, 403, 'Forbidden');
      const q = url.searchParams;
      const ctx = await services.agents.authenticate(
        {
          agentId: q.get('agentId'),
          timestamp: q.get('timestamp'),
          nonce: q.get('nonce'),
          signature: q.get('signature'),
          method: 'GET',
          path: AGENT_TERMINAL_PATH,
          rawBody: '',
        },
        meta,
      );
      wss.handleUpgrade(req, socket, head, (ws) => {
        const handlers = services.terminals.attachAgent(ctx.server, ctx.agent.agent_version, channelFor(ws));
        ws.on('message', (data, isBinary) => !isBinary && handlers.message(data.toString('utf8')));
        ws.on('close', () => handlers.close());
        ws.on('error', () => ws.terminate());
      });
    } catch (err) {
      logger?.warn?.({ err: err.message, ip: meta.ip }, 'agent terminal link refused');
      refuse(socket, err.status ?? 401, 'Unauthorized');
    }
  }

  async function upgradeBrowser(req, socket, head, url) {
    const meta = { ip: req.ip, userAgent: req.get('user-agent') ?? null };
    // The terminal is staff-only, so the panel's address list applies.
    if (!(await services.panelAccess.allows(req.ip).catch(() => false))) return refuse(socket, 403, 'Forbidden');
    wss.handleUpgrade(req, socket, head, async (ws) => {
      const queue = [];
      let handlers = null;
      let closed = false;
      ws.on('message', (data, isBinary) => {
        if (isBinary) return;
        const text = data.toString('utf8');
        if (handlers) handlers.message(text);
        else queue.push(text);
      });
      ws.on('close', () => {
        closed = true;
        handlers?.close();
      });
      ws.on('error', () => ws.terminate());
      try {
        handlers = await services.terminals.attachBrowser(url.searchParams.get('ticket'), channelFor(ws), meta);
        if (handlers && closed) handlers.close();
        else if (handlers) for (const text of queue.splice(0)) handlers.message(text);
      } catch (err) {
        logger?.error?.({ err }, 'terminal session failed to open');
        ws.close(1011, 'error');
      }
    });
  }

  return wss;
}

function channelFor(ws) {
  return {
    send: (msg) => ws.readyState === ws.OPEN && ws.send(JSON.stringify(msg)),
    sendBinary: (buffer) => ws.readyState === ws.OPEN && ws.send(buffer, { binary: true }),
    bufferedAmount: () => ws.bufferedAmount,
    close: (code, reason) => ws.readyState <= ws.OPEN && ws.close(code, reason),
  };
}

function refuse(socket, status, text) {
  if (!socket.writable) return socket.destroy();
  socket.end(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
}
