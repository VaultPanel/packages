import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { recordingSettingsBody } from '../services/terminalRecordingService.js';
import { sendOk } from '../utils/response.js';
import { idParam } from '../validators/common.js';

const recordings = (req) => req.app.locals.services.terminalRecordings;

const listQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
  serverId: z.uuid().optional(),
  userId: z.uuid().optional(),
});
const recordingQuery = z.object({ download: z.enum(['0', '1']).optional() });

// Past terminal sessions and their recordings (owners only, like the
// terminal itself).
export function terminalSessionRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/settings', async (req, res) => sendOk(res, await recordings(req).getSettings(req.actor)));
  r.put('/settings', validate({ body: recordingSettingsBody }), async (req, res) =>
    sendOk(res, await recordings(req).updateSettings(req.actor, req.valid.body), { message: 'Terminal recording settings saved' }),
  );
  r.get('/', validate({ query: listQuery }), async (req, res) => sendOk(res, await recordings(req).list(req.actor, req.valid.query)));
  r.get('/:id', validate({ params: idParam }), async (req, res) => sendOk(res, await recordings(req).get(req.actor, req.valid.params.id)));
  r.get('/:id/recording', validate({ params: idParam, query: recordingQuery }), async (req, res) => {
    const download = req.valid.query.download === '1';
    const file = await recordings(req).openRecording(req.actor, req.valid.params.id, { download });
    res.set('Content-Type', 'application/x-asciicast; charset=utf-8');
    res.set('Content-Length', String(file.size));
    res.set('Cache-Control', 'no-store');
    res.set('Content-Disposition', `${download ? 'attachment' : 'inline'}; filename="${file.filename.replace(/[^A-Za-z0-9._-]/g, '_')}"`);
    file.stream.on('error', () => res.destroy());
    file.stream.pipe(res);
  });
  r.delete('/:id', validate({ params: idParam }), async (req, res) => {
    await recordings(req).remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Recording deleted' });
  });
  return r;
}
