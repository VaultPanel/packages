import { Router } from 'express';
import { serverController as c } from '../controllers/serverController.js';
import { serverGroupController as g } from '../controllers/fleetController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { serverListQuery } from '../services/serverService.js';
import { idParam } from '../validators/common.js';
import { serverGroupsBody } from '../validators/fleetValidators.js';
import { createJobBody, createServerBody, metricsQuery, terminalBody, updateServerBody } from '../validators/serverValidators.js';

export function serverRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: serverListQuery }), c.list);
  r.post('/', validate({ body: createServerBody }), c.create);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateServerBody }), c.update);
  r.delete('/:id', validate({ params: idParam }), c.remove);
  r.post('/:id/enrollment-tokens', validate({ params: idParam }), c.createEnrollment);
  r.get('/:id/metrics', validate({ params: idParam, query: metricsQuery }), c.metrics);
  r.post('/:id/jobs', validate({ params: idParam, body: createJobBody }), c.createJob);
  r.put('/:id/groups', validate({ params: idParam, body: serverGroupsBody }), g.setServerGroups);
  r.post('/:id/agent-update', validate({ params: idParam }), c.updateAgent);
  r.post('/:id/terminal', validate({ params: idParam, body: terminalBody }), c.openTerminal);
  return r;
}
