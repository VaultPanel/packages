import { Router } from 'express';
import { agentController as c } from '../controllers/agentController.js';
import { agentAuth, requireAgentTransport } from '../middleware/agentAuth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import { backupChunkBody, cronRunsBody, downloadChunkBody, uploadChunkQuery, heartbeatBody, jobLogsBody, jobResultBody, registerBody } from '../validators/agentValidators.js';

// Endpoints used by server agents. Everything after /register requires a
// valid Ed25519 request signature from a registered, non-revoked agent.
export function agentRoutes(limits) {
  const r = Router();
  r.get('/install.sh', limits.agentDownload, c.installScript);
  r.get('/package.tgz', limits.agentDownload, c.agentPackage);
  r.get('/panel-cert.pem', limits.agentDownload, c.panelCertificate);

  r.use(requireAgentTransport());
  r.post('/register', limits.agentRegister, validate({ body: registerBody }), c.register);

  r.use(agentAuth());
  r.post('/heartbeat', validate({ body: heartbeatBody }), c.heartbeat);
  r.get('/jobs/next', c.nextJob);
  r.post('/jobs/:id/start', validate({ params: idParam }), c.jobStarted);
  r.post('/jobs/:id/logs', validate({ params: idParam, body: jobLogsBody }), c.jobLogs);
  r.post('/jobs/:id/result', validate({ params: idParam, body: jobResultBody }), c.jobResult);
  r.post('/backups/:id/chunks', validate({ params: idParam, body: backupChunkBody }), c.backupChunk);
  // Pieces of a file uploaded in the file manager, for its FILE_UPLOAD job.
  r.get('/uploads/:id/chunks/:offset', validate({ params: uploadChunkQuery }), c.uploadChunk);
  r.post('/downloads/:id/chunks', validate({ params: idParam, body: downloadChunkBody }), c.downloadChunk);
  r.post('/cron-runs', validate({ body: cronRunsBody }), c.cronRuns);
  return r;
}
