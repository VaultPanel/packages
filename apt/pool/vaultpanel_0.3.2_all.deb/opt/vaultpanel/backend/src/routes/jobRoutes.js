import { Router } from 'express';
import { z } from 'zod';
import { jobController as c } from '../controllers/jobController.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import { jobListQuery } from '../services/jobService.js';
import { idParam } from '../validators/common.js';

const jobQuery = z.object({ afterLogId: z.coerce.number().int().min(0).default(0) });

export function jobRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('job'));
  r.get('/', validate({ query: jobListQuery }), c.list);
  r.get('/operations', c.operations);
  r.get('/:id', validate({ params: idParam, query: jobQuery }), c.get);
  r.post('/:id/cancel', validate({ params: idParam }), c.cancel);
  return r;
}
