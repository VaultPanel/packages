import { Router } from 'express';
import { pluginController as c } from '../controllers/pluginController.js';
import { rejectApiToken } from '../middleware/apiTokenAuth.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  addPluginDirectoryBody,
  installPluginBody,
  pluginDirectoryParams,
  pluginDeliveryParams,
  pluginDeliveryQuery,
  pluginLaunchQuery,
  previewPluginBody,
  updatePluginBody,
} from '../validators/pluginValidators.js';

export function pluginRoutes() {
  const r = Router();
  r.use(requireAuth());
  // Installing, approving new permissions and replacing a plugin's
  // credentials mint credentials, so they are done in the panel by a person,
  // never with an API token or by a plugin.
  const inPanel = rejectApiToken('Install, update and re-key plugins in the panel, on its Plugins page');
  r.get('/', c.list);
  // Pages the signed-in person may open, for the sidebar.
  r.get('/pages', c.pages);
  r.post('/preview', validate({ body: previewPluginBody }), c.preview);
  // Plugin directories: lists of plugins to install. Before /:id.
  r.get('/directory', c.directory);
  r.post('/directory/refresh', c.refreshDirectories);
  r.post('/directory/sources', inPanel, validate({ body: addPluginDirectoryBody }), c.addDirectory);
  r.post('/directory/sources/:directoryId/refresh', validate({ params: pluginDirectoryParams }), c.refreshDirectory);
  r.delete('/directory/sources/:directoryId', validate({ params: pluginDirectoryParams }), c.removeDirectory);
  r.post('/', inPanel, validate({ body: installPluginBody }), c.install);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.put('/:id/manifest', inPanel, validate({ params: idParam, body: updatePluginBody }), c.update);
  r.post('/:id/enable', validate({ params: idParam }), c.enable);
  r.post('/:id/disable', validate({ params: idParam }), c.disable);
  r.post('/:id/rotate-credentials', inPanel, validate({ params: idParam }), c.rotate);
  r.delete('/:id', validate({ params: idParam }), c.remove);
  r.get('/:id/deliveries', validate({ params: idParam, query: pluginDeliveryQuery }), c.deliveries);
  r.post('/:id/test', validate({ params: idParam }), c.test);
  r.post('/:id/deliveries/:deliveryId/redeliver', validate({ params: pluginDeliveryParams }), c.redeliver);
  r.get('/:id/launch', validate({ params: idParam, query: pluginLaunchQuery }), c.launch);
  return r;
}
