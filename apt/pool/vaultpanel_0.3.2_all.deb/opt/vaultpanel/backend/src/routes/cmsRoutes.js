import { Router } from 'express';
import { cmsController as c } from '../controllers/cmsController.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import { cmsInstallListQuery, createCmsInstallBody, removeCmsInstallQuery } from '../validators/cmsValidators.js';

// The app installer: WordPress, Joomla, Drupal and Laravel in a website.
export function cmsRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('cms_install'));
  r.get('/apps', c.catalog);
  r.get('/installs', validate({ query: cmsInstallListQuery }), c.list);
  r.post('/installs', validate({ body: createCmsInstallBody }), c.create);
  r.get('/installs/:id', validate({ params: idParam }), c.get);
  r.delete('/installs/:id', validate({ params: idParam, query: removeCmsInstallQuery }), c.remove);
  return r;
}
