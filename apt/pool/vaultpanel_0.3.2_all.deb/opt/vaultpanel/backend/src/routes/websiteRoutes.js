import express, { Router } from 'express';
import { certificateController, domainController, websiteController as c } from '../controllers/websiteController.js';
import { fileUploadController as uploads } from '../controllers/fileUploadController.js';
import { siteDeployController as git } from '../controllers/siteDeployController.js';
import { siteGitBody, siteRollbackBody } from '../validators/siteDeployValidators.js';
import { envBody } from '../validators/applicationValidators.js';
import { requireAuth } from '../middleware/auth.js';
import { ownedParam } from '../middleware/tenancy.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import { UPLOAD_CHUNK_BYTES } from '@vaultpanel/shared';
import {
  certificateListQuery,
  sslRenewalBody,
  createWebsiteBody,
  deleteWebsiteQuery,
  domainListQuery,
  FILE_ACTIONS,
  fileActionParam,
  issueSslBody,
  installSslBody,
  renewSslBody,
  startDownloadBody,
  downloadParams,
  startUploadBody,
  updateWebsiteBody,
  uploadChunkParams,
  uptimeBody,
  uploadParams,
  websiteListQuery,
  websiteLogsBody,
} from '../validators/websiteValidators.js';

// The body schema depends on the file action in the URL.
function validateFileAction(req, res, next) {
  const schema = FILE_ACTIONS[req.params.action];
  if (!schema) return validate({ params: fileActionParam })(req, res, next);
  return validate({ params: fileActionParam, body: schema })(req, res, next);
}

export function websiteRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('website'));
  r.get('/', validate({ query: websiteListQuery }), c.list);
  r.post('/', validate({ body: createWebsiteBody }), c.create);
  r.get('/:id', validate({ params: idParam }), c.get);
  r.patch('/:id', validate({ params: idParam, body: updateWebsiteBody }), c.update);
  r.delete('/:id', validate({ params: idParam, query: deleteWebsiteQuery }), c.remove);
  r.post('/:id/enable', validate({ params: idParam }), c.enable);
  r.post('/:id/disable', validate({ params: idParam }), c.disable);
  r.post('/:id/retry', validate({ params: idParam }), c.retry);
  r.post('/:id/ssl', validate({ params: idParam, body: issueSslBody }), c.issueSsl);
  r.post('/:id/ssl/renew', validate({ params: idParam, body: renewSslBody }), c.renewSsl);
  r.post('/:id/ssl/upload', validate({ params: idParam, body: installSslBody }), c.installSsl);
  r.delete('/:id/ssl', validate({ params: idParam }), c.disableSsl);
  r.post('/:id/logs', validate({ params: idParam, body: websiteLogsBody }), c.logs);
  r.post('/:id/dns-check', validate({ params: idParam }), c.checkDns);
  // Uptime, checked from the panel.
  r.get('/:id/uptime', validate({ params: idParam }), c.uptime);
  r.put('/:id/uptime', validate({ params: idParam, body: uptimeBody }), c.setUptime);
  r.post('/:id/uptime/check', validate({ params: idParam }), c.checkUptime);
  // Large uploads, in pieces (before /files/:action, which would match "uploads").
  r.post('/:id/files/uploads', validate({ params: idParam, body: startUploadBody }), uploads.start);
  r.put(
    '/:id/files/uploads/:uploadId/chunks/:offset',
    express.raw({ type: 'application/octet-stream', limit: UPLOAD_CHUNK_BYTES }),
    validate({ params: uploadChunkParams }),
    uploads.chunk,
  );
  r.post('/:id/files/uploads/:uploadId/finish', validate({ params: uploadParams }), uploads.finish);
  // Files of any size, sent to the panel by the agent first.
  r.post('/:id/files/downloads', validate({ params: idParam, body: startDownloadBody }), uploads.startDownload);
  r.get('/:id/files/downloads/:downloadId', validate({ params: downloadParams }), uploads.downloadStatus);
  r.get('/:id/files/downloads/:downloadId/file', validate({ params: downloadParams }), uploads.downloadFile);
  r.post('/:id/files/:action', validateFileAction, c.files);
  // Git deploy (static websites).
  r.put('/:id/git', validate({ params: idParam, body: siteGitBody }), git.configure);
  r.delete('/:id/git', validate({ params: idParam }), git.disable);
  r.get('/:id/environment', validate({ params: idParam }), git.getEnv);
  r.put('/:id/environment', validate({ params: idParam, body: envBody }), git.setEnv);
  r.get('/:id/deployments', validate({ params: idParam }), git.deployments);
  r.post('/:id/deploy', validate({ params: idParam }), git.deploy);
  r.post('/:id/rollback', validate({ params: idParam, body: siteRollbackBody }), git.rollback);
  r.post('/:id/git/webhook', validate({ params: idParam }), git.enableWebhook);
  r.delete('/:id/git/webhook', validate({ params: idParam }), git.disableWebhook);
  return r;
}

export function domainRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.param('id', ownedParam('domain'));
  r.get('/', validate({ query: domainListQuery }), domainController.list);
  r.post('/:id/dns-check', validate({ params: idParam }), domainController.checkDns);
  return r;
}

export function certificateRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: certificateListQuery }), certificateController.list);
  r.get('/renewal', certificateController.getRenewal);
  r.put('/renewal', validate({ body: sslRenewalBody }), certificateController.updateRenewal);
  return r;
}
