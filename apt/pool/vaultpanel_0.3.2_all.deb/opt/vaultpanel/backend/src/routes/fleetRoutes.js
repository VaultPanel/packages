import { Router } from 'express';
import { bulkActionController as b, serverGroupController as g } from '../controllers/fleetController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { bulkActionListQuery } from '../services/bulkActionService.js';
import { idParam } from '../validators/common.js';
import { createBulkActionBody, createGroupBody, updateGroupBody } from '../validators/fleetValidators.js';

export function serverGroupRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', g.list);
  r.post('/', validate({ body: createGroupBody }), g.create);
  r.get('/:id', validate({ params: idParam }), g.get);
  r.patch('/:id', validate({ params: idParam, body: updateGroupBody }), g.update);
  r.delete('/:id', validate({ params: idParam }), g.remove);
  return r;
}

export function bulkActionRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/', validate({ query: bulkActionListQuery }), b.list);
  r.post('/', validate({ body: createBulkActionBody }), b.create);
  r.get('/:id', validate({ params: idParam }), b.get);
  r.post('/:id/cancel', validate({ params: idParam }), b.cancel);
  return r;
}
