import { Router } from 'express';
import { dnsController as c } from '../controllers/dnsController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  createDnsProviderBody,
  createRecordBody,
  createZoneBody,
  customerDnsBody,
  recordParams,
  updateDnsProviderBody,
  updateRecordBody,
  updateZoneBody,
  zoneListQuery,
} from '../validators/dnsValidators.js';

// DNS zones and their records, and DNS providers (staff only: hosting
// customers do not reach /dns).
export function dnsRoutes() {
  const r = Router();
  r.use(requireAuth());
  // What hosting customers on a server are told about DNS.
  r.put('/servers/:id/customers', validate({ params: idParam, body: customerDnsBody }), c.setCustomerDns);
  r.get('/zones', validate({ query: zoneListQuery }), c.list);
  r.post('/zones', validate({ body: createZoneBody }), c.create);
  r.get('/zones/:id', validate({ params: idParam }), c.get);
  r.patch('/zones/:id', validate({ params: idParam, body: updateZoneBody }), c.update);
  r.delete('/zones/:id', validate({ params: idParam }), c.remove);
  r.post('/zones/:id/apply', validate({ params: idParam }), c.apply);
  r.post('/zones/:id/check', validate({ params: idParam }), c.check);
  r.post('/zones/:id/records', validate({ params: idParam, body: createRecordBody }), c.addRecord);
  r.patch('/zones/:id/records/:recordId', validate({ params: recordParams, body: updateRecordBody }), c.updateRecord);
  r.delete('/zones/:id/records/:recordId', validate({ params: recordParams }), c.removeRecord);
  // Providers whose API checks wildcard certificates for domains with DNS elsewhere.
  r.get('/providers', c.listProviders);
  r.post('/providers', validate({ body: createDnsProviderBody }), c.createProvider);
  r.get('/providers/:id', validate({ params: idParam }), c.getProvider);
  r.put('/providers/:id', validate({ params: idParam, body: updateDnsProviderBody }), c.updateProvider);
  r.delete('/providers/:id', validate({ params: idParam }), c.removeProvider);
  return r;
}
