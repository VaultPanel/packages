import { Router } from 'express';
import { alertController as c, monitoringController as m } from '../controllers/alertController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { alertEventListQuery } from '../services/alertService.js';
import { fleetServicesQuery } from '../services/monitoringService.js';
import { createRuleBody, updateRuleBody } from '../validators/alertValidators.js';
import { idParam } from '../validators/common.js';

export function alertRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/summary', c.summary);
  r.get('/events', validate({ query: alertEventListQuery }), c.listEvents);
  r.post('/events/:id/acknowledge', validate({ params: idParam }), c.acknowledge);
  r.get('/rules', c.listRules);
  r.post('/rules', validate({ body: createRuleBody }), c.createRule);
  r.patch('/rules/:id', validate({ params: idParam, body: updateRuleBody }), c.updateRule);
  r.delete('/rules/:id', validate({ params: idParam }), c.deleteRule);
  return r;
}

export function monitoringRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/overview', m.overview);
  r.get('/services', validate({ query: fleetServicesQuery }), m.services);
  return r;
}
