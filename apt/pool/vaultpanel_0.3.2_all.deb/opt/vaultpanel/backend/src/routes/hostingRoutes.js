import { Router } from 'express';
import { apiKeyController as k, billingController as b, customerController as c, planController as p, reportController as rep } from '../controllers/hostingController.js';
import { requireApiKey } from '../middleware/apiKeyAuth.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { idParam } from '../validators/common.js';
import {
  accountRefParam,
  assignBody,
  billingCreateBody,
  billingPasswordBody,
  billingPlanBody,
  changePlanBody,
  createApiKeyBody,
  createCustomerBody,
  createPlanBody,
  customerListQuery,
  financialReportQuery,
  resourceParams,
  suspendBody,
  updateCustomerBody,
  updatePlanBody,
} from '../validators/hostingValidators.js';

// Plans, customers and API keys, for staff; /me for a signed-in customer.
export function hostingRoutes() {
  const r = Router();
  r.use(requireAuth());
  r.get('/me', c.me);
  r.get('/me/dns', c.myDns);
  r.post('/me/dns/zones/:id/check', validate({ params: idParam }), c.myDnsCheck);

  r.get('/plans', p.list);
  r.post('/plans', validate({ body: createPlanBody }), p.create);
  r.get('/plans/:id', validate({ params: idParam }), p.get);
  r.patch('/plans/:id', validate({ params: idParam, body: updatePlanBody }), p.update);
  r.delete('/plans/:id', validate({ params: idParam }), p.remove);

  r.get('/customers', validate({ query: customerListQuery }), c.list);
  r.post('/customers', validate({ body: createCustomerBody }), c.create);
  r.get('/customers/:id', validate({ params: idParam }), c.get);
  r.patch('/customers/:id', validate({ params: idParam, body: updateCustomerBody }), c.update);
  r.post('/customers/:id/plan', validate({ params: idParam, body: changePlanBody }), c.changePlan);
  r.post('/customers/:id/suspend', validate({ params: idParam, body: suspendBody }), c.suspend);
  r.post('/customers/:id/unsuspend', validate({ params: idParam }), c.unsuspend);
  r.post('/customers/:id/terminate', validate({ params: idParam }), c.terminate);
  r.post('/customers/:id/password-reset', validate({ params: idParam }), c.passwordReset);
  r.post('/customers/:id/resources', validate({ params: idParam, body: assignBody }), c.assign);
  r.delete('/customers/:id/resources/:type/:resourceId', validate({ params: resourceParams }), c.unassign);

  r.get('/reports/financial', validate({ query: financialReportQuery }), rep.financial);

  r.get('/api-keys', k.list);
  r.post('/api-keys', validate({ body: createApiKeyBody }), k.create);
  r.post('/api-keys/:id/revoke', validate({ params: idParam }), k.revoke);
  return r;
}

// The billing API (Authorization: Bearer <API key>).
export function billingRoutes(limits) {
  const r = Router();
  r.use(limits.billing, requireApiKey());
  r.get('/plans', b.plans);
  // Every account with its usage, a page at a time (disk usage for billing).
  r.get('/accounts', validate({ query: customerListQuery }), b.list);
  r.post('/accounts', validate({ body: billingCreateBody }), b.create);
  r.get('/accounts/:ref', validate({ params: accountRefParam }), b.get);
  r.post('/accounts/:ref/suspend', validate({ params: accountRefParam, body: suspendBody }), b.suspend);
  r.post('/accounts/:ref/unsuspend', validate({ params: accountRefParam }), b.unsuspend);
  r.post('/accounts/:ref/plan', validate({ params: accountRefParam, body: billingPlanBody }), b.changePlan);
  r.post('/accounts/:ref/password', validate({ params: accountRefParam, body: billingPasswordBody }), b.password);
  r.post('/accounts/:ref/login', validate({ params: accountRefParam }), b.loginLink);
  r.delete('/accounts/:ref', validate({ params: accountRefParam }), b.terminate);
  return r;
}
