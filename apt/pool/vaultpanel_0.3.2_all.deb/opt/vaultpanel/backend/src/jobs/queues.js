import { Queue, Worker } from 'bullmq';

// BullMQ runs the panel's own background work. Server operations are not
// BullMQ jobs: they live in the jobs table (the durable record users see)
// and agents pull them over HTTPS.
export const MAINTENANCE_QUEUE = 'vaultpanel-maintenance';
export const MAINTENANCE_EVERY_MS = 15_000;

function connection(redisUrl) {
  return { url: redisUrl, maxRetriesPerRequest: null };
}

export async function scheduleMaintenance(redisUrl) {
  const queue = new Queue(MAINTENANCE_QUEUE, { connection: connection(redisUrl) });
  await queue.upsertJobScheduler(
    'maintenance-every-15s',
    { every: MAINTENANCE_EVERY_MS },
    { name: 'maintenance', opts: { removeOnComplete: 100, removeOnFail: 500 } },
  );
  return queue;
}

export function startMaintenanceWorker(redisUrl, { services, logger }) {
  const worker = new Worker(MAINTENANCE_QUEUE, async () => services.maintenance.run(), {
    connection: connection(redisUrl),
    concurrency: 1,
  });
  worker.on('failed', (job, err) => logger.error({ err, jobId: job?.id }, 'maintenance run failed'));
  return worker;
}

// Questions to the AI assistant (phase 9). Answering takes from seconds to a
// few minutes (provider calls, reading logs through the agent), so it runs
// here instead of in the HTTP request.
export const ASSISTANT_QUEUE = 'vaultpanel-assistant';

export function createAssistantQueue(redisUrl) {
  let queue = null;
  return {
    async add({ conversationId, messageId }) {
      queue ??= new Queue(ASSISTANT_QUEUE, { connection: connection(redisUrl) });
      await queue.add('answer', { conversationId }, { jobId: `${conversationId}-${messageId}-${Date.now()}`, removeOnComplete: 200, removeOnFail: 500, attempts: 1 });
    },
    async close() {
      await queue?.close();
    },
  };
}

export function startAssistantWorker(redisUrl, { services, logger }) {
  const worker = new Worker(ASSISTANT_QUEUE, async (job) => services.assistant.runTurn(job.data.conversationId), {
    connection: connection(redisUrl),
    concurrency: 4,
  });
  worker.on('failed', (job, err) => logger.error({ err, jobId: job?.id }, 'assistant answer failed'));
  return worker;
}
