import { existsSync } from 'node:fs';
import { parseArgs } from 'node:util';
import knex from 'knex';
import { knexConfig } from '../config/database.js';
import { loadConfig } from '../config/env.js';
import { createAuditService } from '../services/auditService.js';
import { createLocalServerService } from '../services/localServerService.js';
import { createSigningService } from '../services/signingService.js';
import { createLogger } from '../utils/logger.js';

// Usage: node src/cli/connectLocal.js [--auto] [--force]
//
// Connects the server the panel runs on (see services/localServerService.js).
// --auto is how npm runs it before the API starts: it never fails the start,
// and does nothing when VAULTPANEL_LOCAL_AGENT=false or the machine is not a
// Linux server with systemd.
const { values } = parseArgs({
  options: {
    auto: { type: 'boolean', default: false },
    force: { type: 'boolean', default: false },
  },
});
const say = (msg) => console.log(`[vaultpanel] ${msg}`);

let db;
try {
  const config = loadConfig();
  if (values.auto && !config.localAgent) process.exit(0);
  if (process.platform !== 'linux' || !existsSync('/run/systemd/system')) {
    if (!values.auto) say('This server is not Linux with systemd, so the agent cannot be installed here.');
    process.exit(values.auto ? 0 : 1);
  }
  db = knex(knexConfig(config.databaseUrl));
  if (!(await db.schema.hasTable('servers')) || !(await db.schema.hasColumn('servers', 'is_local'))) {
    say('Run "npm run db:migrate" so the panel can connect the server it runs on.');
  } else {
    const logger = createLogger({ level: 'warn', name: 'vaultpanel-connect-local' });
    const service = createLocalServerService({
      db,
      config,
      audit: createAuditService({ db, logger }),
      signing: createSigningService({ db, config }),
    });
    const outcome = await service.connect({ force: values.force });
    say(outcome.message);
    if (!values.auto && !['connected', 'adopted', 'upgraded'].includes(outcome.status)) process.exitCode = 1;
  }
} catch (err) {
  say(`Could not connect this server to the panel: ${err.message}`);
  if (!values.auto) process.exitCode = 1;
} finally {
  await db?.destroy();
}
