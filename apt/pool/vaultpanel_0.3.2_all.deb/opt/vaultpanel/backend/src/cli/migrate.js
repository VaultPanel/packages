import knex from 'knex';
import { knexConfig } from '../config/database.js';
import { createLogger } from '../utils/logger.js';
import { createAccessControlService } from '../services/accessControlService.js';
import { databaseHint } from '../utils/databaseHint.js';

// Usage: node src/cli/migrate.js latest|rollback
// Only DATABASE_URL is needed, so migrations can run before the rest of the
// configuration exists.
const command = process.argv[2] ?? 'latest';
const logger = createLogger({ level: 'info', name: 'vaultpanel-migrate' });
if (!process.env.DATABASE_URL) {
  logger.error('DATABASE_URL is required');
  process.exit(1);
}
const db = knex(knexConfig(process.env.DATABASE_URL));

try {
  if (command === 'latest') {
    const [batch, files] = await db.migrate.latest();
    logger.info({ batch, files }, files.length ? 'migrations applied' : 'database already up to date');
    await createAccessControlService({ db }).syncBuiltInRoles();
    logger.info('built-in roles and permissions synced');
  } else if (command === 'rollback') {
    const [batch, files] = await db.migrate.rollback();
    logger.info({ batch, files }, 'rolled back');
  } else {
    throw new Error(`Unknown command "${command}" (use latest or rollback)`);
  }
} catch (err) {
  logger.error({ err }, 'migration failed');
  const hint = databaseHint(err, process.env.DATABASE_URL);
  if (hint) logger.warn(hint);
  process.exitCode = 1;
} finally {
  await db.destroy();
}
