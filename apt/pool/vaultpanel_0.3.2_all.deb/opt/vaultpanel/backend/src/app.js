import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { isIP } from 'node:net';
import path from 'node:path';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { pinoHttp } from 'pino-http';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { createRateLimits } from './middleware/rateLimit.js';
import { requestId } from './middleware/requestId.js';
import { apiRoutes } from './routes/index.js';

// Builds the Express app from an already-created context (see context.js).
export function createApp(ctx, { rateLimits = createRateLimits() } = {}) {
  const { config, logger } = ctx;
  const app = express();
  app.locals.config = config;
  app.locals.services = ctx.services;
  app.locals.db = ctx.db;
  app.locals.redis = ctx.redis;

  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);

  app.use(requestId());
  app.use(
    pinoHttp({
      logger,
      genReqId: (req, res) => res.locals.requestId,
      autoLogging: { ignore: (req) => req.url === '/api/v1/health' },
      customLogLevel: (req, res, err) => (err || res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info'),
    }),
  );
  app.use(helmet(config.uiDir ? { contentSecurityPolicy: { directives: uiDirectives(config) }, strictTransportSecurity: false } : {}));
  if (config.uiDir) app.use(strictTransportSecurity(config));
  // The UI is served from the panel origin (or the Vite proxy in development),
  // so cross-origin browser calls are refused unless explicitly allowed.
  app.use(cors({ origin: config.corsOrigins.length ? config.corsOrigins : false, credentials: true }));
  app.use(
    express.json({
      // Room for a 1 MB file upload (base64) and for agent results that carry an opened file.
      limit: '4mb',
      // Agent requests are signed over the exact bytes received.
      verify: (req, res, buf) => {
        req.rawBody = buf.toString('utf8');
      },
    }),
  );
  app.use(cookieParser());

  app.use('/api/v1', apiRoutes(rateLimits));
  if (config.uiDir) serveUi(app, config.uiDir);
  app.use(notFoundHandler());
  app.use(errorHandler(logger));
  return app;
}

// HSTS only where a browser can trust the certificate: never on an IP
// address, nor on the panel's own port while it uses its self-signed
// certificate (people must be able to accept that one). A panel domain
// behind NGINX, with a real certificate, gets it.
function strictTransportSecurity(config) {
  return (req, res, next) => {
    const selfSignedPort = config.tls?.selfSigned && req.socket?.localPort === config.port;
    if (config.cookieSecure && req.secure && !isIP(req.hostname ?? '') && !selfSignedPort) {
      res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    }
    next();
  };
}

// Serves the built web interface: its files, and index.html for every other
// page address (/servers, /setup...) so the browser router can show it.
// Addresses under /api, and missing built files, never fall through to it.
function serveUi(app, uiDir) {
  const index = path.join(uiDir, 'index.html');
  // Vite puts content-hashed files under assets/, so they can be cached for good.
  app.use('/assets', express.static(path.join(uiDir, 'assets'), { immutable: true, maxAge: '1y' }));
  app.use(express.static(uiDir, { index: false }));
  app.use((req, res, next) => {
    if ((req.method !== 'GET' && req.method !== 'HEAD') || req.path === '/api' || /^\/(api|assets)\//.test(req.path)) return next();
    res.set('Cache-Control', 'no-cache');
    res.sendFile(index, (err) => err && next(err));
  });
}

// The interface loads only its own files. Plugin pages are other servers'
// pages shown in a frame, so frames may come from anywhere. Over plain HTTP
// (no secure cookies) the browser must not be told to switch to HTTPS.
function uiDirectives(config) {
  return {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", ...inlineScriptHashes(path.join(config.uiDir, 'index.html'))],
    styleSrc: ["'self'", "'unsafe-inline'"],
    imgSrc: ["'self'", 'data:', 'blob:'],
    fontSrc: ["'self'", 'data:'],
    connectSrc: ["'self'"],
    frameSrc: ['http:', 'https:'],
    objectSrc: ["'none'"],
    baseUri: ["'self'"],
    formAction: ["'self'"],
    frameAncestors: ["'self'"],
    upgradeInsecureRequests: config.cookieSecure ? [] : null,
  };
}

// index.html sets the theme with a small inline script before the page paints;
// the policy allows exactly that script by its hash, and no other inline code.
function inlineScriptHashes(file) {
  let html;
  try {
    html = readFileSync(file, 'utf8');
  } catch {
    return [];
  }
  return [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)]
    .filter((m) => m[1].trim())
    .map((m) => `'sha256-${createHash('sha256').update(m[1]).digest('base64')}'`);
}
