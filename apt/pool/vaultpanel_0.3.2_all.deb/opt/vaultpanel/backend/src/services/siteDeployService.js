import { randomBytes, randomUUID } from 'node:crypto';
import {
  MAX_KEEP_RELEASES,
  PERMISSIONS,
  SITE_DEPLOY_ERROR_STAGES,
  SITE_GIT_DOCUMENT_ROOT,
  SITE_GIT_ENV_MIN_AGENT_VERSION,
  SITE_GIT_MIN_AGENT_VERSION,
  SITE_GIT_PHP_MIN_AGENT_VERSION,
  envProblems,
  parseCommands,
} from '@vaultpanel/shared';
import { toPublicSiteDeployment } from '../models/websiteModel.js';
import { findServer } from '../models/serverModel.js';
import { compareVersions } from '../utils/agentPackage.js';
import { createSecretBox, deriveKey, newToken, sha256Hex } from '../utils/crypto.js';
import { checkHookSignature, PUSH_EVENTS, pushedRef } from '../utils/hookSignature.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { scopeQuery } from './tenancy.js';
import { systemActor } from './actor.js';

// Git deploy for static and PHP websites: optional, per site. A site with Git deploy
// off is managed with the file manager as before. With it on, each deploy
// clones the repository (and runs its build) into a new release folder on
// the server, and the site serves that release's output folder through the
// "current" link. Like apps, the newest releases stay for instant rollbacks,
// and a push to the branch can deploy through a webhook.
//
// The website row carries the Git settings and what is live; each deploy or
// rollback is a website_deployments row whose logs are its job's logs. The
// site is busy (status updating) while one runs, like any website change.

const GIT_JOB_TYPES = ['SITE_GIT_SETUP', 'DEPLOY_SITE_GIT', 'ROLLBACK_SITE_GIT'];
const SETTING_COLUMNS = {
  repositoryUrl: 'git_repository_url',
  branch: 'git_branch',
  installCommand: 'git_install_command',
  buildCommand: 'git_build_command',
  outputDir: 'git_output_dir',
  keepReleases: 'git_keep_releases',
};

export function createSiteDeployService({ db, config, logger, audit, authorize, jobs, websites }) {
  const envBox = createSecretBox(deriveKey(config.secretKey, 'site-env'));
  const hookBox = createSecretBox(deriveKey(config.secretKey, 'git-webhook'));

  async function loadSite(id) {
    const row = await db('websites as w')
      .join('servers as s', 's.id', 'w.server_id')
      .where('w.id', id)
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .first('w.*');
    if (!row) throw notFound('Website not found');
    return row;
  }

  function requireGit(row) {
    if (!row.git_repository_url) throw new AppError(409, 'GIT_DEPLOY_OFF', 'Git deploy is not on for this website. Turn it on in the Deployments tab first.');
  }

  // Static and PHP sites deploy from Git; a proxy site's app deploys itself.
  function requireStaticSite(row) {
    if (row.type !== 'static' && row.type !== 'php') {
      throw new AppError(409, 'WEBSITE_NOT_STATIC', 'Git deploy is for static and PHP websites. Apps deploy from Git themselves.');
    }
  }

  async function requireReady(row) {
    websites.requireProvisioned(row);
    const server = await findServer(db, row.server_id);
    if (!server || server.status === 'pending' || server.status === 'disabled') {
      throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    }
    if (!server.agent_version || compareVersions(server.agent_version, SITE_GIT_MIN_AGENT_VERSION) < 0) {
      throw new AppError(
        409,
        'AGENT_OUTDATED',
        `Deploying websites from Git needs agent v${SITE_GIT_MIN_AGENT_VERSION} or later; ${server.name} runs v${server.agent_version ?? '?'}. Update the agent from the server page first.`,
      );
    }
    if (row.type === 'php' && compareVersions(server.agent_version, SITE_GIT_PHP_MIN_AGENT_VERSION) < 0) {
      throw new AppError(
        409,
        'AGENT_OUTDATED',
        `Deploying PHP websites from Git needs agent v${SITE_GIT_PHP_MIN_AGENT_VERSION} or later; ${server.name} runs v${server.agent_version}. Update the agent from the server page first.`,
      );
    }
    const stack = fromJson(server.web_stack, null);
    if (stack && stack.git === false) {
      throw new AppError(409, 'SOFTWARE_MISSING', `Git is not installed on ${server.name}. Install it from the Software card on the server page.`, { missing: ['Git'] });
    }
    return server;
  }

  // Checks the settings the panel cannot leave to the agent. Patterns and
  // lengths were checked by the request validator.
  function settingProblems(values) {
    const problems = [];
    for (const field of ['installCommand', 'buildCommand']) {
      if (!values[field]) continue;
      const { error } = parseCommands(values[field]);
      if (error) problems.push({ field, message: error });
    }
    if (values.keepReleases !== undefined && (values.keepReleases < 1 || values.keepReleases > MAX_KEEP_RELEASES)) {
      problems.push({ field: 'keepReleases', message: `From 1 to ${MAX_KEEP_RELEASES}` });
    }
    return problems;
  }

  // ---- Settings -----------------------------------------------------------

  // Turns Git deploy on, or changes its settings. Turning it on (or changing
  // to a repository on another host) sets up the site's release folder and
  // deploy key on the server; deployNow queues the first deployment after it.
  async function configure(actor, id, input) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireStaticSite(row);
    const application = await db('applications').where({ website_id: id }).whereNull('deleted_at').first('id');
    if (application) throw new AppError(409, 'WEBSITE_OWNED_BY_APP', 'This website serves an app, which deploys from Git itself.');
    websites.requireIdle(row);
    await requireReady(row);
    const values = {
      repositoryUrl: input.repositoryUrl,
      branch: input.branch,
      installCommand: input.installCommand || null,
      buildCommand: input.buildCommand || null,
      outputDir: (input.outputDir ?? '').replace(/^\.\/?$/, ''),
      keepReleases: input.keepReleases ?? row.git_keep_releases ?? 5,
    };
    const problems = settingProblems(values);
    if (problems.length) throw validationError(problems);
    const turningOn = !row.git_repository_url;
    const update = { updated_at: new Date() };
    for (const [key, column] of Object.entries(SETTING_COLUMNS)) update[column] = values[key];
    await db('websites').where({ id }).update(update);

    let job = null;
    if (turningOn || !row.git_deploy_public_key) {
      try {
        job = await websites.startChange(actor, row, { action: 'git_setup', type: 'SITE_GIT_SETUP', params: { name: row.name } });
      } catch (err) {
        if (turningOn) await db('websites').where({ id }).update(Object.fromEntries(Object.values(SETTING_COLUMNS).map((c) => [c, c === 'git_keep_releases' ? row.git_keep_releases : null])));
        throw err;
      }
    }
    let deployment = null;
    if (input.deployNow) {
      try {
        ({ deployment } = await queueDeploy(actor, await loadSite(id), { trigger: turningOn ? 'create' : 'manual', afterSetup: Boolean(job) }));
      } catch (err) {
        logger.warn({ err, websiteId: id }, 'could not queue the first site deployment');
      }
    }
    await audit.record({
      actor,
      action: turningOn ? 'website.git_enable' : 'website.git_update',
      target: target(row),
      metadata: { ...values, installCommand: Boolean(values.installCommand), buildCommand: Boolean(values.buildCommand), jobId: job?.id ?? null },
    });
    return { website: await websites.describe(id), job, deployment };
  }

  // Turns Git deploy off. The site serves its previous document root again
  // (usually public, with the files it had before); the releases stay on the
  // server until the site is deleted.
  async function disable(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireGit(row);
    websites.requireIdle(row);
    await db('websites').where({ id }).update({
      ...Object.fromEntries(Object.values(SETTING_COLUMNS).filter((c) => c !== 'git_keep_releases').map((c) => [c, null])),
      git_webhook_token_hash: null,
      git_webhook_created_at: null,
      updated_at: new Date(),
    });
    let job = null;
    if (row.document_root === SITE_GIT_DOCUMENT_ROOT) {
      const back = row.git_previous_document_root || 'public';
      ({ job } = await websites.update(actor, id, { documentRoot: back }, { fromGit: true }));
    }
    await audit.record({ actor, action: 'website.git_disable', target: target(row), metadata: { jobId: job?.id ?? null } });
    return { website: await websites.describe(id), job };
  }

  // ---- Environment variables ---------------------------------------------
  // Given to the install and build commands of each deployment (a Vite site's
  // VITE_API_URL, for example). They end up in the built files, so they are
  // settings rather than secrets, but are stored encrypted like an app's.

  async function envEntries(websiteId) {
    const rows = await db('website_environment_variables').where({ website_id: websiteId }).orderBy('key');
    return rows.map((r) => ({ key: r.key, value: envBox.open(r.value_encrypted) }));
  }

  async function getEnv(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    const variables = await envEntries(id);
    await audit.record({ actor, action: 'website.env_view', target: target(row), metadata: { count: variables.length } });
    return { variables };
  }

  async function setEnv(actor, id, { variables }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireStaticSite(row);
    const problems = envProblems(variables);
    if (problems.length) throw validationError(problems);
    const before = await envEntries(id);
    const now = new Date();
    await db.transaction(async (trx) => {
      await trx('website_environment_variables').where({ website_id: id }).delete();
      if (variables.length) {
        await trx('website_environment_variables').insert(
          variables.map(({ key, value }) => ({ id: randomUUID(), website_id: id, key, value_encrypted: envBox.seal(value), created_at: now, updated_at: now })),
        );
      }
    });
    const keys = (list) => new Map(list.map((v) => [v.key, v.value]));
    const [old, next] = [keys(before), keys(variables)];
    await audit.record({
      actor,
      action: 'website.env_update',
      target: target(row),
      // Names only.
      metadata: {
        added: [...next.keys()].filter((k) => !old.has(k)),
        changed: [...next.keys()].filter((k) => old.has(k) && old.get(k) !== next.get(k)),
        removed: [...old.keys()].filter((k) => !next.has(k)),
      },
    });
    return { variables: await envEntries(id) };
  }

  // ---- Deploying ----------------------------------------------------------

  function newReleaseId(now = new Date()) {
    const stamp = now.toISOString().replace(/[-:T]/g, '').slice(0, 14);
    return `${stamp}-${randomBytes(3).toString('hex')}`;
  }

  async function queueDeploy(actor, row, { trigger, afterSetup = false }) {
    const releaseId = newReleaseId();
    const spec = await websites.specFor(row.id, { documentRoot: SITE_GIT_DOCUMENT_ROOT });
    const params = {
      ...spec,
      repository: row.git_repository_url,
      branch: row.git_branch,
      releaseId,
      keepReleases: row.git_keep_releases,
    };
    if (row.git_install_command) params.installCommand = row.git_install_command;
    if (row.git_build_command) params.buildCommand = row.git_build_command;
    if (row.git_output_dir) params.outputDir = row.git_output_dir;
    const variables = await envEntries(row.id);
    if (variables.length) {
      // Older agents refuse the parameter, so it is only sent when there are variables.
      const server = await findServer(db, row.server_id);
      if (!server?.agent_version || compareVersions(server.agent_version, SITE_GIT_ENV_MIN_AGENT_VERSION) < 0) {
        throw new AppError(
          409,
          'AGENT_OUTDATED',
          `Environment variables for website builds need agent v${SITE_GIT_ENV_MIN_AGENT_VERSION} or later; ${server?.name ?? 'the server'} runs v${server?.agent_version ?? '?'}. Update the agent from the server page, or remove the variables.`,
        );
      }
      params.env = variables.map(({ key, value }) => `${key}=${value}`);
    }

    const deploymentId = randomUUID();
    const now = new Date();
    await db('website_deployments').insert({
      id: deploymentId,
      website_id: row.id,
      server_id: row.server_id,
      kind: 'deploy',
      trigger,
      status: 'queued',
      release_id: releaseId,
      repository_url: row.git_repository_url,
      branch: row.git_branch,
      output_dir: row.git_output_dir ?? '',
      requested_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    let job;
    try {
      if (afterSetup) {
        // The setup runs first (the agent runs a server's jobs in order).
        job = await jobs.create(actor, { serverId: row.server_id, type: 'DEPLOY_SITE_GIT', params, resource: { type: 'website', id: row.id } }, { internal: true });
      } else {
        job = await websites.startChange(actor, row, { action: 'deploy', type: 'DEPLOY_SITE_GIT', params });
      }
    } catch (err) {
      await db('website_deployments').where({ id: deploymentId }).delete();
      throw err;
    }
    await db('website_deployments').where({ id: deploymentId }).update({ job_id: job.id });
    return { job, deployment: await deploymentById(deploymentId) };
  }

  async function deploy(actor, id, { trigger = 'manual' } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireGit(row);
    websites.requireIdle(row);
    await requireReady(row);
    const { job, deployment } = await queueDeploy(actor, row, { trigger });
    await audit.record({ actor, action: 'website.deploy', target: target(row), metadata: { trigger, branch: row.git_branch, releaseId: deployment.releaseId, deploymentId: deployment.id, jobId: job.id } });
    return { website: await websites.describe(id), deployment, job };
  }

  async function rollback(actor, id, { deploymentId }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireGit(row);
    websites.requireIdle(row);
    await requireReady(row);
    if (!row.git_current_release_id) throw new AppError(409, 'WEBSITE_NOT_DEPLOYED', 'This website has not been deployed from Git yet');
    const source = await db('website_deployments').where({ id: deploymentId, website_id: id }).first();
    if (!source) throw notFound('Deployment not found');
    if (source.release_id === row.git_current_release_id) throw new AppError(409, 'RELEASE_ALREADY_LIVE', 'This release is already live');
    if (source.status !== 'succeeded') throw new AppError(409, 'RELEASE_NOT_DEPLOYABLE', 'Only releases that deployed successfully can be rolled back to');
    if (!source.release_available) {
      throw new AppError(409, 'RELEASE_NOT_FOUND', 'This release is no longer on the server (only the newest releases are kept). Deploy its commit again instead.');
    }
    const spec = await websites.specFor(id, { documentRoot: SITE_GIT_DOCUMENT_ROOT });
    const params = { ...spec, releaseId: source.release_id };
    if (source.output_dir) params.outputDir = source.output_dir;
    const newId = randomUUID();
    const now = new Date();
    await db('website_deployments').insert({
      id: newId,
      website_id: id,
      server_id: row.server_id,
      kind: 'rollback',
      trigger: 'rollback',
      status: 'queued',
      release_id: source.release_id,
      source_deployment_id: source.id,
      repository_url: source.repository_url,
      branch: source.branch,
      output_dir: source.output_dir,
      commit_hash: source.commit_hash,
      commit_message: source.commit_message,
      commit_author: source.commit_author,
      release_available: true,
      requested_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    let job;
    try {
      job = await websites.startChange(actor, row, { action: 'rollback', type: 'ROLLBACK_SITE_GIT', params });
    } catch (err) {
      await db('website_deployments').where({ id: newId }).delete();
      throw err;
    }
    await db('website_deployments').where({ id: newId }).update({ job_id: job.id });
    await audit.record({ actor, action: 'website.rollback', target: target(row), metadata: { releaseId: source.release_id, fromReleaseId: row.git_current_release_id, deploymentId: newId, jobId: job.id } });
    return { website: await websites.describe(id), deployment: await deploymentById(newId), job };
  }

  // ---- Webhook (push to deploy) ------------------------------------------

  async function enableWebhook(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    requireGit(row);
    const token = newToken(24);
    const secret = newToken(24);
    const now = new Date();
    await db('websites')
      .where({ id })
      .update({ git_webhook_token_hash: sha256Hex(token), git_webhook_secret_encrypted: hookBox.seal(secret), git_webhook_created_at: now, updated_at: now });
    await audit.record({ actor, action: row.git_webhook_token_hash ? 'website.webhook_rotate' : 'website.webhook_enable', target: target(row) });
    // The URL and secret are shown once. Apps use the same URL form.
    return { website: await websites.describe(id), webhook: { url: `${config.publicUrl}/api/v1/hooks/deploy/${token}`, secret } };
  }

  async function disableWebhook(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await loadSite(id);
    await db('websites').where({ id }).update({ git_webhook_token_hash: null, git_webhook_secret_encrypted: null, git_webhook_created_at: null, updated_at: new Date() });
    await audit.record({ actor, action: 'website.webhook_disable', target: target(row) });
    return { website: await websites.describe(id) };
  }

  // Called by GitHub, GitLab or anything else that can POST on a push, for a
  // token that belongs to a website. Returns null for other tokens (an app's).
  async function deployFromHook(token, body, { event = null, get = () => null, rawBody } = {}) {
    const row = await db('websites').where({ git_webhook_token_hash: sha256Hex(token) }).whereNull('deleted_at').first();
    if (!row) return null;
    if (row.git_webhook_secret_encrypted) {
      const check = checkHookSignature({ secret: hookBox.open(row.git_webhook_secret_encrypted), get, rawBody });
      if (!check.ok) {
        await audit.record({ actor: systemActor('push-to-deploy webhook'), action: 'website.webhook_rejected', target: target(row), metadata: { reason: check.reason } });
        throw new AppError(401, 'WEBHOOK_SIGNATURE_INVALID', check.reason);
      }
    }
    if (event && !PUSH_EVENTS.includes(String(event).toLowerCase())) {
      return { ignored: true, reason: ['ping', 'diagnostics:ping'].includes(event) ? 'Ping received. Pushes will deploy the website.' : `Ignored a ${event} event; only pushes deploy` };
    }
    if (!event && (body?.zen || body?.hook_id)) return { ignored: true, reason: 'Ping received. Pushes will deploy the website.' };
    const ref = pushedRef(body);
    if (ref && ref !== `refs/heads/${row.git_branch}`) return { ignored: true, reason: `Push to ${ref}; this website deploys ${row.git_branch}` };
    const { deployment } = await deploy(systemActor('push-to-deploy webhook'), row.id, { trigger: 'webhook' });
    return { ignored: false, deploymentId: deployment.id, releaseId: deployment.releaseId };
  }

  // ---- Deployments --------------------------------------------------------

  function deploymentQuery() {
    return db('website_deployments as dp')
      .join('websites as w', 'w.id', 'dp.website_id')
      .leftJoin('jobs as j', 'j.id', 'dp.job_id')
      .leftJoin('users as u', 'u.id', 'dp.requested_by')
      .select('dp.*', 'w.git_current_deployment_id as current_deployment_id', 'j.status as job_status', 'j.started_at as job_started_at', 'j.output as job_output', 'u.email as requested_by_email');
  }

  async function deploymentById(id) {
    const row = await deploymentQuery().where('dp.id', id).first();
    return row ? toPublicSiteDeployment(row) : null;
  }

  async function listDeployments(actor, id, { limit = 20 } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    await loadSite(id);
    const rows = await scopeQuery(deploymentQuery(), actor, 'w.customer_id').where('dp.website_id', id).orderBy('dp.created_at', 'desc').limit(limit);
    return { items: rows.map(toPublicSiteDeployment) };
  }

  // ---- Job results --------------------------------------------------------

  async function markReleases(websiteId, releases) {
    if (!Array.isArray(releases)) return;
    await db('website_deployments').where({ website_id: websiteId }).whereIn('release_id', releases).update({ release_available: true });
    await db('website_deployments').where({ website_id: websiteId }).whereNotIn('release_id', releases).update({ release_available: false });
  }

  // The state a site settles in after a Git change: busy again when a
  // deployment is queued behind it (the first one, after the setup).
  async function settle(row, extra, now) {
    const waiting = await db('website_deployments as dp')
      .join('jobs as j', 'j.id', 'dp.job_id')
      .where({ 'dp.website_id': row.id, 'dp.status': 'queued' })
      .whereIn('j.status', ['queued', 'dispatched', 'running'])
      .first('j.id');
    const status = waiting ? 'updating' : row.is_enabled ? 'active' : 'disabled';
    await db('websites')
      .where({ id: row.id })
      .update({ pending_spec: null, ...extra, status, pending_action: waiting ? 'deploy' : null, ...(waiting ? { last_job_id: waiting.id } : {}), updated_at: now });
  }

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'website' || !GIT_JOB_TYPES.includes(job.type)) return;
    const row = await db('websites').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? {} : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };

    if (job.type === 'SITE_GIT_SETUP') {
      if (ok) {
        await settle(row, { git_deploy_public_key: output?.deployKey ?? row.git_deploy_public_key, last_error_code: null, last_error: null }, now);
      } else {
        await settle(row, failure, now);
        // The first deployment cannot work without the site's folders.
        const queued = await db('jobs').where({ resource_type: 'website', resource_id: row.id, status: 'queued', type: 'DEPLOY_SITE_GIT' }).pluck('id');
        for (const jobId of queued) await jobs.cancel(systemActor('Git deploy setup failed'), jobId).catch(() => {});
      }
      return;
    }

    const deployment = await db('website_deployments').where({ job_id: job.id }).first();
    const extra = {};
    if (ok) {
      if (deployment) {
        await db('website_deployments').where({ id: deployment.id }).update({
          status: 'succeeded',
          ...(job.type === 'DEPLOY_SITE_GIT' ? { commit_hash: output?.commit ?? null, commit_message: output?.message?.slice(0, 500) ?? null, commit_author: output?.author?.slice(0, 200) ?? null } : {}),
          release_available: true,
          started_at: job.started_at,
          finished_at: now,
          updated_at: now,
        });
      }
      await markReleases(row.id, output?.releases);
      const params = fromJson(job.params, {});
      Object.assign(extra, {
        git_current_deployment_id: deployment?.id ?? row.git_current_deployment_id,
        git_current_release_id: output?.releaseId ?? params.releaseId,
        git_current_commit: (job.type === 'DEPLOY_SITE_GIT' ? output?.commit : deployment?.commit_hash) ?? null,
        git_last_deployed_at: now,
        last_error_code: null,
        last_error: null,
      });
      // The site serves its releases from now on; its old folder is kept.
      if (row.document_root !== SITE_GIT_DOCUMENT_ROOT) Object.assign(extra, { git_previous_document_root: row.document_root, document_root: SITE_GIT_DOCUMENT_ROOT });
      if (output?.health && !output.health.skipped) {
        Object.assign(extra, { health_status: output.health.ok ? 'ok' : 'failing', health_message: String(output.health.message ?? '').slice(0, 500), health_checked_at: now });
      }
    } else {
      const cancelled = status === 'cancelled';
      if (deployment) {
        await db('website_deployments').where({ id: deployment.id }).update({
          status: cancelled ? 'cancelled' : 'failed',
          failed_stage: cancelled ? null : (SITE_DEPLOY_ERROR_STAGES[error?.code] ?? null),
          error_code: (error?.code ?? 'FAILED').slice(0, 64),
          error_message: error?.message ?? null,
          release_available: false,
          started_at: job.started_at,
          finished_at: now,
          updated_at: now,
        });
      }
      if (!cancelled) Object.assign(extra, failure);
      // A first release that went live but failed its check stays live
      // (there was nothing to switch back to).
      if (error?.code === 'HEALTH_CHECK_FAILED' && !row.git_current_release_id && deployment && job.type === 'DEPLOY_SITE_GIT') {
        Object.assign(extra, { git_current_deployment_id: deployment.id, git_current_release_id: deployment.release_id, git_last_deployed_at: now });
        if (row.document_root !== SITE_GIT_DOCUMENT_ROOT) Object.assign(extra, { git_previous_document_root: row.document_root, document_root: SITE_GIT_DOCUMENT_ROOT });
        await db('website_deployments').where({ id: deployment.id }).update({ release_available: true });
      }
    }
    await settle(row, extra, now);
    if (!ok) logger.info({ websiteId: row.id, job: job.type, error }, 'website deployment failed');
  }

  jobs.onFinished(handleJobFinished);

  return { configure, disable, getEnv, setEnv, deploy, rollback, enableWebhook, disableWebhook, deployFromHook, listDeployments, handleJobFinished };
}

function target(row) {
  return { type: 'website', id: row.id, label: row.name };
}
