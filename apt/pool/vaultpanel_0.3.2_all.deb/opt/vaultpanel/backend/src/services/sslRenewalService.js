import {
  PERMISSIONS,
  SSL_RENEW_BEFORE_MAX,
  SSL_RENEW_BEFORE_MIN,
  SSL_RENEWAL_DEFAULTS,
  SSL_RENEWAL_MIN_AGENT_VERSION,
  SSL_WARN_MIN,
  sslRenewalProblems,
} from '@vaultpanel/shared';
import { loadSslRenewal, setSslRenewal, sslRenewal, SSL_RENEWAL_KEY } from '../models/sslRenewalModel.js';
import { agentOperations } from '../models/serverModel.js';
import { validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { systemActor } from './actor.js';

// How early SSL certificates renew and when the panel warns that one is
// about to expire (SSL Certificates page). Renewal itself stays automatic:
// Certbot's timer on each server renews certificates once they are inside
// the window, the agent keeps that timer on, and the panel asks the server
// to renew any certificate still not renewed a day into the window, so a
// missing or stopped timer does not leave a site to expire. Certificates
// that get close to expiry anyway, or fail to renew, raise events that go
// out by webhook and email.

// Certbot gets this long inside the window before the panel steps in.
const GRACE_MS = 86_400_000;
// One automatic attempt per certificate per day; each run is light, but
// failed attempts count against Let's Encrypt's limits.
const RETRY_MS = 24 * 3_600_000;
// Agents without SET_SSL_RENEWAL keep Certbot's default window.
const CERTBOT_DEFAULT_DAYS = 30;
const DAY_MS = 86_400_000;

export const supportsRenewalWindow = (server) => agentOperations(server).includes('SET_SSL_RENEWAL');

export function createSslRenewalService({ db, logger, audit, authorize, jobs, websites, events }) {
  // Servers with active certificates and whether their agent applies the window.
  async function certificateServers() {
    const rows = await db('servers as s')
      .join('ssl_certificates as c', 'c.server_id', 's.id')
      .join('websites as w', 'w.id', 'c.website_id')
      .where('c.status', 'active')
      // Uploaded certificates are renewed by whoever issued them.
      .where('c.provider', 'letsencrypt')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .groupBy('s.id', 's.name', 's.status', 's.agent_version', 's.agent_operations')
      .select('s.id', 's.name', 's.status', 's.agent_version', 's.agent_operations')
      .count({ certificates: 'c.id' })
      .orderBy('s.name');
    return rows.map((s) => ({
      id: s.id,
      name: s.name,
      status: s.status,
      agentVersion: s.agent_version,
      certificates: Number(s.certificates),
      appliesWindow: supportsRenewalWindow(s),
    }));
  }

  async function get(actor) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    await loadSslRenewal(db);
    return {
      ...sslRenewal(),
      defaults: { ...SSL_RENEWAL_DEFAULTS },
      limits: { renewBeforeDays: { min: SSL_RENEW_BEFORE_MIN, max: SSL_RENEW_BEFORE_MAX }, warnDays: { min: SSL_WARN_MIN } },
      minAgentVersion: SSL_RENEWAL_MIN_AGENT_VERSION,
      // Hosting customers do not see the panel's servers.
      servers: actor?.customerId ? [] : await certificateServers(),
    };
  }

  // Saves the setting and applies the window on every server with
  // certificates whose agent can (older agents keep Certbot's 30 days).
  async function update(actor, input) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const next = { renewBeforeDays: input.renewBeforeDays, warnDays: input.warnDays };
    const problems = sslRenewalProblems(next);
    if (problems.length) throw validationError(problems);
    const before = await loadSslRenewal(db);
    const now = new Date();
    await db('settings')
      .insert({ key: SSL_RENEWAL_KEY, value: toJson(next), is_secret: false, updated_by: actor?.id ?? null, updated_at: now })
      .onConflict('key')
      .merge(['value', 'updated_by', 'updated_at']);
    setSslRenewal(next);
    const queued = [];
    const skipped = [];
    for (const server of await certificateServers()) {
      if (!server.appliesWindow) {
        skipped.push({ serverId: server.id, name: server.name, reason: 'AGENT_OUTDATED' });
        continue;
      }
      try {
        const job = await jobs.create(actor, { serverId: server.id, type: 'SET_SSL_RENEWAL', params: { renewBeforeDays: next.renewBeforeDays } }, { internal: true });
        queued.push({ serverId: server.id, name: server.name, jobId: job.id });
      } catch (err) {
        skipped.push({ serverId: server.id, name: server.name, reason: err.code ?? 'FAILED', message: err.message });
      }
    }
    await audit.record({
      actor,
      action: 'ssl.renewal.update',
      target: { type: 'settings', id: SSL_RENEWAL_KEY, label: 'SSL renewal' },
      metadata: { before, after: next, servers: queued.length, skipped: skipped.length },
    });
    return { ...(await get(actor)), queued, skipped };
  }

  // Asks servers to renew certificates that are a day into their window and
  // still not renewed. Returns how many renewals were started.
  async function autoRenew(now = new Date()) {
    const { renewBeforeDays } = sslRenewal();
    const rows = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .join('servers as s', 's.id', 'c.server_id')
      .where('c.status', 'active')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .whereNotNull('w.provisioned_at')
      .where('w.is_enabled', true)
      .where('s.status', 'online')
      .whereNotNull('c.not_after')
      .where('c.not_after', '<', new Date(now.getTime() + renewBeforeDays * DAY_MS - GRACE_MS))
      .where((q) => q.whereNull('c.auto_renew_attempted_at').orWhere('c.auto_renew_attempted_at', '<', new Date(now.getTime() - RETRY_MS)))
      .select('c.id', 'c.website_id', 'c.not_after', 's.agent_operations');
    let started = 0;
    for (const row of rows) {
      const appliesWindow = supportsRenewalWindow(row);
      const days = appliesWindow ? renewBeforeDays : Math.min(renewBeforeDays, CERTBOT_DEFAULT_DAYS);
      if (new Date(row.not_after).getTime() - now.getTime() >= days * DAY_MS - GRACE_MS) continue;
      // Claimed first, so a failure is not retried on every run.
      await db('ssl_certificates').where({ id: row.id }).update({ auto_renew_attempted_at: now });
      try {
        const job = await websites.renewSslAutomatically(row.website_id, { renewBeforeDays: appliesWindow ? renewBeforeDays : undefined, actor: systemActor('automatic SSL renewal') });
        if (job) {
          await db('ssl_certificates').where({ id: row.id }).update({ auto_renew_job_id: job.id });
          started += 1;
        } else {
          // Busy with another change: try again on the next run.
          await db('ssl_certificates').where({ id: row.id }).update({ auto_renew_attempted_at: null });
        }
      } catch (err) {
        logger.info({ err, certificateId: row.id }, 'automatic SSL renewal not started');
      }
    }
    return started;
  }

  // Sends ssl.expiring and ssl.expired once per certificate and expiry date
  // (a renewed certificate has a new date, so it starts over).
  async function notifyExpiry(now = new Date()) {
    const soon = new Date(now.getTime() + sslRenewal().warnDays * DAY_MS);
    const rows = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .join('servers as s', 's.id', 'c.server_id')
      .where('c.status', 'active')
      .whereNull('w.deleted_at')
      .whereNotNull('c.not_after')
      .where('c.not_after', '<', soon)
      .select('c.id', 'c.not_after', 'c.domains', 'c.expiry_notice', 'c.expiry_notice_for', 'c.is_staging', 'w.id as website_id', 'w.name as website_name', 's.id as server_id', 's.name as server_name');
    let sent = 0;
    for (const row of rows) {
      const notAfter = new Date(row.not_after);
      const notice = notAfter <= now ? 'expired' : 'expiring';
      const sameDate = row.expiry_notice_for && new Date(row.expiry_notice_for).getTime() === notAfter.getTime();
      if (sameDate && row.expiry_notice === notice) continue;
      await db('ssl_certificates').where({ id: row.id }).update({ expiry_notice: notice, expiry_notice_for: notAfter });
      await events.emit(`ssl.${notice}`, {
        website: { id: row.website_id, name: row.website_name },
        server: { id: row.server_id, name: row.server_name },
        domains: fromJson(row.domains, []),
        notAfter: notAfter.toISOString(),
        daysLeft: Math.floor((notAfter - now) / DAY_MS),
        staging: Boolean(row.is_staging),
      });
      sent += 1;
    }
    return sent;
  }

  // Automatic renewals that failed. Manual ones show their error on the page.
  async function onJobFinished(job, { status, error }) {
    if (job.type !== 'RENEW_SSL' || status === 'succeeded') return;
    const row = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .join('servers as s', 's.id', 'c.server_id')
      .where('c.auto_renew_job_id', job.id)
      .first('c.domains', 'c.not_after', 'w.id as website_id', 'w.name as website_name', 's.id as server_id', 's.name as server_name');
    if (!row) return;
    await events.emit('ssl.renew_failed', {
      website: { id: row.website_id, name: row.website_name },
      server: { id: row.server_id, name: row.server_name },
      domains: fromJson(row.domains, []),
      notAfter: row.not_after ? new Date(row.not_after).toISOString() : null,
      error: { code: error?.code ?? null, message: error?.message ?? null },
    });
  }

  // Worker: the setting may have changed in the API process.
  async function tick(now = new Date()) {
    await loadSslRenewal(db);
    const renewals = await autoRenew(now);
    const notices = await notifyExpiry(now);
    return { renewals, notices };
  }

  return { get, update, autoRenew, notifyExpiry, onJobFinished, tick };
}
