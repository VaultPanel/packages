import { randomUUID } from 'node:crypto';
import { Resolver } from 'node:dns/promises';
import {
  ACTIVE_JOB_STATUSES,
  defaultDnsRecords,
  DNS_RECORD_TYPES,
  DNS_TTL,
  dnsHostname,
  dnsRecordProblems,
  dnsRelativeName,
  dnsZoneProblems,
  isIPv4,
  isIPv6,
  isRegisteredDomain,
  nextDnsSerial,
  PERMISSIONS,
} from '@vaultpanel/shared';
import { toPublicDnsRecord, toPublicDnsZone } from '../models/dnsModel.js';
import { findServer } from '../models/serverModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { systemActor } from './actor.js';
import { isPrivateAddress } from './agentService.js';

// DNS zones served by BIND on one of the panel's servers (the way cPanel and
// CyberPanel run DNS on the hosting server itself).
//
// The panel keeps a zone's records. Every change raises the zone's serial and
// sends the whole zone to the agent, which checks it with BIND before it goes
// live. Changes made while one is on its way are sent right after it, so
// people can edit several records in a row without waiting.

const NS_HOST = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]*$/;

export function createDnsService({ db, logger, audit, authorize, jobs, resolver = new Resolver({ timeout: 4000, tries: 2 }) }) {
  // ---- Reading ------------------------------------------------------------

  function zoneQuery() {
    return db('dns_zones as z')
      .join('servers as s', 's.id', 'z.server_id')
      .leftJoin('jobs as j', 'j.id', 'z.last_job_id')
      .whereNull('z.deleted_at')
      .whereNull('s.deleted_at')
      .select('z.*', 's.name as server_name', 'j.status as last_job_status', 'j.type as last_job_type');
  }

  const applying = (row) => row.last_job_type === 'DNS_ZONE_APPLY' && ACTIVE_JOB_STATUSES.includes(row.last_job_status);
  const recordsOf = (zoneId) => db('dns_records').where({ zone_id: zoneId }).orderBy([{ column: 'name' }, { column: 'type' }, { column: 'value' }]);

  async function loadZone(id) {
    const row = await zoneQuery().where('z.id', id).first();
    if (!row) throw notFound('DNS zone not found');
    return row;
  }

  async function zoneDetail(id) {
    const row = await loadZone(id);
    return toPublicDnsZone(row, { records: await recordsOf(id), applying: applying(row) });
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.DNS_READ);
    const q = zoneQuery().select(db('dns_records as r').count('*').whereRaw('r.zone_id = z.id').as('record_count'));
    if (query.serverId) q.where('z.server_id', query.serverId);
    if (query.search) q.where('z.domain', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { domain: 'z.domain', createdAt: 'z.created_at' });
    return { items: rows.map((r) => toPublicDnsZone(r, { recordCount: Number(r.record_count), applying: applying(r) })), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_READ);
    return zoneDetail(id);
  }

  // ---- Checks -------------------------------------------------------------

  function requireDnsServer(server) {
    if (!server || server.deleted_at) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    const dns = fromJson(server.web_stack, null)?.dns;
    if (dns === undefined) throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} is too old to serve DNS zones. Update it from the server page.`);
    if (!dns?.configured) throw new AppError(409, 'DNS_NOT_SET_UP', `The DNS server is not set up on ${server.name}. Set it up from the DNS page first.`);
  }

  // The server's public addresses, for a new zone's records.
  function serverAddresses(server) {
    const all = [server.public_ip, ...fromJson(server.ip_addresses, [])].filter((a) => typeof a === 'string' && !isPrivateAddress(a) && !/^(127\.|::1$|fe80:)/i.test(a));
    return { ipv4: all.find(isIPv4) ?? null, ipv6: all.find(isIPv6) ?? null };
  }

  // A record as typed (names relative or full, host names with or without
  // the final dot), checked and ready to store.
  function cleanRecord(input, domain) {
    const type = DNS_RECORD_TYPES[input.type];
    const record = {
      name: dnsRelativeName(input.name, domain),
      type: input.type,
      ttl: input.ttl ?? null,
      value: ['A', 'AAAA', 'TXT', 'CAA'].includes(input.type) ? String(input.value ?? '').trim() : dnsHostname(input.value),
      priority: type?.priority ? (input.priority ?? null) : null,
      weight: type?.weight ? (input.weight ?? null) : null,
      port: type?.port ? (input.port ?? null) : null,
      tag: type?.tag ? (input.tag ?? 'issue') : null,
    };
    if (input.type === 'TXT') record.value = String(input.value ?? '');
    const problems = dnsRecordProblems(record);
    if (problems.length) throw validationError(problems);
    return record;
  }

  function checkZoneRecords(records) {
    const problems = dnsZoneProblems(records);
    if (problems.length) throw validationError(problems, problems[0].message);
  }

  // ---- Applying -----------------------------------------------------------

  // What the agent gets: the whole zone, without empty fields.
  function zoneParams(zone, records, serial) {
    return {
      zone: zone.domain,
      serial,
      ttl: zone.default_ttl,
      email: zone.soa_email,
      records: records.map((r) => {
        const out = { name: r.name, type: r.type, value: r.value };
        for (const key of ['ttl', 'priority', 'weight', 'port', 'tag']) if (r[key] !== null && r[key] !== undefined) out[key] = r[key];
        return out;
      }),
    };
  }

  // Raises the serial after a change. Returns the new serial.
  async function bump(trx, zoneId) {
    const row = await trx('dns_zones').where({ id: zoneId }).forUpdate().first('serial');
    const serial = nextDnsSerial(Number(row.serial));
    await trx('dns_zones').where({ id: zoneId }).update({ serial, updated_at: new Date() });
    return serial;
  }

  // Sends the zone as it is now, unless an apply is already on its way (it
  // is sent again when that one finishes). Returns the job, or null.
  async function queueApply(actor, zoneId, { force = false } = {}) {
    const row = await loadZone(zoneId);
    if (row.status === 'deleting') return null;
    if (applying(row)) return null;
    if (!force && row.applied_serial !== null && Number(row.applied_serial) >= Number(row.serial)) return null;
    const records = await recordsOf(zoneId);
    let job;
    try {
      job = await jobs.create(
        actor,
        { serverId: row.server_id, type: 'DNS_ZONE_APPLY', params: zoneParams(row, records, Number(row.serial)), resource: { type: 'dns_zone', id: zoneId } },
        { internal: true },
      );
    } catch (err) {
      if (err.code === 'DUPLICATE_OPERATION') return null;
      throw err;
    }
    await db('dns_zones').where({ id: zoneId }).update({ last_job_id: job.id });
    return job;
  }

  // Applies a change to a zone's records or settings, then sends the zone.
  async function change(actor, zoneId, fn) {
    const zone = await loadZone(zoneId);
    if (zone.status === 'deleting') throw new AppError(409, 'DNS_ZONE_DELETING', 'This zone is being deleted');
    const result = await db.transaction(async (trx) => {
      const out = await fn(trx, zone);
      await bump(trx, zoneId);
      return out;
    });
    const job = await queueApply(actor, zoneId);
    return { result, job };
  }

  // ---- Zones --------------------------------------------------------------

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const server = await findServer(db, input.serverId);
    requireDnsServer(server);
    return createZone(actor, server, input);
  }

  // Adds a zone on a server whose DNS is set up (customerId: the hosting
  // account it is added for, when VaultPanel adds it by itself).
  async function createZone(actor, server, input, { customerId = null } = {}) {
    const domain = input.domain;
    const taken = await db('dns_zones').where({ domain_key: domain }).first('id');
    if (taken) throw validationError([{ field: 'domain', message: `There is already a DNS zone for ${domain}` }]);
    const found = serverAddresses(server);
    const ipv4 = input.ipv4 ?? found.ipv4;
    const ipv6 = input.ipv6 === undefined ? null : input.ipv6;
    if (!ipv4 && !ipv6) throw validationError([{ field: 'ipv4', message: `VaultPanel does not know a public address for ${server.name}. Enter the address the domain should point at.` }]);
    const nameservers = input.nameservers?.length ? input.nameservers.map(dnsHostname) : null;
    const records = defaultDnsRecords({ domain, ipv4, ipv6, nameservers, mail: input.mailRecords }).map((r) => cleanRecord(r, domain));
    checkZoneRecords(records);

    const id = randomUUID();
    const now = new Date();
    try {
      await db.transaction(async (trx) => {
        await trx('dns_zones').insert({
          id,
          server_id: server.id,
          domain,
          domain_key: domain,
          status: 'creating',
          default_ttl: input.defaultTtl ?? DNS_TTL.default,
          soa_email: input.soaEmail ?? `hostmaster@${domain}`,
          serial: nextDnsSerial(0, now),
          customer_id: customerId,
          created_by: actor.type === 'user' ? actor.id : null,
          created_at: now,
          updated_at: now,
        });
        await trx('dns_records').insert(records.map((r) => ({ id: randomUUID(), zone_id: id, ...r, created_at: now, updated_at: now })));
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'domain', message: 'This domain was just added' }]);
      throw err;
    }
    let job;
    try {
      job = await queueApply(actor, id);
    } catch (err) {
      await db('dns_zones').where({ id }).delete();
      throw err;
    }
    await audit.record({ actor, action: 'dns_zone.create', target: target({ id, domain }), metadata: { serverId: server.id, records: records.length, customerId: customerId ?? undefined, jobId: job?.id } });
    return { zone: await zoneDetail(id), job };
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const { job } = await change(actor, id, (trx) =>
      trx('dns_zones')
        .where({ id })
        .update({
          ...(changes.defaultTtl !== undefined ? { default_ttl: changes.defaultTtl } : {}),
          ...(changes.soaEmail !== undefined ? { soa_email: changes.soaEmail } : {}),
          updated_at: new Date(),
        }),
    );
    const zone = await loadZone(id);
    await audit.record({ actor, action: 'dns_zone.update', target: target(zone), metadata: { ...changes, jobId: job?.id } });
    return { zone: await zoneDetail(id), job };
  }

  // Sends the zone again (after a failure, or to put back a zone file
  // someone changed by hand).
  async function apply(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const row = await loadZone(id);
    if (row.status === 'deleting') throw new AppError(409, 'DNS_ZONE_DELETING', 'This zone is being deleted');
    if (applying(row)) throw new AppError(409, 'DNS_ZONE_BUSY', 'The zone is being applied right now', { jobId: row.last_job_id });
    await db('dns_zones').where({ id }).update({ last_error_code: null, last_error: null, ...(row.status === 'failed' ? { status: 'creating' } : {}) });
    const job = await queueApply(actor, id, { force: true });
    await audit.record({ actor, action: 'dns_zone.apply', target: target(row), metadata: { jobId: job?.id } });
    return { zone: await zoneDetail(id), job };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    return removeZone(actor, id);
  }

  async function removeZone(actor, id) {
    const row = await loadZone(id);
    if (row.status === 'deleting') throw new AppError(409, 'DNS_ZONE_DELETING', 'This zone is already being deleted', { jobId: row.last_job_id });
    const claimed = await db('dns_zones').where({ id }).whereNot('status', 'deleting').update({ status: 'deleting', last_error_code: null, last_error: null, updated_at: new Date() });
    if (!claimed) throw new AppError(409, 'DNS_ZONE_DELETING', 'This zone is already being deleted');
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type: 'DNS_ZONE_REMOVE', params: { zone: row.domain }, resource: { type: 'dns_zone', id } }, { internal: true });
    } catch (err) {
      await db('dns_zones').where({ id }).update({ status: row.status });
      throw err;
    }
    await db('dns_zones').where({ id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'dns_zone.delete', target: target(row), metadata: { jobId: job.id } });
    return { zone: await zoneDetail(id), job };
  }

  // ---- Records ------------------------------------------------------------

  async function addRecord(actor, zoneId, input) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const zone = await loadZone(zoneId);
    const record = cleanRecord(input, zone.domain);
    const id = randomUUID();
    const { job } = await change(actor, zoneId, async (trx) => {
      const records = await trx('dns_records').where({ zone_id: zoneId });
      checkZoneRecords([...records, record]);
      const now = new Date();
      await trx('dns_records').insert({ id, zone_id: zoneId, ...record, created_at: now, updated_at: now });
    });
    await audit.record({ actor, action: 'dns_record.create', target: target(zone), metadata: { record: describe(record), jobId: job?.id } });
    return { record: toPublicDnsRecord(await db('dns_records').where({ id }).first(), zone.domain), zone: await zoneDetail(zoneId), job };
  }

  async function loadRecord(zoneId, recordId) {
    const row = await db('dns_records').where({ id: recordId, zone_id: zoneId }).first();
    if (!row) throw notFound('DNS record not found');
    return row;
  }

  async function updateRecord(actor, zoneId, recordId, input) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const zone = await loadZone(zoneId);
    const current = await loadRecord(zoneId, recordId);
    const record = cleanRecord({ ...current, ...input }, zone.domain);
    const { job } = await change(actor, zoneId, async (trx) => {
      const records = await trx('dns_records').where({ zone_id: zoneId }).whereNot({ id: recordId });
      checkZoneRecords([...records, record]);
      await trx('dns_records').where({ id: recordId }).update({ ...record, updated_at: new Date() });
    });
    await audit.record({ actor, action: 'dns_record.update', target: target(zone), metadata: { before: describe(current), after: describe(record), jobId: job?.id } });
    return { record: toPublicDnsRecord(await loadRecord(zoneId, recordId), zone.domain), zone: await zoneDetail(zoneId), job };
  }

  async function removeRecord(actor, zoneId, recordId) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const zone = await loadZone(zoneId);
    const current = await loadRecord(zoneId, recordId);
    const { job } = await change(actor, zoneId, async (trx) => {
      const records = await trx('dns_records').where({ zone_id: zoneId }).whereNot({ id: recordId });
      checkZoneRecords(records);
      await trx('dns_records').where({ id: recordId }).delete();
    });
    await audit.record({ actor, action: 'dns_record.delete', target: target(zone), metadata: { record: describe(current), jobId: job?.id } });
    return { zone: await zoneDetail(zoneId), job };
  }

  // ---- Records other features need ---------------------------------------

  // The panel's zone that holds a name (the zone itself or a parent), or
  // null.
  async function zoneFor(name) {
    const candidates = [];
    const labels = name.split('.');
    for (let i = 0; i < labels.length - 1; i += 1) candidates.push(labels.slice(i).join('.'));
    const rows = await zoneQuery().whereIn('z.domain_key', candidates).whereNot('z.status', 'deleting');
    rows.sort((a, b) => b.domain.length - a.domain.length);
    return rows[0] ?? null;
  }

  // Puts records into the zone that holds owner (email's MX, SPF, DKIM and
  // DMARC), replacing what they replace: every MX of the name, and the SPF,
  // DKIM or DMARC text of the name. Names are relative to owner. Returns
  // the zone and what changed, or null when no zone here holds owner.
  async function putRecords(actor, owner, wanted, { replace = () => false } = {}) {
    const zoneRow = await zoneFor(owner);
    if (!zoneRow) return null;
    const relative = (name) => dnsRelativeName(name === '@' ? owner : `${name}.${owner}`, zoneRow.domain);
    const records = wanted.map((r) => cleanRecord({ ...r, name: relative(r.name) }, zoneRow.domain));
    const same = (c, r) => c.name === r.name && c.type === r.type && c.value === r.value && (c.priority ?? null) === (r.priority ?? null);
    const plan = (current) => {
      const out = current.filter((c) => records.some((r) => r.name === c.name && replace(c, r)) && !records.some((r) => same(c, r)));
      const kept = current.filter((c) => !out.includes(c));
      return { kept, out, add: records.filter((r) => !kept.some((c) => same(c, r))) };
    };
    const preview = plan(await recordsOf(zoneRow.id));
    if (!preview.add.length && !preview.out.length) return { zoneId: zoneRow.id, domain: zoneRow.domain, added: 0, removed: 0, job: null };
    let added = [];
    let removed = [];
    const { job } = await change(actor, zoneRow.id, async (trx) => {
      const current = await trx('dns_records').where({ zone_id: zoneRow.id });
      const { kept, out, add } = plan(current);
      removed = out;
      added = add;
      checkZoneRecords([...kept, ...added]);
      if (removed.length) await trx('dns_records').whereIn('id', removed.map((r) => r.id)).delete();
      const now = new Date();
      if (added.length) await trx('dns_records').insert(added.map((r) => ({ id: randomUUID(), zone_id: zoneRow.id, ...r, created_at: now, updated_at: now })));
    });
    if (added.length || removed.length) {
      await audit.record({ actor, action: 'dns_record.update', target: target(zoneRow), metadata: { added: added.map(describe), removed: removed.map(describe), jobId: job?.id } });
    }
    return { zoneId: zoneRow.id, domain: zoneRow.domain, added: added.length, removed: removed.length, job };
  }

  // The records of the zone that holds owner, with names relative to owner
  // (for showing what a feature's records look like there).
  async function recordsAt(owner) {
    const zoneRow = await zoneFor(owner);
    if (!zoneRow) return null;
    const suffix = owner === zoneRow.domain ? '' : owner.slice(0, -zoneRow.domain.length - 1);
    const rows = await recordsOf(zoneRow.id);
    const out = [];
    for (const r of rows) {
      let name = null;
      if (!suffix) name = r.name;
      else if (r.name === suffix) name = '@';
      else if (r.name.endsWith(`.${suffix}`)) name = r.name.slice(0, -suffix.length - 1);
      if (name !== null) out.push({ ...r, name });
    }
    return { zoneId: zoneRow.id, domain: zoneRow.domain, status: zoneRow.status, records: out };
  }

  // Takes records out of the zone that holds owner: the ones of the given
  // type and value at each name (relative to owner). Records changed by hand
  // since are left alone. Returns how many were removed.
  async function dropRecords(actor, owner, unwanted) {
    const zoneRow = await zoneFor(owner);
    if (!zoneRow || !unwanted.length) return 0;
    const relative = (name) => dnsRelativeName(name === '@' ? owner : `${name}.${owner}`, zoneRow.domain);
    const match = (c) => unwanted.some((u) => relative(u.name) === c.name && u.type === c.type && u.value === c.value);
    if (!(await recordsOf(zoneRow.id)).some(match)) return 0;
    let removed = [];
    const { job } = await change(actor, zoneRow.id, async (trx) => {
      const current = await trx('dns_records').where({ zone_id: zoneRow.id });
      removed = current.filter(match);
      checkZoneRecords(current.filter((c) => !match(c)));
      if (removed.length) await trx('dns_records').whereIn('id', removed.map((r) => r.id)).delete();
    });
    if (removed.length) await audit.record({ actor, action: 'dns_record.delete', target: target(zoneRow), metadata: { removed: removed.map(describe), jobId: job?.id } });
    return removed.length;
  }

  // ---- What hosting customers see ----------------------------------------

  // The name servers customers on a server are told to use, and whether a
  // zone is added on the server for each new customer domain.
  async function setCustomerDns(actor, serverId, { nameservers, autoZones }) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const server = await findServer(db, serverId);
    if (!server || server.deleted_at) throw notFound('Server not found');
    if (autoZones) requireDnsServer(server);
    const hosts = [...new Set(nameservers.map(dnsHostname))];
    await db('servers').where({ id: server.id }).update({ customer_nameservers: hosts.length ? toJson(hosts) : null, customer_dns_zones: Boolean(autoZones), updated_at: new Date() });
    await audit.record({ actor, action: 'dns.customer_settings', target: { type: 'server', id: server.id, label: server.name }, metadata: { nameservers: hosts, autoZones: Boolean(autoZones) } });
    return { nameservers: hosts, autoZones: Boolean(autoZones) };
  }

  // The zones a customer may see: the ones added for their account, and the
  // ones for a domain of one of their websites.
  function customerZoneQuery(customerId) {
    return zoneQuery()
      .whereNot('z.status', 'deleting')
      .where((w) =>
        w.where('z.customer_id', customerId).orWhereExists(
          db('website_domains as d').join('websites as ws', 'ws.id', 'd.website_id').whereRaw('d.domain_key = z.domain_key').where('ws.customer_id', customerId).whereNull('ws.deleted_at'),
        ),
      );
  }

  // My Hosting: the name servers to set at the registrar, and the
  // customer's domains this panel answers for.
  async function customerView(customerId) {
    const customer = await db('customers').where({ id: customerId }).first('server_id');
    const server = customer?.server_id ? await db('servers').where({ id: customer.server_id }).whereNull('deleted_at').first() : null;
    const rows = await customerZoneQuery(customerId).orderBy('z.domain');
    const zones = [];
    for (const row of rows) {
      const zone = toPublicDnsZone(row, { records: await recordsOf(row.id), applying: applying(row) });
      zones.push({ id: zone.id, domain: zone.domain, status: zone.status, nameservers: zone.nameservers, delegation: zone.delegation });
    }
    return {
      nameservers: fromJson(server?.customer_nameservers, []),
      autoZones: Boolean(server?.customer_dns_zones) && Boolean(fromJson(server?.web_stack, null)?.dns?.configured),
      zones,
    };
  }

  async function customerCheck(customerId, zoneId) {
    const row = await customerZoneQuery(customerId).where('z.id', zoneId).first();
    if (!row) throw notFound('DNS zone not found');
    await checkDelegationOf(zoneId);
    return (await customerView(customerId)).zones.find((z) => z.id === zoneId) ?? null;
  }

  // A zone for each new domain of a customer's website, when the website's
  // server is set to add them (DNS page, "For customers"). Only for
  // registered domains (example.com, not blog.example.com) that no zone here
  // holds yet. Called when the site is created on its server.
  async function addCustomerZones(website, domains) {
    if (!website.customer_id) return [];
    const server = await findServer(db, website.server_id);
    if (!server || server.deleted_at || !server.customer_dns_zones || !fromJson(server.web_stack, null)?.dns?.configured) return [];
    const wanted = [...new Set(domains.map((d) => d.replace(/^www\./, '')))].filter(isRegisteredDomain);
    const added = [];
    for (const domain of wanted) {
      if (await zoneFor(domain)) continue;
      const nameservers = fromJson(server.customer_nameservers, []);
      try {
        const { zone } = await createZone(systemActor('customer dns zones'), server, { domain, ...(nameservers.length ? { nameservers } : {}), mailRecords: false }, { customerId: website.customer_id });
        added.push(zone.domain);
      } catch (err) {
        logger.warn({ err, domain, websiteId: website.id }, 'could not add a DNS zone for a customer domain');
      }
    }
    return added;
  }

  // Removes the zones added for a hosting account (when it is removed).
  async function removeCustomerZones(actor, customerId) {
    const rows = await zoneQuery().where('z.customer_id', customerId).whereNot('z.status', 'deleting');
    const warnings = [];
    for (const row of rows) {
      try {
        await removeZone(actor, row.id);
      } catch (err) {
        warnings.push(`DNS zone ${row.domain}: ${err.message}`);
      }
    }
    return { removed: rows.length - warnings.length, warnings };
  }

  // ---- Name servers in public DNS ----------------------------------------

  // Asks public DNS which name servers the domain has, and compares them
  // with the zone's own NS records: once they match, the internet asks this
  // server about the domain.
  async function checkDelegation(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_READ);
    return checkDelegationOf(id);
  }

  async function checkDelegationOf(id) {
    const row = await loadZone(id);
    const expected = (await db('dns_records').where({ zone_id: id, name: '@', type: 'NS' }).pluck('value')).map(dnsHostname).sort();
    let status;
    let found = [];
    let detail = null;
    try {
      found = [...new Set((await resolver.resolveNs(row.domain)).map(dnsHostname).filter((h) => NS_HOST.test(h)))].sort();
      const matching = found.filter((h) => expected.includes(h));
      if (matching.length === found.length && found.length) status = 'ok';
      else if (matching.length) status = 'partial';
      else status = 'elsewhere';
      if (status !== 'ok') detail = `Public DNS lists ${found.join(', ')}. Set the domain's name servers to ${expected.join(', ')} at its registrar.`;
    } catch (err) {
      if (['ENOTFOUND', 'ENODATA', 'NXDOMAIN'].includes(err.code)) {
        status = 'unresolved';
        detail = 'Public DNS has no name servers for this domain. It may not be registered yet, or the registrar has not published the change.';
      } else {
        status = 'error';
        detail = `The lookup failed (${err.code ?? err.message}). Try again in a minute.`;
      }
    }
    await db('dns_zones').where({ id }).update({ delegation_status: status, delegation_nameservers: toJson(found), delegation_detail: detail, delegation_checked_at: new Date() });
    return { zone: await zoneDetail(id), expected };
  }

  // ---- Job results --------------------------------------------------------

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'dns_zone') return;
    const row = await db('dns_zones').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };
    if (job.type === 'DNS_ZONE_APPLY') {
      const sent = Number(fromJson(job.params, {}).serial ?? 0);
      const confirmed = Number(output?.serial ?? sent);
      const applied = ok ? Math.max(Number(row.applied_serial ?? 0), confirmed) : row.applied_serial;
      await db('dns_zones')
        .where({ id: row.id })
        .update({
          ...failure,
          ...(ok ? { applied_serial: applied, applied_at: now } : {}),
          status: row.status === 'deleting' ? 'deleting' : ok || row.applied_serial !== null ? 'active' : 'failed',
          updated_at: now,
        });
      // Changes made while this one was on its way.
      if (ok && Number(row.serial) > applied) {
        await queueApply(systemActor('dns zone changes'), row.id).catch((err) => logger.warn({ err, zoneId: row.id }, 'could not send the newer DNS zone'));
      }
      if (!ok) logger.info({ zoneId: row.id, error }, 'DNS zone apply failed');
    } else if (job.type === 'DNS_ZONE_REMOVE') {
      if (ok) {
        await db('dns_zones').where({ id: row.id }).update({ domain_key: null, deleted_at: now, updated_at: now });
      } else {
        await db('dns_zones').where({ id: row.id }).update({ ...failure, status: row.applied_serial !== null ? 'active' : 'failed', updated_at: now });
      }
    }
  }

  async function summary() {
    const row = await zoneQuery().clearSelect().count({ n: '*' }).first();
    return { total: Number(row?.n ?? 0) };
  }

  jobs.onFinished(handleJobFinished);

  return {
    list,
    get,
    create,
    update,
    apply,
    remove,
    addRecord,
    updateRecord,
    removeRecord,
    checkDelegation,
    summary,
    handleJobFinished,
    zoneFor,
    putRecords,
    dropRecords,
    recordsAt,
    serverAddresses,
    setCustomerDns,
    customerView,
    customerCheck,
    addCustomerZones,
    removeCustomerZones,
  };
}

function target(zone) {
  return { type: 'dns_zone', id: zone.id, label: zone.domain };
}

function describe(r) {
  return [r.name, r.ttl ?? '', r.type, r.priority ?? '', r.weight ?? '', r.port ?? '', r.tag ?? '', r.value].filter((x) => x !== '').join(' ').slice(0, 500);
}
