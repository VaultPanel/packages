import { z } from 'zod';
import {
  APP_LOG_KINDS,
  ASSISTANT_ACTION_KEYS,
  ASSISTANT_ACTIONS,
  FILE_LOG_KINDS,
  FINAL_JOB_STATUSES,
  JOB_STATUSES,
  LOG_PRIORITY_KEYS,
  LOG_SOURCE_KEYS,
  SERVICE_NAME_PATTERN,
} from '@vaultpanel/shared';
import { AppError } from '../../utils/errors.js';

// What the assistant can look at, and the one way it can ask for a change
// (propose_action). Every tool calls the same service the web UI uses, as the
// person who asked, so it sees exactly what they may see and nothing more.
// Reads that need the server (logs, service state, ports) run as ordinary
// agent jobs and show up in the job history like any other.

const MAX_RESULT_CHARS = 12_000;
const JOB_WAIT_MS = 60_000;
const MAX_PROPOSALS_PER_TURN = 3;

const uuid = { type: 'string', format: 'uuid' };
const object = (properties, required = Object.keys(properties)) => ({ type: 'object', properties, required, additionalProperties: false });

export const TOOL_DEFINITIONS = [
  {
    name: 'list_servers',
    description: 'List the servers connected to the panel with their status (online, offline, pending), operating system and agent version. Use it to find a server id.',
    inputSchema: object({ search: { type: 'string', description: 'Optional part of a server name or hostname' } }, []),
  },
  {
    name: 'get_server',
    description: 'Details of one server: status, CPU, memory, disk and load right now, uptime, the state of its system services (nginx, php-fpm, mariadb...), installed web software, disks and its open alerts.',
    inputSchema: object({ serverId: uuid }),
  },
  {
    name: 'find',
    description: 'Find websites, domains, apps and databases by name or domain (for example "api.example.com" or "shop"). Start here when the person names something.',
    inputSchema: object({ query: { type: 'string', description: 'A domain, or part of a name' } }),
  },
  {
    name: 'get_website',
    description: 'Details of one website: type (static, php, proxy to an app port), domains, whether it is on, last health check, SSL certificate and its expiry, the app it serves, the last error and recent jobs.',
    inputSchema: object({ websiteId: uuid }),
  },
  {
    name: 'get_application',
    description: 'Details of one app (Node.js or Python, run by PM2): its process state, port, start command, current release, last error, recent deployments and jobs. Environment variable values are never shown.',
    inputSchema: object({ applicationId: uuid }),
  },
  {
    name: 'get_deployment',
    description: 'One deployment of an app: its status, failed stage, commit, and the last lines of its log.',
    inputSchema: object({ deploymentId: uuid }),
  },
  {
    name: 'read_website_log',
    description: 'Read the last lines of a website\'s NGINX access or error log on its server. The error log is where 502/504 and PHP errors show up.',
    inputSchema: object({ websiteId: uuid, log: { type: 'string', enum: FILE_LOG_KINDS }, lines: { type: 'integer', minimum: 10, maximum: 400 } }, ['websiteId', 'log']),
  },
  {
    name: 'read_application_log',
    description: 'Read the last lines of an app\'s output or error log (what the app printed while running under PM2).',
    inputSchema: object({ applicationId: uuid, log: { type: 'string', enum: APP_LOG_KINDS }, lines: { type: 'integer', minimum: 10, maximum: 400 } }, ['applicationId', 'log']),
  },
  {
    name: 'check_service',
    description: 'Check a systemd service on a server right now (for example nginx, php8.3-fpm, mariadb): whether it is active, failed or stopped.',
    inputSchema: object({ serverId: uuid, service: { type: 'string', pattern: SERVICE_NAME_PATTERN.source } }),
  },
  {
    name: 'read_service_log',
    description: 'Read the last journal lines of a systemd service on a server, to see why it failed or restarted.',
    inputSchema: object({ serverId: uuid, service: { type: 'string', pattern: SERVICE_NAME_PATTERN.source }, lines: { type: 'integer', minimum: 10, maximum: 400 } }, ['serverId', 'service']),
  },
  {
    name: 'read_system_log',
    description: 'Read a server\'s system logs: the whole journal, kernel messages (out of memory kills, disk errors), sign-ins, or cron. Can filter by priority, text and time.',
    inputSchema: object(
      {
        serverId: uuid,
        source: { type: 'string', enum: LOG_SOURCE_KEYS },
        priority: { type: 'string', enum: LOG_PRIORITY_KEYS },
        search: { type: 'string', description: 'Plain text to look for' },
        sinceMinutes: { type: 'integer', minimum: 1, maximum: 44640 },
        lines: { type: 'integer', minimum: 10, maximum: 400 },
      },
      ['serverId', 'source'],
    ),
  },
  {
    name: 'list_processes',
    description: 'The processes using the most CPU or memory on a server right now.',
    inputSchema: object({ serverId: uuid, sortBy: { type: 'string', enum: ['cpu', 'memory'] } }, ['serverId']),
  },
  {
    name: 'list_listening_ports',
    description: 'The TCP ports a server is listening on and which programs hold them. Use it to check whether an app is really listening on the port its website proxies to.',
    inputSchema: object({ serverId: uuid }),
  },
  {
    name: 'list_alerts',
    description: 'Open monitoring alerts (high CPU, memory, disk, server offline, service down), for one server or all.',
    inputSchema: object({ serverId: uuid }, []),
  },
  {
    name: 'list_recent_jobs',
    description: 'Recent operations the panel ran on servers (deploys, SSL, service restarts, website changes...), newest first. Use status "failed" to find what went wrong.',
    inputSchema: object({ serverId: uuid, status: { type: 'string', enum: JOB_STATUSES } }, []),
  },
  {
    name: 'get_job',
    description: 'One job: its parameters, result, error and the last lines of its log.',
    inputSchema: object({ jobId: uuid }),
  },
  {
    name: 'list_databases',
    description: 'MariaDB databases on the servers, with their size and the app they belong to.',
    inputSchema: object({ serverId: uuid }, []),
  },
  {
    name: 'propose_action',
    description:
      'Propose a change for the person to review. Nothing happens until they press Approve; the panel then runs it with their permissions. ' +
      'Use it only when your findings show the change will help, at most once per change. Actions: ' +
      ASSISTANT_ACTION_KEYS.map((key) => `${key} (${ASSISTANT_ACTIONS[key].label}; params: ${Object.keys(ASSISTANT_ACTIONS[key].params).join(', ')})`).join('; ') +
      '. server.install_software components: nginx, php, certbot, git, pm2, python, mariadb, cron.',
    inputSchema: object({
      action: { type: 'string', enum: ASSISTANT_ACTION_KEYS },
      params: { type: 'object', description: 'The parameters the action takes, by id' },
      reason: { type: 'string', description: 'One sentence the person reads on the card: why this helps' },
    }),
  },
];

const TOOLS_BY_NAME = Object.fromEntries(TOOL_DEFINITIONS.map((t) => [t.name, t]));

// Input checks, so a malformed tool call gets a clear error back instead of
// reaching a service.
const id = z.uuid();
const lines = z.number().int().min(10).max(400).optional();
const service = z.string().regex(SERVICE_NAME_PATTERN);
const INPUTS = {
  list_servers: z.object({ search: z.string().max(100).optional() }),
  get_server: z.object({ serverId: id }),
  find: z.object({ query: z.string().trim().min(1).max(100) }),
  get_website: z.object({ websiteId: id }),
  get_application: z.object({ applicationId: id }),
  get_deployment: z.object({ deploymentId: id }),
  read_website_log: z.object({ websiteId: id, log: z.enum(FILE_LOG_KINDS), lines }),
  read_application_log: z.object({ applicationId: id, log: z.enum(APP_LOG_KINDS), lines }),
  check_service: z.object({ serverId: id, service }),
  read_service_log: z.object({ serverId: id, service, lines }),
  read_system_log: z.object({
    serverId: id,
    source: z.enum(LOG_SOURCE_KEYS),
    priority: z.enum(LOG_PRIORITY_KEYS).optional(),
    search: z.string().max(200).optional(),
    sinceMinutes: z.number().int().min(1).max(44640).optional(),
    lines,
  }),
  list_processes: z.object({ serverId: id, sortBy: z.enum(['cpu', 'memory']).optional() }),
  list_listening_ports: z.object({ serverId: id }),
  list_alerts: z.object({ serverId: id.optional() }),
  list_recent_jobs: z.object({ serverId: id.optional(), status: z.enum(JOB_STATUSES).optional() }),
  get_job: z.object({ jobId: id }),
  list_databases: z.object({ serverId: id.optional() }),
  propose_action: z.object({ action: z.enum(ASSISTANT_ACTION_KEYS), params: z.record(z.string(), z.unknown()), reason: z.string().trim().min(1).max(1000) }),
};

// The parameters each proposed action takes, checked strictly.
const componentKeys = ASSISTANT_ACTIONS['server.install_software'].params.components.items.enum;
export const ACTION_PARAMS = Object.fromEntries(
  ASSISTANT_ACTION_KEYS.map((key) => {
    const shape = {};
    for (const [name, def] of Object.entries(ASSISTANT_ACTIONS[key].params)) {
      if (def.format === 'uuid') shape[name] = z.uuid();
      else if (def.type === 'array') shape[name] = z.array(z.enum(componentKeys)).min(1).max(componentKeys.length);
      else shape[name] = z.string().regex(new RegExp(def.pattern));
    }
    return [key, z.strictObject(shape)];
  }),
);

// The line shown while a tool runs ("Reading the error log...").
export function toolLabel(name, input = {}) {
  switch (name) {
    case 'list_servers': return 'Listing servers';
    case 'get_server': return 'Checking the server';
    case 'find': return `Looking for "${String(input.query ?? '').slice(0, 60)}"`;
    case 'get_website': return 'Checking the website';
    case 'get_application': return 'Checking the app';
    case 'get_deployment': return 'Reading the deployment';
    case 'read_website_log': return `Reading the website ${input.log === 'access' ? 'access' : 'error'} log`;
    case 'read_application_log': return `Reading the app ${input.log === 'output' ? 'output' : 'error'} log`;
    case 'check_service': return `Checking ${String(input.service ?? 'the service').slice(0, 60)}`;
    case 'read_service_log': return `Reading the ${String(input.service ?? 'service').slice(0, 60)} log`;
    case 'read_system_log': return `Reading the ${input.source ?? 'system'} log`;
    case 'list_processes': return 'Listing processes';
    case 'list_listening_ports': return 'Checking listening ports';
    case 'list_alerts': return 'Checking alerts';
    case 'list_recent_jobs': return 'Checking recent jobs';
    case 'get_job': return 'Reading a job';
    case 'list_databases': return 'Listing databases';
    case 'propose_action': return 'Proposing a change';
    default: return 'Working';
  }
}

// Runs the tools of one turn. `propose(kind, params, reason)` stores a
// proposal and returns it.
export function createToolRunner({ services, db, actor, propose }) {
  let proposals = 0;

  async function waitForJob(jobId) {
    const deadline = Date.now() + JOB_WAIT_MS;
    for (;;) {
      const job = await db('jobs').where({ id: jobId }).first('status');
      if (!job || FINAL_JOB_STATUSES.includes(job.status)) return services.jobs.get(actor, jobId);
      if (Date.now() >= deadline) {
        throw new AppError(504, 'AGENT_SLOW', 'The server agent did not answer within 60 seconds. The server may be offline or busy; the job is still in the job list.');
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
  }

  // Queues a read on a server and waits for its result. A second identical
  // read while one runs waits for the first.
  async function serverRead(create) {
    let job;
    try {
      job = await create();
    } catch (err) {
      if (err.code === 'DUPLICATE_OPERATION' && err.details?.jobId) job = { id: err.details.jobId };
      else throw err;
    }
    const done = await waitForJob(job.id);
    if (done.status !== 'succeeded') {
      throw new AppError(502, done.error?.code ?? 'OPERATION_FAILED', done.error?.message ?? `The operation ended as ${done.status}`);
    }
    return done.output;
  }

  const jobRead = (serverId, type, params) => serverRead(() => services.jobs.create(actor, { serverId, type, params }));

  const page = (extra = {}) => ({ page: 1, pageSize: 50, sort: 'createdAt', order: 'desc', ...extra });

  const handlers = {
    async list_servers({ search }) {
      const { items, pagination } = await services.servers.list(actor, page({ sort: 'name', order: 'asc', search }));
      return { total: pagination.total, servers: items.map((s) => pick(s, ['id', 'name', 'status', 'isLocal', 'hostname', 'publicIp', 'agentVersion', 'lastSeenAt'], { os: `${s.os?.name ?? ''} ${s.os?.version ?? ''}`.trim() })) };
    },
    async get_server({ serverId }) {
      const s = await services.servers.get(actor, serverId);
      const m = s.latestMetrics;
      const alerts = await optional(() => services.alerts.listEvents(actor, page({ status: 'open', serverId, sort: 'startedAt' })));
      return {
        ...pick(s, ['id', 'name', 'status', 'isLocal', 'hostname', 'publicIp', 'cpuCores', 'agentVersion', 'lastSeenAt', 'timezone', 'webStack']),
        os: s.os,
        uptimeHours: s.uptimeSeconds ? Math.round(s.uptimeSeconds / 360) / 10 : null,
        now: m
          ? {
              at: m.collectedAt,
              cpuPercent: m.cpuPercent,
              load: m.load,
              memoryPercent: percent(m.memoryUsedBytes, m.memoryTotalBytes),
              swapPercent: percent(m.swapUsedBytes, m.swapTotalBytes),
              diskPercent: percent(m.diskUsedBytes, m.diskTotalBytes),
              processCount: m.processCount,
            }
          : null,
        services: s.services,
        filesystems: s.filesystems,
        agentUpdateAvailable: s.agentUpdate ? s.agentUpdate.latestVersion : null,
        openAlerts: alerts.ok ? alerts.value.items.map(alertSummary) : alerts.error,
      };
    },
    async find({ query }) {
      const search = query.replace(/^https?:\/\//, '').split('/')[0];
      const [websites, domains, apps, databases] = await Promise.all([
        optional(() => services.websites.list(actor, page({ search, pageSize: 20, sort: 'name' }))),
        optional(() => services.websites.listDomains(actor, { page: 1, pageSize: 20, sort: 'domain', order: 'asc', search })),
        optional(() => services.applications.list(actor, page({ search, pageSize: 20, sort: 'name' }))),
        optional(() => services.databases.list(actor, { page: 1, pageSize: 20, sort: 'name', order: 'asc', search })),
      ]);
      return {
        websites: websites.ok ? websites.value.items.map((w) => pick(w, ['id', 'name', 'type', 'primaryDomain', 'status', 'serverId', 'serverName'])) : websites.error,
        domains: domains.ok ? domains.value.items.map((d) => pick(d, ['domain', 'website', 'server', 'https', 'dns'])) : domains.error,
        apps: apps.ok ? apps.value.items.map((a) => pick(a, ['id', 'name', 'runtime', 'status', 'port', 'primaryDomain', 'serverId', 'serverName'], { process: a.process?.state ?? null })) : apps.error,
        databases: databases.ok ? databases.value.items.map((d) => pick(d, ['id', 'name', 'status', 'serverId', 'serverName'])) : databases.error,
      };
    },
    async get_website({ websiteId }) {
      const w = await services.websites.get(actor, websiteId);
      return {
        ...pick(w, ['id', 'name', 'type', 'serverId', 'serverName', 'serverStatus', 'primaryDomain', 'documentRoot', 'phpVersion', 'proxyPort', 'isEnabled', 'forceHttps', 'status', 'pendingAction', 'provisioned', 'health', 'lastError', 'uncoveredDomains']),
        domains: w.domains.map((d) => d.domain),
        ssl: w.ssl ? pick(w.ssl, ['status', 'state', 'issuer', 'notAfter', 'daysLeft', 'domains', 'lastError', 'isStaging']) : null,
        application: w.application ? pick(w.application, ['id', 'name', 'status', 'port']) : null,
        recentJobs: w.recentJobs.map(jobSummary),
      };
    },
    async get_application({ applicationId }) {
      const a = await services.applications.get(actor, applicationId);
      return {
        ...pick(a, ['id', 'name', 'runtime', 'serverId', 'serverName', 'serverStatus', 'repositoryUrl', 'branch', 'installCommand', 'buildCommand', 'startCommand', 'port', 'status', 'pendingAction', 'provisioned', 'current', 'configPending', 'process', 'websiteId', 'primaryDomain', 'lastError', 'cpuLimitPercent', 'memoryLimitMb', 'instances', 'healthCheckSeconds']),
        environmentVariableNames: a.envKeys ?? undefined,
        deployments: a.deployments.map(deploymentSummary),
        recentJobs: a.recentJobs.map(jobSummary),
      };
    },
    async get_deployment({ deploymentId }) {
      const d = await services.applications.getDeployment(actor, deploymentId);
      const log = d.jobId ? await optional(() => services.jobs.get(actor, d.jobId)) : null;
      return { ...deploymentSummary(d), log: log?.ok ? tailLines(log.value.logs.map((l) => l.message), 120) : (log?.error ?? null) };
    },
    async read_website_log({ websiteId, log, lines: n }) {
      const out = await serverRead(() => services.websites.logs(actor, websiteId, { log, lines: n ?? 150 }));
      return logText(out);
    },
    async read_application_log({ applicationId, log, lines: n }) {
      const out = await serverRead(() => services.applications.logs(actor, applicationId, { log, lines: n ?? 150 }));
      return logText(out);
    },
    async check_service({ serverId, service: name }) {
      return (await jobRead(serverId, 'SERVICE_STATUS', { service: name })).service;
    },
    async read_service_log({ serverId, service: name, lines: n }) {
      return logText(await jobRead(serverId, 'SERVICE_LOGS', { service: name, lines: n ?? 150 }));
    },
    async read_system_log({ serverId, lines: n, ...rest }) {
      return logText(await jobRead(serverId, 'SYSTEM_LOGS', { ...rest, lines: n ?? 150 }));
    },
    async list_processes({ serverId, sortBy }) {
      return jobRead(serverId, 'PROCESS_LIST', { limit: 25, sortBy: sortBy ?? 'cpu' });
    },
    async list_listening_ports({ serverId }) {
      return jobRead(serverId, 'LISTENING_PORTS', {});
    },
    async list_alerts({ serverId }) {
      const { items } = await services.alerts.listEvents(actor, page({ status: 'open', serverId, sort: 'startedAt' }));
      return { openAlerts: items.map(alertSummary) };
    },
    async list_recent_jobs({ serverId, status }) {
      const { items } = await services.jobs.list(actor, { page: 1, pageSize: 15, sort: 'createdAt', order: 'desc', serverId, status });
      return { jobs: items.map(jobSummary) };
    },
    async get_job({ jobId }) {
      const job = await services.jobs.get(actor, jobId);
      return { ...jobSummary(job), params: job.params, output: job.output, log: tailLines(job.logs.map((l) => `[${l.stream}] ${l.message}`), 120) };
    },
    async list_databases({ serverId }) {
      const { items } = await services.databases.list(actor, { page: 1, pageSize: 50, sort: 'name', order: 'asc', serverId });
      return { databases: items.map((d) => pick(d, ['id', 'name', 'status', 'serverId', 'serverName', 'sizeBytes', 'application', 'lastError'])) };
    },
    async propose_action({ action, params, reason }) {
      if (proposals >= MAX_PROPOSALS_PER_TURN) {
        throw new AppError(429, 'TOO_MANY_PROPOSALS', `Propose at most ${MAX_PROPOSALS_PER_TURN} changes per answer`);
      }
      const checked = ACTION_PARAMS[action].safeParse(params);
      if (!checked.success) {
        throw new AppError(422, 'INVALID_ACTION_PARAMS', checked.error.issues.map((i) => `${i.path.join('.') || 'params'}: ${i.message}`).join('; '));
      }
      const proposal = await propose(action, checked.data, reason);
      proposals += 1;
      return {
        proposed: true,
        proposalId: proposal.id,
        target: proposal.targetLabel,
        note: 'The person now sees this change with Approve and Cancel buttons. It has NOT run. Do not say it has been done.',
      };
    },
  };

  // Returns { content, isError } for the model; never throws.
  async function run(name, rawInput) {
    if (!TOOLS_BY_NAME[name]) return { content: `Unknown tool "${name}"`, isError: true };
    const parsed = INPUTS[name].safeParse(rawInput ?? {});
    if (!parsed.success) {
      return { content: `Invalid input: ${parsed.error.issues.map((i) => `${i.path.join('.') || 'input'}: ${i.message}`).join('; ')}`, isError: true };
    }
    try {
      const result = await handlers[name](parsed.data);
      return { content: clip(typeof result === 'string' ? result : JSON.stringify(result)), isError: false };
    } catch (err) {
      return { content: errorText(err), isError: true };
    }
  }

  return { run };
}

// The model hears why a tool failed in the panel's own words.
function errorText(err) {
  if (err instanceof AppError || err?.code) {
    if (err.code === 'FORBIDDEN') return 'Permission denied: the person asking does not have the permission this needs. Tell them which part of the panel they cannot reach and that an admin can give them access.';
    const details = Array.isArray(err.details) ? ` (${err.details.map((d) => `${d.field}: ${d.message}`).join('; ')})` : '';
    return `Error ${err.code}: ${err.message}${details}`;
  }
  return `Error: ${err?.message ?? 'unknown error'}`;
}

async function optional(fn) {
  try {
    return { ok: true, value: await fn() };
  } catch (err) {
    return { ok: false, error: errorText(err) };
  }
}

function pick(obj, keys, extra = {}) {
  const out = {};
  for (const k of keys) if (obj[k] !== undefined) out[k] = obj[k];
  return { ...out, ...extra };
}

function percent(used, total) {
  return used !== null && total ? Math.round((used / total) * 1000) / 10 : null;
}

function alertSummary(e) {
  return pick(e, ['id', 'ruleName', 'metric', 'subject', 'status', 'severity', 'message', 'serverId', 'serverName', 'value', 'threshold', 'startedAt']);
}

function jobSummary(j) {
  return pick(j, ['id', 'type', 'status', 'serverName', 'createdAt', 'finishedAt', 'error'], { resource: j.resource ?? undefined });
}

function deploymentSummary(d) {
  return pick(d, ['id', 'applicationId', 'applicationName', 'kind', 'trigger', 'status', 'branch', 'commit', 'failedStage', 'error', 'releaseId', 'jobId', 'createdAt', 'finishedAt']);
}

// Log output as plain text: a header line, then the lines (newest last).
function logText(output) {
  const header = Object.entries(output ?? {})
    .filter(([k, v]) => k !== 'lines' && v !== undefined && typeof v !== 'object')
    .map(([k, v]) => `${k}=${v}`)
    .join(' ');
  const body = (output?.lines ?? []).map((l) => (typeof l === 'string' ? l : JSON.stringify(l)));
  return `${header}\n${body.length ? tailLines(body, 400).join('\n') : '(no lines)'}`;
}

function tailLines(list, n) {
  return list.slice(-n);
}

// Keeps the end of long results (the newest log lines matter most).
function clip(text) {
  if (text.length <= MAX_RESULT_CHARS) return text;
  return `[earlier output cut, ${text.length - MAX_RESULT_CHARS} characters left out]\n${text.slice(-MAX_RESULT_CHARS)}`;
}
