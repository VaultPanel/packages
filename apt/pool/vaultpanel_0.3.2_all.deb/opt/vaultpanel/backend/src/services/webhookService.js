import { randomUUID } from 'node:crypto';
import { lookup } from 'node:dns/promises';
import http from 'node:http';
import https from 'node:https';
import { isIP } from 'node:net';
import { PERMISSIONS, WEBHOOK_EVENTS, WEBHOOK_MAX_ATTEMPTS } from '@vaultpanel/shared';
import { toPublicDelivery, toPublicWebhook } from '../models/automationModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey, hmacHex, newToken } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { addSeconds } from '../utils/time.js';

// Webhooks tell other systems (a chat channel, an incident tool, a script)
// when something happens in the panel: a backup or cron job failed, a
// deployment went live, an alert fired, a server went offline.
//
// emit() only stores one delivery per subscribed webhook; the worker sends
// them (deliver(), every maintenance run) and retries failures with backoff.
// JSON deliveries are signed with the webhook's secret:
//   X-VaultPanel-Signature: sha256=HMAC_SHA256(secret, "<timestamp>.<body>")
//
// Requests only go to public addresses unless VAULTPANEL_WEBHOOK_ALLOW_PRIVATE
// is on; loopback, link-local (cloud metadata) and multicast are always
// refused. The address is checked after DNS resolution and the request is
// made to that same address, so a name cannot resolve differently later.
//
// A plugin (phase 10, part 3) receives its events through a webhook it owns
// (webhooks.plugin_id). Those are managed through the plugin service, not
// from the Webhooks page, and may reach loopback when
// VAULTPANEL_PLUGIN_ALLOW_LOCAL is on (a plugin running on the panel's server).

const RETRY_SECONDS = [60, 5 * 60, 30 * 60];
const REQUEST_TIMEOUT_MS = 10_000;
const RESPONSE_SNIPPET_BYTES = 2048;
const DELIVERIES_KEPT_DAYS = 30;

export function createWebhookService({ db, config, logger, audit, authorize, allowLoopback = false }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'webhooks'));
  // allowLoopback is for tests only; there is no setting for it.
  const guard = { allowPrivate: config.webhookAllowPrivate, allowLoopback };
  const pluginGuard = { allowPrivate: config.webhookAllowPrivate || config.pluginAllowLocal, allowLoopback: allowLoopback || config.pluginAllowLocal };
  const guardFor = (hook) => (hook.plugin_id ? pluginGuard : guard);

  // ---- Events -----------------------------------------------------------------

  // Others that hear about every event (panel email alerts).
  const listeners = [];
  function onEvent(listener) {
    listeners.push(listener);
  }

  // Queues the event for every enabled webhook subscribed to it.
  async function emit(event, data) {
    if (!WEBHOOK_EVENTS[event]) throw new Error(`Unknown webhook event ${event}`);
    for (const listener of listeners) {
      try {
        await listener(event, data);
      } catch (err) {
        logger.error({ err, event }, 'event listener failed');
      }
    }
    const hooks = await db('webhooks').where({ enabled: true }).select('id', 'events');
    const targets = hooks.filter((h) => fromJson(h.events, []).includes(event));
    if (!targets.length) return 0;
    const now = new Date();
    const payload = toJson({ event, occurredAt: now.toISOString(), data });
    await db('webhook_deliveries').insert(
      targets.map((h) => ({ id: randomUUID(), webhook_id: h.id, event, payload, status: 'pending', attempts: 0, next_attempt_at: now, created_at: now, updated_at: now })),
    );
    return targets.length;
  }

  // Audit entries that are also webhook events.
  async function fromAudit({ action, target, metadata }) {
    const server = target?.type === 'server' ? { id: target.id, name: target.label ?? null } : null;
    if (action === 'alert.fire') {
      await emit('alert.firing', { server, rule: metadata?.rule ?? null, severity: metadata?.severity ?? null, subject: metadata?.subject ?? null, message: metadata?.message ?? null });
    } else if (action === 'alert.resolve') {
      await emit('alert.resolved', { server, rule: metadata?.rule ?? null, subject: metadata?.subject ?? null });
    } else if (action === 'server.offline') {
      await emit('server.offline', { server, lastSeenAt: metadata?.lastSeenAt ? new Date(metadata.lastSeenAt).toISOString() : null });
    } else if (action === 'server.online' && metadata?.previousStatus === 'offline') {
      await emit('server.online', { server });
    }
  }

  // Deployments and rollbacks of apps.
  async function fromJob(job, { status, output, error }) {
    if (job.resource_type !== 'application' || !['DEPLOY_GIT', 'ROLLBACK_APPLICATION'].includes(job.type)) return;
    const app = await db('applications as a').join('servers as s', 's.id', 'a.server_id').where('a.id', job.resource_id).first('a.id', 'a.name', 's.id as server_id', 's.name as server_name');
    if (!app) return;
    const ok = status === 'succeeded';
    await emit(ok ? 'deployment.succeeded' : 'deployment.failed', {
      application: { id: app.id, name: app.name },
      kind: job.type === 'DEPLOY_GIT' ? 'deploy' : 'rollback',
      commit: output?.commit ?? null,
      releaseId: output?.releaseId ?? null,
      server: { id: app.server_id, name: app.server_name },
      ...(ok ? {} : { error: { code: error?.code ?? null, message: error?.message ?? null } }),
    });
  }

  // ---- Managing ------------------------------------------------------------------

  async function loadRow(id) {
    const row = await db('webhooks').where({ id }).first();
    if (!row) throw notFound('Webhook not found');
    if (row.plugin_id) throw new AppError(409, 'PLUGIN_WEBHOOK', "This webhook carries a plugin's events. Manage it on the plugin's page under Plugins.");
    return row;
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const { rows, pagination } = await paginate(db('webhooks').whereNull('plugin_id'), query, { createdAt: 'created_at', name: 'name' });
    return { items: rows.map(toPublicWebhook), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const row = await loadRow(id);
    // Managers may see the full URL to correct it.
    return { ...toPublicWebhook(row), url: box.open(row.url_encrypted) };
  }

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const url = checkUrl(input.url);
    const secret = `whsec_${newToken(24)}`;
    const id = randomUUID();
    const now = new Date();
    await db('webhooks').insert({
      id,
      name: input.name,
      url_encrypted: box.seal(url.href),
      url_host: `${url.protocol}//${url.host}`,
      format: input.format,
      events: toJson(input.events),
      secret_encrypted: box.seal(secret),
      enabled: input.enabled,
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    await audit.record({ actor, action: 'webhook.create', target: { type: 'webhook', id, label: input.name }, metadata: { host: url.host, format: input.format, events: input.events } });
    // The secret is shown once; it can be replaced later.
    return { webhook: toPublicWebhook(await loadRow(id)), secret };
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const row = await loadRow(id);
    const values = { updated_at: new Date() };
    let secret;
    if (changes.name !== undefined) values.name = changes.name;
    if (changes.format !== undefined) values.format = changes.format;
    if (changes.events !== undefined) values.events = toJson(changes.events);
    if (changes.enabled !== undefined) values.enabled = changes.enabled;
    if (changes.url !== undefined) {
      const url = checkUrl(changes.url);
      values.url_encrypted = box.seal(url.href);
      values.url_host = `${url.protocol}//${url.host}`;
    }
    if (changes.rotateSecret) {
      secret = `whsec_${newToken(24)}`;
      values.secret_encrypted = box.seal(secret);
    }
    await db('webhooks').where({ id }).update(values);
    await audit.record({
      actor,
      action: 'webhook.update',
      target: { type: 'webhook', id, label: values.name ?? row.name },
      metadata: { changed: Object.keys(changes).filter((k) => changes[k] !== undefined && k !== 'rotateSecret'), rotatedSecret: Boolean(changes.rotateSecret) },
    });
    return { webhook: toPublicWebhook(await loadRow(id)), ...(secret ? { secret } : {}) };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const row = await loadRow(id);
    await db('webhooks').where({ id }).delete();
    await audit.record({ actor, action: 'webhook.delete', target: { type: 'webhook', id, label: row.name } });
  }

  // Sends a test event now and returns the outcome.
  async function test(actor, id) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const row = await loadRow(id);
    const now = new Date();
    const deliveryId = randomUUID();
    const payload = { event: 'webhook.test', occurredAt: now.toISOString(), data: { webhook: { id: row.id, name: row.name }, message: 'This is a test from VaultPanel.' } };
    await db('webhook_deliveries').insert({ id: deliveryId, webhook_id: id, event: 'webhook.test', payload: toJson(payload), status: 'pending', attempts: 0, next_attempt_at: null, created_at: now, updated_at: now });
    const delivery = await db('webhook_deliveries').where({ id: deliveryId }).first();
    await attempt(row, delivery, now, { retry: false });
    await audit.record({ actor, action: 'webhook.test', target: { type: 'webhook', id, label: row.name } });
    return { delivery: toPublicDelivery(await db('webhook_deliveries').where({ id: deliveryId }).first()) };
  }

  async function deliveries(actor, id, query) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    await loadRow(id);
    const q = db('webhook_deliveries').where({ webhook_id: id });
    if (query.status) q.where({ status: query.status });
    const { rows, pagination } = await paginate(q, query, { createdAt: 'created_at' });
    return { items: rows.map(toPublicDelivery), pagination };
  }

  async function redeliver(actor, webhookId, deliveryId) {
    await authorize(actor, PERMISSIONS.WEBHOOKS_MANAGE);
    const row = await loadRow(webhookId);
    const delivery = await db('webhook_deliveries').where({ id: deliveryId, webhook_id: webhookId }).first();
    if (!delivery) throw notFound('Delivery not found');
    if (delivery.status === 'pending') throw new AppError(409, 'DELIVERY_PENDING', 'This delivery is still being tried');
    await attempt(row, delivery, new Date(), { retry: false });
    await audit.record({ actor, action: 'webhook.redeliver', target: { type: 'webhook', id: webhookId, label: row.name }, metadata: { deliveryId, event: delivery.event } });
    return { delivery: toPublicDelivery(await db('webhook_deliveries').where({ id: deliveryId }).first()) };
  }

  // ---- Delivering -----------------------------------------------------------------

  // Sends the deliveries that are due. Run by the worker.
  async function deliver(now = new Date()) {
    const due = await db('webhook_deliveries').where({ status: 'pending' }).where('next_attempt_at', '<=', now).orderBy('next_attempt_at').limit(25);
    let sent = 0;
    for (const delivery of due) {
      // Claim it for a while, so a second worker skips it.
      const claimed = await db('webhook_deliveries')
        .where({ id: delivery.id, status: 'pending', attempts: delivery.attempts })
        .update({ attempts: delivery.attempts + 1, next_attempt_at: addSeconds(now, 120), updated_at: now });
      if (!claimed) continue;
      const hook = await db('webhooks').where({ id: delivery.webhook_id }).first();
      if (!hook) continue;
      if (!hook.enabled) {
        await db('webhook_deliveries').where({ id: delivery.id }).update({ status: 'failed', error: 'The webhook was turned off', next_attempt_at: null, updated_at: now });
        continue;
      }
      await attempt(hook, { ...delivery, attempts: delivery.attempts + 1 }, now, { retry: true, claimed: true });
      sent += 1;
    }
    return sent;
  }

  async function attempt(hook, delivery, now, { retry, claimed = false }) {
    const attempts = claimed ? delivery.attempts : delivery.attempts + 1;
    const payload = fromJson(delivery.payload, {});
    const started = Date.now();
    let result;
    try {
      const url = new URL(box.open(hook.url_encrypted));
      const body = JSON.stringify(render(hook.format, { ...payload, id: delivery.id }));
      const timestamp = Math.floor(now.getTime() / 1000);
      const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'VaultPanel-Webhook/1',
        'X-VaultPanel-Event': delivery.event,
        'X-VaultPanel-Delivery': delivery.id,
        'X-VaultPanel-Timestamp': String(timestamp),
      };
      if (hook.format === 'json') headers['X-VaultPanel-Signature'] = `sha256=${hmacHex(box.open(hook.secret_encrypted), `${timestamp}.${body}`)}`;
      if (hook.plugin_id) headers['X-VaultPanel-Plugin'] = hook.name;
      result = await send(url, body, headers, guardFor(hook));
    } catch (err) {
      result = { ok: false, status: null, error: err.message };
    }
    const durationMs = Date.now() - started;
    const finished = new Date();
    const values = { attempts, response_status: result.status, duration_ms: durationMs, updated_at: finished };
    if (result.ok) Object.assign(values, { status: 'succeeded', error: null, delivered_at: finished, next_attempt_at: null });
    else if (retry && attempts < WEBHOOK_MAX_ATTEMPTS && result.retryable !== false) {
      Object.assign(values, { status: 'pending', error: result.error, next_attempt_at: addSeconds(finished, RETRY_SECONDS[attempts - 1] ?? RETRY_SECONDS.at(-1)) });
    } else Object.assign(values, { status: 'failed', error: result.error, next_attempt_at: null });
    await db('webhook_deliveries').where({ id: delivery.id }).update(values);
    await db('webhooks').where({ id: hook.id }).update({ last_delivery_at: finished, last_delivery_status: values.status });
    if (!result.ok) logger.info({ webhookId: hook.id, deliveryId: delivery.id, attempts, error: result.error }, 'webhook delivery failed');
  }

  async function prune(now = new Date()) {
    return db('webhook_deliveries').whereNot('status', 'pending').where('created_at', '<', addSeconds(now, -DELIVERIES_KEPT_DAYS * 86_400)).delete();
  }

  // ---- Plugins' webhooks ------------------------------------------------------
  // Called by the plugin service, which has already checked the permission.

  // Creates, changes or removes the webhook that carries a plugin's events.
  // Without a URL or events the plugin receives nothing and has no webhook.
  async function setPluginHook(pluginId, { slug, url, events, secret, enabled }) {
    const row = await db('webhooks').where({ plugin_id: pluginId }).first();
    if (!url || !events?.length) {
      if (row) await db('webhooks').where({ id: row.id }).delete();
      return null;
    }
    const parsed = checkUrl(url, 'webhookUrl');
    const now = new Date();
    const values = {
      name: slug,
      url_encrypted: box.seal(parsed.href),
      url_host: `${parsed.protocol}//${parsed.host}`,
      format: 'json',
      events: toJson(events),
      secret_encrypted: box.seal(secret),
      enabled,
      updated_at: now,
    };
    if (row) {
      await db('webhooks').where({ id: row.id }).update(values);
      return row.id;
    }
    const id = randomUUID();
    await db('webhooks').insert({ id, plugin_id: pluginId, created_at: now, ...values });
    return id;
  }

  async function pluginHook(pluginId) {
    return db('webhooks').where({ plugin_id: pluginId }).first();
  }

  async function pluginDeliveries(pluginId, query) {
    const hook = await pluginHook(pluginId);
    if (!hook) return { items: [], pagination: { page: 1, pageSize: query.pageSize ?? 25, total: 0, totalPages: 1 } };
    const q = db('webhook_deliveries').where({ webhook_id: hook.id });
    if (query.status) q.where({ status: query.status });
    const { rows, pagination } = await paginate(q, query, { createdAt: 'created_at' });
    return { items: rows.map(toPublicDelivery), pagination };
  }

  // Sends a "webhook.test" event to the plugin now.
  async function testPluginHook(pluginId, data) {
    const hook = await pluginHook(pluginId);
    if (!hook) throw new AppError(409, 'NO_EVENTS', 'This plugin does not receive events: its manifest has no webhookUrl or no events');
    const now = new Date();
    const deliveryId = randomUUID();
    const payload = { event: 'webhook.test', occurredAt: now.toISOString(), data: { ...data, message: 'This is a test from VaultPanel.' } };
    await db('webhook_deliveries').insert({ id: deliveryId, webhook_id: hook.id, event: 'webhook.test', payload: toJson(payload), status: 'pending', attempts: 0, next_attempt_at: null, created_at: now, updated_at: now });
    await attempt(hook, await db('webhook_deliveries').where({ id: deliveryId }).first(), now, { retry: false });
    return toPublicDelivery(await db('webhook_deliveries').where({ id: deliveryId }).first());
  }

  async function redeliverPlugin(pluginId, deliveryId) {
    const hook = await pluginHook(pluginId);
    const delivery = hook && (await db('webhook_deliveries').where({ id: deliveryId, webhook_id: hook.id }).first());
    if (!delivery) throw notFound('Delivery not found');
    if (delivery.status === 'pending') throw new AppError(409, 'DELIVERY_PENDING', 'This delivery is still being tried');
    await attempt(hook, delivery, new Date(), { retry: false });
    return toPublicDelivery(await db('webhook_deliveries').where({ id: deliveryId }).first());
  }

  // Fetches a plugin manifest, with the same address rules as a plugin's events.
  function fetchManifest(url) {
    return getJson(checkUrl(url, 'manifestUrl'), pluginGuard);
  }

  // A plugin directory (docs/plugins.md#plugin-directories), with the same
  // address rules as plugins.
  function fetchDirectory(url) {
    return getJson(checkUrl(url, 'url'), pluginGuard, DIRECTORY_FETCH);
  }

  return {
    emit,
    onEvent,
    fromAudit,
    fromJob,
    list,
    get,
    create,
    update,
    remove,
    test,
    deliveries,
    redeliver,
    deliver,
    prune,
    setPluginHook,
    pluginHook,
    pluginDeliveries,
    testPluginHook,
    redeliverPlugin,
    fetchManifest,
    fetchDirectory,
  };
}

// ---- Helpers ----------------------------------------------------------------------

export function checkUrl(value, field = 'url') {
  let url;
  try {
    url = new URL(value);
  } catch {
    throw validationError([{ field, message: 'Enter a full URL, such as https://hooks.example.com/…' }]);
  }
  if (!['http:', 'https:'].includes(url.protocol)) throw validationError([{ field, message: 'Use an http or https URL' }]);
  if (url.username || url.password) throw validationError([{ field, message: 'Put credentials in the path or a token, not user:password@' }]);
  url.hash = '';
  return url;
}

// Whether an address may receive webhooks.
export function addressAllowed(address, { allowPrivate, allowLoopback = false }) {
  const family = isIP(address);
  if (!family) return false;
  if (allowLoopback && (address === '::1' || address.startsWith('127.'))) return true;
  if (family === 6) {
    const lower = address.toLowerCase();
    const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return addressAllowed(mapped[1], { allowPrivate, allowLoopback });
    if (lower === '::' || lower === '::1') return false;
    if (/^fe[89ab]/.test(lower)) return false; // link-local
    if (/^ff/.test(lower)) return false; // multicast
    if (/^f[cd]/.test(lower)) return allowPrivate; // unique local
    return true;
  }
  const [a, b] = address.split('.').map(Number);
  if (a === 0 || a === 127) return false; // this network, loopback
  if (a === 169 && b === 254) return false; // link-local, cloud metadata
  if (a >= 224) return false; // multicast and reserved
  if (a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return allowPrivate;
  return true;
}

async function resolveAllowed(hostname, guard) {
  const host = hostname.replace(/^\[|\]$/g, '');
  const addresses = isIP(host) ? [{ address: host, family: isIP(host) }] : await lookup(host, { all: true });
  if (!addresses.length) throw new Error(`${host} did not resolve`);
  const blocked = addresses.find((a) => !addressAllowed(a.address, guard));
  if (blocked) {
    const err = new Error(`${host} resolves to ${blocked.address}, which webhooks may not reach${guard.allowPrivate ? '' : ' (private addresses need VAULTPANEL_WEBHOOK_ALLOW_PRIVATE=true)'}`);
    err.retryable = false;
    throw err;
  }
  return addresses[0];
}

const MANIFEST_FETCH = { maxBytes: 64 * 1024, code: 'MANIFEST_UNREACHABLE', what: 'manifest' };
const DIRECTORY_FETCH = { maxBytes: 1024 * 1024, code: 'DIRECTORY_UNREACHABLE', what: 'directory' };

// GETs a small JSON document (a plugin manifest or directory) from an allowed address.
async function getJson(url, guard, { maxBytes, code, what } = MANIFEST_FETCH) {
  let target;
  try {
    target = await resolveAllowed(url.hostname, guard);
  } catch (err) {
    throw new AppError(422, code, err.message);
  }
  const client = url.protocol === 'https:' ? https : http;
  return new Promise((resolve, reject) => {
    const fail = (message) => reject(new AppError(422, code, message));
    const req = client.request(
      url,
      {
        method: 'GET',
        headers: { Accept: 'application/json', 'User-Agent': 'VaultPanel-Plugins/1' },
        timeout: REQUEST_TIMEOUT_MS,
        lookup: (_host, options, callback) => {
          if (options?.all) callback(null, [{ address: target.address, family: target.family }]);
          else callback(null, target.address, target.family);
        },
      },
      (res) => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          return fail(`The ${what} URL answered HTTP ${res.statusCode}`);
        }
        const chunks = [];
        let size = 0;
        res.on('data', (chunk) => {
          size += chunk.length;
          if (size > maxBytes) {
            req.destroy();
            return fail(`The ${what} is larger than ${maxBytes / 1024} KB`);
          }
          chunks.push(chunk);
        });
        res.on('end', () => {
          try {
            resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
          } catch {
            fail(`The ${what} URL did not return valid JSON`);
          }
        });
        res.on('error', (err) => fail(err.message));
      },
    );
    req.on('timeout', () => req.destroy(new Error(`No response within ${REQUEST_TIMEOUT_MS / 1000} seconds`)));
    req.on('error', (err) => fail(`Could not fetch the ${what}: ${err.message}`));
    req.end();
  });
}

async function send(url, body, headers, guard) {
  let target;
  try {
    target = await resolveAllowed(url.hostname, guard);
  } catch (err) {
    return { ok: false, status: null, error: err.message, retryable: err.retryable };
  }
  const client = url.protocol === 'https:' ? https : http;
  return new Promise((resolve) => {
    const req = client.request(
      url,
      {
        method: 'POST',
        headers: { ...headers, 'Content-Length': Buffer.byteLength(body) },
        timeout: REQUEST_TIMEOUT_MS,
        // Connect to the address that was checked.
        lookup: (_host, options, callback) => {
          if (options?.all) callback(null, [{ address: target.address, family: target.family }]);
          else callback(null, target.address, target.family);
        },
      },
      (res) => {
        let size = 0;
        let snippet = '';
        res.on('data', (chunk) => {
          if (size < RESPONSE_SNIPPET_BYTES) snippet += chunk.toString('utf8').slice(0, RESPONSE_SNIPPET_BYTES - size);
          size += chunk.length;
        });
        res.on('end', () => {
          const ok = res.statusCode >= 200 && res.statusCode < 300;
          resolve({ ok, status: res.statusCode, error: ok ? null : `HTTP ${res.statusCode}${snippet ? `: ${snippet.trim().slice(0, 300)}` : ''}`, retryable: res.statusCode >= 500 || res.statusCode === 429 || res.statusCode === 408 });
        });
        res.on('error', (err) => resolve({ ok: false, status: res.statusCode, error: err.message }));
      },
    );
    req.on('timeout', () => req.destroy(new Error(`No response within ${REQUEST_TIMEOUT_MS / 1000} seconds`)));
    req.on('error', (err) => resolve({ ok: false, status: null, error: err.message }));
    req.end(body);
  });
}

// ---- Messages ---------------------------------------------------------------------

const serverName = (d) => d.server?.name ?? 'a server';
const sslNames = (d) => (d.domains?.length ? d.domains.join(', ') : (d.website?.name ?? 'a website'));

export function summarize(event, data) {
  switch (event) {
    case 'backup.succeeded':
      return `Backup of ${data.resource?.type} ${data.resource?.name} on ${serverName(data)} finished`;
    case 'backup.failed':
      return `Backup of ${data.resource?.type} ${data.resource?.name} on ${serverName(data)} failed: ${data.error?.message ?? 'unknown error'}`;
    case 'restore.succeeded':
      return `Restore of ${data.resource?.type} ${data.resource?.name} on ${serverName(data)} finished`;
    case 'restore.failed':
      return `Restore of ${data.resource?.type} ${data.resource?.name} on ${serverName(data)} failed: ${data.error?.message ?? 'unknown error'}`;
    case 'cron.failed':
      return `Cron job "${data.cronJob?.name}" (${data.cronJob?.user}) on ${serverName(data)} ${data.run?.status === 'timed_out' ? 'timed out' : `failed with exit code ${data.run?.exitCode}`}`;
    case 'deployment.succeeded':
      return `${data.kind === 'rollback' ? 'Rollback' : 'Deployment'} of ${data.application?.name} on ${serverName(data)} is live${data.commit ? ` (${String(data.commit).slice(0, 7)})` : ''}`;
    case 'deployment.failed':
      return `${data.kind === 'rollback' ? 'Rollback' : 'Deployment'} of ${data.application?.name} on ${serverName(data)} failed: ${data.error?.message ?? 'unknown error'}`;
    case 'alert.firing':
      return `Alert ${data.rule ?? ''} on ${serverName(data)}: ${data.message ?? 'firing'}`;
    case 'alert.resolved':
      return `Alert ${data.rule ?? ''} on ${serverName(data)} resolved`;
    case 'server.offline':
      return `Server ${serverName(data)} went offline`;
    case 'server.online':
      return `Server ${serverName(data)} is back online`;
    case 'ssl.expiring':
      return `SSL certificate for ${sslNames(data)} on ${serverName(data)} expires in ${data.daysLeft} day${data.daysLeft === 1 ? '' : 's'} and has not renewed`;
    case 'ssl.expired':
      return `SSL certificate for ${sslNames(data)} on ${serverName(data)} expired`;
    case 'ssl.renew_failed':
      return `Automatic renewal of the SSL certificate for ${sslNames(data)} on ${serverName(data)} failed: ${data.error?.message ?? 'unknown error'}`;
    case 'webhook.test':
      return data.message ?? 'Test from VaultPanel';
    default:
      return event;
  }
}

export function render(format, payload) {
  const text = `VaultPanel: ${summarize(payload.event, payload.data ?? {})}`;
  if (format === 'slack') return { text };
  if (format === 'discord') return { content: text.slice(0, 2000), allowed_mentions: { parse: [] } };
  return payload;
}
