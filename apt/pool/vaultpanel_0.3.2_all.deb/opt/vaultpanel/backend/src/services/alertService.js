import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { ALERT_EVENT_STATUSES, ALERT_METRICS, ALERT_SEVERITIES, PERMISSIONS, selfChecks } from '@vaultpanel/shared';
import { findServer } from '../models/serverModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';
import { toIso } from '../utils/time.js';
import { checkRule } from '../validators/alertValidators.js';
import { systemActor } from './actor.js';
import { isServiceProblem } from './monitoringService.js';

export const alertEventListQuery = listQuerySchema(['startedAt', 'resolvedAt'], 'startedAt', {
  // "open" is pending and firing together.
  status: z.enum([...ALERT_EVENT_STATUSES, 'open']).optional(),
  serverId: z.uuid().optional(),
  severity: z.enum(ALERT_SEVERITIES).optional(),
});

const OPEN_STATUSES = ['pending', 'firing'];
// Agents send a self-check every few minutes, or say that their root helper
// does not answer; an older report is not judged.
const SELF_CHECK_STALE_MS = 30 * 60_000;
const EVENT_COLUMNS = ['e.*', 's.name as server_name', 'u.email as acknowledged_by_email'];

export function createAlertService({ db, config, logger, audit, authorize, metrics }) {
  const monitor = systemActor('monitor');

  // ---- Rules ------------------------------------------------------------

  async function listRules(actor) {
    await authorize(actor, PERMISSIONS.ALERTS_READ);
    const rows = await db('alert_rules as r')
      .leftJoin('servers as s', 's.id', 'r.server_id')
      .select('r.*', 's.name as server_name')
      .orderBy('r.created_at');
    const open = await db('alert_events')
      .where({ status: 'firing' })
      .whereNotNull('rule_id')
      .select('rule_id')
      .count({ n: '*' })
      .groupBy('rule_id');
    const firing = Object.fromEntries(open.map((r) => [r.rule_id, Number(r.n)]));
    return { items: rows.map((r) => ({ ...toPublicRule(r), firingCount: firing[r.id] ?? 0 })) };
  }

  async function createRule(actor, input) {
    await authorize(actor, PERMISSIONS.ALERTS_MANAGE);
    await requireServerIfSet(input.serverId);
    const id = randomUUID();
    await db('alert_rules').insert({ id, ...ruleColumns(input), created_by: actor.type === 'user' ? actor.id : null });
    const rule = await findRule(id);
    await audit.record({ actor, action: 'alert_rule.create', target: ruleTarget(rule), metadata: publicRuleMeta(rule) });
    return rule;
  }

  async function updateRule(actor, id, changes) {
    await authorize(actor, PERMISSIONS.ALERTS_MANAGE);
    const current = await findRule(id);
    if (!current) throw notFound('Alert rule not found');
    const merged = { ...current, ...changes };
    // A rule switched to a non-metric kind keeps no threshold.
    if (ALERT_METRICS[merged.metric].kind !== 'metric') merged.threshold = null;
    if (ALERT_METRICS[merged.metric].kind !== 'service') merged.serviceName = null;
    const issues = [];
    checkRule(merged, { addIssue: (i) => issues.push({ field: i.path.join('.'), message: i.message }) });
    if (issues.length) throw validationError(issues);
    await requireServerIfSet(merged.serverId);
    await db('alert_rules').where({ id }).update({ ...ruleColumns(merged), updated_at: new Date() });
    // Open alerts raised under the old definition no longer mean the same thing.
    const definitionChanged = ['metric', 'threshold', 'serverId', 'serviceName'].some((k) => k in changes && changes[k] !== current[k]);
    if (definitionChanged || merged.isEnabled === false) await clearOpenEvents({ ruleId: id }, new Date());
    const rule = await findRule(id);
    await audit.record({ actor, action: 'alert_rule.update', target: ruleTarget(rule), metadata: { changes } });
    return rule;
  }

  async function deleteRule(actor, id) {
    await authorize(actor, PERMISSIONS.ALERTS_MANAGE);
    const rule = await findRule(id);
    if (!rule) throw notFound('Alert rule not found');
    await clearOpenEvents({ ruleId: id }, new Date());
    await db('alert_rules').where({ id }).delete();
    await audit.record({ actor, action: 'alert_rule.delete', target: ruleTarget(rule), metadata: publicRuleMeta(rule) });
  }

  async function findRule(id) {
    const row = await db('alert_rules as r')
      .leftJoin('servers as s', 's.id', 'r.server_id')
      .select('r.*', 's.name as server_name')
      .where('r.id', id)
      .first();
    return row ? toPublicRule(row) : null;
  }

  async function requireServerIfSet(serverId) {
    if (serverId && !(await findServer(db, serverId))) {
      throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    }
  }

  // ---- Events -----------------------------------------------------------

  function eventQuery() {
    return db('alert_events as e')
      .leftJoin('servers as s', 's.id', 'e.server_id')
      .leftJoin('users as u', 'u.id', 'e.acknowledged_by')
      .select(EVENT_COLUMNS);
  }

  async function listEvents(actor, query) {
    await authorize(actor, PERMISSIONS.ALERTS_READ);
    const q = eventQuery();
    if (query.status === 'open') q.whereIn('e.status', OPEN_STATUSES);
    else if (query.status) q.where('e.status', query.status);
    if (query.serverId) q.where('e.server_id', query.serverId);
    if (query.severity) q.where('e.severity', query.severity);
    const { rows, pagination } = await paginate(q, query, { startedAt: 'e.started_at', resolvedAt: 'e.resolved_at' });
    return { items: rows.map(toPublicEvent), pagination };
  }

  async function acknowledge(actor, id) {
    await authorize(actor, PERMISSIONS.ALERTS_ACKNOWLEDGE);
    const event = await db('alert_events').where({ id }).first();
    if (!event) throw notFound('Alert not found');
    const now = new Date();
    const n = await db('alert_events')
      .where({ id, status: 'firing' })
      .whereNull('acknowledged_at')
      .update({ acknowledged_at: now, acknowledged_by: actor.type === 'user' ? actor.id : null, updated_at: now });
    if (!n) throw new AppError(409, 'ALERT_NOT_ACKNOWLEDGEABLE', 'Only firing, unacknowledged alerts can be acknowledged');
    await audit.record({
      actor,
      action: 'alert.acknowledge',
      target: { type: 'server', id: event.server_id },
      metadata: { alertId: id, rule: event.rule_name, subject: event.subject || undefined },
    });
    return toPublicEvent(await eventQuery().where('e.id', id).first());
  }

  // Firing alert counts for the top bar and dashboard.
  async function summary(actor) {
    await authorize(actor, PERMISSIONS.ALERTS_READ);
    const rows = await db('alert_events')
      .where({ status: 'firing' })
      .select('severity', db.raw('count(*) as n'), db.raw('sum(case when acknowledged_at is null then 1 else 0 end) as unacked'))
      .groupBy('severity');
    const bySeverity = Object.fromEntries(ALERT_SEVERITIES.map((s) => [s, 0]));
    let unacknowledged = 0;
    for (const r of rows) {
      bySeverity[r.severity] = Number(r.n);
      unacknowledged += Number(r.unacked);
    }
    return { firing: Object.values(bySeverity).reduce((a, b) => a + b, 0), unacknowledged, bySeverity };
  }

  // Open (firing) alerts per server, for fleet views.
  async function firingByServer(serverIds) {
    if (!serverIds.length) return {};
    const rows = await db('alert_events')
      .whereIn('server_id', serverIds)
      .where({ status: 'firing' })
      .select('server_id', 'severity')
      .count({ n: '*' })
      .groupBy('server_id', 'severity');
    const out = {};
    for (const r of rows) {
      out[r.server_id] ??= { warning: 0, critical: 0 };
      out[r.server_id][r.severity] = Number(r.n);
    }
    return out;
  }

  // ---- Evaluation -------------------------------------------------------

  // Checks every enabled rule against every server it applies to. A
  // condition that starts to hold opens a "pending" event; once it has held
  // for the rule's duration the event fires; when it stops holding a firing
  // event resolves and a pending one is dropped. Runs in the worker.
  async function evaluate(now = new Date()) {
    const rules = await db('alert_rules').where({ is_enabled: true });
    const servers = await db('servers').whereNull('deleted_at').whereIn('status', ['online', 'offline']);
    const latest = await metrics.latest(servers.map((s) => s.id));
    const staleMs = Math.max(60, config.agentOfflineSeconds) * 1000;
    // Websites the panel's uptime checks have judged, by server.
    const websites = {};
    const watched = await db('websites')
      .whereNull('deleted_at')
      .where({ uptime_enabled: true, is_enabled: true })
      .whereNotNull('uptime_status')
      .select('id', 'server_id', 'name', 'uptime_status', 'uptime_message', 'uptime_url');
    for (const w of watched) (websites[w.server_id] ??= []).push(w);

    const open = await db('alert_events').whereIn('status', OPEN_STATUSES);
    const openByKey = new Map(open.map((e) => [e.open_key, e]));
    const seen = new Set();
    // rule:server pairs whose state cannot be judged right now (no fresh
    // data); their open events are left alone rather than resolved.
    const unknown = new Set();
    const result = { fired: 0, resolved: 0, pending: 0 };

    for (const rule of rules) {
      for (const server of servers) {
        if (rule.server_id && rule.server_id !== server.id) continue;
        const conditions = evaluateRule(rule, server, latest[server.id], { now, staleMs, websites: websites[server.id] });
        if (!conditions) {
          unknown.add(`${rule.id}:${server.id}`);
          continue;
        }
        for (const c of conditions) {
          if (!c.breaching) continue;
          const key = `${rule.id}:${server.id}:${c.subject}`;
          seen.add(key);
          await advance(rule, server, c, openByKey.get(key), key, now, result);
        }
      }
    }

    for (const event of open) {
      if (seen.has(event.open_key)) continue;
      if (unknown.has(`${event.rule_id}:${event.server_id}`)) continue;
      result.resolved += await clearEvent(event, now);
    }

    if (result.fired || result.resolved) logger.info({ result }, 'alert evaluation changed alerts');
    return result;
  }

  async function advance(rule, server, condition, event, key, now, result) {
    const durationMs = rule.duration_seconds * 1000;
    const fields = {
      value: condition.value,
      message: condition.message.slice(0, 500),
      severity: rule.severity,
      rule_name: rule.name,
      threshold: rule.threshold,
      last_evaluated_at: now,
      updated_at: now,
    };
    if (!event) {
      const firing = durationMs === 0;
      try {
        await db('alert_events').insert({
          id: randomUUID(),
          rule_id: rule.id,
          server_id: server.id,
          metric: rule.metric,
          subject: condition.subject,
          status: firing ? 'firing' : 'pending',
          started_at: now,
          fired_at: firing ? now : null,
          open_key: key,
          created_at: now,
          ...fields,
        });
      } catch (err) {
        // Another worker opened it first.
        if (err.code === 'ER_DUP_ENTRY' || err.code === '23505') return;
        throw err;
      }
      if (firing) await recordFired(rule, server, condition, result);
      else result.pending += 1;
      return;
    }
    if (event.status === 'pending' && now - new Date(event.started_at) >= durationMs) {
      const n = await db('alert_events').where({ id: event.id, status: 'pending' }).update({ ...fields, status: 'firing', fired_at: now });
      if (n) await recordFired(rule, server, condition, result);
      return;
    }
    await db('alert_events').where({ id: event.id }).whereIn('status', OPEN_STATUSES).update(fields);
  }

  async function recordFired(rule, server, condition, result) {
    result.fired += 1;
    await audit.record({
      actor: monitor,
      action: 'alert.fire',
      target: { type: 'server', id: server.id, label: server.name },
      metadata: { rule: rule.name, severity: rule.severity, subject: condition.subject || undefined, message: condition.message },
    });
  }

  // Resolves a firing event, or drops a pending one that never fired.
  async function clearEvent(event, now) {
    if (event.status === 'pending') {
      await db('alert_events').where({ id: event.id, status: 'pending' }).delete();
      return 0;
    }
    const n = await db('alert_events')
      .where({ id: event.id, status: 'firing' })
      .update({ status: 'resolved', resolved_at: now, open_key: null, last_evaluated_at: now, updated_at: now });
    if (n) {
      const server = await db('servers').where({ id: event.server_id }).first('name');
      await audit.record({
        actor: monitor,
        action: 'alert.resolve',
        target: { type: 'server', id: event.server_id, label: server?.name ?? null },
        metadata: { rule: event.rule_name, subject: event.subject || undefined },
      });
    }
    return n;
  }

  async function clearOpenEvents({ ruleId }, now) {
    const events = await db('alert_events').where({ rule_id: ruleId }).whereIn('status', OPEN_STATUSES);
    for (const event of events) await clearEvent(event, now);
  }

  // Resolved alerts are history; keep them for the configured period.
  async function prune(now = new Date()) {
    const cutoff = new Date(now.getTime() - config.alertHistoryDays * 86_400_000);
    return db('alert_events').where({ status: 'resolved' }).where('resolved_at', '<', cutoff).delete();
  }

  return {
    listRules,
    createRule,
    updateRule,
    deleteRule,
    listEvents,
    acknowledge,
    summary,
    firingByServer,
    evaluate,
    prune,
  };
}

// Works out a rule's conditions on one server. Returns null when the state
// is unknown (no recent data), otherwise [{ subject, value, breaching, message }].
// websites: the server's websites with an uptime status (website rules).
export function evaluateRule(rule, server, sample, { now, staleMs, websites = [] }) {
  const def = ALERT_METRICS[rule.metric];
  if (!def) return null;

  // Checked from the panel, so known whether or not the agent reports.
  if (def.kind === 'website') {
    return websites.map((w) => {
      const address = w.uptime_url ? new URL(w.uptime_url).host : w.name;
      return { subject: address, value: null, breaching: w.uptime_status === 'down', message: `${address}: ${w.uptime_message ?? 'does not answer'}` };
    });
  }

  if (def.kind === 'offline') {
    const lastSeen = server.last_seen_at ? new Date(server.last_seen_at) : null;
    const seconds = lastSeen ? Math.round((now - lastSeen) / 1000) : null;
    return [
      {
        subject: '',
        value: seconds,
        breaching: server.status === 'offline',
        message: seconds === null ? 'The agent has never reported' : `The agent has not reported for ${humanDuration(seconds)}`,
      },
    ];
  }

  if (server.status !== 'online') return null;

  // One condition per check; only errors fire (shared/src/selfCheck.js).
  if (def.kind === 'selfcheck') {
    const report = fromJson(server.self_check, null);
    if (!report || now - new Date(report.checkedAt) > SELF_CHECK_STALE_MS) return null;
    return selfChecks(report)
      .filter((c) => c.status !== 'info')
      .map((c) => ({ subject: c.key, value: null, breaching: c.status === 'error', message: `${c.label}: ${c.detail}` }));
  }

  if (def.kind === 'service') {
    const services = fromJson(server.services_snapshot, []);
    return services
      .filter((s) => !rule.service_name || s.name === rule.service_name)
      .map((s) => {
        const down = isServiceProblem(s);
        return {
          subject: s.name,
          value: null,
          breaching: down,
          message: `Service ${s.name} is ${s.active}${s.active === 'inactive' ? ' although it is enabled at boot' : ''}`,
        };
      });
  }

  if (!sample || now - new Date(sample.collected_at) > staleMs) return null;
  const threshold = Number(rule.threshold);
  const check = (subject, value, describe) => {
    if (value === null || Number.isNaN(value)) return null;
    const rounded = Math.round(value * 100) / 100;
    return {
      subject,
      value: rounded,
      breaching: value >= threshold,
      message: `${describe} is ${formatValue(rounded, def.unit)} (threshold ${formatValue(threshold, def.unit)})`,
    };
  };
  const pct = (used, total) => (used === null || !Number(total) ? null : (Number(used) / Number(total)) * 100);

  switch (rule.metric) {
    case 'cpu_percent':
      return compact([check('', numberOrNull(sample.cpu_percent), 'CPU usage')]);
    case 'memory_percent':
      return compact([check('', pct(sample.memory_used_bytes, sample.memory_total_bytes), 'Memory usage')]);
    case 'swap_percent':
      return compact([check('', pct(sample.swap_used_bytes, sample.swap_total_bytes), 'Swap usage')]);
    case 'load_per_core':
      return compact([
        check('', server.cpu_cores ? numberOrNull(sample.load_1) / server.cpu_cores : null, 'Load per CPU core'),
      ]);
    case 'disk_percent': {
      const filesystems = fromJson(server.filesystems_snapshot, []);
      if (filesystems.length) {
        return compact(filesystems.map((f) => check(f.mount, pct(f.usedBytes, f.totalBytes), `Disk usage on ${f.mount}`)));
      }
      return compact([check('/', pct(sample.disk_used_bytes, sample.disk_total_bytes), 'Disk usage on /')]);
    }
    default:
      return null;
  }
}

function compact(list) {
  return list.filter(Boolean);
}

function numberOrNull(value) {
  return value === null || value === undefined ? null : Number(value);
}

function formatValue(value, unit) {
  return unit === '%' ? `${Math.round(value)}%` : String(Math.round(value * 100) / 100);
}

function humanDuration(seconds) {
  if (seconds < 120) return `${seconds} seconds`;
  if (seconds < 7200) return `${Math.round(seconds / 60)} minutes`;
  if (seconds < 172_800) return `${Math.round(seconds / 3600)} hours`;
  return `${Math.round(seconds / 86_400)} days`;
}

function ruleColumns(rule) {
  return {
    name: rule.name,
    metric: rule.metric,
    threshold: ALERT_METRICS[rule.metric].kind === 'metric' ? rule.threshold : null,
    duration_seconds: rule.durationSeconds,
    severity: rule.severity,
    server_id: rule.serverId ?? null,
    service_name: ALERT_METRICS[rule.metric].kind === 'service' ? (rule.serviceName ?? null) : null,
    is_enabled: rule.isEnabled ?? true,
  };
}

export function toPublicRule(row) {
  return {
    id: row.id,
    name: row.name,
    metric: row.metric,
    threshold: numberOrNull(row.threshold),
    durationSeconds: row.duration_seconds,
    severity: row.severity,
    serverId: row.server_id,
    serverName: row.server_name ?? null,
    serviceName: row.service_name,
    isEnabled: Boolean(row.is_enabled),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function toPublicEvent(row) {
  return {
    id: row.id,
    ruleId: row.rule_id,
    ruleName: row.rule_name,
    serverId: row.server_id,
    serverName: row.server_name ?? null,
    metric: row.metric,
    subject: row.subject || null,
    severity: row.severity,
    status: row.status,
    threshold: numberOrNull(row.threshold),
    value: numberOrNull(row.value),
    message: row.message,
    startedAt: toIso(row.started_at),
    firedAt: toIso(row.fired_at),
    resolvedAt: toIso(row.resolved_at),
    acknowledgedAt: toIso(row.acknowledged_at),
    acknowledgedBy: row.acknowledged_by ? { id: row.acknowledged_by, email: row.acknowledged_by_email ?? null } : null,
    lastEvaluatedAt: toIso(row.last_evaluated_at),
  };
}

function ruleTarget(rule) {
  return { type: 'alert_rule', id: rule.id, label: rule.name };
}

function publicRuleMeta(rule) {
  const { name, metric, threshold, durationSeconds, severity, serverId, serviceName, isEnabled } = rule;
  return { name, metric, threshold, durationSeconds, severity, serverId, serviceName, isEnabled };
}
