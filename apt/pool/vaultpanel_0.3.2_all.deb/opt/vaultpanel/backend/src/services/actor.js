import { ALL_PERMISSIONS } from '@vaultpanel/shared';

// An actor is whoever performs an action: a signed-in user, a server agent or
// the system itself. Services take an actor instead of an HTTP request so the
// same code serves the web UI, the API, a CLI or automation.
export function userActor(user, access, meta = {}) {
  return {
    type: 'user',
    id: user.id,
    label: user.email,
    roles: access.roles,
    rank: access.rank,
    permissions: access.permissions,
    // Set for hosting customers (phase 8): everything they do stays inside
    // their own account (see services/tenancy.js).
    customerId: access.customer?.id ?? null,
    sessionId: meta.sessionId ?? null,
    ip: meta.ip ?? null,
    userAgent: meta.userAgent ?? null,
    requestId: meta.requestId ?? null,
  };
}

// A script, the command-line tool or the SDK calling with an API token
// (phase 10). It acts as the person who owns the token, so everything that
// records "who did this" stays right, with two differences: `tokenId` says
// which token was used, and the permissions are already narrowed to the
// token's scopes.
export function apiTokenActor(user, access, token, scopes, permissions, meta = {}) {
  return {
    ...userActor(user, access, meta),
    permissions,
    tokenId: token.id,
    tokenName: token.name,
    tokenScopes: scopes,
    label: `${user.email} (token: ${token.name})`.slice(0, 254),
  };
}

// A plugin calling with its own token (phase 10, part 3). It has the
// permissions of the scopes an owner or admin approved, and nothing else.
// `tokenId` marks it as a token request, so there is no cookie or CSRF check
// and /auth is closed to it, as for API tokens.
export function pluginActor(plugin, scopes, permissions, meta = {}) {
  return {
    type: 'plugin',
    id: plugin.id,
    label: `plugin:${plugin.slug}`,
    roles: [],
    rank: 0,
    permissions,
    customerId: null,
    tokenId: plugin.id,
    tokenName: plugin.name,
    tokenScopes: scopes,
    pluginId: plugin.id,
    pluginSlug: plugin.slug,
    ip: meta.ip ?? null,
    userAgent: meta.userAgent ?? null,
    requestId: meta.requestId ?? null,
  };
}

export function anonymousActor(meta = {}, label = null) {
  return {
    type: 'anonymous',
    id: null,
    label,
    roles: [],
    rank: 0,
    permissions: [],
    ip: meta.ip ?? null,
    userAgent: meta.userAgent ?? null,
    requestId: meta.requestId ?? null,
  };
}

export function agentActor(agent, meta = {}) {
  return {
    type: 'agent',
    id: agent.id,
    label: `agent:${agent.server_id}`,
    roles: [],
    rank: 0,
    permissions: [],
    serverId: agent.server_id,
    ip: meta.ip ?? null,
    userAgent: meta.userAgent ?? null,
    requestId: meta.requestId ?? null,
  };
}

// A billing system (WHMCS, Blesta...) calling with an API key. It gets the
// permissions of its scopes and nothing else.
export function apiKeyActor(key, permissions, meta = {}) {
  return {
    type: 'api_key',
    id: key.id,
    label: `api-key:${key.name}`.slice(0, 254),
    roles: [],
    rank: 0,
    permissions,
    customerId: null,
    ip: meta.ip ?? null,
    userAgent: meta.userAgent ?? null,
    requestId: meta.requestId ?? null,
  };
}

export function systemActor(label = 'system') {
  return { type: 'system', id: null, label, roles: [], rank: Infinity, permissions: ALL_PERMISSIONS };
}
