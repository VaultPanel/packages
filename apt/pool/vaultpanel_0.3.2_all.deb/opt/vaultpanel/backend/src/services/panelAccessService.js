import { addressInNetwork, PANEL_ACCESS_SCOPE_KEYS, PERMISSIONS } from '@vaultpanel/shared';
import { getSetting } from '../models/settingModel.js';
import { AppError } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { isLoopback } from './agentService.js';

export const PANEL_ACCESS_SETTING = 'security.panel_access';
const CACHE_MS = 10_000;
const OFF = Object.freeze({ enabled: false, scope: 'everyone', addresses: [] });

// Restricting the panel to some IP addresses (0.34.0).
//
// When it is on, people use the panel only from the listed addresses or
// networks: the API refuses everyone else (middleware/panelAccess.js), and
// so do the browser terminal and signing in. Agents, push-to-deploy hooks,
// billing systems and plugins have their own credentials and are not
// affected; neither is the panel's own server (loopback). With the scope
// "staff", hosting customers keep using the panel from anywhere.
//
// Lockout guard: it cannot be turned on, or saved, unless the address of
// whoever saves it is allowed. VAULTPANEL_PANEL_ACCESS=off in .env turns the
// check off (for someone locked out after their address changed).
export function createPanelAccessService({ db, config, audit, authorize }) {
  let cached = null;
  let cachedAt = 0;

  async function rules() {
    if (cached && Date.now() - cachedAt < CACHE_MS) return cached;
    const stored = fromJson(await getSetting(db, PANEL_ACCESS_SETTING), null);
    cached = stored && typeof stored === 'object' ? { ...OFF, ...stored } : OFF;
    cachedAt = Date.now();
    return cached;
  }

  const listed = (ip, addresses) => addresses.some((a) => addressInNetwork(ip, a.address));

  // Whether a request from ip may use the panel. customer: the request is a
  // hosting customer's (or someone not signed in, for the sign-in pages).
  async function allows(ip, { customer = false } = {}) {
    if (config.panelAccessOff) return true;
    const current = await rules();
    if (!current.enabled || !ip || isLoopback(ip)) return true;
    if (customer && current.scope === 'staff') return true;
    return listed(ip, current.addresses);
  }

  function refused(ip) {
    return new AppError(403, 'IP_NOT_ALLOWED', `The panel only accepts connections from approved addresses, and ${String(ip ?? 'this address').replace(/^::ffff:/i, '')} is not one of them. Ask an owner or admin to add it.`, {
      address: ip ? String(ip).replace(/^::ffff:/i, '') : null,
    });
  }

  async function assertAllowed(ip, options) {
    if (!(await allows(ip, options))) throw refused(ip);
  }

  async function get(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const current = await rules();
    return { ...current, yourAddress: actor.ip ? String(actor.ip).replace(/^::ffff:/i, '') : null, disabledByEnv: Boolean(config.panelAccessOff) };
  }

  async function set(actor, { enabled, scope, addresses }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    if (!PANEL_ACCESS_SCOPE_KEYS.includes(scope)) throw new AppError(422, 'VALIDATION_ERROR', 'Unknown scope');
    if (enabled && !addresses.length) throw new AppError(422, 'VALIDATION_ERROR', 'Add at least one address first');
    // Whoever saves it must keep their own way in.
    if (enabled && actor.ip && !isLoopback(actor.ip) && !listed(actor.ip, addresses)) {
      throw new AppError(409, 'LOCKOUT_REFUSED', `Your own address (${String(actor.ip).replace(/^::ffff:/i, '')}) is not in the list, so saving it would lock you out. Add it first.`);
    }
    const previous = await rules();
    const value = { enabled, scope, addresses };
    const row = { key: PANEL_ACCESS_SETTING, value: JSON.stringify(value), is_secret: false, updated_by: actor.id, updated_at: new Date() };
    await db('settings').insert(row).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
    cached = null;
    await audit.record({
      actor,
      action: 'security.panel_access',
      target: { type: 'settings', id: null, label: 'Panel access' },
      metadata: { from: { enabled: previous.enabled, scope: previous.scope, count: previous.addresses.length }, to: { enabled, scope, addresses: addresses.map((a) => a.address) } },
    });
    return get(actor);
  }

  return { allows, assertAllowed, refused, get, set, rules };
}
