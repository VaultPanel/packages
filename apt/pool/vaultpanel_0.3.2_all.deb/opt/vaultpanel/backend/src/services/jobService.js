import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import {
  ACTIVE_JOB_STATUSES,
  JOB_STATUSES,
  OPERATIONS,
  OPERATION_TYPES,
  PERMISSIONS,
  redactJobParams,
  ROUTINE_OPERATION_TYPES,
  validateParams,
} from '@vaultpanel/shared';
import { toPublicJob, toPublicJobLog } from '../models/jobModel.js';
import { agentOperations } from '../models/serverModel.js';
import { AppError, forbidden, notFound, validationError } from '../utils/errors.js';
import { canonicalJson, sha256Hex } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';
import { addSeconds } from '../utils/time.js';
import { assertOwned, ownerOf, scopeQuery } from './tenancy.js';

// How long a queued job waits for the agent before failing.
export const PICKUP_TIMEOUT_SECONDS = 5 * 60;
// How long a dispatched job may go without the agent reporting it started.
export const START_TIMEOUT_SECONDS = 60;
// Extra time after a job's own timeout before the panel gives up on it.
export const TIMEOUT_GRACE_SECONDS = 30;
const MAX_LOG_LINES_PER_JOB = 5000;
// Large enough for a file opened in the file manager (1 MB, base64 encoded).
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;
// Results of operations marked transientOutput are cleared after this long.
const TRANSIENT_OUTPUT_SECONDS = 3600;
const TRANSIENT_TYPES = OPERATION_TYPES.filter((type) => OPERATIONS[type].transientOutput);

export const jobListQuery = listQuerySchema(['createdAt', 'finishedAt'], 'createdAt', {
  serverId: z.uuid().optional(),
  status: z.enum(JOB_STATUSES).optional(),
  type: z.enum(OPERATION_TYPES).optional(),
  // Routine lookups (file listings, log reads) are left out unless asked for.
  includeRoutine: z.stringbool().optional(),
});

const JOB_COLUMNS = ['j.*', 's.name as server_name', 'u.email as requested_by_email'];

export function createJobService({ db, logger, audit, authorize }) {
  // Called with (job, { status, output, error }) whenever a job reaches a
  // final state, so services can update the records a job acts on.
  const finishedHandlers = [];
  function onFinished(handler) {
    finishedHandlers.push(handler);
  }

  async function notifyFinished(jobId, result) {
    const job = await db('jobs').where({ id: jobId }).first();
    if (!job) return;
    for (const handler of finishedHandlers) {
      try {
        await handler(job, result);
      } catch (err) {
        logger.error({ err, jobId, type: job.type }, 'job finished handler failed');
      }
    }
  }

  function baseQuery() {
    return db('jobs as j')
      .leftJoin('servers as s', 's.id', 'j.server_id')
      .leftJoin('users as u', 'u.id', 'j.requested_by')
      .select(JOB_COLUMNS);
  }

  // Queues an allow-listed operation for a server. Returns immediately; the
  // agent picks the job up and reports progress.
  //
  // Operations marked internal (websites, files) take parameters only from
  // the panel's own records, so only services may queue them ({ internal: true }).
  // resource links the job to the record it acts on.
  async function create(actor, { serverId, type, params = {}, resource = null }, { internal = false } = {}) {
    const op = OPERATIONS[type];
    if (!op) throw new AppError(400, 'UNKNOWN_OPERATION', `Unknown operation "${type}"`);
    if (!op.available) {
      throw new AppError(409, 'OPERATION_UNAVAILABLE', `${op.label} is not available yet (planned for phase ${op.phase})`);
    }
    if (op.internal && !internal) {
      throw new AppError(400, 'OPERATION_NOT_DIRECT', `${op.label} is done from the Websites pages, not as a direct job`);
    }
    // Hosting customers only reach the server through their own records.
    if (actor?.customerId && !internal) throw forbidden();
    const target = { type: 'server', id: serverId };
    await authorize(actor, op.permission, target);

    const checked = validateParams(op.params, params);
    if (!checked.ok) throw validationError(checked.errors.map((e) => ({ ...e, field: `params.${e.field}` })));

    const id = randomUUID();
    const paramsHash = sha256Hex(canonicalJson({ type, serverId, params: checked.value }));
    // A job belongs to the customer who owns what it acts on, so they see it.
    const customerId = resource ? await ownerOf(db, resource.type, resource.id) : null;
    let server;
    await db.transaction(async (trx) => {
      // Locking the server row serializes job creation per server, which
      // makes the duplicate check below reliable.
      server = await trx('servers').where({ id: serverId }).whereNull('deleted_at').forUpdate().first();
      if (!server) throw notFound('Server not found');
      if (server.status === 'pending' || server.status === 'disabled') {
        throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
      }
      if (!agentOperations(server).includes(type)) {
        throw new AppError(
          409,
          'AGENT_OUTDATED',
          `The agent on this server (v${server.agent_version ?? '?'}) cannot ${op.label.toLowerCase()}. Update the agent to use it.`,
        );
      }
      const duplicate = await trx('jobs')
        .where({ params_hash: paramsHash })
        .whereIn('status', ACTIVE_JOB_STATUSES)
        .first('id');
      if (duplicate) {
        throw new AppError(409, 'DUPLICATE_OPERATION', 'The same operation is already queued or running', {
          jobId: duplicate.id,
        });
      }
      const now = new Date();
      await trx('jobs').insert({
        id,
        type,
        server_id: serverId,
        requested_by_type: actor.type === 'user' ? 'user' : 'system',
        requested_by: actor.type === 'user' ? actor.id : null,
        params: toJson(checked.value),
        params_hash: paramsHash,
        status: 'queued',
        max_attempts: op.retryable ? 3 : 1,
        timeout_seconds: op.timeoutSeconds,
        request_id: actor.requestId ?? null,
        expires_at: addSeconds(now, PICKUP_TIMEOUT_SECONDS),
        resource_type: resource?.type ?? null,
        resource_id: resource?.id ?? null,
        customer_id: customerId,
      });
      await trx('job_logs').insert({ job_id: id, stream: 'system', message: `Queued by ${actor.label ?? actor.type}` });
    });

    await audit.record({
      actor,
      action: 'job.create',
      target: { type: 'server', id: serverId, label: server.name },
      metadata: { jobId: id, operation: type, params: redactJobParams(type, checked.value), resource: resource ?? undefined },
    });
    return toPublicJob(await baseQuery().where('j.id', id).first());
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.JOBS_READ);
    const q = scopeQuery(baseQuery(), actor, 'j.customer_id');
    if (query.serverId) q.where('j.server_id', query.serverId);
    if (query.status) q.where('j.status', query.status);
    if (query.type) q.where('j.type', query.type);
    else if (!query.includeRoutine) q.whereNotIn('j.type', ROUTINE_OPERATION_TYPES);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'j.created_at', finishedAt: 'j.finished_at' });
    return { items: rows.map((r) => publicJobFor(actor, r)), pagination };
  }

  async function get(actor, id, { afterLogId = 0 } = {}) {
    await authorize(actor, PERMISSIONS.JOBS_READ);
    const row = await baseQuery().where('j.id', id).first();
    if (!row) throw notFound('Job not found');
    assertOwned(actor, row.customer_id, 'Job not found');
    const logs = await db('job_logs').where({ job_id: id }).where('id', '>', afterLogId).orderBy('id').limit(1000);
    return { ...publicJobFor(actor, row), logs: logs.map(toPublicJobLog) };
  }

  // A customer sees who of their provider's staff queued a job only as "staff".
  function publicJobFor(actor, row) {
    const job = toPublicJob(row);
    if (actor?.customerId && job.requestedBy?.id && job.requestedBy.id !== actor.id) job.requestedBy = { type: 'staff' };
    return job;
  }

  // Only queued jobs can be cancelled: once the agent has a job it may
  // already be changing the server.
  async function cancel(actor, id) {
    await authorize(actor, PERMISSIONS.JOBS_CANCEL);
    const job = await db('jobs').where({ id }).first();
    if (!job) throw notFound('Job not found');
    const updated = await db('jobs')
      .where({ id, status: 'queued' })
      .update({ ...redactedParamsUpdate(job), status: 'cancelled', cancelled_by: actor.type === 'user' ? actor.id : null, finished_at: new Date(), updated_at: new Date() });
    if (!updated) throw new AppError(409, 'JOB_NOT_CANCELLABLE', 'Only queued jobs can be cancelled');
    await db('job_logs').insert({ job_id: id, stream: 'system', message: `Cancelled by ${actor.label}` });
    await audit.record({ actor, action: 'job.cancel', target: { type: 'job', id, label: job.type } });
    await notifyFinished(id, { status: 'cancelled', output: null, error: { code: 'CANCELLED', message: `Cancelled by ${actor.label}` } });
    return toPublicJob(await baseQuery().where('j.id', id).first());
  }

  // ---- Agent side -------------------------------------------------------

  // Atomically hands the oldest queued job for a server to its agent.
  async function claimNext(serverId) {
    return db.transaction(async (trx) => {
      const job = await trx('jobs')
        .where({ server_id: serverId, status: 'queued' })
        .where('expires_at', '>', new Date())
        .orderBy('created_at')
        .forUpdate()
        .skipLocked()
        .first();
      if (!job) return null;
      const now = new Date();
      await trx('jobs')
        .where({ id: job.id })
        .update({ status: 'dispatched', dispatched_at: now, attempts: job.attempts + 1, updated_at: now });
      await trx('job_logs').insert({
        job_id: job.id,
        stream: 'system',
        message: `Dispatched to agent (attempt ${job.attempts + 1} of ${job.max_attempts})`,
      });
      return { ...job, status: 'dispatched', dispatched_at: now, attempts: job.attempts + 1 };
    });
  }

  async function agentJob(serverId, jobId, allowed) {
    const job = await db('jobs').where({ id: jobId, server_id: serverId }).first();
    if (!job) throw notFound('Job not found');
    if (!allowed.includes(job.status)) {
      throw new AppError(409, 'INVALID_JOB_STATE', `Job is ${job.status}`, { status: job.status });
    }
    return job;
  }

  async function markStarted(serverId, jobId) {
    await agentJob(serverId, jobId, ['dispatched']);
    const now = new Date();
    await db('jobs').where({ id: jobId, status: 'dispatched' }).update({ status: 'running', started_at: now, updated_at: now });
    await db('job_logs').insert({ job_id: jobId, stream: 'system', message: 'Agent started the operation' });
  }

  async function appendLogs(serverId, jobId, lines) {
    await agentJob(serverId, jobId, ['dispatched', 'running']);
    const { n } = await db('job_logs').where({ job_id: jobId }).count({ n: '*' }).first();
    const room = MAX_LOG_LINES_PER_JOB - Number(n);
    if (room <= 0) return { accepted: 0 };
    const accepted = lines.slice(0, room);
    await db('job_logs').insert(
      accepted.map((line) => ({ job_id: jobId, stream: line.stream, message: line.message.slice(0, 8000) })),
    );
    if (accepted.length < lines.length) {
      await db('job_logs').insert({ job_id: jobId, stream: 'system', message: 'Log limit reached; further lines dropped' });
    }
    return { accepted: accepted.length };
  }

  async function complete(serverId, jobId, { status, output, error }, actor = null) {
    const job = await agentJob(serverId, jobId, ['dispatched', 'running']);
    let storedOutput = output === undefined ? null : toJson(output);
    if (storedOutput && Buffer.byteLength(storedOutput) > MAX_OUTPUT_BYTES) {
      storedOutput = toJson({ truncated: true, note: 'Output exceeded 256 KB and was dropped' });
    }
    const now = new Date();
    const redactedParams = redactedParamsUpdate(job);
    const updated = await db('jobs')
      .where({ id: jobId })
      .whereIn('status', ['dispatched', 'running'])
      .update({
        ...redactedParams,
        status,
        output: storedOutput,
        error_code: status === 'failed' ? (error?.code ?? 'OPERATION_FAILED').slice(0, 64) : null,
        error_message: status === 'failed' ? (error?.message ?? 'The operation failed').slice(0, 4000) : null,
        started_at: job.started_at ?? now,
        finished_at: now,
        updated_at: now,
      });
    if (!updated) return;
    await db('job_logs').insert({
      job_id: jobId,
      stream: 'system',
      message: status === 'succeeded' ? 'Operation succeeded' : `Operation failed: ${error?.message ?? 'unknown error'}`,
    });
    await audit.record({
      actor: actor ?? { type: 'agent', id: null, label: `agent on server ${serverId}` },
      action: 'job.complete',
      target: { type: 'job', id: jobId, label: job.type },
      result: status === 'succeeded' ? 'success' : 'failure',
      metadata: { serverId, error: error ?? undefined },
    });
    await notifyFinished(jobId, { status, output: output ?? null, error: status === 'failed' ? (error ?? null) : null });
  }

  // ---- Maintenance --------------------------------------------------------

  // Moves stuck jobs to a final state (or back to the queue when a retry is
  // allowed). Safe to run concurrently: every update is conditional.
  async function sweep(now = new Date()) {
    const results = { expired: 0, requeued: 0, failed: 0, timedOut: 0 };

    const expired = await db('jobs').where({ status: 'queued' }).where('expires_at', '<=', now).select('id');
    for (const { id } of expired) {
      const n = await finish(id, 'queued', 'failed', 'AGENT_UNREACHABLE',
        'The server agent did not pick up this job in time. Check that the server is online.', now);
      results.expired += n;
    }

    const unstarted = await db('jobs')
      .where({ status: 'dispatched' })
      .where('dispatched_at', '<=', addSeconds(now, -START_TIMEOUT_SECONDS))
      .select('id', 'attempts', 'max_attempts');
    for (const job of unstarted) {
      if (job.attempts < job.max_attempts) {
        const n = await db('jobs')
          .where({ id: job.id, status: 'dispatched' })
          .update({ status: 'queued', expires_at: addSeconds(now, PICKUP_TIMEOUT_SECONDS), updated_at: now });
        if (n) {
          await db('job_logs').insert({ job_id: job.id, stream: 'system', message: 'Agent did not start the job; queued for retry' });
          results.requeued += 1;
        }
      } else {
        results.failed += await finish(job.id, 'dispatched', 'failed', 'AGENT_NO_START',
          'The agent received the job but never started it', now);
      }
    }

    const running = await db('jobs').where({ status: 'running' }).select('id', 'started_at', 'timeout_seconds');
    for (const job of running) {
      const deadline = addSeconds(new Date(job.started_at), job.timeout_seconds + TIMEOUT_GRACE_SECONDS);
      if (deadline <= now) {
        results.timedOut += await finish(job.id, 'running', 'timed_out', 'TIMEOUT',
          `No result from the agent within ${job.timeout_seconds} seconds`, now);
      }
    }

    if (TRANSIENT_TYPES.length) {
      await db('jobs')
        .whereIn('type', TRANSIENT_TYPES)
        .whereNotNull('output')
        .where('finished_at', '<', addSeconds(now, -TRANSIENT_OUTPUT_SECONDS))
        .update({ output: null });
    }

    if (results.expired + results.requeued + results.failed + results.timedOut > 0) {
      logger.info({ results }, 'job sweep moved stuck jobs');
    }
    return results;
  }

  async function finish(id, fromStatus, status, code, message, now) {
    const job = await db('jobs').where({ id }).first('type', 'params');
    const n = await db('jobs')
      .where({ id, status: fromStatus })
      .update({ ...(job ? redactedParamsUpdate(job) : {}), status, error_code: code, error_message: message, finished_at: now, updated_at: now });
    if (n) {
      await db('job_logs').insert({ job_id: id, stream: 'system', message });
      await notifyFinished(id, { status, output: null, error: { code, message } });
    }
    return n;
  }

  return { create, list, get, cancel, claimNext, markStarted, appendLogs, complete, sweep, onFinished };
}

// Secrets in a job's parameters (passwords, environment variables) are only
// kept until the job reaches a final state.
function redactedParamsUpdate(job) {
  return OPERATIONS[job.type]?.redactParams ? { params: toJson(redactJobParams(job.type, fromJson(job.params, {}))) } : {};
}
