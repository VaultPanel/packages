import { randomUUID, createPublicKey, verify } from 'node:crypto';
import { AppError, notFound, unauthenticated } from '../utils/errors.js';
import { canonicalJson, sha256Hex } from '../utils/crypto.js';
import { toJson } from '../utils/json.js';
import { addSeconds } from '../utils/time.js';
import { agentActor, anonymousActor, systemActor } from './actor.js';

export const HEARTBEAT_INTERVAL_SECONDS = 15;
export const MAX_CLOCK_SKEW_MS = 5 * 60_000;
const NONCE_TTL_SECONDS = 15 * 60;
const MIN_METRIC_INTERVAL_MS = 10_000;
// How long a dispatched envelope stays valid for the agent to start it.
const ENVELOPE_VALIDITY_SECONDS = 120;

// The string an agent signs for each request. Must match
// agent/src/security/signing.js (a backend test checks both agree).
export function agentSigningString({ method, path, timestamp, nonce, body }) {
  return [method.toUpperCase(), path, timestamp, nonce, sha256Hex(body ?? '')].join('\n');
}

export function createAgentService({ db, redis, logger, audit, jobs, signing, config }) {
  // Other services that want each heartbeat (websites: certificate expiry).
  const heartbeatHandlers = [];
  function onHeartbeat(handler) {
    heartbeatHandlers.push(handler);
  }

  async function register({ enrollmentToken, publicKey, agentVersion, system }, meta) {
    const key = parseEd25519PublicKey(publicKey);
    const fingerprint = sha256Hex(key.export({ type: 'spki', format: 'der' }));
    const agentId = randomUUID();

    const server = await db.transaction(async (trx) => {
      const token = await trx('server_enrollment_tokens')
        .where({ token_hash: sha256Hex(enrollmentToken) })
        .whereNull('used_at')
        .where('expires_at', '>', new Date())
        .forUpdate()
        .first();
      if (!token) return null;
      const srv = await trx('servers').where({ id: token.server_id }).whereNull('deleted_at').forUpdate().first();
      if (!srv) return null;
      const now = new Date();
      await trx('server_enrollment_tokens').where({ id: token.id }).update({ used_at: now });
      // One active agent per server: registering again replaces the old one.
      await trx('server_agents')
        .where({ server_id: srv.id })
        .whereNull('revoked_at')
        .update({ revoked_at: now, revoked_reason: 'replaced by a new registration' });
      await trx('server_agents').insert({
        id: agentId,
        server_id: srv.id,
        public_key: key.export({ type: 'spki', format: 'pem' }),
        key_fingerprint: fingerprint,
        agent_version: agentVersion,
        registered_ip: meta.ip ?? null,
        last_seen_at: now,
      });
      await trx('servers').where({ id: srv.id }).update({
        ...systemColumns(system),
        agent_version: agentVersion,
        // The new agent reports what it supports with its first heartbeat.
        agent_operations: null,
        public_ip: publicAddress(meta.ip, system?.addresses) ?? null,
        status: 'online',
        last_seen_at: now,
        updated_at: now,
      });
      return srv;
    });

    if (!server) {
      await audit.record({
        actor: anonymousActor(meta, system?.hostname ?? null),
        action: 'agent.register',
        result: 'failure',
        metadata: { reason: 'invalid_or_expired_token' },
      });
      throw new AppError(401, 'INVALID_ENROLLMENT_TOKEN', 'The enrollment token is invalid, expired or already used');
    }

    await audit.record({
      actor: { ...anonymousActor(meta, system?.hostname ?? null), type: 'agent', id: agentId },
      action: 'agent.register',
      target: { type: 'server', id: server.id, label: server.name },
      metadata: { fingerprint, agentVersion, hostname: system?.hostname },
    });

    return {
      agentId,
      serverId: server.id,
      panelPublicKey: await signing.publicKeyPem(),
      heartbeatIntervalSeconds: HEARTBEAT_INTERVAL_SECONDS,
    };
  }

  // Verifies a signed agent request. Returns { agent, server, actor }.
  async function authenticate({ agentId, timestamp, nonce, signature, method, path, rawBody }, meta) {
    if (!agentId || !timestamp || !nonce || !signature) throw unauthenticated('Missing agent credentials');
    if (!/^[0-9a-f-]{36}$/i.test(agentId) || !/^[A-Za-z0-9_-]{16,64}$/.test(nonce)) {
      throw unauthenticated('Malformed agent credentials');
    }
    const ts = Number(timestamp);
    if (!Number.isFinite(ts) || Math.abs(Date.now() - ts) > MAX_CLOCK_SKEW_MS) {
      throw new AppError(401, 'CLOCK_SKEW', 'Request timestamp is outside the allowed window; check the server clock');
    }
    const agent = await db('server_agents').where({ id: agentId }).first();
    if (!agent || agent.revoked_at) throw new AppError(401, 'AGENT_REVOKED', 'This agent is not registered or was revoked');
    const server = await db('servers').where({ id: agent.server_id }).whereNull('deleted_at').first();
    if (!server) throw new AppError(401, 'AGENT_REVOKED', 'This server was removed from the panel');

    const message = agentSigningString({ method, path, timestamp, nonce, body: rawBody });
    let valid;
    try {
      valid = verify(null, Buffer.from(message), createPublicKey(agent.public_key), Buffer.from(signature, 'base64'));
    } catch {
      valid = false;
    }
    if (!valid) throw unauthenticated('Invalid agent signature');

    // Each nonce is accepted once, so a captured request cannot be replayed.
    const fresh = await redis.set(`np:agent-nonce:${agentId}:${nonce}`, '1', 'EX', NONCE_TTL_SECONDS, 'NX');
    if (fresh !== 'OK') throw unauthenticated('Replayed agent request');

    await db('server_agents').where({ id: agentId }).update({ last_seen_at: new Date() });
    return { agent, server, actor: { ...agentActor(agent, meta), label: `agent on ${server.name}` } };
  }

  async function heartbeat(ctx, body, meta) {
    const { agentVersion, system, metrics, services, operations, filesystems, webStack, addresses, security, selfCheck } = body;
    const now = new Date();
    const previousStatus = ctx.server.status;
    await db('servers').where({ id: ctx.server.id }).update({
      ...systemColumns(system),
      agent_version: agentVersion,
      public_ip: publicAddress(meta.ip, addresses) ?? ctx.server.public_ip,
      services_snapshot: toJson(services ?? []),
      // Older agents send neither; keep what we had rather than erase it.
      ...(operations ? { agent_operations: toJson(operations) } : {}),
      ...(filesystems ? { filesystems_snapshot: toJson(filesystems) } : {}),
      ...(webStack ? { web_stack: toJson(webStack) } : {}),
      ...(addresses ? { ip_addresses: toJson(addresses) } : {}),
      ...(security ? { security_summary: toJson(security) } : {}),
      // Agents 0.39.0 and later (shared/src/selfCheck.js).
      ...(selfCheck ? { self_check: toJson(selfCheck) } : {}),
      status: 'online',
      last_seen_at: now,
      updated_at: now,
    });

    if (metrics) {
      const last = await db('server_metrics').where({ server_id: ctx.server.id }).orderBy('id', 'desc').first('collected_at');
      if (!last || now - new Date(last.collected_at) >= MIN_METRIC_INTERVAL_MS) {
        await db('server_metrics').insert(metricColumns(ctx.server.id, now, metrics));
      }
    }

    for (const handler of heartbeatHandlers) {
      try {
        await handler(ctx, body);
      } catch (err) {
        logger.error({ err, serverId: ctx.server.id }, 'heartbeat handler failed');
      }
    }

    if (previousStatus !== 'online') {
      await audit.record({
        actor: ctx.actor,
        action: 'server.online',
        target: { type: 'server', id: ctx.server.id, label: ctx.server.name },
        metadata: { previousStatus },
      });
    }
    // The panel's address goes on the server's login message (agent 0.23.0).
    return { heartbeatIntervalSeconds: HEARTBEAT_INTERVAL_SECONDS, panel: { url: config?.publicUrl ?? null, serverName: ctx.server.name } };
  }

  // Long-polls for the next job. Returns a signed envelope or null.
  async function nextJob(ctx, { waitMs = 20_000, isAborted = () => false } = {}) {
    const deadline = Date.now() + waitMs;
    for (;;) {
      const job = await jobs.claimNext(ctx.server.id);
      if (job) return envelopeFor(job);
      if (Date.now() >= deadline || isAborted()) return null;
      await new Promise((r) => setTimeout(r, 1000));
    }
  }

  async function envelopeFor(job) {
    const issuedAt = new Date();
    const envelope = {
      version: 1,
      jobId: job.id,
      operationId: `${job.id}:${job.attempts}`,
      serverId: job.server_id,
      type: job.type,
      params: typeof job.params === 'string' ? JSON.parse(job.params) : job.params,
      requestedBy: job.requested_by ? { type: 'user', id: job.requested_by } : { type: job.requested_by_type },
      attempt: job.attempts,
      timeoutSeconds: job.timeout_seconds,
      issuedAt: issuedAt.toISOString(),
      expiresAt: addSeconds(issuedAt, ENVELOPE_VALIDITY_SECONDS).toISOString(),
    };
    return { envelope, signature: await signing.signEnvelope(envelope) };
  }

  async function revoke(serverId, reason) {
    await db('server_agents')
      .where({ server_id: serverId })
      .whereNull('revoked_at')
      .update({ revoked_at: new Date(), revoked_reason: reason });
  }

  // Marks servers whose agent stopped reporting as offline.
  async function markOfflineServers(offlineSeconds, now = new Date()) {
    const cutoff = addSeconds(now, -offlineSeconds);
    const stale = await db('servers')
      .where({ status: 'online' })
      .whereNull('deleted_at')
      .where('last_seen_at', '<', cutoff)
      .select('id', 'name', 'last_seen_at');
    for (const server of stale) {
      const n = await db('servers').where({ id: server.id, status: 'online' }).where('last_seen_at', '<', cutoff).update({ status: 'offline' });
      if (n) {
        await audit.record({
          actor: systemActor('monitor'),
          action: 'server.offline',
          target: { type: 'server', id: server.id, label: server.name },
          metadata: { lastSeenAt: server.last_seen_at },
        });
      }
    }
    if (stale.length) logger.info({ count: stale.length }, 'marked servers offline');
    return stale.length;
  }

  async function requireServer(serverId) {
    const server = await db('servers').where({ id: serverId }).whereNull('deleted_at').first();
    if (!server) throw notFound('Server not found');
    return server;
  }

  return { register, authenticate, heartbeat, nextJob, revoke, markOfflineServers, requireServer, onHeartbeat };
}

export function parseEd25519PublicKey(pem) {
  let key;
  try {
    key = createPublicKey(pem);
  } catch {
    throw new AppError(422, 'VALIDATION_ERROR', 'publicKey must be a PEM encoded Ed25519 public key');
  }
  if (key.asymmetricKeyType !== 'ed25519') {
    throw new AppError(422, 'VALIDATION_ERROR', 'publicKey must be an Ed25519 key');
  }
  return key;
}

// Checks an envelope signature the way the agent does; used in tests.
export function verifyEnvelope(envelope, signature, publicKeyPem) {
  return verify(null, Buffer.from(canonicalJson(envelope)), createPublicKey(publicKeyPem), Buffer.from(signature, 'base64'));
}

// The address a server is reached at. An agent on the panel's own machine
// talks to it over loopback, so its public address comes from the addresses it
// reports instead: the first public one, else the first one.
export function publicAddress(requestIp, addresses) {
  if (requestIp && !isLoopback(requestIp)) return requestIp;
  const list = Array.isArray(addresses) ? addresses.filter((a) => typeof a === 'string' && !isLoopback(a)) : [];
  return list.find((a) => !isPrivateAddress(a)) ?? list[0] ?? null;
}

export function isLoopback(ip) {
  const v = String(ip).replace(/^::ffff:/i, '');
  return v === '::1' || /^127\./.test(v);
}

export function isPrivateAddress(ip) {
  const v = String(ip).replace(/^::ffff:/i, '');
  return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|169\.254\.)/.test(v) || /^f[cd]/i.test(v);
}

function systemColumns(system) {
  if (!system) return {};
  return {
    hostname: system.hostname,
    os_name: system.os?.name ?? null,
    os_version: system.os?.version ?? null,
    kernel_version: system.kernel ?? null,
    architecture: system.architecture ?? null,
    cpu_cores: system.cpuCores ?? null,
    memory_total_bytes: system.memoryTotalBytes ?? null,
    disk_total_bytes: system.diskTotalBytes ?? null,
    uptime_seconds: system.uptimeSeconds ?? null,
    // Sent by agents 0.5.0 and later; cron jobs run in this time zone.
    ...(system.timezone ? { timezone: system.timezone } : {}),
  };
}

function metricColumns(serverId, collectedAt, m) {
  return {
    server_id: serverId,
    collected_at: collectedAt,
    cpu_percent: m.cpuPercent,
    load_1: m.load?.[0] ?? null,
    load_5: m.load?.[1] ?? null,
    load_15: m.load?.[2] ?? null,
    memory_used_bytes: m.memoryUsedBytes,
    memory_total_bytes: m.memoryTotalBytes,
    swap_used_bytes: m.swapUsedBytes ?? null,
    swap_total_bytes: m.swapTotalBytes ?? null,
    disk_used_bytes: m.diskUsedBytes,
    disk_total_bytes: m.diskTotalBytes,
    net_rx_bytes_per_sec: m.netRxBytesPerSec ?? null,
    net_tx_bytes_per_sec: m.netTxBytesPerSec ?? null,
    process_count: m.processCount ?? null,
    uptime_seconds: m.uptimeSeconds ?? null,
  };
}
