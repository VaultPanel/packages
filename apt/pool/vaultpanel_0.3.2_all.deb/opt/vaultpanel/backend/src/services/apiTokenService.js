import { randomUUID } from 'node:crypto';
import {
  API_TOKEN_PATTERN,
  API_TOKEN_PREFIX,
  MAX_API_TOKENS_PER_USER,
  PERMISSIONS,
  permissionsForScopes,
  tokenPermissions,
} from '@vaultpanel/shared';
import { findUserById } from '../models/userModel.js';
import { AppError, forbidden, notFound } from '../utils/errors.js';
import { newToken, sha256Hex } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';
import { apiTokenActor } from './actor.js';

const TOUCH_INTERVAL_MS = 60_000;

// API tokens (phase 10, part 2). Everyone manages their own tokens; people
// with users.manage also see and revoke everyone's, so a token can be taken
// away when someone leaves.
export function createApiTokenService({ db, audit, authorize, accessControl }) {
  function tokenQuery() {
    return db('api_tokens as t').leftJoin('users as u', 'u.id', 't.user_id').select('t.*', 'u.email as user_email', 'u.name as user_name');
  }

  function mayManageAll(actor) {
    return Boolean(actor.permissions?.includes(PERMISSIONS.USERS_MANAGE));
  }

  async function list(actor, { all = false } = {}) {
    if (all && !mayManageAll(actor)) {
      await authorize(actor, PERMISSIONS.USERS_MANAGE);
    }
    const query = tokenQuery();
    if (!all) query.where('t.user_id', actor.id);
    const rows = await query.orderByRaw('t.revoked_at IS NULL DESC').orderBy('t.created_at', 'desc');
    return { items: rows.map(toPublicToken), canSeeAll: mayManageAll(actor) };
  }

  // Tokens are personal: an actor always creates them for itself, and a token
  // may never ask for more than its owner has.
  async function create(actor, { name, scopes, expiresInDays = null }) {
    if (actor.type !== 'user') throw forbidden('Only a signed-in person can create an API token');
    if (actor.tokenId) throw forbidden('An API token cannot create another API token. Create it in the panel.');
    const access = await accessControl.getUserAccess(actor.id);
    const granted = tokenPermissions(scopes, access.permissions);
    const asked = permissionsForScopes(scopes);
    if (granted.length === 0) {
      throw forbidden('Your account has none of the permissions these scopes cover, so the token could not do anything');
    }
    const active = await db('api_tokens').where({ user_id: actor.id }).whereNull('revoked_at').count({ n: '*' }).first();
    if (Number(active.n) >= MAX_API_TOKENS_PER_USER) {
      throw new AppError(409, 'TOO_MANY_TOKENS', `Up to ${MAX_API_TOKENS_PER_USER} tokens. Revoke one you no longer use.`);
    }
    const token = `${API_TOKEN_PREFIX}${newToken(32)}`;
    const id = randomUUID();
    const now = new Date();
    const expiresAt = expiresInDays ? new Date(now.getTime() + expiresInDays * 86_400_000) : null;
    await db('api_tokens').insert({
      id,
      user_id: actor.id,
      name,
      prefix: token.slice(0, 12),
      token_hash: sha256Hex(token),
      scopes: toJson(scopes),
      expires_at: expiresAt,
      created_at: now,
      updated_at: now,
    });
    await audit.record({
      actor,
      action: 'api_token.create',
      target: { type: 'api_token', id, label: name },
      metadata: { scopes, expiresAt: toIso(expiresAt), permissions: granted.length, notGranted: asked.length - granted.length },
    });
    return { apiToken: toPublicToken(await tokenQuery().where('t.id', id).first()), token };
  }

  async function revoke(actor, id) {
    const row = await db('api_tokens').where({ id }).first();
    if (!row) throw notFound('API token not found');
    if (row.user_id !== actor.id) await authorize(actor, PERMISSIONS.USERS_MANAGE, { type: 'api_token', id, label: row.name });
    if (!row.revoked_at) {
      await db('api_tokens')
        .where({ id })
        .update({ revoked_at: new Date(), revoked_by: actor.type === 'user' ? actor.id : null, updated_at: new Date() });
      await audit.record({ actor, action: 'api_token.revoke', target: { type: 'api_token', id, label: row.name } });
    }
    return toPublicToken(await tokenQuery().where('t.id', id).first());
  }

  // Resolves "Authorization: Bearer vpt_..." to an actor, or null. The token
  // acts as its owner with the overlap of their permissions and its scopes.
  async function resolve(token, meta = {}) {
    if (typeof token !== 'string' || !API_TOKEN_PATTERN.test(token)) return null;
    const row = await db('api_tokens').where({ token_hash: sha256Hex(token) }).whereNull('revoked_at').first();
    if (!row) return null;
    if (row.expires_at && new Date(row.expires_at).getTime() <= Date.now()) return null;
    const user = await findUserById(db, row.user_id);
    if (!user || !user.is_active) return null;
    const access = await accessControl.getUserAccess(user.id);
    // A suspended or removed hosting account cannot use its tokens either.
    if (access.blocked) return null;
    await touch(row, meta);
    const scopes = fromJson(row.scopes, []);
    return { user, access, actor: apiTokenActor(user, access, row, scopes, tokenPermissions(scopes, access.permissions), meta) };
  }

  async function touch(row, meta) {
    const stale = !row.last_used_at || Date.now() - new Date(row.last_used_at).getTime() > TOUCH_INTERVAL_MS;
    if (!stale && row.last_used_ip === (meta.ip ?? null)) return;
    await db('api_tokens')
      .where({ id: row.id })
      .update({ last_used_at: new Date(), last_used_ip: meta.ip ?? null, use_count: db.raw('use_count + 1') });
  }

  return { list, create, revoke, resolve };
}

export function toPublicToken(row) {
  const scopes = fromJson(row.scopes, []);
  return {
    id: row.id,
    name: row.name,
    prefix: row.prefix,
    scopes,
    user: { id: row.user_id, email: row.user_email ?? null, name: row.user_name ?? null },
    expiresAt: toIso(row.expires_at),
    expired: Boolean(row.expires_at && new Date(row.expires_at).getTime() <= Date.now()),
    lastUsedAt: toIso(row.last_used_at),
    lastUsedIp: row.last_used_ip,
    useCount: Number(row.use_count ?? 0),
    revokedAt: toIso(row.revoked_at),
    createdAt: toIso(row.created_at),
  };
}
