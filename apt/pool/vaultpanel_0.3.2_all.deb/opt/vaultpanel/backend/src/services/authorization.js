import { forbidden } from '../utils/errors.js';

// The single place permission checks happen. Denials are written to the audit
// log so probing for access leaves a trace.
export function createAuthorizer({ audit }) {
  return async function authorize(actor, permission, target = null) {
    if (actor?.permissions?.includes(permission)) return;
    await audit.record({ actor, action: 'authz.denied', target, result: 'denied', metadata: { permission } });
    throw forbidden();
  };
}
