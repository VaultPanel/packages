import { randomUUID } from 'node:crypto';
import { CUSTOMER_ROLE, PERMISSIONS, PLAN_APP_CAPS, PLAN_LIMITS, overLimits } from '@vaultpanel/shared';
import { toPublicCustomer, toPublicPlan } from '../models/hostingModel.js';
import { normalizeEmail } from '../models/userModel.js';
import { toPublicServer } from '../models/serverModel.js';
import { getSetting } from '../models/settingModel.js';
import { AppError, conflict, notFound, validationError } from '../utils/errors.js';
import { newToken } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { hashPassword } from '../utils/password.js';
import { toIso } from '../utils/time.js';
import { systemActor } from './actor.js';
import { planAppCaps, planLimits } from './tenancy.js';

// Hosting plans and customers (phase 8).
//
// A plan is a set of limits (how many websites, apps, databases..., how much
// disk) plus caps on each app's CPU and memory, and a price that billing
// systems charge. A customer is a hosting account on a plan: a sign-in with
// the customer role and a home server where its new things are created.
//
// Suspending turns the account's websites off, stops its apps and pauses its
// cron jobs (remembering which, so unsuspending turns back on only those) and
// signs it out. Removing it deletes everything it owns from its servers.

const OWNABLE = {
  website: { table: 'websites', label: 'website', quota: 'websites' },
  application: { table: 'applications', label: 'app', quota: 'applications' },
  database: { table: 'databases', label: 'database', quota: 'databases' },
  database_user: { table: 'database_users', label: 'database user', quota: 'databaseUsers' },
};

export function createHostingService({ db, logger, audit, authorize, quotas, ports, users, auth, websites, applications, databases, cron, backups }) {
  // The actor that queues the jobs of a suspension or removal. Who asked for
  // it is in the audit entry of the customer action itself.
  const hostingActor = () => systemActor('hosting');

  // ---- Plans ----------------------------------------------------------------

  function planQuery() {
    return db('hosting_plans as p')
      .leftJoin('server_groups as g', 'g.id', 'p.server_group_id')
      .select('p.*', 'g.name as server_group_name', db.raw("(SELECT COUNT(*) FROM customers c WHERE c.plan_id = p.id AND c.status <> 'terminated') as customer_count"));
  }

  async function loadPlan(id) {
    const row = await planQuery().where('p.id', id).first();
    if (!row) throw notFound('Plan not found');
    return row;
  }

  async function listPlans(actor, { activeOnly = false } = {}) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_READ);
    const q = planQuery().orderBy('p.name');
    if (activeOnly) q.where('p.is_active', true);
    return { items: (await q).map((r) => toPublicPlan(r)) };
  }

  async function getPlan(actor, id) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_READ);
    return toPublicPlan(await loadPlan(id));
  }

  // Finds a plan by id or by its exact name (billing systems often know it by name).
  async function resolvePlan(ref) {
    const row = /^[0-9a-f-]{36}$/i.test(ref) ? await planQuery().where('p.id', ref).first() : await planQuery().where('p.name', ref).first();
    if (!row) throw validationError([{ field: 'plan', message: 'No plan with this id or name' }]);
    return row;
  }

  async function planColumns(input) {
    const out = {};
    if (input.name !== undefined) out.name = input.name;
    if (input.description !== undefined) out.description = input.description;
    if (input.isActive !== undefined) out.is_active = input.isActive;
    if (input.priceCents !== undefined) out.price_cents = input.priceCents;
    if (input.currency !== undefined) out.currency = input.currency;
    if (input.billingCycle !== undefined) out.billing_cycle = input.billingCycle;
    if (input.serverGroupId !== undefined) {
      if (input.serverGroupId && !(await db('server_groups').where({ id: input.serverGroupId }).first('id'))) {
        throw validationError([{ field: 'serverGroupId', message: 'Server group not found' }]);
      }
      out.server_group_id = input.serverGroupId;
    }
    for (const [key, def] of Object.entries(PLAN_LIMITS)) if (input.limits?.[key] !== undefined) out[def.column] = input.limits[key];
    for (const [key, def] of Object.entries(PLAN_APP_CAPS)) if (input.appCaps?.[key] !== undefined) out[def.column] = input.appCaps[key];
    return out;
  }

  async function createPlan(actor, input) {
    await authorize(actor, PERMISSIONS.PLANS_MANAGE);
    if (await db('hosting_plans').where({ name: input.name }).first('id')) throw validationError([{ field: 'name', message: 'A plan with this name already exists' }]);
    const id = randomUUID();
    const now = new Date();
    try {
      await db('hosting_plans').insert({ id, ...(await planColumns(input)), created_by: actor.type === 'user' ? actor.id : null, created_at: now, updated_at: now });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'name', message: 'A plan with this name already exists' }]);
      throw err;
    }
    await audit.record({ actor, action: 'plan.create', target: { type: 'plan', id, label: input.name }, metadata: { limits: input.limits, appCaps: input.appCaps } });
    return toPublicPlan(await loadPlan(id));
  }

  async function updatePlan(actor, id, input) {
    await authorize(actor, PERMISSIONS.PLANS_MANAGE);
    const row = await loadPlan(id);
    if (input.name && input.name !== row.name && (await db('hosting_plans').where({ name: input.name }).whereNot({ id }).first('id'))) {
      throw validationError([{ field: 'name', message: 'A plan with this name already exists' }]);
    }
    await db('hosting_plans').where({ id }).update({ ...(await planColumns(input)), updated_at: new Date() });
    const plan = await loadPlan(id);
    // Lower caps apply to the apps already there (on their next deploy or apply).
    const appsCapped = await enforceAppCaps({ planId: id });
    // A new app limit changes how many ports each customer on the plan has.
    if ((plan.max_applications ?? null) !== (row.max_applications ?? null)) {
      await ports.syncMany(await db('customers').where({ plan_id: id }).whereNot('status', 'terminated').pluck('id'));
    }
    await audit.record({ actor, action: 'plan.update', target: { type: 'plan', id, label: plan.name }, metadata: { changes: input, appsCapped } });
    return { plan: toPublicPlan(plan), appsCapped };
  }

  async function deletePlan(actor, id) {
    await authorize(actor, PERMISSIONS.PLANS_MANAGE);
    const row = await loadPlan(id);
    const used = await db('customers').where({ plan_id: id }).count({ n: '*' }).first();
    if (Number(used.n) > 0) {
      throw new AppError(409, 'PLAN_IN_USE', `${used.n} customer${Number(used.n) === 1 ? ' is' : 's are'} on this plan (removed accounts included). Move them to another plan, or turn off "Offered to new customers" instead.`);
    }
    await db('hosting_plans').where({ id }).delete();
    await audit.record({ actor, action: 'plan.delete', target: { type: 'plan', id, label: row.name } });
  }

  // Lowers the CPU and memory limits of apps above their plan's caps (or
  // without a limit while the plan has a cap). The new limit is saved and
  // the app shows it as a change to apply; it takes effect on its next
  // deploy or "Apply changes". Returns how many apps changed.
  async function enforceAppCaps({ planId = null, customerId = null }) {
    const q = db('applications as a').join('customers as c', 'c.id', 'a.customer_id').join('hosting_plans as p', 'p.id', 'c.plan_id').whereNull('a.deleted_at').whereNot('c.status', 'terminated');
    if (planId) q.where('p.id', planId);
    if (customerId) q.where('c.id', customerId);
    const rows = await q.select('a.id', 'a.cpu_limit_percent', 'a.memory_limit_mb', 'p.app_cpu_percent', 'p.app_memory_mb');
    let changed = 0;
    const now = new Date();
    for (const r of rows) {
      const update = {};
      if (r.app_cpu_percent !== null && (r.cpu_limit_percent === null || r.cpu_limit_percent > r.app_cpu_percent)) update.cpu_limit_percent = r.app_cpu_percent;
      if (r.app_memory_mb !== null && (r.memory_limit_mb === null || r.memory_limit_mb > r.app_memory_mb)) update.memory_limit_mb = r.app_memory_mb;
      if (!Object.keys(update).length) continue;
      await db('applications').where({ id: r.id }).update({ ...update, config_changed_at: now, updated_at: now });
      changed += 1;
    }
    return changed;
  }

  // ---- Customers --------------------------------------------------------------

  function customerQuery() {
    return db('customers as c')
      .join('hosting_plans as p', 'p.id', 'c.plan_id')
      .leftJoin('servers as s', (j) => j.on('s.id', 'c.server_id').andOnNull('s.deleted_at'))
      .select('c.*', 'p.name as plan_name', 's.name as server_name', 's.status as server_status');
  }

  async function loadCustomer(id) {
    const row = await customerQuery().where('c.id', id).first();
    if (!row) throw notFound('Customer not found');
    return row;
  }

  function withUsage(row, usage, plan) {
    const limits = planLimits(plan ?? row);
    return { ...usage, limits, over: overLimits(usage, limits) };
  }

  async function listCustomers(actor, query) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_READ);
    const q = customerQuery();
    if (query.status) q.where('c.status', query.status);
    else q.whereNot('c.status', 'terminated');
    if (query.planId) q.where('c.plan_id', query.planId);
    if (query.serverId) q.where('c.server_id', query.serverId);
    if (query.search) {
      const term = `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) => w.where('c.name', 'like', term).orWhere('c.email', 'like', term).orWhere('c.company', 'like', term).orWhere('c.external_id', 'like', term));
    }
    const { rows, pagination } = await paginate(q, query, { createdAt: 'c.created_at', name: 'c.name' });
    const [usage, plans] = await Promise.all([
      quotas.usageMany(rows.map((r) => r.id)),
      db('hosting_plans').whereIn('id', [...new Set(rows.map((r) => r.plan_id))]),
    ]);
    const planById = Object.fromEntries(plans.map((p) => [p.id, p]));
    return { items: rows.map((r) => toPublicCustomer(r, { usage: withUsage(r, usage[r.id], planById[r.plan_id]) })), pagination };
  }

  async function describeCustomer(id) {
    const row = await loadCustomer(id);
    const [plan, usage, user] = await Promise.all([
      loadPlan(row.plan_id),
      quotas.usage(id),
      row.user_id ? db('users').where({ id: row.user_id }).first('id', 'email', 'is_active', 'totp_enabled', 'last_login_at') : null,
    ]);
    return toPublicCustomer(row, {
      usage: withUsage(row, usage, plan),
      user: user ? { id: user.id, email: user.email, isActive: Boolean(user.is_active), twoFactorEnabled: Boolean(user.totp_enabled), lastLoginAt: toIso(user.last_login_at) } : null,
    });
  }

  // What the account owns, for its page.
  async function resourcesOf(id) {
    const [siteRows, appRows, dbRows, userRows] = await Promise.all([
      db('websites as w')
        .leftJoin('website_domains as d', (j) => j.on('d.website_id', 'w.id').andOn('d.is_primary', db.raw('?', [true])))
        .leftJoin('applications as a', (j) => j.on('a.website_id', 'w.id').andOnNull('a.deleted_at'))
        .where('w.customer_id', id)
        .whereNull('w.deleted_at')
        .orderBy('w.name')
        .limit(500)
        .select('w.id', 'w.name', 'w.type', 'w.status', 'w.is_enabled', 'w.disk_bytes', 'd.domain', 'a.id as application_id'),
      db('applications').where({ customer_id: id }).whereNull('deleted_at').orderBy('name').limit(500).select('id', 'name', 'runtime', 'status', 'process_state', 'disk_bytes', 'cpu_limit_percent', 'memory_limit_mb'),
      db('databases').where({ customer_id: id }).whereNull('deleted_at').orderBy('name').limit(500).select('id', 'name', 'status', 'size_bytes'),
      db('database_users').where({ customer_id: id }).whereNull('deleted_at').orderBy('username').limit(500).select('id', 'username', 'status'),
    ]);
    const num = (v) => (v === null || v === undefined ? null : Number(v));
    return {
      websites: siteRows.map((r) => ({ id: r.id, name: r.name, type: r.type, status: r.status, isEnabled: Boolean(r.is_enabled), primaryDomain: r.domain, diskBytes: num(r.disk_bytes), applicationId: r.application_id })),
      applications: appRows.map((r) => ({ id: r.id, name: r.name, runtime: r.runtime, status: r.status, processState: r.process_state, diskBytes: num(r.disk_bytes), cpuLimitPercent: r.cpu_limit_percent, memoryLimitMb: r.memory_limit_mb })),
      databases: dbRows.map((r) => ({ id: r.id, name: r.name, status: r.status, sizeBytes: num(r.size_bytes) })),
      databaseUsers: userRows.map((r) => ({ id: r.id, username: r.username, status: r.status })),
    };
  }

  async function getCustomer(actor, id) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_READ);
    const [customer, resources, plan, appPorts] = await Promise.all([describeCustomer(id), resourcesOf(id), loadCustomer(id).then((r) => loadPlan(r.plan_id)), ports.list(id)]);
    return { ...customer, planDetail: toPublicPlan(plan), resources, ports: appPorts };
  }

  // Customers by the billing system's id or ours.
  async function resolveCustomer(ref) {
    const row = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(ref)
      ? await db('customers').where({ id: ref }).first('id')
      : await db('customers').where({ external_id: ref }).first('id');
    if (!row) throw notFound('Customer not found');
    return row.id;
  }

  // The server a new customer goes on: one of the plan's group (or any
  // server), online first, then the one with the fewest customers.
  async function pickServer(plan) {
    const q = db('servers as s')
      .whereNull('s.deleted_at')
      .whereIn('s.status', ['online', 'offline'])
      .select('s.id', 's.name', 's.status', db.raw("(SELECT COUNT(*) FROM customers c WHERE c.server_id = s.id AND c.status <> 'terminated') as customers"));
    if (plan.server_group_id) q.join('server_group_members as m', 'm.server_id', 's.id').where('m.group_id', plan.server_group_id);
    const rows = await q;
    rows.sort((a, b) => Number(b.status === 'online') - Number(a.status === 'online') || Number(a.customers) - Number(b.customers) || a.name.localeCompare(b.name));
    if (!rows.length) {
      throw new AppError(409, 'NO_SERVER', plan.server_group_id ? `No connected server in the server group of the ${plan.name} plan. Add one to the group, or pick a server.` : 'No connected server to put the account on. Add a server first.');
    }
    return rows[0].id;
  }

  async function checkServer(serverId) {
    const server = await db('servers').where({ id: serverId }).whereNull('deleted_at').first('id', 'status');
    if (!server) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') throw validationError([{ field: 'serverId', message: 'This server has no connected agent' }]);
  }

  async function checkUniques({ email, externalId }, exceptCustomerId = null, exceptUserId = null) {
    if (email) {
      const q = db('users').where({ email: normalizeEmail(email) });
      if (exceptUserId) q.whereNot({ id: exceptUserId });
      if (await q.first('id')) throw validationError([{ field: 'email', message: 'An account with this email already exists' }]);
    }
    if (externalId) {
      const q = db('customers').where({ external_id: externalId });
      if (exceptCustomerId) q.whereNot({ id: exceptCustomerId });
      const taken = await q.first('id');
      if (taken) throw new AppError(409, 'EXTERNAL_ID_TAKEN', 'Another customer already has this billing id', { customerId: taken.id });
    }
  }

  // Creates the account and its sign-in. Without a password, returns an
  // invite link (72 hours) the customer opens to choose one.
  async function createCustomer(actor, input, { via = 'panel' } = {}) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const plan = typeof input.plan === 'string' ? await resolvePlan(input.plan) : await loadPlan(input.planId);
    if (!plan.is_active) throw validationError([{ field: 'planId', message: 'This plan is not offered to new customers' }]);
    await checkUniques({ email: input.email, externalId: input.externalId });
    let serverId = input.serverId ?? null;
    if (serverId) await checkServer(serverId);
    else serverId = await pickServer(plan);

    const id = randomUUID();
    const userId = randomUUID();
    const now = new Date();
    const passwordHash = await hashPassword(input.password ?? newToken());
    try {
      await db.transaction(async (trx) => {
        await trx('users').insert({ id: userId, email: normalizeEmail(input.email), name: input.name, password_hash: passwordHash, password_changed_at: input.password ? now : null });
        const role = await trx('roles').where({ name: CUSTOMER_ROLE }).first('id');
        await trx('user_roles').insert({ user_id: userId, role_id: role.id });
        await trx('customers').insert({
          id,
          user_id: userId,
          plan_id: plan.id,
          server_id: serverId,
          name: input.name,
          company: input.company || null,
          email: normalizeEmail(input.email),
          external_id: input.externalId || null,
          status: 'active',
          notes: input.notes ?? '',
          created_by: actor.type === 'user' ? actor.id : null,
          created_via: via,
          created_at: now,
          updated_at: now,
        });
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw conflict('This email or billing id was just taken');
      throw err;
    }
    await ports.sync(id).catch((err) => logger.warn({ err, customerId: id }, 'could not give the customer app ports'));
    const link = input.password ? null : await users.issueLink(userId, 'invite', actor);
    await audit.record({
      actor,
      action: 'customer.create',
      target: { type: 'customer', id, label: input.name },
      metadata: { email: normalizeEmail(input.email), planId: plan.id, plan: plan.name, serverId, externalId: input.externalId ?? null, via },
    });
    return { customer: await describeCustomer(id), inviteUrl: link?.url ?? null, inviteExpiresAt: link?.expiresAt ?? null, email: link?.email ?? null };
  }

  async function updateCustomer(actor, id, input) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (row.status === 'terminated' && Object.keys(input).some((k) => k !== 'notes')) {
      throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed. Only its notes can change.');
    }
    await checkUniques({ email: input.email, externalId: input.externalId }, id, row.user_id);
    if (input.serverId) await checkServer(input.serverId);
    const patch = { updated_at: new Date() };
    if (input.name !== undefined) patch.name = input.name;
    if (input.company !== undefined) patch.company = input.company || null;
    if (input.email !== undefined) patch.email = normalizeEmail(input.email);
    if (input.externalId !== undefined) patch.external_id = input.externalId || null;
    if (input.notes !== undefined) patch.notes = input.notes;
    if (input.serverId !== undefined) patch.server_id = input.serverId;
    await db.transaction(async (trx) => {
      await trx('customers').where({ id }).update(patch);
      if (row.user_id && (input.email !== undefined || input.name !== undefined)) {
        const userPatch = { updated_at: new Date() };
        if (input.email !== undefined) userPatch.email = normalizeEmail(input.email);
        if (input.name !== undefined) userPatch.name = input.name;
        await trx('users').where({ id: row.user_id }).update(userPatch);
      }
    });
    // A new server: the account's free ports move there.
    if (input.serverId !== undefined && input.serverId !== row.server_id) await ports.sync(id);
    await audit.record({ actor, action: 'customer.update', target: customerTarget(row), metadata: { changes: input } });
    return describeCustomer(id);
  }

  async function changePlan(actor, id, planRef) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (row.status === 'terminated') throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed');
    const plan = await resolvePlan(planRef);
    if (plan.id === row.plan_id) return { customer: await describeCustomer(id), over: [], appsCapped: 0 };
    await db('customers').where({ id }).update({ plan_id: plan.id, updated_at: new Date() });
    const appsCapped = await enforceAppCaps({ customerId: id });
    await ports.sync(id);
    const customer = await describeCustomer(id);
    await audit.record({ actor, action: 'customer.plan_change', target: customerTarget(row), metadata: { from: row.plan_name, to: plan.name, over: customer.usage.over, appsCapped } });
    return { customer, over: customer.usage.over, appsCapped };
  }

  // Sets a new password (billing systems pass one) or returns a reset link.
  async function setPassword(actor, id, { password }) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (!row.user_id || row.status === 'terminated') throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed');
    if (password) {
      await db.transaction(async (trx) => {
        await trx('users').where({ id: row.user_id }).update({ password_hash: await hashPassword(password), password_changed_at: new Date(), failed_login_count: 0, locked_until: null });
        await trx('sessions').where({ user_id: row.user_id }).whereNull('revoked_at').update({ revoked_at: new Date() });
      });
      await audit.record({ actor, action: 'customer.password_set', target: customerTarget(row) });
      return { resetUrl: null, expiresAt: null, email: null };
    }
    const link = await users.issueLink(row.user_id, 'reset', actor);
    await audit.record({ actor, action: 'customer.password_reset_issue', target: customerTarget(row), metadata: { emailed: link.email?.sent ?? false } });
    return { resetUrl: link.url, expiresAt: link.expiresAt, email: link.email };
  }

  // A one-time sign-in link for the account's owner, for a billing system's
  // "Log in to VaultPanel" button (two minutes, used once).
  async function loginLink(actor, id) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (!row.user_id || row.status === 'terminated') throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed');
    if (row.status === 'suspended') throw new AppError(409, 'ACCOUNT_SUSPENDED', 'This account is suspended, so its owner cannot sign in');
    const link = await auth.issueLoginLink(row.user_id);
    await audit.record({ actor, action: 'customer.login_link', target: customerTarget(row) });
    return link;
  }

  // ---- Suspending and removing ------------------------------------------------

  async function revokeSessions(userId) {
    if (userId) await db('sessions').where({ user_id: userId }).whereNull('revoked_at').update({ revoked_at: new Date() });
  }

  // Runs step(record) for each record, collecting what failed (a record busy
  // with another change, for example) instead of stopping.
  async function each(rows, label, step, warnings) {
    const done = [];
    for (const r of rows) {
      try {
        await step(r);
        done.push(r.id);
      } catch (err) {
        warnings.push(`${label} ${r.name}: ${err.message}`);
        if (!(err instanceof AppError)) logger.warn({ err, id: r.id }, `hosting: ${label} step failed`);
      }
    }
    return done;
  }

  async function suspend(actor, id, { reason = null } = {}) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (row.status === 'terminated') throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed');
    return quotas.withLock(id, async () => {
      const sys = hostingActor();
      const warnings = [];
      // Suspending again catches what was busy the first time.
      const before = fromJson(row.suspended_resources, null) ?? { websites: [], applications: [], cronJobs: [] };
      const [siteRows, appRows, cronRows] = await Promise.all([
        db('websites').where({ customer_id: id, is_enabled: true }).whereNull('deleted_at').whereNotNull('provisioned_at').whereNot('status', 'deleting').select('id', 'name'),
        db('applications').where({ customer_id: id }).whereNull('deleted_at').whereNotNull('current_release_id').whereIn('process_state', ['running', 'starting']).select('id', 'name'),
        db('cron_jobs').where({ customer_id: id, enabled: true }).whereNull('deleted_at').whereNot('status', 'deleting').select('id', 'name'),
      ]);
      // Signed out and refused at once; then everything is turned off.
      await db('customers').where({ id }).update({ status: 'suspended', suspend_reason: reason ?? row.suspend_reason ?? null, suspended_at: row.suspended_at ?? new Date(), updated_at: new Date() });
      await revokeSessions(row.user_id);
      const sites = await each(siteRows, 'Website', (r) => websites.setEnabled(sys, r.id, false), warnings);
      const apps = await each(appRows, 'App', (r) => applications.control(sys, r.id, 'stop'), warnings);
      const crons = await each(cronRows, 'Cron job', (r) => cron.update(sys, r.id, { enabled: false }), warnings);
      const suspended = {
        websites: [...new Set([...before.websites, ...sites])],
        applications: [...new Set([...before.applications, ...apps])],
        cronJobs: [...new Set([...before.cronJobs, ...crons])],
      };
      await db('customers').where({ id }).update({ suspended_resources: toJson(suspended), updated_at: new Date() });
      await audit.record({ actor, action: 'customer.suspend', target: customerTarget(row), metadata: { reason, websites: sites.length, applications: apps.length, cronJobs: crons.length, warnings } });
      return { customer: await describeCustomer(id), warnings };
    });
  }

  async function unsuspend(actor, id) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    if (row.status !== 'suspended') throw new AppError(409, 'NOT_SUSPENDED', 'This account is not suspended');
    return quotas.withLock(id, async () => {
      const sys = hostingActor();
      const warnings = [];
      const was = fromJson(row.suspended_resources, null) ?? { websites: [], applications: [], cronJobs: [] };
      const pick = (table, ids) => (ids.length ? db(table).whereIn('id', ids).where({ customer_id: id }).whereNull('deleted_at').select('id', 'name') : []);
      const [siteRows, appRows, cronRows] = await Promise.all([pick('websites', was.websites), pick('applications', was.applications), pick('cron_jobs', was.cronJobs)]);
      // Back on before the jobs start, so the account can sign in meanwhile.
      await db('customers').where({ id }).update({ status: 'active', suspend_reason: null, suspended_at: null, suspended_resources: null, updated_at: new Date() });
      const sites = await each(siteRows, 'Website', (r) => websites.setEnabled(sys, r.id, true), warnings);
      const apps = await each(appRows, 'App', (r) => applications.control(sys, r.id, 'start'), warnings);
      const crons = await each(cronRows, 'Cron job', (r) => cron.update(sys, r.id, { enabled: true }), warnings);
      await audit.record({ actor, action: 'customer.unsuspend', target: customerTarget(row), metadata: { websites: sites.length, applications: apps.length, cronJobs: crons.length, warnings } });
      return { customer: await describeCustomer(id), warnings };
    });
  }

  // Deletes everything the account owns from its servers (files included),
  // its backups, and closes its sign-in. Running it again retries whatever
  // could not be removed the first time.
  // Called with (actor, customerId) while an account is removed, for what
  // other services added for it (DNS zones). May return { warnings }.
  const terminatedHooks = [];
  function onTerminated(fn) {
    terminatedHooks.push(fn);
  }

  async function terminate(actor, id) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const row = await loadCustomer(id);
    return quotas.withLock(id, async () => {
      const sys = hostingActor();
      const warnings = [];
      await db('customers').where({ id }).update({ status: 'terminated', terminated_at: row.terminated_at ?? new Date(), suspended_resources: null, updated_at: new Date() });
      if (row.user_id) await db('users').where({ id: row.user_id }).update({ is_active: false, updated_at: new Date() });
      await revokeSessions(row.user_id);

      const live = (table) => db(table).where({ customer_id: id }).whereNull('deleted_at').whereNot('status', 'deleting');
      const crons = await each(await live('cron_jobs').select('id', 'name'), 'Cron job', (r) => cron.remove(sys, r.id), warnings);
      const apps = await each(await live('applications').select('id', 'name'), 'App', (r) => applications.remove(sys, r.id, { removeFiles: true }), warnings);
      // An app's own website goes with the app.
      const siteRows = await live('websites')
        .whereNotExists(db('applications as a').whereRaw('a.website_id = websites.id').whereNull('a.deleted_at'))
        .select('id', 'name');
      const sites = await each(siteRows, 'Website', (r) => websites.remove(sys, r.id, { removeFiles: true }), warnings);
      const dbUsers = await each(await live('database_users').select('id', 'username as name'), 'Database user', (r) => databases.removeUser(sys, r.id), warnings);
      const dbs = await each(await live('databases').select('id', 'name'), 'Database', (r) => databases.remove(sys, r.id), warnings);
      await db('backup_schedules').where({ customer_id: id }).delete();
      const backupRows = await db('backups').where({ customer_id: id }).whereNull('deleted_at').whereNotIn('status', ['creating', 'deleting']).select('id', 'resource_name as name');
      const backupsRemoved = await each(backupRows, 'Backup of', (r) => backups.remove(sys, r.id), warnings);

      await ports.sync(id, { locked: true });
      for (const hook of terminatedHooks) {
        try {
          const result = await hook(sys, id);
          warnings.push(...(result?.warnings ?? []));
        } catch (err) {
          warnings.push(err.message);
        }
      }
      const queued = { cronJobs: crons.length, applications: apps.length, websites: sites.length, databaseUsers: dbUsers.length, databases: dbs.length, backups: backupsRemoved.length };
      await audit.record({ actor, action: 'customer.terminate', target: customerTarget(row), metadata: { queued, warnings } });
      return { customer: await describeCustomer(id), queued, warnings };
    });
  }

  // ---- Moving existing records to or from an account --------------------------

  // Gives a record (and what hangs off it: cron jobs, backups, schedules,
  // job history; an app's website) to customerId, or back to staff (null).
  async function setOwner(trx, type, resourceId, customerId) {
    const ids = { website: [], application: [], database: [], database_user: [] };
    ids[type].push(resourceId);
    if (type === 'application') {
      const app = await trx('applications').where({ id: resourceId }).first('website_id');
      if (app?.website_id) ids.website.push(app.website_id);
    }
    for (const [kind, list] of Object.entries(ids)) {
      if (!list.length) continue;
      await trx(OWNABLE[kind].table).whereIn('id', list).update({ customer_id: customerId });
      await trx('jobs').where({ resource_type: kind }).whereIn('resource_id', list).update({ customer_id: customerId });
      if (kind === 'database_user') continue;
      const backupIds = await trx('backups').where({ resource_type: kind }).whereIn('resource_id', list).pluck('id');
      await trx('backups').whereIn('id', backupIds).update({ customer_id: customerId });
      await trx('backup_schedules').where({ resource_type: kind }).whereIn('resource_id', list).update({ customer_id: customerId });
      if (backupIds.length) {
        await trx('jobs').whereIn('resource_type', ['backup', 'backup_download']).whereIn('resource_id', backupIds).update({ customer_id: customerId });
        const restoreIds = await trx('backup_restores').whereIn('backup_id', backupIds).pluck('id');
        if (restoreIds.length) await trx('jobs').where({ resource_type: 'backup_restore' }).whereIn('resource_id', restoreIds).update({ customer_id: customerId });
      }
      if (kind === 'website' || kind === 'application') {
        const cronIds = await trx('cron_jobs').where({ owner_type: kind }).whereIn('owner_id', list).pluck('id');
        await trx('cron_jobs').whereIn('id', cronIds).update({ customer_id: customerId });
        if (cronIds.length) await trx('jobs').where({ resource_type: 'cron_job' }).whereIn('resource_id', cronIds).update({ customer_id: customerId });
      }
    }
  }

  async function loadOwnable(type, resourceId) {
    const def = OWNABLE[type];
    const row = await db(def.table).where({ id: resourceId }).whereNull('deleted_at').first();
    if (!row) throw notFound(`This ${def.label} was not found`);
    return row;
  }

  async function assignResource(actor, id, { type, resourceId }) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const customer = await loadCustomer(id);
    if (customer.status === 'terminated') throw new AppError(409, 'CUSTOMER_REMOVED', 'This account was removed');
    const def = OWNABLE[type];
    const row = await loadOwnable(type, resourceId);
    if (row.customer_id === id) return { customer: await describeCustomer(id) };
    if (row.customer_id) throw new AppError(409, 'RESOURCE_OWNED', `This ${def.label} belongs to another customer. Take it from that account first.`);
    if (type === 'website' && (await db('applications').where({ website_id: resourceId }).whereNull('deleted_at').first('id'))) {
      throw new AppError(409, 'WEBSITE_OWNED_BY_APP', 'This website serves an app. Move the app instead; its website goes with it.');
    }
    if (type === 'website' && fromJson(await getSetting(db, 'panel.domain'), null)?.websiteId === row.id) {
      throw new AppError(409, 'PANEL_WEBSITE', 'This website puts VaultPanel itself on its domain, so it cannot belong to a customer.');
    }
    if (type === 'database_user') {
      const foreign = await db('database_user_grants as g').join('databases as d', 'd.id', 'g.database_id').where('g.database_user_id', resourceId).where((w) => w.whereNull('d.customer_id').orWhereNot('d.customer_id', id)).first('d.name');
      if (foreign) throw validationError([{ field: 'resourceId', message: `This user has access to ${foreign.name}, which is not this customer's. Remove that access first.` }]);
    }
    if (type === 'application' && row.port_key) {
      const holder = await db('customer_ports').where({ server_id: row.server_id, port: row.port_key }).whereNot({ customer_id: id }).first('id');
      if (holder) throw validationError([{ field: 'resourceId', message: `This app listens on port ${row.port_key}, one of another customer's ports. Change its port first.` }]);
    }
    await quotas.reserve(id, [def.quota], async () => {
      await db.transaction((trx) => setOwner(trx, type, resourceId, id));
      // The app's port becomes one of the account's ports.
      if (type === 'application') await ports.sync(id, { locked: true });
    });
    await audit.record({ actor, action: 'customer.resource_assign', target: customerTarget(customer), metadata: { type, resourceId, name: row.name ?? row.username } });
    if (type === 'application') await enforceAppCaps({ customerId: id });
    return { customer: await describeCustomer(id) };
  }

  async function unassignResource(actor, id, { type, resourceId }) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_MANAGE);
    const customer = await loadCustomer(id);
    const row = await loadOwnable(type, resourceId);
    if (row.customer_id !== id) throw notFound(`This ${OWNABLE[type].label} is not this customer's`);
    if (type === 'website' && (await db('applications').where({ website_id: resourceId }).whereNull('deleted_at').first('id'))) {
      throw new AppError(409, 'WEBSITE_OWNED_BY_APP', 'This website serves an app. Move the app instead; its website goes with it.');
    }
    await quotas.withLock(id, async () => {
      await db.transaction((trx) => setOwner(trx, type, resourceId, null));
      // The app keeps its port; the account gets another in its place.
      if (type === 'application') {
        await ports.release(id, row.server_id, row.port_key);
        await ports.sync(id, { locked: true });
      }
    });
    await audit.record({ actor, action: 'customer.resource_unassign', target: customerTarget(customer), metadata: { type, resourceId, name: row.name ?? row.username } });
    return { customer: await describeCustomer(id) };
  }

  // Gives a website, app or database back to staff without anyone asking:
  // the panel's own website (Panel Domain page) must never belong to a
  // customer, and older panels let staff assign it.
  async function releaseToStaff(type, resourceId) {
    const row = await db(OWNABLE[type].table).where({ id: resourceId }).first();
    if (!row?.customer_id) return false;
    const customer = await db('customers').where({ id: row.customer_id }).first('id', 'name');
    await quotas.withLock(row.customer_id, () => db.transaction((trx) => setOwner(trx, type, resourceId, null)));
    await audit.record({
      actor: systemActor('panel domain'),
      action: 'customer.resource_unassign',
      target: customer ? customerTarget(customer) : { type: 'customer', id: row.customer_id, label: null },
      metadata: { type, resourceId, name: row.name ?? row.username, reason: 'panel website' },
    });
    return true;
  }

  // ---- The customer's own view ------------------------------------------------

  // A signed-in customer's account: plan, limits, what it uses and the
  // server it creates on (with what is installed there, for the forms).
  async function myAccount(actor) {
    if (!actor?.customerId) throw notFound('No hosting account');
    const row = await loadCustomer(actor.customerId);
    const [plan, usage, server, appPorts] = await Promise.all([
      loadPlan(row.plan_id),
      quotas.usage(row.id),
      row.server_id ? db('servers').where({ id: row.server_id }).whereNull('deleted_at').first() : null,
      ports.list(row.id),
    ]);
    const publicServer = server ? toPublicServer(server) : null;
    const publicPlan = toPublicPlan(plan);
    delete publicPlan.serverGroup;
    delete publicPlan.customerCount;
    return {
      customer: { id: row.id, name: row.name, company: row.company, email: row.email, status: row.status, createdAt: toIso(row.created_at) },
      plan: publicPlan,
      usage: withUsage(row, usage, plan),
      appCaps: planAppCaps(plan),
      // The account's own app ports; its apps can only listen on these.
      ports: appPorts.map(({ port, serverId, application }) => ({ port, serverId, application })),
      // Only what a customer needs: where to point DNS and what is installed.
      server: publicServer
        ? {
            id: publicServer.id,
            name: publicServer.name,
            status: publicServer.status,
            hostname: publicServer.hostname,
            publicIp: publicServer.publicIp,
            ipAddresses: publicServer.ipAddresses,
            timezone: publicServer.timezone,
            webStack: publicServer.webStack,
            agentOperations: publicServer.agentOperations,
          }
        : null,
    };
  }

  // Disk use of site and app folders, from the agent's heartbeat. The same
  // report comes with every heartbeat until the agent measures again, so
  // only a newer one is written. An app and its website share one folder,
  // which counts for the app.
  async function syncDiskUsage(serverId, report) {
    if (!report?.folders) return;
    const sizes = new Map(report.folders.map((f) => [f.name, f.sizeBytes]));
    const checkedAt = new Date(report.checkedAt);
    const fresh = (q) => q.where({ server_id: serverId }).whereNull('deleted_at').where((w) => w.whereNull('disk_checked_at').orWhere('disk_checked_at', '<', checkedAt));
    const [appRows, siteRows] = await Promise.all([
      fresh(db('applications')).select('id', 'name'),
      fresh(db('websites')).whereNotExists(db('applications as a').whereRaw('a.website_id = websites.id').whereNull('a.deleted_at')).select('id', 'name'),
    ]);
    for (const [table, rows] of [['applications', appRows], ['websites', siteRows]]) {
      for (const r of rows) {
        if (sizes.has(r.name)) await db(table).where({ id: r.id }).update({ disk_bytes: sizes.get(r.name), disk_checked_at: checkedAt });
      }
    }
  }

  return {
    listPlans,
    getPlan,
    createPlan,
    updatePlan,
    deletePlan,
    listCustomers,
    getCustomer,
    resolveCustomer,
    createCustomer,
    updateCustomer,
    changePlan,
    setPassword,
    loginLink,
    suspend,
    unsuspend,
    terminate,
    onTerminated,
    assignResource,
    unassignResource,
    releaseToStaff,
    myAccount,
    syncDiskUsage,
    describeCustomer,
  };
}

function customerTarget(row) {
  return { type: 'customer', id: row.id, label: row.name };
}
