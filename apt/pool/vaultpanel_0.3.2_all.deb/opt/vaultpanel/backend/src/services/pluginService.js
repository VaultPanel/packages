import { randomUUID } from 'node:crypto';
import {
  API_TOKEN_SCOPES,
  MAX_PLUGINS,
  PERMISSIONS,
  PLUGIN_EVENT_PERMISSIONS,
  PLUGIN_TOKEN_PATTERN,
  PLUGIN_TOKEN_PREFIX,
  WEBHOOK_EVENTS,
  eventsNotCovered,
  permissionsForScopes,
  pluginLaunchSigningString,
  pluginPermissions,
} from '@vaultpanel/shared';
import { AppError, forbidden, notFound, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey, hmacHex, newToken, sha256Hex } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';
import { pluginManifest } from '../validators/pluginValidators.js';
import { pluginActor } from './actor.js';
import { directoryListings, newestListing } from './pluginDirectoryService.js';

const TOUCH_INTERVAL_MS = 60_000;

// Plugins (phase 10, part 3). See shared/src/plugins.js for the model and
// docs/plugins.md for the manifest.
//
// Installing a plugin is: read its manifest (by URL or pasted), show what it
// asks for, and have an owner or admin approve exactly that. The plugin then
// gets a token (vpp_...) and a signing secret, shown once. The token acts as
// the plugin, with the approved scopes' permissions; the secret signs the
// events sent to it and the links that open its page in the panel.
export function createPluginService({ db, config, audit, authorize, webhooks }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'plugins'));

  // ---- Manifests ---------------------------------------------------------------

  async function readManifest({ manifestUrl, manifest }) {
    const raw = manifestUrl ? await webhooks.fetchManifest(manifestUrl) : manifest;
    const parsed = pluginManifest.safeParse(raw ?? {});
    if (!parsed.success) {
      throw validationError(
        parsed.error.issues.map((i) => ({ field: ['manifest', ...i.path].join('.'), message: i.message })),
        'The plugin manifest is not valid',
      );
    }
    return { manifest: parsed.data, manifestUrl: manifestUrl ?? null };
  }

  // What the person approving needs to know: each scope in words, how many
  // permissions that is, and anything to be careful about.
  function review(manifest, approverPermissions) {
    const asked = permissionsForScopes(manifest.permissions);
    const granted = pluginPermissions(manifest.permissions, approverPermissions);
    const warnings = [];
    const plain = [manifest.webhookUrl, manifest.page?.url].filter((u) => u && u.startsWith('http:'));
    if (plain.length) warnings.push('Some of its addresses use plain http, so its events and page are not encrypted on the way.');
    if (manifest.page && sameOrigin(manifest.page.url, config.publicUrl)) {
      warnings.push("Its page is on the panel's own address, so it is shown without the usual separation from the panel. Only install it if you trust it fully.");
    }
    if (manifest.permissions.includes('servers')) warnings.push('It may run server operations such as service restarts and reboots.');
    if (manifest.permissions.includes('customers')) warnings.push('It may create, suspend and remove hosting customers.');
    if (manifest.permissions.includes('manage')) warnings.push('It may create, change and delete websites, apps, databases, containers and backups.');
    return {
      scopes: manifest.permissions.map((key) => ({ key, label: API_TOKEN_SCOPES[key].label, description: API_TOKEN_SCOPES[key].description })),
      permissions: granted,
      notGranted: asked.filter((p) => !granted.includes(p)),
      events: manifest.events.map((key) => ({ key, description: WEBHOOK_EVENTS[key] })),
      eventsNotCovered: eventsNotCovered(manifest.events, asked),
      warnings,
    };
  }

  // The person approves everything the manifest asks for, or nothing.
  function checkApproval(manifest, approved, actor) {
    const asked = [...manifest.permissions].sort();
    const given = [...new Set(approved ?? [])].sort();
    if (asked.join(',') !== given.join(',')) {
      throw validationError([
        {
          field: 'approvedPermissions',
          message: asked.length ? `Approve what the plugin asks for: ${asked.join(', ')}` : 'This plugin asks for no permissions, so approve none',
        },
      ]);
    }
    const r = review(manifest, actor.permissions);
    if (r.notGranted.length) throw forbidden('You cannot approve permissions your own account does not have');
    if (r.eventsNotCovered.length) {
      const needs = r.eventsNotCovered.map((e) => `${e} needs ${PLUGIN_EVENT_PERMISSIONS[e]}`);
      throw validationError([{ field: 'manifest.events', message: `Its permissions do not cover these events: ${needs.join('; ')}` }], 'The plugin manifest is not valid');
    }
  }

  // Installing and changing credentials stay with a person signed in to the
  // panel, like making API tokens.
  function requirePerson(actor) {
    if (actor.type !== 'user' || actor.tokenId) throw forbidden('Plugins are installed and approved in the panel, by a signed-in owner or admin');
  }

  function newCredentials() {
    return { token: `${PLUGIN_TOKEN_PREFIX}${newToken(32)}`, secret: `whsec_${newToken(24)}` };
  }

  // ---- Reading -------------------------------------------------------------------

  async function loadRow(id) {
    const row = await db('plugins').where({ id }).first();
    if (!row) throw notFound('Plugin not found');
    return row;
  }

  async function withHook(row) {
    return toPublicPlugin(row, await webhooks.pluginHook(row.id), await installer(row));
  }

  async function installer(row) {
    if (!row.installed_by) return null;
    const user = await db('users').where({ id: row.installed_by }).first('id', 'email', 'name');
    return user ?? null;
  }

  async function list(actor) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const rows = await db('plugins').orderBy('name');
    const hooks = await db('webhooks').whereIn('plugin_id', rows.map((r) => r.id)).select('*');
    const byPlugin = new Map(hooks.map((h) => [h.plugin_id, h]));
    const listings = await directoryListings(db);
    return {
      items: rows.map((row) => ({ ...toPublicPlugin(row, byPlugin.get(row.id)), update: newestListing(listings.get(row.slug), row.version) })),
      max: MAX_PLUGINS,
    };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    const manifest = fromJson(row.manifest, {});
    const listings = (await directoryListings(db)).get(row.slug);
    return {
      plugin: { ...(await withHook(row)), update: newestListing(listings, row.version) },
      manifest,
      review: review(manifest, permissionsForScopes(fromJson(row.scopes, []))),
    };
  }

  async function preview(actor, body) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const { manifest, manifestUrl } = await readManifest(body);
    const existing = await db('plugins').where({ slug: manifest.id }).first();
    const r = review(manifest, actor.permissions);
    const listedIn = directoryMatches((await directoryListings(db)).get(manifest.id), manifest, r);
    return { manifest, manifestUrl, review: r, installed: existing ? toPublicPlugin(existing) : null, listedIn };
  }

  // ---- Changing ------------------------------------------------------------------

  async function install(actor, body) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    requirePerson(actor);
    const { manifest, manifestUrl } = await readManifest(body);
    checkApproval(manifest, body.approvedPermissions, actor);
    if (await db('plugins').where({ slug: manifest.id }).first()) {
      throw new AppError(409, 'PLUGIN_INSTALLED', `A plugin with the id ${manifest.id} is already installed. Update it from its page instead.`);
    }
    const count = await db('plugins').count({ n: '*' }).first();
    if (Number(count.n) >= MAX_PLUGINS) throw new AppError(409, 'TOO_MANY_PLUGINS', `Up to ${MAX_PLUGINS} plugins. Remove one you no longer use.`);

    const { token, secret } = newCredentials();
    const id = randomUUID();
    const now = new Date();
    await db('plugins').insert({
      id,
      ...manifestColumns(manifest, manifestUrl),
      enabled: true,
      token_prefix: token.slice(0, 12),
      token_hash: sha256Hex(token),
      secret_encrypted: box.seal(secret),
      installed_by: actor.id,
      approved_by: actor.id,
      approved_at: now,
      created_at: now,
      updated_at: now,
    });
    try {
      await webhooks.setPluginHook(id, { slug: manifest.id, url: manifest.webhookUrl, events: manifest.events, secret, enabled: true });
    } catch (err) {
      await db('plugins').where({ id }).delete();
      throw err;
    }
    await audit.record({
      actor,
      action: 'plugin.install',
      target: { type: 'plugin', id, label: manifest.name },
      metadata: { slug: manifest.id, version: manifest.version, scopes: manifest.permissions, events: manifest.events, manifestUrl },
    });
    return { plugin: await withHook(await loadRow(id)), credentials: { token, signingSecret: secret } };
  }

  // A new version of the manifest, given or fetched again from its URL. Its
  // permissions are approved again, as on install.
  async function update(actor, id, body) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    requirePerson(actor);
    const row = await loadRow(id);
    const source = body.manifest || body.manifestUrl ? body : { manifestUrl: row.manifest_url };
    if (!source.manifestUrl && !source.manifest) {
      throw validationError([{ field: 'manifest', message: 'This plugin was installed from a pasted manifest. Paste the new one.' }]);
    }
    const { manifest, manifestUrl } = await readManifest(source);
    if (manifest.id !== row.slug) {
      throw validationError([{ field: 'manifest.id', message: `This manifest is for ${manifest.id}, not ${row.slug}` }], 'The plugin manifest is not valid');
    }
    checkApproval(manifest, body.approvedPermissions, actor);
    const before = fromJson(row.scopes, []);
    const now = new Date();
    await db('plugins')
      .where({ id })
      .update({ ...manifestColumns(manifest, manifestUrl), approved_by: actor.id, approved_at: now, updated_at: now });
    await webhooks.setPluginHook(id, { slug: manifest.id, url: manifest.webhookUrl, events: manifest.events, secret: box.open(row.secret_encrypted), enabled: Boolean(row.enabled) });
    await audit.record({
      actor,
      action: 'plugin.update',
      target: { type: 'plugin', id, label: manifest.name },
      metadata: {
        fromVersion: row.version,
        toVersion: manifest.version,
        addedScopes: manifest.permissions.filter((s) => !before.includes(s)),
        removedScopes: before.filter((s) => !manifest.permissions.includes(s)),
        events: manifest.events,
      },
    });
    return { plugin: await withHook(await loadRow(id)) };
  }

  // Turned off, a plugin's token is refused, it receives no events and its
  // page is hidden. Nothing else changes, so turning it on again restores it.
  async function setEnabled(actor, id, enabled) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    if (Boolean(row.enabled) !== enabled) {
      await db('plugins').where({ id }).update({ enabled, updated_at: new Date() });
      await db('webhooks').where({ plugin_id: id }).update({ enabled, updated_at: new Date() });
      await audit.record({ actor, action: enabled ? 'plugin.enable' : 'plugin.disable', target: { type: 'plugin', id, label: row.name } });
    }
    return { plugin: await withHook(await loadRow(id)) };
  }

  // A new token and signing secret; the old ones stop working at once.
  async function rotateCredentials(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    requirePerson(actor);
    const row = await loadRow(id);
    const { token, secret } = newCredentials();
    await db('plugins')
      .where({ id })
      .update({ token_prefix: token.slice(0, 12), token_hash: sha256Hex(token), secret_encrypted: box.seal(secret), updated_at: new Date() });
    const manifest = fromJson(row.manifest, {});
    await webhooks.setPluginHook(id, { slug: row.slug, url: manifest.webhookUrl, events: fromJson(row.events, []), secret, enabled: Boolean(row.enabled) });
    await audit.record({ actor, action: 'plugin.rotate_credentials', target: { type: 'plugin', id, label: row.name } });
    return { plugin: await withHook(await loadRow(id)), credentials: { token, signingSecret: secret } };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    // Its webhook and the webhook's deliveries go with it.
    await db('plugins').where({ id }).delete();
    await audit.record({ actor, action: 'plugin.remove', target: { type: 'plugin', id, label: row.name }, metadata: { slug: row.slug, version: row.version } });
  }

  // ---- Events ----------------------------------------------------------------------

  async function deliveries(actor, id, query) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    await loadRow(id);
    return webhooks.pluginDeliveries(id, query);
  }

  async function test(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    if (!row.enabled) throw new AppError(409, 'PLUGIN_DISABLED', 'Turn the plugin on to send it events');
    const delivery = await webhooks.testPluginHook(id, { plugin: { id: row.id, slug: row.slug, name: row.name } });
    await audit.record({ actor, action: 'plugin.test', target: { type: 'plugin', id, label: row.name } });
    return { delivery };
  }

  async function redeliver(actor, id, deliveryId) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    if (!row.enabled) throw new AppError(409, 'PLUGIN_DISABLED', 'Turn the plugin on to send it events');
    const delivery = await webhooks.redeliverPlugin(id, deliveryId);
    await audit.record({ actor, action: 'plugin.redeliver', target: { type: 'plugin', id, label: row.name }, metadata: { deliveryId, event: delivery.event } });
    return { delivery };
  }

  // ---- Pages in the panel ----------------------------------------------------------

  // A plugin's page is shown to staff who may do everything the plugin may
  // do, so nobody gains anything by going through a plugin's page. Hosting
  // customers never see plugin pages: a plugin works across all accounts.
  function maySee(actor, row) {
    if (actor.type !== 'user' || actor.customerId || actor.tokenId) return false;
    const mine = new Set(actor.permissions ?? []);
    return permissionsForScopes(fromJson(row.scopes, [])).every((p) => mine.has(p));
  }

  async function pages(actor) {
    const rows = await db('plugins').where({ enabled: true }).whereNotNull('page_url').orderBy('name');
    return {
      items: rows.filter((row) => maySee(actor, row)).map((row) => ({ id: row.id, slug: row.slug, name: row.name, title: row.page_title, icon: row.page_icon ?? 'plug' })),
    };
  }

  // The plugin's page URL with the viewer and a signature added, so the
  // plugin can tell the page was opened from the panel and by whom:
  //   vp_sig = HMAC_SHA256(signingSecret, "vp_email=...&vp_panel=...&...")
  // over every vp_ parameter but vp_sig, sorted by name. The link is good
  // for PLUGIN_LAUNCH_MAX_AGE_SECONDS (see docs/plugins.md).
  async function launch(actor, id, { theme = 'light' } = {}) {
    const row = await db('plugins').where({ id, enabled: true }).whereNotNull('page_url').first();
    if (!row || !maySee(actor, row)) throw notFound('Plugin page not found');
    const params = {
      vp_plugin: row.slug,
      vp_user: actor.id,
      vp_email: actor.label ?? '',
      vp_roles: (actor.roles ?? []).join(','),
      vp_panel: config.publicUrl,
      vp_theme: theme,
      vp_ts: String(Math.floor(Date.now() / 1000)),
    };
    params.vp_sig = hmacHex(box.open(row.secret_encrypted), pluginLaunchSigningString(params));
    const url = new URL(row.page_url);
    for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
    return { plugin: { id: row.id, slug: row.slug, name: row.name, title: row.page_title, icon: row.page_icon ?? 'plug' }, url: url.href, origin: url.origin };
  }

  // ---- The plugin's own requests ---------------------------------------------------

  // Resolves "Authorization: Bearer vpp_..." to an actor, or null.
  async function resolve(token, meta = {}) {
    if (typeof token !== 'string' || !PLUGIN_TOKEN_PATTERN.test(token)) return null;
    const row = await db('plugins').where({ token_hash: sha256Hex(token) }).first();
    if (!row) return null;
    if (!row.enabled) return { disabled: true };
    await touch(row, meta);
    const scopes = fromJson(row.scopes, []);
    return { actor: pluginActor(row, scopes, permissionsForScopes(scopes), meta) };
  }

  async function touch(row, meta) {
    const stale = !row.last_used_at || Date.now() - new Date(row.last_used_at).getTime() > TOUCH_INTERVAL_MS;
    if (!stale && row.last_used_ip === (meta.ip ?? null)) return;
    await db('plugins')
      .where({ id: row.id })
      .update({ last_used_at: new Date(), last_used_ip: meta.ip ?? null, use_count: db.raw('use_count + 1') });
  }

  return { list, get, preview, install, update, setEnabled, rotateCredentials, remove, deliveries, test, redeliver, pages, launch, resolve };
}

// The directories that list this plugin. When its manifest asks for more
// than a directory said it would, the review says so: what is approved is
// always the manifest, but a difference is worth a second look.
function directoryMatches(listings, manifest, r) {
  const items = (listings ?? []).map((entry) => ({
    directory: entry.directory,
    version: entry.version,
    extraPermissions: manifest.permissions.filter((p) => !entry.permissions.includes(p)),
    extraEvents: manifest.events.filter((e) => !entry.events.includes(e)),
  }));
  for (const item of items) {
    const extra = [...item.extraPermissions, ...item.extraEvents];
    if (extra.length) r.warnings.push(`It asks for more than ${item.directory.name ?? 'its directory'} lists: ${extra.join(', ')}.`);
  }
  return items;
}

function sameOrigin(a, b) {
  try {
    return new URL(a).origin === new URL(b).origin;
  } catch {
    return false;
  }
}

function manifestColumns(manifest, manifestUrl) {
  return {
    slug: manifest.id,
    name: manifest.name,
    version: manifest.version,
    description: manifest.description ?? null,
    author: manifest.author ?? null,
    homepage: manifest.homepage ?? null,
    manifest_url: manifestUrl,
    manifest: toJson(manifest),
    scopes: toJson(manifest.permissions),
    events: toJson(manifest.events),
    page_title: manifest.page?.title ?? null,
    page_url: manifest.page?.url ?? null,
    page_icon: manifest.page?.icon ?? null,
  };
}

export function toPublicPlugin(row, hook = null, installedBy = null) {
  const manifest = fromJson(row.manifest, {});
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    version: row.version,
    description: row.description,
    author: row.author,
    homepage: row.homepage,
    manifestUrl: row.manifest_url,
    scopes: fromJson(row.scopes, []),
    permissionCount: permissionsForScopes(fromJson(row.scopes, [])).length,
    events: fromJson(row.events, []),
    webhook: manifest.webhookUrl
      ? {
          url: manifest.webhookUrl,
          lastDelivery: hook?.last_delivery_at ? { at: toIso(hook.last_delivery_at), status: hook.last_delivery_status } : null,
        }
      : null,
    page: row.page_url ? { title: row.page_title, url: row.page_url, icon: row.page_icon ?? 'plug' } : null,
    enabled: Boolean(row.enabled),
    tokenPrefix: row.token_prefix,
    installedBy: installedBy ? { id: installedBy.id, email: installedBy.email, name: installedBy.name } : row.installed_by ? { id: row.installed_by } : null,
    approvedAt: toIso(row.approved_at),
    lastUsedAt: toIso(row.last_used_at),
    lastUsedIp: row.last_used_ip,
    useCount: Number(row.use_count ?? 0),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
