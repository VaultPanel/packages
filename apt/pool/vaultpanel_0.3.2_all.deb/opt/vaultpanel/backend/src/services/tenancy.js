import { PLAN_APP_CAPS, PLAN_COUNT_KEYS, PLAN_LIMITS } from '@vaultpanel/shared';
import { AppError, notFound, validationError } from '../utils/errors.js';

// Customers (phase 8) own websites, apps, databases and what hangs off them.
// A customer's actor carries customerId; everything here keeps such an actor
// inside its own account. Staff actors (no customerId) are never limited.

// SQL returning a record's customer_id, by the kind of record. Used by the
// route guards (an id in the URL) and to give jobs the owner of what they act on.
const OWNER_QUERIES = {
  website: (db, id) => db('websites').where({ id }).first('customer_id'),
  application: (db, id) => db('applications').where({ id }).first('customer_id'),
  database: (db, id) => db('databases').where({ id }).first('customer_id'),
  database_user: (db, id) => db('database_users').where({ id }).first('customer_id'),
  cron_job: (db, id) => db('cron_jobs').where({ id }).first('customer_id'),
  backup: (db, id) => db('backups').where({ id }).first('customer_id'),
  backup_download: (db, id) => db('backups').where({ id }).first('customer_id'),
  backup_schedule: (db, id) => db('backup_schedules').where({ id }).first('customer_id'),
  backup_restore: (db, id) => db('backup_restores as r').join('backups as b', 'b.id', 'r.backup_id').where('r.id', id).first('b.customer_id'),
  deployment: (db, id) => db('deployments as d').join('applications as a', 'a.id', 'd.application_id').where('d.id', id).first('a.customer_id'),
  domain: (db, id) => db('website_domains as d').join('websites as w', 'w.id', 'd.website_id').where('d.id', id).first('w.customer_id'),
  job: (db, id) => db('jobs').where({ id }).first('customer_id'),
  cms_install: (db, id) => db('cms_installs').where({ id }).first('customer_id'),
};

export const OWNED_KINDS = Object.freeze(Object.keys(OWNER_QUERIES));

// The customer a record belongs to: an id, or null (staff-owned or missing).
export async function ownerOf(db, kind, id) {
  const query = OWNER_QUERIES[kind];
  if (!query || !id) return null;
  const row = await query(db, id);
  return row?.customer_id ?? null;
}

export function customerIdOf(actor) {
  return actor?.customerId ?? null;
}

export function isCustomer(actor) {
  return Boolean(actor?.customerId);
}

// Limits a list query to the actor's own records when the actor is a customer.
export function scopeQuery(q, actor, column) {
  if (actor?.customerId) q.where(column, actor.customerId);
  return q;
}

// For a record a customer actor reached by id: anything not theirs reads as
// missing, so ids of other accounts cannot be probed.
export function assertOwned(actor, customerId, message = 'Not found') {
  if (actor?.customerId && customerId !== actor.customerId) throw notFound(message);
}

// Things only staff do, even with a permission customers have (for example
// installing software on a server).
export function rejectCustomers(actor, message = 'Your hosting account cannot do this') {
  if (actor?.customerId) throw new AppError(403, 'FORBIDDEN', message);
}

// Plan limits as { websites: n|null, ..., diskMb: n|null }.
export function planLimits(plan) {
  const limits = {};
  for (const [key, def] of Object.entries(PLAN_LIMITS)) {
    const value = plan?.[def.column];
    limits[key] = value === null || value === undefined ? null : Number(value);
  }
  return limits;
}

export function planAppCaps(plan) {
  const caps = {};
  for (const [key, def] of Object.entries(PLAN_APP_CAPS)) {
    const value = plan?.[def.column];
    caps[key] = value === null || value === undefined ? null : Number(value);
  }
  return caps;
}

function emptyUsage() {
  return { websites: 0, subdomains: 0, applications: 0, databases: 0, databaseUsers: 0, cronJobs: 0, diskMb: 0, diskBytes: 0, disk: { websites: 0, applications: 0, databases: 0 } };
}

const LOCK_TTL_MS = 30_000;
const LOCK_WAIT_MS = 10_000;

// Quotas: counts and disk use per customer, checked before anything new is
// created for the account. Checks for one customer run one at a time (a Redis
// lock), so two requests at once cannot both take the last free slot.
export function createQuotaService({ db, redis }) {
  async function withLock(customerId, fn) {
    const key = `np:customer-lock:${customerId}`;
    const token = `${process.pid}-${Math.random().toString(36).slice(2)}`;
    const deadline = Date.now() + LOCK_WAIT_MS;
    while (!(await redis.set(key, token, 'PX', LOCK_TTL_MS, 'NX'))) {
      if (Date.now() > deadline) throw new AppError(409, 'ACCOUNT_BUSY', 'Another change to this hosting account is running. Try again in a moment.');
      await new Promise((r) => setTimeout(r, 100));
    }
    try {
      return await fn();
    } finally {
      // Release only our own lock (it may have expired and been taken).
      await redis.eval("if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end", 1, key, token).catch(() => {});
    }
  }

  async function loadAccount(customerId) {
    const customer = await db('customers').where({ id: customerId }).first();
    if (!customer) throw notFound('Customer not found');
    const plan = await db('hosting_plans').where({ id: customer.plan_id }).first();
    return { customer, plan };
  }

  // What accounts use now, by customer id. Disk counts site and app folders
  // (as their agents last reported them) plus database sizes.
  async function usageMany(customerIds) {
    const ids = [...new Set(customerIds)].filter(Boolean);
    const out = Object.fromEntries(ids.map((id) => [id, emptyUsage()]));
    if (!ids.length) return out;
    const grouped = (q, column = 'customer_id') => q.whereIn(column, ids).whereNull('deleted_at').groupBy(column).select(`${column} as customer_id`);
    const sites = () =>
      db('websites as w')
        .whereIn('w.customer_id', ids)
        .whereNull('w.deleted_at')
        .whereNotExists(db('applications as a').whereRaw('a.website_id = w.id').whereNull('a.deleted_at'))
        .groupBy('w.customer_id')
        .select('w.customer_id');
    const [websites, subdomains, applications, databases, databaseUsers, cronJobs, siteDisk, appDisk, dbDisk] = await Promise.all([
      // An app's own website (for its domains) is part of the app. A site
      // added on the Subdomains page counts as a subdomain instead.
      sites().whereNull('w.subdomain_of').count({ n: '*' }),
      sites().whereNotNull('w.subdomain_of').count({ n: '*' }),
      grouped(db('applications')).count({ n: '*' }),
      grouped(db('databases')).count({ n: '*' }),
      grouped(db('database_users')).count({ n: '*' }),
      grouped(db('cron_jobs')).count({ n: '*' }),
      // An app and its website share one folder, counted for the app.
      db('websites as w')
        .whereIn('w.customer_id', ids)
        .whereNull('w.deleted_at')
        .whereNotExists(db('applications as a').whereRaw('a.website_id = w.id').whereNull('a.deleted_at'))
        .groupBy('w.customer_id')
        .select('w.customer_id')
        .sum({ n: 'w.disk_bytes' }),
      grouped(db('applications')).sum({ n: 'disk_bytes' }),
      grouped(db('databases')).sum({ n: 'size_bytes' }),
    ]);
    const put = (rows, set) => rows.forEach((r) => set(out[r.customer_id], Number(r.n ?? 0)));
    put(websites, (u, n) => (u.websites = n));
    put(subdomains, (u, n) => (u.subdomains = n));
    put(applications, (u, n) => (u.applications = n));
    put(databases, (u, n) => (u.databases = n));
    put(databaseUsers, (u, n) => (u.databaseUsers = n));
    put(cronJobs, (u, n) => (u.cronJobs = n));
    put(siteDisk, (u, n) => (u.disk.websites = n));
    put(appDisk, (u, n) => (u.disk.applications = n));
    put(dbDisk, (u, n) => (u.disk.databases = n));
    for (const u of Object.values(out)) {
      u.diskBytes = u.disk.websites + u.disk.applications + u.disk.databases;
      u.diskMb = Math.ceil(u.diskBytes / (1024 * 1024));
    }
    return out;
  }

  async function usage(customerId) {
    return (await usageMany([customerId]))[customerId];
  }

  // The account must be active, and below its plan's limit for `kind` (and
  // under its disk space, for anything that takes disk).
  async function check(customerId, kinds) {
    const { customer, plan } = await loadAccount(customerId);
    if (customer.status !== 'active') {
      throw new AppError(409, 'ACCOUNT_SUSPENDED', customer.status === 'suspended' ? 'This hosting account is suspended' : 'This hosting account was removed');
    }
    const limits = planLimits(plan);
    const used = await usage(customerId);
    for (const kind of kinds) {
      if (!PLAN_COUNT_KEYS.includes(kind)) continue;
      const limit = limits[kind];
      if (limit !== null && used[kind] >= limit) {
        const plural = PLAN_LIMITS[kind].label.toLowerCase();
        const label = limit === 1 ? plural.replace(/s$/, '') : plural;
        throw new AppError(
          409,
          'QUOTA_REACHED',
          `The ${plan.name} plan allows ${limit} ${label} and this account has ${used[kind]}. Delete one or move to a bigger plan.`,
          { kind, limit, used: used[kind] },
        );
      }
    }
    if (kinds.some((k) => ['websites', 'subdomains', 'applications', 'databases'].includes(k)) && limits.diskMb !== null && used.diskMb >= limits.diskMb) {
      throw new AppError(409, 'QUOTA_REACHED', `This account uses ${used.diskMb} MB of the ${limits.diskMb} MB its ${plan.name} plan allows. Free up space or move to a bigger plan.`, {
        kind: 'diskMb',
        limit: limits.diskMb,
        used: used.diskMb,
      });
    }
    return { customer, plan };
  }

  // Runs fn({ customer, plan }) for a new record owned by customerId, after
  // checking the quota for each of kinds. With no customer, just runs fn(null).
  async function reserve(customerId, kinds, fn) {
    if (!customerId) return fn(null);
    return withLock(customerId, async () => fn(await check(customerId, kinds)));
  }

  // The account a customer actor creates in: active, with a server. serverId
  // is what the request named; it must be the account's server.
  async function homeFor(actor, serverId) {
    if (!actor?.customerId) return null;
    const { customer, plan } = await loadAccount(actor.customerId);
    if (!customer.server_id) throw new AppError(409, 'NO_SERVER', 'Your hosting account has no server yet. Contact your provider.');
    if (serverId && serverId !== customer.server_id) throw validationError([{ field: 'serverId', message: 'Your hosting account can only use its own server' }]);
    return { customer, plan };
  }

  // Applies a plan's per-app caps to an app's CPU and memory limits: no limit
  // or one above the cap becomes the cap. Returns the values to store, or
  // throws when values were asked for explicitly above the cap.
  function capAppLimits(plan, values, { explicit = {} } = {}) {
    const caps = planAppCaps(plan);
    const out = { ...values };
    const problems = [];
    for (const [key, def] of Object.entries(PLAN_APP_CAPS)) {
      const cap = caps[key];
      if (cap === null) continue;
      const value = out[def.field];
      if (value === null || value === undefined || value > cap) {
        if (explicit[def.field] !== undefined && (explicit[def.field] === null || explicit[def.field] > cap)) {
          problems.push({ field: def.field, message: `The ${plan.name} plan allows up to ${cap}${def.unit === '%' ? '%' : ` ${def.unit}`} per app` });
        }
        out[def.field] = cap;
      }
    }
    if (problems.length) throw validationError(problems);
    return out;
  }

  return { usage, usageMany, check, reserve, homeFor, capAppLimits, loadAccount, withLock };
}
