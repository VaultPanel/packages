import { randomUUID } from 'node:crypto';
import { Resolver } from 'node:dns/promises';
import {
  ACTIVE_JOB_STATUSES,
  isIPv4,
  isIPv6,
  MAIL_DKIM_SELECTOR,
  MAIL_QUOTA_MB,
  mailAddress,
  mailDnsRecords,
  mailTxtKind,
  MAX_MAIL_DOMAINS,
  MAX_MAIL_FORWARDERS,
  MAX_MAILBOXES,
  PERMISSIONS,
} from '@vaultpanel/shared';
import { clientSettings, toPublicForwarder, toPublicMailbox, toPublicMailDomain, toPublicMailServer } from '../models/mailModel.js';
import { findServer } from '../models/serverModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { sha512Crypt } from '../utils/sha512Crypt.js';
import { systemActor } from './actor.js';
import { isPrivateAddress } from './agentService.js';
import { generatePassword } from './databaseService.js';

// Email hosting on the panel's own servers (Postfix, Dovecot and OpenDKIM,
// the way cPanel and CyberPanel host mail).
//
// Each server that hosts email has one mail server with a host name (such as
// mail.example.com) that mail clients and other mail servers use. The panel
// keeps its domains, mailboxes and forwarders; every change raises the mail
// server's serial and sends the whole set to the agent (mailboxes with their
// password hashes only). Changes made while one is on its way are sent right
// after it.
//
// When the panel also runs DNS for a domain, its MX, SPF, DKIM and DMARC
// records are added to the zone.

export function createMailService({ db, logger, audit, authorize, jobs, dns, resolver = new Resolver({ timeout: 4000, tries: 2 }) }) {
  // ---- Reading ------------------------------------------------------------

  const mailServerQuery = () =>
    db('mail_servers as m').leftJoin('jobs as j', 'j.id', 'm.last_job_id').select('m.*', 'j.status as last_job_status', 'j.type as last_job_type');
  const jobActive = (row, type) => row?.last_job_type === type && ACTIVE_JOB_STATUSES.includes(row.last_job_status);
  const publicServer = (row) => toPublicMailServer(row, { applying: jobActive(row, 'MAIL_APPLY'), settingUp: jobActive(row, 'MAIL_SETUP') });

  function domainQuery() {
    return db('mail_domains as d')
      .join('servers as s', 's.id', 'd.server_id')
      .leftJoin('mail_servers as m', 'm.server_id', 'd.server_id')
      .whereNull('d.deleted_at')
      .whereNull('s.deleted_at')
      .select('d.*', 's.name as server_name', 'm.hostname');
  }

  async function loadDomain(id) {
    const row = await domainQuery().where('d.id', id).first();
    if (!row) throw notFound('Email domain not found');
    return row;
  }

  async function loadMailServer(serverId) {
    return mailServerQuery().where('m.server_id', serverId).first();
  }

  // Every server, with its mail server when it has one.
  async function listServers(actor) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    const servers = await db('servers').whereNull('deleted_at').orderBy('name').select('id', 'name', 'status', 'web_stack', 'public_ip', 'ip_addresses', 'hostname');
    const mailServers = await mailServerQuery();
    const counts = await db('mail_domains').whereNull('deleted_at').groupBy('server_id').select('server_id').count({ n: '*' });
    return {
      items: servers.map((s) => {
        const detected = fromJson(s.web_stack, null)?.mail;
        return {
          serverId: s.id,
          serverName: s.name,
          serverStatus: s.status,
          // undefined: the agent is too old to host email.
          agent: detected === undefined ? null : detected,
          addresses: serverAddresses(s),
          suggestedHostname: s.hostname && s.hostname.includes('.') ? s.hostname.toLowerCase() : null,
          domainCount: Number(counts.find((c) => c.server_id === s.id)?.n ?? 0),
          mailServer: publicServer(mailServers.find((m) => m.server_id === s.id)),
        };
      }),
    };
  }

  async function listDomains(actor, query) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    const q = domainQuery()
      .select(db('mailboxes as b').count('*').whereRaw('b.domain_id = d.id').as('mailbox_count'))
      .select(db('mail_forwarders as f').count('*').whereRaw('f.domain_id = d.id').as('forwarder_count'));
    if (query.serverId) q.where('d.server_id', query.serverId);
    if (query.search) q.where('d.domain', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { domain: 'd.domain', createdAt: 'd.created_at' });
    return { items: rows.map((r) => toPublicMailDomain(r, { mailboxCount: Number(r.mailbox_count), forwarderCount: Number(r.forwarder_count) })), pagination };
  }

  // The records the domain needs, and whether the panel's zone (when the
  // panel runs its DNS) has them.
  async function dnsStatus(row) {
    const needed = mailDnsRecords({ domain: row.domain, hostname: row.hostname ?? row.domain, dkimSelector: row.dkim_selector, dkimPublicKey: row.dkim_public_key });
    const zone = dns ? await dns.recordsAt(row.domain) : null;
    return {
      zone: zone ? { id: zone.zoneId, domain: zone.domain } : null,
      records: needed.map((r) => {
        let state = 'no_zone';
        if (zone) {
          const same = zone.records.some((c) => c.name === r.name && c.type === r.type && c.value === r.value && (c.priority ?? null) === (r.priority ?? null));
          const other = zone.records.some((c) => c.name === r.name && c.type === r.type && (r.type === 'MX' || mailTxtKind(c.value) === r.purpose));
          state = same ? 'ok' : other ? 'different' : 'missing';
        }
        return { ...r, state };
      }),
      dkimPending: !row.dkim_public_key,
    };
  }

  async function domainDetail(id) {
    const row = await loadDomain(id);
    const [mailboxes, forwarders, mailServer] = await Promise.all([
      db('mailboxes').where({ domain_id: id }).orderBy('local_part'),
      db('mail_forwarders').where({ domain_id: id }).orderBy('local_part'),
      loadMailServer(row.server_id),
    ]);
    return toPublicMailDomain(row, {
      mailboxCount: mailboxes.length,
      forwarderCount: forwarders.length,
      extra: {
        mailboxes: mailboxes.map(toPublicMailbox),
        forwarders: forwarders.map(toPublicForwarder),
        mailServer: publicServer(mailServer),
        client: clientSettings(row.hostname),
        dns: await dnsStatus(row),
      },
    });
  }

  async function getDomain(actor, id) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    return domainDetail(id);
  }

  // ---- Checks -------------------------------------------------------------

  function serverAddresses(server) {
    const all = [server.public_ip, ...fromJson(server.ip_addresses, [])].filter((a) => typeof a === 'string' && !isPrivateAddress(a) && !/^(127\.|::1$|fe80:)/i.test(a));
    return { ipv4: all.find(isIPv4) ?? null, ipv6: all.find(isIPv6) ?? null };
  }

  function requireAgent(server) {
    if (!server || server.deleted_at) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    const mail = fromJson(server.web_stack, null)?.mail;
    if (mail === undefined) throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} is too old to host email. Update it from the server page.`);
  }

  async function requireMailServer(serverId) {
    const row = await loadMailServer(serverId);
    if (!row || (row.status !== 'active' && row.applied_serial === null)) {
      throw new AppError(409, 'MAIL_NOT_SET_UP', 'The mail server is not set up on this server yet. Set it up from the Email page first.');
    }
    return row;
  }

  // ---- Applying -----------------------------------------------------------

  async function bump(trx, serverId) {
    const row = await trx('mail_servers').where({ server_id: serverId }).forUpdate().first('serial');
    const serial = Number(row.serial) + 1;
    await trx('mail_servers').where({ server_id: serverId }).update({ serial, updated_at: new Date() });
    return serial;
  }

  // Every domain, mailbox and forwarder of the server, as the agent gets them.
  async function stateOf(mailServer) {
    const domains = await db('mail_domains').where({ server_id: mailServer.server_id, status: 'active' }).whereNull('deleted_at').orderBy('domain');
    const ids = domains.map((d) => d.id);
    const [mailboxes, forwarders] = ids.length
      ? await Promise.all([db('mailboxes').whereIn('domain_id', ids).orderBy('address'), db('mail_forwarders').whereIn('domain_id', ids).orderBy('address')])
      : [[], []];
    return {
      hostname: mailServer.hostname,
      serial: Number(mailServer.serial),
      domains: domains.map((d) => ({ domain: d.domain, selector: d.dkim_selector })),
      mailboxes: mailboxes.map((m) => ({ address: m.address, hash: m.password_hash, quotaMb: m.quota_mb, enabled: Boolean(m.enabled) })),
      forwarders: forwarders.map((f) => ({ address: f.address, destinations: fromJson(f.destinations, []) })),
      purge: fromJson(mailServer.pending_purge, []),
    };
  }

  // Sends the server's email settings as they are now, unless a set-up or an
  // apply is already on its way (it is sent again when that one finishes).
  async function queueApply(actor, serverId, { force = false } = {}) {
    const row = await loadMailServer(serverId);
    if (!row || row.status === 'setting_up') return null;
    if (jobActive(row, 'MAIL_APPLY') || jobActive(row, 'MAIL_SETUP')) return null;
    if (!force && row.applied_serial !== null && Number(row.applied_serial) >= Number(row.serial)) return null;
    let job;
    try {
      job = await jobs.create(actor, { serverId, type: 'MAIL_APPLY', params: await stateOf(row), resource: { type: 'mail_server', id: row.id } }, { internal: true });
    } catch (err) {
      if (err.code === 'DUPLICATE_OPERATION') return null;
      throw err;
    }
    await db('mail_servers').where({ id: row.id }).update({ last_job_id: job.id });
    return job;
  }

  // Applies a change to a server's email settings, then sends them.
  async function change(actor, serverId, fn) {
    const result = await db.transaction(async (trx) => {
      const out = await fn(trx);
      await bump(trx, serverId);
      return out;
    });
    const job = await queueApply(actor, serverId);
    return { result, job };
  }

  // ---- Mail servers -------------------------------------------------------

  async function setupServer(actor, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const server = await findServer(db, input.serverId);
    requireAgent(server);
    const current = await loadMailServer(server.id);
    if (jobActive(current, 'MAIL_SETUP')) throw new AppError(409, 'MAIL_BUSY', 'The mail server is being set up right now', { jobId: current.last_job_id });
    const now = new Date();
    const id = current?.id ?? randomUUID();
    if (current) {
      await db('mail_servers').where({ id }).update({ hostname: input.hostname, status: current.applied_serial === null ? 'setting_up' : current.status, last_error_code: null, last_error: null, updated_at: now });
    } else {
      await db('mail_servers').insert({ id, server_id: server.id, hostname: input.hostname, status: 'setting_up', serial: 1, pending_purge: toJson([]), created_at: now, updated_at: now });
    }
    let job;
    try {
      job = await jobs.create(actor, { serverId: server.id, type: 'MAIL_SETUP', params: { hostname: input.hostname }, resource: { type: 'mail_server', id } }, { internal: true });
    } catch (err) {
      if (!current) await db('mail_servers').where({ id }).delete();
      else await db('mail_servers').where({ id }).update({ hostname: current.hostname, status: current.status });
      throw err;
    }
    await db('mail_servers').where({ id }).update({ last_job_id: job.id });

    // The host name needs an address; add it when the panel runs its DNS.
    let hostRecord = null;
    const { ipv4, ipv6 } = serverAddresses(server);
    if (dns && (ipv4 || ipv6)) {
      const zone = await dns.recordsAt(input.hostname);
      if (zone && !zone.records.some((r) => r.name === '@' && ['A', 'AAAA', 'CNAME'].includes(r.type))) {
        hostRecord = await dns
          .putRecords(actor, input.hostname, [...(ipv4 ? [{ name: '@', type: 'A', value: ipv4 }] : []), ...(ipv6 ? [{ name: '@', type: 'AAAA', value: ipv6 }] : [])])
          .catch((err) => {
            logger.warn({ err, hostname: input.hostname }, 'could not add the mail host name to its DNS zone');
            return null;
          });
      }
    }
    await audit.record({ actor, action: 'mail_server.setup', target: { type: 'server', id: server.id, label: server.name }, metadata: { hostname: input.hostname, jobId: job.id, dnsZone: hostRecord?.domain } });
    return { mailServer: publicServer(await loadMailServer(server.id)), job };
  }

  // Sends the server's settings again (after a failure, or to put back
  // files someone changed by hand).
  async function applyServer(actor, serverId) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const row = await requireMailServer(serverId);
    if (jobActive(row, 'MAIL_APPLY') || jobActive(row, 'MAIL_SETUP')) throw new AppError(409, 'MAIL_BUSY', 'The email settings are being applied right now', { jobId: row.last_job_id });
    await db('mail_servers').where({ id: row.id }).update({ last_error_code: null, last_error: null });
    const job = await queueApply(actor, serverId, { force: true });
    await audit.record({ actor, action: 'mail_server.apply', target: { type: 'server', id: serverId, label: row.hostname }, metadata: { jobId: job?.id } });
    return { mailServer: publicServer(await loadMailServer(serverId)), job };
  }

  // What public DNS says about the host name: does it point at the server,
  // and does the server's address point back at it (reverse DNS, which many
  // receivers check before they accept mail).
  async function checkServer(actor, serverId) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    const row = await requireMailServer(serverId);
    const server = await findServer(db, serverId);
    const { ipv4 } = serverAddresses(server);
    const checks = { hostname: row.hostname, address: ipv4 };
    try {
      const found = await resolver.resolve4(row.hostname);
      checks.forward = { ok: Boolean(ipv4) && found.includes(ipv4), found };
    } catch (err) {
      checks.forward = { ok: false, found: [], error: err.code ?? 'LOOKUP_FAILED' };
    }
    if (ipv4) {
      try {
        const found = (await resolver.reverse(ipv4)).map((h) => h.toLowerCase().replace(/\.$/, ''));
        checks.reverse = { ok: found.includes(row.hostname), found };
      } catch (err) {
        checks.reverse = { ok: false, found: [], error: err.code ?? 'LOOKUP_FAILED' };
      }
    }
    await db('mail_servers').where({ id: row.id }).update({ checks: toJson(checks), checked_at: new Date() });
    return { mailServer: publicServer(await loadMailServer(serverId)) };
  }

  // How much mail each mailbox holds (asked from the server).
  async function refreshUsage(actor, serverId) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    const row = await requireMailServer(serverId);
    try {
      const job = await jobs.create(actor, { serverId, type: 'MAIL_USAGE', params: {}, resource: { type: 'mail_server', id: row.id } }, { internal: true });
      return { job };
    } catch (err) {
      if (err.code === 'DUPLICATE_OPERATION') return { job: { id: err.details?.jobId ?? null } };
      throw err;
    }
  }

  // ---- Domains ------------------------------------------------------------

  async function createDomain(actor, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const server = await findServer(db, input.serverId);
    requireAgent(server);
    const mailServer = await requireMailServer(server.id);
    const domain = input.domain;
    if (await db('mail_domains').where({ domain_key: domain }).first('id')) throw validationError([{ field: 'domain', message: `${domain} already has email here` }]);
    const count = await db('mail_domains').where({ server_id: server.id }).whereNull('deleted_at').count({ n: '*' }).first();
    if (Number(count.n) >= MAX_MAIL_DOMAINS) throw validationError([{ field: 'domain', message: `A server can host email for at most ${MAX_MAIL_DOMAINS} domains` }]);
    const id = randomUUID();
    const now = new Date();
    let job;
    try {
      ({ job } = await change(actor, server.id, (trx) =>
        trx('mail_domains').insert({
          id,
          server_id: server.id,
          domain,
          domain_key: domain,
          status: 'active',
          dkim_selector: MAIL_DKIM_SELECTOR,
          auto_dns: input.addDnsRecords,
          created_by: actor.type === 'user' ? actor.id : null,
          created_at: now,
          updated_at: now,
        }),
      ));
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'domain', message: 'This domain was just added' }]);
      throw err;
    }
    // MX, SPF and DMARC now; DKIM once the server made the key.
    let zone = null;
    if (input.addDnsRecords) zone = await putDnsRecords(actor, { domain, hostname: mailServer.hostname, dkim_selector: MAIL_DKIM_SELECTOR, dkim_public_key: null });
    await audit.record({ actor, action: 'mail_domain.create', target: { type: 'mail_domain', id, label: domain }, metadata: { serverId: server.id, jobId: job?.id, dnsZone: zone?.domain } });
    return { domain: await domainDetail(id), job, dnsZone: zone ? { id: zone.zoneId, domain: zone.domain, added: zone.added } : null };
  }

  async function putDnsRecords(actor, row) {
    if (!dns) return null;
    const records = mailDnsRecords({ domain: row.domain, hostname: row.hostname, dkimSelector: row.dkim_selector, dkimPublicKey: row.dkim_public_key }).map(({ purpose, ...r }) => r);
    const replace = (current, wanted) => current.type === wanted.type && (wanted.type === 'MX' || (wanted.type === 'TXT' && mailTxtKind(current.value) !== null && mailTxtKind(current.value) === mailTxtKind(wanted.value)));
    try {
      return await dns.putRecords(actor, row.domain, records, { replace });
    } catch (err) {
      logger.warn({ err, domain: row.domain }, 'could not add email records to the DNS zone');
      if (actor.type === 'user') throw err;
      return null;
    }
  }

  async function addDnsRecords(actor, id) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const row = await loadDomain(id);
    const zone = await putDnsRecords(actor, row);
    if (!zone) throw new AppError(409, 'NO_DNS_ZONE', `VaultPanel does not run DNS for ${row.domain}. Add the records where its DNS is hosted.`);
    if (!row.auto_dns) await db('mail_domains').where({ id }).update({ auto_dns: true });
    await audit.record({ actor, action: 'mail_domain.dns', target: { type: 'mail_domain', id, label: row.domain }, metadata: { zone: zone.domain, added: zone.added, removed: zone.removed } });
    return { domain: await domainDetail(id), dnsZone: { id: zone.zoneId, domain: zone.domain, added: zone.added, removed: zone.removed }, job: zone.job };
  }

  // Asks public DNS for the domain's mail records.
  async function checkDomainDns(actor, id) {
    await authorize(actor, PERMISSIONS.MAIL_READ);
    const row = await loadDomain(id);
    const needed = mailDnsRecords({ domain: row.domain, hostname: row.hostname ?? row.domain, dkimSelector: row.dkim_selector, dkimPublicKey: row.dkim_public_key });
    const lookup = async (r) => {
      const name = r.name === '@' ? row.domain : `${r.name}.${row.domain}`;
      try {
        if (r.type === 'MX') {
          const found = (await resolver.resolveMx(name)).map((m) => m.exchange.toLowerCase().replace(/\.$/, ''));
          return { found, state: found.includes(r.value) ? 'ok' : found.length ? 'different' : 'missing' };
        }
        const found = (await resolver.resolveTxt(name)).map((parts) => parts.join(''));
        const kind = found.filter((v) => mailTxtKind(v) === r.purpose);
        return { found: kind, state: found.includes(r.value) ? 'ok' : kind.length ? 'different' : 'missing' };
      } catch (err) {
        if (['ENOTFOUND', 'ENODATA', 'NXDOMAIN'].includes(err.code)) return { found: [], state: 'missing' };
        return { found: [], state: 'error', error: err.code ?? 'LOOKUP_FAILED' };
      }
    };
    const results = [];
    for (const r of needed) results.push({ ...r, public: await lookup(r) });
    return { records: results, checkedAt: new Date().toISOString() };
  }

  async function removeDomain(actor, id, { deleteMail = true } = {}) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const row = await loadDomain(id);
    if (row.status === 'deleting') throw new AppError(409, 'MAIL_DOMAIN_DELETING', 'This domain is already being removed');
    const { job } = await change(actor, row.server_id, async (trx) => {
      await trx('mail_domains').where({ id }).update({ status: 'deleting', updated_at: new Date() });
      if (deleteMail) await addPurge(trx, row.server_id, [row.domain]);
    });
    await audit.record({ actor, action: 'mail_domain.delete', target: { type: 'mail_domain', id, label: row.domain }, metadata: { deleteMail, jobId: job?.id } });
    return { domain: await domainDetail(id), job };
  }

  async function addPurge(trx, serverId, items) {
    const row = await trx('mail_servers').where({ server_id: serverId }).forUpdate().first('pending_purge');
    const next = [...new Set([...fromJson(row.pending_purge, []), ...items])].slice(-MAX_MAILBOXES);
    await trx('mail_servers').where({ server_id: serverId }).update({ pending_purge: toJson(next) });
  }

  async function removePurge(trx, serverId, items) {
    const row = await trx('mail_servers').where({ server_id: serverId }).forUpdate().first('pending_purge');
    await trx('mail_servers').where({ server_id: serverId }).update({ pending_purge: toJson(fromJson(row.pending_purge, []).filter((p) => !items.includes(p))) });
  }

  // ---- Mailboxes and forwarders -------------------------------------------

  async function activeDomain(id) {
    const row = await loadDomain(id);
    if (row.status === 'deleting') throw new AppError(409, 'MAIL_DOMAIN_DELETING', 'This domain is being removed');
    return row;
  }

  async function requireFreeAddress(trx, address, { ignoreMailbox = null, ignoreForwarder = null } = {}) {
    const box = await trx('mailboxes').where({ address }).modify((q) => ignoreMailbox && q.whereNot({ id: ignoreMailbox })).first('id');
    const fwd = await trx('mail_forwarders').where({ address }).modify((q) => ignoreForwarder && q.whereNot({ id: ignoreForwarder })).first('id');
    if (box) throw validationError([{ field: 'localPart', message: `${address} is already a mailbox` }]);
    if (fwd) throw validationError([{ field: 'localPart', message: `${address} is already a forwarder` }]);
  }

  async function createMailbox(actor, domainId, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const address = mailAddress(input.localPart, domain.domain);
    const password = input.password ?? generatePassword(20);
    const id = randomUUID();
    const now = new Date();
    let job;
    try {
      ({ job } = await change(actor, domain.server_id, async (trx) => {
        await requireFreeAddress(trx, address);
        const total = await trx('mailboxes as b').join('mail_domains as d', 'd.id', 'b.domain_id').where('d.server_id', domain.server_id).count({ n: '*' }).first();
        if (Number(total.n) >= MAX_MAILBOXES) throw validationError([{ field: 'localPart', message: `A server can have at most ${MAX_MAILBOXES} mailboxes` }]);
        await trx('mailboxes').insert({
          id,
          domain_id: domainId,
          local_part: input.localPart,
          address,
          display_name: input.displayName ?? null,
          password_hash: sha512Crypt(password),
          quota_mb: input.quotaMb ?? MAIL_QUOTA_MB.default,
          enabled: true,
          created_at: now,
          updated_at: now,
        });
        // A mailbox made again gets a fresh start.
        await removePurge(trx, domain.server_id, [address]);
      }));
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'localPart', message: `${address} was just added` }]);
      throw err;
    }
    await audit.record({ actor, action: 'mailbox.create', target: { type: 'mailbox', id, label: address }, metadata: { quotaMb: input.quotaMb ?? MAIL_QUOTA_MB.default, jobId: job?.id } });
    return { mailbox: toPublicMailbox(await db('mailboxes').where({ id }).first()), password: input.password ? undefined : password, domain: await domainDetail(domainId), job };
  }

  async function loadMailbox(domainId, id) {
    const row = await db('mailboxes').where({ id, domain_id: domainId }).first();
    if (!row) throw notFound('Mailbox not found');
    return row;
  }

  async function updateMailbox(actor, domainId, id, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const current = await loadMailbox(domainId, id);
    const password = input.generatePassword ? generatePassword(20) : input.password;
    const changes = {
      ...(input.displayName !== undefined ? { display_name: input.displayName } : {}),
      ...(input.quotaMb !== undefined ? { quota_mb: input.quotaMb } : {}),
      ...(input.enabled !== undefined ? { enabled: input.enabled } : {}),
      ...(password ? { password_hash: sha512Crypt(password) } : {}),
    };
    const { job } = await change(actor, domain.server_id, (trx) => trx('mailboxes').where({ id }).update({ ...changes, updated_at: new Date() }));
    await audit.record({
      actor,
      action: 'mailbox.update',
      target: { type: 'mailbox', id, label: current.address },
      metadata: { quotaMb: input.quotaMb, enabled: input.enabled, displayName: input.displayName, passwordChanged: Boolean(password), jobId: job?.id },
    });
    return { mailbox: toPublicMailbox(await loadMailbox(domainId, id)), password: input.generatePassword ? password : undefined, domain: await domainDetail(domainId), job };
  }

  async function removeMailbox(actor, domainId, id, { deleteMail = true } = {}) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const current = await loadMailbox(domainId, id);
    const { job } = await change(actor, domain.server_id, async (trx) => {
      await trx('mailboxes').where({ id }).delete();
      if (deleteMail) await addPurge(trx, domain.server_id, [current.address]);
    });
    await audit.record({ actor, action: 'mailbox.delete', target: { type: 'mailbox', id, label: current.address }, metadata: { deleteMail, jobId: job?.id } });
    return { domain: await domainDetail(domainId), job };
  }

  async function createForwarder(actor, domainId, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const address = mailAddress(input.localPart, domain.domain);
    if (input.destinations.includes(address)) throw validationError([{ field: 'destinations', message: 'A forwarder cannot send mail to itself' }]);
    const id = randomUUID();
    const now = new Date();
    let job;
    try {
      ({ job } = await change(actor, domain.server_id, async (trx) => {
        await requireFreeAddress(trx, address);
        const total = await trx('mail_forwarders as f').join('mail_domains as d', 'd.id', 'f.domain_id').where('d.server_id', domain.server_id).count({ n: '*' }).first();
        if (Number(total.n) >= MAX_MAIL_FORWARDERS) throw validationError([{ field: 'localPart', message: `A server can have at most ${MAX_MAIL_FORWARDERS} forwarders` }]);
        await trx('mail_forwarders').insert({ id, domain_id: domainId, local_part: input.localPart, address, destinations: toJson(input.destinations), created_at: now, updated_at: now });
      }));
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'localPart', message: `${address} was just added` }]);
      throw err;
    }
    await audit.record({ actor, action: 'mail_forwarder.create', target: { type: 'mail_forwarder', id, label: address }, metadata: { destinations: input.destinations, jobId: job?.id } });
    return { forwarder: toPublicForwarder(await db('mail_forwarders').where({ id }).first()), domain: await domainDetail(domainId), job };
  }

  async function loadForwarder(domainId, id) {
    const row = await db('mail_forwarders').where({ id, domain_id: domainId }).first();
    if (!row) throw notFound('Forwarder not found');
    return row;
  }

  async function updateForwarder(actor, domainId, id, input) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const current = await loadForwarder(domainId, id);
    if (input.destinations.includes(current.address)) throw validationError([{ field: 'destinations', message: 'A forwarder cannot send mail to itself' }]);
    const { job } = await change(actor, domain.server_id, (trx) => trx('mail_forwarders').where({ id }).update({ destinations: toJson(input.destinations), updated_at: new Date() }));
    await audit.record({ actor, action: 'mail_forwarder.update', target: { type: 'mail_forwarder', id, label: current.address }, metadata: { destinations: input.destinations, jobId: job?.id } });
    return { forwarder: toPublicForwarder(await loadForwarder(domainId, id)), domain: await domainDetail(domainId), job };
  }

  async function removeForwarder(actor, domainId, id) {
    await authorize(actor, PERMISSIONS.MAIL_MANAGE);
    const domain = await activeDomain(domainId);
    const current = await loadForwarder(domainId, id);
    const { job } = await change(actor, domain.server_id, (trx) => trx('mail_forwarders').where({ id }).delete());
    await audit.record({ actor, action: 'mail_forwarder.delete', target: { type: 'mail_forwarder', id, label: current.address }, metadata: { jobId: job?.id } });
    return { domain: await domainDetail(domainId), job };
  }

  // ---- Job results --------------------------------------------------------

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'mail_server') return;
    const row = await db('mail_servers').where({ id: job.resource_id }).first();
    if (!row) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };
    const params = fromJson(job.params, {});

    if (job.type === 'MAIL_SETUP') {
      await db('mail_servers')
        .where({ id: row.id })
        .update({ ...failure, ...(ok ? { status: 'active', tls: output?.tls ?? null } : { status: row.applied_serial !== null ? 'active' : 'failed' }), updated_at: now });
      if (ok) await queueApply(systemActor('mail server set up'), row.server_id, { force: true }).catch((err) => logger.warn({ err, serverId: row.server_id }, 'could not send the email settings'));
      return;
    }

    if (job.type === 'MAIL_USAGE') {
      if (!ok) return;
      for (const m of output?.mailboxes ?? []) {
        await db('mailboxes').where({ address: m.address }).update({ used_bytes: Math.max(0, Math.round(Number(m.bytes) || 0)), usage_checked_at: now });
      }
      return;
    }

    if (job.type !== 'MAIL_APPLY') return;
    const sent = Number(params.serial ?? 0);
    const confirmed = Number(output?.serial ?? sent);
    const applied = ok ? Math.max(Number(row.applied_serial ?? 0), confirmed) : row.applied_serial;
    await db('mail_servers').where({ id: row.id }).update({ ...failure, ...(ok ? { applied_serial: applied, applied_at: now } : {}), updated_at: now });
    if (!ok) {
      logger.info({ serverId: row.server_id, error }, 'email settings apply failed');
      return;
    }
    if (output?.skipped) return;

    // Stored mail the server deleted.
    if (Array.isArray(params.purge) && params.purge.length) {
      await db.transaction((trx) => removePurge(trx, row.server_id, params.purge));
    }
    // Domains the server no longer has.
    const kept = new Set((params.domains ?? []).map((d) => d.domain));
    const gone = await db('mail_domains').where({ server_id: row.server_id, status: 'deleting' }).whereNull('deleted_at');
    for (const d of gone.filter((g) => !kept.has(g.domain))) {
      await db.transaction(async (trx) => {
        await trx('mailboxes').where({ domain_id: d.id }).delete();
        await trx('mail_forwarders').where({ domain_id: d.id }).delete();
        await trx('mail_domains').where({ id: d.id }).update({ domain_key: null, deleted_at: now, updated_at: now });
      });
    }
    // DKIM keys the server made: their records go into the DNS zone.
    for (const key of output?.dkim ?? []) {
      const domain = await db('mail_domains').where({ server_id: row.server_id, domain: key.domain, status: 'active' }).whereNull('deleted_at').first();
      if (!domain || domain.dkim_selector !== key.selector || domain.dkim_public_key === key.publicKey) continue;
      await db('mail_domains').where({ id: domain.id }).update({ dkim_public_key: key.publicKey, updated_at: now });
      if (domain.auto_dns) await putDnsRecords(systemActor('email DNS records'), { ...domain, hostname: row.hostname, dkim_public_key: key.publicKey });
    }
    // Changes made while this one was on its way.
    if (Number(row.serial) > applied) {
      await queueApply(systemActor('email changes'), row.server_id).catch((err) => logger.warn({ err, serverId: row.server_id }, 'could not send the newer email settings'));
    }
  }

  async function summary() {
    const [domains, mailboxes] = await Promise.all([domainQuery().clearSelect().count({ n: '*' }).first(), db('mailboxes').count({ n: '*' }).first()]);
    return { domains: Number(domains?.n ?? 0), mailboxes: Number(mailboxes?.n ?? 0) };
  }

  jobs.onFinished(handleJobFinished);

  return {
    listServers,
    setupServer,
    applyServer,
    checkServer,
    refreshUsage,
    listDomains,
    getDomain,
    createDomain,
    removeDomain,
    addDnsRecords,
    checkDomainDns,
    createMailbox,
    updateMailbox,
    removeMailbox,
    createForwarder,
    updateForwarder,
    removeForwarder,
    summary,
    handleJobFinished,
  };
}
