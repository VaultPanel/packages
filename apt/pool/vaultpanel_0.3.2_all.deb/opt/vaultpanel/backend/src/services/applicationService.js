import { randomBytes, randomUUID } from 'node:crypto';
import {
  APP_BUSY_STATUSES,
  APP_RUNTIMES,
  DEPLOY_ERROR_STAGES,
  PERMISSIONS,
  RESERVED_APP_PORTS,
  APP_PORT_MAX,
  NEW_RUNTIMES_MIN_AGENT_VERSION,
  SINGLE_PROCESS_RUNTIMES,
  ZERO_DOWNTIME_MIN_AGENT_VERSION,
  applicationProblems,
  envProblems,
} from '@vaultpanel/shared';
import { toPublicApplication, toPublicDeployment } from '../models/applicationModel.js';
import { toPublicJob } from '../models/jobModel.js';
import { findServer } from '../models/serverModel.js';
import { createSecretBox, deriveKey, newToken, sha256Hex } from '../utils/crypto.js';
import { checkHookSignature, PUSH_EVENTS, pushedRef } from '../utils/hookSignature.js';
import { compareVersions } from '../utils/agentPackage.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { scopeQuery } from './tenancy.js';
import { systemActor } from './actor.js';

// Applications: Node.js and Python apps deployed from Git and kept running by
// PM2 under systemd, each as its own Linux user.
//
// The application row holds the app's settings (what the next deploy or
// restart uses) and what is live on the server: the current release, and the
// process state the agent reports. Each deploy or rollback is a deployment
// row whose logs are its job's logs. Like websites, an app is "busy" while a
// change runs, and only one change runs at a time.
//
// An app can have a website: an NGINX reverse proxy from its domains to its
// port, with the same name. Domains and SSL are managed on that website.

const PROCESS_TYPES = ['CONFIGURE_APPLICATION', 'START_APPLICATION', 'STOP_APPLICATION', 'RESTART_APPLICATION'];
const HISTORY_TYPES = ['CREATE_APPLICATION', 'DEPLOY_GIT', 'ROLLBACK_APPLICATION', 'DELETE_APPLICATION', ...PROCESS_TYPES];
const SETTING_COLUMNS = {
  repositoryUrl: 'repository_url',
  branch: 'branch',
  installCommand: 'install_command',
  buildCommand: 'build_command',
  startCommand: 'start_command',
  port: 'port',
  keepReleases: 'keep_releases',
  healthCheckSeconds: 'health_check_seconds',
  cpuLimitPercent: 'cpu_limit_percent',
  memoryLimitMb: 'memory_limit_mb',
  instances: 'instances',
  zeroDowntime: 'zero_downtime',
};
// Settings the running process uses; changing them needs a restart.
const PROCESS_SETTINGS = ['startCommand', 'port', 'healthCheckSeconds', 'cpuLimitPercent', 'memoryLimitMb', 'instances', 'zeroDowntime'];
// Running several copies of an app needs this agent version.
export const INSTANCES_MIN_AGENT_VERSION = '0.14.0';

export function createApplicationService({ db, config, logger, audit, authorize, jobs, websites, quotas, ports }) {
  const envBox = createSecretBox(deriveKey(config.secretKey, 'app-env'));
  const hookBox = createSecretBox(deriveKey(config.secretKey, 'git-webhook'));

  // ---- Reading ------------------------------------------------------------

  function appQuery() {
    return db('applications as a')
      .join('servers as s', 's.id', 'a.server_id')
      .leftJoin('websites as w', (j) => j.on('w.id', 'a.website_id').andOnNull('w.deleted_at'))
      .leftJoin('website_domains as d', (j) => j.on('d.website_id', 'w.id').andOn('d.is_primary', db.raw('?', [true])))
      .whereNull('a.deleted_at')
      .whereNull('s.deleted_at')
      .select('a.*', 's.name as server_name', 's.status as server_status', 'd.domain as primary_domain');
  }

  async function load(id) {
    const row = await appQuery().where('a.id', id).first();
    if (!row) throw notFound('Application not found');
    return row;
  }

  async function detail(id) {
    const row = await load(id);
    const [website, keys] = await Promise.all([
      row.website_id ? websites.describe(row.website_id).catch(() => null) : null,
      db('environment_variables').where({ application_id: id }).orderBy('key').pluck('key'),
    ]);
    return toPublicApplication(row, { website, envKeys: keys });
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const q = scopeQuery(appQuery(), actor, 'a.customer_id');
    if (query.serverId) q.where('a.server_id', query.serverId);
    if (query.status) q.where('a.status', query.status);
    if (query.runtime) q.where('a.runtime', query.runtime);
    if (query.search) {
      const term = `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) => w.where('a.name', 'like', term).orWhere('a.repository_url', 'like', term).orWhere('d.domain', 'like', term));
    }
    const { rows, pagination } = await paginate(q, query, { createdAt: 'a.created_at', name: 'a.name', lastDeployedAt: 'a.last_deployed_at' });
    return { items: rows.map((r) => toPublicApplication(r)), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const application = await detail(id);
    const [deployments, recentJobs] = await Promise.all([
      deploymentQuery().where('dp.application_id', id).orderBy('dp.created_at', 'desc').limit(10),
      db('jobs as j')
        .leftJoin('users as u', 'u.id', 'j.requested_by')
        .select('j.*', 'u.email as requested_by_email')
        .where({ 'j.resource_type': 'application', 'j.resource_id': id })
        .whereIn('j.type', HISTORY_TYPES)
        .orderBy('j.created_at', 'desc')
        .limit(10),
    ]);
    return { ...application, deployments: deployments.map(toPublicDeployment), recentJobs: recentJobs.map(toPublicJob) };
  }

  // A free port for a new app on a server: for a hosting customer, the first
  // free one of their own ports (with all of them, as `pool`); for staff, the
  // first from 3000 up that no app, site or customer holds.
  async function suggestPort(actor, serverId) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const account = await quotas.homeFor(actor, serverId);
    if (account) {
      await ports.sync(account.customer.id);
      const pool = await ports.forServer(account.customer.id, serverId);
      return { port: pool.free[0] ?? null, pool };
    }
    const [appPorts, sitePorts, poolPorts] = await Promise.all([
      db('applications').where({ server_id: serverId }).whereNotNull('port_key').pluck('port_key'),
      db('websites').where({ server_id: serverId }).whereNull('deleted_at').whereNotNull('proxy_port').pluck('proxy_port'),
      db('customer_ports').where({ server_id: serverId }).pluck('port'),
    ]);
    const used = new Set([...appPorts, ...sitePorts, ...poolPorts, ...RESERVED_APP_PORTS].map(Number));
    for (let port = 3000; port <= APP_PORT_MAX; port += 1) if (!used.has(port)) return { port, pool: null };
    return { port: null, pool: null };
  }

  // ---- Checks -------------------------------------------------------------

  function requireServerReady(server) {
    if (!server || server.deleted_at) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') {
      throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    }
  }

  // What the server needs to deploy an app, as its agent last reported.
  function requireSoftware(server, runtime) {
    const stack = fromJson(server.web_stack, null);
    if (!stack) return;
    const missing = [];
    if (stack.git === false) missing.push('Git');
    if (stack.pm2 === false) missing.push('PM2');
    if (runtime === 'python' && !stack.python && 'python' in stack) missing.push('Python');
    if (stack.git === undefined && stack.pm2 === undefined) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} is too old to run apps. Update it from the server page.`);
    }
    if (SINGLE_PROCESS_RUNTIMES.includes(runtime)) {
      requireAgentVersion(server, NEW_RUNTIMES_MIN_AGENT_VERSION, `${APP_RUNTIMES[runtime].label} apps`);
      if (!stack[runtime]) missing.push(APP_RUNTIMES[runtime].label);
    }
    if (stack.nodeInHome) {
      throw new AppError(409, 'NODE_IN_HOME_FOLDER', `Node.js on ${server.name} is installed in a home folder (for example by nvm), so apps cannot use it. Install Node.js system-wide; the server page shows how.`);
    }
    if (missing.length) {
      throw new AppError(409, 'SOFTWARE_MISSING', `${missing.join(' and ')} ${missing.length > 1 ? 'are' : 'is'} not installed on ${server.name}. Install ${missing.length > 1 ? 'them' : 'it'} from the Software card on the server page.`, { missing });
    }
  }

  function requireIdle(row) {
    if (APP_BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'APPLICATION_BUSY', 'Another change to this app is still running. Wait for it to finish.', { jobId: row.last_job_id });
    }
  }

  function requireProvisioned(row) {
    requireIdle(row);
    if (!row.provisioned_at) {
      throw new AppError(409, 'APPLICATION_NOT_READY', 'This app was never set up on its server. Deploy it to set it up, or delete it.');
    }
  }

  function requireDeployed(row) {
    requireProvisioned(row);
    if (!row.current_release_id) throw new AppError(409, 'APPLICATION_NOT_DEPLOYED', 'This app has not been deployed yet. Deploy it first.');
  }

  // customerId: who owns the app (null: staff); its port must be one of
  // that account's ports, and staff apps cannot take a customer's port.
  async function checkSettings(serverId, values, appId = null, customerId = null) {
    const problems = applicationProblems(values);
    if (values.port) {
      const [app, site] = await Promise.all([
        db('applications').where({ server_id: serverId, port_key: values.port }).modify((q) => appId && q.whereNot('id', appId)).first('name'),
        db('websites as w')
          .where({ 'w.server_id': serverId, 'w.proxy_port': values.port })
          .whereNull('w.deleted_at')
          .modify((q) => appId && q.whereNotExists(db('applications as a').whereRaw('a.website_id = w.id').where('a.id', appId)))
          .first('w.name'),
      ]);
      if (app) problems.push({ field: 'port', message: `Port ${values.port} is used by the app ${app.name}` });
      else if (site) problems.push({ field: 'port', message: `The site ${site.name} already proxies to port ${values.port}` });
    }
    if (problems.length) throw validationError(problems);
    if (values.port) await ports.check(customerId, serverId, values.port);
  }

  // ---- Environment variables ---------------------------------------------

  async function envEntries(appId) {
    const rows = await db('environment_variables').where({ application_id: appId }).orderBy('key');
    return rows.map((r) => ({ key: r.key, value: envBox.open(r.value_encrypted) }));
  }

  async function writeEnv(trx, appId, variables, now) {
    await trx('environment_variables').where({ application_id: appId }).delete();
    if (variables.length) {
      await trx('environment_variables').insert(
        variables.map(({ key, value }) => ({ id: randomUUID(), application_id: appId, key, value_encrypted: envBox.seal(value), created_at: now, updated_at: now })),
      );
    }
  }

  async function getEnv(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    const variables = await envEntries(id);
    await audit.record({ actor, action: 'application.env_view', target: target(row), metadata: { count: variables.length } });
    return { variables };
  }

  async function setEnv(actor, id, { variables }) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const problems = envProblems(variables);
    if (problems.length) throw validationError(problems);
    const before = await envEntries(id);
    const now = new Date();
    await db.transaction(async (trx) => {
      await writeEnv(trx, id, variables, now);
      await trx('applications').where({ id }).update({ config_changed_at: now, updated_at: now });
    });
    const keys = (list) => new Map(list.map((v) => [v.key, v.value]));
    const [old, next] = [keys(before), keys(variables)];
    await audit.record({
      actor,
      action: 'application.env_update',
      target: target(row),
      // Names only: values may be secrets.
      metadata: {
        added: [...next.keys()].filter((k) => !old.has(k)),
        changed: [...next.keys()].filter((k) => old.has(k) && old.get(k) !== next.get(k)),
        removed: [...old.keys()].filter((k) => !next.has(k)),
      },
    });
    return { application: await detail(id) };
  }

  // Adds variables the app does not have yet (a new database's connection
  // settings). Existing variables are left alone. Returns the added keys.
  async function addEnv(actor, id, entries) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    const existing = new Set(await db('environment_variables').where({ application_id: id }).pluck('key'));
    const added = entries.filter((e) => !existing.has(e.key));
    if (!added.length) return [];
    const now = new Date();
    await db.transaction(async (trx) => {
      await trx('environment_variables').insert(
        added.map(({ key, value }) => ({ id: randomUUID(), application_id: id, key, value_encrypted: envBox.seal(value), created_at: now, updated_at: now })),
      );
      await trx('applications').where({ id }).update({ config_changed_at: now, updated_at: now });
    });
    await audit.record({ actor, action: 'application.env_update', target: target(row), metadata: { added: added.map((e) => e.key), changed: [], removed: [] } });
    return added.map((e) => e.key);
  }

  // ---- Building agent parameters ------------------------------------------

  async function processParams(row) {
    const env = await envEntries(row.id);
    const params = {
      name: row.name,
      runtime: row.runtime,
      startCommand: row.start_command,
      env: env.map(({ key, value }) => `${key}=${value}`),
      healthCheckSeconds: row.health_check_seconds,
    };
    if (row.port) params.port = row.port;
    if (row.cpu_limit_percent) params.cpuPercent = row.cpu_limit_percent;
    if (row.memory_limit_mb) params.memoryMb = row.memory_limit_mb;
    // Older agents do not know the parameter; one copy is what they run.
    if (row.instances > 1) params.instances = row.instances;
    if (row.zero_downtime) params.zeroDowntime = true;
    return params;
  }

  const controlParams = (row, verb) => ({
    name: row.name,
    ...(row.port ? { port: row.port } : {}),
    healthCheckSeconds: row.health_check_seconds,
    ...(verb === 'restart' && row.zero_downtime ? { zeroDowntime: true } : {}),
  });

  // ---- Changes ------------------------------------------------------------

  // Marks the app busy, queues the job and links them. If the job cannot be
  // queued (agent offline or outdated...), the app is put back.
  async function startChange(actor, row, { action, type, params, status = 'updating', onQueued = null }) {
    const claimed = await db('applications')
      .where({ id: row.id })
      .whereNotIn('status', APP_BUSY_STATUSES)
      .update({ status, pending_action: action, last_error_code: null, last_error: null, updated_at: new Date() });
    if (!claimed) requireIdle({ ...row, status: 'updating' });
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type, params, resource: { type: 'application', id: row.id } }, { internal: true });
    } catch (err) {
      await db('applications').where({ id: row.id }).update({ status: row.status, pending_action: null, updated_at: new Date() });
      throw err;
    }
    await db('applications').where({ id: row.id }).update({ last_job_id: job.id });
    if (onQueued) await onQueued(job);
    return job;
  }

  // A hosting customer's app goes on their account's server, counts against
  // their plan and gets the plan's CPU and memory caps.
  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    await quotas.homeFor(actor, input.serverId);
    return quotas.reserve(actor.customerId, ['applications'], (account) => createChecked(actor, input, account));
  }

  async function createChecked(actor, input, account) {
    const limits = account ? quotas.capAppLimits(account.plan, {}) : {};
    const server = await findServer(db, input.serverId);
    requireServerReady(server);
    requireSoftware(server, input.runtime);
    const domains = input.domains ?? [];
    if (domains.length && !input.port) throw validationError([{ field: 'port', message: 'An app with a domain needs the port it listens on' }]);
    const envList = input.env ?? [];
    const problems = envProblems(envList);
    if (problems.length) throw validationError(problems);
    // The account's lock is held here (quotas.reserve), so its ports cannot change underneath.
    if (account) await ports.sync(account.customer.id, { locked: true });
    await checkSettings(server.id, input, null, account?.customer.id ?? null);
    const [appTaken, siteTaken] = await Promise.all([
      db('applications').where({ server_id: server.id, name_key: input.name }).first('id'),
      db('websites').where({ server_id: server.id, name_key: input.name }).first('id'),
    ]);
    if (appTaken || siteTaken) {
      throw validationError([{ field: 'name', message: `${input.name} is already used by ${appTaken ? 'an app' : 'a website'} on ${server.name}. Each app and site has its own Linux user, so names must differ.` }]);
    }
    if (domains.length) {
      await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
      await websites.checkNew({ serverId: server.id, name: input.name, type: 'proxy', domains, proxyPort: input.port }, { forApplication: true });
    }

    const id = randomUUID();
    const now = new Date();
    try {
      await db.transaction(async (trx) => {
        await trx('applications').insert({
          id,
          server_id: server.id,
          name: input.name,
          name_key: input.name,
          runtime: input.runtime,
          repository_url: input.repositoryUrl,
          branch: input.branch,
          install_command: input.installCommand || null,
          build_command: input.buildCommand || APP_RUNTIMES[input.runtime].defaultBuildCommand || null,
          start_command: input.startCommand || APP_RUNTIMES[input.runtime].defaultStartCommand,
          port: input.port ?? null,
          port_key: input.port ?? null,
          keep_releases: input.keepReleases,
          health_check_seconds: input.healthCheckSeconds,
          cpu_limit_percent: limits.cpuLimitPercent ?? null,
          memory_limit_mb: limits.memoryLimitMb ?? null,
          customer_id: account?.customer.id ?? null,
          status: 'creating',
          pending_action: 'create',
          config_changed_at: now,
          created_by: actor.type === 'user' ? actor.id : null,
          created_at: now,
          updated_at: now,
        });
        await writeEnv(trx, id, envList, now);
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'name', message: 'This name or port was just taken by another app' }]);
      throw err;
    }
    // With no app limit, the account always keeps one free port.
    if (account) await ports.sync(account.customer.id, { locked: true }).catch((err) => logger.warn({ err, applicationId: id }, 'could not update the customer ports'));

    let job;
    try {
      job = await jobs.create(actor, { serverId: server.id, type: 'CREATE_APPLICATION', params: { name: input.name, runtime: input.runtime }, resource: { type: 'application', id } }, { internal: true });
    } catch (err) {
      // Nothing was queued, so nothing exists on the server: drop the record.
      await db('applications').where({ id }).delete();
      throw err;
    }
    await db('applications').where({ id }).update({ last_job_id: job.id });

    // The agent runs one job at a time in order: the app's user and folders
    // first, then its website, then the first deployment.
    if (domains.length) {
      try {
        const { website } = await websites.create(actor, { serverId: server.id, name: input.name, type: 'proxy', domains, proxyPort: input.port }, { forApplication: true, customerId: account?.customer.id ?? null });
        await db('applications').where({ id }).update({ website_id: website.id });
      } catch (err) {
        logger.warn({ err, applicationId: id }, 'could not add the app website');
        await db('applications').where({ id }).update({ last_error_code: 'WEBSITE_FAILED', last_error: `The app was saved, but its domains could not be added: ${err.message}` });
      }
    }
    let deployment = null;
    if (input.deployNow) {
      try {
        ({ deployment } = await queueDeploy(actor, await load(id), { trigger: 'create', afterCreate: true }));
      } catch (err) {
        logger.warn({ err, applicationId: id }, 'could not queue the first deployment');
      }
    }
    await audit.record({
      actor,
      action: 'application.create',
      target: { type: 'application', id, label: input.name },
      metadata: { serverId: server.id, runtime: input.runtime, repositoryUrl: input.repositoryUrl, branch: input.branch, port: input.port ?? null, domains, envKeys: envList.map((v) => v.key), jobId: job.id },
    });
    return { application: await detail(id), job, deployment };
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const next = {};
    for (const [key, column] of Object.entries(SETTING_COLUMNS)) {
      if (changes[key] === undefined) continue;
      const value = changes[key] === '' ? null : changes[key];
      if ((row[column] ?? null) !== value) next[key] = value;
    }
    // A customer's app stays within its plan's CPU and memory caps.
    if (row.customer_id && ('cpuLimitPercent' in next || 'memoryLimitMb' in next)) {
      const { plan } = await quotas.loadAccount(row.customer_id);
      const capped = quotas.capAppLimits(plan, { cpuLimitPercent: row.cpu_limit_percent, memoryLimitMb: row.memory_limit_mb, ...next }, { explicit: next });
      for (const key of ['cpuLimitPercent', 'memoryLimitMb']) if (key in next) next[key] = capped[key];
    }
    if (!Object.keys(next).length) return { application: await detail(id), changed: [] };
    if ('startCommand' in next && !next.startCommand) throw validationError([{ field: 'startCommand', message: 'Enter the command that starts the app' }]);
    if ('port' in next && next.port === null && row.website_id) {
      throw validationError([{ field: 'port', message: 'This app has domains, so it needs a port. Delete its website first to run it without one.' }]);
    }
    await checkSettings(row.server_id, next, id, row.customer_id);
    if (next.instances > 1) await requireInstancesSupport(row.server_id);
    if (next.instances > 1 && SINGLE_PROCESS_RUNTIMES.includes(row.runtime)) {
      throw validationError([{ field: 'instances', message: `${APP_RUNTIMES[row.runtime].label} apps run as one process. Start more workers inside the app instead.` }]);
    }
    if (next.zeroDowntime) {
      if (row.runtime !== 'node') throw validationError([{ field: 'zeroDowntime', message: 'Zero-downtime reloads are for Node.js apps' }]);
      requireAgentVersion(await findServer(db, row.server_id), ZERO_DOWNTIME_MIN_AGENT_VERSION, 'Zero-downtime reloads');
    }
    const now = new Date();
    const update = { updated_at: now };
    for (const [key, value] of Object.entries(next)) update[SETTING_COLUMNS[key]] = value;
    if ('port' in next) update.port_key = next.port;
    if (Object.keys(next).some((k) => PROCESS_SETTINGS.includes(k))) update.config_changed_at = now;
    try {
      await db('applications').where({ id }).update(update);
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'port', message: 'This port was just taken by another app' }]);
      throw err;
    }
    await audit.record({ actor, action: 'application.update', target: target(row), metadata: { changes: next } });
    return { application: await detail(id), changed: Object.keys(next) };
  }

  function requireAgentVersion(server, version, what) {
    if (!server?.agent_version || compareVersions(server.agent_version, version) < 0) {
      throw new AppError(409, 'AGENT_OUTDATED', `${what} need agent v${version} or later; ${server?.name ?? 'this server'} runs v${server?.agent_version ?? '?'}. Update the agent from the server page first.`);
    }
  }

  async function requireInstancesSupport(serverId) {
    const server = await findServer(db, serverId);
    if (!server?.agent_version || compareVersions(server.agent_version, INSTANCES_MIN_AGENT_VERSION) < 0) {
      throw new AppError(
        409,
        'AGENT_OUTDATED',
        `Running several copies of an app needs agent v${INSTANCES_MIN_AGENT_VERSION} or later; ${server?.name ?? 'this server'} runs v${server?.agent_version ?? '?'}. Update the agent from the server page first.`,
      );
    }
  }

  // Sets how many copies of the app run, and puts it into effect: a running
  // app is reconfigured (in cluster mode PM2 adds or removes copies while
  // the others keep serving), a stopped or undeployed one uses it next time
  // it starts.
  async function scale(actor, id, { instances }) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const { application, changed } = await update(actor, id, { instances });
    const row = await load(id);
    if (!changed.length || !row.current_release_id || row.process_state !== 'running') return { application, job: null };
    const job = await startChange(actor, row, { action: 'configure', type: 'CONFIGURE_APPLICATION', params: { ...(await processParams(row)), restart: true } });
    await audit.record({ actor, action: 'application.scale', target: target(row), metadata: { instances, jobId: job.id } });
    return { application: await detail(id), job };
  }

  // ---- Deploying ----------------------------------------------------------

  function newReleaseId(now = new Date()) {
    const stamp = now.toISOString().replace(/[-:T]/g, '').slice(0, 14);
    return `${stamp}-${randomBytes(3).toString('hex')}`;
  }

  async function queueDeploy(actor, row, { trigger, afterCreate = false }) {
    const server = await findServer(db, row.server_id);
    requireServerReady(server);
    requireSoftware(server, row.runtime);
    const releaseId = newReleaseId();
    const params = {
      ...(await processParams(row)),
      repository: row.repository_url,
      branch: row.branch,
      releaseId,
      keepReleases: row.keep_releases,
    };
    if (row.install_command) params.installCommand = row.install_command;
    if (row.build_command) params.buildCommand = row.build_command;

    const deploymentId = randomUUID();
    const now = new Date();
    await db('deployments').insert({
      id: deploymentId,
      application_id: row.id,
      server_id: row.server_id,
      kind: 'deploy',
      trigger,
      status: 'queued',
      release_id: releaseId,
      repository_url: row.repository_url,
      branch: row.branch,
      requested_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    let job;
    try {
      if (afterCreate) {
        // The app is still being set up; it shows as deploying once that is done.
        job = await jobs.create(actor, { serverId: row.server_id, type: 'DEPLOY_GIT', params, resource: { type: 'application', id: row.id } }, { internal: true });
      } else {
        job = await startChange(actor, row, { action: 'deploy', type: 'DEPLOY_GIT', params, status: 'deploying' });
      }
    } catch (err) {
      await db('deployments').where({ id: deploymentId }).delete();
      throw err;
    }
    await db('deployments').where({ id: deploymentId }).update({ job_id: job.id });
    return { job, deployment: await deploymentById(deploymentId) };
  }

  async function deploy(actor, id, { trigger = 'manual' } = {}) {
    await authorize(actor, PERMISSIONS.APPS_DEPLOY);
    const row = await load(id);
    requireIdle(row);
    if (!row.provisioned_at && row.status !== 'failed') requireProvisioned(row);
    const { job, deployment } = await queueDeploy(actor, row, { trigger });
    await audit.record({ actor, action: 'application.deploy', target: target(row), metadata: { trigger, branch: row.branch, releaseId: deployment.releaseId, deploymentId: deployment.id, jobId: job.id } });
    return { application: await detail(id), deployment, job };
  }

  async function rollback(actor, id, { deploymentId }) {
    await authorize(actor, PERMISSIONS.APPS_DEPLOY);
    const row = await load(id);
    requireDeployed(row);
    const source = await db('deployments').where({ id: deploymentId, application_id: id }).first();
    if (!source) throw notFound('Deployment not found');
    if (source.status !== 'succeeded' && source.release_id !== row.current_release_id) {
      throw new AppError(409, 'RELEASE_NOT_DEPLOYABLE', 'Only releases that deployed successfully can be rolled back to');
    }
    if (source.release_id === row.current_release_id) throw new AppError(409, 'RELEASE_ALREADY_LIVE', 'This release is already live');
    if (!source.release_available) {
      throw new AppError(409, 'RELEASE_NOT_FOUND', 'This release is no longer on the server (only the newest releases are kept). Deploy its commit again instead.');
    }
    const newId = randomUUID();
    const now = new Date();
    await db('deployments').insert({
      id: newId,
      application_id: id,
      server_id: row.server_id,
      kind: 'rollback',
      trigger: 'rollback',
      status: 'queued',
      release_id: source.release_id,
      source_deployment_id: source.id,
      repository_url: source.repository_url,
      branch: source.branch,
      commit_hash: source.commit_hash,
      commit_message: source.commit_message,
      commit_author: source.commit_author,
      release_available: true,
      requested_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    let job;
    try {
      job = await startChange(actor, row, { action: 'rollback', type: 'ROLLBACK_APPLICATION', params: { ...(await processParams(row)), releaseId: source.release_id }, status: 'deploying' });
    } catch (err) {
      await db('deployments').where({ id: newId }).delete();
      throw err;
    }
    await db('deployments').where({ id: newId }).update({ job_id: job.id });
    await audit.record({ actor, action: 'application.rollback', target: target(row), metadata: { releaseId: source.release_id, fromReleaseId: row.current_release_id, deploymentId: newId, jobId: job.id } });
    return { application: await detail(id), deployment: await deploymentById(newId), job };
  }

  // ---- Process control ----------------------------------------------------

  async function control(actor, id, verb) {
    await authorize(actor, PERMISSIONS.APPS_DEPLOY);
    const row = await load(id);
    requireDeployed(row);
    const type = { start: 'START_APPLICATION', stop: 'STOP_APPLICATION', restart: 'RESTART_APPLICATION' }[verb];
    const params = verb === 'stop' ? { name: row.name } : controlParams(row, verb);
    const job = await startChange(actor, row, { action: verb, type, params });
    await audit.record({ actor, action: `application.${verb}`, target: target(row), metadata: { jobId: job.id } });
    return { application: await detail(id), job };
  }

  // Writes the saved start command, port and environment to the server and
  // restarts the app with them.
  async function apply(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    requireDeployed(row);
    const job = await startChange(actor, row, { action: 'configure', type: 'CONFIGURE_APPLICATION', params: { ...(await processParams(row)), restart: true } });
    await audit.record({ actor, action: 'application.apply', target: target(row), metadata: { jobId: job.id } });
    return { application: await detail(id), job };
  }

  async function refresh(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const row = await load(id);
    if (!row.provisioned_at) throw new AppError(409, 'APPLICATION_NOT_READY', 'This app is not set up on its server yet');
    return jobs.create(actor, { serverId: row.server_id, type: 'APP_STATUS', params: { name: row.name }, resource: { type: 'application', id } }, { internal: true });
  }

  async function logs(actor, id, { log, lines }) {
    await authorize(actor, PERMISSIONS.APPS_LOGS);
    const row = await load(id);
    if (!row.provisioned_at) throw new AppError(409, 'APPLICATION_NOT_READY', 'This app is not set up on its server yet');
    return jobs.create(actor, { serverId: row.server_id, type: 'APP_LOGS', params: { name: row.name, log, lines }, resource: { type: 'application', id } }, { internal: true });
  }

  // ---- Domains ------------------------------------------------------------

  // Gives an app without a website one: a reverse proxy to its port.
  async function addWebsite(actor, id, { domains }) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    if (row.website_id) throw new AppError(409, 'APPLICATION_HAS_WEBSITE', 'This app already has a website. Add domains to it on its website page.');
    if (!row.port) throw validationError([{ field: 'port', message: 'Set the port the app listens on first (in Settings)' }]);
    const { website, job } = await websites.create(actor, { serverId: row.server_id, name: row.name, type: 'proxy', domains, proxyPort: row.port }, { forApplication: true, customerId: row.customer_id });
    await db('applications').where({ id }).update({ website_id: website.id, updated_at: new Date() });
    await audit.record({ actor, action: 'application.website_add', target: target(row), metadata: { websiteId: website.id, domains } });
    return { application: await detail(id), website, job };
  }

  // ---- Webhook (push to deploy) ------------------------------------------

  async function enableWebhook(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    const token = newToken(24);
    const secret = newToken(24);
    const now = new Date();
    await db('applications')
      .where({ id })
      .update({ webhook_token_hash: sha256Hex(token), webhook_secret_encrypted: hookBox.seal(secret), webhook_created_at: now, updated_at: now });
    await audit.record({ actor, action: row.webhook_token_hash ? 'application.webhook_rotate' : 'application.webhook_enable', target: target(row) });
    // The URL and secret are shown once; the URL's hash and the encrypted
    // secret (needed to check signatures) are stored.
    return { application: await detail(id), webhook: { url: `${config.publicUrl}/api/v1/hooks/deploy/${token}`, secret } };
  }

  async function disableWebhook(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    await db('applications').where({ id }).update({ webhook_token_hash: null, webhook_secret_encrypted: null, webhook_created_at: null, updated_at: new Date() });
    await audit.record({ actor, action: 'application.webhook_disable', target: target(row) });
    return { application: await detail(id) };
  }

  // Called by GitHub, GitLab or anything else that can POST on a push. The
  // token in the URL finds the app; the signature (or GitLab token) made
  // with the webhook's secret proves the request. Webhooks from before
  // secrets existed have none and work on the URL alone. Pushes to other
  // branches are ignored.
  async function deployFromHook(token, body, { event = null, get = () => null, rawBody } = {}) {
    const row = await db('applications').where({ webhook_token_hash: sha256Hex(token) }).whereNull('deleted_at').first();
    if (!row) throw notFound('Unknown webhook');
    if (row.webhook_secret_encrypted) {
      const check = checkHookSignature({ secret: hookBox.open(row.webhook_secret_encrypted), get, rawBody });
      if (!check.ok) {
        await audit.record({ actor: systemActor('push-to-deploy webhook'), action: 'application.webhook_rejected', target: target(row), metadata: { reason: check.reason } });
        throw new AppError(401, 'WEBHOOK_SIGNATURE_INVALID', check.reason);
      }
    }
    // GitHub, Gitea and GitLab name the event in a header; only pushes deploy.
    if (event && !PUSH_EVENTS.includes(String(event).toLowerCase())) {
      return { ignored: true, reason: ['ping', 'diagnostics:ping'].includes(event) ? 'Ping received. Pushes will deploy the app.' : `Ignored a ${event} event; only pushes deploy` };
    }
    if (!event && (body?.zen || body?.hook_id)) return { ignored: true, reason: 'Ping received. Pushes will deploy the app.' };
    const ref = pushedRef(body);
    if (ref && ref !== `refs/heads/${row.branch}`) return { ignored: true, reason: `Push to ${ref}; this app deploys ${row.branch}` };
    const { deployment } = await deploy(systemActor('push-to-deploy webhook'), row.id, { trigger: 'webhook' });
    return { ignored: false, deploymentId: deployment.id, releaseId: deployment.releaseId };
  }

  // ---- Deleting -----------------------------------------------------------

  async function remove(actor, id, { removeFiles }) {
    await authorize(actor, PERMISSIONS.APPS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const website = row.website_id ? await db('websites').where({ id: row.website_id }).whereNull('deleted_at').first() : null;
    if (website) await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const job = await startChange(actor, row, { action: 'delete', type: 'DELETE_APPLICATION', params: { name: row.name, removeFiles, removeSite: Boolean(website) }, status: 'deleting' });
    await audit.record({ actor, action: 'application.delete', target: target(row), metadata: { removeFiles, websiteId: website?.id ?? null, jobId: job.id } });
    return { application: await detail(id), job };
  }

  // ---- Deployments --------------------------------------------------------

  function deploymentQuery() {
    return db('deployments as dp')
      .join('applications as a', 'a.id', 'dp.application_id')
      .join('servers as s', 's.id', 'dp.server_id')
      .leftJoin('jobs as j', 'j.id', 'dp.job_id')
      .leftJoin('users as u', 'u.id', 'dp.requested_by')
      .whereNull('s.deleted_at')
      .select(
        'dp.*',
        'a.name as application_name',
        'a.current_deployment_id',
        's.name as server_name',
        'j.status as job_status',
        'j.started_at as job_started_at',
        'j.output as job_output',
        'u.email as requested_by_email',
      );
  }

  async function deploymentById(id) {
    const row = await deploymentQuery().where('dp.id', id).first();
    return row ? toPublicDeployment(row) : null;
  }

  async function listDeployments(actor, query) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const q = scopeQuery(deploymentQuery().whereNull('a.deleted_at'), actor, 'a.customer_id');
    if (query.applicationId) q.where('dp.application_id', query.applicationId);
    if (query.serverId) q.where('dp.server_id', query.serverId);
    if (query.status === 'running') q.where('dp.status', 'queued');
    else if (query.status) q.where('dp.status', query.status);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'dp.created_at' });
    return { items: rows.map(toPublicDeployment), pagination };
  }

  async function getDeployment(actor, id) {
    await authorize(actor, PERMISSIONS.APPS_READ);
    const deployment = await deploymentById(id);
    if (!deployment) throw notFound('Deployment not found');
    return deployment;
  }

  // ---- Job results --------------------------------------------------------

  // The state an app settles in after a change: ready, or deploying when its
  // first deployment is queued behind the setup.
  async function settle(row, extra = {}, now = new Date()) {
    const provisioned = extra.provisioned_at ?? row.provisioned_at;
    const waiting = await db('deployments as dp')
      .join('jobs as j', 'j.id', 'dp.job_id')
      .where({ 'dp.application_id': row.id, 'dp.status': 'queued' })
      .whereIn('j.status', ['queued', 'dispatched', 'running'])
      .first('j.id');
    const status = waiting && provisioned ? 'deploying' : provisioned ? 'ready' : 'failed';
    await db('applications')
      .where({ id: row.id })
      .update({ pending_action: status === 'deploying' ? 'deploy' : null, ...extra, status, ...(waiting ? { last_job_id: waiting.id } : {}), updated_at: now });
  }

  function processColumns(output, now) {
    if (!output?.unit) return {};
    return { process_state: processState(output.unit, output.process), process_info: toJson(processInfo(output.unit, output.process)), process_checked_at: now };
  }

  async function markReleases(appId, releases) {
    if (!Array.isArray(releases)) return;
    await db('deployments').where({ application_id: appId }).whereIn('release_id', releases).update({ release_available: true });
    await db('deployments').where({ application_id: appId }).whereNotIn('release_id', releases).update({ release_available: false });
  }

  // The website follows the app's port once the app runs on it.
  async function syncWebsitePort(row, port) {
    if (!row.website_id || !port) return;
    const site = await db('websites').where({ id: row.website_id }).whereNull('deleted_at').first();
    if (!site || site.proxy_port === port || !site.provisioned_at) return;
    try {
      await websites.update(systemActor(`app ${row.name}`), site.id, { proxyPort: port }, { fromApplication: true });
    } catch (err) {
      logger.warn({ err, applicationId: row.id }, 'could not move the website to the new port');
      await db('applications').where({ id: row.id }).update({ last_error_code: 'WEBSITE_PORT', last_error: `The app now listens on ${port}, but its website could not be updated: ${err.message}` });
    }
  }

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'application') return;
    const row = await db('applications').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? {} : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };
    const params = fromJson(job.params, {});

    switch (job.type) {
      case 'CREATE_APPLICATION': {
        if (ok) {
          await settle(row, { provisioned_at: row.provisioned_at ?? now, deploy_public_key: output?.deployKey ?? row.deploy_public_key, last_error_code: null, last_error: null }, now);
        } else {
          await settle(row, failure, now);
          // The first deployment cannot work without the app's user.
          const queued = await db('jobs').where({ resource_type: 'application', resource_id: row.id, status: 'queued', type: 'DEPLOY_GIT' }).pluck('id');
          for (const jobId of queued) await jobs.cancel(systemActor('app setup failed'), jobId).catch(() => {});
        }
        break;
      }
      case 'DEPLOY_GIT':
      case 'ROLLBACK_APPLICATION': {
        const deployment = await db('deployments').where({ job_id: job.id }).first();
        const extra = {};
        if (ok) {
          if (deployment) {
            await db('deployments').where({ id: deployment.id }).update({
              status: 'succeeded',
              ...(job.type === 'DEPLOY_GIT' ? { commit_hash: output?.commit ?? null, commit_message: output?.message?.slice(0, 500) ?? null, commit_author: output?.author?.slice(0, 200) ?? null } : {}),
              release_available: true,
              started_at: job.started_at,
              finished_at: now,
              updated_at: now,
            });
          }
          await markReleases(row.id, output?.releases);
          Object.assign(extra, {
            provisioned_at: row.provisioned_at ?? now,
            current_deployment_id: deployment?.id ?? row.current_deployment_id,
            current_release_id: output?.releaseId ?? params.releaseId,
            current_commit: (job.type === 'DEPLOY_GIT' ? output?.commit : deployment?.commit_hash) ?? null,
            last_deployed_at: now,
            config_applied_at: new Date(job.created_at),
            last_error_code: null,
            last_error: null,
            ...processColumns(output, now),
          });
          if (job.type === 'DEPLOY_GIT' && output?.deployKey) extra.deploy_public_key = output.deployKey;
        } else {
          const cancelled = status === 'cancelled';
          if (deployment) {
            await db('deployments').where({ id: deployment.id }).update({
              status: cancelled ? 'cancelled' : 'failed',
              failed_stage: cancelled ? null : (DEPLOY_ERROR_STAGES[error?.code] ?? null),
              error_code: (error?.code ?? 'FAILED').slice(0, 64),
              error_message: error?.message ?? null,
              release_available: false,
              started_at: job.started_at,
              finished_at: now,
              updated_at: now,
            });
          }
          // A cancelled deployment keeps the error that caused it (a failed setup).
          if (!cancelled) Object.assign(extra, failure);
          // Deploying sets the app up as well, so a failure after that stage
          // still leaves a set-up app.
          if (!row.provisioned_at && error?.code && !['PREPARE_FAILED', 'CANCELLED', 'AGENT_UNREACHABLE', 'NOT_ALLOWED', 'SITE_USER_CONFLICT'].includes(error.code)) {
            extra.provisioned_at = now;
          }
          // A first release that started but failed its check stays in place
          // (there is nothing to switch back to).
          if (error?.code === 'HEALTH_CHECK_FAILED' && !row.current_release_id && deployment && job.type === 'DEPLOY_GIT') {
            Object.assign(extra, { current_deployment_id: deployment.id, current_release_id: deployment.release_id, config_applied_at: new Date(job.created_at), process_state: 'failed', process_checked_at: now });
            await db('deployments').where({ id: deployment.id }).update({ release_available: true });
          }
        }
        await settle(row, extra, now);
        if (ok) await syncWebsitePort(row, params.port);
        break;
      }
      case 'CONFIGURE_APPLICATION': {
        // A failed health check still wrote the new settings.
        const written = ok || error?.code === 'HEALTH_CHECK_FAILED';
        await settle(row, { ...failure, ...(written ? { config_applied_at: new Date(job.created_at) } : {}), ...processColumns(output, now) }, now);
        if (written) await syncWebsitePort(row, params.port);
        break;
      }
      case 'START_APPLICATION':
      case 'STOP_APPLICATION':
      case 'RESTART_APPLICATION': {
        const fallback = ok ? {} : { process_state: job.type === 'STOP_APPLICATION' ? row.process_state : 'failed', process_checked_at: now };
        await settle(row, { ...failure, ...fallback, ...processColumns(output, now) }, now);
        break;
      }
      case 'APP_STATUS': {
        if (ok) {
          await db('applications').where({ id: row.id }).update({ ...processColumns(output, now) });
          await markReleases(row.id, output?.releases);
        }
        break;
      }
      case 'DELETE_APPLICATION': {
        if (ok) {
          await db.transaction(async (trx) => {
            await trx('applications').where({ id: row.id }).update({
              status: 'ready',
              pending_action: null,
              name_key: null,
              port_key: null,
              webhook_token_hash: null,
              deleted_at: now,
              updated_at: now,
            });
            await trx('environment_variables').where({ application_id: row.id }).delete();
            await trx('databases').where({ application_id: row.id }).update({ application_id: null });
          });
          if (row.website_id && output?.siteRemoved) await websites.markRemoved(row.website_id, now);
        } else {
          await settle(row, failure, now);
        }
        break;
      }
      default:
        return;
    }
    if (!ok) logger.info({ applicationId: row.id, job: job.type, error }, 'application change failed');
  }

  // ---- Heartbeat ----------------------------------------------------------

  // The pm2-<name> units the agent reports each heartbeat.
  async function syncProcesses(serverId, applications) {
    if (!Array.isArray(applications)) return;
    const rows = await db('applications').where({ server_id: serverId }).whereNull('deleted_at').whereNotNull('provisioned_at').select('id', 'name', 'process_state', 'process_info', 'status');
    const now = new Date();
    for (const row of rows) {
      // Changes report their own result; do not race them.
      if (APP_BUSY_STATUSES.includes(row.status)) continue;
      const unit = applications.find((a) => a.name === row.name);
      const state = unit ? processState({ exists: true, active: unit.active }) : row.process_state ? 'stopped' : null;
      if (state === row.process_state) {
        await db('applications').where({ id: row.id }).update({ process_checked_at: now });
        continue;
      }
      const info = { ...fromJson(row.process_info, {}), unit: unit ? { active: unit.active, sub: unit.sub ?? null, enabled: unit.enabled ?? null } : null };
      await db('applications').where({ id: row.id }).update({ process_state: state, process_info: toJson(info), process_checked_at: now });
    }
  }

  // Counts for the dashboard.
  async function summary() {
    const rows = await appQuery().clearSelect().select('a.process_state', 'a.status').count({ n: '*' }).groupBy('a.process_state', 'a.status');
    const byProcess = {};
    let total = 0;
    let busy = 0;
    for (const r of rows) {
      const n = Number(r.n);
      total += n;
      if (APP_BUSY_STATUSES.includes(r.status)) busy += n;
      const key = r.process_state ?? 'not_deployed';
      byProcess[key] = (byProcess[key] ?? 0) + n;
    }
    const since = new Date(Date.now() - 86_400_000);
    const deploys = await db('deployments').where('created_at', '>=', since).select('status').count({ n: '*' }).groupBy('status');
    return { total, busy, byProcess, deployments24h: Object.fromEntries(deploys.map((d) => [d.status, Number(d.n)])) };
  }

  jobs.onFinished(handleJobFinished);

  return {
    list,
    get,
    suggestPort,
    create,
    update,
    getEnv,
    setEnv,
    addEnv,
    deploy,
    rollback,
    control,
    apply,
    scale,
    refresh,
    logs,
    addWebsite,
    enableWebhook,
    disableWebhook,
    deployFromHook,
    remove,
    listDeployments,
    getDeployment,
    syncProcesses,
    summary,
    handleJobFinished,
  };
}

function target(row) {
  return { type: 'application', id: row.id, label: row.name };
}

// systemd's view of the pm2-<name> unit, refined by PM2's view of the app.
export function processState(unit, proc = null) {
  if (!unit || unit.exists === false) return 'stopped';
  if (unit.active === 'active') {
    if (proc && ['errored', 'stopped'].includes(proc.status)) return 'failed';
    if (proc && ['launching', 'waiting restart'].includes(proc.status)) return 'starting';
    return 'running';
  }
  if (['activating', 'reloading'].includes(unit.active)) return 'starting';
  if (unit.active === 'failed') return 'failed';
  if (['inactive', 'deactivating'].includes(unit.active)) return 'stopped';
  return 'unknown';
}

function processInfo(unit, proc) {
  return {
    unit: { active: unit.active ?? null, sub: unit.sub ?? null, enabled: unit.enabled ?? null },
    pid: proc?.pid ?? null,
    restarts: proc?.restarts ?? null,
    memoryBytes: proc?.memoryBytes ?? unit.memoryBytes ?? null,
    cpuPercent: proc?.cpuPercent ?? null,
    startedAt: proc?.startedAt ?? unit.since ?? null,
    // Several copies (agent 0.14.0+): how many PM2 runs, how many are online, and each one.
    count: proc?.count ?? null,
    online: proc?.online ?? null,
    instances: Array.isArray(proc?.instances) ? proc.instances.slice(0, 32) : null,
  };
}

