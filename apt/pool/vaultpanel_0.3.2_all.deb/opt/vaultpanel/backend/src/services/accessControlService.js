import { ALL_PERMISSIONS, CUSTOMER_ROLE, PERMISSION_DESCRIPTIONS, PERMISSIONS, ROLES } from '@vaultpanel/shared';

export function createAccessControlService({ db, authorize }) {
  // Makes the roles/permissions tables match the definitions in
  // @vaultpanel/shared. Idempotent; runs after every migration.
  async function syncBuiltInRoles() {
    await db.transaction(async (trx) => {
      for (const key of ALL_PERMISSIONS) {
        await trx('permissions')
          .insert({ key, description: PERMISSION_DESCRIPTIONS[key] ?? '' })
          .onConflict('key')
          .merge(['description']);
      }
      const permissionIds = Object.fromEntries(
        (await trx('permissions').select('id', 'key')).map((p) => [p.key, p.id]),
      );
      for (const [name, role] of Object.entries(ROLES)) {
        await trx('roles')
          .insert({ name, description: role.description, rank: role.rank, is_system: true })
          .onConflict('name')
          .merge(['description', 'rank', 'is_system']);
        const { id: roleId } = await trx('roles').where({ name }).first('id');
        await trx('role_permissions').where({ role_id: roleId }).delete();
        if (role.permissions.length) {
          await trx('role_permissions').insert(
            role.permissions.map((key) => ({ role_id: roleId, permission_id: permissionIds[key] })),
          );
        }
      }
    });
  }

  // Effective access for a user: union of the permissions of all their roles.
  //
  // A customer account (phase 8) also gets its customer: its permissions only
  // ever apply inside that account. Without an active customer record behind
  // it (suspended, removed, or the role given some other way) the account
  // gets no permissions at all, and `blocked` says why.
  async function getUserAccess(userId) {
    const rows = await db('user_roles as ur')
      .join('roles as r', 'r.id', 'ur.role_id')
      .leftJoin('role_permissions as rp', 'rp.role_id', 'r.id')
      .leftJoin('permissions as p', 'p.id', 'rp.permission_id')
      .where('ur.user_id', userId)
      .select('r.name as role', 'r.rank', 'p.key as permission');
    const roles = [...new Set(rows.map((r) => r.role))];
    let permissions = [...new Set(rows.map((r) => r.permission).filter(Boolean))].sort();
    let rank = rows.reduce((max, r) => Math.max(max, r.rank), 0);
    if (!roles.includes(CUSTOMER_ROLE)) return { roles, permissions, rank, customer: null, blocked: null };

    const customer = await db('customers').where({ user_id: userId }).first('id', 'status', 'name');
    let blocked = null;
    if (!customer) blocked = 'not_a_customer';
    else if (customer.status !== 'active') blocked = customer.status;
    // A customer is never also staff: other roles are ignored.
    permissions = blocked ? [] : (ROLES[CUSTOMER_ROLE].permissions ?? []).slice().sort();
    rank = ROLES[CUSTOMER_ROLE].rank;
    return { roles: [CUSTOMER_ROLE], permissions, rank, customer: customer && !blocked ? { id: customer.id, name: customer.name } : null, blocked };
  }

  async function listRoles(actor) {
    await authorize(actor, PERMISSIONS.ROLES_READ);
    const roles = await db('roles').orderBy('rank', 'desc');
    const links = await db('role_permissions as rp')
      .join('permissions as p', 'p.id', 'rp.permission_id')
      .select('rp.role_id', 'p.key');
    const counts = await db('user_roles').select('role_id').count({ users: '*' }).groupBy('role_id');
    return {
      roles: roles.map((r) => ({
        name: r.name,
        description: r.description,
        rank: r.rank,
        isSystem: Boolean(r.is_system),
        userCount: Number(counts.find((c) => c.role_id === r.id)?.users ?? 0),
        permissions: links.filter((l) => l.role_id === r.id).map((l) => l.key).sort(),
      })),
      permissions: ALL_PERMISSIONS.map((key) => ({ key, description: PERMISSION_DESCRIPTIONS[key] ?? '' })),
    };
  }

  async function roleIdByName(name, trx = db) {
    const row = await trx('roles').where({ name }).first('id');
    return row?.id ?? null;
  }

  return { syncBuiltInRoles, getUserAccess, listRoles, roleIdByName };
}
