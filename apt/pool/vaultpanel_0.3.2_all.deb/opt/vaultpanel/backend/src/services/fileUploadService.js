import { createHash, randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, open, readdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { FINAL_JOB_STATUSES, UPLOAD_CHUNK_BYTES } from '@vaultpanel/shared';
import { AppError, notFound } from '../utils/errors.js';

// Large uploads in the website file manager. The browser sends the file in
// pieces of up to UPLOAD_CHUNK_BYTES, which the panel appends to a file in
// VAULTPANEL_DATA_DIR/uploads. When every piece is in, the panel works out the
// SHA-256 and queues FILE_UPLOAD; the server's agent then fetches the file
// in pieces over its signed connection, checks it and saves it in the site
// as the site's own user. The panel's copy is removed when the job ends, and
// uploads nobody finished are removed after a while.

// Unfinished uploads are kept this long after their last piece.
const STALE_MS = 6 * 3_600_000;
// Finished ones whose job never ended (a server that went away).
const ABANDONED_MS = 48 * 3_600_000;

export function createFileUploadService({ db, config, logger, audit, jobs, websites }) {
  const dir = path.join(config.dataDir, 'uploads');
  const fileOf = (id) => path.join(dir, `${id}.part`);
  const maxBytes = config.fileUploadMaxBytes;

  async function own(actor, websiteId, uploadId) {
    const row = await db('file_uploads').where({ id: uploadId, website_id: websiteId }).first();
    // Only the person who started an upload adds to it.
    if (!row || (row.created_by ?? null) !== (actor?.id ?? null)) throw notFound('Upload not found');
    return row;
  }

  async function start(actor, websiteId, { path: target, size, overwrite }) {
    const site = await websites.fileSite(actor, websiteId, 'upload');
    if (size > maxBytes) {
      throw new AppError(413, 'FILE_TOO_LARGE', `Files up to ${Math.floor(maxBytes / 1024 / 1024)} MB can be uploaded (VAULTPANEL_FILE_UPLOAD_MAX_MB)`);
    }
    const id = randomUUID();
    await mkdir(dir, { recursive: true, mode: 0o700 });
    await (await open(fileOf(id), 'w', 0o600)).close();
    const now = new Date();
    await db('file_uploads').insert({
      id,
      website_id: site.id,
      server_id: site.server_id,
      created_by: actor?.id ?? null,
      path: target,
      overwrite,
      size_bytes: size,
      received_bytes: 0,
      created_at: now,
      updated_at: now,
    });
    return { uploadId: id, chunkBytes: UPLOAD_CHUNK_BYTES, size };
  }

  async function receive(actor, websiteId, uploadId, offset, data) {
    const row = await own(actor, websiteId, uploadId);
    if (row.job_id) throw new AppError(409, 'UPLOAD_FINISHED', 'This upload is already complete');
    if (!Buffer.isBuffer(data) || data.length === 0) throw new AppError(400, 'BAD_REQUEST', 'Send the piece as the request body');
    if (data.length > UPLOAD_CHUNK_BYTES) throw new AppError(413, 'CHUNK_TOO_LARGE', `Pieces are up to ${UPLOAD_CHUNK_BYTES} bytes`);
    const handle = await open(fileOf(row.id), 'a', 0o600).catch((err) => {
      throw err.code === 'ENOENT' ? notFound('Upload not found') : err;
    });
    try {
      const { size } = await handle.stat();
      if (size !== offset) throw new AppError(409, 'OFFSET_MISMATCH', `Expected offset ${size}`, { expected: size });
      if (size + data.length > Number(row.size_bytes)) throw new AppError(422, 'UPLOAD_TOO_LARGE', 'More data than the file holds');
      await handle.write(data);
    } finally {
      await handle.close();
    }
    const received = offset + data.length;
    await db('file_uploads').where({ id: row.id }).update({ received_bytes: received, updated_at: new Date() });
    return { received, size: Number(row.size_bytes) };
  }

  // Every piece is in: check the size and queue the job that saves it.
  async function finish(actor, websiteId, uploadId) {
    const row = await own(actor, websiteId, uploadId);
    if (row.job_id) throw new AppError(409, 'UPLOAD_FINISHED', 'This upload is already complete');
    const file = fileOf(row.id);
    const info = await stat(file).catch(() => null);
    if (!info || info.size !== Number(row.size_bytes)) {
      throw new AppError(409, 'UPLOAD_INCOMPLETE', `${info?.size ?? 0} of ${row.size_bytes} bytes have arrived`, { received: info?.size ?? 0 });
    }
    const sha256 = await hashFile(file);
    const job = await websites.files(actor, websiteId, 'upload', {
      path: row.path,
      uploadId: row.id,
      size: Number(row.size_bytes),
      sha256,
      overwrite: Boolean(row.overwrite),
    });
    await db('file_uploads').where({ id: row.id }).update({ sha256, job_id: job.id, updated_at: new Date() });
    await audit.record({
      actor,
      action: 'website.file.upload',
      target: { type: 'website', id: websiteId, label: row.path },
      metadata: { path: row.path, size: Number(row.size_bytes), jobId: job.id },
    });
    return job;
  }

  // A piece for the server's agent, while its FILE_UPLOAD job runs.
  async function chunkForAgent(serverId, uploadId, offset) {
    const row = await db('file_uploads').where({ id: uploadId, server_id: serverId }).first();
    if (!row?.job_id) throw notFound('Upload not found');
    const job = await db('jobs').where({ id: row.job_id, server_id: serverId }).first('status');
    if (!job || !['dispatched', 'running'].includes(job.status)) throw new AppError(409, 'NO_UPLOAD', 'No upload of this file is running');
    const size = Number(row.size_bytes);
    if (offset >= size) throw new AppError(416, 'OFFSET_OUT_OF_RANGE', 'Past the end of the file');
    const length = Math.min(UPLOAD_CHUNK_BYTES, size - offset);
    const handle = await open(fileOf(row.id), 'r');
    try {
      const buffer = Buffer.alloc(length);
      const { bytesRead } = await handle.read(buffer, 0, length, offset);
      return { offset, data: buffer.subarray(0, bytesRead).toString('base64') };
    } finally {
      await handle.close();
    }
  }

  async function remove(row) {
    await rm(fileOf(row.id), { force: true });
    await db('file_uploads').where({ id: row.id }).delete();
  }

  // The agent has the file (or gave up): the panel's copy goes.
  async function handleJobFinished(job) {
    if (job.type !== 'FILE_UPLOAD') return;
    const row = await db('file_uploads').where({ job_id: job.id }).first();
    if (row) await remove(row);
  }

  // Worker: uploads nobody finished, or whose job never ended, and pieces
  // left without a record.
  async function prune(now = new Date()) {
    const rows = await db('file_uploads as u')
      .leftJoin('jobs as j', 'j.id', 'u.job_id')
      .where((q) =>
        q
          .where((qq) => qq.whereNull('u.job_id').where('u.updated_at', '<', new Date(now.getTime() - STALE_MS)))
          .orWhere((qq) => qq.whereNotNull('u.job_id').where((j) => j.whereNull('j.id').orWhereIn('j.status', FINAL_JOB_STATUSES)))
          .orWhere('u.updated_at', '<', new Date(now.getTime() - ABANDONED_MS)),
      )
      .select('u.id');
    for (const row of rows) await remove(row);
    let orphans = 0;
    const names = await readdir(dir).catch(() => []);
    if (names.length) {
      const known = new Set((await db('file_uploads').select('id')).map((r) => `${r.id}.part`));
      for (const name of names) {
        if (known.has(name)) continue;
        const info = await stat(path.join(dir, name)).catch(() => null);
        if (info && now.getTime() - info.mtimeMs > STALE_MS) {
          await rm(path.join(dir, name), { force: true });
          orphans += 1;
        }
      }
    }
    if (rows.length || orphans) logger.info({ uploads: rows.length, orphans }, 'removed stale file uploads');
    return rows.length + orphans;
  }

  jobs.onFinished(handleJobFinished);
  return { start, receive, finish, chunkForAgent, handleJobFinished, prune };
}

function hashFile(file) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    createReadStream(file)
      .on('data', (chunk) => hash.update(chunk))
      .on('end', () => resolve(hash.digest('hex')))
      .on('error', reject);
  });
}
