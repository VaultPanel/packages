import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { CUSTOMER_ROLE, PERMISSIONS, ROLE_NAMES, roleRank } from '@vaultpanel/shared';
import { findUserById, normalizeEmail, rolesByUser, toPublicUser } from '../models/userModel.js';
import { AppError, conflict, forbidden, notFound } from '../utils/errors.js';
import { newToken, sha256Hex } from '../utils/crypto.js';
import { hashPassword } from '../utils/password.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';

const INVITE_TTL_HOURS = 72;
const RESET_TTL_HOURS = 2;
// "Forgot password?" sends at most one email per account this often.
const RESET_REQUEST_EVERY_MINUTES = 5;

export const userListQuery = listQuerySchema(['createdAt', 'email', 'name', 'lastLoginAt'], 'createdAt', {
  search: z.string().max(100).optional(),
  status: z.enum(['active', 'inactive']).optional(),
  role: z.enum(ROLE_NAMES).optional(),
});

export function createUserService({ db, config, audit, authorize, accessControl, email = null, logger = null }) {
  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.USERS_READ);
    const q = db('users').whereNull('deleted_at').select('*');
    if (query.search) {
      const term = `%${query.search.replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) => w.where('email', 'like', term).orWhere('name', 'like', term));
    }
    if (query.status) q.where('is_active', query.status === 'active');
    const withRole = (role) => db('user_roles as ur').join('roles as r', 'r.id', 'ur.role_id').where('r.name', role).select('ur.user_id');
    if (query.role) q.whereIn('id', withRole(query.role));
    // Hosting customers have their own page (Customers) unless asked for.
    else q.whereNotIn('id', withRole(CUSTOMER_ROLE));
    const { rows, pagination } = await paginate(q, query, {
      createdAt: 'created_at',
      lastLoginAt: 'last_login_at',
    });
    const roles = await rolesByUser(db, rows.map((r) => r.id));
    return { items: rows.map((r) => toPublicUser(r, roles[r.id])), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.USERS_READ);
    const user = await findUserById(db, id);
    if (!user) throw notFound('User not found');
    return toPublicUser(user, (await rolesByUser(db, [id]))[id]);
  }

  // Creates an account with an unusable password and returns a one-time
  // invite link the new user opens to choose their password.
  async function invite(actor, { email, name, role }) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    assertCanGrant(actor, role);
    const normalized = normalizeEmail(email);
    if (await db('users').where({ email: normalized }).first()) {
      throw conflict('A user with this email already exists');
    }
    const id = randomUUID();
    await db.transaction(async (trx) => {
      await trx('users').insert({
        id,
        email: normalized,
        name,
        // Random hash nobody knows; replaced when the invite is accepted.
        password_hash: await hashPassword(newToken()),
      });
      await trx('user_roles').insert({ user_id: id, role_id: await accessControl.roleIdByName(role, trx) });
    });
    const link = await issueToken(id, 'invite', actor);
    const user = await findUserById(db, id);
    const emailed = await sendLink(user, 'invite', link, actor);
    await audit.record({ actor, action: 'user.invite', target: target(user), metadata: { role, emailed: emailed?.sent ?? false } });
    return { user: toPublicUser(user, [role]), inviteUrl: link.url, inviteExpiresAt: link.expiresAt, email: emailed };
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    const user = await findUserById(db, id);
    if (!user) throw notFound('User not found');
    const currentRoles = (await rolesByUser(db, [id]))[id];
    assertCanManage(actor, currentRoles);
    if (currentRoles.includes(CUSTOMER_ROLE)) {
      throw new AppError(409, 'CUSTOMER_ACCOUNT', 'This is a hosting customer. Manage it from its page under Customers.');
    }

    const isSelf = actor.id === id;
    if (isSelf && changes.role !== undefined) throw forbidden('You cannot change your own role');
    if (isSelf && changes.isActive === false) throw forbidden('You cannot deactivate your own account');
    if (changes.role !== undefined) assertCanGrant(actor, changes.role);

    const losingOwner =
      currentRoles.includes('owner') &&
      ((changes.role !== undefined && changes.role !== 'owner') || changes.isActive === false);

    await db.transaction(async (trx) => {
      if (losingOwner) await assertAnotherActiveOwner(trx, id);
      const patch = { updated_at: new Date() };
      if (changes.name !== undefined) patch.name = changes.name;
      if (changes.isActive !== undefined) patch.is_active = changes.isActive;
      await trx('users').where({ id }).update(patch);
      if (changes.role !== undefined) {
        await trx('user_roles').where({ user_id: id }).delete();
        await trx('user_roles').insert({ user_id: id, role_id: await accessControl.roleIdByName(changes.role, trx) });
      }
      // Deactivating or changing a role ends existing sessions so the change
      // applies immediately.
      if (changes.isActive === false || changes.role !== undefined) {
        await trx('sessions').where({ user_id: id }).whereNull('revoked_at').update({ revoked_at: new Date() });
      }
    });

    await audit.record({
      actor,
      action: 'user.update',
      target: target(user),
      metadata: { changes, previousRoles: currentRoles },
    });
    return get(actor, id);
  }

  async function issuePasswordReset(actor, id) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    const user = await findUserById(db, id);
    if (!user) throw notFound('User not found');
    assertCanManage(actor, (await rolesByUser(db, [id]))[id]);
    const link = await issueToken(id, 'reset', actor);
    const emailed = await sendLink(user, 'reset', link, actor);
    await audit.record({ actor, action: 'user.password_reset_issue', target: target(user), metadata: { emailed: emailed?.sent ?? false } });
    return { resetUrl: link.url, expiresAt: link.expiresAt, email: emailed };
  }

  // "Forgot password?" on the sign-in page. Only works when panel email is
  // set up, and says nothing about whether the address has an account: the
  // caller answers the same way before this finishes. One email per account
  // every few minutes, so nobody can flood an inbox or keep voiding links.
  async function requestPasswordReset(address, actor) {
    if (!email || !(await email.isReady())) return { sent: false, reason: 'email_off' };
    const user = await db('users').where({ email: normalizeEmail(address) }).whereNull('deleted_at').first();
    if (!user || !user.is_active) {
      await audit.record({ actor, action: 'auth.password_reset_request', result: 'failure', metadata: { reason: 'unknown_or_inactive' } });
      return { sent: false, reason: 'unknown' };
    }
    const recent = await db('password_reset_tokens')
      .where({ user_id: user.id, purpose: 'reset' })
      .whereNull('created_by')
      .where('created_at', '>', new Date(Date.now() - RESET_REQUEST_EVERY_MINUTES * 60_000))
      .first('id');
    if (recent) {
      await audit.record({ actor, action: 'auth.password_reset_request', result: 'failure', target: target(user), metadata: { reason: 'too_soon' } });
      return { sent: false, reason: 'too_soon' };
    }
    const link = await issueToken(user.id, 'reset', actor);
    const emailed = await sendLink(user, 'reset', link, null);
    await audit.record({ actor, action: 'auth.password_reset_request', target: target(user), metadata: { emailed: emailed?.sent ?? false } });
    return { sent: Boolean(emailed?.sent), reason: emailed?.sent ? null : 'send_failed' };
  }

  // The link by email when panel email is set up (null when it is not). The
  // link is also returned to whoever issued it, to hand over if the email
  // does not arrive. A sending problem never undoes the invite or reset.
  async function sendLink(user, purpose, link, actor) {
    if (!email) return null;
    try {
      return await email.sendLink({ user, purpose, url: link.url, expiresAt: link.expiresAt, by: actor?.type === 'user' ? actor.label : null });
    } catch (err) {
      logger?.error({ err }, 'could not email the link');
      return { to: user.email, sent: false, error: 'The email could not be sent' };
    }
  }

  async function issueToken(userId, purpose, actor) {
    const token = newToken();
    const hours = purpose === 'invite' ? INVITE_TTL_HOURS : RESET_TTL_HOURS;
    const expiresAt = new Date(Date.now() + hours * 3600_000);
    await db('password_reset_tokens').where({ user_id: userId }).whereNull('used_at').update({ used_at: new Date() });
    await db('password_reset_tokens').insert({
      id: randomUUID(),
      user_id: userId,
      token_hash: sha256Hex(token),
      purpose,
      created_by: actor.type === 'user' ? actor.id : null,
      expires_at: expiresAt,
    });
    return { url: `${config.publicUrl}/reset-password#token=${token}`, expiresAt };
  }

  // For someone who lost their phone and their recovery codes. They sign in
  // with their password alone and can set two-factor sign-in up again.
  async function resetTwoFactor(actor, id) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    const user = await findUserById(db, id);
    if (!user) throw notFound('User not found');
    if (id === actor.id) throw new AppError(400, 'BAD_REQUEST', 'Turn off your own two-factor sign-in on the Account page');
    assertCanManage(actor, (await rolesByUser(db, [id]))[id]);
    if (!user.totp_enabled) throw new AppError(409, 'TWO_FACTOR_OFF', 'Two-factor sign-in is already off for this user');
    await db.transaction(async (trx) => {
      await trx('users').where({ id }).update({ totp_enabled: false, totp_secret_encrypted: null, totp_last_step: null });
      await trx('user_recovery_codes').where({ user_id: id }).delete();
      await trx('sessions').where({ user_id: id }).whereNull('revoked_at').update({ revoked_at: new Date() });
    });
    await audit.record({ actor, action: 'user.2fa_reset', target: target(user) });
    return get(actor, id);
  }

  async function assertAnotherActiveOwner(trx, excludingId) {
    const row = await trx('users as u')
      .join('user_roles as ur', 'ur.user_id', 'u.id')
      .join('roles as r', 'r.id', 'ur.role_id')
      .where('r.name', 'owner')
      .where('u.is_active', true)
      .whereNull('u.deleted_at')
      .whereNot('u.id', excludingId)
      .forUpdate()
      .count({ n: '*' })
      .first();
    if (Number(row.n) === 0) throw new AppError(409, 'LAST_OWNER', 'The panel must keep at least one active owner');
  }

  // Invite and reset links for accounts made elsewhere (hosting customers),
  // emailed too when panel email is set up.
  async function issueLink(userId, purpose, actor) {
    const link = await issueToken(userId, purpose, actor);
    const user = await findUserById(db, userId);
    return { ...link, email: user ? await sendLink(user, purpose, link, actor) : null };
  }

  return { list, get, invite, update, issuePasswordReset, requestPasswordReset, resetTwoFactor, issueLink };
}

// An actor can only grant roles at or below their own rank, except admins
// cannot grant owner (owner rank is above admin, so this follows).
function assertCanGrant(actor, role) {
  if (role === CUSTOMER_ROLE) throw forbidden('Customer accounts are created on the Customers page');
  if (roleRank(role) > actor.rank) throw forbidden(`You cannot assign the ${role} role`);
}

function assertCanManage(actor, targetRoles) {
  const targetRank = Math.max(0, ...targetRoles.map(roleRank));
  if (targetRank > actor.rank) throw forbidden('You cannot manage a user with a higher role than yours');
}

function target(user) {
  return { type: 'user', id: user.id, label: user.email };
}
