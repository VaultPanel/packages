// Periodic housekeeping, run by the background worker (see src/jobs).
// Customer app ports are checked every few minutes, not every run.
const PORT_SYNC_MS = 5 * 60_000;
// Certificates change slowly: renewals and expiry notices every few minutes.
const SSL_CHECK_MS = 5 * 60_000;
// Plugin directories are read again every few hours; this is how often to look.
const PLUGIN_DIRECTORY_CHECK_MS = 10 * 60_000;

export function createMaintenanceService({ db, logger, agents, jobs, metrics, alerts, backups, webhooks, email, bulkActions, assistant, ports, sslRenewal, fileUploads, fileDownloads, pluginDirectories, terminalRecordings, websiteMonitor, config }) {
  let portsSyncedAt = 0;
  let sslCheckedAt = 0;
  let directoriesCheckedAt = 0;
  async function run(now = new Date()) {
    const offline = await agents.markOfflineServers(config.agentOfflineSeconds, now);
    // Website uptime checks run in the background; their results are read
    // by the alert evaluation below on a later run.
    const uptime = websiteMonitor ? await websiteMonitor.tick(now) : null;
    const swept = await jobs.sweep(now);
    // After the sweep, so bulk actions see jobs it just failed.
    const bulk = await bulkActions.tick(now);
    // Alerts are evaluated after offline detection so "server offline" sees it.
    const alertChanges = await alerts.evaluate(now);
    const rolledUpHours = await metrics.rollup(now);
    const prunedMetrics = await metrics.prune(now);
    const prunedAlerts = await alerts.prune(now);
    const scheduledBackups = await backups.runDueSchedules(now);
    let ssl = null;
    if (sslRenewal && now.getTime() - sslCheckedAt >= SSL_CHECK_MS) {
      sslCheckedAt = now.getTime();
      ssl = await sslRenewal.tick(now);
    }
    const prunedDownloads = await backups.pruneDownloads(now);
    const prunedUploads = fileUploads ? await fileUploads.prune(now) : null;
    const prunedFileDownloads = fileDownloads ? await fileDownloads.prune(now) : null;
    // Terminal recordings past the retention period in their settings.
    const prunedRecordings = terminalRecordings ? await terminalRecordings.prune(now) : null;
    // Last, so events from this run go out at once.
    const webhookDeliveries = await webhooks.deliver(now);
    const prunedDeliveries = await webhooks.prune(now);
    const emailsSent = email ? await email.deliver(now) : null;
    const prunedEmails = email ? await email.prune(now) : null;
    // Expired or revoked sessions are kept for 30 days for investigation, then removed.
    const sessionCutoff = new Date(now.getTime() - 30 * 86_400_000);
    const prunedSessions = await db('sessions')
      .where((q) => q.where('expires_at', '<', sessionCutoff).orWhere('revoked_at', '<', sessionCutoff))
      .delete();
    const assistantRuns = assistant ? await assistant.failStuck(now) : null;
    // Customers' app ports follow their plans (and fill in for accounts
    // created before ports were per customer).
    let customerPorts = null;
    if (ports && now.getTime() - portsSyncedAt >= PORT_SYNC_MS) {
      portsSyncedAt = now.getTime();
      customerPorts = await ports.syncAll();
    }
    let pluginDirectoriesRead = null;
    if (pluginDirectories && now.getTime() - directoriesCheckedAt >= PLUGIN_DIRECTORY_CHECK_MS) {
      directoriesCheckedAt = now.getTime();
      pluginDirectoriesRead = await pluginDirectories.refreshStale(now);
    }
    const result = { offline, uptime, customerPorts, ssl, swept, bulk, assistantRuns, alertChanges, rolledUpHours, prunedMetrics, prunedAlerts, prunedSessions, scheduledBackups, prunedDownloads, prunedUploads, prunedFileDownloads, prunedRecordings, webhookDeliveries, prunedDeliveries, emailsSent, prunedEmails, pluginDirectoriesRead };
    logger.debug({ result }, 'maintenance run complete');
    return result;
  }
  return { run };
}
