import { createPrivateKey, randomUUID, X509Certificate } from 'node:crypto';
import { Resolver } from 'node:dns/promises';
import {
  OPERATIONS,
  PERMISSIONS,
  SITE_GIT_DOCUMENT_ROOT,
  SSL_UPLOAD_MIN_AGENT_VERSION,
  WILDCARD_SITE_MIN_AGENT_VERSION,
  certificateCovers,
  isDomainSuffix,
  isWildcardDomain,
  parentDomains,
  siteSpecProblems,
  validateParams,
  wildcardZonesFor,
} from '@vaultpanel/shared';
import { toPublicCertificate, toPublicDomain, toPublicWebsite } from '../models/websiteModel.js';
import { agentOperations, findServer } from '../models/serverModel.js';
import { toPublicJob } from '../models/jobModel.js';
import { AppError, forbidden, notFound, validationError } from '../utils/errors.js';
import { compareVersions } from '../utils/agentPackage.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { getSetting } from '../models/settingModel.js';
import { sslRenewal } from '../models/sslRenewalModel.js';
import { scopeQuery } from './tenancy.js';

// Websites: the records behind each site and the jobs that build them.
//
// The website row always describes what is live on the server. A change is
// stored as pending (pending_action, pending_spec) while its job runs, and
// only applied to the row when the agent reports success. A failed change
// leaves the row as it was, which matches the server: the agent puts the
// previous configuration back when a change fails.

const BUSY_STATUSES = ['creating', 'updating', 'deleting'];

// The renewal window for agents that apply it (SET_SSL_RENEWAL); older
// agents refuse unknown parameters, so they get none.
function renewalWindow(server) {
  return agentOperations(server).includes('SET_SSL_RENEWAL') ? { renewBeforeDays: sslRenewal().renewBeforeDays } : {};
}
const FILE_OPERATIONS = {
  list: 'FILE_LIST',
  read: 'FILE_READ',
  write: 'FILE_WRITE',
  mkdir: 'FILE_MKDIR',
  rename: 'FILE_RENAME',
  delete: 'FILE_DELETE',
  extract: 'FILE_EXTRACT',
  compress: 'FILE_COMPRESS',
  // Started by the upload service once every piece is in (not a browser action).
  upload: 'FILE_UPLOAD',
  // Started by the download service, which keeps track of the copy.
  download: 'FILE_DOWNLOAD',
  chmod: 'FILE_CHMOD',
};

export function createWebsiteService({ db, logger, audit, authorize, jobs, quotas, dnsProviders, resolver = new Resolver({ timeout: 4000, tries: 2 }) }) {
  // The website that puts VaultPanel itself on a domain (Panel Domain page,
  // services/panelDomainService.js): { websiteId, domain } or null. It is
  // shown only on that page, never in the lists of websites, domains and
  // certificates.
  async function panelSite() {
    return fromJson(await getSetting(db, 'panel.domain'), null);
  }

  // A query modifier (q.modify(withoutPanelSite, panel, 'w.id')). It is not
  // async on purpose: an async function would run the query it returns.
  function withoutPanelSite(q, panel, column) {
    if (panel?.websiteId) q.whereNot(column, panel.websiteId);
  }

  // ---- Reading ------------------------------------------------------------

  function websiteQuery() {
    return db('websites as w')
      .join('servers as s', 's.id', 'w.server_id')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .select('w.*', 's.name as server_name', 's.status as server_status');
  }

  async function related(ids) {
    if (!ids.length) return { domains: {}, certificates: {}, applications: {} };
    const [domainRows, certRows, appRows] = await Promise.all([
      db('website_domains').whereIn('website_id', ids),
      db('ssl_certificates').whereIn('website_id', ids),
      db('applications').whereIn('website_id', ids).whereNull('deleted_at').select('id', 'name', 'website_id'),
    ]);
    const domains = {};
    for (const d of domainRows) (domains[d.website_id] ??= []).push(d);
    return {
      domains,
      certificates: Object.fromEntries(certRows.map((c) => [c.website_id, c])),
      applications: Object.fromEntries(appRows.map((a) => [a.website_id, { id: a.id, name: a.name }])),
    };
  }

  async function load(id) {
    const row = await websiteQuery().where('w.id', id).first();
    if (!row) throw notFound('Website not found');
    const { domains, certificates, applications } = await related([id]);
    return { row, domains: domains[id] ?? [], certificate: certificates[id] ?? null, application: applications[id] ?? null };
  }

  async function detail(id) {
    const { row, domains, certificate, application } = await load(id);
    return toPublicWebsite(row, { domains, certificate, application });
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const q = scopeQuery(websiteQuery(), actor, 'w.customer_id').modify(withoutPanelSite, await panelSite(), 'w.id');
    if (query.serverId) q.where('w.server_id', query.serverId);
    if (query.status) q.where('w.status', query.status);
    // Sites added on the Subdomains page.
    if (query.subdomains) q.whereNotNull('w.subdomain_of');
    if (query.search) {
      const term = `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) =>
        w.where('w.name', 'like', term).orWhereExists(
          db('website_domains as d').whereRaw('d.website_id = w.id').where('d.domain', 'like', term),
        ),
      );
    }
    const { rows, pagination } = await paginate(q, query, { createdAt: 'w.created_at', name: 'w.name' });
    const { domains, certificates, applications } = await related(rows.map((r) => r.id));
    return {
      items: rows.map((r) => toPublicWebsite(r, { domains: domains[r.id] ?? [], certificate: certificates[r.id] ?? null, application: applications[r.id] ?? null })),
      pagination,
    };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const website = await detail(id);
    const recentJobs = await db('jobs as j')
      .leftJoin('users as u', 'u.id', 'j.requested_by')
      .select('j.*', 'u.email as requested_by_email')
      .where({ 'j.resource_type': 'website', 'j.resource_id': id })
      .whereIn('j.type', ['CREATE_SITE', 'CREATE_NGINX_CONFIG', 'DELETE_SITE', 'ISSUE_SSL', 'INSTALL_SSL_CERT', 'RENEW_SSL', 'FILE_WRITE', 'FILE_MKDIR', 'FILE_RENAME', 'FILE_DELETE', 'SITE_GIT_SETUP', 'DEPLOY_SITE_GIT', 'ROLLBACK_SITE_GIT'])
      .orderBy('j.created_at', 'desc')
      .limit(10);
    return { ...website, recentJobs: recentJobs.map(toPublicJob) };
  }

  // ---- Building the parameters the agent receives ------------------------

  // The full site definition for the agent, from the live record plus changes.
  function siteSpec(row, domains, certificate, changes = {}) {
    const primaryFirst = [...domains].sort((a, b) => Number(b.is_primary) - Number(a.is_primary)).map((d) => d.domain);
    const sslActive = certificate?.status === 'active';
    const spec = {
      name: row.name,
      type: row.type,
      domains: primaryFirst,
      documentRoot: row.document_root,
      phpVersion: row.php_version,
      proxyPort: row.proxy_port,
      enabled: Boolean(row.is_enabled),
      ssl: sslActive,
      forceHttps: sslActive && Boolean(row.force_https),
      customNginx: row.custom_nginx || null,
      // Sent only when on, so agents before 0.18.0 keep working.
      htaccess: Boolean(row.htaccess) || null,
      // Sent only when on, so agents before 0.30.0 keep working.
      spa: Boolean(row.spa) || null,
      ...changes,
    };
    if (spec.type !== 'php') delete spec.phpVersion;
    if (spec.type === 'proxy' || !spec.htaccess) delete spec.htaccess;
    if (spec.type !== 'static' || !spec.spa) delete spec.spa;
    if (spec.type !== 'proxy') delete spec.proxyPort;
    if (!spec.ssl) spec.forceHttps = false;
    for (const key of Object.keys(spec)) if (spec[key] === null || spec[key] === undefined) delete spec[key];
    return spec;
  }

  // Checks a complete site definition the way the agent will, plus what only
  // the panel knows (the server's web stack, other sites' domains).
  async function checkSpec(spec, server, websiteId = null) {
    const wildcards = (spec.domains ?? []).filter(isWildcardDomain);
    if (wildcards.length && compareVersions(server.agent_version ?? '0.0.0', WILDCARD_SITE_MIN_AGENT_VERSION) < 0) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot serve wildcard domains. Update the agent to ${WILDCARD_SITE_MIN_AGENT_VERSION} or newer first.`);
    }
    const checked = validateParams(OPERATIONS.CREATE_NGINX_CONFIG.params, spec);
    const problems = checked.ok ? [] : [...checked.errors];
    problems.push(...siteSpecProblems(spec));
    for (const w of wildcards) {
      if (isDomainSuffix(w.slice(2))) problems.push({ field: 'domains', message: `${w} would catch other people’s domains under ${w.slice(2)}. Use a wildcard under your own domain, such as *.example.${w.slice(2)}` });
    }
    const stack = fromJson(server.web_stack, null);
    if (stack && spec.type === 'php' && spec.phpVersion && !stack.phpVersions?.includes(spec.phpVersion)) {
      problems.push({
        field: 'phpVersion',
        message: stack.phpVersions?.length
          ? `PHP ${spec.phpVersion} is not installed on ${server.name}. Installed: ${stack.phpVersions.join(', ')}`
          : `PHP-FPM is not installed on ${server.name}. Install it from the server's Web stack card.`,
      });
    }
    if (stack && spec.htaccess && stack.apache === false) {
      problems.push({ field: 'htaccess', message: `Apache is not installed on ${server.name}. Install it from the server's Web stack card to use .htaccess files.` });
    }
    if (spec.spa && spec.htaccess) {
      problems.push({ field: 'spa', message: 'Turn off .htaccess files first, or add the index.html fallback to your .htaccess file.' });
    }
    const taken = await db('website_domains as d')
      .join('websites as w', 'w.id', 'd.website_id')
      .whereIn('d.domain_key', spec.domains ?? [])
      .modify((q) => websiteId && q.whereNot('d.website_id', websiteId))
      .select('d.domain', 'w.id', 'w.name');
    const panel = taken.length ? await panelSite() : null;
    for (const t of taken) {
      problems.push({ field: 'domains', message: t.id === panel?.websiteId ? `${t.domain} is the panel's own domain (System > Panel Domain)` : `${t.domain} is already used by the site ${t.name}` });
    }
    if (problems.length) throw validationError(problems);
    return checked.value;
  }

  // A customer's reverse proxy may only point at one of their own apps, so
  // a site cannot publish another account's app or a service of the server.
  async function checkCustomerProxy(customerId, spec, serverId) {
    if (!customerId || spec.type !== 'proxy') return;
    const app = await db('applications').where({ server_id: serverId, port_key: spec.proxyPort, customer_id: customerId }).whereNull('deleted_at').first('id');
    if (!app) throw validationError([{ field: 'proxyPort', message: 'A reverse proxy can only point at the port of one of your own apps' }]);
  }

  // A hosting customer may not put a site on a name under another
  // account's domain (shop.someone-else.com), or under one of the panel's
  // DNS zones that is not theirs. Going up from each domain, the nearest
  // parent that is a site's domain, or its wildcard (*.someone-else.com), or
  // a zone decides. Staff are not limited.
  async function checkCustomerDomains(customerId, domains, websiteId = null) {
    if (!customerId) return;
    const parents = [...new Set(domains.flatMap(parentDomains))].filter((p) => !domains.includes(p));
    if (!parents.length) return;
    const [siteRows, zoneRows] = await Promise.all([
      db('website_domains as d')
        .join('websites as w', 'w.id', 'd.website_id')
        .whereIn('d.domain_key', [...parents, ...parents.map((p) => `*.${p}`)])
        .modify((q) => websiteId && q.whereNot('w.id', websiteId))
        .select('d.domain', 'w.customer_id'),
      db('dns_zones').whereIn('domain_key', parents).select('domain', 'customer_id'),
    ]);
    const problems = [];
    for (const domain of domains) {
      // The names that hold a parent: itself and its wildcard, other than
      // the domain being checked (*.example.com is under example.com).
      const holders = (parent) => [parent, `*.${parent}`].filter((n) => n !== domain);
      for (const parent of parentDomains(domain)) {
        // The site's own domain (blog.example.com next to example.com or *.example.com).
        if (holders(parent).some((n) => domains.includes(n))) break;
        const owners = siteRows.filter((r) => holders(parent).includes(r.domain));
        if (owners.length) {
          if (owners.some((r) => r.customer_id !== customerId)) problems.push({ field: 'domains', message: `${domain} is under ${parent}, which belongs to another account` });
          break;
        }
        const zone = zoneRows.find((z) => z.domain === parent);
        if (zone) {
          if (zone.customer_id !== customerId) problems.push({ field: 'domains', message: `${domain} is under ${parent}, which is not part of your hosting account. Add ${parent} as a website first.` });
          break;
        }
      }
    }
    if (problems.length) throw validationError(problems);
  }

  function requireNginx(server) {
    const stack = fromJson(server.web_stack, null);
    if (stack && !stack.nginx) {
      throw new AppError(409, 'NGINX_NOT_INSTALLED', `NGINX is not installed on ${server.name}. Install the web stack from the server page first.`);
    }
  }

  function requireServerReady(server) {
    if (!server || server.deleted_at) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') {
      throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    }
  }

  function requireIdle(row) {
    if (BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'WEBSITE_BUSY', 'Another change to this website is still running. Wait for it to finish.', { jobId: row.last_job_id });
    }
  }

  function requireProvisioned(row) {
    requireIdle(row);
    if (!row.provisioned_at) {
      throw new AppError(409, 'WEBSITE_NOT_READY', 'This website was never created successfully on its server. Retry creating it or delete it.');
    }
  }

  // The website that puts VaultPanel itself on a domain (Panel Domain page,
  // services/panelDomainService.js) is changed and removed only from there,
  // so it cannot be taken away from the Websites page by mistake.
  async function requireNotPanelSite(row, fromPanel) {
    if (fromPanel) return;
    const panel = await panelSite();
    if (panel?.websiteId === row.id) {
      throw new AppError(409, 'PANEL_WEBSITE', `This website puts VaultPanel itself on ${panel.domain}. Change or remove it on the Panel Domain page.`);
    }
  }

  // ---- Changes ------------------------------------------------------------

  // Marks the website busy, queues the job and links them. If the job cannot
  // be queued (agent offline or outdated...), the website is put back.
  async function startChange(actor, row, { action, type, params, pendingSpec = null, status = 'updating' }) {
    const now = new Date();
    const claimed = await db('websites')
      .where({ id: row.id })
      .whereNotIn('status', BUSY_STATUSES)
      .update({ status, pending_action: action, pending_spec: toJson(pendingSpec), last_error_code: null, last_error: null, updated_at: now });
    if (!claimed) requireIdle({ ...row, status: 'updating' });
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type, params, resource: { type: 'website', id: row.id } }, { internal: true });
    } catch (err) {
      await db('websites').where({ id: row.id }).update({ status: row.status, pending_action: null, pending_spec: null, updated_at: new Date() });
      throw err;
    }
    await db('websites').where({ id: row.id }).update({ last_job_id: job.id });
    return job;
  }

  // Checks a new website before anything is saved. An app's website
  // ({ forApplication: true }) shares the app's name and Linux user.
  async function checkNew(input, { forApplication = false } = {}) {
    const server = await findServer(db, input.serverId);
    requireServerReady(server);
    requireNginx(server);
    const spec = await checkSpec(
      { name: input.name, type: input.type, domains: input.domains, documentRoot: input.documentRoot ?? 'public', phpVersion: input.phpVersion ?? undefined, proxyPort: input.proxyPort ?? undefined, enabled: true, ssl: false, forceHttps: false },
      server,
    );
    if (spec.type !== 'php') delete spec.phpVersion;
    if (spec.type !== 'proxy') delete spec.proxyPort;
    const nameTaken = await db('websites').where({ server_id: server.id, name_key: spec.name }).first('id');
    if (nameTaken) throw validationError([{ field: 'name', message: `A site named ${spec.name} already exists on ${server.name}` }]);
    if (!forApplication) {
      const app = await db('applications').where({ server_id: server.id, name_key: spec.name }).first('id');
      if (app) throw validationError([{ field: 'name', message: `An app named ${spec.name} already uses this name (and its Linux user) on ${server.name}` }]);
    }
    return { server, spec };
  }

  // A hosting customer's site goes on their account's server and counts
  // against their plan. An app's site belongs to the app's customer
  // ({ customerId }) and is part of the app, so it does not count.
  async function create(actor, input, { forApplication = false, customerId = null } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    if (forApplication) return createChecked(actor, input, { forApplication, customerId });
    await quotas.homeFor(actor, input.serverId);
    return quotas.reserve(actor.customerId, ['websites'], () => createChecked(actor, input, { customerId: actor.customerId }));
  }

  // A site for a subdomain of one of the account's domains (Subdomains
  // page). It counts against the plan's subdomains, not its websites.
  async function createSubdomain(actor, input, { customerId = null, subdomainOf }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    return quotas.reserve(customerId, ['subdomains'], () => createChecked(actor, input, { customerId, subdomainOf }));
  }

  async function createChecked(actor, input, { forApplication = false, customerId = null, subdomainOf = null }) {
    const { server, spec } = await checkNew(input, { forApplication });
    if (!forApplication) await checkCustomerProxy(customerId, spec, server.id);
    await checkCustomerDomains(customerId, spec.domains);

    const id = randomUUID();
    const now = new Date();
    try {
      await db.transaction(async (trx) => {
        await trx('websites').insert({
          id,
          server_id: server.id,
          name: spec.name,
          name_key: spec.name,
          type: spec.type,
          document_root: spec.documentRoot,
          php_version: spec.phpVersion ?? null,
          proxy_port: spec.proxyPort ?? null,
          is_enabled: true,
          force_https: false,
          status: 'creating',
          pending_action: 'create',
          customer_id: customerId,
          subdomain_of: subdomainOf,
          created_by: actor.type === 'user' ? actor.id : null,
          created_at: now,
          updated_at: now,
        });
        await trx('website_domains').insert(
          spec.domains.map((domain, i) => ({ id: randomUUID(), website_id: id, domain, domain_key: domain, is_primary: i === 0, created_at: now, updated_at: now })),
        );
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'domains', message: 'This name or one of these domains was just taken by another site' }]);
      throw err;
    }

    let job;
    try {
      job = await jobs.create(actor, { serverId: server.id, type: 'CREATE_SITE', params: spec, resource: { type: 'website', id } }, { internal: true });
    } catch (err) {
      // Nothing was queued, so nothing exists on the server: drop the record.
      await db('websites').where({ id }).delete();
      throw err;
    }
    await db('websites').where({ id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'website.create', target: target({ id, name: spec.name }), metadata: { serverId: server.id, type: spec.type, domains: spec.domains, jobId: job.id } });
    return { website: await detail(id), job };
  }

  async function update(actor, id, changes, { fromApplication = false, fromPanel = false, fromGit = false } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate, application } = await load(id);
    requireProvisioned(row);
    // A site deployed from Git serves its live release; turning Git deploy
    // off gives the document root back.
    if (row.git_repository_url && !fromGit) {
      if (changes.type !== undefined && changes.type !== row.type) {
        throw new AppError(409, 'WEBSITE_GIT_DEPLOY', 'This website is deployed from Git. Turn Git deploy off in the Deployments tab before changing its type.');
      }
      if (changes.documentRoot !== undefined && changes.documentRoot !== row.document_root && row.document_root === SITE_GIT_DOCUMENT_ROOT) {
        throw validationError([{ field: 'documentRoot', message: 'This website serves its live Git release. Set the folder to serve as the output folder in the Deployments tab.' }]);
      }
    }
    if (['type', 'domains', 'documentRoot', 'phpVersion', 'proxyPort', 'customNginx', 'htaccess', 'spa'].some((key) => changes[key] !== undefined)) await requireNotPanelSite(row, fromPanel);
    if (changes.customNginx !== undefined && (changes.customNginx || '').trim() !== (row.custom_nginx || '')) {
      // Custom rules go into NGINX as text, so only staff write them.
      if (actor?.customerId) throw forbidden('Custom NGINX rules are set by your host');
    }
    if (application && !fromApplication && ((changes.type && changes.type !== row.type) || (changes.proxyPort && changes.proxyPort !== row.proxy_port))) {
      throw new AppError(409, 'WEBSITE_OWNED_BY_APP', `This site serves the app ${application.name}. Change the app's port in its settings instead.`);
    }
    const server = await findServer(db, row.server_id);
    const next = siteSpec(row, domains, certificate, cleanChanges(changes, certificate));
    const spec = await checkSpec(next, server, id);
    if (changes.domains !== undefined) await checkCustomerDomains(row.customer_id, spec.domains, id);
    const added = (spec.customNginx && !row.custom_nginx) || (spec.htaccess && !row.htaccess);
    if (spec.spa && !row.spa && compareVersions(server.agent_version ?? '0.0.0', SPA_AGENT) < 0) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot serve single-page apps. Update the agent to ${SPA_AGENT} or newer first.`);
    }
    if (added && compareVersions(server.agent_version ?? '0.0.0', CUSTOM_NGINX_AGENT) < 0) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot use ${spec.htaccess && !row.htaccess ? '.htaccess files' : 'custom NGINX rules'}. Update the agent to ${CUSTOM_NGINX_AGENT} or newer first.`);
    }
    if (!fromApplication && !application && (spec.type !== row.type || spec.proxyPort !== row.proxy_port)) await checkCustomerProxy(row.customer_id, spec, row.server_id);
    const current = siteSpec(row, domains, certificate);
    if (JSON.stringify(withDefaults(current)) === JSON.stringify(spec)) return { website: await detail(id), job: null };
    const job = await startChange(actor, row, { action: 'update', type: 'CREATE_NGINX_CONFIG', params: spec, pendingSpec: spec });
    await audit.record({ actor, action: 'website.update', target: target(row), metadata: { changes, jobId: job.id } });
    return { website: await detail(id), job };
  }

  async function setEnabled(actor, id, enabled) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate } = await load(id);
    requireProvisioned(row);
    if (Boolean(row.is_enabled) === enabled) return { website: await detail(id), job: null };
    if (!enabled) await requireNotPanelSite(row, false);
    const spec = siteSpec(row, domains, certificate, { enabled });
    const job = await startChange(actor, row, { action: enabled ? 'enable' : 'disable', type: 'CREATE_NGINX_CONFIG', params: spec, pendingSpec: spec });
    await audit.record({ actor, action: enabled ? 'website.enable' : 'website.disable', target: target(row), metadata: { jobId: job.id } });
    return { website: await detail(id), job };
  }

  async function retry(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate } = await load(id);
    requireIdle(row);
    if (row.provisioned_at) throw new AppError(409, 'WEBSITE_READY', 'This website already exists on its server');
    const server = await findServer(db, row.server_id);
    requireServerReady(server);
    requireNginx(server);
    const spec = siteSpec(row, domains, certificate);
    const job = await startChange(actor, row, { action: 'create', type: 'CREATE_SITE', params: spec, status: 'creating' });
    await audit.record({ actor, action: 'website.retry', target: target(row), metadata: { jobId: job.id } });
    return { website: await detail(id), job };
  }

  async function remove(actor, id, { removeFiles }, { fromPanel = false } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, application } = await load(id);
    requireIdle(row);
    await requireNotPanelSite(row, fromPanel);
    if (application && removeFiles) {
      throw new AppError(409, 'WEBSITE_OWNED_BY_APP', `The files belong to the app ${application.name}. Delete the app to remove them, or delete only the site to stop serving its domains.`);
    }
    const params = { name: row.name, removeFiles };
    if (row.php_version) params.phpVersion = row.php_version;
    const job = await startChange(actor, row, { action: 'delete', type: 'DELETE_SITE', params, status: 'deleting' });
    await audit.record({ actor, action: 'website.delete', target: target(row), metadata: { removeFiles, jobId: job.id } });
    return { website: await detail(id), job };
  }

  // ---- SSL ----------------------------------------------------------------

  // The names a wildcard certificate for the site could be for: each covers
  // every domain of the site (the domain and names one level under it).
  // Longest first.
  function wildcardNames(server, domains) {
    if (!agentOperations(server).includes('INSTALL_SSL_CERT')) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot issue wildcard certificates. Update the agent to ${SSL_UPLOAD_MIN_AGENT_VERSION} or newer first.`);
    }
    const names = wildcardZonesFor(domains);
    if (!names.length) {
      throw new AppError(422, 'WILDCARD_NOT_POSSIBLE', `A wildcard certificate covers one domain and the names one level under it (example.com and *.example.com). ${domains.join(', ')} do not fit one; issue a normal certificate instead.`);
    }
    return names;
  }

  // The name a wildcard certificate is for, when this server's DNS zones
  // serve it (Let's Encrypt checks it through DNS).
  async function wildcardZone(server, domains) {
    const names = wildcardNames(server, domains);
    const zones = await db('dns_zones')
      .where({ server_id: server.id, status: 'active' })
      .whereNotNull('domain_key')
      .whereIn('domain', [...new Set(names.flatMap((n) => [n, ...parentDomains(n)]))])
      .pluck('domain');
    const name = names.find((n) => [n, ...parentDomains(n)].some((z) => zones.includes(z)));
    if (!name) {
      const zone = names.at(-1);
      throw new AppError(409, 'DNS_ZONE_MISSING', `Let’s Encrypt checks wildcard certificates through DNS, so ${zone} needs a DNS zone on ${server.name}: add it under Web > DNS Zones and point the domain's name servers at it first.`);
    }
    return name;
  }

  async function issueSsl(actor, id, { email, staging, verifyDns, forceHttps, wildcard = false, dnsProviderId = null }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate } = await load(id);
    requireProvisioned(row);
    if (!row.is_enabled) throw new AppError(409, 'SITE_DISABLED', 'Enable the website first: Let’s Encrypt has to reach it to issue a certificate');
    const server = await findServer(db, row.server_id);
    const stack = fromJson(server.web_stack, null);
    if (stack && !stack.certbot) {
      throw new AppError(409, 'CERTBOT_NOT_INSTALLED', `Certbot is not installed on ${server.name}. Install it from the server's Web stack card first.`);
    }
    const spec = siteSpec(row, domains, certificate, { ssl: true, forceHttps });
    // Without a wildcard certificate, the agent leaves the site's wildcard
    // domains out; a site with nothing else can only have a wildcard one.
    // Through a DNS provider, the shortest name (usually the domain as
    // registered) is checked where the domain's DNS is, not on this server.
    let zone = null;
    let provider = null;
    if (dnsProviderId) {
      zone = wildcardNames(server, spec.domains).at(-1);
      provider = await dnsProviders.forCertificate(actor, dnsProviderId, { server, zone });
    } else if (wildcard || spec.domains.every(isWildcardDomain)) {
      zone = await wildcardZone(server, spec.domains);
    }
    const params = { ...spec, email, staging, verifyDns, ...renewalWindow(server), ...(zone ? { wildcardZone: zone } : {}), ...(provider ? { dnsProvider: provider.payload } : {}) };
    const now = new Date();
    if (certificate) {
      await db('ssl_certificates')
        .where({ id: certificate.id })
        .update({ email, status: certificate.status === 'active' ? 'active' : 'pending', last_error: null, last_error_code: null, updated_at: now });
    } else {
      await db('ssl_certificates').insert({
        id: randomUUID(),
        website_id: id,
        server_id: row.server_id,
        cert_name: `vp-${row.name}`,
        provider: 'letsencrypt',
        status: 'pending',
        email,
        domains: toJson(spec.domains),
        created_at: now,
        updated_at: now,
      });
    }
    let job;
    try {
      job = await startChange(actor, row, { action: 'ssl_issue', type: 'ISSUE_SSL', params, pendingSpec: { forceHttps, staging, dnsProviderId: provider?.row.id ?? null } });
    } catch (err) {
      if (!certificate) await db('ssl_certificates').where({ website_id: id }).delete();
      else await db('ssl_certificates').where({ id: certificate.id }).update({ status: certificate.status });
      throw err;
    }
    await db('ssl_certificates').where({ website_id: id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'ssl.issue', target: target(row), metadata: { domains: spec.domains, staging, forceHttps, wildcardZone: zone ?? undefined, dnsProvider: provider?.row.name, jobId: job.id } });
    return { website: await detail(id), job };
  }

  // A certificate bought elsewhere. The agent checks it again (the key
  // matches, it is valid now and covers every domain) before it goes live.
  async function installSsl(actor, id, { certificate: certificatePem, privateKey, forceHttps }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate } = await load(id);
    requireProvisioned(row);
    const server = await findServer(db, row.server_id);
    requireServerReady(server);
    if (!agentOperations(server).includes('INSTALL_SSL_CERT')) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot install uploaded certificates. Update the agent to ${SSL_UPLOAD_MIN_AGENT_VERSION} or newer first.`);
    }
    const spec = siteSpec(row, domains, certificate, { ssl: true, forceHttps });
    const problems = uploadedCertificateProblems(certificatePem, privateKey, spec.domains);
    if (problems.length) throw validationError(problems);
    const now = new Date();
    if (certificate) {
      await db('ssl_certificates').where({ id: certificate.id }).update({ status: certificate.status === 'active' ? 'active' : 'pending', last_error: null, last_error_code: null, updated_at: now });
    } else {
      await db('ssl_certificates').insert({ id: randomUUID(), website_id: id, server_id: row.server_id, cert_name: `vp-${row.name}`, provider: 'custom', status: 'pending', domains: toJson([]), created_at: now, updated_at: now });
    }
    let job;
    try {
      job = await startChange(actor, row, { action: 'ssl_upload', type: 'INSTALL_SSL_CERT', params: { ...spec, certificate: certificatePem, privateKey }, pendingSpec: { forceHttps } });
    } catch (err) {
      if (!certificate) await db('ssl_certificates').where({ website_id: id }).delete();
      else await db('ssl_certificates').where({ id: certificate.id }).update({ status: certificate.status });
      throw err;
    }
    await db('ssl_certificates').where({ website_id: id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'ssl.upload', target: target(row), metadata: { domains: spec.domains, forceHttps, jobId: job.id } });
    return { website: await detail(id), job };
  }

  async function renewSsl(actor, id, { force }) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, certificate } = await load(id);
    requireProvisioned(row);
    if (!certificate?.not_after) throw new AppError(409, 'SSL_NOT_FOUND', 'This website has no certificate yet. Issue one first.');
    if (certificate.provider === 'custom') throw new AppError(409, 'SSL_CUSTOM', 'This website uses an uploaded certificate, which Let’s Encrypt cannot renew. Upload the renewed certificate instead.');
    const server = await findServer(db, row.server_id);
    const job = await startChange(actor, row, { action: 'ssl_renew', type: 'RENEW_SSL', params: { name: row.name, force, ...renewalWindow(server) } });
    await db('ssl_certificates').where({ id: certificate.id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'ssl.renew', target: target(row), metadata: { force, jobId: job.id } });
    return { website: await detail(id), job };
  }

  // Started by the panel when a certificate is inside its renewal window and
  // Certbot's timer has not renewed it. Returns null when the website is
  // busy with another change (tried again later).
  async function renewSslAutomatically(id, { renewBeforeDays, actor }) {
    const { row, certificate } = await load(id);
    if (!certificate?.not_after || certificate.provider === 'custom' || BUSY_STATUSES.includes(row.status)) return null;
    const params = { name: row.name, force: false, ...(renewBeforeDays ? { renewBeforeDays } : {}) };
    const job = await startChange(actor, row, { action: 'ssl_renew', type: 'RENEW_SSL', params });
    await db('ssl_certificates').where({ id: certificate.id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'ssl.renew', target: target(row), metadata: { automatic: true, jobId: job.id } });
    return job;
  }

  // Serves the site over HTTP only again. The certificate stays on the
  // server (until the site is deleted) so HTTPS can be turned back on.
  async function disableSsl(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const { row, domains, certificate } = await load(id);
    requireProvisioned(row);
    if (certificate?.status !== 'active') throw new AppError(409, 'SSL_NOT_ACTIVE', 'HTTPS is not on for this website');
    await requireNotPanelSite(row, false);
    const spec = siteSpec(row, domains, certificate, { ssl: false, forceHttps: false });
    const job = await startChange(actor, row, { action: 'ssl_disable', type: 'CREATE_NGINX_CONFIG', params: spec, pendingSpec: spec });
    await audit.record({ actor, action: 'ssl.disable', target: target(row), metadata: { jobId: job.id } });
    return { website: await detail(id), job };
  }

  // ---- Logs and files -----------------------------------------------------

  async function logs(actor, id, { log, lines }) {
    await authorize(actor, PERMISSIONS.WEBSITES_LOGS);
    const { row } = await load(id);
    if (!row.provisioned_at) throw new AppError(409, 'WEBSITE_NOT_READY', 'This website does not exist on its server yet');
    return jobs.create(actor, { serverId: row.server_id, type: 'SITE_LOGS', params: { name: row.name, log, lines }, resource: { type: 'website', id } }, { internal: true });
  }

  // The website, when the actor may run this file action on it now.
  async function fileSite(actor, id, action) {
    await authorize(actor, OPERATIONS[FILE_OPERATIONS[action]].permission);
    const { row } = await load(id);
    if (!row.provisioned_at || ['creating', 'deleting'].includes(row.status)) {
      throw new AppError(409, 'WEBSITE_NOT_READY', 'The files of this website are not available right now');
    }
    return row;
  }

  async function files(actor, id, action, body) {
    const type = FILE_OPERATIONS[action];
    const row = await fileSite(actor, id, action);
    return jobs.create(actor, { serverId: row.server_id, type, params: { name: row.name, ...body }, resource: { type: 'website', id } }, { internal: true });
  }

  // ---- Job results --------------------------------------------------------

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'website') return;
    const row = await db('websites').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? {} : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };
    const health = ok && output?.health ? healthColumns(output.health, now) : {};
    const done = { pending_action: null, pending_spec: null, updated_at: now };
    const stable = (enabled, provisioned = row.provisioned_at) => (!provisioned ? 'failed' : enabled ? 'active' : 'disabled');

    switch (job.type) {
      case 'CREATE_SITE': {
        const provisioned = ok ? (row.provisioned_at ?? now) : row.provisioned_at;
        await db('websites').where({ id: row.id }).update({ ...done, ...failure, ...health, provisioned_at: provisioned, status: stable(row.is_enabled, provisioned) });
        break;
      }
      case 'CREATE_NGINX_CONFIG': {
        const spec = fromJson(row.pending_spec, null);
        if (ok && spec) await applySpec(row, spec, now);
        const enabled = ok && spec ? spec.enabled : Boolean(row.is_enabled);
        await db('websites').where({ id: row.id }).update({ ...done, ...failure, ...health, status: stable(enabled) });
        break;
      }
      case 'ISSUE_SSL':
      case 'INSTALL_SSL_CERT': {
        const pending = fromJson(row.pending_spec, {});
        const cert = await db('ssl_certificates').where({ website_id: row.id }).first();
        if (ok) {
          const c = output?.certificate ?? {};
          await db('ssl_certificates').where({ website_id: row.id }).update({
            status: 'active',
            provider: job.type === 'INSTALL_SSL_CERT' ? 'custom' : 'letsencrypt',
            // The DNS provider its renewals go through, if any.
            dns_provider_id: job.type === 'ISSUE_SSL' ? (pending.dnsProviderId ?? null) : null,
            // Reminders for the new certificate's own expiry date.
            expiry_notice: null,
            expiry_notice_for: null,
            domains: toJson(c.domains ?? []),
            issuer: c.issuer ?? null,
            is_staging: Boolean(c.staging),
            not_before: c.notBefore ? new Date(c.notBefore) : null,
            not_after: c.notAfter ? new Date(c.notAfter) : null,
            issued_at: now,
            last_error: null,
            last_error_code: null,
            updated_at: now,
          });
          await db('websites').where({ id: row.id }).update({ ...done, ...health, force_https: Boolean(pending.forceHttps), status: stable(row.is_enabled) });
        } else {
          if (cert) {
            // A failed reissue leaves a working certificate in place.
            await db('ssl_certificates').where({ id: cert.id }).update({ status: cert.status === 'active' ? 'active' : 'failed', ...failure, updated_at: now });
          }
          await db('websites').where({ id: row.id }).update({ ...done, ...failure, status: stable(row.is_enabled) });
        }
        break;
      }
      case 'RENEW_SSL': {
        const c = output?.certificate;
        await db('ssl_certificates')
          .where({ website_id: row.id })
          .update(
            ok && c
              ? { not_before: new Date(c.notBefore), not_after: new Date(c.notAfter), issuer: c.issuer ?? null, last_error: null, last_error_code: null, updated_at: now }
              : { ...failure, updated_at: now },
          );
        await db('websites').where({ id: row.id }).update({ ...done, ...failure, status: stable(row.is_enabled) });
        break;
      }
      case 'DELETE_SITE': {
        if (ok) {
          await markRemoved(row.id, now);
        } else {
          await db('websites').where({ id: row.id }).update({ ...done, ...failure, status: stable(row.is_enabled) });
        }
        break;
      }
      default:
        return;
    }
    if (!ok) logger.info({ websiteId: row.id, job: job.type, error }, 'website change failed');
  }

  // The site is gone from the server (deleted on its own or with its app).
  async function markRemoved(id, now = new Date()) {
    await db.transaction(async (trx) => {
      await trx('websites').where({ id }).update({ pending_action: null, pending_spec: null, status: 'disabled', is_enabled: false, name_key: null, git_webhook_token_hash: null, deleted_at: now, updated_at: now });
      await trx('website_domains').where({ website_id: id }).update({ domain_key: null, updated_at: now });
      await trx('ssl_certificates').where({ website_id: id }).update({ status: 'inactive', updated_at: now });
      await trx('applications').where({ website_id: id }).update({ website_id: null, updated_at: now });
    });
  }

  // Applies a successful configuration change to the record.
  async function applySpec(row, spec, now) {
    await db.transaction(async (trx) => {
      await trx('websites').where({ id: row.id }).update({
        type: spec.type,
        document_root: spec.documentRoot,
        php_version: spec.type === 'php' ? spec.phpVersion : null,
        proxy_port: spec.type === 'proxy' ? spec.proxyPort : null,
        is_enabled: spec.enabled,
        force_https: Boolean(spec.forceHttps),
        custom_nginx: spec.customNginx || null,
        htaccess: Boolean(spec.htaccess),
        spa: Boolean(spec.spa),
        updated_at: now,
      });
      const existing = await trx('website_domains').where({ website_id: row.id });
      const wanted = spec.domains;
      const removed = existing.filter((d) => !wanted.includes(d.domain)).map((d) => d.id);
      if (removed.length) await trx('website_domains').whereIn('id', removed).delete();
      for (const [i, domain] of wanted.entries()) {
        const found = existing.find((d) => d.domain === domain);
        if (found) await trx('website_domains').where({ id: found.id }).update({ is_primary: i === 0, updated_at: now });
        else await trx('website_domains').insert({ id: randomUUID(), website_id: row.id, domain, domain_key: domain, is_primary: i === 0, created_at: now, updated_at: now });
      }
      if (!spec.ssl) await trx('ssl_certificates').where({ website_id: row.id, status: 'active' }).update({ status: 'inactive', updated_at: now });
    });
  }

  // ---- Heartbeat ----------------------------------------------------------

  // Certificates the agent found on the server. Keeps expiry dates right after
  // Certbot renews on its own.
  async function syncCertificates(serverId, certificates) {
    if (!Array.isArray(certificates) || !certificates.length) return;
    const rows = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .where('c.server_id', serverId)
      .whereNull('w.deleted_at')
      .whereNotNull('c.not_after')
      .select('c.id', 'c.not_after', 'c.provider', 'w.name');
    for (const row of rows) {
      const reported = certificates.find((c) => c.site === row.name);
      if (!reported?.notAfter) continue;
      const provider = reported.custom === undefined ? row.provider : reported.custom ? 'custom' : 'letsencrypt';
      if (new Date(reported.notAfter).getTime() === new Date(row.not_after).getTime() && provider === row.provider) continue;
      await db('ssl_certificates').where({ id: row.id }).update({
        not_before: new Date(reported.notBefore),
        not_after: new Date(reported.notAfter),
        issuer: reported.issuer?.slice(0, 255) ?? null,
        domains: toJson(reported.domains ?? []),
        is_staging: Boolean(reported.staging),
        provider,
        updated_at: new Date(),
      });
    }
  }

  // ---- Domains and certificates ------------------------------------------

  function domainQuery() {
    return db('website_domains as d')
      .join('websites as w', 'w.id', 'd.website_id')
      .join('servers as s', 's.id', 'w.server_id')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .select('d.*', 'w.name as website_name', 'w.server_id', 's.name as server_name');
  }

  async function listDomains(actor, query) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const q = scopeQuery(domainQuery(), actor, 'w.customer_id').modify(withoutPanelSite, await panelSite(), 'w.id');
    if (query.serverId) q.where('w.server_id', query.serverId);
    if (query.search) q.where('d.domain', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { domain: 'd.domain', createdAt: 'd.created_at' });
    const certs = rows.length ? await db('ssl_certificates').whereIn('website_id', [...new Set(rows.map((r) => r.website_id))]) : [];
    return {
      items: rows.map((r) => {
        const cert = toPublicCertificate(certs.find((c) => c.website_id === r.website_id));
        return {
          ...toPublicDomain(r),
          website: { id: r.website_id, name: r.website_name },
          server: { id: r.server_id, name: r.server_name },
          https: cert?.status === 'active' && certificateCovers(cert.domains, r.domain) ? cert.state : null,
        };
      }),
      pagination,
    };
  }

  // Looks the domains up in public DNS and compares with the server's addresses.
  async function checkDns(actor, { websiteId, domainId }) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const q = scopeQuery(domainQuery().select('s.public_ip', 's.ip_addresses'), actor, 'w.customer_id');
    if (websiteId) q.where('d.website_id', websiteId);
    if (domainId) q.where('d.id', domainId);
    const rows = await q;
    if (!rows.length) throw notFound(domainId ? 'Domain not found' : 'Website not found');
    const now = new Date();
    const results = [];
    for (const row of rows) {
      const serverAddresses = new Set([row.public_ip, ...fromJson(row.ip_addresses, [])].filter(Boolean).map(normalizeIp));
      // A wildcard resolves through a wildcard record (*): look up a name
      // nothing else uses under it.
      const lookup = isWildcardDomain(row.domain)
        ? await resolveDomain(`vaultpanel-check-${randomUUID().slice(0, 8)}${row.domain.slice(1)}`, `No A or AAAA record named * under ${row.domain.slice(2)}`)
        : await resolveDomain(row.domain);
      let dnsStatus = lookup.status;
      if (dnsStatus === 'resolved') dnsStatus = lookup.addresses.some((a) => serverAddresses.has(normalizeIp(a))) ? 'ok' : 'mismatch';
      await db('website_domains').where({ id: row.id }).update({ dns_status: dnsStatus, dns_addresses: toJson(lookup.addresses), dns_checked_at: now });
      results.push({ ...toPublicDomain({ ...row, dns_status: dnsStatus, dns_addresses: lookup.addresses, dns_checked_at: now }), serverAddresses: [...serverAddresses], detail: lookup.detail ?? null });
    }
    return { items: results };
  }

  async function resolveDomain(domain, missing = 'No A or AAAA records') {
    const settled = await Promise.allSettled([resolver.resolve4(domain), resolver.resolve6(domain)]);
    const addresses = settled.filter((s) => s.status === 'fulfilled').flatMap((s) => s.value);
    if (addresses.length) return { status: 'resolved', addresses };
    const codes = settled.map((s) => s.reason?.code);
    if (codes.every((c) => ['ENOTFOUND', 'ENODATA', 'NXDOMAIN'].includes(c))) return { status: 'unresolved', addresses: [], detail: missing };
    return { status: 'error', addresses: [], detail: `DNS lookup failed (${codes.filter(Boolean).join(', ') || 'unknown error'})` };
  }

  async function listCertificates(actor, query) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const q = db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .join('servers as s', 's.id', 'c.server_id')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .select('c.*', 'w.name as website_name', 'w.status as website_status', 's.name as server_name');
    scopeQuery(q, actor, 'w.customer_id');
    q.modify(withoutPanelSite, await panelSite(), 'w.id');
    if (query.serverId) q.where('c.server_id', query.serverId);
    const now = new Date();
    const soon = new Date(now.getTime() + sslRenewal().warnDays * 86_400_000);
    if (query.status === 'expired') q.where('c.status', 'active').where('c.not_after', '<=', now);
    else if (query.status === 'expiring') q.where('c.status', 'active').where('c.not_after', '>', now).where('c.not_after', '<', soon);
    else if (query.status) q.where('c.status', query.status);
    const { rows, pagination } = await paginate(q, query, { notAfter: 'c.not_after', createdAt: 'c.created_at' });
    return {
      items: rows.map((r) => ({ ...toPublicCertificate(r, now), website: { id: r.website_id, name: r.website_name, status: r.website_status }, server: { id: r.server_id, name: r.server_name } })),
      pagination,
    };
  }

  // Counts for the dashboard.
  async function summary() {
    const panel = await panelSite();
    const rows = await websiteQuery().modify(withoutPanelSite, panel, 'w.id').clearSelect().select('w.status').count({ n: '*' }).groupBy('w.status');
    const byStatus = Object.fromEntries(rows.map((r) => [r.status, Number(r.n)]));
    const soon = new Date(Date.now() + sslRenewal().warnDays * 86_400_000);
    const expiring = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .modify(withoutPanelSite, panel, 'w.id')
      .whereNull('w.deleted_at')
      .where('c.status', 'active')
      .where('c.not_after', '<', soon)
      .count({ n: '*' })
      .first();
    return { total: Object.values(byStatus).reduce((a, b) => a + b, 0), byStatus, sslExpiring: Number(expiring?.n ?? 0) };
  }

  // The live site definition, with changes, for operations built on a
  // website (Git deploy).
  async function specFor(id, changes = {}) {
    const { row, domains, certificate } = await load(id);
    return siteSpec(row, domains, certificate, changes);
  }

  jobs.onFinished(handleJobFinished);

  return {
    list,
    get,
    describe: detail,
    specFor,
    startChange,
    requireIdle,
    requireProvisioned,
    checkNew,
    markRemoved,
    create,
    createSubdomain,
    update,
    setEnabled,
    retry,
    remove,
    issueSsl,
    installSsl,
    renewSslAutomatically,
    renewSsl,
    disableSsl,
    logs,
    files,
    fileSite,
    listDomains,
    checkDns,
    listCertificates,
    syncCertificates,
    summary,
    handleJobFinished,
  };
}

function target(row) {
  return { type: 'website', id: row.id, label: row.name };
}

// The first agent that accepts custom NGINX rules and .htaccess files.
const CUSTOM_NGINX_AGENT = '0.18.0';
// The first agent that serves index.html for single-page apps.
const SPA_AGENT = '0.30.0';

// Quick checks of an uploaded certificate, so mistakes show in the form; the
// agent checks everything again before installing it.
export function uploadedCertificateProblems(certificatePem, keyPem, domains, now = Date.now()) {
  const block = /-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----/.exec(certificatePem)?.[0];
  let leaf;
  try {
    leaf = new X509Certificate(block);
  } catch {
    return [{ field: 'certificate', message: 'Paste the certificate as PEM text (-----BEGIN CERTIFICATE----- ...), followed by its intermediate certificates' }];
  }
  if (/ENCRYPTED/.test(keyPem)) return [{ field: 'privateKey', message: 'The private key has a passphrase. Remove it first (openssl pkey -in key.pem -out plain.pem).' }];
  let key;
  try {
    key = createPrivateKey(keyPem);
  } catch {
    return [{ field: 'privateKey', message: 'Paste the private key as PEM text (-----BEGIN PRIVATE KEY----- ...)' }];
  }
  if (!leaf.checkPrivateKey(key)) return [{ field: 'privateKey', message: 'This private key does not belong to the certificate' }];
  if (Date.parse(leaf.validTo) <= now) return [{ field: 'certificate', message: `The certificate expired on ${new Date(leaf.validTo).toISOString().slice(0, 10)}` }];
  const names = (leaf.subjectAltName ?? '').split(',').map((n) => n.trim()).filter((n) => n.startsWith('DNS:')).map((n) => n.slice(4));
  const missing = domains.filter((d) => !certificateCovers(names, d));
  if (missing.length) return [{ field: 'certificate', message: `The certificate does not cover ${missing.join(', ')} (it covers ${names.join(', ') || 'no domain names'})` }];
  return [];
}

function healthColumns(health, now) {
  if (health.skipped) return {};
  return { health_status: health.ok ? 'ok' : 'failing', health_message: String(health.message ?? '').slice(0, 500), health_checked_at: now };
}

// Maps API changes to site definition fields. Turning HTTPS redirects on is
// only possible while a certificate is active.
function cleanChanges(changes, certificate) {
  const out = {};
  for (const key of ['type', 'domains', 'documentRoot', 'phpVersion', 'proxyPort']) {
    if (changes[key] !== undefined) out[key] = changes[key];
  }
  if (changes.customNginx !== undefined) out.customNginx = changes.customNginx.trim() || null;
  if (changes.htaccess !== undefined) out.htaccess = changes.htaccess || null;
  if (changes.spa !== undefined) out.spa = changes.spa || null;
  if (changes.forceHttps !== undefined) {
    if (changes.forceHttps && certificate?.status !== 'active') {
      throw validationError([{ field: 'forceHttps', message: 'Issue a certificate before redirecting to HTTPS' }]);
    }
    out.forceHttps = changes.forceHttps;
  }
  return out;
}

// Fills the defaults validateParams adds, so specs compare equal.
function withDefaults(spec) {
  const checked = validateParams(OPERATIONS.CREATE_NGINX_CONFIG.params, spec);
  return checked.ok ? checked.value : spec;
}

function normalizeIp(ip) {
  return String(ip).replace(/^::ffff:/, '').toLowerCase();
}
