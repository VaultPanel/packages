import { PERMISSIONS, siteNameForDomain } from '@vaultpanel/shared';
import { AppError, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { getSetting } from '../models/settingModel.js';
import { systemActor } from './actor.js';

// Subdomains: blog.example.com added under one of the account's own
// domains, served as its own site on the parent's server. When one of the
// panel's DNS zones holds the name, its A (and AAAA) record is added there
// once the site exists, and taken out again when the site is deleted.
//
// It also adds DNS zones for customers' new domains, on servers set to do
// so (DNS page, "For customers").

const MAX_PARENTS = 500;

export function createSubdomainService({ db, logger, audit, authorize, jobs, websites, quotas, dns }) {
  // The domains a subdomain can go under: those of the actor's websites
  // (every website's, for staff), without www. names and the panel's own.
  async function parents(actor) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const panel = fromJson(await getSetting(db, 'panel.domain'), null);
    const q = db('website_domains as d')
      .join('websites as w', 'w.id', 'd.website_id')
      .join('servers as s', 's.id', 'w.server_id')
      .leftJoin('customers as c', 'c.id', 'w.customer_id')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .whereNotNull('d.domain_key')
      .whereNot('d.domain', 'like', 'www.%')
      .select('d.domain', 'w.id as website_id', 'w.name as website_name', 'w.server_id', 's.name as server_name', 's.web_stack', 'w.customer_id', 'c.name as customer_name')
      .orderBy('d.domain')
      .limit(MAX_PARENTS);
    if (actor.customerId) q.where('w.customer_id', actor.customerId);
    if (panel?.websiteId) q.whereNot('w.id', panel.websiteId);
    const rows = await q;
    return {
      items: rows.map((r) => ({
        domain: r.domain,
        website: { id: r.website_id, name: r.website_name },
        server: { id: r.server_id, name: r.server_name, phpVersions: fromJson(r.web_stack, null)?.phpVersions ?? [] },
        ...(actor.customerId ? {} : { customer: r.customer_id ? { id: r.customer_id, name: r.customer_name } : null }),
      })),
    };
  }

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const parent = await db('website_domains as d')
      .join('websites as w', 'w.id', 'd.website_id')
      .where('d.domain_key', input.parentDomain)
      .whereNull('w.deleted_at')
      .first('d.domain', 'w.id', 'w.server_id', 'w.customer_id');
    const panel = fromJson(await getSetting(db, 'panel.domain'), null);
    if (!parent || parent.id === panel?.websiteId || (actor.customerId && parent.customer_id !== actor.customerId)) {
      throw validationError([{ field: 'parentDomain', message: 'Choose one of your domains' }]);
    }
    if (actor.customerId) await quotas.homeFor(actor, parent.server_id);
    const domain = `${input.name}.${parent.domain}`;
    const taken = [
      ...(await db('websites').where({ server_id: parent.server_id }).whereNotNull('name_key').pluck('name_key')),
      ...(await db('applications').where({ server_id: parent.server_id }).whereNotNull('name_key').pluck('name_key')),
    ];
    const name = siteNameForDomain(domain, taken);
    if (!name) throw new AppError(409, 'NAME_TAKEN', `Could not find a free site name for ${domain} on this server`);
    const result = await websites.createSubdomain(
      actor,
      { serverId: parent.server_id, name, type: input.type, domains: [domain], documentRoot: input.documentRoot, phpVersion: input.type === 'php' ? input.phpVersion : undefined },
      { customerId: parent.customer_id ?? null, subdomainOf: parent.domain },
    );
    await audit.record({ actor, action: 'subdomain.create', target: { type: 'website', id: result.website.id, label: result.website.name }, metadata: { domain, parent: parent.domain } });
    return result;
  }

  // ---- After a site is created or deleted on its server -------------------

  // The A (and AAAA) record for a new subdomain, in the panel's zone that
  // holds it, unless the name already has an address or alias there.
  async function addRecords(row, domain) {
    const here = await dns.recordsAt(domain);
    if (!here) return;
    if (here.records.some((r) => r.name === '@' && ['A', 'AAAA', 'CNAME'].includes(r.type))) return;
    const server = await db('servers').where({ id: row.server_id }).first();
    const { ipv4, ipv6 } = dns.serverAddresses(server);
    const parentHasIpv6 = (await dns.recordsAt(row.subdomain_of))?.records.some((r) => r.name === '@' && r.type === 'AAAA');
    const wanted = [...(ipv4 ? [{ name: '@', type: 'A', value: ipv4 }] : []), ...(ipv6 && parentHasIpv6 ? [{ name: '@', type: 'AAAA', value: ipv6 }] : [])];
    if (!wanted.length) return;
    const result = await dns.putRecords(systemActor('subdomains'), domain, wanted);
    if (!result?.added) return;
    await db('websites').where({ id: row.id }).update({ dns_records: toJson(wanted.map((r) => ({ domain, type: r.type, value: r.value }))) });
  }

  async function onJobFinished(job, { status }) {
    if (job.resource_type !== 'website' || status !== 'succeeded' || !['CREATE_SITE', 'DELETE_SITE'].includes(job.type)) return;
    const row = await db('websites').where({ id: job.resource_id }).first();
    if (!row) return;
    if (job.type === 'CREATE_SITE') {
      const domains = (await db('website_domains').where({ website_id: row.id }).orderBy('is_primary', 'desc')).map((d) => d.domain);
      await dns.addCustomerZones(row, domains).catch((err) => logger.warn({ err, websiteId: row.id }, 'could not add DNS zones for the site'));
      if (row.subdomain_of && !fromJson(row.dns_records, []).length && domains[0]) {
        await addRecords(row, domains[0]).catch((err) => logger.warn({ err, websiteId: row.id }, 'could not add the DNS record for the subdomain'));
      }
    } else if (job.type === 'DELETE_SITE' && row.deleted_at) {
      const added = fromJson(row.dns_records, []);
      const byDomain = Map.groupBy(added, (r) => r.domain);
      for (const [domain, records] of byDomain) {
        await dns
          .dropRecords(systemActor('subdomains'), domain, records.map((r) => ({ name: '@', type: r.type, value: r.value })))
          .catch((err) => logger.warn({ err, websiteId: row.id }, 'could not remove the DNS record of the subdomain'));
      }
      if (added.length) await db('websites').where({ id: row.id }).update({ dns_records: null });
    }
  }

  jobs.onFinished(onJobFinished);

  return { parents, create, onJobFinished };
}
