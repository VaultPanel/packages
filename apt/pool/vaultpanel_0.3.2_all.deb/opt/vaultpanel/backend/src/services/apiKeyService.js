import { randomUUID } from 'node:crypto';
import { API_KEY_PATTERN, API_KEY_PREFIX, MAX_API_KEYS, PERMISSIONS } from '@vaultpanel/shared';
import { toPublicApiKey } from '../models/hostingModel.js';
import { AppError, notFound } from '../utils/errors.js';
import { newToken, sha256Hex } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { apiKeyActor } from './actor.js';

// What each API key scope may do. A key never gets more than this, whoever
// made it.
const SCOPE_PERMISSIONS = {
  billing: [PERMISSIONS.CUSTOMERS_READ, PERMISSIONS.CUSTOMERS_MANAGE],
};
const TOUCH_INTERVAL_MS = 60_000;

// API keys for billing systems (phase 8). The key is shown once when it is
// made; only its SHA-256 is kept, like session tokens.
export function createApiKeyService({ db, audit, authorize }) {
  function keyQuery() {
    return db('api_keys as k').leftJoin('users as u', 'u.id', 'k.created_by').select('k.*', 'u.email as created_by_email');
  }

  async function list(actor) {
    await authorize(actor, PERMISSIONS.BILLING_MANAGE);
    const rows = await keyQuery().orderByRaw('k.revoked_at IS NULL DESC').orderBy('k.created_at', 'desc');
    return { items: rows.map(toPublicApiKey) };
  }

  async function create(actor, { name, scopes }) {
    await authorize(actor, PERMISSIONS.BILLING_MANAGE);
    const active = await db('api_keys').whereNull('revoked_at').count({ n: '*' }).first();
    if (Number(active.n) >= MAX_API_KEYS) throw new AppError(409, 'TOO_MANY_KEYS', `Up to ${MAX_API_KEYS} keys. Revoke one you no longer use.`);
    const key = `${API_KEY_PREFIX}${newToken(32)}`;
    const id = randomUUID();
    const now = new Date();
    await db('api_keys').insert({
      id,
      name,
      prefix: key.slice(0, 12),
      key_hash: sha256Hex(key),
      scopes: toJson(scopes),
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    await audit.record({ actor, action: 'api_key.create', target: { type: 'api_key', id, label: name }, metadata: { scopes } });
    return { apiKey: toPublicApiKey(await keyQuery().where('k.id', id).first()), key };
  }

  async function revoke(actor, id) {
    await authorize(actor, PERMISSIONS.BILLING_MANAGE);
    const row = await db('api_keys').where({ id }).first();
    if (!row) throw notFound('API key not found');
    if (!row.revoked_at) {
      await db('api_keys').where({ id }).update({ revoked_at: new Date(), revoked_by: actor.type === 'user' ? actor.id : null, updated_at: new Date() });
      await audit.record({ actor, action: 'api_key.revoke', target: { type: 'api_key', id, label: row.name } });
    }
    return toPublicApiKey(await keyQuery().where('k.id', id).first());
  }

  // The actor for a request carrying a key, or null.
  async function resolve(key, meta = {}) {
    if (typeof key !== 'string' || !API_KEY_PATTERN.test(key)) return null;
    const row = await db('api_keys').where({ key_hash: sha256Hex(key) }).whereNull('revoked_at').first();
    if (!row) return null;
    if (!row.last_used_at || Date.now() - new Date(row.last_used_at).getTime() > TOUCH_INTERVAL_MS || row.last_used_ip !== (meta.ip ?? null)) {
      await db('api_keys').where({ id: row.id }).update({ last_used_at: new Date(), last_used_ip: meta.ip ?? null });
    }
    const permissions = [...new Set(fromJson(row.scopes, []).flatMap((s) => SCOPE_PERMISSIONS[s] ?? []))];
    return apiKeyActor(row, permissions, meta);
  }

  return { list, create, revoke, resolve };
}
