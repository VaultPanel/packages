import { randomUUID, createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, open, rename, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import {
  BACKUP_DOWNLOAD_HOURS,
  BACKUP_RESOURCES,
  PERMISSIONS,
  isValidTimeZone,
  nextCronRun,
  parseCron,
} from '@vaultpanel/shared';
import { toPublicBackup, toPublicRestore, toPublicSchedule } from '../models/automationModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { paginate } from '../utils/pagination.js';
import { assertOwned, isCustomer, scopeQuery } from './tenancy.js';
import { addSeconds } from '../utils/time.js';
import { systemActor } from './actor.js';
import { loadResource, requireReady, resourceExistsSql, resourceNameSql, whereResource } from './resources.js';

// Backups of websites, apps and databases, kept on their server by the agent
// (see agent/src/operations/backups.js). A backup row is created first and
// completed (size, checksum) when the agent reports the CREATE_BACKUP job.
//
// Restores are jobs too, recorded in backup_restores; by default the agent
// first saves a safety copy of the current state as another backup.
//
// Schedules are run by the panel's worker: when one is due it queues a
// backup, and once that succeeds the schedule's older backups beyond its
// keep count are deleted.
//
// Downloads: the agent uploads the file to the panel in chunks
// (UPLOAD_BACKUP), the panel checks the checksum, and the copy can be
// downloaded for a few hours before it is removed.
//
// Storage (see backupStorageService.js): a backup or schedule can name an
// S3-compatible destination. The agent copies the backup there and, unless
// the destination keeps local copies, removes it from the server. Restores,
// downloads and deletes then send the destination along, so the agent can
// fetch or delete the object. If the copy fails the backup stays on the
// server, completed, with storage_error saying why.

const DOWNLOAD_EXTENSIONS = { site: 'tar.gz', app: 'tar.gz', database: 'sql.gz' };

export function createBackupService({ db, config, logger, audit, authorize, jobs, events, storage }) {
  const downloadDir = path.join(config.dataDir, 'backup-downloads');

  // ---- Reading ------------------------------------------------------------

  function backupQuery() {
    return db('backups as b')
      .join('servers as s', 's.id', 'b.server_id')
      .leftJoin('users as u', 'u.id', 'b.created_by')
      .leftJoin('backup_storages as st', 'st.id', 'b.storage_id')
      .whereNull('b.deleted_at')
      .whereNull('s.deleted_at')
      .select('b.*', 's.name as server_name', 'u.email as created_by_email', 'st.name as storage_name', db.raw(`(${resourceExistsSql('b')}) as resource_exists`));
  }

  async function loadBackup(id) {
    const row = await backupQuery().where('b.id', id).first();
    if (!row) throw notFound('Backup not found');
    return row;
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.BACKUPS_READ);
    const q = scopeQuery(backupQuery(), actor, 'b.customer_id');
    if (query.serverId) q.where('b.server_id', query.serverId);
    whereResource(db, q, 'b', query);
    if (query.status) q.where('b.status', query.status);
    if (query.trigger) q.where('b.trigger', query.trigger);
    if (query.storageId) q.where('b.storage_id', query.storageId);
    if (query.search) q.where('b.resource_name', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'b.created_at', size: 'b.size_bytes' });
    return { items: rows.map((r) => toPublicBackup(r)), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_READ);
    const row = await loadBackup(id);
    const restores = await db('backup_restores as r')
      .leftJoin('users as u', 'u.id', 'r.requested_by')
      .where('r.backup_id', id)
      .orderBy('r.created_at', 'desc')
      .limit(20)
      .select('r.*', 'u.email as requested_by_email');
    return { ...toPublicBackup(row), restores: restores.map(toPublicRestore) };
  }

  // ---- Backing up -----------------------------------------------------------

  async function create(actor, { resourceType, resourceId, storageId = null }, { trigger = 'manual', scheduleId = null } = {}) {
    await authorize(actor, PERMISSIONS.BACKUPS_CREATE);
    const resource = await loadResource(db, resourceType, resourceId);
    assertOwned(actor, resource.customerId, `This ${BACKUP_RESOURCES[resourceType].label.toLowerCase()} was not found`);
    requireReady(resource);
    const running = await db('backups').where({ resource_type: resourceType, resource_id: resourceId, status: 'creating' }).whereNull('deleted_at').first('id', 'job_id');
    if (running) throw new AppError(409, 'BACKUP_RUNNING', `A backup of this ${BACKUP_RESOURCES[resourceType].label.toLowerCase()} is already running`, { jobId: running.job_id });
    const server = storageId ? await db('servers').where({ id: resource.serverId }).first() : null;
    const destination = await storage.forBackup(actor, storageId, server);

    const id = randomUUID();
    const now = new Date();
    await db('backups').insert({
      id,
      server_id: resource.serverId,
      resource_type: resourceType,
      resource_id: resourceId,
      resource_name: resource.name,
      status: 'creating',
      trigger,
      schedule_id: scheduleId,
      storage_id: destination?.id ?? null,
      customer_id: resource.customerId,
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    const params = { backupId: id, kind: resource.agentKind, name: resource.name };
    if (destination) {
      params.storage = storage.payload(destination, storage.keyFor(destination, { serverId: resource.serverId, ...params }), { keepLocal: Boolean(destination.keep_local) });
    }
    let job;
    try {
      job = await jobs.create(actor, { serverId: resource.serverId, type: 'CREATE_BACKUP', params, resource: { type: 'backup', id } }, { internal: true });
    } catch (err) {
      await db('backups').where({ id }).delete();
      throw err;
    }
    await db('backups').where({ id }).update({ job_id: job.id });
    await audit.record({ actor, action: 'backup.create', target: { type: resourceType, id: resourceId, label: resource.name }, metadata: { backupId: id, trigger, jobId: job.id, storageId: destination?.id ?? null } });
    return { backup: toPublicBackup(await loadBackup(id)), job };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const row = await loadBackup(id);
    if (row.status === 'creating' || row.status === 'deleting') throw new AppError(409, 'BACKUP_BUSY', 'This backup is still being written or deleted');
    if (await restoreRunning(id)) throw new AppError(409, 'BACKUP_BUSY', 'This backup is being restored');
    let job = null;
    if (row.status === 'completed') {
      const claimed = await db('backups').where({ id, status: 'completed' }).update({ status: 'deleting', updated_at: new Date() });
      if (!claimed) throw new AppError(409, 'BACKUP_BUSY', 'This backup changed meanwhile; try again');
      try {
        job = await jobs.create(actor, { serverId: row.server_id, type: 'DELETE_BACKUP', params: await withStorage(row, target(row)), resource: { type: 'backup', id } }, { internal: true });
      } catch (err) {
        await db('backups').where({ id }).update({ status: 'completed' });
        throw err;
      }
    } else {
      // Failed and missing backups have no file to delete.
      await softDelete(row);
    }
    await audit.record({ actor, action: 'backup.delete', target: backupTarget(row), metadata: { jobId: job?.id ?? null } });
    return { job };
  }

  // Adds the destination to a job's parameters when the backup is stored there.
  async function withStorage(row, params) {
    if (!row.storage_id || !row.storage_key) return params;
    const destination = await storage.load(row.storage_id);
    return { ...params, storage: storage.payload(destination, row.storage_key) };
  }

  // Jobs on a backup that is only in the storage need an agent that can reach it.
  async function requireReachable(row) {
    if (!row.storage_key) return;
    const server = await db('servers').where({ id: row.server_id }).first();
    storage.requireCapableAgent(server);
  }

  async function softDelete(row) {
    const now = new Date();
    await db('backups').where({ id: row.id }).update({ deleted_at: now, updated_at: now, download_path: null, download_ready_until: null });
    if (row.download_path) await rm(row.download_path, { force: true });
  }

  // ---- Restoring ------------------------------------------------------------

  async function restoreRunning(backupId) {
    return db('backup_restores').where({ backup_id: backupId, status: 'running' }).first('id');
  }

  async function restore(actor, id, { safetyBackup = true } = {}) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const row = await loadBackup(id);
    if (row.status !== 'completed' || !row.sha256) throw new AppError(409, 'BACKUP_NOT_RESTORABLE', 'Only completed backups can be restored');
    const resource = await loadResource(db, row.resource_type, row.resource_id).catch(() => null);
    if (!resource) throw new AppError(409, 'RESOURCE_DELETED', `The ${BACKUP_RESOURCES[row.resource_type].label.toLowerCase()} ${row.resource_name} was deleted, so this backup cannot be restored into it. Download it instead.`);
    requireReady(resource);
    const busy = await db('backup_restores as r')
      .join('backups as b', 'b.id', 'r.backup_id')
      .where({ 'b.resource_type': row.resource_type, 'b.resource_id': row.resource_id, 'r.status': 'running' })
      .first('r.id');
    if (busy) throw new AppError(409, 'RESTORE_RUNNING', 'A restore of this is already running');

    const restoreId = randomUUID();
    const safetyId = safetyBackup ? randomUUID() : null;
    const now = new Date();
    await requireReachable(row);
    const params = await withStorage(row, { ...target(row), sha256: row.sha256 });
    if (safetyId) params.safetyBackupId = safetyId;
    if (resource.type === 'application') {
      if (resource.row.port) params.port = resource.row.port;
      params.healthCheckSeconds = resource.row.health_check_seconds ?? 30;
    }
    await db.transaction(async (trx) => {
      await trx('backup_restores').insert({ id: restoreId, backup_id: id, server_id: row.server_id, safety_backup_id: safetyId, status: 'running', requested_by: actor.type === 'user' ? actor.id : null, created_at: now, updated_at: now });
      if (safetyId) {
        await trx('backups').insert({ id: safetyId, server_id: row.server_id, resource_type: row.resource_type, resource_id: row.resource_id, resource_name: row.resource_name, status: 'creating', trigger: 'pre_restore', customer_id: row.customer_id, created_by: actor.type === 'user' ? actor.id : null, created_at: now, updated_at: now });
      }
    });
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type: 'RESTORE_BACKUP', params, resource: { type: 'backup_restore', id: restoreId } }, { internal: true });
    } catch (err) {
      await db('backup_restores').where({ id: restoreId }).delete();
      if (safetyId) await db('backups').where({ id: safetyId }).delete();
      throw err;
    }
    await db('backup_restores').where({ id: restoreId }).update({ job_id: job.id });
    if (safetyId) await db('backups').where({ id: safetyId }).update({ job_id: job.id });
    await audit.record({ actor, action: 'backup.restore', target: { type: row.resource_type, id: row.resource_id, label: row.resource_name }, metadata: { backupId: id, restoreId, safetyBackupId: safetyId, jobId: job.id } });
    return { restore: toPublicRestore({ id: restoreId, backup_id: id, job_id: job.id, safety_backup_id: safetyId, status: 'running', created_at: now }), job };
  }

  // ---- Downloads --------------------------------------------------------------

  function downloadFile(row, suffix = '') {
    return path.join(downloadDir, `${row.id}.${DOWNLOAD_EXTENSIONS[BACKUP_RESOURCES[row.resource_type].agentKind]}${suffix}`);
  }

  async function prepareDownload(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const row = await loadBackup(id);
    if (row.status !== 'completed' || !row.sha256) throw new AppError(409, 'BACKUP_NOT_READY', 'Only completed backups can be downloaded');
    if (row.download_path && new Date(row.download_ready_until) > new Date()) return { ready: true, backup: toPublicBackup(row) };
    if (row.download_job_id) {
      const active = await db('jobs').where({ id: row.download_job_id }).whereIn('status', ['queued', 'dispatched', 'running']).first('id');
      if (active) return { ready: false, job: { id: active.id } };
    }
    if (Number(row.size_bytes) > config.backupDownloadMaxBytes) {
      const where = row.local_copy && row.file_path ? `Copy it from the server with scp or SFTP instead: ${row.file_path}` : `Download it from the storage ${row.storage_name ?? ''} instead: ${row.storage_key}`;
      throw new AppError(409, 'BACKUP_TOO_LARGE', `This backup is larger than the ${Math.round(config.backupDownloadMaxBytes / 1024 / 1024)} MB the panel accepts for downloads (VAULTPANEL_BACKUP_DOWNLOAD_MAX_MB). ${where}`);
    }
    await requireReachable(row);
    await mkdir(downloadDir, { recursive: true, mode: 0o700 });
    await rm(downloadFile(row, '.part'), { force: true });
    const job = await jobs.create(actor, { serverId: row.server_id, type: 'UPLOAD_BACKUP', params: await withStorage(row, { ...target(row), sha256: row.sha256 }), resource: { type: 'backup_download', id } }, { internal: true });
    await db('backups').where({ id }).update({ download_job_id: job.id, download_path: null, download_ready_until: null });
    await audit.record({ actor, action: 'backup.download_prepare', target: backupTarget(row), metadata: { jobId: job.id } });
    return { ready: false, job };
  }

  // The file to send to the browser. Each download is audited.
  async function openDownload(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const row = await loadBackup(id);
    if (!row.download_path || new Date(row.download_ready_until) <= new Date()) {
      throw new AppError(409, 'DOWNLOAD_NOT_READY', 'Prepare the download first');
    }
    const info = await stat(row.download_path).catch(() => null);
    if (!info) throw new AppError(409, 'DOWNLOAD_NOT_READY', 'The prepared copy is gone; prepare the download again');
    await audit.record({ actor, action: 'backup.download', target: backupTarget(row), metadata: { sizeBytes: info.size } });
    const stamp = new Date(row.created_at).toISOString().slice(0, 16).replace(/[-:T]/g, '');
    const ext = path.basename(row.download_path).split('.').slice(1).join('.');
    return { path: row.download_path, sizeBytes: info.size, filename: `${row.resource_name}-${stamp}.${ext}` };
  }

  // A chunk of an UPLOAD_BACKUP job, from the agent of the backup's server.
  async function receiveChunk(serverId, id, { offset, data, final }) {
    const row = await db('backups').where({ id, server_id: serverId }).whereNull('deleted_at').first();
    if (!row) throw notFound('Backup not found');
    const job = row.download_job_id ? await db('jobs').where({ id: row.download_job_id, server_id: serverId }).first('status') : null;
    if (!job || !['dispatched', 'running'].includes(job.status)) throw new AppError(409, 'NO_UPLOAD', 'No upload of this backup is running');
    const bytes = Buffer.from(data, 'base64');
    const file = downloadFile(row, '.part');
    await mkdir(downloadDir, { recursive: true, mode: 0o700 });
    const handle = await open(file, offset === 0 ? 'w' : 'a', 0o600);
    try {
      const { size } = await handle.stat();
      if (size !== offset) throw new AppError(409, 'OFFSET_MISMATCH', `Expected offset ${size}`, { expected: size });
      if (size + bytes.length > Number(row.size_bytes)) throw new AppError(422, 'UPLOAD_TOO_LARGE', 'More data than the backup holds');
      await handle.write(bytes);
    } finally {
      await handle.close();
    }
    return { received: offset + bytes.length, final: Boolean(final) };
  }

  async function finishDownload(job, row, ok) {
    const part = downloadFile(row, '.part');
    if (ok) {
      const actual = await hashFile(part).catch(() => null);
      if (actual && actual.sizeBytes === Number(row.size_bytes) && actual.sha256 === row.sha256) {
        const file = downloadFile(row);
        await rename(part, file);
        await db('backups').where({ id: row.id }).update({ download_path: file, download_ready_until: addSeconds(new Date(), BACKUP_DOWNLOAD_HOURS * 3600) });
        return;
      }
      logger.warn({ backupId: row.id, actual }, 'uploaded backup does not match its checksum');
      await db('jobs').where({ id: job.id }).update({ status: 'failed', error_code: 'UPLOAD_CORRUPT', error_message: 'The copy the panel received does not match the backup’s checksum. Try again.' });
    }
    await rm(part, { force: true });
  }

  // ---- Schedules ------------------------------------------------------------

  function scheduleQuery() {
    return db('backup_schedules as bs')
      .join('servers as s', 's.id', 'bs.server_id')
      .leftJoin('backups as lb', 'lb.id', 'bs.last_backup_id')
      .leftJoin('backup_storages as st', 'st.id', 'bs.storage_id')
      .whereNull('s.deleted_at')
      .select('bs.*', 's.name as server_name', 'lb.status as last_backup_status', 'lb.storage_error as last_storage_error', 'st.name as storage_name', db.raw(`(${resourceNameSql('bs')}) as resource_name`));
  }

  async function listSchedules(actor, query) {
    await authorize(actor, PERMISSIONS.BACKUPS_READ);
    const q = scopeQuery(scheduleQuery(), actor, 'bs.customer_id');
    if (query.serverId) q.where('bs.server_id', query.serverId);
    whereResource(db, q, 'bs', query);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'bs.created_at', nextRunAt: 'bs.next_run_at' });
    return { items: rows.map(toPublicSchedule), pagination };
  }

  function checkSchedule({ schedule, timezone }) {
    const parsed = parseCron(schedule);
    if (!parsed.ok) throw validationError([{ field: 'schedule', message: parsed.error }]);
    if (!isValidTimeZone(timezone)) throw validationError([{ field: 'timezone', message: 'Unknown time zone' }]);
    return parsed.expression;
  }

  // One schedule per website, app or database: saving replaces it.
  async function saveSchedule(actor, input) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const resource = await loadResource(db, input.resourceType, input.resourceId);
    assertOwned(actor, resource.customerId, `This ${BACKUP_RESOURCES[input.resourceType].label.toLowerCase()} was not found`);
    const expression = checkSchedule(input);
    const nextRunAt = input.enabled ? nextCronRun(expression, { timeZone: input.timezone }) : null;
    const existing = await db('backup_schedules').where({ resource_type: input.resourceType, resource_id: input.resourceId }).first('id', 'storage_id');
    // Customers keep the destination staff chose; they cannot pick one.
    const storageId = isCustomer(actor) ? (existing?.storage_id ?? null) : (input.storageId ?? null);
    if (storageId && storageId !== existing?.storage_id) {
      const server = await db('servers').where({ id: resource.serverId }).first();
      await storage.forBackup(actor, storageId, server);
    }
    const now = new Date();
    const values = { schedule: expression, timezone: input.timezone, keep_count: input.keepCount, enabled: input.enabled, storage_id: storageId, next_run_at: nextRunAt, updated_at: now };
    let id = existing?.id;
    if (id) await db('backup_schedules').where({ id }).update(values);
    else {
      id = randomUUID();
      await db('backup_schedules').insert({ id, server_id: resource.serverId, resource_type: input.resourceType, resource_id: input.resourceId, customer_id: resource.customerId, created_by: actor.type === 'user' ? actor.id : null, created_at: now, ...values });
    }
    await audit.record({ actor, action: existing ? 'backup_schedule.update' : 'backup_schedule.create', target: { type: input.resourceType, id: input.resourceId, label: resource.name }, metadata: { schedule: expression, timezone: input.timezone, keepCount: input.keepCount, enabled: input.enabled, storageId } });
    return { schedule: toPublicSchedule(await scheduleQuery().where('bs.id', id).first()) };
  }

  async function removeSchedule(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_MANAGE);
    const row = await scheduleQuery().where('bs.id', id).first();
    if (!row) throw notFound('Schedule not found');
    await db('backup_schedules').where({ id }).delete();
    await audit.record({ actor, action: 'backup_schedule.delete', target: { type: row.resource_type, id: row.resource_id, label: row.resource_name } });
  }

  // Queues the backups whose schedule is due. Run by the worker.
  async function runDueSchedules(now = new Date()) {
    const due = await db('backup_schedules').where({ enabled: true }).where('next_run_at', '<=', now).orderBy('next_run_at').limit(20);
    let started = 0;
    for (const schedule of due) {
      const next = nextCronRun(schedule.schedule, { from: now, timeZone: schedule.timezone });
      // Claim it, so two workers never start the same run.
      const claimed = await db('backup_schedules').where({ id: schedule.id, next_run_at: schedule.next_run_at }).update({ next_run_at: next, last_run_at: now, updated_at: now });
      if (!claimed) continue;
      const resource = await loadResource(db, schedule.resource_type, schedule.resource_id).catch(() => null);
      if (!resource) {
        await db('backup_schedules').where({ id: schedule.id }).delete();
        continue;
      }
      try {
        const { backup } = await create(systemActor('backup schedule'), { resourceType: schedule.resource_type, resourceId: schedule.resource_id, storageId: schedule.storage_id }, { trigger: 'schedule', scheduleId: schedule.id });
        await db('backup_schedules').where({ id: schedule.id }).update({ last_backup_id: backup.id });
        started += 1;
      } catch (err) {
        // Recorded as a failed backup, so the history and webhooks show it.
        const id = randomUUID();
        await db('backups').insert({ id, server_id: resource.serverId, resource_type: resource.type, resource_id: resource.id, resource_name: resource.name, status: 'failed', trigger: 'schedule', schedule_id: schedule.id, storage_id: schedule.storage_id, error_code: (err.code ?? 'BACKUP_FAILED').slice(0, 64), error: err.message, created_at: now, updated_at: now });
        await db('backup_schedules').where({ id: schedule.id }).update({ last_backup_id: id });
        await emitBackup('backup.failed', { id, resource_type: resource.type, resource_name: resource.name, server_id: resource.serverId, trigger: 'schedule' }, { code: err.code, message: err.message });
        logger.warn({ err, scheduleId: schedule.id }, 'scheduled backup could not start');
      }
    }
    return started;
  }

  // Deletes a schedule's completed backups beyond its keep count.
  async function applyRetention(scheduleId) {
    const schedule = await db('backup_schedules').where({ id: scheduleId }).first();
    if (!schedule) return 0;
    const old = await db('backups').where({ schedule_id: scheduleId, status: 'completed' }).whereNull('deleted_at').orderBy('created_at', 'desc').offset(schedule.keep_count).limit(50);
    const actor = systemActor('backup retention');
    for (const row of old) {
      const claimed = await db('backups').where({ id: row.id, status: 'completed' }).update({ status: 'deleting', updated_at: new Date() });
      if (!claimed) continue;
      try {
        await jobs.create(actor, { serverId: row.server_id, type: 'DELETE_BACKUP', params: await withStorage(row, target(row)), resource: { type: 'backup', id: row.id } }, { internal: true });
      } catch (err) {
        await db('backups').where({ id: row.id }).update({ status: 'completed' });
        logger.warn({ err, backupId: row.id }, 'could not delete an old scheduled backup');
      }
    }
    // Failed runs are kept for a while, then pruned the same way.
    await db('backups').where({ schedule_id: scheduleId, status: 'failed' }).whereNull('deleted_at').where('created_at', '<', addSeconds(new Date(), -30 * 86_400)).update({ deleted_at: new Date() });
    return old.length;
  }

  // ---- Job results ------------------------------------------------------------

  async function emitBackup(event, row, error = null, extra = {}) {
    const server = await db('servers').where({ id: row.server_id }).first('name');
    await events.emit(event, {
      backup: { id: row.id, trigger: row.trigger, sizeBytes: row.size_bytes === undefined || row.size_bytes === null ? null : Number(row.size_bytes) },
      resource: { type: row.resource_type, name: row.resource_name },
      server: { id: row.server_id, name: server?.name ?? null },
      ...(error ? { error: { code: error.code ?? null, message: error.message ?? null } } : {}),
      ...extra,
    });
  }

  // output.localKept / output.stored come from agents 0.13.0+; older agents
  // only ever keep backups on the server.
  async function completeBackup(id, output, now) {
    await db('backups').where({ id }).update({
      status: 'completed',
      local_copy: output?.localKept !== false,
      storage_key: output?.stored?.key?.slice(0, 512) ?? null,
      storage_error: output?.storageError?.message ?? null,
      file_path: output?.path?.slice(0, 500) ?? null,
      size_bytes: output?.sizeBytes ?? null,
      sha256: output?.sha256 ?? null,
      release_id: output?.releaseId ?? null,
      completed_at: now,
      error_code: null,
      error: null,
      updated_at: now,
    });
  }

  async function failBackup(id, error, now) {
    await db('backups').where({ id }).update({ status: 'failed', error_code: (error?.code ?? 'BACKUP_FAILED').slice(0, 64), error: error?.message ?? 'The backup failed', updated_at: now });
  }

  async function handleJobFinished(job, { status, output, error }) {
    const ok = status === 'succeeded';
    const now = new Date();
    if (ok && ['DELETE_SITE', 'DELETE_APPLICATION', 'DELETE_DATABASE'].includes(job.type)) {
      await removeOrphanSchedules();
      return;
    }
    if (job.resource_type === 'backup') {
      const row = await db('backups').where({ id: job.resource_id }).first();
      if (!row) return;
      if (job.type === 'CREATE_BACKUP') {
        // A failed copy to storage still leaves a good backup on the server.
        const savedLocally = !ok && output?.sha256 && output?.storageError;
        if (ok || savedLocally) await completeBackup(row.id, output, now);
        else await failBackup(row.id, error, now);
        const fresh = await db('backups').where({ id: row.id }).first();
        await emitBackup(ok ? 'backup.succeeded' : 'backup.failed', fresh, ok ? null : error);
        if ((ok || savedLocally) && row.schedule_id) await applyRetention(row.schedule_id).catch((err) => logger.warn({ err }, 'backup retention failed'));
      } else if (job.type === 'DELETE_BACKUP') {
        if (ok) await softDelete(row);
        else await db('backups').where({ id: row.id }).update({ status: 'completed', updated_at: now });
      }
      return;
    }
    if (job.resource_type === 'backup_restore' && job.type === 'RESTORE_BACKUP') {
      const restoreRow = await db('backup_restores').where({ id: job.resource_id }).first();
      if (!restoreRow) return;
      await db('backup_restores').where({ id: restoreRow.id }).update({
        status: ok ? 'succeeded' : 'failed',
        error_code: ok ? null : (error?.code ?? 'RESTORE_FAILED').slice(0, 64),
        error: ok ? null : (error?.message ?? 'The restore failed'),
        finished_at: now,
        updated_at: now,
      });
      if (restoreRow.safety_backup_id) {
        if (output?.safetyBackup) await completeBackup(restoreRow.safety_backup_id, output.safetyBackup, now);
        else await failBackup(restoreRow.safety_backup_id, output?.safetyError ?? { code: error?.code ?? 'NOT_STARTED', message: 'The restore stopped before the safety copy was made' }, now);
      }
      const backup = await db('backups').where({ id: restoreRow.backup_id }).first();
      if (ok) {
        await db('backups').where({ id: backup.id }).update({ last_restored_at: now });
        // An app now runs the release the backup holds.
        if (backup.resource_type === 'application' && output?.releaseId) {
          const deployment = await db('deployments').where({ application_id: backup.resource_id, release_id: output.releaseId, status: 'succeeded' }).orderBy('created_at', 'desc').first('id', 'commit_hash');
          await db('applications').where({ id: backup.resource_id }).update({
            current_release_id: output.releaseId,
            ...(deployment ? { current_deployment_id: deployment.id, current_commit: deployment.commit_hash } : {}),
            updated_at: now,
          });
          await db('deployments').where({ application_id: backup.resource_id, release_id: output.releaseId }).update({ release_available: true });
        }
      }
      await emitBackup(ok ? 'restore.succeeded' : 'restore.failed', backup, ok ? null : error, { restore: { id: restoreRow.id, safetyBackupId: restoreRow.safety_backup_id } });
      return;
    }
    if (job.resource_type === 'backup_download' && job.type === 'UPLOAD_BACKUP') {
      const row = await db('backups').where({ id: job.resource_id }).first();
      if (row) await finishDownload(job, row, ok);
    }
  }

  // ---- Heartbeat and housekeeping ---------------------------------------------

  // The agent lists the backup files it has every few minutes. Completed
  // backups whose file is gone become "missing" (and back, if it returns).
  async function syncFiles(serverId, report) {
    if (!report || !Array.isArray(report.files)) return;
    const checkedAt = new Date(report.checkedAt);
    if (Number.isNaN(checkedAt.getTime())) return;
    const present = new Set(report.files.map((f) => f.id));
    // Backups kept only in storage have no file on the server to look for.
    const rows = await db('backups').where({ server_id: serverId, local_copy: true }).whereIn('status', ['completed', 'missing']).whereNull('deleted_at').where('completed_at', '<', checkedAt).select('id', 'status', 'storage_key');
    for (const row of rows) {
      const has = present.has(row.id);
      if (row.storage_key) {
        // Also in storage: losing the server's copy only means restores fetch it.
        if (!has) await db('backups').where({ id: row.id }).update({ local_copy: false, file_path: null, updated_at: new Date() });
        continue;
      }
      if (row.status === 'completed' && !has) await db('backups').where({ id: row.id, status: 'completed' }).update({ status: 'missing', updated_at: new Date() });
      if (row.status === 'missing' && has) await db('backups').where({ id: row.id, status: 'missing' }).update({ status: 'completed', updated_at: new Date() });
    }
  }

  async function pruneDownloads(now = new Date()) {
    const expired = await db('backups').whereNotNull('download_path').where('download_ready_until', '<=', now).select('id', 'download_path');
    for (const row of expired) {
      await rm(row.download_path, { force: true });
      await db('backups').where({ id: row.id }).update({ download_path: null, download_ready_until: null });
    }
    return expired.length;
  }

  // Schedules of websites, apps and databases that were deleted go with them.
  // Their backups stay, to be downloaded or deleted.
  async function removeOrphanSchedules() {
    const orphans = await db('backup_schedules as bs').whereRaw(`NOT (${resourceExistsSql('bs')})`).pluck('bs.id');
    if (orphans.length) await db('backup_schedules').whereIn('id', orphans).delete();
    return orphans.length;
  }

  async function summary() {
    const since = addSeconds(new Date(), -86_400);
    const [counts, recentFailed, schedules, size] = await Promise.all([
      db('backups').whereNull('deleted_at').select('status').count({ n: '*' }).groupBy('status'),
      db('backups').whereNull('deleted_at').where({ status: 'failed' }).where('created_at', '>=', since).count({ n: '*' }).first(),
      db('backup_schedules').where({ enabled: true }).count({ n: '*' }).first(),
      db('backups').whereNull('deleted_at').where({ status: 'completed' }).sum({ bytes: 'size_bytes' }).first(),
    ]);
    const byStatus = Object.fromEntries(counts.map((r) => [r.status, Number(r.n)]));
    return { byStatus, failedLastDay: Number(recentFailed?.n ?? 0), schedules: Number(schedules?.n ?? 0), totalBytes: Number(size?.bytes ?? 0) };
  }

  jobs.onFinished(handleJobFinished);

  return {
    list,
    get,
    create,
    remove,
    restore,
    prepareDownload,
    openDownload,
    receiveChunk,
    listSchedules,
    saveSchedule,
    removeSchedule,
    runDueSchedules,
    applyRetention,
    syncFiles,
    pruneDownloads,
    removeOrphanSchedules,
    summary,
    handleJobFinished,
  };
}

function target(row) {
  return { backupId: row.id, kind: BACKUP_RESOURCES[row.resource_type].agentKind, name: row.resource_name };
}

function backupTarget(row) {
  return { type: 'backup', id: row.id, label: `${row.resource_name} (${row.resource_type})` };
}

async function hashFile(file) {
  const hash = createHash('sha256');
  let sizeBytes = 0;
  for await (const chunk of createReadStream(file)) {
    hash.update(chunk);
    sizeBytes += chunk.length;
  }
  return { sizeBytes, sha256: hash.digest('hex') };
}
