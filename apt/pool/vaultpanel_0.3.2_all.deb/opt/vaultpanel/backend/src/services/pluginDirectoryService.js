import { randomUUID } from 'node:crypto';
import { MAX_PLUGIN_DIRECTORIES, PERMISSIONS, PLUGIN_DIRECTORY_REFRESH_HOURS, compareVersions } from '@vaultpanel/shared';
import { AppError, forbidden, notFound, validationError } from '../utils/errors.js';
import { sha256Hex } from '../utils/crypto.js';
import { fromJson, toJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';
import { pluginDirectoryDocument, pluginDirectoryEntry } from '../validators/pluginValidators.js';

const SKIPPED_KEPT = 20;
const REFRESH_MS = PLUGIN_DIRECTORY_REFRESH_HOURS * 3_600_000;

// Plugin directories (docs/plugins.md#plugin-directories): lists of plugins
// published as JSON at a URL. An owner or admin adds a directory; the panel
// reads it, keeps the latest good copy, reads it again every
// PLUGIN_DIRECTORY_REFRESH_HOURS and lists its plugins on the Plugins page.
//
// A directory only suggests plugins. Installing one goes through the usual
// manifest preview and approval (pluginService), from the plugin's own
// manifest, so a directory can never grant a plugin anything, and updating an
// installed plugin always reads that plugin's own manifest URL again.
export function createPluginDirectoryService({ db, audit, authorize, webhooks, logger }) {
  // Installing and removing directories is done in the panel, like plugins.
  function requirePerson(actor) {
    if (actor.type !== 'user' || actor.tokenId) throw forbidden('Plugin directories are added in the panel, by a signed-in owner or admin');
  }

  async function loadRow(id) {
    const row = await db('plugin_directories').where({ id }).first();
    if (!row) throw notFound('Plugin directory not found');
    return row;
  }

  // Reads a directory and checks it. Entries are checked one by one: a bad
  // one is left out (and reported), not the whole directory.
  async function read(url) {
    const raw = await webhooks.fetchDirectory(url);
    const doc = pluginDirectoryDocument.safeParse(raw ?? {});
    if (!doc.success) {
      throw validationError(
        doc.error.issues.map((i) => ({ field: ['directory', ...i.path].join('.'), message: i.message })),
        'This is not a VaultPanel plugin directory',
      );
    }
    const entries = [];
    const skipped = [];
    const seen = new Set();
    doc.data.plugins.forEach((item, index) => {
      const parsed = pluginDirectoryEntry.safeParse(item);
      const id = typeof item?.id === 'string' ? item.id.slice(0, 64) : null;
      if (!parsed.success) {
        const issue = parsed.error.issues[0];
        skipped.push({ index, id, reason: `${issue.path.join('.') || 'entry'}: ${issue.message}` });
      } else if (seen.has(parsed.data.id)) {
        skipped.push({ index, id, reason: 'Listed twice; the first one is used' });
      } else {
        seen.add(parsed.data.id);
        entries.push(parsed.data);
      }
    });
    return {
      columns: {
        name: doc.data.name,
        description: doc.data.description ?? null,
        homepage: doc.data.homepage ?? null,
        entries: toJson(entries),
        skipped_count: skipped.length,
        skipped: toJson(skipped.slice(0, SKIPPED_KEPT)),
      },
      count: entries.length,
    };
  }

  async function list(actor) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const rows = await db('plugin_directories').orderBy('created_at');
    const installed = new Map((await db('plugins').select('id', 'slug', 'version', 'enabled')).map((p) => [p.slug, p]));
    const items = [];
    for (const row of rows) {
      for (const entry of fromJson(row.entries, [])) {
        const plugin = installed.get(entry.id);
        items.push({
          ...entry,
          directory: { id: row.id, name: row.name },
          installed: plugin ? { id: plugin.id, version: plugin.version, enabled: Boolean(plugin.enabled) } : null,
          updateAvailable: Boolean(plugin && compareVersions(entry.version, plugin.version) > 0),
        });
      }
    }
    items.sort((a, b) => a.name.localeCompare(b.name));
    const categories = [...new Set(items.flatMap((i) => i.categories))].sort();
    return { directories: rows.map(toPublicDirectory), items, categories, max: MAX_PLUGIN_DIRECTORIES };
  }

  async function add(actor, { url }) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    requirePerson(actor);
    const href = new URL(url).href;
    if (await db('plugin_directories').where({ url_hash: sha256Hex(href) }).first()) {
      throw new AppError(409, 'DIRECTORY_ADDED', 'This directory is already added. Refresh it to read it again.');
    }
    const count = await db('plugin_directories').count({ n: '*' }).first();
    if (Number(count.n) >= MAX_PLUGIN_DIRECTORIES) {
      throw new AppError(409, 'TOO_MANY_DIRECTORIES', `Up to ${MAX_PLUGIN_DIRECTORIES} plugin directories. Remove one you no longer use.`);
    }
    // Nothing is saved unless the directory can be read.
    const { columns, count: entries } = await read(href);
    const id = randomUUID();
    const now = new Date();
    await db('plugin_directories').insert({
      id,
      url: href,
      url_hash: sha256Hex(href),
      ...columns,
      fetched_at: now,
      last_attempt_at: now,
      last_error: null,
      added_by: actor.id,
      created_at: now,
      updated_at: now,
    });
    await audit.record({ actor, action: 'plugin.directory.add', target: { type: 'plugin_directory', id, label: columns.name }, metadata: { url: href, plugins: entries } });
    return { directory: toPublicDirectory(await loadRow(id)) };
  }

  // Reads one directory again. A failure is kept on the directory (its last
  // good copy stays listed) and reported.
  async function fetchAgain(row, now = new Date()) {
    try {
      const { columns } = await read(row.url);
      await db('plugin_directories')
        .where({ id: row.id })
        .update({ ...columns, fetched_at: now, last_attempt_at: now, last_error: null, updated_at: now });
      return null;
    } catch (err) {
      const message = errorText(err);
      await db('plugin_directories').where({ id: row.id }).update({ last_attempt_at: now, last_error: message.slice(0, 500), updated_at: now });
      return err;
    }
  }

  async function refresh(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const err = await fetchAgain(await loadRow(id));
    if (err) throw err;
    return { directory: toPublicDirectory(await loadRow(id)) };
  }

  // Every directory; failures are kept on each directory, not thrown.
  async function refreshAll(actor) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const rows = await db('plugin_directories');
    await Promise.all(rows.map((row) => fetchAgain(row)));
    return list(actor);
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.PLUGINS_MANAGE);
    const row = await loadRow(id);
    // Plugins installed from it stay installed.
    await db('plugin_directories').where({ id }).delete();
    await audit.record({ actor, action: 'plugin.directory.remove', target: { type: 'plugin_directory', id, label: row.name ?? row.url }, metadata: { url: row.url } });
  }

  // From the maintenance worker: directories not read for a while.
  async function refreshStale(now = new Date()) {
    const cutoff = new Date(now.getTime() - REFRESH_MS);
    const rows = await db('plugin_directories').where((q) => q.whereNull('last_attempt_at').orWhere('last_attempt_at', '<', cutoff));
    let failed = 0;
    for (const row of rows) {
      const err = await fetchAgain(row, now);
      if (err) {
        failed += 1;
        logger?.warn({ directory: row.url, err: errorText(err) }, 'plugin directory could not be read');
      }
    }
    return rows.length ? { read: rows.length, failed } : null;
  }

  return { list, add, refresh, refreshAll, remove, refreshStale };
}

// For installed plugins: the newest version any directory lists for each
// plugin id, and every directory entry for one id (to compare with what its
// manifest asks for). Used by pluginService.
export async function directoryListings(db) {
  const rows = await db('plugin_directories').select('id', 'name', 'entries');
  const byId = new Map();
  for (const row of rows) {
    for (const entry of fromJson(row.entries, [])) {
      if (!byId.has(entry.id)) byId.set(entry.id, []);
      byId.get(entry.id).push({ ...entry, directory: { id: row.id, name: row.name } });
    }
  }
  return byId;
}

export function newestListing(listings, installedVersion) {
  let best = null;
  for (const entry of listings ?? []) {
    if (compareVersions(entry.version, installedVersion) > 0 && (!best || compareVersions(entry.version, best.version) > 0)) best = entry;
  }
  return best ? { version: best.version, directory: best.directory } : null;
}

function errorText(err) {
  if (err?.details?.length) return `${err.message}: ${err.details.map((d) => `${d.field} ${d.message}`).join('; ')}`;
  return err?.message ?? String(err);
}

function toPublicDirectory(row) {
  return {
    id: row.id,
    url: row.url,
    name: row.name,
    description: row.description,
    homepage: row.homepage,
    pluginCount: fromJson(row.entries, []).length,
    skippedCount: Number(row.skipped_count ?? 0),
    skipped: fromJson(row.skipped, []),
    fetchedAt: toIso(row.fetched_at),
    lastAttemptAt: toIso(row.last_attempt_at),
    lastError: row.last_error,
    createdAt: toIso(row.created_at),
  };
}
