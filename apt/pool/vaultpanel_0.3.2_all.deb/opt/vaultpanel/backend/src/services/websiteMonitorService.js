import { randomUUID } from 'node:crypto';
import { lookup } from 'node:dns/promises';
import http from 'node:http';
import https from 'node:https';
import { isIP } from 'node:net';
import { PERMISSIONS, certificateCovers, isWildcardDomain } from '@vaultpanel/shared';
import { getSetting } from '../models/settingModel.js';
import { AppError, notFound } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { addressAllowed } from './webhookService.js';

// Uptime of websites, checked from the panel the way visitors reach them:
// public DNS, then the front page over HTTPS when the site has a certificate
// for the name (HTTP otherwise). Every few minutes (VAULTPANEL_UPTIME_CHECK_SECONDS)
// the worker checks the websites that are due; a failure is checked again
// before the website counts as down. A website is down when it does not
// answer, answers with a server error (5xx), or serves a certificate browsers
// refuse. The "Website down" alert rule (alertService.js) turns that into
// alerts, emails and webhooks.
//
// Only public addresses, or the website's own server, are ever contacted, so
// a domain pointed at an internal address cannot make the panel reach it.

const PROBE_TIMEOUT_MS = 10_000;
const RETRY_DELAY_MS = 10_000;
// Websites checked per run, and at once.
const BATCH = 60;
const CONCURRENCY = 8;
const PRUNE_EVERY_MS = 60 * 60_000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const normalizeIp = (ip) => String(ip).replace(/^::ffff:/i, '').toLowerCase();

// Asks a website for its front page once. allowed(address) decides which
// addresses may be contacted. Never follows redirects: any answer below 500
// means the website is there.
export async function probeWebsite(url, { allowed, timeoutMs = PROBE_TIMEOUT_MS, ignoreUntrusted = false, resolve = (host) => lookup(host, { all: true }) } = {}) {
  const host = url.hostname.replace(/^\[|\]$/g, '');
  let addresses;
  try {
    addresses = isIP(host) ? [{ address: host, family: isIP(host) }] : await resolve(host);
  } catch (err) {
    const missing = ['ENOTFOUND', 'ENODATA', 'NXDOMAIN'].includes(err.code);
    return { ok: false, status: null, ms: null, certificate: null, message: missing ? `${host} does not resolve in DNS` : `Looking up ${host} failed (${err.code ?? err.message})` };
  }
  const target = addresses.find((a) => allowed(a.address));
  if (!target) {
    return { ok: false, status: null, ms: null, certificate: null, message: `${host} points at ${addresses.map((a) => a.address).join(', ')}, which is not a public address or this website’s server` };
  }
  const started = process.hrtime.bigint();
  const secure = url.protocol === 'https:';
  return new Promise((resolveResult) => {
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      resolveResult(result);
    };
    const req = (secure ? https : http).request(
      url,
      {
        method: 'GET',
        headers: { 'User-Agent': 'VaultPanel-Uptime/1', Accept: '*/*' },
        timeout: timeoutMs,
        agent: false,
        // The certificate is judged below, so its problem can be named.
        rejectUnauthorized: false,
        ...(secure && !isIP(host) ? { servername: host } : {}),
        // Connect to the address that was checked.
        lookup: (_host, options, callback) => {
          if (options?.all) callback(null, [{ address: target.address, family: target.family }]);
          else callback(null, target.address, target.family);
        },
      },
      (res) => {
        const ms = Number((process.hrtime.bigint() - started) / 1_000_000n);
        const certificate = secure ? judgeCertificate(res.socket, host, { ignoreUntrusted }) : null;
        const status = res.statusCode;
        let message = `HTTP ${status} in ${ms} ms`;
        if (status >= 500) message = `HTTP ${status}: the website answers with a server error`;
        if (certificate?.problem) message = certificate.problem;
        finish({ ok: status < 500 && !certificate?.problem, status, ms, certificate, message });
        // The page itself is not needed.
        req.destroy();
      },
    );
    req.on('timeout', () => req.destroy(Object.assign(new Error('timeout'), { code: 'TIMEOUT' })));
    req.on('error', (err) => finish({ ok: false, status: null, ms: null, certificate: null, message: describeError(err, { secure, timeoutMs, port: url.port || (secure ? 443 : 80) }) }));
    req.end();
  });
}

// The certificate a website served, and what browsers would say about it.
export function judgeCertificate(socket, host, { ignoreUntrusted = false } = {}) {
  const cert = socket?.getPeerCertificate?.() ?? null;
  const validTo = cert?.valid_to ? new Date(cert.valid_to) : null;
  const error = socket?.authorizationError ? String(socket.authorizationError.code ?? socket.authorizationError) : null;
  let problem = null;
  if (error === 'CERT_HAS_EXPIRED' || (validTo && validTo <= new Date())) problem = `The certificate it serves expired${validTo ? ` on ${validTo.toISOString().slice(0, 10)}` : ''}`;
  else if (error === 'ERR_TLS_CERT_ALTNAME_INVALID') problem = `The certificate it serves does not cover ${host}`;
  else if (error === 'CERT_NOT_YET_VALID') problem = 'The certificate it serves is not valid yet';
  else if (error && !ignoreUntrusted) problem = `Browsers do not trust the certificate it serves (${error})`;
  return { validTo: validTo && !Number.isNaN(validTo.getTime()) ? validTo.toISOString() : null, problem };
}

function describeError(err, { secure, timeoutMs, port }) {
  switch (err.code) {
    case 'TIMEOUT':
      return `No answer within ${timeoutMs / 1000} seconds`;
    case 'ECONNREFUSED':
      return `Connection refused: nothing answers on port ${port}`;
    case 'ECONNRESET':
      return 'The connection was closed before the website answered';
    case 'EHOSTUNREACH':
    case 'ENETUNREACH':
      return 'The server cannot be reached';
    default:
      return secure && /SSL|TLS|EPROTO/i.test(`${err.code} ${err.message}`) ? `HTTPS failed: ${err.message}` : err.message;
  }
}

export function createWebsiteMonitorService({ db, config, logger, audit, authorize, probe = probeWebsite, wait = sleep }) {
  let running = null;
  let prunedAt = 0;

  // Websites that are checked: live, enabled and with monitoring on.
  function monitored() {
    return db('websites as w')
      .join('servers as s', 's.id', 'w.server_id')
      .whereNull('w.deleted_at')
      .whereNull('s.deleted_at')
      .where({ 'w.uptime_enabled': true, 'w.is_enabled': true })
      .whereNotNull('w.provisioned_at')
      .whereIn('w.status', ['active', 'updating'])
      .select('w.id', 'w.name', 'w.uptime_status', 'w.uptime_since', 's.public_ip', 's.ip_addresses');
  }

  // Run by the worker's maintenance: starts the due checks in the background
  // (they take seconds each) and prunes old history now and then.
  async function tick(now = new Date()) {
    if (now.getTime() - prunedAt >= PRUNE_EVERY_MS) {
      prunedAt = now.getTime();
      await prune(now);
    }
    if (running || !config.uptimeCheckSeconds) return { started: false };
    running = checkDue(now)
      .catch((err) => logger.error({ err }, 'website uptime checks failed'))
      .finally(() => {
        running = null;
      });
    return { started: true };
  }

  async function checkDue(now = new Date()) {
    if (!config.uptimeCheckSeconds) return { checked: 0 };
    const cutoff = new Date(now.getTime() - config.uptimeCheckSeconds * 1000);
    // The panel's own website is left to the Panel Domain page.
    const panel = fromJson(await getSetting(db, 'panel.domain'), null);
    const due = await monitored()
      .where((q) => q.whereNull('w.uptime_checked_at').orWhere('w.uptime_checked_at', '<=', cutoff))
      .modify((q) => panel?.websiteId && q.whereNot('w.id', panel.websiteId))
      .orderByRaw('w.uptime_checked_at IS NULL DESC, w.uptime_checked_at ASC')
      .limit(BATCH);
    let next = 0;
    const worker = async () => {
      while (next < due.length) {
        const row = due[next++];
        await checkOne(row).catch((err) => logger.warn({ err, websiteId: row.id }, 'website uptime check failed'));
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, due.length) }, worker));
    return { checked: due.length };
  }

  async function checkOne(row, { retry = true } = {}) {
    const [domains, cert] = await Promise.all([
      db('website_domains').where({ website_id: row.id }).orderBy('is_primary', 'desc').pluck('domain'),
      db('ssl_certificates').where({ website_id: row.id }).first(),
    ]);
    // The primary domain, or the first one that is not a wildcard.
    const host = domains.find((d) => !isWildcardDomain(d));
    if (!host) {
      await db('websites').where({ id: row.id }).update({ uptime_status: null, uptime_since: null, uptime_checked_at: new Date(), uptime_message: 'Only wildcard domains: there is no address to check', uptime_url: null });
      return null;
    }
    const secure = cert?.status === 'active' && certificateCovers(fromJson(cert.domains, []), host);
    const url = new URL(`${secure ? 'https' : 'http'}://${host}/`);
    const own = new Set([row.public_ip, ...fromJson(row.ip_addresses, [])].filter(Boolean).map(normalizeIp));
    const options = {
      allowed: (address) => own.has(normalizeIp(address)) || addressAllowed(address, { allowPrivate: config.webhookAllowPrivate }),
      // A staging certificate is untrusted on purpose; the website warns about it.
      ignoreUntrusted: Boolean(cert?.is_staging),
    };
    let result = await probe(url, options);
    // One failure can be a blip: ask again before calling the website down.
    if (!result.ok && retry) {
      await wait(RETRY_DELAY_MS);
      result = await probe(url, options);
    }
    await record(row, url, result, new Date());
    return result;
  }

  async function record(row, url, result, at) {
    const status = result.ok ? 'up' : 'down';
    const changed = status !== row.uptime_status;
    const message = String(result.message ?? '').slice(0, 500);
    await db.transaction(async (trx) => {
      await trx('website_checks').insert({ website_id: row.id, checked_at: at, ok: result.ok, status_code: result.status ?? null, response_ms: result.ms ?? null, message });
      await trx('websites')
        .where({ id: row.id })
        .update({
          uptime_status: status,
          uptime_since: changed || !row.uptime_since ? at : row.uptime_since,
          uptime_checked_at: at,
          uptime_message: message,
          uptime_response_ms: result.ms ?? null,
          uptime_url: url.href,
          uptime_cert_valid_to: result.certificate?.validTo ? new Date(result.certificate.validTo) : null,
        });
      if (changed && status === 'down') await trx('website_incidents').insert({ id: randomUUID(), website_id: row.id, started_at: at, message, created_at: at });
      if (changed && status === 'up') await trx('website_incidents').where({ website_id: row.id }).whereNull('ended_at').update({ ended_at: at });
    });
  }

  async function prune(now = new Date()) {
    const cutoff = new Date(now.getTime() - config.uptimeHistoryDays * 86_400_000);
    const checks = await db('website_checks').where('checked_at', '<', cutoff).delete();
    const incidents = await db('website_incidents').whereNotNull('ended_at').where('ended_at', '<', cutoff).delete();
    return { checks, incidents };
  }

  // ---- The website page ------------------------------------------------------

  async function load(id) {
    const row = await db('websites').where({ id }).whereNull('deleted_at').first();
    if (!row) throw notFound('Website not found');
    return row;
  }

  // The current state, uptime over the last day, week and month, the average
  // response time of the last day, and the latest downtime.
  async function get(actor, id, now = new Date()) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const row = await load(id);
    const ago = (days) => new Date(now.getTime() - days * 86_400_000);
    const [day, week] = [ago(1), ago(7)];
    const [stats, incidents] = await Promise.all([
      db('website_checks')
        .where({ website_id: id })
        .where('checked_at', '>=', ago(30))
        .first(
          db.raw('COUNT(*) AS month_total'),
          db.raw('SUM(CASE WHEN ok THEN 1 ELSE 0 END) AS month_up'),
          db.raw('SUM(CASE WHEN checked_at >= ? THEN 1 ELSE 0 END) AS week_total', [week]),
          db.raw('SUM(CASE WHEN checked_at >= ? AND ok THEN 1 ELSE 0 END) AS week_up', [week]),
          db.raw('SUM(CASE WHEN checked_at >= ? THEN 1 ELSE 0 END) AS day_total', [day]),
          db.raw('SUM(CASE WHEN checked_at >= ? AND ok THEN 1 ELSE 0 END) AS day_up', [day]),
          db.raw('AVG(CASE WHEN checked_at >= ? AND ok THEN response_ms END) AS day_ms', [day]),
        ),
      db('website_incidents').where({ website_id: id }).orderBy('started_at', 'desc').limit(10),
    ]);
    const percent = (up, total) => (Number(total) ? Math.round((Number(up) / Number(total)) * 10_000) / 100 : null);
    return {
      uptime: {
        enabled: Boolean(row.uptime_enabled),
        intervalSeconds: config.uptimeCheckSeconds,
        status: row.uptime_status ?? null,
        since: row.uptime_since ? new Date(row.uptime_since).toISOString() : null,
        checkedAt: row.uptime_checked_at ? new Date(row.uptime_checked_at).toISOString() : null,
        message: row.uptime_message ?? null,
        responseMs: row.uptime_response_ms ?? null,
        url: row.uptime_url ?? null,
        certificateValidTo: row.uptime_cert_valid_to ? new Date(row.uptime_cert_valid_to).toISOString() : null,
        day: percent(stats?.day_up, stats?.day_total),
        week: percent(stats?.week_up, stats?.week_total),
        month: percent(stats?.month_up, stats?.month_total),
        averageMs: stats?.day_ms === null || stats?.day_ms === undefined ? null : Math.round(Number(stats.day_ms)),
        incidents: incidents.map((i) => ({
          id: i.id,
          startedAt: new Date(i.started_at).toISOString(),
          endedAt: i.ended_at ? new Date(i.ended_at).toISOString() : null,
          message: i.message,
        })),
      },
    };
  }

  // Turning monitoring off forgets the current state and ends open downtime,
  // so its alert resolves.
  async function setEnabled(actor, id, enabled) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await load(id);
    if (Boolean(row.uptime_enabled) !== enabled) {
      const now = new Date();
      await db.transaction(async (trx) => {
        await trx('websites')
          .where({ id })
          .update(enabled ? { uptime_enabled: true } : { uptime_enabled: false, uptime_status: null, uptime_since: null, uptime_message: null, uptime_response_ms: null });
        if (!enabled) await trx('website_incidents').where({ website_id: id }).whereNull('ended_at').update({ ended_at: now });
      });
      await audit.record({ actor, action: enabled ? 'website.uptime_on' : 'website.uptime_off', target: { type: 'website', id, label: row.name } });
    }
    return get(actor, id);
  }

  // Checks one website now, once (no second try).
  async function checkNow(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    await load(id);
    const row = await monitored().where('w.id', id).first();
    if (!row) throw new AppError(409, 'UPTIME_NOT_CHECKED', 'Only enabled websites with monitoring on are checked. Turn monitoring on, or enable the website first.');
    await checkOne(row, { retry: false });
    return get(actor, id);
  }

  return { tick, checkDue, checkOne, prune, get, setEnabled, checkNow };
}
