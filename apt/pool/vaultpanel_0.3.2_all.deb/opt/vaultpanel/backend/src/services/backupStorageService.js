import { randomBytes, randomUUID } from 'node:crypto';
import { BACKUP_STORAGE_PROVIDERS, PERMISSIONS, storageEndpointFor } from '@vaultpanel/shared';
import { agentOperations } from '../models/serverModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { generateSshKeyPair } from '../utils/sshKeys.js';
import { isCustomer } from './tenancy.js';

// Storage for backups off their server: S3-compatible buckets (Amazon S3,
// Backblaze B2, Wasabi, Cloudflare R2, MinIO…) and other servers over SFTP.
// Owners and admins set up destinations here; a backup or a schedule then
// names one, and the agent copies each backup there after writing it (see
// agent/src/operations/backups.js).
//
// S3 secret keys and SFTP private keys are stored encrypted and sent to the
// agent only inside the job that needs them; those parameters are redacted
// once the job ends. For SFTP the panel makes its own Ed25519 key pair; the
// owner adds the public key to the backup server, and the first check pins
// that server's host key (a different key later is refused).
// Hosting customers neither see nor choose destinations: their backups stay
// on the server unless staff give them a schedule that uses one.

export const STORAGE_MIN_AGENT_OPERATION = 'TEST_BACKUP_STORAGE';
const EXTENSIONS = { site: 'tar.gz', app: 'tar.gz', database: 'sql.gz' };

export function toPublicStorage(row, { usage } = {}) {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    provider: row.provider,
    providerLabel: row.type === 'sftp' ? 'SFTP' : (BACKUP_STORAGE_PROVIDERS[row.provider]?.label ?? row.provider),
    endpoint: row.endpoint,
    region: row.region,
    bucket: row.bucket,
    prefix: row.prefix,
    pathStyle: Boolean(row.path_style),
    accessKeyId: row.access_key_id,
    host: row.host,
    port: row.port,
    username: row.username,
    // SFTP: the folder is the prefix; the public key goes in authorized_keys.
    path: row.type === 'sftp' ? row.prefix : undefined,
    publicKey: row.public_key,
    hostKeyFingerprint: row.host_key_fingerprint,
    keepLocal: Boolean(row.keep_local),
    insecure: row.type === 's3' && Boolean(row.endpoint?.startsWith('http:')),
    test: row.test_status ? { status: row.test_status, message: row.test_message, jobId: row.test_job_id, testedAt: row.tested_at ? new Date(row.tested_at).toISOString() : null } : null,
    ...(usage ? { usage } : {}),
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function createBackupStorageService({ db, config, audit, authorize, jobs }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'backup-storage'));

  async function load(id) {
    const row = await db('backup_storages').where({ id }).first();
    if (!row) throw notFound('Storage not found');
    return row;
  }

  async function usageOf(ids) {
    if (!ids.length) return {};
    const [backups, schedules] = await Promise.all([
      db('backups').whereIn('storage_id', ids).whereNull('deleted_at').whereNotNull('storage_key').select('storage_id').count({ n: '*' }).sum({ bytes: 'size_bytes' }).groupBy('storage_id'),
      db('backup_schedules').whereIn('storage_id', ids).select('storage_id').count({ n: '*' }).groupBy('storage_id'),
    ]);
    const out = Object.fromEntries(ids.map((id) => [id, { backups: 0, bytes: 0, schedules: 0 }]));
    for (const r of backups) Object.assign(out[r.storage_id], { backups: Number(r.n), bytes: Number(r.bytes ?? 0) });
    for (const r of schedules) out[r.storage_id].schedules = Number(r.n);
    return out;
  }

  // Customers get an empty list: destinations belong to the panel's staff.
  async function list(actor) {
    await authorize(actor, PERMISSIONS.BACKUPS_READ);
    if (isCustomer(actor)) return { items: [] };
    const rows = await db('backup_storages').orderBy('name');
    const usage = await usageOf(rows.map((r) => r.id));
    return { items: rows.map((r) => toPublicStorage(r, { usage: usage[r.id] })) };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.BACKUPS_READ);
    if (isCustomer(actor)) throw notFound('Storage not found');
    const row = await load(id);
    return { storage: toPublicStorage(row, { usage: (await usageOf([id]))[id] }) };
  }

  function values(input) {
    if (input.type === 'sftp') {
      return { name: input.name, type: 'sftp', provider: 'sftp', host: input.host, port: input.port, username: input.username, prefix: input.path ?? '', keep_local: input.keepLocal };
    }
    const endpoint = (input.endpoint || storageEndpointFor(input.provider, input.region)).replace(/\/+$/, '');
    if (!endpoint || endpoint.includes('ACCOUNT_ID')) throw validationError([{ field: 'endpoint', message: 'Type the endpoint address of the service' }]);
    return {
      name: input.name,
      type: 's3',
      provider: input.provider,
      endpoint,
      region: input.region,
      bucket: input.bucket,
      prefix: input.prefix ?? '',
      path_style: input.pathStyle,
      access_key_id: input.accessKeyId,
      keep_local: input.keepLocal,
    };
  }

  async function nameTaken(name, exceptId = null) {
    const q = db('backup_storages').where({ name });
    if (exceptId) q.whereNot({ id: exceptId });
    return Boolean(await q.first('id'));
  }

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    if (input.type === 's3' && !input.secretAccessKey) throw validationError([{ field: 'secretAccessKey', message: 'Required' }]);
    if (await nameTaken(input.name)) throw validationError([{ field: 'name', message: 'Another storage has this name' }]);
    const id = randomUUID();
    const now = new Date();
    let secrets;
    if (input.type === 'sftp') {
      const pair = generateSshKeyPair(`vaultpanel-backups-${id.slice(0, 8)}`);
      secrets = { private_key_encrypted: box.seal(pair.privateKey), public_key: pair.publicKey };
    } else {
      secrets = { secret_encrypted: box.seal(input.secretAccessKey) };
    }
    const row = { id, ...values(input), ...secrets, created_by: actor.type === 'user' ? actor.id : null, created_at: now, updated_at: now };
    await db('backup_storages').insert(row);
    await audit.record({ actor, action: 'backup_storage.create', target: { type: 'backup_storage', id, label: input.name }, metadata: { type: row.type, provider: row.provider, endpoint: row.endpoint ?? undefined, bucket: row.bucket ?? undefined, host: row.host ?? undefined } });
    return get(actor, id);
  }

  // A blank secret keeps the one saved.
  async function update(actor, id, input) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const current = await load(id);
    if (await nameTaken(input.name, id)) throw validationError([{ field: 'name', message: 'Another storage has this name' }]);
    if (input.type !== current.type) throw validationError([{ field: 'type', message: 'The kind of storage cannot change; add a new one instead' }]);
    const next = values(input);
    const connection = current.type === 'sftp' ? ['host', 'port', 'username', 'prefix'] : ['endpoint', 'region', 'bucket', 'path_style', 'access_key_id'];
    const connectionChanged = connection.some((k) => String(next[k]) !== String(current[k])) || Boolean(input.secretAccessKey);
    // Another address is another server: its host key is read again on the next check.
    const forgetHostKey = current.type === 'sftp' && (input.trustNewHostKey || next.host !== current.host || next.port !== current.port);
    await db('backup_storages')
      .where({ id })
      .update({
        ...next,
        ...(current.type === 's3' && input.secretAccessKey ? { secret_encrypted: box.seal(input.secretAccessKey) } : {}),
        ...(forgetHostKey ? { host_key: null, host_key_fingerprint: null } : {}),
        // A changed connection has not been checked yet.
        ...(connectionChanged || forgetHostKey ? { test_status: null, test_message: null, test_job_id: null, tested_at: null } : {}),
        updated_at: new Date(),
      });
    await audit.record({
      actor,
      action: 'backup_storage.update',
      target: { type: 'backup_storage', id, label: input.name },
      metadata: { endpoint: next.endpoint ?? undefined, bucket: next.bucket ?? undefined, host: next.host ?? undefined, secretChanged: Boolean(input.secretAccessKey), hostKeyForgotten: forgetHostKey || undefined },
    });
    return get(actor, id);
  }

  // Refused while backups or schedules use it: their copies would be lost
  // to the panel.
  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const row = await load(id);
    const usage = (await usageOf([id]))[id];
    if (usage.backups || usage.schedules) {
      const parts = [];
      if (usage.backups) parts.push(`${usage.backups} backup${usage.backups === 1 ? ' is' : 's are'} kept there`);
      if (usage.schedules) parts.push(`${usage.schedules} schedule${usage.schedules === 1 ? ' uses' : 's use'} it`);
      throw new AppError(409, 'STORAGE_IN_USE', `This storage is still in use: ${parts.join(' and ')}. Delete those backups and change those schedules first.`, usage);
    }
    await db.transaction(async (trx) => {
      // Deleted backups, and ones whose copy never got there, only point at it.
      await trx('backups').where({ storage_id: id }).update({ storage_id: null });
      await trx('backup_storages').where({ id }).delete();
    });
    await audit.record({ actor, action: 'backup_storage.delete', target: { type: 'backup_storage', id, label: row.name } });
  }

  // What a job gets: the connection, the secret and the object key.
  function payload(row, key, { keepLocal } = {}) {
    if (row.type === 'sftp') {
      return {
        type: 'sftp',
        host: row.host,
        port: row.port,
        username: row.username,
        privateKey: box.open(row.private_key_encrypted),
        ...(row.host_key ? { knownHosts: row.host_key } : {}),
        ...(row.prefix ? { path: row.prefix } : {}),
        key,
        ...(keepLocal !== undefined ? { keepLocal } : {}),
      };
    }
    return {
      type: 's3',
      endpoint: row.endpoint,
      region: row.region,
      bucket: row.bucket,
      accessKeyId: row.access_key_id,
      secretAccessKey: box.open(row.secret_encrypted),
      pathStyle: Boolean(row.path_style),
      key,
      ...(keepLocal !== undefined ? { keepLocal } : {}),
    };
  }

  // <prefix>/<server id>/<kind>/<name>/<backup id>.<ext> (SFTP: the folder
  // is sent apart, as path).
  function keyFor(row, { serverId, kind, name, backupId }) {
    return [row.type === 'sftp' ? '' : row.prefix, serverId, kind, name, `${backupId}.${EXTENSIONS[kind]}`].filter(Boolean).join('/');
  }

  // The destination a new backup should use, checked for the actor and server.
  async function forBackup(actor, storageId, server) {
    if (!storageId) return null;
    if (isCustomer(actor)) throw new AppError(403, 'FORBIDDEN', 'Backups of hosting accounts are kept on the server');
    const row = await db('backup_storages').where({ id: storageId }).first();
    if (!row) throw validationError([{ field: 'storageId', message: 'This storage no longer exists' }]);
    if (row.type === 'sftp' && !row.host_key) {
      throw new AppError(409, 'STORAGE_NOT_CHECKED', `Check ${row.name} once on the Storage tab first: that is when the panel learns the backup server's host key.`);
    }
    requireCapableAgent(server);
    return row;
  }

  function requireCapableAgent(server) {
    if (server && !agentOperations(server).includes(STORAGE_MIN_AGENT_OPERATION)) {
      throw new AppError(409, 'AGENT_OUTDATED', `Copying backups to storage needs agent v0.13.0 or later; ${server.name} runs v${server.agent_version ?? '?'}. Update the agent from the server page first.`);
    }
  }

  // Writes, reads and deletes a small file from one server's agent.
  async function test(actor, id, { serverId }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const row = await load(id);
    const server = await db('servers').where({ id: serverId }).whereNull('deleted_at').first();
    if (!server) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    requireCapableAgent(server);
    const key = [row.type === 'sftp' ? '' : row.prefix, `.vaultpanel-check-${randomBytes(6).toString('hex')}`].filter(Boolean).join('/');
    const job = await jobs.create(actor, { serverId, type: 'TEST_BACKUP_STORAGE', params: { storage: payload(row, key) }, resource: { type: 'backup_storage', id } }, { internal: true });
    await db('backup_storages').where({ id }).update({ test_job_id: job.id });
    await audit.record({ actor, action: 'backup_storage.test', target: { type: 'backup_storage', id, label: row.name }, metadata: { serverId, jobId: job.id } });
    return { job };
  }

  async function handleJobFinished(job, { status, output, error }) {
    if (job.type !== 'TEST_BACKUP_STORAGE' || job.resource_type !== 'backup_storage') return;
    const ok = status === 'succeeded';
    // The first successful check of an SFTP server pins its host key.
    const hostKey = ok && output?.hostKey?.knownHosts ? output.hostKey : null;
    await db('backup_storages')
      .where({ id: job.resource_id, test_job_id: job.id })
      .update({
        test_status: ok ? 'passed' : 'failed',
        test_message: ok ? 'Backups can be written, read and deleted' : (error?.message ?? 'The check failed'),
        tested_at: new Date(),
        ...(hostKey ? { host_key: String(hostKey.knownHosts).slice(0, 4000), host_key_fingerprint: String(hostKey.fingerprint ?? '').slice(0, 80) || null } : {}),
      });
  }

  jobs.onFinished(handleJobFinished);

  return { list, get, create, update, remove, test, payload, keyFor, forBackup, requireCapableAgent, load, handleJobFinished };
}
