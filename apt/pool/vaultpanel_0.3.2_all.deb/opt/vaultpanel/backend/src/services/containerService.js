import { randomUUID } from 'node:crypto';
import {
  CONTAINER_ACTIONS,
  CONTAINER_BUSY_STATUSES,
  CONTAINER_ID_PATTERN,
  formatPortMapping,
  formatVolumeMapping,
  LOCAL_AI,
  parsePortMapping,
  parseVolumeMapping,
  PERMISSIONS,
  splitCommand,
} from '@vaultpanel/shared';
import { toPublicContainer } from '../models/containerModel.js';
import { agentOperations, findServer } from '../models/serverModel.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { toIso } from '../utils/time.js';

// Docker containers on each server (phase 10).
//
// Containers VaultPanel deploys have a row here; the agent builds each one
// from the row's fields alone (see agent/src/operations/containers.js), so
// nothing the panel stores can make a container privileged or mount the
// host. Every container on a server, deployed by VaultPanel or not, can be
// listed, started, stopped, restarted, read and removed, except the ones
// VaultPanel itself depends on (its own MariaDB and Redis when they run in
// Docker on the same server): those the panel and the agent both protect.

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
const DEFAULT_PORTS = { 'mysql:': 3306, 'mariadb:': 3306, 'redis:': 6379, 'rediss:': 6379 };
const SSH_PORT = 22;

export function createContainerService({ db, config, logger, audit, authorize, jobs }) {
  const envBox = createSecretBox(deriveKey(config.secretKey, 'container-env'));

  // ---- What the panel depends on ---------------------------------------------

  // Host ports of the panel's own database and Redis, when they run on this
  // server: whatever publishes them is VaultPanel's own container.
  function protectedPorts(server) {
    if (!server?.is_local) return [];
    const ports = new Set();
    for (const url of [config.databaseUrl, config.redisUrl]) {
      try {
        const parsed = new URL(url);
        if (LOOPBACK.has(parsed.hostname)) ports.add(Number(parsed.port) || DEFAULT_PORTS[parsed.protocol]);
      } catch {
        // validated at startup
      }
    }
    return [...ports].filter(Boolean);
  }

  // The port people reach the panel on, when it runs on this server. With a
  // panel domain, NGINX serves the domain and passes it on to this port.
  function panelPort(server) {
    if (!server?.is_local) return null;
    try {
      const url = new URL(config.envPublicUrl ?? config.publicUrl);
      return Number(url.port) || (url.protocol === 'https:' ? 443 : 80);
    } catch {
      return null;
    }
  }

  function dockerOf(server, { withProtected = true } = {}) {
    const summary = fromJson(server.docker_summary, null);
    if (!summary) return null;
    const ports = protectedPorts(server);
    return {
      installed: Boolean(summary.installed),
      running: Boolean(summary.running),
      source: summary.source ?? null,
      service: summary.service ?? null,
      version: summary.version ?? null,
      containers: (summary.containers ?? []).map((c) => ({
        ...c,
        protected: withProtected ? Boolean(c.protected || (c.hostPorts ?? []).some((p) => ports.includes(p))) : Boolean(c.protected),
      })),
    };
  }

  // ---- Reading ---------------------------------------------------------------

  function baseQuery() {
    return db('containers as c')
      .join('servers as s', 's.id', 'c.server_id')
      .whereNull('c.deleted_at')
      .whereNull('s.deleted_at')
      .select('c.*', 's.name as server_name');
  }

  function envOf(sealed) {
    return sealed ? JSON.parse(envBox.open(sealed)) : [];
  }

  function describe(row) {
    return toPublicContainer(row, { envKeys: envOf(row.env_encrypted).map((e) => e.key) });
  }

  async function load(id) {
    const row = await baseQuery().where('c.id', id).first();
    if (!row) throw notFound('Container not found');
    return row;
  }

  async function loadServer(id) {
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    return server;
  }

  // Every server with what its agent last said about Docker.
  async function servers(actor) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const rows = await db('servers').whereNull('deleted_at').orderBy('name').select('*');
    const counts = await db('containers').whereNull('deleted_at').groupBy('server_id').select('server_id').count({ n: '*' });
    return {
      items: rows.map((s) => {
        const docker = dockerOf(s);
        return {
          id: s.id,
          name: s.name,
          status: s.status,
          isLocal: Boolean(s.is_local),
          agentVersion: s.agent_version,
          // The agent can manage containers (0.10.0 and later).
          supported: agentOperations(s).includes('CONTAINER_DEPLOY'),
          docker: docker && { installed: docker.installed, running: docker.running, source: docker.source, service: docker.service, version: docker.version },
          containers: docker ? { total: docker.containers.length, running: docker.containers.filter((c) => c.state === 'running').length } : null,
          deployed: Number(counts.find((c) => c.server_id === s.id)?.n ?? 0),
          protectedPorts: protectedPorts(s),
          lastSeenAt: toIso(s.last_seen_at),
        };
      }),
    };
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const q = baseQuery();
    if (query.serverId) q.where('c.server_id', query.serverId);
    if (query.search) q.where('c.name', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'c.created_at', name: 'c.name' });
    return { items: rows.map(describe), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    return describe(await load(id));
  }

  // Values of the environment variables. Every look is audited.
  async function getEnv(actor, id) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const row = await load(id);
    await audit.record({ actor, action: 'container.env_view', target: target(row) });
    return { variables: envOf(row.env_encrypted) };
  }

  // ---- Checks ----------------------------------------------------------------

  function requireReady(server) {
    if (server.status === 'pending' || server.status === 'disabled') throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    if (!agentOperations(server).includes('CONTAINER_DEPLOY')) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) is too old to manage containers. Update it from the server page.`);
    }
  }

  function requireDocker(server) {
    requireReady(server);
    const docker = dockerOf(server);
    if (docker && !docker.installed) throw new AppError(409, 'DOCKER_NOT_INSTALLED', `Docker is not installed on ${server.name}. Install it from the Containers page.`);
    if (docker && !docker.running) throw new AppError(409, 'DOCKER_NOT_RUNNING', `Docker is installed on ${server.name} but not running. Start it from the Containers page.`);
  }

  function requireIdle(row) {
    if (CONTAINER_BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'CONTAINER_BUSY', 'Another change to this container is still running. Wait for it to finish.', { jobId: row.last_job_id });
    }
  }

  // Turns the API's fields into the stored spec, checking what only the
  // panel can: ports other containers or apps already use, and ports that
  // belong to the panel, SSH or NGINX.
  async function buildSpec(server, input, { except = null } = {}) {
    const problems = [];
    const ports = input.ports.map(formatPortMapping);
    const docker = dockerOf(server);
    const taken = new Map();
    const apps = await db('applications').where({ server_id: server.id }).whereNull('deleted_at').whereNotNull('port').select('name', 'port');
    for (const a of apps) taken.set(`${a.port}/tcp`, `the app ${a.name}`);
    const others = await db('containers').where({ server_id: server.id }).whereNull('deleted_at').modify((q) => except && q.whereNot({ id: except })).select('name', 'spec');
    for (const c of others) {
      for (const p of (fromJson(c.spec, {}).ports ?? []).map(parsePortMapping).filter(Boolean)) {
        taken.set(`${p.hostPort}/${p.protocol}`, `the container ${c.name}`);
      }
    }
    for (const c of docker?.containers ?? []) {
      if (except && c.managedId === except) continue;
      for (const port of c.hostPorts ?? []) if (!taken.has(`${port}/tcp`)) taken.set(`${port}/tcp`, `the container ${c.name}`);
    }
    // The ports SSH listens on, as the agent last reported them.
    const sshPorts = fromJson(server.security_summary, null)?.ssh?.ports;
    const reserved = new Map((Array.isArray(sshPorts) && sshPorts.length ? sshPorts : [SSH_PORT]).map((port) => [port, 'SSH']));
    const own = panelPort(server);
    if (own) reserved.set(own, 'the panel');
    if (server.is_local && config.loopbackPort) reserved.set(config.loopbackPort, 'the panel (loopback)');
    for (const port of protectedPorts(server)) reserved.set(port, 'the panel’s database or Redis');
    if (server.is_local) reserved.set(LOCAL_AI.port, 'the assistant’s model on this server');
    if (fromJson(server.web_stack, null)?.nginx) {
      reserved.set(80, 'NGINX (websites)');
      reserved.set(443, 'NGINX (websites)');
    }
    const seen = new Set();
    input.ports.forEach((p, i) => {
      const key = `${p.hostPort}/${p.protocol}`;
      if (seen.has(key)) problems.push({ field: `ports.${i}.hostPort`, message: `Port ${p.hostPort} is listed twice` });
      else if (reserved.has(p.hostPort) && p.protocol === 'tcp') problems.push({ field: `ports.${i}.hostPort`, message: `Port ${p.hostPort} is used by ${reserved.get(p.hostPort)}` });
      else if (taken.has(key)) problems.push({ field: `ports.${i}.hostPort`, message: `Port ${p.hostPort} is used by ${taken.get(key)}` });
      seen.add(key);
    });

    const volumes = input.volumes.map(formatVolumeMapping);
    if (new Set(input.volumes.map((v) => v.volume)).size !== input.volumes.length) problems.push({ field: 'volumes', message: 'Each volume can be mounted once' });
    if (new Set(input.volumes.map((v) => v.path)).size !== input.volumes.length) problems.push({ field: 'volumes', message: 'Each path can have one volume' });

    let command = null;
    if (input.command?.trim()) {
      const parsed = splitCommand(input.command.trim());
      if (parsed.error) problems.push({ field: 'command', message: parsed.error });
      else command = input.command.trim();
    }
    if (input.env) {
      const keys = input.env.map((e) => e.key);
      keys.forEach((key, i) => {
        if (keys.indexOf(key) !== i) problems.push({ field: `env.${i}.key`, message: `${key} is listed twice` });
      });
    }
    if (problems.length) throw validationError(problems);
    return {
      ports,
      volumes,
      restartPolicy: input.restartPolicy,
      memoryMb: input.memoryMb ?? null,
      cpuPercent: input.cpuPercent ?? null,
      command,
      healthCheckSeconds: input.healthCheckSeconds,
    };
  }

  function deployParams(row, { image, spec, env }, pull) {
    const params = {
      id: row.id,
      name: row.name,
      image,
      ports: spec.ports,
      env: env.map(({ key, value }) => `${key}=${value}`),
      volumes: spec.volumes,
      restartPolicy: spec.restartPolicy,
      healthCheckSeconds: spec.healthCheckSeconds,
      pull,
    };
    if (spec.memoryMb) params.memoryMb = spec.memoryMb;
    if (spec.cpuPercent) params.cpuPercent = spec.cpuPercent;
    if (spec.command) params.command = splitCommand(spec.command).argv;
    return params;
  }

  // ---- Deploying ---------------------------------------------------------------

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const server = await findServer(db, input.serverId);
    if (!server) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    requireDocker(server);
    const taken = await db('containers').where({ server_id: server.id, name_key: input.name }).first('id');
    if (taken) throw validationError([{ field: 'name', message: `A container named ${input.name} already exists on ${server.name}` }]);
    const other = dockerOf(server)?.containers.find((c) => c.name === input.name);
    if (other) throw validationError([{ field: 'name', message: `${server.name} already runs a container named ${input.name}` }]);
    const spec = await buildSpec(server, input);

    const id = randomUUID();
    const now = new Date();
    try {
      await db('containers').insert({
        id,
        server_id: server.id,
        name: input.name,
        name_key: input.name,
        image: input.image,
        spec: toJson(spec),
        env_encrypted: input.env.length ? envBox.seal(JSON.stringify(input.env)) : null,
        status: 'deploying',
        created_by: actor.type === 'user' ? actor.id : null,
        created_at: now,
        updated_at: now,
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'name', message: 'This name was just taken' }]);
      throw err;
    }
    let job;
    try {
      job = await jobs.create(
        actor,
        { serverId: server.id, type: 'CONTAINER_DEPLOY', params: deployParams({ id, name: input.name }, { image: input.image, spec, env: input.env }, true), resource: { type: 'container', id } },
        { internal: true },
      );
    } catch (err) {
      await db('containers').where({ id }).delete();
      throw err;
    }
    await db('containers').where({ id }).update({ last_job_id: job.id });
    await audit.record({
      actor,
      action: 'container.create',
      target: { type: 'container', id, label: input.name },
      metadata: { serverId: server.id, image: input.image, ports: spec.ports, volumes: spec.volumes, envKeys: input.env.map((e) => e.key), jobId: job.id },
    });
    return { container: describe(await load(id)), job };
  }

  // Queues a deployment of the row with the given image, spec and env. They
  // become the row's own when it succeeds.
  async function queueDeploy(actor, row, next, pull) {
    const claimed = await db('containers')
      .where({ id: row.id })
      .whereNotIn('status', CONTAINER_BUSY_STATUSES)
      .update({
        status: 'deploying',
        pending_image: next.image,
        pending_spec: toJson(next.spec),
        pending_env_encrypted: next.env.length ? envBox.seal(JSON.stringify(next.env)) : null,
        last_error_code: null,
        last_error: null,
        updated_at: new Date(),
      });
    if (!claimed) requireIdle({ ...row, status: 'deploying' });
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type: 'CONTAINER_DEPLOY', params: deployParams(row, next, pull), resource: { type: 'container', id: row.id } }, { internal: true });
    } catch (err) {
      await db('containers').where({ id: row.id }).update({ status: row.status, pending_image: null, pending_spec: null, pending_env_encrypted: null, updated_at: new Date() });
      throw err;
    }
    await db('containers').where({ id: row.id }).update({ last_job_id: job.id });
    return job;
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const server = await loadServer(row.server_id);
    requireDocker(server);
    const current = fromJson(row.spec, {});
    const merged = toInput(current, changes);
    const spec = await buildSpec(server, merged, { except: row.id });
    const env = changes.env ?? envOf(row.env_encrypted);
    const image = changes.image ?? row.image;
    const job = await queueDeploy(actor, row, { image, spec, env }, changes.pull ?? false);
    await audit.record({
      actor,
      action: 'container.update',
      target: target(row),
      metadata: { image, ports: spec.ports, volumes: spec.volumes, envChanged: Boolean(changes.env), envKeys: env.map((e) => e.key), jobId: job.id },
    });
    return { container: describe(await load(id)), job };
  }

  // Recreates the container as it is, pulling its image again by default
  // (picks up a new build of the same tag). Also retries a failed first deployment.
  async function redeploy(actor, id, { pull = true } = {}) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    requireDocker(await loadServer(row.server_id));
    const job = await queueDeploy(actor, row, { image: row.image, spec: fromJson(row.spec, {}), env: envOf(row.env_encrypted) }, pull);
    await audit.record({ actor, action: 'container.redeploy', target: target(row), metadata: { pull, jobId: job.id } });
    return { container: describe(await load(id)), job };
  }

  async function remove(actor, id, { removeVolumes = false } = {}) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const server = await loadServer(row.server_id);
    requireReady(server);
    const claimed = await db('containers').where({ id }).whereNotIn('status', CONTAINER_BUSY_STATUSES).update({ status: 'removing', last_error_code: null, last_error: null, updated_at: new Date() });
    if (!claimed) requireIdle({ ...row, status: 'removing' });
    let job;
    try {
      job = await jobs.create(
        actor,
        { serverId: row.server_id, type: 'CONTAINER_REMOVE', params: { container: row.name, id: row.id, removeVolumes, protectedPorts: protectedPorts(server) }, resource: { type: 'container', id } },
        { internal: true },
      );
    } catch (err) {
      await db('containers').where({ id }).update({ status: row.status, updated_at: new Date() });
      throw err;
    }
    await db('containers').where({ id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'container.remove', target: target(row), metadata: { removeVolumes, jobId: job.id } });
    return { container: describe(await load(id)), job };
  }

  // ---- Any container on a server -------------------------------------------------

  // The record of a deployed container a ref points at (its name or Docker ID).
  async function recordFor(serverId, ref) {
    const rows = await db('containers').where({ server_id: serverId }).whereNull('deleted_at').select('*');
    return rows.find((r) => r.name === ref || (r.docker_id && CONTAINER_ID_PATTERN.test(ref) && (r.docker_id.startsWith(ref) || ref.startsWith(r.docker_id)))) ?? null;
  }

  function refuseProtected(server, ref, verb) {
    const container = dockerOf(server)?.containers.find((c) => c.name === ref || (CONTAINER_ID_PATTERN.test(ref) && (ref.startsWith(c.id) || c.id.startsWith(ref))));
    if (container?.protected) {
      throw new AppError(409, 'PROTECTED_CONTAINER', `${container.name} runs part of VaultPanel itself (its database or Redis), so it cannot be ${verb} from the panel`);
    }
  }

  async function serverJob(actor, server, type, params, { action, label, record = null, metadata = {} }) {
    const job = await jobs.create(actor, { serverId: server.id, type, params, resource: record ? { type: 'container', id: record.id } : null }, { internal: true });
    if (action) {
      await audit.record({
        actor,
        action,
        target: record ? target(record) : { type: 'server', id: server.id, label: `${server.name}: ${label}` },
        metadata: { serverId: server.id, ...metadata, jobId: job.id },
      });
    }
    return job;
  }

  async function dockerStatus(actor, serverId) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'DOCKER_STATUS', {}, {});
  }

  async function installDocker(actor, serverId) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'DOCKER_INSTALL', {}, { action: 'docker.install', label: 'Docker' });
  }

  async function listLive(actor, serverId) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'CONTAINER_LIST', { protectedPorts: protectedPorts(server) }, {});
  }

  async function act(actor, serverId, ref, action) {
    const def = CONTAINER_ACTIONS[action];
    if (!def) throw notFound();
    await authorize(actor, PERMISSIONS.CONTAINERS_OPERATE);
    const server = await loadServer(serverId);
    requireReady(server);
    if (action !== 'start') refuseProtected(server, ref, action === 'stop' ? 'stopped' : 'restarted');
    const record = await recordFor(server.id, ref);
    if (record) requireIdle(record);
    return serverJob(actor, server, def.operation, { container: ref, protectedPorts: protectedPorts(server) }, { action: `container.${action}`, label: ref, record, metadata: { container: ref } });
  }

  // Start, stop or restart a deployed container from its own page.
  async function actOn(actor, id, action) {
    const row = await load(id);
    return act(actor, row.server_id, row.name, action);
  }

  async function logs(actor, serverId, ref, { lines }) {
    await authorize(actor, PERMISSIONS.CONTAINERS_LOGS);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'CONTAINER_LOGS', { container: ref, lines }, {});
  }

  async function inspect(actor, serverId, ref) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'CONTAINER_INSPECT', { container: ref, protectedPorts: protectedPorts(server) }, {});
  }

  // Removes any container. A container VaultPanel deployed is removed as its
  // record (so the record goes too).
  async function removeLive(actor, serverId, ref) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const server = await loadServer(serverId);
    requireReady(server);
    const record = await recordFor(server.id, ref);
    if (record) return (await remove(actor, record.id, { removeVolumes: false })).job;
    refuseProtected(server, ref, 'removed');
    return serverJob(actor, server, 'CONTAINER_REMOVE', { container: ref, protectedPorts: protectedPorts(server) }, { action: 'container.remove', label: ref, metadata: { container: ref } });
  }

  async function listImages(actor, serverId) {
    await authorize(actor, PERMISSIONS.CONTAINERS_READ);
    const server = await loadServer(serverId);
    requireReady(server);
    return serverJob(actor, server, 'IMAGE_LIST', {}, {});
  }

  async function pullImage(actor, serverId, { image }) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const server = await loadServer(serverId);
    requireDocker(server);
    return serverJob(actor, server, 'IMAGE_PULL', { image }, { action: 'image.pull', label: image, metadata: { image } });
  }

  async function removeImage(actor, serverId, { imageId }) {
    await authorize(actor, PERMISSIONS.CONTAINERS_MANAGE);
    const server = await loadServer(serverId);
    requireDocker(server);
    return serverJob(actor, server, 'IMAGE_REMOVE', { image: imageId }, { action: 'image.remove', label: imageId.slice(7, 19), metadata: { imageId } });
  }

  // ---- Job results and heartbeats ------------------------------------------------

  const failureOf = (ok, error) => (ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' });

  function stateColumns(container, now) {
    if (!container) return {};
    return { docker_id: container.id ?? null, state: container.state?.status ?? null, state_detail: null, state_checked_at: now };
  }

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type !== 'container') return;
    const row = await db('containers').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    switch (job.type) {
      case 'CONTAINER_DEPLOY': {
        if (ok) {
          // A change carries the whole environment, so an empty pending one
          // means no variables. A first deployment has nothing pending.
          const pendingSpec = fromJson(row.pending_spec, null);
          await db('containers').where({ id: row.id }).update({
            status: 'active',
            ...(pendingSpec ? { image: row.pending_image ?? row.image, spec: toJson(pendingSpec), env_encrypted: row.pending_env_encrypted } : {}),
            pending_image: null,
            pending_spec: null,
            pending_env_encrypted: null,
            deployed_at: now,
            ...stateColumns(output?.container, now),
            ...failureOf(true),
            updated_at: now,
          });
        } else {
          // A first deployment that failed leaves nothing on the server; a
          // later one rolled back to the container that was running.
          await db('containers').where({ id: row.id }).update({
            status: row.deployed_at ? 'active' : 'failed',
            pending_image: null,
            pending_spec: null,
            pending_env_encrypted: null,
            ...failureOf(false, error),
            updated_at: now,
          });
        }
        break;
      }
      case 'CONTAINER_REMOVE':
        if (ok) await db('containers').where({ id: row.id }).update({ status: 'active', name_key: null, deleted_at: now, state: null, updated_at: now });
        else await db('containers').where({ id: row.id }).update({ status: row.deployed_at ? 'active' : 'failed', ...failureOf(false, error), updated_at: now });
        break;
      case 'CONTAINER_START':
      case 'CONTAINER_STOP':
      case 'CONTAINER_RESTART':
        await db('containers').where({ id: row.id }).update({ ...(ok ? stateColumns(output?.container, now) : failureOf(false, error)), updated_at: now });
        break;
      default:
        return;
    }
    if (!ok) logger.info({ containerId: row.id, job: job.type, error }, 'container change failed');
  }

  // Docker's state, reported with every heartbeat by agents 0.10.0 and later.
  async function syncDocker(serverId, docker) {
    if (!docker || typeof docker !== 'object') return;
    const now = new Date();
    const containers = Array.isArray(docker.containers) ? docker.containers.slice(0, 300) : [];
    await db('servers').where({ id: serverId }).update({ docker_summary: toJson({ ...docker, containers, checkedAt: now.toISOString() }) });
    const rows = await db('containers').where({ server_id: serverId }).whereNull('deleted_at').whereNot('status', 'removing').select('id', 'docker_id');
    for (const row of rows) {
      const found = containers.find((c) => c.managedId === row.id);
      let next;
      if (!docker.running) next = { state: 'unknown', state_detail: 'Docker is not running' };
      else if (found) next = { state: String(found.state ?? '').slice(0, 16) || null, state_detail: found.status ? String(found.status).slice(0, 100) : null };
      else next = { state: 'missing', state_detail: null };
      // The heartbeat has the short ID; keep the full one a job reported.
      const dockerId = found && !row.docker_id?.startsWith(found.id) ? found.id : row.docker_id;
      await db('containers').where({ id: row.id }).update({ ...next, docker_id: dockerId, state_checked_at: now });
    }
  }

  async function summary() {
    const rows = await baseQuery().clearSelect().select('c.state').count({ n: '*' }).groupBy('c.state');
    const byState = Object.fromEntries(rows.map((r) => [r.state ?? 'unknown', Number(r.n)]));
    return { total: Object.values(byState).reduce((a, b) => a + b, 0), running: byState.running ?? 0, byState };
  }

  jobs.onFinished(handleJobFinished);

  return {
    servers,
    list,
    get,
    getEnv,
    create,
    update,
    redeploy,
    remove,
    actOn,
    act,
    logs,
    inspect,
    removeLive,
    listLive,
    dockerStatus,
    installDocker,
    listImages,
    pullImage,
    removeImage,
    protectedPorts,
    syncDocker,
    summary,
    handleJobFinished,
  };
}

// The stored spec with the changes asked for, in the API's shape.
function toInput(spec, changes) {
  return {
    ports: changes.ports ?? (spec.ports ?? []).map(parsePortMapping).filter(Boolean),
    volumes: changes.volumes ?? (spec.volumes ?? []).map(parseVolumeMapping).filter(Boolean),
    restartPolicy: changes.restartPolicy ?? spec.restartPolicy ?? 'unless-stopped',
    memoryMb: changes.memoryMb !== undefined ? changes.memoryMb : spec.memoryMb,
    cpuPercent: changes.cpuPercent !== undefined ? changes.cpuPercent : spec.cpuPercent,
    command: changes.command !== undefined ? changes.command : spec.command,
    healthCheckSeconds: changes.healthCheckSeconds ?? spec.healthCheckSeconds ?? 10,
    env: changes.env,
  };
}

function target(row) {
  return { type: 'container', id: row.id, label: row.name };
}
