import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import {
  BULK_ACTION_STATUSES,
  BULK_OPERATIONS,
  BULK_TARGET_FINAL_STATUSES,
  FINAL_JOB_STATUSES,
  MAX_BULK_SERVERS,
  OPERATIONS,
  PERMISSIONS,
  redactJobParams,
  validateParams,
} from '@vaultpanel/shared';
import { agentOperations } from '../models/serverModel.js';
import { compareVersions } from '../utils/agentPackage.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';
import { toIso } from '../utils/time.js';
import { userActor } from './actor.js';

export const bulkActionListQuery = listQuerySchema(['createdAt'], 'createdAt', {
  status: z.enum(BULK_ACTION_STATUSES).optional(),
  groupId: z.uuid().optional(),
});

// The job resource type that links a server's job to its part of a bulk action.
const RESOURCE = 'bulk_action';
// A target claimed for a job that never got one (the panel stopped in between).
const STALE_CLAIM_MS = 2 * 60_000;
// Reboot check: the server's boot time must be after the job finished, give or
// take this much for clock rounding.
const BOOT_SLACK_MS = 10_000;
const PANEL_HOST_VERIFY_MINUTES = 24 * 60;

// Bulk actions (phase 7): one allow-listed operation run on several servers,
// either all at once or one server at a time. Each server's part is an
// ordinary agent job, created as the person who started the action, so the
// same permission checks, duplicate checks, logs and audit entries apply.
//
// One at a time ("rolling") starts the next server only when the current one
// is done: its job succeeded and, for reboots and agent updates, the server
// came back (a newer boot time, or the new agent version). With
// stop_on_failure, a failed server stops the rest.
export function createBulkActionService({ db, logger, audit, authorize, jobs, groups, accessControl, agentPackage }) {
  async function create(actor, input) {
    const { type, params: rawParams = {}, serverIds = [], groupId = null, stopOnFailure = true } = input;
    await authorize(actor, PERMISSIONS.SERVERS_BULK);
    const spec = BULK_OPERATIONS[type];
    const op = OPERATIONS[type];
    if (!spec || !op?.available) throw new AppError(400, 'UNKNOWN_OPERATION', `"${type}" cannot be run as a bulk action`);
    await authorize(actor, op.permission);
    const mode = input.mode ?? spec.defaultMode ?? 'parallel';

    let params;
    if (type === 'AGENT_UPDATE') {
      const pkg = await agentPackage();
      params = { version: pkg.version, sha256: pkg.sha256, size: pkg.size };
    } else {
      const checked = validateParams(op.params, rawParams);
      if (!checked.ok) throw validationError(checked.errors.map((e) => ({ ...e, field: `params.${e.field}` })));
      params = checked.value;
    }

    let group = null;
    let ids = serverIds;
    if (groupId) {
      const picked = await groups.serverIdsInGroup(groupId);
      group = picked.group;
      ids = picked.serverIds;
      if (!ids.length) throw new AppError(409, 'GROUP_EMPTY', `The group "${group.name}" has no servers`);
    }
    ids = [...new Set(ids)];
    if (!ids.length) throw validationError([{ field: 'serverIds', message: 'Pick at least one server' }]);
    if (ids.length > MAX_BULK_SERVERS) throw validationError([{ field: 'serverIds', message: `At most ${MAX_BULK_SERVERS} servers at a time` }]);
    // The panel's own server goes last, so a reboot or agent restart there
    // cannot cut off the servers after it.
    const servers = await db('servers').whereIn('id', ids).whereNull('deleted_at').orderBy([{ column: 'is_local' }, { column: 'name' }]).select('*');
    if (servers.length !== ids.length) throw validationError([{ field: 'serverIds', message: 'One of the servers was not found' }]);

    const targets = servers.map((server, position) => {
      const reason = skipReason(type, server, params);
      return {
        id: randomUUID(),
        server_id: server.id,
        server_name: server.name,
        position,
        status: reason ? 'skipped' : 'waiting',
        message: reason,
        finished_at: reason ? new Date() : null,
      };
    });
    if (!targets.some((t) => t.status === 'waiting')) {
      throw new AppError(409, 'NOTHING_TO_RUN', `None of the servers can run this: ${targets.map((t) => `${t.server_name}: ${t.message}`).join('; ')}`, {
        servers: targets.map((t) => ({ serverId: t.server_id, name: t.server_name, reason: t.message })),
      });
    }

    const id = randomUUID();
    await db.transaction(async (trx) => {
      await trx('bulk_actions').insert({
        id,
        type,
        params: toJson(params),
        mode,
        stop_on_failure: mode === 'rolling' ? Boolean(stopOnFailure) : false,
        status: 'running',
        group_id: group?.id ?? null,
        group_name: group?.name ?? null,
        requested_by_type: actor.type === 'user' ? 'user' : 'system',
        requested_by: actor.type === 'user' ? actor.id : null,
        request_id: actor.requestId ?? null,
      });
      await trx('bulk_action_targets').insert(targets.map((t) => ({ ...t, action_id: id })));
    });
    await audit.record({
      actor,
      action: 'bulk_action.create',
      target: { type: 'bulk_action', id, label: spec.label },
      metadata: {
        operation: type,
        params: redactJobParams(type, params),
        mode,
        group: group?.name,
        servers: targets.length,
        skipped: targets.filter((t) => t.status === 'skipped').length,
      },
    });
    await advance(id, actor);
    return get(actor, id);
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.JOBS_READ);
    const q = db('bulk_actions as b').leftJoin('users as u', 'u.id', 'b.requested_by').select('b.*', 'u.email as requested_by_email');
    if (query.status) q.where('b.status', query.status);
    if (query.groupId) q.where('b.group_id', query.groupId);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'b.created_at' });
    const counts = await countsFor(rows.map((r) => r.id));
    return { items: rows.map((r) => toPublicAction(r, counts[r.id])), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.JOBS_READ);
    const row = await db('bulk_actions as b')
      .leftJoin('users as u', 'u.id', 'b.requested_by')
      .where('b.id', id)
      .first('b.*', 'u.email as requested_by_email');
    if (!row) throw notFound('Bulk action not found');
    const targets = await db('bulk_action_targets as t')
      .leftJoin('jobs as j', 'j.id', 't.job_id')
      .where('t.action_id', id)
      .leftJoin('servers as s', 's.id', 't.server_id')
      .orderBy('t.position')
      .select('t.*', 'j.status as job_status', 's.is_local');
    const counts = await countsFor([id]);
    return { ...toPublicAction(row, counts[id]), targets: targets.map(toPublicTarget) };
  }

  // Stops servers that have not started. Jobs still waiting for their agent
  // are cancelled too; anything already running on a server finishes.
  async function cancel(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_BULK);
    const action = await db('bulk_actions').where({ id }).first();
    if (!action) throw notFound('Bulk action not found');
    if (action.status !== 'running') throw new AppError(409, 'NOT_RUNNING', 'This bulk action has already finished');
    const now = new Date();
    await db('bulk_actions').where({ id }).update({ cancelled_at: now, cancelled_by: actor.type === 'user' ? actor.id : null, updated_at: now });
    await db('bulk_action_targets')
      .where({ action_id: id, status: 'waiting' })
      .update({ status: 'cancelled', message: `Cancelled by ${actor.label}`, finished_at: now, updated_at: now });
    const queued = await db('bulk_action_targets as t')
      .join('jobs as j', 'j.id', 't.job_id')
      .where({ 't.action_id': id, 't.status': 'running', 'j.status': 'queued' })
      .select('j.id');
    for (const { id: jobId } of queued) {
      // The job's own finish handler marks the target cancelled.
      await jobs.cancel(actor, jobId).catch((err) => logger.warn({ err, jobId }, 'could not cancel a bulk action job'));
    }
    await audit.record({ actor, action: 'bulk_action.cancel', target: { type: 'bulk_action', id, label: BULK_OPERATIONS[action.type]?.label ?? action.type } });
    await advance(id);
    return get(actor, id);
  }

  // ---- Progress ----------------------------------------------------------

  // Starts the servers that may start now and finishes the action when every
  // server is done. Safe to call from several places at once: targets are
  // claimed under a lock on the action row.
  async function advance(actionId, actor = null) {
    const claimed = await db.transaction(async (trx) => {
      const action = await trx('bulk_actions').where({ id: actionId }).forUpdate().first();
      if (!action || action.status !== 'running') return [];
      const targets = await trx('bulk_action_targets as t')
        .leftJoin('servers as s', 's.id', 't.server_id')
        .where('t.action_id', actionId)
        .orderBy('t.position')
        .select('t.*', 's.is_local');
      const now = new Date();
      const active = targets.filter((t) => t.status === 'running' || t.status === 'verifying');
      const failed = targets.some((t) => t.status === 'failed');
      let waiting = targets.filter((t) => t.status === 'waiting');

      if (action.mode === 'rolling' && action.stop_on_failure && failed && waiting.length) {
        await trx('bulk_action_targets')
          .whereIn('id', waiting.map((t) => t.id))
          .update({ status: 'cancelled', message: 'Not started because a server before it failed', finished_at: now, updated_at: now });
        waiting = [];
      }
      // Rebooting the panel's own server takes the panel down with it, so
      // that server waits until every other server is done, in either mode.
      if (action.type === 'SERVER_REBOOT') {
        const othersBusy = targets.some((t) => !t.is_local && !BULK_TARGET_FINAL_STATUSES.includes(t.status));
        if (othersBusy) waiting = waiting.filter((t) => !t.is_local);
      }
      const toStart = action.mode === 'rolling' ? (active.length ? [] : waiting.slice(0, 1)) : waiting;

      if (!toStart.length && !active.length) {
        const after = await trx('bulk_action_targets').where({ action_id: actionId }).select('status');
        const status = action.cancelled_at ? 'cancelled' : after.some((t) => t.status === 'failed') ? 'failed' : 'succeeded';
        await trx('bulk_actions').where({ id: actionId }).update({ status, finished_at: now, updated_at: now });
        return { finished: status, action };
      }
      if (toStart.length) {
        await trx('bulk_action_targets')
          .whereIn('id', toStart.map((t) => t.id))
          .update({ status: 'running', started_at: now, updated_at: now });
      }
      return { action, targets: toStart };
    });

    if (claimed.finished) {
      await audit.record({
        actor: { type: 'system', id: null, label: 'system' },
        action: 'bulk_action.finish',
        target: { type: 'bulk_action', id: actionId, label: BULK_OPERATIONS[claimed.action.type]?.label ?? claimed.action.type },
        result: claimed.finished === 'failed' ? 'failure' : 'success',
        metadata: { status: claimed.finished },
      });
      return;
    }
    if (!claimed.targets?.length) return;

    const requester = actor ?? (await actorFor(claimed.action));
    let startedAny = false;
    for (const target of claimed.targets) {
      if (!requester) {
        await finishTarget(target.id, 'failed', 'The person who started this action can no longer sign in, so it was not run');
        continue;
      }
      try {
        const job = await jobs.create(
          requester,
          { serverId: target.server_id, type: claimed.action.type, params: fromJson(claimed.action.params, {}), resource: { type: RESOURCE, id: target.id } },
          { internal: true },
        );
        await db('bulk_action_targets').where({ id: target.id }).update({ job_id: job.id, updated_at: new Date() });
        startedAny = true;
      } catch (err) {
        if (!(err instanceof AppError)) logger.error({ err, actionId }, 'bulk action job could not be queued');
        await finishTarget(target.id, 'failed', err instanceof AppError ? err.message : 'The job could not be queued');
      }
    }
    // A target that failed to start may let the next one start (rolling), or
    // finish the action.
    if (!startedAny || claimed.action.mode === 'rolling') await advance(actionId);
  }

  // Called for every job that reaches a final state.
  async function onJobFinished(job, result) {
    if (job.resource_type !== RESOURCE) return;
    const target = await db('bulk_action_targets').where({ id: job.resource_id }).first();
    if (!target || target.status !== 'running') return;
    if (!target.job_id) await db('bulk_action_targets').where({ id: target.id }).update({ job_id: job.id });
    await settleJob(target, job, result);
    await advance(target.action_id);
  }

  async function settleJob(target, job, result) {
    const spec = BULK_OPERATIONS[job.type] ?? {};
    if (result.status === 'cancelled') return finishTarget(target.id, 'cancelled', result.error?.message ?? 'Cancelled');
    if (result.status !== 'succeeded') return finishTarget(target.id, 'failed', result.error?.message ?? `The job ${result.status.replace('_', ' ')}`);
    const output = result.output ?? fromJson(job.output, null);
    if (spec.verify && !(job.type === 'AGENT_UPDATE' && output?.updated === false)) {
      const now = new Date();
      // The panel's own server comes back only when someone starts the panel
      // again, so it is given a day instead of the usual few minutes.
      const panelHost = spec.verify === 'reboot' && (await db('servers').where({ id: target.server_id }).first('is_local'))?.is_local;
      await db('bulk_action_targets')
        .where({ id: target.id, status: 'running' })
        .update({
          status: 'verifying',
          message: panelHost
            ? 'Waiting for the panel to be started again on this server after it boots'
            : spec.verify === 'reboot'
              ? 'Waiting for the server to come back online'
              : 'Waiting for the new agent to report in',
          verify_until: new Date(now.getTime() + (panelHost ? PANEL_HOST_VERIFY_MINUTES : spec.verifyMinutes) * 60_000),
          updated_at: now,
        });
      return null;
    }
    return finishTarget(target.id, 'succeeded', successMessage(job.type, output));
  }

  // Checks servers waiting to come back after a reboot or an agent update.
  async function verify(serverIds = null, now = new Date()) {
    const q = db('bulk_action_targets as t')
      .join('bulk_actions as b', 'b.id', 't.action_id')
      .join('jobs as j', 'j.id', 't.job_id')
      .join('servers as s', 's.id', 't.server_id')
      .where('t.status', 'verifying')
      .select('t.id', 't.action_id', 't.verify_until', 'b.type', 'b.params', 'j.finished_at', 's.status as server_status', 's.last_seen_at', 's.uptime_seconds', 's.agent_version');
    if (serverIds) q.whereIn('t.server_id', serverIds);
    const rows = await q;
    const touched = new Set();
    for (const row of rows) {
      const outcome = verifyOutcome(row, now);
      if (!outcome) continue;
      await finishTarget(row.id, outcome.status, outcome.message, 'verifying');
      touched.add(row.action_id);
    }
    for (const actionId of touched) await advance(actionId);
    return touched.size;
  }

  // From the agent's heartbeat: a server coming back is checked at once.
  async function onHeartbeat(serverId) {
    const waiting = await db('bulk_action_targets').where({ server_id: serverId, status: 'verifying' }).first('id');
    if (waiting) await verify([serverId]);
  }

  // Run by the maintenance pass: verification timeouts, jobs whose finish was
  // missed, claims that never got a job, and actions to move on.
  async function tick(now = new Date()) {
    const verified = await verify(null, now);
    const missed = await db('bulk_action_targets as t')
      .join('jobs as j', 'j.id', 't.job_id')
      .where('t.status', 'running')
      .whereIn('j.status', FINAL_JOB_STATUSES)
      .select('t.*', 'j.type', 'j.status as job_status', 'j.output', 'j.error_code', 'j.error_message', 'j.finished_at as job_finished_at');
    for (const row of missed) {
      const job = { id: row.job_id, type: row.type, output: row.output, resource_type: RESOURCE, resource_id: row.id };
      await settleJob(row, job, {
        status: row.job_status,
        output: fromJson(row.output, null),
        error: row.error_code ? { code: row.error_code, message: row.error_message } : null,
      });
    }
    const stale = await db('bulk_action_targets')
      .where({ status: 'running' })
      .whereNull('job_id')
      .where('started_at', '<', new Date(now.getTime() - STALE_CLAIM_MS))
      .select('id');
    for (const { id } of stale) await finishTarget(id, 'failed', 'The job for this server was never queued');
    const running = await db('bulk_actions').where({ status: 'running' }).select('id');
    for (const { id } of running) await advance(id);
    return { verified, missed: missed.length, stale: stale.length };
  }

  async function finishTarget(id, status, message, from = null) {
    const now = new Date();
    const q = db('bulk_action_targets').where({ id });
    if (from) q.where({ status: from });
    else q.whereNotIn('status', BULK_TARGET_FINAL_STATUSES);
    return q.update({ status, message: message ? String(message).slice(0, 1000) : null, finished_at: now, updated_at: now });
  }

  // Later servers run as the person who started the action, with the access
  // they have now: someone deactivated or demoted since cannot keep running it.
  async function actorFor(action) {
    if (!action.requested_by) return null;
    const user = await db('users').where({ id: action.requested_by, is_active: true }).whereNull('deleted_at').first();
    if (!user) return null;
    const access = await accessControl.getUserAccess(user.id);
    return { ...userActor(user, access, { requestId: action.request_id }), label: `${user.email} (bulk action)` };
  }

  async function countsFor(actionIds) {
    if (!actionIds.length) return {};
    const rows = await db('bulk_action_targets').whereIn('action_id', actionIds).groupBy('action_id', 'status').select('action_id', 'status').count({ n: '*' });
    const out = {};
    for (const r of rows) {
      const c = (out[r.action_id] ??= { total: 0 });
      c[r.status] = Number(r.n);
      c.total += Number(r.n);
    }
    return out;
  }

  return { create, list, get, cancel, advance, onJobFinished, onHeartbeat, verify, tick };
}

// Why a server is left out of a bulk action, or null if it can run it.
export function skipReason(type, server, params) {
  if (server.status === 'pending' || server.status === 'disabled') return 'No agent is connected';
  if (server.status === 'offline') return 'The server is offline';
  if (!agentOperations(server).includes(type)) {
    if (type === 'AGENT_UPDATE') return `Agent v${server.agent_version ?? '?'} cannot update itself; update it once with the command on the server's page`;
    return `Agent v${server.agent_version ?? '?'} cannot do this; update the agent first`;
  }
  if (type === 'AGENT_UPDATE' && server.agent_version && compareVersions(server.agent_version, params.version) >= 0) {
    return `Already on v${server.agent_version}`;
  }
  return null;
}

// Whether a server finished coming back, failed to, or is still pending (null).
export function verifyOutcome(row, now = new Date()) {
  const spec = BULK_OPERATIONS[row.type] ?? {};
  const finishedAt = row.finished_at ? new Date(row.finished_at).getTime() : 0;
  const lastSeen = row.last_seen_at ? new Date(row.last_seen_at).getTime() : 0;
  if (row.server_status === 'online' && lastSeen > finishedAt) {
    if (spec.verify === 'reboot' && row.uptime_seconds !== null && row.uptime_seconds !== undefined) {
      const bootedAt = lastSeen - Number(row.uptime_seconds) * 1000;
      if (bootedAt >= finishedAt - BOOT_SLACK_MS) return { status: 'succeeded', message: 'Rebooted and back online' };
    }
    if (spec.verify === 'agentVersion') {
      const wanted = fromJson(row.params, {}).version;
      if (row.agent_version && wanted && compareVersions(row.agent_version, wanted) >= 0) {
        return { status: 'succeeded', message: `Agent updated to v${row.agent_version}` };
      }
    }
  }
  if (row.verify_until && new Date(row.verify_until) <= now) {
    return {
      status: 'failed',
      message:
        spec.verify === 'reboot'
          ? `The server did not come back online within ${spec.verifyMinutes} minutes`
          : `The server did not report the new agent within ${spec.verifyMinutes} minutes. Check "journalctl -u vaultpanel-agent" on it`,
    };
  }
  return null;
}

function successMessage(type, output) {
  const service = output?.service;
  if (service?.name) return `${service.name} is ${service.active}${service.sub ? ` (${service.sub})` : ''}`;
  if (type === 'SECURITY_UPDATES_INSTALL') {
    const left = output?.updates?.security;
    return typeof left === 'number' ? `Updates installed; ${left} security update${left === 1 ? '' : 's'} still waiting` : 'Updates installed';
  }
  if (type === 'AGENT_UPDATE' && output?.updated === false) return `Already on v${output.version}`;
  return 'Done';
}

function toPublicAction(row, counts = {}) {
  return {
    id: row.id,
    type: row.type,
    label: BULK_OPERATIONS[row.type]?.label ?? row.type,
    params: redactJobParams(row.type, fromJson(row.params, {})),
    mode: row.mode,
    stopOnFailure: Boolean(row.stop_on_failure),
    status: row.status,
    group: row.group_name ? { id: row.group_id, name: row.group_name } : null,
    requestedBy: row.requested_by ? { id: row.requested_by, email: row.requested_by_email ?? undefined } : { type: row.requested_by_type },
    counts: { total: 0, waiting: 0, running: 0, verifying: 0, succeeded: 0, failed: 0, skipped: 0, cancelled: 0, ...counts },
    cancelledAt: toIso(row.cancelled_at),
    createdAt: toIso(row.created_at),
    finishedAt: toIso(row.finished_at),
  };
}

function toPublicTarget(row) {
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name,
    position: row.position,
    status: row.status,
    message: row.message,
    jobId: row.job_id,
    jobStatus: row.job_status ?? null,
    isLocal: Boolean(row.is_local),
    verifyUntil: toIso(row.verify_until),
    startedAt: toIso(row.started_at),
    finishedAt: toIso(row.finished_at),
  };
}
