import { randomUUID } from 'node:crypto';
import { CUSTOMER_PORT_RANGE, RESERVED_APP_PORTS } from '@vaultpanel/shared';
import { validationError } from '../utils/errors.js';
import { planLimits } from './tenancy.js';

// Each hosting customer's own app ports.
//
// A customer gets as many ports on their server as their plan allows apps
// (with no app limit: the ports their apps use plus one free one). Their apps
// can only listen on their own ports, and other apps (staff's or another
// customer's) cannot take them. sync() brings an account's ports in line with
// its plan and server: it adds ports from CUSTOMER_PORT_RANGE that nothing on
// the server uses, and gives back free ones above the limit. A port an app
// uses is never given back while the app exists.
export function createPortPoolService({ db, logger, quotas }) {
  const liveApps = (customerId) =>
    db('applications').where({ customer_id: customerId }).whereNull('deleted_at').select('id', 'name', 'server_id', 'port_key');

  // Ports on a server that something else already holds.
  async function takenOn(serverId) {
    const [appPorts, sitePorts, poolPorts] = await Promise.all([
      db('applications').where({ server_id: serverId }).whereNotNull('port_key').pluck('port_key'),
      db('websites').where({ server_id: serverId }).whereNull('deleted_at').whereNotNull('proxy_port').pluck('proxy_port'),
      db('customer_ports').where({ server_id: serverId }).pluck('port'),
    ]);
    return new Set([...appPorts, ...sitePorts, ...poolPorts, ...RESERVED_APP_PORTS].map(Number));
  }

  async function syncUnlocked(customerId) {
    const customer = await db('customers').where({ id: customerId }).first();
    if (!customer) return { added: 0, removed: 0, missing: 0 };
    const pool = await db('customer_ports').where({ customer_id: customerId }).select('id', 'server_id', 'port');
    const key = (serverId, port) => `${serverId}:${port}`;
    const inPool = new Set(pool.map((p) => key(p.server_id, p.port)));
    if (customer.status === 'terminated') {
      const removed = await db('customer_ports').where({ customer_id: customerId }).delete();
      return { added: 0, removed, missing: 0 };
    }

    const apps = await liveApps(customerId);
    const used = new Set(apps.filter((a) => a.port_key).map((a) => key(a.server_id, a.port_key)));
    let added = 0;
    let removed = 0;

    // Ports the account's apps already listen on are theirs (apps created
    // before ports were per customer, or given to the account by staff).
    for (const app of apps) {
      if (!app.port_key || inPool.has(key(app.server_id, app.port_key))) continue;
      try {
        await db('customer_ports').insert({ id: randomUUID(), customer_id: customerId, server_id: app.server_id, port: app.port_key, created_at: new Date() });
        pool.push({ server_id: app.server_id, port: app.port_key });
        inPool.add(key(app.server_id, app.port_key));
        added += 1;
      } catch (err) {
        if (err.code !== 'ER_DUP_ENTRY') throw err;
        logger.warn({ customerId, applicationId: app.id, port: app.port_key }, 'an app of this customer listens on a port of another customer');
      }
    }

    // Free ports on other servers (the account moved) go back.
    const away = pool.filter((p) => p.server_id !== customer.server_id && !used.has(key(p.server_id, p.port)));
    if (away.length) {
      removed += await db('customer_ports').where({ customer_id: customerId }).whereIn('id', away.map((p) => p.id).filter(Boolean)).delete();
    }
    if (!customer.server_id) return { added, removed, missing: 0 };

    const plan = await db('hosting_plans').where({ id: customer.plan_id }).first();
    const limit = planLimits(plan).applications;
    const usedElsewhere = apps.filter((a) => a.port_key && a.server_id !== customer.server_id).length;
    const target = limit === null ? apps.length + 1 : Math.max(0, limit - usedElsewhere);
    const home = (await db('customer_ports').where({ customer_id: customerId, server_id: customer.server_id }).orderBy('port', 'desc').select('id', 'port'));

    if (home.length > target) {
      const spare = home.filter((p) => !used.has(key(customer.server_id, p.port))).slice(0, home.length - target);
      if (spare.length) removed += await db('customer_ports').whereIn('id', spare.map((p) => p.id)).delete();
      return { added, removed, missing: 0 };
    }

    let wanted = target - home.length;
    if (wanted > 0) {
      const taken = await takenOn(customer.server_id);
      for (let port = CUSTOMER_PORT_RANGE.min; port <= CUSTOMER_PORT_RANGE.max && wanted > 0; port += 1) {
        if (taken.has(port)) continue;
        try {
          await db('customer_ports').insert({ id: randomUUID(), customer_id: customerId, server_id: customer.server_id, port, created_at: new Date() });
          added += 1;
          wanted -= 1;
        } catch (err) {
          // Another account took it at the same moment: try the next one.
          if (err.code !== 'ER_DUP_ENTRY') throw err;
        }
      }
      if (wanted > 0) logger.warn({ customerId, serverId: customer.server_id, missing: wanted }, 'no free customer ports left on this server');
    }
    return { added, removed, missing: Math.max(0, wanted) };
  }

  // Brings one account's ports in line with its plan. Pass locked when the
  // caller already holds the account's lock.
  async function sync(customerId, { locked = false } = {}) {
    if (!customerId) return null;
    return locked ? syncUnlocked(customerId) : quotas.withLock(customerId, () => syncUnlocked(customerId));
  }

  async function syncMany(customerIds) {
    for (const id of [...new Set(customerIds)].filter(Boolean)) {
      try {
        await sync(id);
      } catch (err) {
        logger.warn({ err, customerId: id }, 'could not update the customer ports');
      }
    }
  }

  // Every account that is not removed, plus removed ones still holding ports.
  // Run by the worker, so accounts created before per-customer ports, and
  // apps deleted since, are kept in line.
  async function syncAll() {
    const ids = await db('customers')
      .whereNot('status', 'terminated')
      .orWhereExists(db('customer_ports as cp').whereRaw('cp.customer_id = customers.id'))
      .pluck('id');
    await syncMany(ids);
    return ids.length;
  }

  // An account's ports with the app on each, home server first.
  async function list(customerId) {
    const rows = await db('customer_ports as cp')
      .join('servers as s', 's.id', 'cp.server_id')
      .leftJoin('applications as a', (j) => j.on('a.server_id', 'cp.server_id').andOn('a.port_key', 'cp.port').andOnNull('a.deleted_at'))
      .where('cp.customer_id', customerId)
      .orderBy([{ column: 's.name' }, { column: 'cp.port' }])
      .select('cp.port', 'cp.server_id', 's.name as server_name', 'a.id as application_id', 'a.name as application_name');
    return rows.map((r) => ({
      port: r.port,
      serverId: r.server_id,
      serverName: r.server_name,
      application: r.application_id ? { id: r.application_id, name: r.application_name } : null,
    }));
  }

  // For the app forms: the account's ports on a server and the free ones.
  async function forServer(customerId, serverId) {
    const ports = (await list(customerId)).filter((p) => p.serverId === serverId);
    return { ports, free: ports.filter((p) => !p.application).map((p) => p.port) };
  }

  // Throws unless `port` on `serverId` may be used by an app owned by
  // customerId (null: staff). A customer's app must use one of the account's
  // ports; nobody else may use them.
  async function check(customerId, serverId, port) {
    if (!port) return;
    const owner = await db('customer_ports').where({ server_id: serverId, port }).first('customer_id');
    if (customerId) {
      if (owner?.customer_id === customerId) return;
      const { free } = await forServer(customerId, serverId);
      const choices = free.length ? `Free ports: ${free.slice(0, 10).join(', ')}${free.length > 10 ? '…' : ''}.` : 'All of them are in use; delete an app or move to a bigger plan.';
      throw validationError([{ field: 'port', message: `Port ${port} is not one of this account's app ports. ${choices}` }]);
    }
    if (owner) {
      throw validationError([{ field: 'port', message: `Port ${port} is one of a hosting customer's app ports. Pick another port.` }]);
    }
  }

  // An app leaves an account: its port leaves the account's ports with it,
  // so the app can keep running on it.
  async function release(customerId, serverId, port) {
    if (!customerId || !port) return;
    await db('customer_ports').where({ customer_id: customerId, server_id: serverId, port }).delete();
  }

  return { sync, syncMany, syncAll, list, forServer, check, release };
}
