import { createAccessControlService } from './accessControlService.js';
import { createAgentService } from './agentService.js';
import { createAlertService } from './alertService.js';
import { createApiKeyService } from './apiKeyService.js';
import { createApiTokenService } from './apiTokenService.js';
import { createAuditQueryService, createAuditService } from './auditService.js';
import { createAuthService } from './authService.js';
import { createApplicationService } from './applicationService.js';
import { createAssistantService } from './assistantService.js';
import { createAuthorizer } from './authorization.js';
import { createBackupService } from './backupService.js';
import { createBackupStorageService } from './backupStorageService.js';
import { createBulkActionService } from './bulkActionService.js';
import { createCmsService } from './cmsService.js';
import { createContainerService } from './containerService.js';
import { createCronService } from './cronService.js';
import { createDashboardService } from './dashboardService.js';
import { createDatabaseService } from './databaseService.js';
import { createDnsProviderService } from './dnsProviderService.js';
import { createDnsService } from './dnsService.js';
import { createMailService } from './mailService.js';
import { createFinancialReportService } from './financialReportService.js';
import { createHostingService } from './hostingService.js';
import { createJobService } from './jobService.js';
import { createMaintenanceService } from './maintenanceService.js';
import { createPluginDirectoryService } from './pluginDirectoryService.js';
import { createFileUploadService } from './fileUploadService.js';
import { createFileDownloadService } from './fileDownloadService.js';
import { createMetricsService } from './metricsService.js';
import { createMonitoringService } from './monitoringService.js';
import { createPanelDomainService } from './panelDomainService.js';
import { createPanelEmailService } from './panelEmailService.js';
import { createPluginService } from './pluginService.js';
import { createPortPoolService } from './portPoolService.js';
import { createPanelAccessService } from './panelAccessService.js';
import { createSecurityService } from './securityService.js';
import { createServerGroupService } from './serverGroupService.js';
import { createServerService } from './serverService.js';
import { createSigningService } from './signingService.js';
import { createSiteDeployService } from './siteDeployService.js';
import { createSubdomainService } from './subdomainService.js';
import { createTerminalService } from './terminalService.js';
import { createTerminalRecordingService } from './terminalRecordingService.js';
import { createQuotaService } from './tenancy.js';
import { createUserService } from './userService.js';
import { createWebhookService } from './webhookService.js';
import { createWebsiteMonitorService } from './websiteMonitorService.js';
import { createWebsiteService } from './websiteService.js';
import { createSslRenewalService } from './sslRenewalService.js';
import { buildAgentPackage } from '../utils/agentPackage.js';

// Wires the service layer. Nothing here knows about HTTP, so the same
// services back the REST API, the worker and future CLI/automation callers.
export function createServices({ db, redis, config, logger, enqueueAssistant }) {
  const audit = createAuditService({ db, logger });
  const authorize = createAuthorizer({ audit });
  const accessControl = createAccessControlService({ db, authorize });
  const signing = createSigningService({ db, config });
  const jobs = createJobService({ db, logger, audit, authorize });
  const agents = createAgentService({ db, redis, logger, audit, jobs, signing, config });
  const metrics = createMetricsService({ db, config });
  const alerts = createAlertService({ db, config, logger, audit, authorize, metrics });
  // Hosting customers' limits (phase 8), checked when their things are created.
  const quotas = createQuotaService({ db, redis });
  // Each customer's own app ports, as many as their plan allows apps.
  const ports = createPortPoolService({ db, logger, quotas });
  // DNS providers whose API checks wildcard certificates (agent 0.38.0).
  const dnsProviders = createDnsProviderService({ db, config, audit, authorize });
  const websites = createWebsiteService({ db, logger, audit, authorize, jobs, quotas, dnsProviders });
  // Uptime of websites, checked from the panel (the worker runs the checks).
  const websiteMonitor = createWebsiteMonitorService({ db, config, logger, audit, authorize });
  const applications = createApplicationService({ db, config, logger, audit, authorize, jobs, websites, quotas, ports });
  // Static websites deployed from Git.
  // Large uploads in the website file manager.
  const fileUploads = createFileUploadService({ db, config, logger, audit, jobs, websites });
  const fileDownloads = createFileDownloadService({ db, config, logger, jobs, websites });
  // Recorded terminal sessions (the terminal service records into it).
  const terminalRecordings = createTerminalRecordingService({ db, config, logger, audit, authorize });
  const siteDeploys = createSiteDeployService({ db, config, logger, audit, authorize, jobs, websites });
  const databases = createDatabaseService({ db, config, logger, audit, authorize, jobs, applications, quotas });
  agents.onHeartbeat((ctx, body) => websites.syncCertificates(ctx.server.id, body.certificates));
  agents.onHeartbeat((ctx, body) => applications.syncProcesses(ctx.server.id, body.applications));
  agents.onHeartbeat((ctx, body) => databases.syncSizes(ctx.server.id, body.databases));
  // The app installer (WordPress, Joomla, Drupal, Laravel) builds on websites and databases.
  const cms = createCmsService({ db, config, logger, audit, authorize, jobs, websites, databases, quotas });
  // Webhooks hear about alerts and servers through the audit log, and about
  // deployments through their jobs. Backups and cron emit their own events.
  const webhooks = createWebhookService({ db, config, logger, audit, authorize });
  // Lists of plugins to install (docs/plugins.md#plugin-directories).
  const pluginDirectories = createPluginDirectoryService({ db, logger, audit, authorize, webhooks });
  audit.onRecord(webhooks.fromAudit);
  // Email the panel sends itself: links, and the same events as alerts.
  const email = createPanelEmailService({ db, config, logger, audit, authorize });
  webhooks.onEvent(email.onEvent);
  jobs.onFinished(webhooks.fromJob);
  // How early certificates renew, the panel's own renewals and expiry events.
  const sslRenewal = createSslRenewalService({ db, logger, audit, authorize, jobs, websites, events: webhooks });
  jobs.onFinished(sslRenewal.onJobFinished);
  // Restricting the panel to some addresses (0.34.0).
  const panelAccess = createPanelAccessService({ db, config, audit, authorize });
  const auth = createAuthService({ db, config, logger, audit, accessControl, panelAccess });
  const backupStorage = createBackupStorageService({ db, config, audit, authorize, jobs });
  const backups = createBackupService({ db, config, logger, audit, authorize, jobs, events: webhooks, storage: backupStorage });
  const cron = createCronService({ db, logger, audit, authorize, jobs, events: webhooks, quotas });
  agents.onHeartbeat((ctx, body) => backups.syncFiles(ctx.server.id, body.backups));
  // Multi-server management (phase 7).
  const serverGroups = createServerGroupService({ db, audit, authorize, metrics });
  const bulkActions = createBulkActionService({ db, logger, audit, authorize, jobs, groups: serverGroups, accessControl, agentPackage: buildAgentPackage });
  jobs.onFinished(bulkActions.onJobFinished);
  agents.onHeartbeat((ctx) => bulkActions.onHeartbeat(ctx.server.id));
  // Hosting plans, customers and billing (phase 8).
  const users = createUserService({ db, config, logger, audit, authorize, accessControl, email });
  const hosting = createHostingService({ db, logger, audit, authorize, quotas, ports, users, auth, websites, applications, databases, cron, backups });
  agents.onHeartbeat((ctx, body) => hosting.syncDiskUsage(ctx.server.id, body.diskUsage));
  // Docker containers (phase 10).
  const containers = createContainerService({ db, config, logger, audit, authorize, jobs });
  agents.onHeartbeat((ctx, body) => containers.syncDocker(ctx.server.id, body.docker));
  const servers = createServerService({ db, config, audit, authorize, metrics, groups: serverGroups, jobs, agentPackage: buildAgentPackage });
  // The AI assistant (phase 9) reads and acts through the services above.
  const assistant = createAssistantService({
    db,
    config,
    logger,
    audit,
    authorize,
    accessControl,
    services: { servers, websites, applications, databases, alerts, jobs },
    enqueue: enqueueAssistant,
  });
  jobs.onFinished(assistant.onJobFinished);
  const dns = createDnsService({ db, logger, audit, authorize, jobs });
  // Zones added for a hosting account go with it.
  hosting.onTerminated((actor, customerId) => dns.removeCustomerZones(actor, customerId));
  // Subdomains of the accounts' own domains, and their DNS records.
  const subdomains = createSubdomainService({ db, logger, audit, authorize, jobs, websites, quotas, dns });
  return {
    panelAccess,
    audit,
    auditQuery: createAuditQueryService({ db, authorize }),
    authorize,
    accessControl,
    signing,
    auth,
    users,
    email,
    quotas,
    ports,
    hosting,
    apiKeys: createApiKeyService({ db, audit, authorize }),
    financialReport: createFinancialReportService({ db, authorize }),
    // API tokens for the REST API, CLI and SDK (phase 10, part 2).
    apiTokens: createApiTokenService({ db, audit, authorize, accessControl }),
    // Plugins (phase 10, part 3): outside programs that use the API, receive
    // events through their own webhook and can show a page in the panel.
    plugins: createPluginService({ db, config, audit, authorize, webhooks }),
    pluginDirectories,
    servers,
    // The server terminal (agent 0.11.0): a root shell for owners.
    terminals: createTerminalService({ db, logger, audit, authorize, signing, accessControl, recordings: terminalRecordings }),
    terminalRecordings,
    serverGroups,
    bulkActions,
    jobs,
    agents,
    metrics,
    alerts,
    websites,
    websiteMonitor,
    sslRenewal,
    siteDeploys,
    fileUploads,
    fileDownloads,
    // The panel's own domain and certificate (Panel Domain page).
    panelDomain: createPanelDomainService({ db, config, logger, audit, authorize, websites, hosting }),
    applications,
    databases,
    cms,
    // DNS zones served by BIND on the panel's servers.
    dns,
    dnsProviders,
    subdomains,
    // Email hosting (Postfix, Dovecot, OpenDKIM) on the panel's servers.
    mail: createMailService({ db, logger, audit, authorize, jobs, dns }),
    containers,
    backups,
    backupStorage,
    cron,
    webhooks,
    security: createSecurityService({ db, config, audit, authorize, jobs, onPolicyChange: auth.invalidatePolicy }),
    monitoring: createMonitoringService({ db, authorize, metrics, alerts }),
    dashboard: createDashboardService({ db, authorize, alerts, websites, applications, databases, backups, cron }),
    assistant,
    maintenance: createMaintenanceService({ db, config, logger, agents, jobs, metrics, alerts, backups, webhooks, email, bulkActions, assistant, ports, sslRenewal, fileUploads, fileDownloads, pluginDirectories, terminalRecordings, websiteMonitor }),
  };
}
