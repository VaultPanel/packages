import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { PERMISSIONS, SERVER_STATUSES } from '@vaultpanel/shared';
import { agentOperations, findServer, toPublicMetric, toPublicServer } from '../models/serverModel.js';
import { compareVersions, LATEST_AGENT_VERSION } from '../utils/agentPackage.js';
import { AppError, notFound } from '../utils/errors.js';
import { newToken, sha256Hex } from '../utils/crypto.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';
import { addMinutes, toIso } from '../utils/time.js';
import { agentPinFor, curlTlsOptions } from '../utils/panelTls.js';

export const serverListQuery = listQuerySchema(['createdAt', 'name', 'lastSeenAt'], 'createdAt', {
  search: z.string().max(100).optional(),
  status: z.enum(SERVER_STATUSES).optional(),
  groupId: z.uuid().optional(),
});

export function createServerService({ db, config, audit, authorize, metrics: metricStore, groups, jobs, agentPackage }) {
  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const q = db('servers').whereNull('deleted_at').select('*');
    if (query.search) {
      const term = `%${query.search.replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) => w.where('name', 'like', term).orWhere('hostname', 'like', term).orWhere('public_ip', 'like', term));
    }
    if (query.status) q.where('status', query.status);
    if (query.groupId) q.whereIn('id', db('server_group_members').where({ group_id: query.groupId }).select('server_id'));
    const { rows, pagination } = await paginate(q, query, { createdAt: 'created_at', lastSeenAt: 'last_seen_at' });
    const ids = rows.map((r) => r.id);
    const [latest, groupsByServer] = await Promise.all([metricStore.latest(ids), groups.groupsForServers(ids)]);
    return {
      items: rows.map((r) => ({
        ...toPublicServer(r),
        latestMetrics: toPublicMetric(latest[r.id]),
        groups: groupsByServer[r.id] ?? [],
        agentUpdateAvailable: Boolean(agentUpdate(r)),
      })),
      pagination,
    };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    const [latest, groupsByServer, agent, enrollment] = await Promise.all([
      metricStore.latest([id]),
      groups.groupsForServers([id]),
      db('server_agents').where({ server_id: id }).whereNull('revoked_at').orderBy('registered_at', 'desc').first(),
      db('server_enrollment_tokens')
        .where({ server_id: id })
        .whereNull('used_at')
        .where('expires_at', '>', new Date())
        .orderBy('created_at', 'desc')
        .first(),
    ]);
    return {
      ...toPublicServer(server),
      latestMetrics: toPublicMetric(latest[id]),
      groups: groupsByServer[id] ?? [],
      agent: agent
        ? {
            id: agent.id,
            keyFingerprint: agent.key_fingerprint,
            version: agent.agent_version,
            registeredAt: toIso(agent.registered_at),
            registeredIp: agent.registered_ip,
            lastSeenAt: toIso(agent.last_seen_at),
          }
        : null,
      pendingEnrollment: enrollment ? { expiresAt: toIso(enrollment.expires_at) } : null,
      agentUpdate: agentUpdate(server),
    };
  }

  // Adds a server record and an enrollment token. The server stays "pending"
  // until an agent registers with the token.
  async function create(actor, { name }) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const id = randomUUID();
    await db('servers').insert({ id, name, status: 'pending', created_by: actor.type === 'user' ? actor.id : null });
    const enrollment = await issueEnrollment(id, actor);
    const server = await findServer(db, id);
    await audit.record({ actor, action: 'server.create', target: target(server) });
    return { server: toPublicServer(server), enrollment };
  }

  async function update(actor, id, { name }) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    await db('servers').where({ id }).update({ name, updated_at: new Date() });
    await audit.record({ actor, action: 'server.update', target: target(server), metadata: { name } });
    return get(actor, id);
  }

  // Removes the server from the panel and revokes its agent. Nothing on the
  // server itself is touched; the agent stops working once revoked.
  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    const now = new Date();
    await db.transaction(async (trx) => {
      await trx('servers').where({ id }).update({ deleted_at: now, status: 'disabled', updated_at: now });
      await trx('server_agents')
        .where({ server_id: id })
        .whereNull('revoked_at')
        .update({ revoked_at: now, revoked_reason: 'server removed' });
      await trx('server_enrollment_tokens').where({ server_id: id }).whereNull('used_at').update({ used_at: now });
      await trx('jobs')
        .where({ server_id: id, status: 'queued' })
        .update({ status: 'cancelled', finished_at: now, error_code: 'SERVER_REMOVED', error_message: 'Server was removed' });
    });
    await audit.record({ actor, action: 'server.delete', target: target(server) });
  }

  async function createEnrollment(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    const enrollment = await issueEnrollment(id, actor);
    await audit.record({ actor, action: 'server.enrollment_token_create', target: target(server) });
    return enrollment;
  }

  async function metrics(actor, id, range) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    if (!(await findServer(db, id))) throw notFound('Server not found');
    return metricStore.history(id, range);
  }

  // Updates the agent from the panel (agent 0.7.0 and later can install a new
  // version of itself). Older agents are updated with the command instead.
  async function updateAgent(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const server = await findServer(db, id);
    if (!server) throw notFound('Server not found');
    if (!agentUpdate(server)) throw new AppError(409, 'AGENT_CURRENT', `The agent is already on v${server.agent_version ?? '?'}`);
    const pkg = await agentPackage();
    const job = await jobs.create(actor, { serverId: id, type: 'AGENT_UPDATE', params: { version: pkg.version, sha256: pkg.sha256, size: pkg.size } }, { internal: true });
    await audit.record({ actor, action: 'server.agent_update', target: target(server), metadata: { jobId: job.id, from: server.agent_version, to: pkg.version } });
    return job;
  }

  // Tells the UI when the agent is older than the one this panel serves,
  // with the command that upgrades it in place (no new enrollment needed),
  // and whether the panel can do it with a job instead.
  function agentUpdate(server) {
    if (!server.agent_version || !LATEST_AGENT_VERSION) return null;
    if (compareVersions(server.agent_version, LATEST_AGENT_VERSION) >= 0) return null;
    return {
      currentVersion: server.agent_version,
      latestVersion: LATEST_AGENT_VERSION,
      fromPanel: agentOperations(server).includes('AGENT_UPDATE'),
      command: agentInstallCommand(config, { before: ['--upgrade'] }),
    };
  }

  async function issueEnrollment(serverId, actor) {
    const token = `vpe_${newToken()}`;
    const expiresAt = addMinutes(new Date(), config.enrollmentTtlMinutes);
    // Only the newest token is valid.
    await db('server_enrollment_tokens').where({ server_id: serverId }).whereNull('used_at').update({ used_at: new Date() });
    await db('server_enrollment_tokens').insert({
      id: randomUUID(),
      server_id: serverId,
      token_hash: sha256Hex(token),
      created_by: actor.type === 'user' ? actor.id : null,
      expires_at: expiresAt,
    });
    return {
      token,
      expiresAt: expiresAt.toISOString(),
      installCommand: agentInstallCommand(config, { after: ['--token', token] }),
    };
  }

  return { list, get, create, update, remove, createEnrollment, metrics, updateAgent };
}

// The one-line command that installs (or upgrades) an agent from this panel.
// When the panel serves its own self-signed certificate, curl and the agent
// trust exactly that certificate through its public key pin, so no domain is
// needed to add servers safely. Over plain HTTP (development, or a panel set
// up that way on purpose) the agent must be told it may use HTTP.
export function agentInstallCommand(config, { before = [], after = [] } = {}) {
  const pin = agentPinFor(config);
  const extra = [...after];
  if (pin) extra.push('--panel-pin', `'${pin}'`);
  else if (config.publicUrl.startsWith('http://') && config.allowInsecureAgents) extra.push('--insecure-http');
  const args = [...before, '--panel', config.publicUrl, ...extra].join(' ');
  return `curl -fsSL ${curlTlsOptions(pin)}${config.publicUrl}/api/v1/agent/install.sh | sudo bash -s -- ${args}`;
}

function target(server) {
  return { type: 'server', id: server.id, label: server.name };
}
