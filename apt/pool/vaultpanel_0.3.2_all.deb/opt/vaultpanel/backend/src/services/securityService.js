import { addressInNetwork, PERMISSIONS, roleRank, securityChecks, TWO_FACTOR_POLICY_KEYS } from '@vaultpanel/shared';
import { agentOperations } from '../models/serverModel.js';
import { rolesByUser } from '../models/userModel.js';
import { getSetting } from '../models/settingModel.js';
import { AppError, notFound } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { toIso } from '../utils/time.js';

export const TWO_FACTOR_POLICY_SETTING = 'auth.two_factor_policy';

// Server security (firewall, SSH, Fail2ban, updates) and the panel's sign-in
// policy.
//
// Every server change is a job for the server's agent, which re-checks it and
// refuses anything that would lock people out (see agent/src/operations/
// firewall.js and ssh.js). The panel adds what only it knows: the port people
// reach the panel on, when the panel runs on that server, and the address of
// the person asking, so a firewall rule cannot block them.
export function createSecurityService({ db, config, audit, authorize, jobs, onPolicyChange = () => {} }) {
  async function loadServer(id) {
    const server = await db('servers').where({ id }).whereNull('deleted_at').first();
    if (!server) throw notFound('Server not found');
    return server;
  }

  // The panel's own port, if it runs on this server: blocking it would cut
  // off the panel along with the server.
  function protectedPorts(server) {
    if (!server.is_local) return [];
    const ports = new Set();
    // Both the address from the environment (which keeps working) and the
    // one set on the Panel Domain page.
    for (const address of new Set([config.envPublicUrl, config.publicUrl].filter(Boolean))) {
      try {
        const url = new URL(address);
        ports.add(Number(url.port) || (url.protocol === 'https:' ? 443 : 80));
      } catch {
        // validated when set
      }
    }
    return [...ports];
  }

  // Outgoing rules, SSH ports and other accounts' keys came with agent 0.34.0.
  function requireNewAgent(server, what) {
    if (!agentOperations(server).includes('SSH_PORTS_SET')) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot change ${what}. Update the agent to 0.34.0 or later first.`);
    }
  }

  async function queue(actor, server, type, params, action, metadata = {}) {
    const job = await jobs.create(actor, { serverId: server.id, type, params }, { internal: true });
    await audit.record({ actor, action, target: { type: 'server', id: server.id, label: server.name }, metadata: { ...metadata, jobId: job.id } });
    return job;
  }

  async function overview(actor) {
    await authorize(actor, PERMISSIONS.SECURITY_READ);
    const rows = await db('servers').whereNull('deleted_at').orderBy('name').select('*');
    const items = rows.map((row) => {
      const summary = fromJson(row.security_summary, null);
      const checks = securityChecks(summary);
      const scored = checks.filter((c) => c.status !== 'info');
      return {
        id: row.id,
        name: row.name,
        status: row.status,
        isLocal: Boolean(row.is_local),
        agentVersion: row.agent_version,
        supported: agentOperations(row).includes('SECURITY_STATUS'),
        protectedPorts: protectedPorts(row),
        summary,
        checkedAt: summary?.checkedAt ?? null,
        checks,
        passed: scored.filter((c) => c.status === 'ok').length,
        total: scored.length,
      };
    });
    return { items };
  }

  async function server(actor, id) {
    await authorize(actor, PERMISSIONS.SECURITY_READ);
    const row = await loadServer(id);
    const summary = fromJson(row.security_summary, null);
    return {
      id: row.id,
      name: row.name,
      supported: agentOperations(row).includes('SECURITY_STATUS'),
      // Outgoing rules, SSH ports, other accounts' keys (agent 0.34.0).
      advanced: agentOperations(row).includes('SSH_PORTS_SET'),
      protectedPorts: protectedPorts(row),
      summary,
      checks: securityChecks(summary),
      // What a firewall rule must not block.
      yourAddress: actor.ip ?? null,
    };
  }

  // ---- Firewall ---------------------------------------------------------------

  async function setFirewall(actor, id, { enabled }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    if (enabled) return queue(actor, row, 'FIREWALL_ENABLE', { protectedPorts: protectedPorts(row) }, 'security.firewall_enable');
    return queue(actor, row, 'FIREWALL_DISABLE', {}, 'security.firewall_disable');
  }

  function assertNotSelf(actor, rule) {
    if (rule.direction === 'out' || !['deny', 'reject'].includes(rule.action) || rule.source === 'any' || !actor.ip) return;
    if (addressInNetwork(actor.ip, rule.source)) {
      throw new AppError(409, 'LOCKOUT_REFUSED', `This rule would block your own address (${actor.ip.replace(/^::ffff:/, '')}), so it was not added`);
    }
  }

  async function addRule(actor, id, rule) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    assertNotSelf(actor, rule);
    const params = ruleParams(row, rule);
    if (!params.comment) delete params.comment;
    return queue(actor, row, 'FIREWALL_RULE_ADD', params, 'security.firewall_rule_add', { rule });
  }

  async function deleteRule(actor, id, rule) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    return queue(actor, row, 'FIREWALL_RULE_DELETE', ruleParams(row, rule), 'security.firewall_rule_delete', { rule });
  }

  // Incoming rules go out as before, so older agents keep working.
  function ruleParams(row, { direction = 'in', destination = 'any', ...rule }) {
    if (direction === 'in') return { ...rule, protectedPorts: protectedPorts(row) };
    requireNewAgent(row, 'outgoing rules');
    const { source, ...rest } = rule;
    return { ...rest, direction, destination, protectedPorts: protectedPorts(row) };
  }

  async function setFirewallDefault(actor, id, { incoming, outgoing }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    if (outgoing !== undefined) requireNewAgent(row, 'the outgoing default');
    const params = { ...(incoming ? { incoming } : {}), ...(outgoing ? { outgoing } : {}), protectedPorts: protectedPorts(row) };
    return queue(actor, row, 'FIREWALL_DEFAULTS', params, 'security.firewall_default', { incoming, outgoing });
  }

  // ---- SSH, Fail2ban and updates ---------------------------------------------------

  async function configureSsh(actor, id, settings) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    return queue(actor, await loadServer(id), 'SSH_CONFIGURE', settings, 'security.ssh_configure', { settings });
  }

  // Keys for root go out as before; other accounts need agent 0.34.0.
  function keyUser(row, user) {
    if (!user || user === 'root') return {};
    requireNewAgent(row, `the SSH keys of ${user}`);
    return { user };
  }

  async function addSshKey(actor, id, { key, user }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    const [type, , ...comment] = key.trim().split(' ');
    return queue(actor, row, 'SSH_KEY_ADD', { key: key.trim(), ...keyUser(row, user) }, 'security.ssh_key_add', { user: user ?? 'root', keyType: type, comment: comment.join(' ') || undefined });
  }

  async function removeSshKey(actor, id, { fingerprint, user }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    return queue(actor, row, 'SSH_KEY_REMOVE', { fingerprint, ...keyUser(row, user) }, 'security.ssh_key_remove', { user: user ?? 'root', fingerprint });
  }

  // The ports SSH listens on. The panel's own port can't be one of them.
  async function setSshPorts(actor, id, { ports }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    requireNewAgent(row, 'the SSH port');
    const taken = ports.find((port) => protectedPorts(row).includes(port));
    if (taken) throw new AppError(422, 'VALIDATION_ERROR', `Port ${taken} is where people reach the panel`);
    return queue(actor, row, 'SSH_PORTS_SET', { ports, protectedPorts: protectedPorts(row) }, 'security.ssh_ports', { ports });
  }

  // "VaultPanel only": SSH logins and the Terminal show just the VaultPanel
  // banner, with this server's name and the panel's address.
  async function setLoginBanner(actor, id, { vaultpanelOnly }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    const row = await loadServer(id);
    const params = vaultpanelOnly ? { vaultpanelOnly, serverName: row.name.slice(0, 100), panelUrl: config.publicUrl.slice(0, 300) } : { vaultpanelOnly };
    return queue(actor, row, 'LOGIN_BANNER_SET', params, 'security.login_banner', { vaultpanelOnly });
  }

  async function configureFail2ban(actor, id, settings) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    return queue(actor, await loadServer(id), 'FAIL2BAN_CONFIGURE', settings, 'security.fail2ban_configure', { settings });
  }

  async function unban(actor, id, { ip }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    return queue(actor, await loadServer(id), 'FAIL2BAN_UNBAN', { ip }, 'security.fail2ban_unban', { ip });
  }

  async function setAutoUpdates(actor, id, { enabled }) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    return queue(actor, await loadServer(id), 'AUTO_UPDATES_CONFIGURE', { enabled }, 'security.auto_updates', { enabled });
  }

  async function installUpdates(actor, id) {
    await authorize(actor, PERMISSIONS.SECURITY_MANAGE);
    return queue(actor, await loadServer(id), 'SECURITY_UPDATES_INSTALL', {}, 'security.updates_install');
  }

  // ---- Panel sign-in ---------------------------------------------------------------

  async function authentication(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const policy = (await getSetting(db, TWO_FACTOR_POLICY_SETTING)) ?? 'off';
    const users = await db('users as u')
      .leftJoin('user_roles as ur', 'ur.user_id', 'u.id')
      .leftJoin('roles as r', 'r.id', 'ur.role_id')
      .whereNull('u.deleted_at')
      .orderBy('u.email')
      .select('u.id', 'u.email', 'u.name', 'u.is_active', 'u.totp_enabled', 'u.last_login_at', 'r.name as role');
    const codes = await db('user_recovery_codes').whereNull('used_at').groupBy('user_id').select('user_id').count({ n: '*' });
    const left = Object.fromEntries(codes.map((c) => [c.user_id, Number(c.n)]));
    const sessions = await db('sessions').whereNull('revoked_at').where('expires_at', '>', new Date()).groupBy('user_id').select('user_id').count({ n: '*' });
    const active = Object.fromEntries(sessions.map((s) => [s.user_id, Number(s.n)]));
    return {
      twoFactorPolicy: policy,
      users: users.map((u) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        isActive: Boolean(u.is_active),
        twoFactorEnabled: Boolean(u.totp_enabled),
        recoveryCodesLeft: u.totp_enabled ? (left[u.id] ?? 0) : null,
        activeSessions: active[u.id] ?? 0,
        lastLoginAt: toIso(u.last_login_at),
      })),
    };
  }

  async function setTwoFactorPolicy(actor, { twoFactorPolicy }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    if (!TWO_FACTOR_POLICY_KEYS.includes(twoFactorPolicy)) throw new AppError(422, 'VALIDATION_ERROR', 'Unknown policy');
    // Whoever turns it on must already use it, or they would be sent
    // straight to the setup page.
    if (twoFactorPolicy !== 'off') {
      const me = await db('users').where({ id: actor.id }).first('totp_enabled');
      if (!me?.totp_enabled) {
        throw new AppError(409, 'TWO_FACTOR_REQUIRED_FIRST', 'Turn on two-factor sign-in for your own account first (Account page)');
      }
    }
    const previous = (await getSetting(db, TWO_FACTOR_POLICY_SETTING)) ?? 'off';
    const row = { key: TWO_FACTOR_POLICY_SETTING, value: twoFactorPolicy, is_secret: false, updated_by: actor.id, updated_at: new Date() };
    await db('settings').insert(row).onConflict('key').merge(['value', 'updated_by', 'updated_at']);
    onPolicyChange();
    await audit.record({ actor, action: 'security.two_factor_policy', target: { type: 'settings', id: null, label: 'Two-factor sign-in' }, metadata: { from: previous, to: twoFactorPolicy } });
    return authentication(actor);
  }

  // Everyone's signed-in sessions, for people who manage users.
  async function sessions(actor) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    const rows = await db('sessions as s')
      .join('users as u', 'u.id', 's.user_id')
      .whereNull('s.revoked_at')
      .where('s.expires_at', '>', new Date())
      .whereNull('u.deleted_at')
      .orderBy('s.last_seen_at', 'desc')
      .select('s.id', 's.user_id', 's.ip', 's.user_agent', 's.created_at', 's.last_seen_at', 's.expires_at', 'u.email', 'u.name')
      .limit(500);
    return {
      items: rows.map((r) => ({
        id: r.id,
        user: { id: r.user_id, email: r.email, name: r.name },
        ip: r.ip,
        userAgent: r.user_agent,
        createdAt: toIso(r.created_at),
        lastSeenAt: toIso(r.last_seen_at),
        expiresAt: toIso(r.expires_at),
        current: r.id === actor.sessionId,
      })),
    };
  }

  async function revokeSession(actor, id) {
    await authorize(actor, PERMISSIONS.USERS_MANAGE);
    const session = await db('sessions as s').join('users as u', 'u.id', 's.user_id').where('s.id', id).whereNull('s.revoked_at').first('s.id', 's.user_id', 'u.email');
    if (!session) throw notFound('Session not found');
    if (id === actor.sessionId) throw new AppError(400, 'BAD_REQUEST', 'Use Sign out to end the session you are using');
    const roles = (await rolesByUser(db, [session.user_id]))[session.user_id] ?? [];
    if (Math.max(0, ...roles.map(roleRank)) > actor.rank) throw new AppError(403, 'FORBIDDEN', 'You cannot manage a user with a higher role than yours');
    await db('sessions').where({ id }).update({ revoked_at: new Date() });
    await audit.record({ actor, action: 'user.session_revoke', target: { type: 'user', id: session.user_id, label: session.email }, metadata: { sessionId: id } });
  }

  return {
    sessions,
    revokeSession,
    overview,
    server,
    setFirewall,
    addRule,
    deleteRule,
    setFirewallDefault,
    configureSsh,
    addSshKey,
    removeSshKey,
    setSshPorts,
    setLoginBanner,
    configureFail2ban,
    unban,
    setAutoUpdates,
    installUpdates,
    authentication,
    setTwoFactorPolicy,
    protectedPorts,
  };
}
