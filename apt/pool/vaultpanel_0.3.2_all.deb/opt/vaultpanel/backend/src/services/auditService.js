import { z } from 'zod';
import { toPublicAuditEntry } from '../models/auditModel.js';
import { toJson } from '../utils/json.js';
import { listQuerySchema, paginate } from '../utils/pagination.js';
import { PERMISSIONS } from '@vaultpanel/shared';

export const auditListQuery = listQuerySchema(['occurredAt', 'action'], 'occurredAt', {
  action: z.string().max(64).optional(),
  actorId: z.string().max(36).optional(),
  targetType: z.string().max(32).optional(),
  targetId: z.string().max(64).optional(),
  result: z.enum(['success', 'failure', 'denied']).optional(),
  from: z.iso.datetime().optional(),
  to: z.iso.datetime().optional(),
});

export function createAuditService({ db, logger }) {
  // Called after each recorded entry ({ actor, action, target, result,
  // metadata }); used to turn some actions into webhook events.
  const listeners = [];
  function onRecord(listener) {
    listeners.push(listener);
  }

  // Records one audit entry. Failing to write the audit log is logged loudly
  // but never hides the outcome of the action being audited.
  async function record({ actor, action, target = null, result = 'success', metadata = null }, trx = db) {
    const entry = {
      occurred_at: new Date(),
      actor_type: actor?.type ?? 'system',
      actor_id: actor?.id ?? null,
      actor_label: truncate(actor?.label, 254),
      action,
      target_type: target?.type ?? null,
      target_id: target?.id ? String(target.id) : null,
      target_label: truncate(target?.label, 255),
      result,
      ip: actor?.ip ?? null,
      user_agent: truncate(actor?.userAgent, 512),
      request_id: actor?.requestId ?? null,
      metadata: metadata ? toJson(metadata) : null,
    };
    try {
      await trx('audit_logs').insert(entry);
    } catch (err) {
      logger.error({ err, audit: entry }, 'failed to write audit log entry');
      if (trx !== db) throw err;
    }
    for (const listener of listeners) {
      try {
        await listener({ actor, action, target, result, metadata });
      } catch (err) {
        logger.error({ err, action }, 'audit listener failed');
      }
    }
  }

  return { record, onRecord };
}

// Reading the audit log is separate from writing it because reads need the
// authorizer, which itself writes to the audit log.
export function createAuditQueryService({ db, authorize }) {
  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.AUDIT_READ);
    const q = db('audit_logs').select('*');
    if (query.action) q.where('action', 'like', `${query.action.replace(/[\\%_]/g, '\\$&')}%`);
    if (query.actorId) q.where('actor_id', query.actorId);
    if (query.targetType) q.where('target_type', query.targetType);
    if (query.targetId) q.where('target_id', query.targetId);
    if (query.result) q.where('result', query.result);
    if (query.from) q.where('occurred_at', '>=', new Date(query.from));
    if (query.to) q.where('occurred_at', '<=', new Date(query.to));
    const { rows, pagination } = await paginate(q, query, { occurredAt: 'occurred_at' });
    return { items: rows.map(toPublicAuditEntry), pagination };
  }

  return { list };
}

function truncate(value, max) {
  if (value === null || value === undefined) return null;
  const s = String(value);
  return s.length > max ? s.slice(0, max) : s;
}
