import { randomUUID } from 'node:crypto';
import { PERMISSIONS } from '@vaultpanel/shared';
import { toPublicMetric, toPublicServer } from '../models/serverModel.js';
import { compareVersions, LATEST_AGENT_VERSION } from '../utils/agentPackage.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { toIso } from '../utils/time.js';

// Server groups (phase 7): named sets of servers ("Production", "EU") used to
// filter the server list, see a group's health at a glance and run bulk
// actions on every server in it. A server can be in several groups.
export function createServerGroupService({ db, audit, authorize, metrics: metricStore }) {
  async function list(actor) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const groups = await db('server_groups').orderBy('name').select('*');
    const members = await memberRows(groups.map((g) => g.id));
    const health = await healthByServer(members.map((m) => m.id));
    return {
      items: groups.map((g) => {
        const servers = members.filter((m) => m.group_id === g.id);
        return {
          ...toPublicGroup(g),
          servers: servers.map((s) => ({ id: s.id, name: s.name, status: s.status })),
          summary: summarize(servers, health),
        };
      }),
    };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const group = await findGroup(id);
    const members = await memberRows([id]);
    const ids = members.map((m) => m.id);
    const [health, latest] = await Promise.all([healthByServer(ids), metricStore.latest(ids)]);
    return {
      ...toPublicGroup(group),
      servers: members.map((row) => ({
        ...toPublicServer(row),
        latestMetrics: toPublicMetric(latest[row.id]),
        firingAlerts: health[row.id]?.firing ?? 0,
        agentOutdated: agentOutdated(row),
      })),
      summary: summarize(members, health),
    };
  }

  async function create(actor, { name, description = '', color = 'blue', serverIds = [] }) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    await assertNameFree(name);
    const servers = await loadServers(serverIds);
    const id = randomUUID();
    await db.transaction(async (trx) => {
      await trx('server_groups').insert({ id, name, description, color, created_by: actor.type === 'user' ? actor.id : null });
      if (servers.length) await trx('server_group_members').insert(servers.map((s) => ({ group_id: id, server_id: s.id })));
    });
    await audit.record({ actor, action: 'server_group.create', target: target({ id, name }), metadata: { servers: servers.length } });
    return get(actor, id);
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const group = await findGroup(id);
    if (changes.name !== undefined && changes.name !== group.name) await assertNameFree(changes.name, id);
    const servers = changes.serverIds ? await loadServers(changes.serverIds) : null;
    const fields = {};
    for (const key of ['name', 'description', 'color']) if (changes[key] !== undefined) fields[key] = changes[key];
    await db.transaction(async (trx) => {
      if (Object.keys(fields).length) await trx('server_groups').where({ id }).update({ ...fields, updated_at: new Date() });
      if (servers) {
        await trx('server_group_members').where({ group_id: id }).delete();
        if (servers.length) await trx('server_group_members').insert(servers.map((s) => ({ group_id: id, server_id: s.id })));
      }
    });
    await audit.record({
      actor,
      action: 'server_group.update',
      target: target({ id, name: fields.name ?? group.name }),
      metadata: { ...fields, ...(servers ? { servers: servers.length } : {}) },
    });
    return get(actor, id);
  }

  // Deletes the group only; its servers and past bulk actions stay.
  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const group = await findGroup(id);
    await db('server_groups').where({ id }).delete();
    await audit.record({ actor, action: 'server_group.delete', target: target(group) });
  }

  // Sets the groups one server is in (from the server's own page).
  async function setServerGroups(actor, serverId, groupIds) {
    await authorize(actor, PERMISSIONS.SERVERS_MANAGE);
    const [server] = await loadServers([serverId]);
    const groups = groupIds.length ? await db('server_groups').whereIn('id', groupIds).select('id', 'name') : [];
    if (groups.length !== new Set(groupIds).size) throw notFound('One of the groups was not found');
    await db.transaction(async (trx) => {
      await trx('server_group_members').where({ server_id: serverId }).delete();
      if (groups.length) await trx('server_group_members').insert(groups.map((g) => ({ group_id: g.id, server_id: serverId })));
    });
    await audit.record({
      actor,
      action: 'server.groups_update',
      target: { type: 'server', id: serverId, label: server.name },
      metadata: { groups: groups.map((g) => g.name) },
    });
    return groupsForServers([serverId]).then((byServer) => byServer[serverId] ?? []);
  }

  // { serverId: [{ id, name, color }] } for server lists and pages.
  async function groupsForServers(serverIds) {
    if (!serverIds.length) return {};
    const rows = await db('server_group_members as m')
      .join('server_groups as g', 'g.id', 'm.group_id')
      .whereIn('m.server_id', serverIds)
      .orderBy('g.name')
      .select('m.server_id', 'g.id', 'g.name', 'g.color');
    const out = {};
    for (const r of rows) (out[r.server_id] ??= []).push({ id: r.id, name: r.name, color: r.color });
    return out;
  }

  // The servers in a group, for bulk actions. Removed servers are left out.
  async function serverIdsInGroup(groupId) {
    const group = await findGroup(groupId);
    const rows = await db('server_group_members as m')
      .join('servers as s', 's.id', 'm.server_id')
      .where('m.group_id', groupId)
      .whereNull('s.deleted_at')
      .orderBy('s.name')
      .select('s.id');
    return { group, serverIds: rows.map((r) => r.id) };
  }

  async function findGroup(id) {
    const group = await db('server_groups').where({ id }).first();
    if (!group) throw notFound('Server group not found');
    return group;
  }

  async function assertNameFree(name, exceptId = null) {
    const q = db('server_groups').where({ name });
    if (exceptId) q.whereNot({ id: exceptId });
    if (await q.first('id')) throw new AppError(409, 'GROUP_EXISTS', `A group called "${name}" already exists`);
  }

  async function loadServers(ids) {
    const unique = [...new Set(ids)];
    if (!unique.length) return [];
    const rows = await db('servers').whereIn('id', unique).whereNull('deleted_at').select('id', 'name');
    if (rows.length !== unique.length) throw validationError([{ field: 'serverIds', message: 'One of the servers was not found' }]);
    return rows;
  }

  function memberRows(groupIds) {
    if (!groupIds.length) return [];
    return db('server_group_members as m')
      .join('servers as s', 's.id', 'm.server_id')
      .whereIn('m.group_id', groupIds)
      .whereNull('s.deleted_at')
      .orderBy('s.name')
      .select('s.*', 'm.group_id');
  }

  // Latest metrics and firing alerts per server.
  async function healthByServer(serverIds) {
    const ids = [...new Set(serverIds)];
    if (!ids.length) return {};
    const [latest, firing] = await Promise.all([
      metricStore.latest(ids),
      db('alert_events').whereIn('server_id', ids).where({ status: 'firing' }).groupBy('server_id').select('server_id').count({ n: '*' }),
    ]);
    const out = Object.fromEntries(ids.map((id) => [id, { metric: latest[id] ? toPublicMetric(latest[id]) : null, firing: 0 }]));
    for (const row of firing) out[row.server_id].firing = Number(row.n);
    return out;
  }

  return { list, get, create, update, remove, setServerGroups, groupsForServers, serverIdsInGroup };
}

// Counts and averages over a group's servers. Averages only use servers that
// are online and have reported metrics.
export function summarize(servers, health) {
  const byStatus = { online: 0, offline: 0, pending: 0, disabled: 0 };
  const usage = { cpu: [], memory: [], disk: [] };
  let firingAlerts = 0;
  let agentsOutdated = 0;
  for (const s of servers) {
    byStatus[s.status] = (byStatus[s.status] ?? 0) + 1;
    const h = health[s.id];
    firingAlerts += h?.firing ?? 0;
    if (agentOutdated(s)) agentsOutdated += 1;
    const m = h?.metric;
    if (s.status !== 'online' || !m) continue;
    if (m.cpuPercent !== null) usage.cpu.push(m.cpuPercent);
    if (m.memoryTotalBytes) usage.memory.push((m.memoryUsedBytes / m.memoryTotalBytes) * 100);
    if (m.diskTotalBytes) usage.disk.push((m.diskUsedBytes / m.diskTotalBytes) * 100);
  }
  const avg = (list) => (list.length ? Math.round((list.reduce((a, b) => a + b, 0) / list.length) * 10) / 10 : null);
  const max = (list) => (list.length ? Math.round(Math.max(...list) * 10) / 10 : null);
  return {
    total: servers.length,
    ...byStatus,
    firingAlerts,
    agentsOutdated,
    cpu: { average: avg(usage.cpu), max: max(usage.cpu) },
    memory: { average: avg(usage.memory), max: max(usage.memory) },
    disk: { average: avg(usage.disk), max: max(usage.disk) },
  };
}

export function agentOutdated(server) {
  return Boolean(server.agent_version && LATEST_AGENT_VERSION && compareVersions(server.agent_version, LATEST_AGENT_VERSION) < 0);
}

function toPublicGroup(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    color: row.color,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function target(group) {
  return { type: 'server_group', id: group.id, label: group.name };
}
