import { PERMISSIONS, ROUTINE_OPERATION_TYPES } from '@vaultpanel/shared';
import { toPublicAuditEntry } from '../models/auditModel.js';
import { toPublicJob } from '../models/jobModel.js';

export function createDashboardService({ db, authorize, alerts, websites, applications, databases, backups, cron }) {
  async function summary(actor) {
    await authorize(actor, PERMISSIONS.DASHBOARD_VIEW);
    const can = (p) => actor.permissions.includes(p);
    const result = { servers: null, websites: null, applications: null, databases: null, backups: null, cron: null, jobs: null, recentJobs: null, recentActivity: null, users: null, alerts: null };

    if (can(PERMISSIONS.SERVERS_READ)) {
      const rows = await db('servers').whereNull('deleted_at').select('status').count({ n: '*' }).groupBy('status');
      const byStatus = { pending: 0, online: 0, offline: 0, disabled: 0 };
      for (const r of rows) byStatus[r.status] = Number(r.n);
      result.servers = { total: Object.values(byStatus).reduce((a, b) => a + b, 0), byStatus };
    }
    if (can(PERMISSIONS.WEBSITES_READ)) {
      result.websites = await websites.summary();
    }
    if (can(PERMISSIONS.APPS_READ)) {
      result.applications = await applications.summary();
    }
    if (can(PERMISSIONS.DATABASES_READ)) {
      result.databases = await databases.summary();
    }
    if (can(PERMISSIONS.BACKUPS_READ)) {
      result.backups = await backups.summary();
    }
    if (can(PERMISSIONS.CRON_READ)) {
      result.cron = await cron.summary();
    }
    if (can(PERMISSIONS.JOBS_READ)) {
      const since = new Date(Date.now() - 86_400_000);
      const rows = await db('jobs').where('created_at', '>=', since).select('status').count({ n: '*' }).groupBy('status');
      result.jobs = { last24h: Object.fromEntries(rows.map((r) => [r.status, Number(r.n)])) };
      const recent = await db('jobs as j')
        .leftJoin('servers as s', 's.id', 'j.server_id')
        .leftJoin('users as u', 'u.id', 'j.requested_by')
        .select('j.*', 's.name as server_name', 'u.email as requested_by_email')
        .whereNotIn('j.type', ROUTINE_OPERATION_TYPES)
        .orderBy('j.created_at', 'desc')
        .limit(6);
      result.recentJobs = recent.map(toPublicJob);
    }
    if (can(PERMISSIONS.AUDIT_READ)) {
      const rows = await db('audit_logs').orderBy('id', 'desc').limit(8);
      result.recentActivity = rows.map(toPublicAuditEntry);
    }
    if (can(PERMISSIONS.ALERTS_READ)) {
      result.alerts = await alerts.summary(actor);
    }
    if (can(PERMISSIONS.USERS_READ)) {
      const row = await db('users').whereNull('deleted_at').where({ is_active: true }).count({ n: '*' }).first();
      result.users = { active: Number(row.n) };
    }
    return result;
  }
  return { summary };
}
