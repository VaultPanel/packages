import { randomInt, randomUUID } from 'node:crypto';
import { RECOVERY_CODE_COUNT, twoFactorRequiredFor } from '@vaultpanel/shared';
import { findUserByEmail, findUserById, normalizeEmail, toPublicUser } from '../models/userModel.js';
import { AppError, badRequest, unauthenticated, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey, hmacHex, newToken, safeEqual, sha256Hex } from '../utils/crypto.js';
import { burnPasswordCheck, hashPassword, verifyPassword } from '../utils/password.js';
import { generateTotpSecret, matchTotp, otpauthUrl } from '../utils/totp.js';
import { addMinutes } from '../utils/time.js';
import { getSetting } from '../models/settingModel.js';
import { anonymousActor, userActor } from './actor.js';
import { TWO_FACTOR_POLICY_SETTING } from './securityService.js';

export const MAX_FAILED_LOGINS = 5;
export const LOCKOUT_MINUTES = 15;
const CHALLENGE_TTL_MS = 5 * 60_000;
const LOGIN_LINK_TTL_MS = 2 * 60_000;
const SESSION_TOUCH_INTERVAL_MS = 5 * 60_000;
const POLICY_CACHE_MS = 10_000;
// Recovery codes avoid characters that are easy to misread (0/o, 1/l/i).
const RECOVERY_ALPHABET = 'abcdefghjkmnpqrstuvwxyz23456789';

export function createAuthService({ db, config, logger, audit, accessControl, panelAccess = null }) {
  const totpBox = createSecretBox(deriveKey(config.secretKey, 'totp-secrets'));
  const csrfKey = deriveKey(config.secretKey, 'csrf');
  const challengeKey = deriveKey(config.secretKey, 'login-challenge');
  const recoveryKey = deriveKey(config.secretKey, 'recovery-codes');
  let policyCache = { at: 0, value: 'off' };

  // One-time setup token required to create the first owner, so a freshly
  // started panel cannot be claimed by whoever reaches it first.
  let setupToken = process.env.VAULTPANEL_SETUP_TOKEN || null;

  async function needsSetup() {
    const row = await db('users').count({ n: '*' }).first();
    return Number(row.n) === 0;
  }

  // Makes sure a setup token exists while the panel has no accounts, and logs
  // it when it is created (or on every call with { log: true }, used at startup).
  async function ensureSetupToken({ log = false } = {}) {
    if (!(await needsSetup())) return null;
    const created = !setupToken;
    if (created) setupToken = newToken(18);
    if (created || log) {
      logger.warn(
        { setupUrl: `${config.publicUrl}/setup` },
        `No accounts exist yet. Create the owner account at /setup with setup token: ${setupToken}`,
      );
    }
    return setupToken;
  }

  async function setupOwner({ setupToken: provided, name, email, password }, meta) {
    await ensureSetupToken();
    if (!setupToken || !safeEqual(provided, setupToken)) {
      throw new AppError(403, 'INVALID_SETUP_TOKEN', 'The setup token is not valid. Find it in the panel logs.');
    }
    const id = randomUUID();
    const passwordHash = await hashPassword(password);
    await db.transaction(async (trx) => {
      // Lock the users table range so two setup requests cannot both succeed.
      const existing = await trx('users').forUpdate().count({ n: '*' }).first();
      if (Number(existing.n) > 0) throw new AppError(409, 'ALREADY_SET_UP', 'The panel already has an owner');
      const now = new Date();
      await trx('users').insert({
        id,
        email: normalizeEmail(email),
        name,
        password_hash: passwordHash,
        password_changed_at: now,
      });
      await trx('user_roles').insert({ user_id: id, role_id: await accessControl.roleIdByName('owner', trx) });
    });
    setupToken = process.env.VAULTPANEL_SETUP_TOKEN || null;
    const user = await findUserById(db, id);
    await audit.record({
      actor: { ...anonymousActor(meta), type: 'user', id, label: user.email },
      action: 'auth.setup_owner',
      target: { type: 'user', id, label: user.email },
    });
    return startSession(user, meta);
  }

  async function login({ email, password }, meta) {
    const user = await findUserByEmail(db, email);
    const failActor = anonymousActor(meta, normalizeEmail(email));
    if (!user || !user.is_active) {
      await burnPasswordCheck(password);
      await audit.record({ actor: failActor, action: 'auth.login', result: 'failure', metadata: { reason: 'unknown_or_inactive' } });
      throw invalidCredentials();
    }
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      await burnPasswordCheck(password);
      await audit.record({ actor: failActor, action: 'auth.login', result: 'failure', target: userTarget(user), metadata: { reason: 'locked' } });
      throw new AppError(429, 'ACCOUNT_LOCKED', 'Too many failed sign-in attempts. Try again later.');
    }
    if (!(await verifyPassword(password, user.password_hash))) {
      await registerFailure(user);
      await audit.record({ actor: failActor, action: 'auth.login', result: 'failure', target: userTarget(user), metadata: { reason: 'bad_password' } });
      throw invalidCredentials();
    }
    await refuseBlocked(user, failActor);
    if (user.totp_enabled) {
      return { twoFactorRequired: true, challengeToken: issueChallenge(user.id) };
    }
    return completeLogin(user, meta, 'password');
  }

  // The second step: a code from the authenticator app, or one of the
  // account's recovery codes (each works once).
  async function completeTwoFactor({ challengeToken, code, recoveryCode }, meta) {
    const userId = readChallenge(challengeToken);
    const user = userId ? await findUserById(db, userId) : null;
    if (!user || !user.is_active || !user.totp_enabled) throw unauthenticated('Sign-in expired, start again');
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new AppError(429, 'ACCOUNT_LOCKED', 'Too many failed sign-in attempts. Try again later.');
    }
    const ok = recoveryCode ? await consumeRecoveryCode(user, recoveryCode) : await consumeTotp(user, code);
    if (!ok) {
      await registerFailure(user);
      await audit.record({
        actor: anonymousActor(meta, user.email),
        action: 'auth.login',
        result: 'failure',
        target: userTarget(user),
        metadata: { reason: recoveryCode ? 'bad_recovery_code' : 'bad_totp' },
      });
      throw new AppError(401, 'INVALID_CODE', recoveryCode ? 'That recovery code is not valid or was already used' : 'That code is not valid');
    }
    await refuseBlocked(user, anonymousActor(meta, user.email));
    const session = await completeLogin(user, meta, recoveryCode ? 'password+recovery_code' : 'password+totp');
    if (recoveryCode) session.recoveryCodesLeft = await recoveryCodesLeft(user.id);
    return session;
  }

  async function completeLogin(user, meta, method) {
    await db('users').where({ id: user.id }).update({
      failed_login_count: 0,
      locked_until: null,
      last_login_at: new Date(),
      last_login_ip: meta.ip ?? null,
    });
    const result = await startSession(user, meta);
    await audit.record({
      actor: { ...anonymousActor(meta), type: 'user', id: user.id, label: user.email },
      action: 'auth.login',
      target: userTarget(user),
      metadata: { method },
    });
    return result;
  }

  // A hosting customer whose account is suspended or removed cannot sign in.
  // Said only after the right password, so it reveals nothing to strangers.
  // So is someone signing in from an address the panel does not accept.
  async function refuseBlocked(user, failActor) {
    const access = await accessControl.getUserAccess(user.id);
    if (panelAccess && !(await panelAccess.allows(failActor.ip, { customer: Boolean(access.customer) }))) {
      await audit.record({ actor: failActor, action: 'auth.login', result: 'failure', target: userTarget(user), metadata: { reason: 'address_not_allowed' } });
      throw panelAccess.refused(failActor.ip);
    }
    if (!access.blocked) return;
    await audit.record({ actor: failActor, action: 'auth.login', result: 'failure', target: userTarget(user), metadata: { reason: `customer_${access.blocked}` } });
    throw new AppError(
      403,
      'ACCOUNT_SUSPENDED',
      access.blocked === 'suspended'
        ? 'Your hosting account is suspended. Contact your provider.'
        : access.blocked === 'terminated'
          ? 'This hosting account was closed.'
          : 'This account is not set up for sign-in.',
    );
  }

  async function registerFailure(user) {
    const failures = user.failed_login_count + 1;
    const update = { failed_login_count: failures };
    if (failures >= MAX_FAILED_LOGINS) {
      update.locked_until = addMinutes(new Date(), LOCKOUT_MINUTES);
      update.failed_login_count = 0;
    }
    await db('users').where({ id: user.id }).update(update);
  }

  async function startSession(user, meta) {
    const token = newToken();
    const sessionId = randomUUID();
    const expiresAt = new Date(Date.now() + config.sessionTtlHours * 3600_000);
    await db('sessions').insert({
      id: sessionId,
      user_id: user.id,
      token_hash: sha256Hex(token),
      ip: meta.ip ?? null,
      user_agent: meta.userAgent?.slice(0, 512) ?? null,
      expires_at: expiresAt,
    });
    const access = await accessControl.getUserAccess(user.id);
    const fresh = await findUserById(db, user.id);
    return {
      token,
      expiresAt,
      sessionId,
      csrfToken: csrfTokenFor(sessionId),
      user: toPublicUser(fresh, access.roles),
      permissions: access.permissions,
      customer: access.customer,
      twoFactorSetupRequired: !fresh.totp_enabled && twoFactorRequiredFor(await twoFactorPolicy(), access.roles),
    };
  }

  // Resolves a session cookie to an actor, or null if the session is not valid.
  async function resolveSession(token, meta) {
    if (!token || token.length > 200) return null;
    const session = await db('sessions')
      .where({ token_hash: sha256Hex(token) })
      .whereNull('revoked_at')
      .where('expires_at', '>', new Date())
      .first();
    if (!session) return null;
    const user = await findUserById(db, session.user_id);
    if (!user || !user.is_active) return null;
    if (Date.now() - new Date(session.last_seen_at).getTime() > SESSION_TOUCH_INTERVAL_MS) {
      await db('sessions').where({ id: session.id }).update({ last_seen_at: new Date() });
    }
    const access = await accessControl.getUserAccess(user.id);
    // A suspended or removed hosting account is signed out at once.
    if (access.blocked) return null;
    const actor = userActor(user, access, { ...meta, sessionId: session.id });
    // The two-factor policy applies to accounts without it: until they turn
    // it on, they can only reach their account settings.
    if (!user.totp_enabled && twoFactorRequiredFor(await twoFactorPolicy(), access.roles)) actor.twoFactorSetupRequired = true;
    return { user, access, actor };
  }

  async function twoFactorPolicy() {
    if (Date.now() - policyCache.at > POLICY_CACHE_MS) {
      policyCache = { at: Date.now(), value: (await getSetting(db, TWO_FACTOR_POLICY_SETTING)) ?? 'off' };
    }
    return policyCache.value;
  }

  async function logout(actor) {
    await db('sessions').where({ id: actor.sessionId }).update({ revoked_at: new Date() });
    await audit.record({ actor, action: 'auth.logout', target: { type: 'user', id: actor.id, label: actor.label } });
  }

  async function me(actor) {
    // A plugin's own token has no person behind it.
    if (actor.type === 'plugin') {
      return {
        user: null,
        plugin: { id: actor.pluginId, slug: actor.pluginSlug, name: actor.tokenName, scopes: actor.tokenScopes },
        permissions: actor.permissions,
        customer: null,
        csrfToken: null,
        apiToken: null,
        twoFactorSetupRequired: false,
        recoveryCodesLeft: null,
      };
    }
    const user = await findUserById(db, actor.id);
    return {
      user: toPublicUser(user, actor.roles),
      permissions: actor.permissions,
      customer: actor.customerId ? { id: actor.customerId } : null,
      // A request made with an API token has no session and so no CSRF token;
      // it reports which token it used instead (the CLI's "whoami").
      csrfToken: actor.tokenId ? null : csrfTokenFor(actor.sessionId),
      apiToken: actor.tokenId ? { id: actor.tokenId, name: actor.tokenName, scopes: actor.tokenScopes } : null,
      twoFactorSetupRequired: Boolean(actor.twoFactorSetupRequired),
      recoveryCodesLeft: user.totp_enabled ? await recoveryCodesLeft(user.id) : null,
    };
  }

  async function changePassword(actor, { currentPassword, newPassword }) {
    const user = await findUserById(db, actor.id);
    if (!(await verifyPassword(currentPassword, user.password_hash))) {
      await audit.record({ actor, action: 'auth.password_change', result: 'failure', target: userTarget(user) });
      throw validationError([{ field: 'currentPassword', message: 'Current password is incorrect' }]);
    }
    await db.transaction(async (trx) => {
      await trx('users')
        .where({ id: user.id })
        .update({ password_hash: await hashPassword(newPassword), password_changed_at: new Date() });
      // Sign out every other session; the current one stays.
      await trx('sessions')
        .where({ user_id: user.id })
        .whereNot({ id: actor.sessionId })
        .whereNull('revoked_at')
        .update({ revoked_at: new Date() });
    });
    await audit.record({ actor, action: 'auth.password_change', target: userTarget(user) });
  }

  async function beginTotpSetup(actor) {
    const user = await findUserById(db, actor.id);
    if (user.totp_enabled) throw new AppError(409, 'TWO_FACTOR_ALREADY_ENABLED', 'Two-factor sign-in is already on');
    const secret = generateTotpSecret();
    await db('users').where({ id: user.id }).update({ totp_secret_encrypted: totpBox.seal(secret) });
    return { secret, otpauthUrl: otpauthUrl(secret, user.email) };
  }

  async function enableTotp(actor, { code }) {
    const user = await findUserById(db, actor.id);
    if (user.totp_enabled) throw new AppError(409, 'TWO_FACTOR_ALREADY_ENABLED', 'Two-factor sign-in is already on');
    if (!user.totp_secret_encrypted) throw badRequest('Start two-factor setup first');
    if (!(await consumeTotp(user, code, { allowPending: true }))) {
      throw validationError([{ field: 'code', message: 'That code is not valid' }]);
    }
    await db('users').where({ id: user.id }).update({ totp_enabled: true });
    policyCache.at = 0;
    const recoveryCodes = await replaceRecoveryCodes(user.id);
    await audit.record({ actor, action: 'auth.2fa_enable', target: userTarget(user) });
    return { recoveryCodes };
  }

  async function disableTotp(actor, { password, code }) {
    const user = await findUserById(db, actor.id);
    if (!user.totp_enabled) throw badRequest('Two-factor sign-in is not on');
    const passwordOk = await verifyPassword(password, user.password_hash);
    const codeOk = passwordOk && (await consumeTotp(user, code));
    if (!passwordOk || !codeOk) {
      await audit.record({ actor, action: 'auth.2fa_disable', result: 'failure', target: userTarget(user) });
      throw validationError([{ field: passwordOk ? 'code' : 'password', message: 'Incorrect' }]);
    }
    await db.transaction(async (trx) => {
      await trx('users').where({ id: user.id }).update({ totp_enabled: false, totp_secret_encrypted: null, totp_last_step: null });
      await trx('user_recovery_codes').where({ user_id: user.id }).delete();
    });
    await audit.record({ actor, action: 'auth.2fa_disable', target: userTarget(user) });
  }

  // ---- Recovery codes ---------------------------------------------------------

  function recoveryHash(code) {
    return hmacHex(recoveryKey, String(code).toLowerCase().replace(/[^a-z0-9]/g, ''));
  }

  function newRecoveryCode() {
    let text = '';
    for (let i = 0; i < 10; i += 1) text += RECOVERY_ALPHABET[randomInt(RECOVERY_ALPHABET.length)];
    return `${text.slice(0, 5)}-${text.slice(5)}`;
  }

  async function replaceRecoveryCodes(userId) {
    const codes = Array.from({ length: RECOVERY_CODE_COUNT }, newRecoveryCode);
    await db.transaction(async (trx) => {
      await trx('user_recovery_codes').where({ user_id: userId }).delete();
      await trx('user_recovery_codes').insert(codes.map((code) => ({ id: randomUUID(), user_id: userId, code_hash: recoveryHash(code) })));
    });
    return codes;
  }

  async function consumeRecoveryCode(user, code) {
    const used = await db('user_recovery_codes')
      .where({ user_id: user.id, code_hash: recoveryHash(code) })
      .whereNull('used_at')
      .update({ used_at: new Date() });
    return used >= 1;
  }

  async function recoveryCodesLeft(userId) {
    const row = await db('user_recovery_codes').where({ user_id: userId }).whereNull('used_at').count({ n: '*' }).first();
    return Number(row.n);
  }

  // New codes replace all the old ones. Needs the password and a current
  // code, like turning two-factor sign-in off.
  async function regenerateRecoveryCodes(actor, { password, code }) {
    const user = await findUserById(db, actor.id);
    if (!user.totp_enabled) throw badRequest('Two-factor sign-in is not on');
    const passwordOk = await verifyPassword(password, user.password_hash);
    const codeOk = passwordOk && (await consumeTotp(user, code));
    if (!passwordOk || !codeOk) {
      await audit.record({ actor, action: 'auth.recovery_codes_regenerate', result: 'failure', target: userTarget(user) });
      throw validationError([{ field: passwordOk ? 'code' : 'password', message: 'Incorrect' }]);
    }
    const recoveryCodes = await replaceRecoveryCodes(user.id);
    await audit.record({ actor, action: 'auth.recovery_codes_regenerate', target: userTarget(user) });
    return { recoveryCodes };
  }

  // ---- Sessions -------------------------------------------------------------------

  function toPublicSession(row, currentId) {
    return {
      id: row.id,
      ip: row.ip,
      userAgent: row.user_agent,
      createdAt: row.created_at ? new Date(row.created_at).toISOString() : null,
      lastSeenAt: row.last_seen_at ? new Date(row.last_seen_at).toISOString() : null,
      expiresAt: row.expires_at ? new Date(row.expires_at).toISOString() : null,
      current: row.id === currentId,
      ...(row.email ? { user: { id: row.user_id, email: row.email, name: row.name } } : {}),
    };
  }

  function activeSessions() {
    return db('sessions as s').whereNull('s.revoked_at').where('s.expires_at', '>', new Date()).orderBy('s.last_seen_at', 'desc');
  }

  async function listSessions(actor) {
    const rows = await activeSessions().where('s.user_id', actor.id).select('s.*').limit(200);
    return { items: rows.map((r) => toPublicSession(r, actor.sessionId)) };
  }

  async function revokeSession(actor, id) {
    if (id === actor.sessionId) throw badRequest('Use Sign out to end the session you are using');
    const updated = await db('sessions').where({ id, user_id: actor.id }).whereNull('revoked_at').update({ revoked_at: new Date() });
    if (!updated) throw new AppError(404, 'NOT_FOUND', 'Session not found');
    await audit.record({ actor, action: 'auth.session_revoke', target: { type: 'user', id: actor.id, label: actor.label }, metadata: { sessionId: id } });
  }

  async function revokeOtherSessions(actor) {
    const count = await db('sessions').where({ user_id: actor.id }).whereNot({ id: actor.sessionId }).whereNull('revoked_at').update({ revoked_at: new Date() });
    await audit.record({ actor, action: 'auth.session_revoke_others', target: { type: 'user', id: actor.id, label: actor.label }, metadata: { count } });
    return { count };
  }

  // Checks a code and records its time step so the same code cannot be reused.
  async function consumeTotp(user, code, { allowPending = false } = {}) {
    if (!user.totp_secret_encrypted || (!user.totp_enabled && !allowPending)) return false;
    let secret;
    try {
      secret = totpBox.open(user.totp_secret_encrypted);
    } catch (err) {
      logger.error({ err, userId: user.id }, 'cannot decrypt TOTP secret (was VAULTPANEL_SECRET_KEY changed?)');
      return false;
    }
    const step = matchTotp(secret, code);
    if (step === null) return false;
    const updated = await db('users')
      .where({ id: user.id })
      .where((q) => q.whereNull('totp_last_step').orWhere('totp_last_step', '<', step))
      .update({ totp_last_step: step });
    return updated === 1;
  }

  async function inspectResetToken(token) {
    const row = await findResetToken(token);
    if (!row) throw new AppError(400, 'INVALID_RESET_TOKEN', 'This link is invalid or has expired');
    const user = await findUserById(db, row.user_id);
    return { email: user.email, name: user.name, purpose: row.purpose };
  }

  async function resetPassword({ token, password }, meta) {
    const row = await findResetToken(token);
    if (!row) throw new AppError(400, 'INVALID_RESET_TOKEN', 'This link is invalid or has expired');
    const user = await findUserById(db, row.user_id);
    await db.transaction(async (trx) => {
      const used = await trx('password_reset_tokens')
        .where({ id: row.id })
        .whereNull('used_at')
        .update({ used_at: new Date() });
      if (used !== 1) throw new AppError(400, 'INVALID_RESET_TOKEN', 'This link has already been used');
      await trx('users').where({ id: user.id }).update({
        password_hash: await hashPassword(password),
        password_changed_at: new Date(),
        failed_login_count: 0,
        locked_until: null,
      });
      await trx('sessions').where({ user_id: user.id }).whereNull('revoked_at').update({ revoked_at: new Date() });
    });
    await audit.record({
      actor: { ...anonymousActor(meta), type: 'user', id: user.id, label: user.email },
      action: row.purpose === 'invite' ? 'auth.invite_accept' : 'auth.password_reset',
      target: userTarget(user),
    });
  }

  // Invite and reset links only: a sign-in link never sets a password.
  function findResetToken(token) {
    if (!token || token.length > 200) return null;
    return db('password_reset_tokens')
      .where({ token_hash: sha256Hex(token) })
      .whereIn('purpose', ['invite', 'reset'])
      .whereNull('used_at')
      .where('expires_at', '>', new Date())
      .first();
  }

  // A one-time sign-in link a billing system opens for its customer ("Log in
  // to VaultPanel" in WHMCS). It works once, for two minutes, and goes
  // through the same checks as a password sign-in except the second factor:
  // whoever holds the billing API key can already set the password.
  async function issueLoginLink(userId) {
    const token = newToken();
    const expiresAt = new Date(Date.now() + LOGIN_LINK_TTL_MS);
    await db('password_reset_tokens').insert({ id: randomUUID(), user_id: userId, token_hash: sha256Hex(token), purpose: 'login', created_by: null, expires_at: expiresAt });
    return { url: `${config.publicUrl}/sso#token=${token}`, expiresAt };
  }

  async function loginWithLink({ token }, meta) {
    const expired = () => new AppError(401, 'LOGIN_LINK_INVALID', 'This sign-in link expired or was already used. Open VaultPanel again from your billing account.');
    if (!token || token.length > 200) throw expired();
    const row = await db('password_reset_tokens')
      .where({ token_hash: sha256Hex(token), purpose: 'login' })
      .whereNull('used_at')
      .where('expires_at', '>', new Date())
      .first();
    // Used once, even when two requests race for it.
    const claimed = row ? await db('password_reset_tokens').where({ id: row.id }).whereNull('used_at').update({ used_at: new Date() }) : 0;
    if (!claimed) throw expired();
    const user = await findUserById(db, row.user_id);
    if (!user || !user.is_active) throw expired();
    await refuseBlocked(user, anonymousActor(meta, user.email));
    return completeLogin(user, meta, 'billing_link');
  }

  // The CSRF token is bound to the session: HMAC(session id). Nothing to store.
  function csrfTokenFor(sessionId) {
    return hmacHex(csrfKey, sessionId);
  }

  function verifyCsrf(sessionId, provided) {
    return Boolean(provided) && safeEqual(provided, csrfTokenFor(sessionId));
  }

  function issueChallenge(userId) {
    const payload = `${userId}.${Date.now() + CHALLENGE_TTL_MS}.${newToken(9)}`;
    return `${Buffer.from(payload).toString('base64url')}.${hmacHex(challengeKey, payload)}`;
  }

  function readChallenge(token) {
    const [encoded, mac] = String(token ?? '').split('.');
    if (!encoded || !mac) return null;
    const payload = Buffer.from(encoded, 'base64url').toString();
    if (!safeEqual(mac, hmacHex(challengeKey, payload))) return null;
    const [userId, expires] = payload.split('.');
    return Number(expires) > Date.now() ? userId : null;
  }

  return {
    needsSetup,
    ensureSetupToken,
    setupOwner,
    login,
    completeTwoFactor,
    resolveSession,
    logout,
    me,
    changePassword,
    beginTotpSetup,
    enableTotp,
    disableTotp,
    regenerateRecoveryCodes,
    listSessions,
    revokeSession,
    revokeOtherSessions,
    inspectResetToken,
    resetPassword,
    issueLoginLink,
    loginWithLink,
    verifyCsrf,
    // Called when the two-factor policy changes, so it applies at once.
    invalidatePolicy: () => {
      policyCache.at = 0;
    },
  };
}

function invalidCredentials() {
  return new AppError(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect');
}

function userTarget(user) {
  return { type: 'user', id: user.id, label: user.email };
}
