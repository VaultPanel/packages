import { randomBytes, randomUUID } from 'node:crypto';
import { PERMISSIONS } from '@vaultpanel/shared';
import { AppError, forbidden, notFound } from '../utils/errors.js';
import { compareVersions } from '../utils/agentPackage.js';

// The server terminal (agent 0.11.0 and later).
//
// A terminal is a root shell, so it is not one of the allow-listed
// operations: it is its own channel. Each agent keeps one WebSocket open to
// the panel (an "agent link"). An owner asks for a terminal with a normal API
// request (session cookie and CSRF token), gets a one-time ticket, and opens
// a WebSocket with it; the panel then asks the agent for a shell with an
// envelope signed by its key and passes bytes both ways. Opening and closing
// are written to the audit log; what is typed is not recorded.
//
// The links and sessions live in the API process's memory.

export const TERMINAL_MIN_AGENT_VERSION = '0.11.0';
export const MAX_SESSIONS_PER_SERVER = 5;
export const MAX_SESSIONS_PER_USER = 10;
const TICKET_TTL_MS = 30_000;
const OPEN_TIMEOUT_MS = 20_000;
const ENVELOPE_VALIDITY_MS = 60_000;
const PING_MS = 30_000;
const RECHECK_MS = 60_000;
// Output waiting for a slow browser: past the high mark the agent pauses the
// shell's output until the browser catches up.
const HIGH_WATER = 1024 * 1024;
const LOW_WATER = 128 * 1024;
const MAX_INPUT = 64 * 1024;

export function createTerminalService({ db, logger, audit, authorize, signing, accessControl, recordings = null, now = () => Date.now() }) {
  const links = new Map(); // serverId -> link
  const sessions = new Map(); // sessionId -> session
  const tickets = new Map(); // ticket -> pending request
  let timers = [];

  function start() {
    if (timers.length) return;
    timers = [
      setInterval(() => {
        for (const link of links.values()) link.channel.send({ type: 'ping' });
        const t = now();
        for (const [key, ticket] of tickets) if (ticket.expiresAt < t) tickets.delete(key);
      }, PING_MS),
      setInterval(() => recheckAll().catch((err) => logger.warn({ err }, 'terminal recheck failed')), RECHECK_MS),
    ];
    for (const timer of timers) timer.unref?.();
  }

  function stop() {
    for (const timer of timers) clearInterval(timer);
    timers = [];
    for (const session of sessions.values()) endSession(session, { message: 'The panel is restarting' });
    for (const link of links.values()) link.channel.close(1001, 'panel stopping');
  }

  // --- Owners -------------------------------------------------------------

  // Step one, over the REST API: checks and a one-time ticket.
  async function createTicket(actor, serverId, { cols = 80, rows = 24 } = {}) {
    await authorize(actor, PERMISSIONS.SERVERS_TERMINAL, { type: 'server', id: serverId });
    // A shell is for a person at the panel in a browser: not for an API
    // token, a plugin or any other caller, even with the permission.
    if (actor.type !== 'user' || actor.tokenId || !actor.sessionId) {
      throw forbidden('The terminal opens only from the panel in a browser');
    }
    const server = await db('servers').where({ id: serverId }).whereNull('deleted_at').first();
    if (!server) throw notFound('Server not found');
    if (server.status !== 'online') throw new AppError(409, 'SERVER_OFFLINE', 'The server is not online, so a terminal cannot be opened');
    const link = links.get(serverId);
    if (!link) {
      if (!server.agent_version || compareVersions(server.agent_version, TERMINAL_MIN_AGENT_VERSION) < 0) {
        throw new AppError(409, 'AGENT_TOO_OLD', `The terminal needs agent v${TERMINAL_MIN_AGENT_VERSION} or later; this server runs v${server.agent_version ?? '?'}. Update the agent from the Overview tab.`);
      }
      throw new AppError(409, 'TERMINAL_NOT_CONNECTED', 'The agent on this server has not connected its terminal channel yet. Wait a few seconds and try again; if it keeps happening, check the agent\'s log (journalctl -u vaultpanel-agent).');
    }
    if (!link.enabled) throw new AppError(409, 'TERMINAL_DISABLED', link.reason || 'The terminal is turned off on this server');
    const open = [...sessions.values()];
    if (open.filter((s) => s.serverId === serverId).length >= MAX_SESSIONS_PER_SERVER) {
      throw new AppError(429, 'TOO_MANY_TERMINALS', `At most ${MAX_SESSIONS_PER_SERVER} terminals can be open on one server. Close one first.`);
    }
    if (open.filter((s) => s.actor.id === actor.id).length >= MAX_SESSIONS_PER_USER) {
      throw new AppError(429, 'TOO_MANY_TERMINALS', `You have ${MAX_SESSIONS_PER_USER} terminals open. Close one first.`);
    }
    const ticket = randomBytes(32).toString('base64url');
    tickets.set(ticket, {
      actor,
      serverId,
      serverName: server.name,
      cols: clamp(cols, 80, 1000),
      rows: clamp(rows, 24, 500),
      expiresAt: now() + TICKET_TTL_MS,
    });
    return { ticket, path: `/api/v1/terminal/connect?ticket=${ticket}`, expiresInSeconds: TICKET_TTL_MS / 1000 };
  }

  // Step two: the browser's WebSocket, with the ticket. `channel` is
  // { send(obj), sendBinary(buffer), bufferedAmount(), close(code, reason) }.
  // Returns the handlers for what the browser sends, or null when refused.
  async function attachBrowser(ticketValue, channel, meta = {}) {
    const ticket = ticketValue && tickets.get(ticketValue);
    if (ticket) tickets.delete(ticketValue);
    if (!ticket || ticket.expiresAt < now()) {
      channel.send({ type: 'exit', message: 'This terminal link expired. Open the terminal again.' });
      channel.close(4401, 'ticket');
      return null;
    }
    const link = links.get(ticket.serverId);
    if (!link || !link.enabled) {
      channel.send({ type: 'exit', message: 'The server\'s agent disconnected. Try again in a few seconds.' });
      channel.close(4409, 'agent');
      return null;
    }
    const actor = { ...ticket.actor, ip: meta.ip ?? ticket.actor.ip, userAgent: meta.userAgent ?? ticket.actor.userAgent };
    const session = {
      id: randomUUID(),
      serverId: ticket.serverId,
      serverName: ticket.serverName,
      actor,
      channel,
      link,
      state: 'opening',
      openedAt: now(),
      bytesOut: 0,
      paused: false,
      drainTimer: null,
      openTimer: null,
      recorder: null,
    };
    // Recorded in the panel, as the bytes pass (terminalRecordingService.js).
    if (recordings) {
      try {
        session.recorder = await recordings.start({ id: session.id, serverId: session.serverId, serverName: session.serverName, actor, cols: ticket.cols, rows: ticket.rows });
      } catch (err) {
        logger.warn({ err, sessionId: session.id }, 'could not start the terminal recording');
      }
    }
    const recording = session.recorder?.mode ?? 'off';
    sessions.set(session.id, session);
    link.sessions.add(session.id);
    const target = { type: 'server', id: session.serverId, label: session.serverName };
    await audit.record({ actor, action: 'server.terminal.open', target, metadata: { sessionId: session.id, recording } });

    const issuedAt = new Date(now());
    const envelope = {
      version: 1,
      kind: 'terminal',
      sessionId: session.id,
      serverId: session.serverId,
      requestedBy: { type: 'user', id: actor.id, label: actor.label },
      cols: ticket.cols,
      rows: ticket.rows,
      issuedAt: issuedAt.toISOString(),
      expiresAt: new Date(issuedAt.getTime() + ENVELOPE_VALIDITY_MS).toISOString(),
    };
    channel.send({ type: 'status', state: 'connecting', server: session.serverName, recording });
    link.channel.send({ type: 'open', envelope, signature: await signing.signEnvelope(envelope) });
    session.openTimer = setTimeout(() => {
      if (session.state === 'opening') endSession(session, { message: 'The server did not start the terminal in time' });
    }, OPEN_TIMEOUT_MS);

    return {
      message(raw) {
        if (session.state === 'closed') return;
        if (raw.length > MAX_INPUT * 2) return;
        let msg;
        try {
          msg = JSON.parse(raw);
        } catch {
          return;
        }
        if (msg.type === 'input' && typeof msg.data === 'string' && msg.data.length <= MAX_INPUT) {
          session.link.channel.send({ type: 'input', session: session.id, data: msg.data });
          session.recorder?.input(msg.data);
        } else if (msg.type === 'resize') {
          const cols = clamp(msg.cols, 80, 1000);
          const rows = clamp(msg.rows, 24, 500);
          session.link.channel.send({ type: 'resize', session: session.id, cols, rows });
          session.recorder?.resize(cols, rows);
        }
      },
      close() {
        if (session.state === 'closed') return;
        session.link.channel.send({ type: 'close', session: session.id });
        endSession(session, { notifyBrowser: false });
      },
    };
  }

  function endSession(session, { code = null, signal = null, message = null, notifyBrowser = true } = {}) {
    if (session.state === 'closed') return;
    session.state = 'closed';
    clearTimeout(session.openTimer);
    clearInterval(session.drainTimer);
    sessions.delete(session.id);
    session.link.sessions.delete(session.id);
    if (notifyBrowser) {
      session.channel.send({ type: 'exit', code, signal, message });
      session.channel.close(1000, 'ended');
    }
    const seconds = Math.round((now() - session.openedAt) / 1000);
    session.recorder?.finish({ exitCode: code, reason: message, outputBytes: session.bytesOut }).catch((err) => logger.warn({ err }, 'could not finish the terminal recording'));
    audit
      .record({
        actor: session.actor,
        action: 'server.terminal.close',
        target: { type: 'server', id: session.serverId, label: session.serverName },
        metadata: { sessionId: session.id, seconds, outputBytes: session.bytesOut, exitCode: code, ...(message ? { reason: message } : {}) },
      })
      .catch((err) => logger.warn({ err }, 'could not record terminal close'));
  }

  // Signed-out, deactivated or demoted owners lose their open terminals.
  async function recheckAll() {
    const byUser = new Map();
    for (const session of sessions.values()) {
      const key = `${session.actor.id}:${session.actor.sessionId}`;
      if (!byUser.has(key)) byUser.set(key, await stillAllowed(session.actor));
      if (!byUser.get(key)) {
        session.link.channel.send({ type: 'close', session: session.id });
        endSession(session, { message: 'Your sign-in ended or you no longer have access to the terminal' });
      }
    }
  }

  async function stillAllowed(actor) {
    const signIn = await db('sessions')
      .where({ id: actor.sessionId, user_id: actor.id })
      .whereNull('revoked_at')
      .where('expires_at', '>', new Date(now()))
      .first('id');
    if (!signIn) return false;
    const user = await db('users').where({ id: actor.id }).first('is_active');
    if (!user?.is_active) return false;
    const access = await accessControl.getUserAccess(actor.id);
    return access.permissions.includes(PERMISSIONS.SERVERS_TERMINAL);
  }

  // --- Agents -------------------------------------------------------------

  // An authenticated agent connected. Returns the handlers for its messages.
  function attachAgent(server, agentVersion, channel) {
    const previous = links.get(server.id);
    if (previous) dropLink(previous, 'replaced by a new connection');
    const link = { serverId: server.id, channel, enabled: false, reason: 'The agent has not said hello yet', version: agentVersion, sessions: new Set() };
    links.set(server.id, link);
    logger.info({ serverId: server.id }, 'agent terminal link connected');

    return {
      message(raw) {
        let msg;
        try {
          msg = JSON.parse(raw);
        } catch {
          return;
        }
        if (msg.type === 'hello') {
          link.enabled = msg.enabled === true;
          link.reason = typeof msg.reason === 'string' ? msg.reason.slice(0, 300) : null;
          link.version = typeof msg.version === 'string' ? msg.version.slice(0, 40) : link.version;
          return;
        }
        const session = typeof msg.session === 'string' && sessions.get(msg.session);
        // An agent only ever speaks for its own server's sessions.
        if (!session || session.link !== link) return;
        if (msg.type === 'opened') {
          session.state = 'open';
          clearTimeout(session.openTimer);
          session.channel.send({ type: 'status', state: 'ready', server: session.serverName, recording: session.recorder?.mode ?? 'off' });
        } else if (msg.type === 'data' && typeof msg.data === 'string') {
          const bytes = Buffer.from(msg.data, 'base64');
          session.bytesOut += bytes.length;
          session.channel.sendBinary(bytes);
          session.recorder?.output(bytes);
          throttle(session);
        } else if (msg.type === 'exit') {
          endSession(session, {
            code: Number.isInteger(msg.code) ? msg.code : null,
            signal: typeof msg.signal === 'string' ? msg.signal.slice(0, 20) : null,
            message: typeof msg.message === 'string' ? msg.message.slice(0, 300) : null,
          });
        }
      },
      close() {
        if (links.get(server.id) === link) links.delete(server.id);
        dropLink(link, null);
      },
    };
  }

  function dropLink(link, reason) {
    for (const id of [...link.sessions]) {
      const session = sessions.get(id);
      if (session) endSession(session, { message: 'Lost the connection to the server\'s agent' });
    }
    if (reason) link.channel.close(4000, reason);
  }

  function throttle(session) {
    if (session.paused || session.channel.bufferedAmount() < HIGH_WATER) return;
    session.paused = true;
    session.link.channel.send({ type: 'pause', session: session.id });
    session.drainTimer = setInterval(() => {
      if (session.state === 'closed' || session.channel.bufferedAmount() > LOW_WATER) return;
      clearInterval(session.drainTimer);
      session.paused = false;
      session.link.channel.send({ type: 'resume', session: session.id });
    }, 50);
  }

  function status() {
    return { links: links.size, sessions: sessions.size };
  }

  return { start, stop, createTicket, attachBrowser, attachAgent, status };
}

function clamp(value, fallback, max) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 2 && n <= max ? n : fallback;
}
