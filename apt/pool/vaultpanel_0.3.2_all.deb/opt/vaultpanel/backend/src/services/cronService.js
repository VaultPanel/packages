import { randomUUID } from 'node:crypto';
import { CRON_JOB_BUSY_STATUSES, CRON_OWNER_TYPES, CRON_RUNS_KEPT, PERMISSIONS, parseCommands, parseCron } from '@vaultpanel/shared';
import { toPublicCronJob, toPublicCronRun } from '../models/automationModel.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { assertOwned, scopeQuery } from './tenancy.js';
import { systemActor } from './actor.js';
import { loadResource, requireReady } from './resources.js';

// Cron jobs run commands on a schedule as a website's or an app's own Linux
// user. The agent keeps each job's settings in a root-only file and writes
// one line per job to /etc/cron.d/vaultpanel that runs the agent with the
// job's id, never the commands themselves (see agent/src/operations/cron.js).
//
// Like databases, a job has a status while a change is on its way to the
// server (creating, updating, deleting); pending_spec holds the settings an
// update will make live once the agent confirms it.
//
// Runs started by cron reach the panel with the agent's next heartbeat
// (POST /agent/cron-runs); runs started by hand come back with their job.

const SPEC_FIELDS = ['name', 'schedule', 'commands', 'workingDir', 'timeoutSeconds', 'enabled', 'appEnv'];

export function createCronService({ db, logger, audit, authorize, jobs, events, quotas }) {
  function baseQuery() {
    return db('cron_jobs as c')
      .join('servers as s', 's.id', 'c.server_id')
      .whereNull('c.deleted_at')
      .whereNull('s.deleted_at')
      .select('c.*', 's.name as server_name', 's.timezone as server_timezone');
  }

  async function load(id) {
    const row = await baseQuery().where('c.id', id).first();
    if (!row) throw notFound('Cron job not found');
    return row;
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.CRON_READ);
    const q = scopeQuery(baseQuery(), actor, 'c.customer_id');
    if (query.serverId) q.where('c.server_id', query.serverId);
    if (query.ownerType) q.where('c.owner_type', query.ownerType);
    if (query.ownerId) q.where('c.owner_id', query.ownerId);
    if (query.search) {
      const like = `%${query.search.replace(/[\\%_]/g, '\\$&')}%`;
      q.where((w) => w.where('c.name', 'like', like).orWhere('c.user_name', 'like', like));
    }
    const { rows, pagination } = await paginate(q, query, { createdAt: 'c.created_at', name: 'c.name', lastRunAt: 'c.last_run_at' });
    return { items: rows.map(toPublicCronJob), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.CRON_READ);
    return toPublicCronJob(await load(id));
  }

  // ---- Changing -------------------------------------------------------------

  function checkSpec(spec, ownerType) {
    const parsed = parseCron(spec.schedule);
    if (!parsed.ok) throw validationError([{ field: 'schedule', message: parsed.error }]);
    const commands = parseCommands(spec.commands);
    if (commands.error) throw validationError([{ field: 'commands', message: commands.error }]);
    if (!commands.commands.length) throw validationError([{ field: 'commands', message: 'Enter at least one command' }]);
    if (spec.appEnv && ownerType !== 'application') {
      throw validationError([{ field: 'appEnv', message: 'Only an app has environment variables to load' }]);
    }
    return { ...spec, schedule: parsed.expression, workingDir: spec.workingDir ?? '' };
  }

  function jobParams(row, spec) {
    const params = {
      id: row.id,
      user: row.user_name,
      schedule: spec.schedule,
      commands: spec.commands,
      timeoutSeconds: spec.timeoutSeconds,
      enabled: spec.enabled,
      appEnv: spec.appEnv,
    };
    if (spec.workingDir) params.workingDir = spec.workingDir;
    return params;
  }

  function specOf(row) {
    return {
      name: row.name,
      schedule: row.schedule,
      commands: row.commands,
      workingDir: row.working_dir ?? '',
      timeoutSeconds: row.timeout_seconds,
      enabled: Boolean(row.enabled),
      appEnv: Boolean(row.app_env),
    };
  }

  function specColumns(spec) {
    return {
      name: spec.name,
      schedule: spec.schedule,
      commands: spec.commands,
      working_dir: spec.workingDir || null,
      timeout_seconds: spec.timeoutSeconds,
      enabled: spec.enabled,
      app_env: spec.appEnv,
    };
  }

  function requireIdle(row) {
    if (CRON_JOB_BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'CRON_JOB_BUSY', 'A change to this cron job is still running', { jobId: row.last_job_id });
    }
  }

  const target = (row) => ({ type: 'cron_job', id: row.id, label: `${row.name} (${row.user_name})` });

  // A cron job belongs to the hosting customer of its website or app, and
  // counts against their plan.
  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.CRON_MANAGE);
    const owner = await loadResource(db, input.ownerType, input.ownerId);
    assertOwned(actor, owner.customerId, `This ${input.ownerType === 'website' ? 'website' : 'app'} was not found`);
    if (!CRON_OWNER_TYPES[owner.type]) throw validationError([{ field: 'ownerType', message: 'Cron jobs run as a website or an app' }]);
    return quotas.reserve(owner.customerId, ['cronJobs'], () => createChecked(actor, input, owner));
  }

  async function createChecked(actor, input, owner) {
    requireReady(owner);
    const spec = checkSpec(input, owner.type);
    const id = randomUUID();
    const now = new Date();
    const row = {
      id,
      server_id: owner.serverId,
      owner_type: owner.type,
      owner_id: owner.id,
      user_name: owner.name,
      ...specColumns(spec),
      customer_id: owner.customerId,
      status: 'creating',
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    };
    await db('cron_jobs').insert(row);
    let job;
    try {
      job = await jobs.create(actor, { serverId: owner.serverId, type: 'CREATE_CRON', params: jobParams(row, spec), resource: { type: 'cron_job', id } }, { internal: true });
    } catch (err) {
      await db('cron_jobs').where({ id }).delete();
      throw err;
    }
    await db('cron_jobs').where({ id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'cron_job.create', target: target(row), metadata: { owner: { type: owner.type, id: owner.id }, schedule: spec.schedule, enabled: spec.enabled, jobId: job.id } });
    return { cronJob: toPublicCronJob(await load(id)), job };
  }

  async function update(actor, id, changes) {
    await authorize(actor, PERMISSIONS.CRON_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const owner = await loadResource(db, row.owner_type, row.owner_id);
    requireReady(owner);
    const current = specOf(row);
    const spec = checkSpec({ ...current, ...Object.fromEntries(SPEC_FIELDS.filter((f) => changes[f] !== undefined).map((f) => [f, changes[f]])) }, row.owner_type);
    const changed = SPEC_FIELDS.filter((f) => spec[f] !== current[f]);
    if (!changed.length) return { cronJob: toPublicCronJob(row), job: null };

    // A new name only changes the panel's record.
    if (changed.length === 1 && changed[0] === 'name') {
      await db('cron_jobs').where({ id }).update({ name: spec.name, updated_at: new Date() });
      await audit.record({ actor, action: 'cron_job.update', target: target(row), metadata: { changed } });
      return { cronJob: toPublicCronJob(await load(id)), job: null };
    }
    // A job that never reached its server is created again with the new settings.
    const failedCreate = row.status === 'failed';
    const claimed = await db('cron_jobs')
      .where({ id, status: row.status })
      .update({ status: failedCreate ? 'creating' : 'updating', pending_spec: toJson(spec), updated_at: new Date() });
    if (!claimed) throw new AppError(409, 'CRON_JOB_BUSY', 'This cron job changed meanwhile; try again');
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type: 'CREATE_CRON', params: jobParams(row, spec), resource: { type: 'cron_job', id } }, { internal: true });
    } catch (err) {
      await db('cron_jobs').where({ id }).update({ status: row.status, pending_spec: null });
      throw err;
    }
    await db('cron_jobs').where({ id }).update({ last_job_id: job.id });
    await audit.record({ actor, action: 'cron_job.update', target: target(row), metadata: { changed, schedule: spec.schedule, enabled: spec.enabled, jobId: job.id } });
    return { cronJob: toPublicCronJob(await load(id)), job };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.CRON_MANAGE);
    const row = await load(id);
    requireIdle(row);
    const job = await queueDelete(actor, row);
    await audit.record({ actor, action: 'cron_job.delete', target: target(row), metadata: { jobId: job?.id ?? null } });
    return { job };
  }

  async function queueDelete(actor, row) {
    // A job whose creation failed is removed from the panel at once; the
    // agent is still asked to remove anything it may have left behind.
    if (row.status === 'failed') {
      await db('cron_jobs').where({ id: row.id }).update({ deleted_at: new Date(), updated_at: new Date() });
      return jobs.create(actor, { serverId: row.server_id, type: 'DELETE_CRON', params: { id: row.id }, resource: { type: 'cron_job', id: row.id } }, { internal: true }).catch(() => null);
    }
    const claimed = await db('cron_jobs').where({ id: row.id, status: row.status }).update({ status: 'deleting', pending_spec: null, updated_at: new Date() });
    if (!claimed) throw new AppError(409, 'CRON_JOB_BUSY', 'This cron job changed meanwhile; try again');
    try {
      const job = await jobs.create(actor, { serverId: row.server_id, type: 'DELETE_CRON', params: { id: row.id }, resource: { type: 'cron_job', id: row.id } }, { internal: true });
      await db('cron_jobs').where({ id: row.id }).update({ last_job_id: job.id });
      return job;
    } catch (err) {
      await db('cron_jobs').where({ id: row.id }).update({ status: row.status });
      throw err;
    }
  }

  async function run(actor, id) {
    await authorize(actor, PERMISSIONS.CRON_RUN);
    const row = await load(id);
    if (row.status !== 'active') throw new AppError(409, 'CRON_JOB_NOT_READY', row.status === 'failed' ? 'This cron job is not set up on its server. Save it again first.' : 'A change to this cron job is still running');
    const job = await jobs.create(actor, { serverId: row.server_id, type: 'RUN_CRON', params: { id }, resource: { type: 'cron_job', id } }, { internal: true });
    await audit.record({ actor, action: 'cron_job.run', target: target(row), metadata: { jobId: job.id } });
    return { job };
  }

  async function runs(actor, id, query) {
    await authorize(actor, PERMISSIONS.CRON_READ);
    await load(id);
    const q = db('cron_runs').where({ cron_job_id: id });
    if (query.status) q.where({ status: query.status });
    const { rows, pagination } = await paginate(q, query, { startedAt: 'started_at' });
    return { items: rows.map((r) => toPublicCronRun(r)), pagination };
  }

  // ---- Results ----------------------------------------------------------------

  // Stores runs reported by a server's agent. Each run has the agent's own
  // id, so a report sent twice (a lost response) is stored once.
  async function recordRuns(serverId, reported, { jobId = null } = {}) {
    let stored = 0;
    for (const r of reported) {
      const row = await db('cron_jobs').where({ id: r.cronId, server_id: serverId }).first();
      if (!row) continue;
      const exists = await db('cron_runs').where({ run_key: r.runKey }).first('id');
      if (exists) continue;
      try {
        await db('cron_runs').insert({
          cron_job_id: row.id,
          server_id: serverId,
          run_key: r.runKey,
          trigger: r.trigger,
          status: r.status,
          exit_code: r.exitCode ?? null,
          started_at: new Date(r.startedAt),
          finished_at: r.finishedAt ? new Date(r.finishedAt) : null,
          duration_ms: r.durationMs ?? null,
          output: r.output ?? '',
          output_truncated: Boolean(r.outputTruncated),
          job_id: jobId,
        });
      } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') continue;
        throw err;
      }
      stored += 1;
      const startedAt = new Date(r.startedAt);
      if (!row.last_run_at || startedAt >= new Date(row.last_run_at)) {
        await db('cron_jobs').where({ id: row.id }).update({ last_run_at: startedAt, last_run_status: r.status, last_run_exit_code: r.exitCode ?? null, last_run_duration_ms: r.durationMs ?? null });
      }
      if (r.status === 'failed' || r.status === 'timed_out') {
        const server = await db('servers').where({ id: serverId }).first('name');
        await events.emit('cron.failed', {
          cronJob: { id: row.id, name: row.name, user: row.user_name, owner: { type: row.owner_type, id: row.owner_id } },
          run: { status: r.status, exitCode: r.exitCode ?? null, trigger: r.trigger, startedAt: startedAt.toISOString(), durationMs: r.durationMs ?? null, outputTail: (r.output ?? '').slice(-1000) },
          server: { id: serverId, name: server?.name ?? null },
        });
      }
      await pruneRuns(row.id);
    }
    return { stored };
  }

  async function pruneRuns(cronJobId) {
    const keep = await db('cron_runs').where({ cron_job_id: cronJobId }).orderBy('started_at', 'desc').offset(CRON_RUNS_KEPT).first('started_at');
    if (keep) await db('cron_runs').where({ cron_job_id: cronJobId }).where('started_at', '<=', keep.started_at).delete();
  }

  async function handleJobFinished(job, { status, output, error }) {
    if (job.resource_type === 'cron_job') return cronJobFinished(job, status, output, error);
    // Cron jobs of a deleted website or app are removed from the server too.
    if (status === 'succeeded' && ['DELETE_SITE', 'DELETE_APPLICATION'].includes(job.type)) await removeOrphans(job.server_id);
  }

  async function cronJobFinished(job, status, output, error) {
    const row = await db('cron_jobs').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };
    switch (job.type) {
      case 'CREATE_CRON': {
        if (row.status !== 'creating' && row.status !== 'updating') return;
        const pending = fromJson(row.pending_spec, null);
        if (ok) {
          // Saved, but nothing will start it until cron is installed.
          const warning = output?.cronInstalled === false
            ? { last_error_code: 'CRON_NOT_INSTALLED', last_error: 'The cron service is not installed on this server, so this job will not run on its schedule. Install Cron from the server’s Software card.' }
            : failure;
          await db('cron_jobs').where({ id: row.id }).update({ ...(pending ? specColumns(pending) : {}), status: 'active', pending_spec: null, ...warning, updated_at: now });
        } else {
          // A failed update leaves the previous settings on the server.
          await db('cron_jobs').where({ id: row.id }).update({ status: row.status === 'creating' ? 'failed' : 'active', pending_spec: null, ...failure, updated_at: now });
        }
        break;
      }
      case 'DELETE_CRON': {
        if (ok) await db('cron_jobs').where({ id: row.id }).update({ deleted_at: now, updated_at: now });
        else await db('cron_jobs').where({ id: row.id }).update({ status: 'active', ...failure, updated_at: now });
        break;
      }
      case 'RUN_CRON': {
        if (output?.run?.runKey) await recordRuns(row.server_id, [{ ...output.run, cronId: row.id }], { jobId: job.id });
        break;
      }
      default:
    }
  }

  // Removes the cron jobs whose website or app was deleted.
  async function removeOrphans(serverId) {
    const rows = await db('cron_jobs as c')
      .where('c.server_id', serverId)
      .whereNull('c.deleted_at')
      .whereNot('c.status', 'deleting')
      .where((w) =>
        w
          .where((x) => x.where('c.owner_type', 'website').whereNotExists(db('websites as w').whereRaw('w.id = c.owner_id').whereNull('w.deleted_at')))
          .orWhere((x) => x.where('c.owner_type', 'application').whereNotExists(db('applications as a').whereRaw('a.id = c.owner_id').whereNull('a.deleted_at'))),
      )
      .select('c.*');
    const actor = systemActor('cron cleanup');
    for (const row of rows) {
      try {
        await queueDelete(actor, row);
        await audit.record({ actor, action: 'cron_job.delete', target: target(row), metadata: { reason: `${row.owner_type} deleted` } });
      } catch (err) {
        logger.warn({ err, cronJobId: row.id }, 'could not remove the cron job of a deleted owner');
      }
    }
    return rows.length;
  }

  async function summary() {
    const since = new Date(Date.now() - 86_400_000);
    const [jobsCount, failed] = await Promise.all([
      db('cron_jobs').whereNull('deleted_at').count({ n: '*' }).first(),
      db('cron_runs').whereIn('status', ['failed', 'timed_out']).where('started_at', '>=', since).count({ n: '*' }).first(),
    ]);
    return { jobs: Number(jobsCount?.n ?? 0), failedLastDay: Number(failed?.n ?? 0) };
  }

  jobs.onFinished(handleJobFinished);

  return { list, get, create, update, remove, run, runs, recordRuns, removeOrphans, summary };
}
