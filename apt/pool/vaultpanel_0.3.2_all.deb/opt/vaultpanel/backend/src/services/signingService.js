import { createPrivateKey, createPublicKey, generateKeyPairSync, sign } from 'node:crypto';
import { getOrCreateSetting } from '../models/settingModel.js';
import { canonicalJson, createSecretBox, deriveKey } from '../utils/crypto.js';

const SETTING_KEY = 'agent.job_signing_key';

// The panel signs every job it hands to an agent with an Ed25519 key. Agents
// pin the matching public key at registration and refuse unsigned or
// tampered jobs, so a compromised network path cannot inject operations.
// The private key is generated on first use and stored encrypted.
export function createSigningService({ db, config }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'settings'));
  let keys = null;

  async function load() {
    if (keys) return keys;
    const sealed = await getOrCreateSetting(
      db,
      SETTING_KEY,
      () => {
        const { privateKey } = generateKeyPairSync('ed25519');
        return box.seal(privateKey.export({ type: 'pkcs8', format: 'pem' }));
      },
      { isSecret: true },
    );
    const privateKey = createPrivateKey(box.open(sealed));
    keys = {
      privateKey,
      publicKeyPem: createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }),
    };
    return keys;
  }

  async function signEnvelope(envelope) {
    const { privateKey } = await load();
    return sign(null, Buffer.from(canonicalJson(envelope)), privateKey).toString('base64');
  }

  async function publicKeyPem() {
    return (await load()).publicKeyPem;
  }

  return { signEnvelope, publicKeyPem };
}
