import { randomUUID } from 'node:crypto';
import { DNS_PROVIDER_MIN_AGENT_VERSION, DNS_PROVIDER_TYPES, PERMISSIONS, isIPv4, isRegisteredDomain, parentDomains } from '@vaultpanel/shared';
import { compareVersions } from '../utils/agentPackage.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { fromJson } from '../utils/json.js';
import { isPrivateAddress } from './agentService.js';
import { isCustomer } from './tenancy.js';

// DNS providers (Cloudflare, Namecheap): staff save an account's API
// credentials once, and wildcard certificates for domains whose DNS is there
// are checked through it instead of a zone on the panel's servers (agent
// 0.38.0). The secret is stored encrypted and sent to the agent only inside
// the ISSUE_SSL job, redacted once it ends; the agent keeps a copy only root
// reads, so Certbot can renew. Hosting customers neither see nor use them.

export function toPublicDnsProvider(row, { certificates } = {}) {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    typeLabel: DNS_PROVIDER_TYPES[row.type]?.label ?? row.type,
    username: row.username,
    ...(certificates !== undefined ? { certificates } : {}),
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function createDnsProviderService({ db, config, audit, authorize }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'dns-providers'));
  const target = (row) => ({ type: 'dns_provider', id: row.id, label: row.name });

  async function load(id) {
    const row = await db('dns_providers').where({ id }).first();
    if (!row) throw notFound('DNS provider not found');
    return row;
  }

  // Active certificates of live websites that renew through each provider.
  async function certificatesOf(ids) {
    const out = Object.fromEntries(ids.map((id) => [id, 0]));
    if (!ids.length) return out;
    const rows = await db('ssl_certificates as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .whereIn('c.dns_provider_id', ids)
      .whereNull('w.deleted_at')
      .where('c.status', 'active')
      .select('c.dns_provider_id')
      .count({ n: '*' })
      .groupBy('c.dns_provider_id');
    for (const r of rows) out[r.dns_provider_id] = Number(r.n);
    return out;
  }

  async function list(actor) {
    await authorize(actor, PERMISSIONS.DNS_READ);
    if (isCustomer(actor)) return { items: [] };
    const rows = await db('dns_providers').orderBy('name');
    const used = await certificatesOf(rows.map((r) => r.id));
    return { items: rows.map((r) => toPublicDnsProvider(r, { certificates: used[r.id] })) };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_READ);
    if (isCustomer(actor)) throw notFound('DNS provider not found');
    const row = await load(id);
    return { provider: toPublicDnsProvider(row, { certificates: (await certificatesOf([id]))[id] }) };
  }

  async function nameTaken(name, exceptId = null) {
    const q = db('dns_providers').where({ name });
    if (exceptId) q.whereNot({ id: exceptId });
    return Boolean(await q.first('id'));
  }

  function checkUsername(type, username) {
    if (type === 'namecheap' && !username) throw validationError([{ field: 'username', message: 'Enter your Namecheap user name' }]);
  }

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    checkUsername(input.type, input.username);
    if (!input.secret) throw validationError([{ field: 'secret', message: 'Required' }]);
    if (await nameTaken(input.name)) throw validationError([{ field: 'name', message: 'Another DNS provider has this name' }]);
    const now = new Date();
    const row = {
      id: randomUUID(),
      name: input.name,
      type: input.type,
      username: input.type === 'namecheap' ? input.username : null,
      secret_encrypted: box.seal(input.secret),
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    };
    await db('dns_providers').insert(row);
    await audit.record({ actor, action: 'dns_provider.create', target: target(row), metadata: { type: row.type } });
    return get(actor, row.id);
  }

  // A blank secret keeps the one saved. Servers keep the copy they got until
  // a certificate is issued again.
  async function update(actor, id, input) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const current = await load(id);
    if (input.type !== current.type) throw validationError([{ field: 'type', message: 'The provider cannot change; add a new one instead' }]);
    checkUsername(current.type, input.username);
    if (await nameTaken(input.name, id)) throw validationError([{ field: 'name', message: 'Another DNS provider has this name' }]);
    await db('dns_providers')
      .where({ id })
      .update({
        name: input.name,
        username: current.type === 'namecheap' ? input.username : null,
        ...(input.secret ? { secret_encrypted: box.seal(input.secret) } : {}),
        updated_at: new Date(),
      });
    await audit.record({ actor, action: 'dns_provider.update', target: { ...target(current), label: input.name }, metadata: { secretChanged: Boolean(input.secret) } });
    return get(actor, id);
  }

  // Refused while certificates renew through it.
  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.DNS_MANAGE);
    const row = await load(id);
    const used = (await certificatesOf([id]))[id];
    if (used) {
      throw new AppError(409, 'DNS_PROVIDER_IN_USE', `${used} certificate${used === 1 ? ' renews' : 's renew'} through ${row.name}. Issue ${used === 1 ? 'it' : 'them'} again another way, or turn HTTPS off on ${used === 1 ? 'that website' : 'those websites'}, first.`, { certificates: used });
    }
    await db('dns_providers').where({ id }).delete();
    await audit.record({ actor, action: 'dns_provider.delete', target: target(row) });
  }

  // What ISSUE_SSL gets to check a wildcard certificate for zone through the
  // provider, from server.
  async function forCertificate(actor, id, { server, zone }) {
    if (isCustomer(actor)) throw new AppError(403, 'FORBIDDEN', 'DNS providers are set up by your host');
    await authorize(actor, PERMISSIONS.DNS_READ);
    const row = await db('dns_providers').where({ id }).first();
    if (!row) throw validationError([{ field: 'dnsProviderId', message: 'This DNS provider no longer exists' }]);
    if (compareVersions(server.agent_version ?? '0.0.0', DNS_PROVIDER_MIN_AGENT_VERSION) < 0) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot use DNS providers. Update the agent to ${DNS_PROVIDER_MIN_AGENT_VERSION} or newer first.`);
    }
    const secret = box.open(row.secret_encrypted);
    if (row.type === 'cloudflare') return { row, payload: { type: 'cloudflare', apiToken: secret } };
    // Namecheap changes the records of the domain as registered, and answers
    // only the whitelisted address the server calls from.
    const domain = [zone, ...parentDomains(zone)].find(isRegisteredDomain);
    if (!domain) throw new AppError(422, 'DNS_PROVIDER_DOMAIN', `VaultPanel cannot tell which domain registered at Namecheap ${zone} belongs to.`);
    const clientIp = [server.public_ip, ...fromJson(server.ip_addresses, [])].find((a) => typeof a === 'string' && isIPv4(a) && !isPrivateAddress(a) && !a.startsWith('127.'));
    if (!clientIp) throw new AppError(409, 'DNS_PROVIDER_NO_ADDRESS', `Namecheap answers only whitelisted IPv4 addresses, and ${server.name} has no public IPv4 address the panel knows of.`);
    return { row, payload: { type: 'namecheap', apiUser: row.username, apiKey: secret, clientIp, domain } };
  }

  return { list, get, create, update, remove, forCertificate };
}
