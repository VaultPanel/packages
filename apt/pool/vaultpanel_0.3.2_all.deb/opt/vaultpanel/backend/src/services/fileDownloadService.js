import { createHash, randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, open, readdir, rename, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { FINAL_JOB_STATUSES } from '@vaultpanel/shared';
import { AppError, notFound } from '../utils/errors.js';

// Downloads of website files of any size, and opening big text files in the
// editor. FILE_DOWNLOAD has the server's agent read the file as the site's
// user and send it to the panel in pieces; once the whole file is in and
// matches the agent's SHA-256, the person who asked downloads it from
// VAULTPANEL_DATA_DIR/downloads. Copies are removed an hour after they are
// ready, and unfinished ones when their job ends.

const READY_MS = 3_600_000;
const ABANDONED_MS = 6 * 3_600_000;

export function createFileDownloadService({ db, config, logger, jobs, websites }) {
  const dir = path.join(config.dataDir, 'downloads');
  const fileOf = (id, part = false) => path.join(dir, `${id}${part ? '.part' : ''}`);

  // Queues the job; resolves with it plus the download's id.
  async function start(actor, websiteId, { path: target }) {
    const id = randomUUID();
    const site = await websites.fileSite(actor, websiteId, 'download');
    await mkdir(dir, { recursive: true, mode: 0o700 });
    const now = new Date();
    await db('file_downloads').insert({ id, website_id: site.id, server_id: site.server_id, created_by: actor?.id ?? null, path: target, created_at: now, updated_at: now });
    try {
      const job = await websites.files(actor, websiteId, 'download', { path: target, downloadId: id, maxBytes: config.fileDownloadMaxBytes });
      await db('file_downloads').where({ id }).update({ job_id: job.id });
      return { ...job, downloadId: id };
    } catch (err) {
      await db('file_downloads').where({ id }).delete();
      throw err;
    }
  }

  // A piece from the agent, while its FILE_DOWNLOAD job runs.
  async function receiveChunk(serverId, id, { offset, data }) {
    const row = await db('file_downloads').where({ id, server_id: serverId }).first();
    if (!row?.job_id) throw notFound('Download not found');
    const job = await db('jobs').where({ id: row.job_id, server_id: serverId }).first('status');
    if (!job || !['dispatched', 'running'].includes(job.status)) throw new AppError(409, 'NO_DOWNLOAD', 'No download of this file is running');
    const bytes = Buffer.from(data, 'base64');
    const handle = await open(fileOf(id, true), offset === 0 ? 'w' : 'a', 0o600);
    try {
      const { size } = await handle.stat();
      if (size !== offset) throw new AppError(409, 'OFFSET_MISMATCH', `Expected offset ${size}`, { expected: size });
      if (size + bytes.length > config.fileDownloadMaxBytes) throw new AppError(422, 'DOWNLOAD_TOO_LARGE', 'More data than downloads take');
      await handle.write(bytes);
    } finally {
      await handle.close();
    }
    return { received: offset + bytes.length };
  }

  async function remove(id) {
    await rm(fileOf(id, true), { force: true });
    await rm(fileOf(id), { force: true });
    await db('file_downloads').where({ id }).delete();
  }

  async function handleJobFinished(job, { status, output }) {
    if (job.type !== 'FILE_DOWNLOAD') return;
    const row = await db('file_downloads').where({ job_id: job.id }).first();
    if (!row) return;
    if (status === 'succeeded') {
      const actual = await hashFile(fileOf(row.id, true)).catch(() => null);
      if (actual && actual.size === output?.size && actual.sha256 === output?.sha256) {
        await rename(fileOf(row.id, true), fileOf(row.id));
        await db('file_downloads').where({ id: row.id }).update({ size_bytes: actual.size, sha256: actual.sha256, ready_at: new Date(), updated_at: new Date() });
        return;
      }
      logger.warn({ downloadId: row.id, actual, expected: output }, 'downloaded file does not match its checksum');
      await db('jobs').where({ id: job.id }).update({ status: 'failed', error_code: 'DOWNLOAD_CORRUPT', error_message: 'The copy the panel received does not match the file. Try again.' });
    }
    await remove(row.id);
  }

  async function own(actor, websiteId, id) {
    const row = await db('file_downloads').where({ id, website_id: websiteId }).first();
    if (!row || (row.created_by ?? null) !== (actor?.id ?? null)) throw notFound('This download has expired or failed. Download the file again.');
    await websites.fileSite(actor, websiteId, 'download');
    return row;
  }

  // Whether the file is ready (the job can end a moment before the checksum is checked).
  async function status(actor, websiteId, id) {
    const row = await own(actor, websiteId, id);
    return { id: row.id, path: row.path, ready: Boolean(row.ready_at), size: row.size_bytes === null ? null : Number(row.size_bytes), sha256: row.sha256 };
  }

  // The file for the person who asked for it, once it is ready.
  async function open_(actor, websiteId, id) {
    const row = await own(actor, websiteId, id);
    if (!row.ready_at) throw new AppError(409, 'DOWNLOAD_NOT_READY', 'The file is still on its way from the server');
    const file = fileOf(row.id);
    const info = await stat(file).catch(() => null);
    if (!info) throw notFound('This download has expired. Download the file again.');
    return { file, size: info.size, name: path.basename(row.path), stream: () => createReadStream(file) };
  }

  // Worker: ready copies after an hour, and copies whose job never finished.
  async function prune(now = new Date()) {
    const rows = await db('file_downloads as d')
      .leftJoin('jobs as j', 'j.id', 'd.job_id')
      .where((q) =>
        q
          .where((qq) => qq.whereNotNull('d.ready_at').where('d.ready_at', '<', new Date(now.getTime() - READY_MS)))
          .orWhere((qq) => qq.whereNull('d.ready_at').where((j) => j.whereNull('j.id').orWhereIn('j.status', FINAL_JOB_STATUSES)).where('d.updated_at', '<', new Date(now.getTime() - 60_000)))
          .orWhere('d.created_at', '<', new Date(now.getTime() - ABANDONED_MS)),
      )
      .select('d.id');
    for (const row of rows) await remove(row.id);
    let orphans = 0;
    const names = await readdir(dir).catch(() => []);
    if (names.length) {
      const known = new Set((await db('file_downloads').select('id')).map((r) => r.id));
      for (const name of names) {
        if (known.has(name.replace(/\.part$/, ''))) continue;
        const info = await stat(path.join(dir, name)).catch(() => null);
        if (info && now.getTime() - info.mtimeMs > READY_MS) {
          await rm(path.join(dir, name), { force: true });
          orphans += 1;
        }
      }
    }
    if (rows.length || orphans) logger.info({ downloads: rows.length, orphans }, 'removed old file downloads');
    return rows.length + orphans;
  }

  jobs.onFinished(handleJobFinished);
  return { start, receiveChunk, status, open: open_, handleJobFinished, prune };
}

function hashFile(file) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    let size = 0;
    createReadStream(file)
      .on('data', (chunk) => {
        size += chunk.length;
        hash.update(chunk);
      })
      .on('end', () => resolve({ size, sha256: hash.digest('hex') }))
      .on('error', reject);
  });
}
