import { PERMISSIONS, monthlyPriceCents } from '@vaultpanel/shared';
import { toPublicPlan } from '../models/hostingModel.js';

// The financial report: what the hosting accounts are worth at their plans'
// prices, and how the accounts changed month by month.
//
// VaultPanel takes no payments (billing systems charge customers and call the
// billing API), so these are expected amounts from plan prices, never money
// received. Plan changes are not kept per month, so past months are priced at
// each account's current plan.

const monthKey = (d) => `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;

export function createFinancialReportService({ db, authorize }) {
  async function report(actor, { months }) {
    await authorize(actor, PERMISSIONS.CUSTOMERS_READ);
    const now = new Date();
    // First day of the oldest month shown, UTC.
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - (months - 1), 1));

    const [planRows, customers, suspensions] = await Promise.all([
      db('hosting_plans').orderBy('name'),
      db('customers').select('id', 'plan_id', 'status', 'created_at', 'terminated_at'),
      db('audit_logs')
        .where({ action: 'customer.suspend', result: 'success' })
        .where('occurred_at', '>=', start)
        .select('occurred_at'),
    ]);

    const plans = new Map(
      planRows.map((row) => {
        const plan = toPublicPlan(row);
        return [plan.id, { ...plan, monthlyCents: monthlyPriceCents(plan) }];
      }),
    );

    // Per plan, today.
    const perPlan = new Map([...plans.keys()].map((id) => [id, { active: 0, suspended: 0 }]));
    for (const c of customers) {
      if (c.status === 'terminated' || !perPlan.has(c.plan_id)) continue;
      perPlan.get(c.plan_id)[c.status === 'suspended' ? 'suspended' : 'active'] += 1;
    }
    const planItems = [...plans.values()].map((p) => {
      const counts = perPlan.get(p.id);
      const priced = p.monthlyCents !== null;
      return {
        id: p.id,
        name: p.name,
        isActive: p.isActive,
        billingCycle: p.billingCycle,
        priceCents: p.priceCents,
        currency: p.currency,
        monthlyCents: p.monthlyCents,
        activeAccounts: counts.active,
        suspendedAccounts: counts.suspended,
        monthlyTotalCents: priced ? p.monthlyCents * counts.active : null,
        atRiskCents: priced ? p.monthlyCents * counts.suspended : null,
      };
    });

    // Totals per currency (plans may use different ones; they are never mixed).
    const byCurrency = new Map();
    const totals = (currency) => {
      if (!byCurrency.has(currency)) byCurrency.set(currency, { currency, monthlyCents: 0, yearlyCents: 0, atRiskCents: 0, payingAccounts: 0 });
      return byCurrency.get(currency);
    };
    for (const p of planItems) {
      if (p.monthlyTotalCents === null) continue;
      const t = totals(p.currency);
      t.monthlyCents += p.monthlyTotalCents;
      t.atRiskCents += p.atRiskCents;
      if (p.monthlyCents > 0) t.payingAccounts += p.activeAccounts;
    }
    for (const t of byCurrency.values()) t.yearlyCents = t.monthlyCents * 12;

    // Month by month.
    const history = [];
    for (let i = 0; i < months; i += 1) {
      const from = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
      const to = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i + 1, 1));
      const end = to > now ? now : to;
      const entry = { month: monthKey(from), newAccounts: 0, removedAccounts: 0, suspensions: 0, accountsAtEnd: 0, monthlyByCurrency: {} };
      for (const c of customers) {
        const created = new Date(c.created_at);
        const removed = c.terminated_at ? new Date(c.terminated_at) : null;
        if (created >= from && created < to) entry.newAccounts += 1;
        if (removed && removed >= from && removed < to) entry.removedAccounts += 1;
        if (created < end && (!removed || removed >= end)) {
          entry.accountsAtEnd += 1;
          const plan = plans.get(c.plan_id);
          if (plan && plan.monthlyCents !== null) entry.monthlyByCurrency[plan.currency] = (entry.monthlyByCurrency[plan.currency] ?? 0) + plan.monthlyCents;
        }
      }
      history.push(entry);
    }
    const historyByMonth = new Map(history.map((h) => [h.month, h]));
    for (const s of suspensions) {
      const h = historyByMonth.get(monthKey(new Date(s.occurred_at)));
      if (h) h.suspensions += 1;
    }

    const live = customers.filter((c) => c.status !== 'terminated');
    return {
      generatedAt: now.toISOString(),
      months,
      from: start.toISOString(),
      summary: {
        activeAccounts: live.filter((c) => c.status === 'active').length,
        suspendedAccounts: live.filter((c) => c.status === 'suspended').length,
        unpricedAccounts: live.filter((c) => c.status === 'active' && plans.get(c.plan_id)?.monthlyCents === null).length,
        newAccounts: history.reduce((n, h) => n + h.newAccounts, 0),
        removedAccounts: history.reduce((n, h) => n + h.removedAccounts, 0),
        byCurrency: [...byCurrency.values()].sort((a, b) => b.monthlyCents - a.monthlyCents),
      },
      plans: planItems,
      history,
    };
  }

  return { report };
}
