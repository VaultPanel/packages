import { randomUUID, createPublicKey, generateKeyPairSync } from 'node:crypto';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { saveSecretFile, withDefaults } from '../../../agent/src/config.js';
import { compareVersions, LATEST_AGENT_VERSION, REPO_ROOT } from '../utils/agentPackage.js';
import { sha256Hex } from '../utils/crypto.js';
import { systemActor } from './actor.js';
import { HEARTBEAT_INTERVAL_SECONDS, isLoopback } from './agentService.js';

export const LOCAL_AGENT_PATHS = Object.freeze({
  configPath: '/etc/vaultpanel-agent/config.json',
  installDir: '/opt/vaultpanel-agent',
  unitPath: '/etc/systemd/system/vaultpanel-agent.service',
});

// Connects the server the panel runs on, so it shows in the panel without
// anyone adding it or copying an install command.
//
// This never runs inside the web app. It runs as its own short process before
// the API starts (npm's predev/prestart, or `npm run connect-local`), as root,
// and does what an operator would: it creates the server record and the
// agent's identity directly in the database, writes the agent's config, and
// installs the agent with scripts/install-agent.sh from this checkout. From
// then on the panel manages the server only through that agent, like any other.
//
// It is safe to run on every start: once the server is connected it only
// updates the agent when this checkout carries a newer version.
export function createLocalServerService({ db, config, audit, signing, paths = LOCAL_AGENT_PATHS, runInstaller = defaultInstaller }) {
  const actor = systemActor('local server setup');

  async function connect({ force = false, isRoot = process.getuid?.() === 0 } = {}) {
    const local = await db('servers').where({ is_local: true }).orderBy('created_at', 'desc').first();
    if (local?.deleted_at && !force) {
      return result('removed', 'This server was removed from the panel, so it is not connected again. To connect it anyway: npm run connect-local -- --force');
    }
    const agentConfig = await readJson(paths.configPath);

    // Already connected: the agent here belongs to the local server.
    if (local && !local.deleted_at && (await ownsAgent(local.id, agentConfig))) {
      return ensureInstalled(local, agentConfig, { isRoot });
    }

    // Connected by hand with "Add a server": adopt that server instead of
    // adding a second one.
    if (!local || local.deleted_at) {
      const manual = agentConfig?.serverId ? await db('servers').where({ id: agentConfig.serverId }).whereNull('deleted_at').first() : null;
      if (manual && (await ownsAgent(manual.id, agentConfig))) {
        await db.transaction(async (trx) => {
          await trx('servers').where({ is_local: true }).whereNot({ id: manual.id }).update({ is_local: false });
          await trx('servers').where({ id: manual.id }).update({ is_local: true, updated_at: new Date() });
        });
        await audit.record({ actor, action: 'server.mark_local', target: target(manual) });
        return ensureInstalled(manual, agentConfig, { isRoot, adopted: true });
      }
    }

    // An agent here that talks to a different panel is left alone.
    if (agentConfig?.panelUrl && !force && !isThisPanel(agentConfig.panelUrl)) {
      return result('foreign', `The agent on this server is connected to another panel (${agentConfig.panelUrl}), so it was left as it is. To connect it to this panel instead: npm run connect-local -- --force`);
    }

    if (!isRoot) {
      return result('needs_root', 'This server is not connected to the panel yet. Start the panel as root once, or run: sudo npm run connect-local');
    }

    const server = local && !local.deleted_at ? local : await createServer(local);
    await register(server, agentConfig);
    await runInstaller(['--registered', '--from', path.join(REPO_ROOT, 'agent')]);
    return result('connected', `Connected this server to the panel as "${server.name}".`, server.id);
  }

  async function ownsAgent(serverId, agentConfig) {
    if (!agentConfig?.agentId || agentConfig.serverId !== serverId) return false;
    const agent = await db('server_agents').where({ id: agentConfig.agentId, server_id: serverId }).whereNull('revoked_at').first();
    return Boolean(agent);
  }

  // Installs the agent's files and service if they are missing, or updates
  // them when this checkout has a newer agent. An agent connected by hand
  // usually reaches the panel through the web address (the Vite dev server in
  // development); it is pointed straight at the API instead, so it keeps
  // working whatever serves the UI.
  async function ensureInstalled(server, agentConfig, { isRoot, adopted = false }) {
    const installed = existsSync(paths.unitPath) ? (await readJson(path.join(paths.installDir, 'package.json')))?.version : null;
    const outdated = !installed || (LATEST_AGENT_VERSION && compareVersions(installed, LATEST_AGENT_VERSION) < 0);
    const panelUrl = localPanelUrl(config);
    const moved = isRoot && agentConfig.panelUrl !== panelUrl;
    const connected = adopted
      ? `"${server.name}" was already connected by hand; it is now marked as the server this panel runs on.`
      : `This server is connected to the panel as "${server.name}".`;
    if (moved) {
      await saveSecretFile(paths.configPath, `${JSON.stringify({ ...agentConfig, panelUrl, allowInsecureHttp: false }, null, 2)}\n`);
    }
    // Agents installed while the panel's UMask=0077 reached the installer
    // (before 0.37.0) are readable by root only, so site users cannot start
    // the file manager's worker. Installing again fixes the modes.
    const unreadable = isRoot && Boolean(installed) && !(await readableByAll(paths.installDir));
    if (!outdated && !moved && !unreadable) return result(adopted ? 'adopted' : 'connected', connected, server.id);
    if (!outdated) {
      await runInstaller(['--upgrade', '--from', path.join(REPO_ROOT, 'agent')]);
      const done = moved ? ` Its agent now talks to the panel directly at ${panelUrl}.` : ' Its agent was installed again, readable by site users this time (the file manager needs that).';
      return result(adopted ? 'adopted' : 'connected', `${connected}${done}`, server.id);
    }
    if (!isRoot) {
      const what = installed ? `The agent on this server (${installed}) is older than this panel's (${LATEST_AGENT_VERSION}).` : 'The agent on this server is not installed.';
      return result('needs_root', `${what} Start the panel as root once, or run: sudo npm run connect-local`, server.id);
    }
    await runInstaller(installed ? ['--upgrade', '--from', path.join(REPO_ROOT, 'agent')] : ['--registered', '--from', path.join(REPO_ROOT, 'agent')]);
    if (installed) return result('upgraded', `${connected} Its agent was updated from ${installed} to ${LATEST_AGENT_VERSION}.`, server.id);
    return result(adopted ? 'adopted' : 'connected', `${connected} Its agent was installed again.`, server.id);
  }

  async function createServer(removed) {
    const id = randomUUID();
    const name = os.hostname() || 'This server';
    await db.transaction(async (trx) => {
      // With --force after a removal: the removed record stops being the local one.
      if (removed) await trx('servers').where({ id: removed.id }).update({ is_local: false });
      await trx('servers').insert({ id, name, status: 'pending', is_local: true });
    });
    const server = await db('servers').where({ id }).first();
    await audit.record({ actor, action: 'server.create', target: target(server), metadata: { local: true } });
    return server;
  }

  // The same records an agent registration writes, without the round trip
  // and enrollment token: this process can already write to the database.
  async function register(server, previousConfig) {
    const { privateKey, publicKey } = generateKeyPairSync('ed25519');
    const publicKeyPem = publicKey.export({ type: 'spki', format: 'pem' });
    const fingerprint = sha256Hex(createPublicKey(publicKeyPem).export({ type: 'spki', format: 'der' }));
    const agentId = randomUUID();
    const now = new Date();
    await db.transaction(async (trx) => {
      await trx('server_agents')
        .where({ server_id: server.id })
        .whereNull('revoked_at')
        .update({ revoked_at: now, revoked_reason: 'replaced by a new registration' });
      await trx('server_enrollment_tokens').where({ server_id: server.id }).whereNull('used_at').update({ used_at: now });
      await trx('server_agents').insert({
        id: agentId,
        server_id: server.id,
        public_key: publicKeyPem,
        key_fingerprint: fingerprint,
        agent_version: LATEST_AGENT_VERSION,
        registered_ip: '127.0.0.1',
        last_seen_at: now,
      });
      await trx('servers').where({ id: server.id }).update({
        agent_version: LATEST_AGENT_VERSION,
        agent_operations: null,
        hostname: os.hostname(),
        updated_at: now,
      });
    });

    // Policy the operator set on this server (allowed services, paths...) is
    // kept; only the identity changes.
    const { panelUrl: _p, agentId: _a, serverId: _s, panelPublicKey: _k, privateKeyPath: _pk, allowInsecureHttp: _i, ...policy } = previousConfig ?? {};
    const privateKeyPath = path.join(path.dirname(paths.configPath), 'agent.key');
    await saveSecretFile(privateKeyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }));
    const agentConfig = withDefaults({
      ...policy,
      panelUrl: localPanelUrl(config),
      agentId,
      serverId: server.id,
      panelPublicKey: await signing.publicKeyPem(),
      privateKeyPath,
      heartbeatIntervalSeconds: HEARTBEAT_INTERVAL_SECONDS,
      allowInsecureHttp: false,
    });
    await saveSecretFile(paths.configPath, `${JSON.stringify(agentConfig, null, 2)}\n`);
    await audit.record({
      actor,
      action: 'agent.register',
      target: target(server),
      metadata: { fingerprint, agentVersion: LATEST_AGENT_VERSION, hostname: os.hostname(), local: true },
    });
  }

  function isThisPanel(url) {
    try {
      const u = new URL(url);
      return isLoopback(u.hostname.replace(/^\[|\]$/g, '')) || u.hostname === 'localhost' || [config.publicUrl, config.envPublicUrl].filter(Boolean).some((address) => u.origin === new URL(address).origin);
    } catch {
      return false;
    }
  }

  return { connect };
}

// The agent on the panel's own server talks to the API directly over loopback
// (no proxy, no TLS needed: the traffic never leaves the machine).
export function localPanelUrl(config) {
  // HTTPS on the panel's port: the agent here uses the plain HTTP loopback
  // port instead, which never leaves the machine.
  if (config.loopbackPort) return `http://127.0.0.1:${config.loopbackPort}`;
  const host = config.host;
  if (!host || host === '0.0.0.0' || host === '::' || host === 'localhost' || isLoopback(host)) {
    return `http://${host === '::1' ? '[::1]' : '127.0.0.1'}:${config.port}`;
  }
  return `http://${host.includes(':') ? `[${host}]` : host}:${config.port}`;
}

// Runs scripts/install-agent.sh with the Node.js this process runs on, so the
// agent gets a Node.js new enough even when the system's own is older.
function defaultInstaller(args) {
  return new Promise((resolve, reject) => {
    const child = spawn('bash', [path.join(REPO_ROOT, 'scripts/install-agent.sh'), ...args], {
      stdio: 'inherit',
      env: { ...process.env, PATH: `${path.dirname(process.execPath)}:${process.env.PATH ?? '/usr/sbin:/usr/bin:/sbin:/bin'}` },
    });
    child.on('error', reject);
    child.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`The agent installer failed (exit code ${code})`))));
  });
}

// Whether everyone can read the agent's code down to the file manager's
// worker, which runs as each site's user. Missing files count as readable:
// the version check finds a missing install.
async function readableByAll(installDir) {
  const services = path.join(installDir, 'src', 'services');
  try {
    for (const dir of [installDir, path.join(installDir, 'src'), services]) {
      if (((await stat(dir)).mode & 0o005) !== 0o005) return false;
    }
    return ((await stat(path.join(services, 'fileWorker.js'))).mode & 0o004) !== 0;
  } catch {
    return true;
  }
}

async function readJson(file) {
  try {
    return JSON.parse(await readFile(file, 'utf8'));
  } catch {
    return null;
  }
}

function result(status, message, serverId = null) {
  return { status, message, serverId };
}

function target(server) {
  return { type: 'server', id: server.id, label: server.name };
}
