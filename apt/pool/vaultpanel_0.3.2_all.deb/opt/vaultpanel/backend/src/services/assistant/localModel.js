import { LOCAL_AI, LOCAL_AI_MODELS, PERMISSIONS } from '@vaultpanel/shared';
import { agentOperations, toPublicMetric } from '../../models/serverModel.js';
import { AppError } from '../../utils/errors.js';
import { fromJson, toJson } from '../../utils/json.js';

// The assistant's free model on the panel's own server: Ollama, installed,
// fed models and removed by the server's agent (LOCAL_AI_* operations), and
// reachable only from this machine. The panel reads what is installed from
// Ollama itself; what the last finished job reported is kept for when Ollama
// is not answering (stopped, or still starting).
const STATE_KEY = 'assistant.local_model';
export const LOCAL_AI_JOB_TYPES = Object.freeze(['LOCAL_AI_INSTALL', 'LOCAL_AI_REMOVE', 'LOCAL_AI_UNINSTALL']);

export function createLocalModelService({ db, logger, authorize, jobs, readSettings, fetchImpl = fetch, apiUrl = LOCAL_AI.apiUrl, panelUid = () => process.getuid?.() }) {
  async function localServer() {
    return db('servers').where({ is_local: true }).whereNull('deleted_at').first();
  }

  async function ollama(path) {
    const res = await fetchImpl(`${apiUrl}${path}`, { signal: AbortSignal.timeout(2000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  // What Ollama says now, or { running: false } when it does not answer.
  async function live() {
    try {
      const [version, tags] = await Promise.all([ollama('/api/version'), ollama('/api/tags')]);
      return { running: true, version: version?.version ?? null, models: (tags?.models ?? []).map((m) => ({ id: m.name ?? m.model, sizeBytes: m.size ?? null })) };
    } catch {
      return { running: false };
    }
  }

  async function savedState() {
    return fromJson((await db('settings').where({ key: STATE_KEY }).first())?.value, {}) ?? {};
  }

  // Why the model cannot be installed from the panel, or null.
  function problemWith(server) {
    if (!server) return 'The panel’s own server is not connected to the panel, so nothing can be installed on it from here.';
    if (server.status !== 'online') return `The panel’s own server (${server.name}) is ${server.status}. Its agent must be online to install the model.`;
    if (!agentOperations(server).includes('LOCAL_AI_INSTALL')) {
      return `The agent on the panel’s own server (v${server.agent_version ?? '?'}) cannot install the model yet. Update it on the server’s Overview tab.`;
    }
    return null;
  }

  async function status(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const server = await localServer();
    const [now, state, metric, job] = await Promise.all([
      live(),
      savedState(),
      server ? db('server_metrics').where({ server_id: server.id }).orderBy('collected_at', 'desc').first() : null,
      server ? db('jobs').where({ server_id: server.id }).whereIn('type', LOCAL_AI_JOB_TYPES).orderBy('created_at', 'desc').first('id', 'type', 'status', 'created_at') : null,
    ]);
    const m = toPublicMetric(metric);
    return {
      server: server ? { id: server.id, name: server.name, status: server.status } : null,
      problem: problemWith(server),
      installed: now.running || Boolean(state.installed),
      running: now.running,
      version: now.running ? now.version : (state.version ?? null),
      models: now.running ? now.models : (state.models ?? []),
      memory: m?.memoryTotalBytes ? { totalBytes: m.memoryTotalBytes, availableBytes: Math.max(0, m.memoryTotalBytes - (m.memoryUsedBytes ?? 0)) } : null,
      diskFreeBytes: m?.diskTotalBytes ? Math.max(0, m.diskTotalBytes - (m.diskUsedBytes ?? 0)) : null,
      lastJob: job ? { id: job.id, type: job.type, status: job.status } : null,
      catalog: LOCAL_AI_MODELS,
    };
  }

  async function requireServer() {
    const server = await localServer();
    const problem = problemWith(server);
    if (problem) throw new AppError(409, server ? 'LOCAL_MODEL_UNAVAILABLE' : 'LOCAL_SERVER_MISSING', problem);
    return server;
  }

  function catalogModel(id) {
    const model = LOCAL_AI_MODELS.find((m) => m.id === id);
    if (!model) throw new AppError(422, 'VALIDATION_ERROR', 'Some fields are invalid', [{ field: 'model', message: 'Choose a model from the list' }]);
    return model;
  }

  // The model the assistant answers with, when it is the one on this server.
  async function modelInUse() {
    const s = await readSettings();
    return s.provider === 'local' ? s.model : null;
  }

  // Installs Ollama when it is missing (or older than the agent's), then
  // downloads the model. Returns the job, which the page follows.
  async function install(actor, { model }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const def = catalogModel(model);
    const server = await requireServer();
    const uid = panelUid();
    if (!Number.isInteger(uid)) throw new AppError(409, 'LOCAL_MODEL_UNAVAILABLE', 'The model on this server needs the panel to run on Linux.');
    return jobs.create(actor, { serverId: server.id, type: 'LOCAL_AI_INSTALL', params: { model: def.id, panelUid: uid } }, { internal: true });
  }

  async function remove(actor, { model }) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    const def = catalogModel(model);
    if ((await modelInUse()) === def.id) {
      throw new AppError(409, 'LOCAL_MODEL_IN_USE', `The assistant answers with ${def.label}. Choose another model or provider and save, then remove it.`);
    }
    const server = await requireServer();
    return jobs.create(actor, { serverId: server.id, type: 'LOCAL_AI_REMOVE', params: { model: def.id } }, { internal: true });
  }

  async function uninstall(actor) {
    await authorize(actor, PERMISSIONS.SETTINGS_MANAGE);
    if (await modelInUse()) {
      throw new AppError(409, 'LOCAL_MODEL_IN_USE', 'The assistant answers with the model on this server. Choose another provider and save, then remove it.');
    }
    const server = await requireServer();
    return jobs.create(actor, { serverId: server.id, type: 'LOCAL_AI_UNINSTALL', params: {} }, { internal: true });
  }

  // Keeps what the agent reported, for when Ollama is not answering.
  async function onJobFinished(job, result) {
    if (!LOCAL_AI_JOB_TYPES.includes(job.type) || result.status !== 'succeeded') return;
    const output = result.output ?? {};
    const state =
      job.type === 'LOCAL_AI_UNINSTALL'
        ? { installed: false, version: null, models: [] }
        : { installed: true, version: output.version ?? null, models: Array.isArray(output.models) ? output.models : [] };
    const now = new Date();
    await db('settings')
      .insert({ key: STATE_KEY, value: toJson({ ...state, updatedAt: now.toISOString() }), is_secret: false, updated_by: null, updated_at: now })
      .onConflict('key')
      .merge(['value', 'updated_by', 'updated_at']);
    logger?.info({ jobId: job.id, type: job.type }, 'assistant: the local model changed');
  }

  return { status, install, remove, uninstall, onJobFinished };
}
