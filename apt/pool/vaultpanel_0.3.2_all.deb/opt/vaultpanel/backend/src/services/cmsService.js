import { randomBytes, randomUUID } from 'node:crypto';
import { CMS_APPS, CMS_BUSY_STATUSES, CMS_RESERVED_FOLDERS, PERMISSIONS, phpAtLeast } from '@vaultpanel/shared';
import { toPublicCmsInstall } from '../models/cmsModel.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson } from '../utils/json.js';
import { getSetting } from '../models/settingModel.js';
import { agentOperations } from '../models/serverModel.js';
import { paginate } from '../utils/pagination.js';
import { systemActor } from './actor.js';
import { generatePassword } from './databaseService.js';
import { assertOwned, scopeQuery } from './tenancy.js';

// The app installer: WordPress, Joomla, Drupal or Laravel in a PHP website,
// like Softaculous. An install is a small chain of jobs:
//
//   1. the website (when a new one is made with it) and the app's database
//      and user are created the usual way, so they show on their own pages
//      and count against a hosting customer's plan;
//   2. once they all exist (each job's result arrives here), CMS_INSTALL
//      puts the app in the site and runs its installer;
//   3. Drupal and Laravel then get the site's document root pointed at their
//      public folder, as an ordinary website change.
//
// The admin password is shown once, in the answer to the install request.
// Until the install job is queued, its parameters (with the passwords) are
// kept sealed with the panel's secret key; after that only the job has them,
// and the job's copy is redacted when it finishes.

export const CMS_AGENT_VERSION = '0.20.0';

export function createCmsService({ db, config, logger, audit, authorize, jobs, websites, databases, quotas }) {
  const box = createSecretBox(deriveKey(config.secretKey, 'cms-install'));
  const installer = () => systemActor('app installer');

  function installQuery() {
    return db('cms_installs as c')
      .join('websites as w', 'w.id', 'c.website_id')
      .leftJoin('website_domains as d', (j) => j.on('d.website_id', 'w.id').andOn('d.is_primary', db.raw('?', [true])))
      .leftJoin('databases as dbs', 'dbs.id', 'c.database_id')
      .leftJoin('database_users as u', 'u.id', 'c.database_user_id')
      .join('servers as s', 's.id', 'c.server_id')
      .whereNull('c.deleted_at')
      .select('c.*', 'w.name as website_name', 'd.domain as website_domain', 's.name as server_name', 'dbs.name as database_name', 'dbs.deleted_at as database_deleted_at', 'u.username as database_username', 'u.deleted_at as database_user_deleted_at');
  }

  async function load(id) {
    const row = await installQuery().where('c.id', id).first();
    if (!row) throw notFound('Installed app not found');
    return row;
  }

  const detail = async (id) => toPublicCmsInstall(await load(id));

  function catalog() {
    return { apps: Object.entries(CMS_APPS).map(([key, app]) => ({ key, ...app })) };
  }

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    const q = scopeQuery(installQuery(), actor, 'c.customer_id');
    if (query.websiteId) q.where('c.website_id', query.websiteId);
    if (query.serverId) q.where('c.server_id', query.serverId);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'c.created_at' });
    return { items: rows.map(toPublicCmsInstall), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.WEBSITES_READ);
    return detail(id);
  }

  // ---- Installing -----------------------------------------------------------

  // The website an app goes into, checked before anything is created.
  async function checkWebsite(actor, websiteId) {
    const row = await db('websites').where({ id: websiteId }).whereNull('deleted_at').first();
    if (!row) throw validationError([{ field: 'websiteId', message: 'Website not found' }]);
    assertOwned(actor, row.customer_id, 'Website not found');
    if (row.type !== 'php') throw validationError([{ field: 'websiteId', message: 'Apps go in a PHP website. Change the site type to PHP on its Settings tab first.' }]);
    if (!row.provisioned_at || ['creating', 'deleting', 'failed'].includes(row.status)) {
      throw new AppError(409, 'WEBSITE_NOT_READY', 'This website is not ready yet. Wait for it to be created.');
    }
    const panel = fromJson(await getSetting(db, 'panel.domain'), null);
    if (panel?.websiteId === row.id) throw new AppError(409, 'PANEL_WEBSITE', 'This website serves VaultPanel itself');
    const owner = await db('applications').where({ website_id: row.id }).whereNull('deleted_at').first('name');
    if (owner) throw new AppError(409, 'WEBSITE_OWNED_BY_APP', `This website serves the app ${owner.name}`);
    return row;
  }

  function requirePhp(phpVersion, appKey) {
    const app = CMS_APPS[appKey];
    if (!phpVersion || !phpAtLeast(phpVersion, app.minPhp)) {
      throw new AppError(409, 'CMS_PHP_TOO_OLD', `${app.label} needs PHP ${app.minPhp} or newer${phpVersion ? `; this site runs PHP ${phpVersion}` : ''}. Switch the site's PHP version on its Overview first.`);
    }
  }

  // Where the app's files go, the folder it answers at and its address.
  async function placement(website, appKey, rawPath) {
    const app = CMS_APPS[appKey];
    const path = (rawPath ?? '').replace(/^\/+|\/+$/g, '');
    const others = await db('cms_installs').where({ website_id: website.id }).whereNull('deleted_at').whereNot('status', 'failed').select('app', 'directory');
    if (others.some((o) => CMS_APPS[o.app]?.kind === 'project')) {
      throw new AppError(409, 'CMS_SITE_TAKEN', 'A Drupal or Laravel app already uses this website’s document root. Remove it first, or use another website.');
    }
    const domain = await db('website_domains').where({ website_id: website.id, is_primary: true }).first('domain');
    const cert = await db('ssl_certificates').where({ website_id: website.id, status: 'active' }).first('id');
    const origin = `${cert ? 'https' : 'http'}://${domain?.domain}`;
    if (app.kind === 'project') {
      if (others.length) throw new AppError(409, 'CMS_SITE_TAKEN', `${app.label} takes over the website’s document root, and this website already has an app. Use another website.`);
      const folder = path || app.defaultFolder;
      if (folder.includes('/') || CMS_RESERVED_FOLDERS.includes(folder) || folder === website.document_root.split('/')[0]) {
        throw validationError([{ field: 'path', message: `Choose a folder name for the ${app.label} project other than ${folder}` }]);
      }
      return { directory: folder, urlPath: '', url: origin };
    }
    const directory = path ? `${website.document_root}/${path}` : website.document_root;
    const clash = others.find((o) => o.directory === directory || directory.startsWith(`${o.directory}/`) || o.directory.startsWith(`${directory}/`));
    if (clash) {
      throw validationError([{ field: 'path', message: `${CMS_APPS[clash.app]?.label ?? 'Another app'} is already installed ${clash.directory === website.document_root ? 'at the site’s root' : `in /${clash.directory.slice(website.document_root.length + 1)}`}. Choose another folder.` }]);
    }
    return { directory, urlPath: path, url: path ? `${origin}/${path}` : origin };
  }

  // A database name for the app: the site's name, the app and a random part.
  function databaseName(website, appKey) {
    const base = website.name.replace(/-/g, '_').slice(0, 20);
    return `${base}_${appKey.slice(0, 2)}${randomBytes(3).toString('hex')}`.slice(0, 32);
  }

  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const app = CMS_APPS[input.app];
    if (!app) throw validationError([{ field: 'app', message: 'Choose an app' }]);

    // A hosting customer's plan must have room for everything the install
    // makes, checked before the first of them is made.
    if (actor.customerId && quotas) {
      await quotas.check(actor.customerId, input.websiteId ? ['databases', 'databaseUsers'] : ['websites', 'databases', 'databaseUsers']);
    }

    // 1. The website: an existing one, or a new PHP website made now.
    let website;
    let websiteJob = null;
    let where;
    if (input.websiteId) {
      website = await checkWebsite(actor, input.websiteId);
      requirePhp(website.php_version, input.app);
      await requireAgent(website.server_id);
      where = await placement(website, input.app, input.path);
    } else {
      const fresh = input.newWebsite;
      requirePhp(fresh.phpVersion, input.app);
      await requireAgent(fresh.serverId);
      const app = CMS_APPS[input.app];
      if (app.kind === 'project' && [...CMS_RESERVED_FOLDERS, 'public'].includes(input.path || app.defaultFolder)) {
        throw validationError([{ field: 'path', message: `Choose a folder name for the ${app.label} project other than ${input.path}` }]);
      }
      const made = await websites.create(actor, { serverId: fresh.serverId, name: fresh.name, type: 'php', domains: fresh.domains, documentRoot: 'public', phpVersion: fresh.phpVersion });
      website = await db('websites').where({ id: made.website.id }).first();
      websiteJob = made.job;
      where = await placement(website, input.app, input.path);
    }

    // 2. Its database and database user.
    const name = databaseName(website, input.app);
    const made = await databases.create(actor, { serverId: website.server_id, name, createUser: true, username: name, privileges: 'all', addToAppEnv: false });
    if (!made.user || !made.password) {
      throw new AppError(500, 'CMS_DATABASE_FAILED', `The database ${name} was created but its user could not be. Delete it on the Databases page and try again.`);
    }
    // Linked to the website, so its backups can include the database.
    await db('databases').where({ id: made.database.id }).update({ website_id: website.id });
    // Staff installing for a hosting customer: the database is the customer's.
    if (!actor.customerId && website.customer_id) {
      await db('databases').where({ id: made.database.id }).update({ customer_id: website.customer_id });
      await db('database_users').where({ id: made.user.id }).update({ customer_id: website.customer_id });
    }

    // 3. The install itself, queued once all of that exists.
    const adminPassword = app.admin ? (input.adminPassword || generatePassword(20)) : null;
    const adminEmail = app.admin ? (input.adminEmail || (/@/.test(actor.label ?? '') ? actor.label : `admin@${where.url.split('/')[2]}`)) : null;
    const adminUser = app.admin ? (input.adminUser || 'siteadmin') : null;
    const title = input.title || (await db('website_domains').where({ website_id: website.id, is_primary: true }).first('domain'))?.domain || website.name;
    const params = {
      app: input.app,
      site: website.name,
      phpVersion: website.php_version,
      directory: where.directory,
      url: where.url,
      databaseName: name,
      databaseUser: name,
      databasePassword: made.password,
      title,
      ...(app.admin ? { adminUser, adminEmail, adminPassword } : {}),
    };
    const id = randomUUID();
    const now = new Date();
    await db('cms_installs').insert({
      id,
      server_id: website.server_id,
      website_id: website.id,
      customer_id: website.customer_id ?? null,
      app: input.app,
      directory: where.directory,
      url_path: where.urlPath,
      url: where.url,
      title,
      admin_user: adminUser,
      admin_email: adminEmail,
      database_id: made.database.id,
      database_user_id: made.user.id,
      status: 'waiting',
      pending_params_encrypted: box.seal(JSON.stringify(params)),
      created_by: actor.type === 'user' ? actor.id : null,
      created_at: now,
      updated_at: now,
    });
    await audit.record({
      actor,
      action: 'cms.install',
      target: { type: 'cms_install', id, label: `${app.label} on ${website.name}` },
      metadata: { websiteId: website.id, app: input.app, directory: where.directory, databaseId: made.database.id, websiteJobId: websiteJob?.id ?? null },
    });
    await advance(id);
    const install = await detail(id);
    return {
      install,
      // Shown once: the panel does not keep the admin password.
      admin: app.admin ? { url: install.adminUrl, username: adminUser, password: adminPassword, email: adminEmail } : null,
      database: { name, username: name },
      jobs: { website: websiteJob, database: made.job },
    };
  }

  async function requireAgent(serverId) {
    const server = await db('servers').where({ id: serverId }).whereNull('deleted_at').first();
    if (!server) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status !== 'pending' && !agentOperations(server).includes('CMS_INSTALL')) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} (v${server.agent_version ?? '?'}) cannot install apps. Update the agent to ${CMS_AGENT_VERSION} or newer first.`);
    }
  }

  // Queues the install job once the website, database and user all exist,
  // or fails the install when one of them could not be made.
  async function advance(id) {
    const row = await db('cms_installs').where({ id, status: 'waiting' }).whereNull('deleted_at').first();
    if (!row) return;
    const website = await db('websites').where({ id: row.website_id }).first();
    const database = await db('databases').where({ id: row.database_id }).first();
    const user = await db('database_users').where({ id: row.database_user_id }).first();
    if (!website || website.deleted_at) return fail(row, 'WEBSITE_GONE', 'The website was deleted');
    if (website.status === 'failed' && !website.provisioned_at) return fail(row, 'WEBSITE_FAILED', `The website could not be created: ${website.last_error ?? 'see its page'}`);
    if (!database || database.deleted_at || database.status === 'failed') return fail(row, 'CMS_DATABASE_FAILED', `The database could not be created: ${database?.last_error ?? 'it was deleted'}`);
    if (!user || user.deleted_at || user.status === 'failed') return fail(row, 'CMS_DATABASE_FAILED', `The database user could not be created: ${user?.last_error ?? 'it was deleted'}`);
    if (!website.provisioned_at || database.status !== 'active' || user.status !== 'active') return;

    const claimed = await db('cms_installs').where({ id, status: 'waiting' }).update({ status: 'installing', updated_at: new Date() });
    if (!claimed) return;
    let params;
    try {
      params = JSON.parse(box.open(row.pending_params_encrypted));
      // The site's PHP version may have changed while it waited.
      params.phpVersion = website.php_version;
      const job = await jobs.create(installer(), { serverId: row.server_id, type: 'CMS_INSTALL', params, resource: { type: 'cms_install', id } }, { internal: true });
      await db('cms_installs').where({ id }).update({ last_job_id: job.id, pending_params_encrypted: null, updated_at: new Date() });
    } catch (err) {
      logger.warn({ err, installId: id }, 'could not queue the app install');
      await fail({ ...row, status: 'installing' }, err.code ?? 'CMS_INSTALL_FAILED', err.message);
    }
  }

  async function fail(row, code, message) {
    await db('cms_installs')
      .where({ id: row.id })
      .whereIn('status', ['waiting', 'installing'])
      .update({ status: 'failed', pending_params_encrypted: null, last_error_code: String(code).slice(0, 64), last_error: message, updated_at: new Date() });
  }

  // ---- Removing -------------------------------------------------------------

  async function remove(actor, id, { removeDatabase = false } = {}) {
    await authorize(actor, PERMISSIONS.WEBSITES_MANAGE);
    const row = await load(id);
    if (CMS_BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'CMS_BUSY', row.status === 'removing' ? 'This app is already being removed' : 'This app is still being installed. Wait for it to finish.', { jobId: row.last_job_id });
    }
    const website = await db('websites').where({ id: row.website_id }).first();
    const warnings = [];
    if (removeDatabase) {
      await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
      if (row.database_id && !row.database_deleted_at) {
        await databases.remove(actor, row.database_id).catch((err) => warnings.push(`The database was not deleted: ${err.message}`));
      }
      if (row.database_user_id && !row.database_user_deleted_at) {
        await databases.removeUser(actor, row.database_user_id).catch((err) => warnings.push(`The database user was not deleted: ${err.message}`));
      }
    }
    let job = null;
    if (row.status === 'failed' || !website || website.deleted_at) {
      // A failed install left nothing in the site.
      await markRemoved(id);
    } else {
      const claimed = await db('cms_installs').where({ id, status: row.status }).update({ status: 'removing', last_error: null, last_error_code: null, updated_at: new Date() });
      if (!claimed) throw new AppError(409, 'CMS_BUSY', 'Another change to this app is running');
      try {
        job = await jobs.create(
          actor,
          { serverId: row.server_id, type: 'CMS_REMOVE', params: { site: website.name, directory: row.directory, keepFolder: row.directory === website.document_root }, resource: { type: 'cms_install', id } },
          { internal: true },
        );
      } catch (err) {
        await db('cms_installs').where({ id }).update({ status: row.status, updated_at: new Date() });
        throw err;
      }
      await db('cms_installs').where({ id }).update({ last_job_id: job.id });
    }
    await audit.record({ actor, action: 'cms.remove', target: { type: 'cms_install', id, label: `${CMS_APPS[row.app]?.label ?? row.app} on ${row.website_name}` }, metadata: { removeDatabase, jobId: job?.id ?? null } });
    return { install: job ? await detail(id) : null, job, warnings };
  }

  async function markRemoved(id) {
    await db('cms_installs').where({ id }).update({ status: 'failed', pending_params_encrypted: null, deleted_at: new Date(), updated_at: new Date() });
  }

  // Points the website's document root at a folder (Drupal's web/, Laravel's
  // public/, or back). Returns an error message instead of throwing.
  async function setDocumentRoot(websiteId, documentRoot) {
    try {
      await websites.update(installer(), websiteId, { documentRoot });
      return null;
    } catch (err) {
      logger.warn({ err, websiteId, documentRoot }, 'could not change the document root for an app');
      return err.message;
    }
  }

  // ---- Job results ------------------------------------------------------------

  async function handleJobFinished(job, { status, output, error }) {
    // A website, database or user an install waits for is ready (or failed).
    const column = { website: 'website_id', database: 'database_id', database_user: 'database_user_id' }[job.resource_type];
    if (column) {
      if (job.resource_type === 'website' && job.type === 'DELETE_SITE' && status === 'succeeded') {
        await db('cms_installs').where({ website_id: job.resource_id }).whereNull('deleted_at').update({ status: 'failed', deleted_at: new Date(), updated_at: new Date() });
        return;
      }
      const waiting = await db('cms_installs').where({ [column]: job.resource_id, status: 'waiting' }).whereNull('deleted_at').select('id');
      for (const { id } of waiting) await advance(id);
      return;
    }
    if (job.resource_type !== 'cms_install') return;
    const row = await db('cms_installs').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const failure = ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' };

    if (job.type === 'CMS_INSTALL') {
      if (!ok) {
        await db('cms_installs').where({ id: row.id }).update({ status: 'failed', ...failure, updated_at: now });
        return;
      }
      await db('cms_installs').where({ id: row.id }).update({ status: 'installed', version: output?.version ?? null, installed_at: now, ...failure, updated_at: now });
      if (output?.publicDirectory) {
        const website = await db('websites').where({ id: row.website_id }).first('document_root');
        await db('cms_installs').where({ id: row.id }).update({ previous_document_root: website?.document_root ?? 'public' });
        const problem = await setDocumentRoot(row.website_id, output.publicDirectory);
        if (problem) {
          await db('cms_installs').where({ id: row.id }).update({
            last_error_code: 'DOCUMENT_ROOT_NOT_SET',
            last_error: `The app is installed, but the website still serves its old folder (${problem}). Set the document root to ${output.publicDirectory} on the website's Settings tab.`,
          });
        }
      }
    } else if (job.type === 'CMS_REMOVE') {
      if (!ok) {
        await db('cms_installs').where({ id: row.id }).update({ status: 'installed', ...failure, updated_at: now });
        return;
      }
      if (row.previous_document_root) await setDocumentRoot(row.website_id, row.previous_document_root);
      await markRemoved(row.id);
    }
  }
  jobs.onFinished(handleJobFinished);

  return { catalog, list, get, create, remove, handleJobFinished };
}
