import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { z } from 'zod';
import { PERMISSIONS } from '@vaultpanel/shared';
import { AppError, notFound } from '../utils/errors.js';
import { paginate } from '../utils/pagination.js';
import { toIso } from '../utils/time.js';

// Recorded terminal sessions.
//
// The panel already passes every byte between the browser and the server's
// agent, so it records there: no agent change. Each session gets a row in
// terminal_sessions, and, while recording is on, an asciicast v2 file
// (https://docs.asciinema.org/manual/asciicast/v2/) in
// VAULTPANEL_DATA_DIR/terminal-recordings: a JSON header, then one
// [seconds, "o" | "i" | "r", data] line per output, input or resize. The
// panel's player replays it, and asciinema can play a downloaded copy.
//
// What was typed is recorded only when "record input" is on: passwords
// typed at a prompt that does not echo them (sudo, mysql -p) would be kept.
// Recordings can hold secrets shown on screen, so only owners (the people
// who may open a terminal) can see them, and files are readable by the
// panel's user alone.

export const RECORDING_SETTING = 'terminal.recording';
export const DEFAULT_RECORDING = Object.freeze({ enabled: true, recordInput: false, retentionDays: 90, maxSizeMb: 50 });

export const recordingSettingsBody = z.object({
  enabled: z.boolean(),
  recordInput: z.boolean(),
  retentionDays: z.coerce.number().int().min(1).max(3650),
  maxSizeMb: z.coerce.number().int().min(1).max(1024),
});

const SETTINGS_CACHE_MS = 30_000;

export function createTerminalRecordingService({ db, config, logger, audit, authorize, now = () => Date.now() }) {
  const dir = path.join(config.dataDir, 'terminal-recordings');
  let cache = { at: 0, value: null };

  const fileFor = (id) => path.join(dir, `${id}.cast`);

  async function settings() {
    if (cache.value && now() - cache.at < SETTINGS_CACHE_MS) return cache.value;
    const row = await db('settings').where({ key: RECORDING_SETTING }).first();
    let value = { ...DEFAULT_RECORDING };
    if (row?.value) {
      try {
        value = { ...value, ...recordingSettingsBody.partial().parse(JSON.parse(row.value)) };
      } catch {
        // keep the defaults
      }
    }
    cache = { at: now(), value };
    return value;
  }

  async function getSettings(actor) {
    await authorize(actor, PERMISSIONS.SERVERS_TERMINAL);
    return settings();
  }

  async function updateSettings(actor, body) {
    await authorize(actor, PERMISSIONS.SERVERS_TERMINAL);
    const before = await settings();
    const next = recordingSettingsBody.parse(body);
    await db('settings')
      .insert({ key: RECORDING_SETTING, value: JSON.stringify(next), is_secret: false, updated_by: actor.id, updated_at: new Date(now()) })
      .onConflict('key')
      .merge(['value', 'updated_by', 'updated_at']);
    cache = { at: now(), value: next };
    await audit.record({ actor, action: 'terminal.recording.settings', target: { type: 'setting', id: RECORDING_SETTING, label: 'Terminal recording' }, metadata: { before, after: next } });
    return next;
  }

  // Called by the terminal service when a session opens. Returns the
  // session's recorder; every method is safe to call when not recording.
  async function start({ id, serverId, serverName, actor, cols, rows }) {
    const opts = await settings();
    const mode = opts.enabled ? (opts.recordInput ? 'output_input' : 'output') : 'off';
    const startedAt = now();
    await db('terminal_sessions').insert({
      id,
      server_id: serverId,
      server_name: serverName?.slice(0, 255) ?? null,
      user_id: actor.type === 'user' ? actor.id : null,
      user_label: actor.label?.slice(0, 255) ?? null,
      ip: actor.ip?.slice(0, 64) ?? null,
      cols,
      rows,
      started_at: new Date(startedAt),
      recording: mode,
    });

    let stream = null;
    let bytes = 0;
    let truncated = false;
    let closed = false;
    const limit = opts.maxSizeMb * 1024 * 1024;
    const decoder = new StringDecoder('utf8');
    if (mode !== 'off') {
      await mkdir(dir, { recursive: true, mode: 0o700 });
      stream = createWriteStream(fileFor(id), { flags: 'wx', mode: 0o600 });
      stream.on('error', (err) => {
        logger.warn({ err, sessionId: id }, 'terminal recording stopped');
        stream = null;
      });
      const header = { version: 2, width: cols, height: rows, timestamp: Math.floor(startedAt / 1000), title: `${serverName ?? 'server'}, ${actor.label ?? ''}`.trim(), env: { TERM: 'xterm-256color', SHELL: '/bin/bash' } };
      write(`${JSON.stringify(header)}\n`);
    }

    function write(line) {
      if (!stream || closed) return;
      const size = Buffer.byteLength(line);
      if (bytes + size > limit) {
        truncated = true;
        stream.end();
        stream = null;
        return;
      }
      bytes += size;
      stream.write(line);
    }
    const event = (type, data) => write(`${JSON.stringify([Number(((now() - startedAt) / 1000).toFixed(3)), type, data])}\n`);

    return {
      mode,
      output(buffer) {
        if (!stream) return;
        const text = decoder.write(buffer);
        if (text) event('o', text);
      },
      input(text) {
        if (mode === 'output_input' && stream) event('i', text);
      },
      resize(newCols, newRows) {
        if (stream) event('r', `${newCols}x${newRows}`);
      },
      async finish({ exitCode = null, reason = null, outputBytes = 0 } = {}) {
        if (closed) return;
        if (stream) {
          const rest = decoder.end();
          if (rest) event('o', rest);
        }
        closed = true;
        if (stream) await new Promise((resolve) => stream.end(resolve));
        stream = null;
        await db('terminal_sessions')
          .where({ id })
          .update({
            ended_at: new Date(now()),
            exit_code: Number.isInteger(exitCode) ? exitCode : null,
            end_reason: reason?.slice(0, 300) ?? null,
            output_bytes: outputBytes,
            recording_bytes: bytes,
            recording_truncated: truncated,
          })
          .catch((err) => logger.warn({ err, sessionId: id }, 'could not save the terminal session'));
      },
    };
  }

  async function list(actor, { page = 1, pageSize = 25, serverId, userId } = {}) {
    await authorize(actor, PERMISSIONS.SERVERS_TERMINAL);
    const query = db('terminal_sessions').select('*');
    if (serverId) query.where({ server_id: serverId });
    if (userId) query.where({ user_id: userId });
    const { rows, pagination } = await paginate(query, { page, pageSize, sort: 'started_at', order: 'desc' });
    return { items: rows.map(toPublic), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.SERVERS_TERMINAL);
    const row = await db('terminal_sessions').where({ id }).first();
    if (!row) throw notFound('Terminal session not found');
    return toPublic(row);
  }

  // The recording file, for the player and for download. Watching one is
  // in the audit log, as it may show what was on someone's screen.
  async function openRecording(actor, id, { download = false } = {}) {
    const session = await get(actor, id);
    if (session.recording === 'off') throw notFound('This session was not recorded');
    const file = fileFor(id);
    const info = await stat(file).catch(() => null);
    if (!info) throw notFound('The recording file is gone (removed after the retention period, or deleted)');
    await audit.record({ actor, action: download ? 'terminal.recording.download' : 'terminal.recording.view', target: { type: 'terminal_session', id, label: `${session.serverName} (${session.userLabel ?? '?'})` } });
    return { stream: createReadStream(file), size: info.size, filename: `terminal-${session.serverName ?? 'server'}-${session.startedAt.replace(/[:.]/g, '-')}.cast` };
  }

  async function remove(actor, id) {
    const session = await get(actor, id);
    if (!session.endedAt) {
      throw new AppError(409, 'SESSION_OPEN', 'This session is still open; close it first');
    }
    await rm(fileFor(id), { force: true });
    await db('terminal_sessions').where({ id }).delete();
    await audit.record({ actor, action: 'terminal.recording.delete', target: { type: 'terminal_session', id, label: `${session.serverName} (${session.userLabel ?? '?'})` } });
  }

  // Removes sessions and recordings older than the retention period. Run by
  // the worker's maintenance loop.
  async function prune(at = new Date(now())) {
    const { retentionDays } = await settings();
    const cutoff = new Date(at.getTime() - retentionDays * 86_400_000);
    const old = await db('terminal_sessions').where('started_at', '<', cutoff).whereNotNull('ended_at').limit(500).pluck('id');
    for (const id of old) await rm(fileFor(id), { force: true }).catch(() => {});
    if (old.length) await db('terminal_sessions').whereIn('id', old).delete();
    return old.length;
  }

  // Sessions the panel lost track of (it restarted while they were open).
  async function closeOrphans(reason = 'The panel restarted') {
    return db('terminal_sessions').whereNull('ended_at').update({ ended_at: new Date(now()), end_reason: reason });
  }

  return { settings, getSettings, updateSettings, start, list, get, openRecording, remove, prune, closeOrphans };
}

function toPublic(row) {
  const started = toIso(row.started_at);
  const ended = toIso(row.ended_at);
  return {
    id: row.id,
    serverId: row.server_id,
    serverName: row.server_name,
    userId: row.user_id,
    userLabel: row.user_label,
    ip: row.ip,
    cols: row.cols,
    rows: row.rows,
    startedAt: started,
    endedAt: ended,
    seconds: ended ? Math.max(0, Math.round((Date.parse(ended) - Date.parse(started)) / 1000)) : null,
    exitCode: row.exit_code,
    endReason: row.end_reason,
    outputBytes: Number(row.output_bytes ?? 0),
    recording: row.recording,
    recordingBytes: Number(row.recording_bytes ?? 0),
    recordingTruncated: Boolean(row.recording_truncated),
  };
}
