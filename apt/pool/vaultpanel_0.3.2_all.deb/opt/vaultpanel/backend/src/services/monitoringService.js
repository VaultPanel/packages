import { z } from 'zod';
import { PERMISSIONS } from '@vaultpanel/shared';
import { toPublicMetric, toPublicServer } from '../models/serverModel.js';

export const fleetServicesQuery = z.object({
  search: z.string().trim().max(100).optional(),
  state: z.enum(['all', 'running', 'problem']).default('all'),
});

// Fleet-wide views: every server's health at a glance, and every watched
// service across servers. Reads only what agents already report.
export function createMonitoringService({ db, authorize, metrics, alerts }) {
  async function overview(actor) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const rows = await db('servers').whereNull('deleted_at').orderBy('name');
    const ids = rows.map((r) => r.id);
    const canSeeAlerts = actor.permissions.includes(PERMISSIONS.ALERTS_READ);
    const [latest, trends, firing] = await Promise.all([
      metrics.latest(ids),
      metrics.sparklines(ids.filter((id, i) => rows[i].status !== 'pending')),
      canSeeAlerts ? alerts.firingByServer(ids) : Promise.resolve(null),
    ]);
    const items = rows.map((row) => {
      const server = toPublicServer(row);
      return {
        id: server.id,
        name: server.name,
        status: server.status,
        hostname: server.hostname,
        cpuCores: server.cpuCores,
        lastSeenAt: server.lastSeenAt,
        latestMetrics: toPublicMetric(latest[row.id]),
        fullestFilesystem: fullest(server.filesystems),
        services: {
          total: server.services.length,
          problems: server.services.filter(isServiceProblem).length,
        },
        trend: trends[row.id] ?? [],
        firingAlerts: firing ? (firing[row.id] ?? { warning: 0, critical: 0 }) : null,
      };
    });
    const byStatus = { pending: 0, online: 0, offline: 0, disabled: 0 };
    for (const s of items) byStatus[s.status] += 1;
    return { items, totals: { servers: items.length, byStatus } };
  }

  async function services(actor, query) {
    await authorize(actor, PERMISSIONS.SERVERS_READ);
    const rows = await db('servers').whereNull('deleted_at').whereNot('status', 'pending').orderBy('name');
    const term = query.search?.toLowerCase();
    const items = [];
    for (const row of rows) {
      const server = toPublicServer(row);
      for (const service of server.services) {
        const problem = isServiceProblem(service);
        if (query.state === 'running' && service.active !== 'active') continue;
        if (query.state === 'problem' && !problem) continue;
        if (term && !service.name.toLowerCase().includes(term) && !server.name.toLowerCase().includes(term)) continue;
        items.push({
          ...service,
          problem,
          server: { id: server.id, name: server.name, status: server.status, lastSeenAt: server.lastSeenAt },
        });
      }
    }
    return { items };
  }

  return { overview, services };
}

// Failed, or stopped although it is enabled to start at boot.
export function isServiceProblem(service) {
  return service.active === 'failed' || (service.active === 'inactive' && service.enabled === 'enabled');
}

function fullest(filesystems) {
  let best = null;
  for (const f of filesystems) {
    const percent = f.totalBytes ? (f.usedBytes / f.totalBytes) * 100 : 0;
    if (!best || percent > best.percent) best = { mount: f.mount, percent, usedBytes: f.usedBytes, totalBytes: f.totalBytes };
  }
  return best;
}
