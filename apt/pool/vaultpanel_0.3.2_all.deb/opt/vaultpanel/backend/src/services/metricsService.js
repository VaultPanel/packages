import { toPublicMetric } from '../models/serverModel.js';
import { getSetting } from '../models/settingModel.js';

// Ranges up to a day read raw samples (one every ~15 seconds); longer ranges
// read hourly averages, which are kept much longer than raw samples.
export const METRIC_RANGES = {
  '1h': { seconds: 3600, source: 'raw' },
  '6h': { seconds: 6 * 3600, source: 'raw' },
  '24h': { seconds: 24 * 3600, source: 'raw' },
  '7d': { seconds: 7 * 86_400, source: 'hourly' },
  '30d': { seconds: 30 * 86_400, source: 'hourly' },
  '90d': { seconds: 90 * 86_400, source: 'hourly' },
};
const MAX_POINTS = 240;
const HOUR_MS = 3_600_000;
// Bounds the work one maintenance run does when catching up.
const MAX_HOURS_PER_RUN = 24;
export const ROLLUP_SETTING = 'metrics.rolled_up_until';

const AVERAGED = [
  'cpu_percent',
  'load_1',
  'load_5',
  'load_15',
  'memory_used_bytes',
  'swap_used_bytes',
  'disk_used_bytes',
  'net_rx_bytes_per_sec',
  'net_tx_bytes_per_sec',
  'process_count',
];
const MAXED = ['memory_total_bytes', 'swap_total_bytes', 'disk_total_bytes'];
const INTEGER_COLUMNS = new Set([
  'memory_used_bytes',
  'swap_used_bytes',
  'disk_used_bytes',
  'net_rx_bytes_per_sec',
  'net_tx_bytes_per_sec',
  'process_count',
]);

export function createMetricsService({ db, config }) {
  async function history(serverId, range) {
    const { seconds, source } = METRIC_RANGES[range];
    const since = new Date(Date.now() - seconds * 1000);
    if (source === 'hourly') {
      const rows = await db('server_metrics_hourly')
        .where({ server_id: serverId })
        .where('hour_start', '>=', since)
        .orderBy('hour_start');
      return { range, resolution: 'hour', points: rows.map(toPublicHourlyMetric) };
    }
    const rows = await db('server_metrics').where({ server_id: serverId }).where('collected_at', '>=', since).orderBy('collected_at');
    return { range, resolution: 'raw', points: downsample(rows.map(toPublicMetric), MAX_POINTS) };
  }

  // Averages every completed hour of raw samples into server_metrics_hourly.
  // Progress is stored in a setting, so each hour is rolled up once; the
  // upsert makes a repeat harmless.
  async function rollup(now = new Date()) {
    const currentHour = floorHour(now);
    const stored = await getSetting(db, ROLLUP_SETTING);
    const earliest = floorHour(new Date(now.getTime() - config.metricsRetentionDays * 86_400_000));
    let hour = stored ? new Date(stored) : earliest;
    if (hour < earliest) hour = earliest;
    let hours = 0;
    while (hour < currentHour && hours < MAX_HOURS_PER_RUN) {
      await rollupHour(hour);
      hour = new Date(hour.getTime() + HOUR_MS);
      hours += 1;
      await db('settings')
        .insert({ key: ROLLUP_SETTING, value: hour.toISOString() })
        .onConflict('key')
        .merge(['value', 'updated_at']);
    }
    return hours;
  }

  async function rollupHour(hourStart) {
    const hourEnd = new Date(hourStart.getTime() + HOUR_MS);
    const rows = await db('server_metrics')
      .where('collected_at', '>=', hourStart)
      .where('collected_at', '<', hourEnd)
      .groupBy('server_id')
      .select(
        'server_id',
        db.raw('count(*) as samples'),
        db.raw('max(cpu_percent) as cpu_percent_max'),
        ...AVERAGED.map((c) => db.raw(`avg(${c}) as ${c}`)),
        ...MAXED.map((c) => db.raw(`max(${c}) as ${c}`)),
      );
    if (!rows.length) return;
    const records = rows.map((r) => {
      const record = { server_id: r.server_id, hour_start: hourStart, samples: Number(r.samples) };
      for (const column of ['cpu_percent_max', ...AVERAGED, ...MAXED]) {
        const value = r[column] === null ? null : Number(r[column]);
        record[column] = value === null ? null : INTEGER_COLUMNS.has(column) || MAXED.includes(column) ? Math.round(value) : round2(value);
      }
      return record;
    });
    await db('server_metrics_hourly').insert(records).onConflict(['server_id', 'hour_start']).merge();
  }

  async function prune(now = new Date()) {
    const rawCutoff = new Date(now.getTime() - config.metricsRetentionDays * 86_400_000);
    const hourlyCutoff = new Date(now.getTime() - config.metricsHourlyRetentionDays * 86_400_000);
    const raw = await db('server_metrics').where('collected_at', '<', rawCutoff).delete();
    const hourly = await db('server_metrics_hourly').where('hour_start', '<', hourlyCutoff).delete();
    return { raw, hourly };
  }

  // Latest raw sample per server, keyed by server id.
  async function latest(serverIds) {
    if (!serverIds.length) return {};
    const rows = await db('server_metrics').whereIn(
      'id',
      db('server_metrics').whereIn('server_id', serverIds).groupBy('server_id').max('id'),
    );
    return Object.fromEntries(rows.map((r) => [r.server_id, r]));
  }

  // A short CPU/memory trend per server for fleet views: one point per
  // `bucketMinutes` over the last hour.
  async function sparklines(serverIds, { minutes = 60, buckets = 30 } = {}) {
    if (!serverIds.length) return {};
    const since = new Date(Date.now() - minutes * 60_000);
    const rows = await db('server_metrics')
      .whereIn('server_id', serverIds)
      .where('collected_at', '>=', since)
      .orderBy('collected_at')
      .select('server_id', 'collected_at', 'cpu_percent', 'memory_used_bytes', 'memory_total_bytes');
    const out = Object.fromEntries(serverIds.map((id) => [id, []]));
    for (const r of rows) out[r.server_id].push(toPublicMetric(r));
    for (const id of serverIds) {
      out[id] = downsample(out[id], buckets).map((p) => ({
        t: p.collectedAt,
        cpu: p.cpuPercent,
        memory: p.memoryTotalBytes ? (p.memoryUsedBytes / p.memoryTotalBytes) * 100 : null,
      }));
    }
    return out;
  }

  return { history, rollup, prune, latest, sparklines };
}

export function floorHour(date) {
  return new Date(Math.floor(date.getTime() / HOUR_MS) * HOUR_MS);
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

function toPublicHourlyMetric(row) {
  const metric = toPublicMetric({ ...row, collected_at: row.hour_start, uptime_seconds: null });
  return { ...metric, cpuPercentMax: row.cpu_percent_max === null ? null : Number(row.cpu_percent_max), samples: row.samples };
}

const AVERAGED_FIELDS = [
  'cpuPercent',
  'memoryUsedBytes',
  'swapUsedBytes',
  'diskUsedBytes',
  'netRxBytesPerSec',
  'netTxBytesPerSec',
  'processCount',
];

// Averages consecutive points into at most maxPoints buckets.
export function downsample(points, maxPoints) {
  if (points.length <= maxPoints) return points;
  const size = Math.ceil(points.length / maxPoints);
  const out = [];
  for (let i = 0; i < points.length; i += size) {
    const bucket = points.slice(i, i + size);
    const avg = (get) => {
      const values = bucket.map(get).filter((v) => v !== null && v !== undefined);
      return values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
    };
    const point = { ...bucket[bucket.length - 1] };
    for (const field of AVERAGED_FIELDS) if (field in point) point[field] = avg((p) => p[field]);
    if (Array.isArray(point.load)) point.load = [0, 1, 2].map((i) => avg((p) => p.load?.[i]));
    out.push(point);
  }
  return out;
}
