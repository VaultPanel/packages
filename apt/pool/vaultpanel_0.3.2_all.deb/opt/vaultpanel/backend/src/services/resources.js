import { BACKUP_RESOURCES } from '@vaultpanel/shared';
import { AppError, notFound } from '../utils/errors.js';

// The websites, apps and databases that backups and cron jobs act on, read
// the same way whichever record it is.

const TABLES = { website: 'websites', application: 'applications', database: 'databases' };
const LABELS = { website: 'website', application: 'app', database: 'database' };

export async function loadResource(db, type, id, { includeDeleted = false } = {}) {
  const table = TABLES[type];
  if (!table) throw new AppError(422, 'VALIDATION_ERROR', `Unknown resource type ${type}`);
  const q = db(table).where({ id });
  if (!includeDeleted) q.whereNull('deleted_at');
  const row = await q.first();
  if (!row) throw notFound(`This ${LABELS[type]} was not found`);
  return {
    type,
    id: row.id,
    serverId: row.server_id,
    name: row.name,
    agentKind: BACKUP_RESOURCES[type].agentKind,
    label: `${LABELS[type]} ${row.name}`,
    // The hosting customer it belongs to (phase 8), or null.
    customerId: row.customer_id ?? null,
    deleted: Boolean(row.deleted_at),
    row,
  };
}

// Whether a website, app or database exists on its server (it may still be
// being created, or have failed).
export function resourceReady(resource) {
  const { type, row } = resource;
  if (resource.deleted) return { ok: false, reason: `The ${LABELS[type]} was deleted` };
  if (type === 'website') {
    if (!row.provisioned_at || ['creating', 'failed'].includes(row.status)) return { ok: false, reason: 'The website is not set up on its server yet' };
    if (row.status === 'deleting') return { ok: false, reason: 'The website is being deleted' };
  } else if (type === 'application') {
    if (!row.provisioned_at) return { ok: false, reason: 'The app is not set up on its server yet' };
    if (row.status === 'deleting') return { ok: false, reason: 'The app is being deleted' };
  } else if (type === 'database') {
    if (row.status !== 'active') return { ok: false, reason: row.status === 'deleting' ? 'The database is being deleted' : 'The database is not created on its server yet' };
  }
  return { ok: true };
}

export function requireReady(resource) {
  const ready = resourceReady(resource);
  if (!ready.ok) throw new AppError(409, 'RESOURCE_NOT_READY', ready.reason);
}

// Narrows a query on backups or schedules (alias) to one website or app, and
// with includeDatabases also to the databases linked to it (as the app's or
// the website's), deleted ones included.
const DATABASE_LINKS = { website: 'website_id', application: 'application_id' };
export function whereResource(db, q, alias, { resourceType, resourceId, includeDatabases = false }) {
  const link = includeDatabases && resourceId ? DATABASE_LINKS[resourceType] : null;
  if (!link) {
    if (resourceType) q.where(`${alias}.resource_type`, resourceType);
    if (resourceId) q.where(`${alias}.resource_id`, resourceId);
    return q;
  }
  return q.where((w) =>
    w
      .where({ [`${alias}.resource_type`]: resourceType, [`${alias}.resource_id`]: resourceId })
      .orWhere((o) => o.where(`${alias}.resource_type`, 'database').whereIn(`${alias}.resource_id`, db('databases').where(link, resourceId).select('id'))),
  );
}

// SQL for a column telling whether a backup's or schedule's record still exists.
export function resourceExistsSql(alias) {
  return `CASE ${alias}.resource_type
    WHEN 'website' THEN EXISTS (SELECT 1 FROM websites w WHERE w.id = ${alias}.resource_id AND w.deleted_at IS NULL)
    WHEN 'application' THEN EXISTS (SELECT 1 FROM applications a WHERE a.id = ${alias}.resource_id AND a.deleted_at IS NULL)
    WHEN 'database' THEN EXISTS (SELECT 1 FROM ` + '`databases`' + ` d WHERE d.id = ${alias}.resource_id AND d.deleted_at IS NULL)
  END`;
}

export function resourceNameSql(alias) {
  return `CASE ${alias}.resource_type
    WHEN 'website' THEN (SELECT w.name FROM websites w WHERE w.id = ${alias}.resource_id)
    WHEN 'application' THEN (SELECT a.name FROM applications a WHERE a.id = ${alias}.resource_id)
    WHEN 'database' THEN (SELECT d.name FROM ` + '`databases`' + ` d WHERE d.id = ${alias}.resource_id)
  END`;
}
