import { createHash, randomBytes, randomInt, randomUUID } from 'node:crypto';
import {
  DATABASE_BUSY_STATUSES,
  DATABASE_USER_PATTERN,
  PERMISSIONS,
  isReservedDatabaseName,
  isReservedDatabaseUser,
} from '@vaultpanel/shared';
import { toPublicDatabase, toPublicDatabaseUser } from '../models/databaseModel.js';
import { findServer, toPublicServer } from '../models/serverModel.js';
import { createSecretBox, deriveKey } from '../utils/crypto.js';
import { AppError, notFound, validationError } from '../utils/errors.js';
import { fromJson, toJson } from '../utils/json.js';
import { paginate } from '../utils/pagination.js';
import { scopeQuery } from './tenancy.js';

// MySQL / MariaDB databases and users on each server.
//
// As with websites, a row describes what exists on the server; a change is
// pending while its job runs and applied when the agent reports success.
// Passwords are generated here (or chosen by an admin), stored encrypted with
// the panel's secret key so admins can look them up, and sent to the agent
// in a job whose parameters are redacted once it finishes.

const PASSWORD_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
export const DATABASE_PORT = 3306;

export function generatePassword(length = 24) {
  let out = '';
  for (let i = 0; i < length; i += 1) out += PASSWORD_ALPHABET[randomInt(PASSWORD_ALPHABET.length)];
  return out;
}

export function createDatabaseService({ db, config, logger, audit, authorize, jobs, applications, quotas }) {
  const passwordBox = createSecretBox(deriveKey(config.secretKey, 'database-passwords'));

  // ---- Reading ------------------------------------------------------------

  function databaseQuery() {
    return db('databases as d')
      .join('servers as s', 's.id', 'd.server_id')
      .leftJoin('applications as a', (j) => j.on('a.id', 'd.application_id').andOnNull('a.deleted_at'))
      .leftJoin('websites as w', (j) => j.on('w.id', 'd.website_id').andOnNull('w.deleted_at'))
      .whereNull('d.deleted_at')
      .whereNull('s.deleted_at')
      .select('d.*', 's.name as server_name', 'a.name as application_name', 'w.name as website_name');
  }

  function userQuery() {
    return db('database_users as u')
      .join('servers as s', 's.id', 'u.server_id')
      .whereNull('u.deleted_at')
      .whereNull('s.deleted_at')
      .select('u.*', 's.name as server_name');
  }

  async function grantsFor({ databaseIds = null, userIds = null }) {
    const q = db('database_user_grants as g')
      .join('databases as d', 'd.id', 'g.database_id')
      .join('database_users as u', 'u.id', 'g.database_user_id')
      .whereNull('d.deleted_at')
      .whereNull('u.deleted_at')
      .select('g.*', 'd.name as database_name', 'u.username', 'u.privileges');
    if (databaseIds) q.whereIn('g.database_id', databaseIds);
    if (userIds) q.whereIn('g.database_user_id', userIds);
    return databaseIds?.length === 0 || userIds?.length === 0 ? [] : q;
  }

  async function describeDatabases(rows) {
    const grants = await grantsFor({ databaseIds: rows.map((r) => r.id) });
    return rows.map((r) =>
      toPublicDatabase(r, {
        users: grants.filter((g) => g.database_id === r.id).map((g) => ({ id: g.database_user_id, username: g.username, privileges: g.privileges })),
      }),
    );
  }

  async function describeUsers(rows) {
    const grants = await grantsFor({ userIds: rows.map((r) => r.id) });
    return rows.map((r) =>
      toPublicDatabaseUser(r, { databases: grants.filter((g) => g.database_user_id === r.id).map((g) => ({ id: g.database_id, name: g.database_name })) }),
    );
  }

  async function loadDatabase(id) {
    const row = await databaseQuery().where('d.id', id).first();
    if (!row) throw notFound('Database not found');
    return row;
  }

  async function loadUser(id) {
    const row = await userQuery().where('u.id', id).first();
    if (!row) throw notFound('Database user not found');
    return row;
  }

  const databaseDetail = async (id) => (await describeDatabases([await loadDatabase(id)]))[0];
  const userDetail = async (id) => (await describeUsers([await loadUser(id)]))[0];

  async function list(actor, query) {
    await authorize(actor, PERMISSIONS.DATABASES_READ);
    const q = scopeQuery(databaseQuery(), actor, 'd.customer_id');
    if (query.serverId) q.where('d.server_id', query.serverId);
    if (query.applicationId) q.where('d.application_id', query.applicationId);
    if (query.websiteId) q.where('d.website_id', query.websiteId);
    if (query.search) q.where('d.name', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'd.created_at', name: 'd.name', size: 'd.size_bytes' });
    return { items: await describeDatabases(rows), pagination };
  }

  async function get(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_READ);
    return databaseDetail(id);
  }

  async function listUsers(actor, query) {
    await authorize(actor, PERMISSIONS.DATABASES_READ);
    const q = scopeQuery(userQuery(), actor, 'u.customer_id');
    if (query.serverId) q.where('u.server_id', query.serverId);
    if (query.search) q.where('u.username', 'like', `%${query.search.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`);
    const { rows, pagination } = await paginate(q, query, { createdAt: 'u.created_at', username: 'u.username' });
    return { items: await describeUsers(rows), pagination };
  }

  // ---- Checks -------------------------------------------------------------

  function requireServer(server) {
    if (!server || server.deleted_at) throw validationError([{ field: 'serverId', message: 'Server not found' }]);
    if (server.status === 'pending' || server.status === 'disabled') {
      throw new AppError(409, 'SERVER_NOT_READY', 'This server has no connected agent yet');
    }
    const stack = fromJson(server.web_stack, null);
    if (stack && stack.mariadb === undefined) {
      throw new AppError(409, 'AGENT_OUTDATED', `The agent on ${server.name} is too old to manage databases. Update it from the server page.`);
    }
    if (stack && !stack.mariadb) {
      throw new AppError(409, 'DATABASE_SERVER_NOT_INSTALLED', `MariaDB is not installed on ${server.name}. Install it from the Software card on the server page.`);
    }
  }

  function requireIdle(row, what = 'database') {
    if (DATABASE_BUSY_STATUSES.includes(row.status)) {
      throw new AppError(409, 'DATABASE_BUSY', `Another change to this ${what} is still running. Wait for it to finish.`, { jobId: row.last_job_id });
    }
  }

  async function checkUsername(serverId, username, field = 'username') {
    if (isReservedDatabaseUser(username)) throw validationError([{ field, message: `${username} is reserved for the database server` }]);
    const taken = await db('database_users').where({ server_id: serverId, engine: 'mariadb', username_key: username }).first('id');
    if (taken) throw validationError([{ field, message: `A database user named ${username} already exists on this server` }]);
  }

  // The server's databases a user may get access to. A hosting customer's
  // user only gets databases of the same account.
  async function grantableDatabases(serverId, ids, customerId = null) {
    if (!ids.length) return [];
    const q = db('databases').where({ server_id: serverId }).whereIn('id', ids).whereNull('deleted_at').whereNot('status', 'deleting').select('id', 'name', 'customer_id');
    if (customerId) q.where({ customer_id: customerId });
    const rows = await q;
    if (rows.length !== new Set(ids).size) {
      throw validationError([{ field: 'databaseIds', message: customerId ? 'Choose databases of the same account on the same server' : 'Choose databases on the same server' }]);
    }
    return rows;
  }

  // The app a database is linked to must belong to the same account.
  async function linkableApp(applicationId, serverId, customerId) {
    const app = await db('applications').where({ id: applicationId, server_id: serverId }).whereNull('deleted_at').first();
    if (!app || (customerId && app.customer_id !== customerId)) throw validationError([{ field: 'applicationId', message: 'Choose an app on the same server' }]);
    return app;
  }

  // So is the website a database is linked to.
  async function linkableWebsite(websiteId, serverId, customerId) {
    const site = await db('websites').where({ id: websiteId, server_id: serverId }).whereNull('deleted_at').first();
    if (!site || (customerId && site.customer_id !== customerId)) throw validationError([{ field: 'websiteId', message: 'Choose a website on the same server' }]);
    return site;
  }

  // ---- Changes ------------------------------------------------------------

  async function queue(actor, table, row, { type, params, status, resourceType, pending = {} }) {
    const claimed = await db(table)
      .where({ id: row.id })
      .whereNotIn('status', DATABASE_BUSY_STATUSES)
      .update({ status, last_error_code: null, last_error: null, ...pending, updated_at: new Date() });
    if (!claimed) requireIdle({ ...row, status: 'updating' }, table === 'databases' ? 'database' : 'user');
    let job;
    try {
      job = await jobs.create(actor, { serverId: row.server_id, type, params, resource: { type: resourceType, id: row.id } }, { internal: true });
    } catch (err) {
      await db(table).where({ id: row.id }).update({ status: row.status, ...(table === 'database_users' ? { pending_spec: null, pending_password_encrypted: null } : {}), updated_at: new Date() });
      throw err;
    }
    await db(table).where({ id: row.id }).update({ last_job_id: job.id });
    return job;
  }

  // Inserts a user row and queues its creation. Returns the job.
  async function insertUser(actor, server, { username, password, privileges, databases, customerId = null }) {
    const id = randomUUID();
    const now = new Date();
    try {
      await db('database_users').insert({
        id,
        server_id: server.id,
        engine: 'mariadb',
        username,
        username_key: username,
        password_encrypted: passwordBox.seal(password),
        privileges,
        status: 'creating',
        customer_id: customerId,
        pending_spec: toJson({ databaseIds: databases.map((d) => d.id), privileges }),
        created_by: actor.type === 'user' ? actor.id : null,
        created_at: now,
        updated_at: now,
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'username', message: 'This username was just taken' }]);
      throw err;
    }
    let job;
    try {
      job = await jobs.create(
        actor,
        { serverId: server.id, type: 'CREATE_DATABASE_USER', params: { username, password, databases: databases.map((d) => d.name), privileges }, resource: { type: 'database_user', id } },
        { internal: true },
      );
    } catch (err) {
      await db('database_users').where({ id }).delete();
      throw err;
    }
    await db('database_users').where({ id }).update({ last_job_id: job.id });
    return { id, job };
  }

  // A database belongs to the hosting customer creating it, or to the
  // customer of the app or website it is made for, and counts against their
  // plan (with its user, when one is made).
  async function create(actor, input) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    await quotas.homeFor(actor, input.serverId);
    let customerId = actor.customerId ?? null;
    if (!customerId && input.applicationId) customerId = (await db('applications').where({ id: input.applicationId }).first('customer_id'))?.customer_id ?? null;
    if (!customerId && input.websiteId) customerId = (await db('websites').where({ id: input.websiteId }).first('customer_id'))?.customer_id ?? null;
    const kinds = input.createUser ? ['databases', 'databaseUsers'] : ['databases'];
    return quotas.reserve(customerId, kinds, () => createChecked(actor, input, customerId));
  }

  async function createChecked(actor, input, customerId) {
    const server = await findServer(db, input.serverId);
    requireServer(server);
    if (isReservedDatabaseName(input.name)) throw validationError([{ field: 'name', message: `${input.name} is reserved for the database server` }]);
    const taken = await db('databases').where({ server_id: server.id, engine: 'mariadb', name_key: input.name }).first('id');
    if (taken) throw validationError([{ field: 'name', message: `A database named ${input.name} already exists on ${server.name}` }]);
    let app = null;
    if (input.applicationId) app = await linkableApp(input.applicationId, server.id, actor.customerId);
    const site = input.websiteId ? await linkableWebsite(input.websiteId, server.id, actor.customerId) : null;
    let username = null;
    if (input.createUser) {
      username = input.username ?? input.name.slice(0, 32);
      if (!DATABASE_USER_PATTERN.test(username)) throw validationError([{ field: 'username', message: 'Choose a username for the database user' }]);
      await checkUsername(server.id, username);
    }
    if (input.addToAppEnv && app) await authorize(actor, PERMISSIONS.APPS_MANAGE);

    const id = randomUUID();
    const now = new Date();
    try {
      await db('databases').insert({
        id,
        server_id: server.id,
        engine: 'mariadb',
        name: input.name,
        name_key: input.name,
        status: 'creating',
        application_id: app?.id ?? null,
        website_id: site?.id ?? null,
        customer_id: customerId,
        created_by: actor.type === 'user' ? actor.id : null,
        created_at: now,
        updated_at: now,
      });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw validationError([{ field: 'name', message: 'This name was just taken' }]);
      throw err;
    }
    let job;
    try {
      job = await jobs.create(actor, { serverId: server.id, type: 'CREATE_DATABASE', params: { name: input.name }, resource: { type: 'database', id } }, { internal: true });
    } catch (err) {
      await db('databases').where({ id }).delete();
      throw err;
    }
    await db('databases').where({ id }).update({ last_job_id: job.id });

    let user = null;
    let password = null;
    let envAdded = [];
    if (username) {
      password = generatePassword();
      try {
        const created = await insertUser(actor, server, { username, password, privileges: input.privileges, databases: [{ id, name: input.name }], customerId });
        user = await userDetail(created.id);
      } catch (err) {
        logger.warn({ err, databaseId: id }, 'could not queue the database user');
        password = null;
      }
      if (user && app && input.addToAppEnv) {
        envAdded = await applications.addEnv(actor, app.id, connectionEnv({ username, password, database: input.name }));
      }
    }
    await audit.record({
      actor,
      action: 'database.create',
      target: { type: 'database', id, label: input.name },
      metadata: { serverId: server.id, applicationId: app?.id ?? null, websiteId: site?.id ?? null, username, envAdded, jobId: job.id },
    });
    return { database: await databaseDetail(id), job, user, password, envAdded };
  }

  // Links the database to an app and a website, or unlinks it (null). A
  // link left out stays as it is.
  async function update(actor, id, { applicationId, websiteId }) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadDatabase(id);
    const changes = {};
    if (applicationId !== undefined) {
      if (applicationId) await linkableApp(applicationId, row.server_id, row.customer_id);
      changes.application_id = applicationId;
    }
    if (websiteId !== undefined) {
      if (websiteId) await linkableWebsite(websiteId, row.server_id, row.customer_id);
      changes.website_id = websiteId;
    }
    await db('databases').where({ id }).update({ ...changes, updated_at: new Date() });
    await audit.record({ actor, action: 'database.update', target: target(row), metadata: { applicationId, websiteId } });
    return { database: await databaseDetail(id) };
  }

  async function remove(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadDatabase(id);
    requireIdle(row);
    const job = await queue(actor, 'databases', row, { type: 'DELETE_DATABASE', params: { name: row.name }, status: 'deleting', resourceType: 'database' });
    await audit.record({ actor, action: 'database.delete', target: target(row), metadata: { jobId: job.id } });
    return { database: await databaseDetail(id), job };
  }

  async function retry(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadDatabase(id);
    if (row.status !== 'failed') throw new AppError(409, 'DATABASE_READY', 'This database already exists on its server');
    const job = await queue(actor, 'databases', row, { type: 'CREATE_DATABASE', params: { name: row.name }, status: 'creating', resourceType: 'database' });
    await audit.record({ actor, action: 'database.retry', target: target(row), metadata: { jobId: job.id } });
    return { database: await databaseDetail(id), job };
  }

  // ---- Database interface -------------------------------------------------
  // Tables, rows and SQL in one database. The agent runs them as an account
  // that can reach only this database (read-only unless allowChanges), and
  // the browser waits for the job's result.

  async function browserTarget(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadDatabase(id);
    if (['creating', 'deleting', 'failed'].includes(row.status)) {
      throw new AppError(409, 'DATABASE_NOT_READY', 'This database is not ready on its server');
    }
    return row;
  }

  const browserJob = (actor, row, type, params) =>
    jobs.create(actor, { serverId: row.server_id, type, params: { name: row.name, ...params }, resource: { type: 'database', id: row.id } }, { internal: true });

  async function tables(actor, id) {
    return browserJob(actor, await browserTarget(actor, id), 'DATABASE_TABLES', {});
  }

  async function tableRows(actor, id, query) {
    return browserJob(actor, await browserTarget(actor, id), 'DATABASE_TABLE_ROWS', query);
  }

  async function runQuery(actor, id, { sql, allowChanges }) {
    const row = await browserTarget(actor, id);
    const job = await browserJob(actor, row, 'DATABASE_QUERY', { sql, allowChanges });
    if (allowChanges) {
      await audit.record({ actor, action: 'database.query', target: target(row), metadata: { jobId: job.id, sql: sql.slice(0, 1000), truncated: sql.length > 1000 } });
    }
    return job;
  }

  // One-click phpMyAdmin: the agent leaves a two-minute, one-time ticket for
  // a fresh token and the browser opens phpMyAdmin with it, signed in as this
  // database's own full-access account. Only the token's SHA-256 goes into
  // the job; the token itself goes back to this caller only.
  async function openPhpMyAdmin(actor, id) {
    const row = await browserTarget(actor, id);
    const server = toPublicServer(await findServer(db, row.server_id));
    const pma = server.webStack?.phpmyadmin;
    if (!pma?.port) throw new AppError(409, 'PHPMYADMIN_NOT_SET_UP', 'phpMyAdmin is not set up on this server');
    const token = randomBytes(32).toString('base64url');
    const job = await browserJob(actor, row, 'PHPMYADMIN_SIGNON', { tokenHash: createHash('sha256').update(token).digest('hex') });
    await audit.record({ actor, action: 'database.phpmyadmin', target: target(row), metadata: { jobId: job.id } });
    return {
      job,
      token,
      phpmyadmin: { port: pma.port, domain: pma.domain ?? null, host: pma.domain ?? server.publicIp ?? null, isLocal: server.isLocal },
    };
  }

  // ---- Users --------------------------------------------------------------

  // A user belongs to the hosting customer creating it, or to the one
  // customer all its databases belong to.
  async function createUser(actor, input) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    await quotas.homeFor(actor, input.serverId);
    let customerId = actor.customerId ?? null;
    if (!customerId && input.databaseIds.length) {
      const owners = [...new Set((await db('databases').whereIn('id', input.databaseIds).pluck('customer_id')).map((c) => c ?? null))];
      if (owners.length === 1) customerId = owners[0];
    }
    return quotas.reserve(customerId, ['databaseUsers'], () => createUserChecked(actor, input, customerId));
  }

  async function createUserChecked(actor, input, customerId) {
    const server = await findServer(db, input.serverId);
    requireServer(server);
    await checkUsername(server.id, input.username);
    const databases = await grantableDatabases(server.id, input.databaseIds, customerId);
    const password = input.password ?? generatePassword();
    const { id, job } = await insertUser(actor, server, { username: input.username, password, privileges: input.privileges, databases, customerId });
    await audit.record({ actor, action: 'database_user.create', target: { type: 'database_user', id, label: input.username }, metadata: { serverId: server.id, databases: databases.map((d) => d.name), privileges: input.privileges, generatedPassword: !input.password, jobId: job.id } });
    return { user: await userDetail(id), job, password: input.password ? null : password };
  }

  async function updateUser(actor, id, changes) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadUser(id);
    requireIdle(row, 'user');
    if (row.status === 'failed') throw new AppError(409, 'DATABASE_USER_NOT_READY', 'This user was never created on the server. Delete it and create it again.');
    const current = await grantsFor({ userIds: [id] });
    const databaseIds = changes.databaseIds ?? current.map((g) => g.database_id);
    const databases = await grantableDatabases(row.server_id, databaseIds, row.customer_id);
    const privileges = changes.privileges ?? row.privileges;
    const password = changes.password ?? (changes.generatePassword ? generatePassword() : null);
    const params = { username: row.username, databases: databases.map((d) => d.name), privileges };
    if (password) params.password = password;
    const job = await queue(actor, 'database_users', row, {
      type: 'UPDATE_DATABASE_USER',
      params,
      status: 'updating',
      resourceType: 'database_user',
      pending: { pending_spec: toJson({ databaseIds: databases.map((d) => d.id), privileges }), pending_password_encrypted: password ? passwordBox.seal(password) : null },
    });
    await audit.record({ actor, action: 'database_user.update', target: userTarget(row), metadata: { databases: params.databases, privileges, passwordChanged: Boolean(password), jobId: job.id } });
    return { user: await userDetail(id), job, password: changes.generatePassword ? password : null };
  }

  async function removeUser(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadUser(id);
    requireIdle(row, 'user');
    const job = await queue(actor, 'database_users', row, { type: 'DELETE_DATABASE_USER', params: { username: row.username }, status: 'deleting', resourceType: 'database_user' });
    await audit.record({ actor, action: 'database_user.delete', target: userTarget(row), metadata: { jobId: job.id } });
    return { user: await userDetail(id), job };
  }

  // Shows a user's password (and how to connect). Every look is audited.
  async function revealPassword(actor, id) {
    await authorize(actor, PERMISSIONS.DATABASES_MANAGE);
    const row = await loadUser(id);
    const password = passwordBox.open(row.password_encrypted);
    const [first] = await grantsFor({ userIds: [id] });
    await audit.record({ actor, action: 'database_user.password_view', target: userTarget(row) });
    return {
      username: row.username,
      password,
      host: '127.0.0.1',
      port: DATABASE_PORT,
      connectionUrl: first ? connectionEnv({ username: row.username, password, database: first.database_name }).find((e) => e.key === 'DATABASE_URL').value : null,
    };
  }

  // ---- Job results --------------------------------------------------------

  async function handleJobFinished(job, { status, error }) {
    if (job.resource_type === 'database') return databaseFinished(job, status, error);
    if (job.resource_type === 'database_user') return userFinished(job, status, error);
  }

  const failureOf = (ok, error) => (ok ? { last_error_code: null, last_error: null } : { last_error_code: (error?.code ?? 'FAILED').slice(0, 64), last_error: error?.message ?? 'The operation failed' });

  async function databaseFinished(job, status, error) {
    const row = await db('databases').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    if (job.type === 'CREATE_DATABASE') {
      await db('databases').where({ id: row.id }).update({ status: ok ? 'active' : 'failed', ...failureOf(ok, error), updated_at: now });
    } else if (job.type === 'DELETE_DATABASE') {
      if (ok) {
        await db.transaction(async (trx) => {
          await trx('databases').where({ id: row.id }).update({ status: 'active', name_key: null, deleted_at: now, updated_at: now });
          await trx('database_user_grants').where({ database_id: row.id }).delete();
        });
      } else {
        await db('databases').where({ id: row.id }).update({ status: 'active', ...failureOf(ok, error), updated_at: now });
      }
    }
    if (!ok) logger.info({ databaseId: row.id, job: job.type, error }, 'database change failed');
  }

  async function userFinished(job, status, error) {
    const row = await db('database_users').where({ id: job.resource_id }).first();
    if (!row || row.deleted_at) return;
    const ok = status === 'succeeded';
    const now = new Date();
    const pending = fromJson(row.pending_spec, null);
    const done = { pending_spec: null, pending_password_encrypted: null, updated_at: now, ...failureOf(ok, error) };
    const applyGrants = async (trx) => {
      if (!pending) return;
      await trx('database_user_grants').where({ database_user_id: row.id }).delete();
      if (pending.databaseIds.length) await trx('database_user_grants').insert(pending.databaseIds.map((databaseId) => ({ database_user_id: row.id, database_id: databaseId })));
    };
    switch (job.type) {
      case 'CREATE_DATABASE_USER':
        await db.transaction(async (trx) => {
          if (ok) await applyGrants(trx);
          await trx('database_users').where({ id: row.id }).update({ ...done, status: ok ? 'active' : 'failed', ...(ok && pending ? { privileges: pending.privileges } : {}) });
        });
        break;
      case 'UPDATE_DATABASE_USER':
        await db.transaction(async (trx) => {
          if (ok) await applyGrants(trx);
          await trx('database_users')
            .where({ id: row.id })
            .update({
              ...done,
              status: 'active',
              ...(ok && pending ? { privileges: pending.privileges } : {}),
              ...(ok && row.pending_password_encrypted ? { password_encrypted: row.pending_password_encrypted } : {}),
            });
        });
        break;
      case 'DELETE_DATABASE_USER':
        if (ok) {
          await db.transaction(async (trx) => {
            await trx('database_users').where({ id: row.id }).update({ ...done, status: 'active', username_key: null, deleted_at: now });
            await trx('database_user_grants').where({ database_user_id: row.id }).delete();
          });
        } else {
          await db('database_users').where({ id: row.id }).update({ ...done, status: 'active' });
        }
        break;
      default:
        return;
    }
    if (!ok) logger.info({ databaseUserId: row.id, job: job.type, error }, 'database user change failed');
  }

  // ---- Heartbeat ----------------------------------------------------------

  // Database sizes the agent reports every few minutes.
  async function syncSizes(serverId, databases) {
    if (!Array.isArray(databases)) return;
    const rows = await db('databases').where({ server_id: serverId, status: 'active' }).whereNull('deleted_at').select('id', 'name');
    const now = new Date();
    for (const row of rows) {
      const found = databases.find((d) => d.name === row.name);
      if (found) await db('databases').where({ id: row.id }).update({ size_bytes: found.sizeBytes, size_checked_at: now });
    }
  }

  async function summary() {
    const [dbs, users] = await Promise.all([
      databaseQuery().clearSelect().select('d.status').count({ n: '*' }).groupBy('d.status'),
      userQuery().clearSelect().count({ n: '*' }).first(),
    ]);
    const byStatus = Object.fromEntries(dbs.map((r) => [r.status, Number(r.n)]));
    return { total: Object.values(byStatus).reduce((a, b) => a + b, 0), byStatus, users: Number(users?.n ?? 0) };
  }

  jobs.onFinished(handleJobFinished);

  return { list, get, create, update, remove, retry, listUsers, createUser, updateUser, removeUser, revealPassword, tables, tableRows, runQuery, openPhpMyAdmin, syncSizes, summary, handleJobFinished };
}

// Environment variables that connect an app to a database.
export function connectionEnv({ username, password, database }) {
  return [
    { key: 'DATABASE_URL', value: `mysql://${username}:${encodeURIComponent(password)}@127.0.0.1:${DATABASE_PORT}/${database}` },
    { key: 'DB_HOST', value: '127.0.0.1' },
    { key: 'DB_PORT', value: String(DATABASE_PORT) },
    { key: 'DB_NAME', value: database },
    { key: 'DB_USER', value: username },
    { key: 'DB_PASSWORD', value: password },
  ];
}

function target(row) {
  return { type: 'database', id: row.id, label: row.name };
}

function userTarget(row) {
  return { type: 'database_user', id: row.id, label: row.username };
}
