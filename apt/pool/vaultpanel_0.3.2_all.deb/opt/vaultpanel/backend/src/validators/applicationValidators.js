import { z } from 'zod';
import {
  APP_CPU_LIMIT,
  APP_INSTANCES,
  APP_LOG_KINDS,
  APP_MEMORY_LIMIT_MB,
  APP_PORT_MAX,
  APP_PORT_MIN,
  APP_RUNTIME_KEYS,
  APP_STATUSES,
  BRANCH_MESSAGE,
  BRANCH_PATTERN,
  DEFAULT_KEEP_RELEASES,
  DEPLOYMENT_STATUSES,
  ENV_KEY_MESSAGE,
  ENV_KEY_PATTERN,
  MAX_COMMAND_LENGTH,
  MAX_COMMAND_LINES,
  MAX_ENV_VALUE_LENGTH,
  MAX_ENV_VARS,
  MAX_KEEP_RELEASES,
  MAX_REPOSITORY_URL_LENGTH,
  MAX_SITE_DOMAINS,
  REPOSITORY_URL_MESSAGE,
  REPOSITORY_URL_PATTERN,
  SITE_NAME_MESSAGE,
  SITE_NAME_PATTERN,
  applicationProblems,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';
import { siteDomain } from './websiteValidators.js';

const repositoryUrl = z.string().trim().max(MAX_REPOSITORY_URL_LENGTH).regex(REPOSITORY_URL_PATTERN, REPOSITORY_URL_MESSAGE);
const branch = z.string().trim().regex(BRANCH_PATTERN, BRANCH_MESSAGE);
const commands = z.string().max(MAX_COMMAND_LINES * (MAX_COMMAND_LENGTH + 1), 'Too long');
const port = z.number().int().min(APP_PORT_MIN, `Use a port from ${APP_PORT_MIN} to ${APP_PORT_MAX}`).max(APP_PORT_MAX, `Use a port from ${APP_PORT_MIN} to ${APP_PORT_MAX}`);
const keepReleases = z.number().int().min(1, 'Keep at least 1 release').max(MAX_KEEP_RELEASES, `Up to ${MAX_KEEP_RELEASES} releases`);
const instances = z.number().int().min(APP_INSTANCES.min, `At least ${APP_INSTANCES.min}`).max(APP_INSTANCES.max, `Up to ${APP_INSTANCES.max} copies`);
const healthCheckSeconds = z.number().int().min(5, 'At least 5 seconds').max(300, 'Up to 300 seconds');
export const envVariable = z.object({
  key: z.string().trim().regex(ENV_KEY_PATTERN, ENV_KEY_MESSAGE),
  value: z.string().max(MAX_ENV_VALUE_LENGTH, `Values are up to ${MAX_ENV_VALUE_LENGTH} characters`),
});
const envList = z.array(envVariable).max(MAX_ENV_VARS, `Up to ${MAX_ENV_VARS} variables`);

function addProblems(value, ctx) {
  for (const p of applicationProblems(value)) ctx.addIssue({ code: 'custom', path: [p.field], message: p.message });
}

export const createApplicationBody = z
  .object({
    serverId: z.uuid(),
    name: z.string().trim().regex(SITE_NAME_PATTERN, SITE_NAME_MESSAGE),
    runtime: z.enum(APP_RUNTIME_KEYS),
    repositoryUrl,
    branch: branch.default('main'),
    installCommand: commands.optional(),
    buildCommand: commands.optional(),
    startCommand: commands.optional(),
    port: port.nullable().optional(),
    keepReleases: keepReleases.default(DEFAULT_KEEP_RELEASES),
    healthCheckSeconds: healthCheckSeconds.default(30),
    domains: z.array(siteDomain).max(MAX_SITE_DOMAINS, `Up to ${MAX_SITE_DOMAINS} domains`).default([]),
    env: envList.default([]),
    deployNow: z.boolean().default(true),
  })
  .superRefine(addProblems);

export const updateApplicationBody = z
  .object({
    repositoryUrl: repositoryUrl.optional(),
    branch: branch.optional(),
    installCommand: commands.nullable().optional(),
    buildCommand: commands.nullable().optional(),
    startCommand: commands.optional(),
    port: port.nullable().optional(),
    keepReleases: keepReleases.optional(),
    healthCheckSeconds: healthCheckSeconds.optional(),
    cpuLimitPercent: z.number().int().min(APP_CPU_LIMIT.min, `At least ${APP_CPU_LIMIT.min}%`).max(APP_CPU_LIMIT.max).nullable().optional(),
    memoryLimitMb: z.number().int().min(APP_MEMORY_LIMIT_MB.min, `At least ${APP_MEMORY_LIMIT_MB.min} MB`).max(APP_MEMORY_LIMIT_MB.max).nullable().optional(),
    instances: instances.optional(),
    zeroDowntime: z.boolean().optional(),
  })
  .superRefine(addProblems)
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const envBody = z.object({ variables: envList });
export const scaleBody = z.object({ instances });
export const rollbackBody = z.object({ deploymentId: z.uuid() });
export const deleteApplicationQuery = z.object({ removeFiles: z.stringbool().default(false) });
export const appLogsBody = z.object({ log: z.enum(APP_LOG_KINDS), lines: z.number().int().min(10).max(2000).default(200) });
export const addWebsiteBody = z.object({ domains: z.array(siteDomain).min(1, 'Add at least one domain').max(MAX_SITE_DOMAINS) });
export const controlParam = z.object({ id: z.uuid(), action: z.enum(['start', 'stop', 'restart']) });
export const suggestPortQuery = z.object({ serverId: z.uuid() });
export const webhookParam = z.object({ token: z.string().regex(/^[A-Za-z0-9_-]{20,64}$/) });

export const applicationListQuery = listQuerySchema(['createdAt', 'name', 'lastDeployedAt'], 'createdAt', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
  status: z.enum(APP_STATUSES).optional(),
  runtime: z.enum(APP_RUNTIME_KEYS).optional(),
});
export const deploymentListQuery = listQuerySchema(['createdAt'], 'createdAt', {
  applicationId: z.uuid().optional(),
  serverId: z.uuid().optional(),
  status: z.enum([...DEPLOYMENT_STATUSES.filter((s) => s !== 'queued'), 'running']).optional(),
});
