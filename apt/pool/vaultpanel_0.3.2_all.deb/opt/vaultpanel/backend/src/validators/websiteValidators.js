import { z } from 'zod';
import {
  DOCUMENT_ROOT_MESSAGE,
  DOCUMENT_ROOT_PATTERN,
  DOMAIN_MESSAGE,
  DOMAIN_PATTERN,
  ARCHIVE_FILE_PATTERN,
  FILE_LOG_KINDS,
  FILE_MODE_PATTERN,
  FILE_NAME_PATTERN,
  FILE_PATH_MESSAGE,
  FILE_PATH_PATTERN,
  MAX_COMPRESS_NAMES,
  MAX_FILE_BYTES,
  MAX_FILE_PATH_LENGTH,
  MAX_UPLOAD_BYTES,
  MAX_SITE_DOMAINS,
  SSL_RENEW_BEFORE_MAX,
  SSL_RENEW_BEFORE_MIN,
  SSL_WARN_MIN,
  PHP_VERSION_PATTERN,
  SITE_DOMAIN_MESSAGE,
  SITE_DOMAIN_PATTERN,
  SITE_NAME_MESSAGE,
  SITE_NAME_PATTERN,
  SITE_TYPE_KEYS,
  SSL_STATUSES,
  WEBSITE_STATUSES,
  siteSpecProblems,
  MAX_CERT_PEM_LENGTH,
  MAX_CUSTOM_NGINX_LENGTH,
  MAX_KEY_PEM_LENGTH,
  customNginxProblem,
  subdomainProblems,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';
import { email } from './common.js';

export const domain = z.string().trim().toLowerCase().max(253).regex(DOMAIN_PATTERN, DOMAIN_MESSAGE);
// A website's domain, which may also be a wildcard (*.example.com).
export const siteDomain = z.string().trim().toLowerCase().max(253).regex(SITE_DOMAIN_PATTERN, SITE_DOMAIN_MESSAGE);
const domains = z.array(siteDomain).min(1, 'Add at least one domain').max(MAX_SITE_DOMAINS, `Up to ${MAX_SITE_DOMAINS} domains`);
const documentRoot = z.string().trim().max(200).regex(DOCUMENT_ROOT_PATTERN, DOCUMENT_ROOT_MESSAGE);
const phpVersion = z.string().regex(PHP_VERSION_PATTERN, 'Choose a PHP version').nullable().optional();
const proxyPort = z.number().int().min(1, 'Ports are 1 to 65535').max(65535, 'Ports are 1 to 65535').nullable().optional();
const filePath = z.string().max(MAX_FILE_PATH_LENGTH).regex(FILE_PATH_PATTERN, FILE_PATH_MESSAGE);
const requiredPath = filePath.min(1, 'Choose a file or folder');

function addProblems(value, ctx) {
  for (const p of siteSpecProblems(value)) ctx.addIssue({ code: 'custom', path: [p.field], message: p.message });
}

// domains[0] is the primary domain.
export const createWebsiteBody = z
  .object({
    serverId: z.uuid(),
    name: z.string().trim().regex(SITE_NAME_PATTERN, SITE_NAME_MESSAGE),
    type: z.enum(SITE_TYPE_KEYS),
    domains,
    documentRoot: documentRoot.default('public'),
    phpVersion,
    proxyPort,
  })
  .superRefine(addProblems);

// Settings are merged with the site's current ones and checked again in the
// service layer.
export const updateWebsiteBody = z
  .object({
    type: z.enum(SITE_TYPE_KEYS).optional(),
    domains: domains.optional(),
    documentRoot: documentRoot.optional(),
    phpVersion,
    proxyPort,
    forceHttps: z.boolean().optional(),
    customNginx: z
      .string()
      .max(MAX_CUSTOM_NGINX_LENGTH, `At most ${MAX_CUSTOM_NGINX_LENGTH} characters`)
      .superRefine((v, ctx) => {
        const problem = customNginxProblem(v);
        if (problem) ctx.addIssue({ code: 'custom', message: problem });
      })
      .optional(),
    htaccess: z.boolean().optional(),
    spa: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const deleteWebsiteQuery = z.object({ removeFiles: z.stringbool().default(false) });

export const issueSslBody = z.object({
  email,
  staging: z.boolean().default(false),
  verifyDns: z.boolean().default(true),
  forceHttps: z.boolean().default(true),
  // A certificate for the domain and *.domain, checked through the site's
  // DNS zone on its server.
  wildcard: z.boolean().default(false),
  // Or checked through a DNS provider (DNS Zones page), for DNS elsewhere.
  dnsProviderId: z.uuid().nullable().optional(),
});
export const installSslBody = z.object({
  certificate: z.string().trim().min(1, 'Paste the certificate').max(MAX_CERT_PEM_LENGTH),
  privateKey: z.string().trim().min(1, 'Paste the private key').max(MAX_KEY_PEM_LENGTH),
  forceHttps: z.boolean().default(true),
});
export const renewSslBody = z.object({ force: z.boolean().default(false) });
// Whether the panel checks the website's uptime.
export const uptimeBody = z.object({ enabled: z.boolean() });
// Checked further by sslRenewalProblems (warning inside the renewal window).
export const sslRenewalBody = z.object({
  renewBeforeDays: z.number().int().min(SSL_RENEW_BEFORE_MIN).max(SSL_RENEW_BEFORE_MAX),
  warnDays: z.number().int().min(SSL_WARN_MIN).max(SSL_RENEW_BEFORE_MAX),
}).strict();
export const websiteLogsBody = z.object({
  log: z.enum(FILE_LOG_KINDS),
  lines: z.number().int().min(10).max(2000).default(200),
});

export const FILE_ACTIONS = {
  list: z.object({ path: filePath.default('') }),
  read: z.object({ path: requiredPath }),
  write: z.object({
    path: requiredPath,
    content: z.string().max(Math.ceil(MAX_FILE_BYTES / 3) * 4, 'Files up to 1 MB can be saved here'),
    encoding: z.enum(['utf8', 'base64']).default('utf8'),
    overwrite: z.boolean().default(true),
  }),
  mkdir: z.object({ path: requiredPath }),
  rename: z.object({ from: requiredPath, to: requiredPath }),
  delete: z.object({ path: requiredPath }),
  extract: z.object({
    path: requiredPath.regex(ARCHIVE_FILE_PATTERN, 'Choose a .zip, .tar.gz, .tgz or .tar file'),
    // Empty is the site's home folder; a missing folder is created.
    to: filePath.default(''),
    overwrite: z.boolean().default(false),
  }),
  compress: z.object({
    folder: filePath.default(''),
    names: z
      .array(z.string().max(255).regex(FILE_NAME_PATTERN, 'Must be a name in the folder'))
      .min(1, 'Choose what to compress')
      .max(MAX_COMPRESS_NAMES, `Up to ${MAX_COMPRESS_NAMES} items at a time`)
      .refine((names) => new Set(names).size === names.length, 'Each item once'),
    to: requiredPath.regex(/\.zip$/i, 'The name must end in .zip'),
  }),
  chmod: z
    .object({
      path: requiredPath,
      mode: z.string().regex(FILE_MODE_PATTERN, 'Three digits from 0 to 7, such as 755'),
      // Also everything inside a folder: folders get mode, files fileMode.
      recursive: z.boolean().default(false),
      fileMode: z.string().regex(FILE_MODE_PATTERN, 'Three digits from 0 to 7, such as 644').optional(),
    })
    .superRefine((value, ctx) => {
      if (value.recursive && !value.fileMode) ctx.addIssue({ code: 'custom', path: ['fileMode'], message: 'Choose the permissions for files inside' });
    })
    .transform(({ fileMode, ...rest }) => (rest.recursive ? { ...rest, fileMode } : rest)),
};
// Large uploads go up in pieces (fileUploadService).
export const startUploadBody = z.object({
  path: requiredPath,
  size: z.number().int().min(0).max(MAX_UPLOAD_BYTES),
  overwrite: z.boolean().default(false),
});
export const startDownloadBody = z.object({ path: requiredPath });
export const downloadParams = z.object({ id: z.uuid(), downloadId: z.uuid() });
export const uploadParams = z.object({ id: z.uuid(), uploadId: z.uuid() });
export const uploadChunkParams = uploadParams.extend({ offset: z.coerce.number().int().min(0).max(MAX_UPLOAD_BYTES) });
export const fileActionParam = z.object({ id: z.uuid(), action: z.enum(Object.keys(FILE_ACTIONS)) });

export const websiteListQuery = listQuerySchema(['createdAt', 'name'], 'createdAt', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
  status: z.enum(WEBSITE_STATUSES).optional(),
  subdomains: z.stringbool().optional(),
});
export const domainListQuery = listQuerySchema(['domain', 'createdAt'], 'domain', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
}, 'asc');
export const certificateListQuery = listQuerySchema(['notAfter', 'createdAt'], 'notAfter', {
  status: z.enum([...SSL_STATUSES, 'expiring', 'expired']).optional(),
  serverId: z.uuid().optional(),
}, 'asc');

// A subdomain of one of the account's domains, served as its own site.
export const createSubdomainBody = z
  .object({
    parentDomain: domain,
    name: z.string().trim().toLowerCase().max(200),
    type: z.enum(['static', 'php']),
    documentRoot: documentRoot.default('public'),
    phpVersion,
  })
  .superRefine((value, ctx) => {
    for (const p of subdomainProblems(value.name, value.parentDomain)) ctx.addIssue({ code: 'custom', path: [p.field], message: p.message });
    if (value.type === 'php' && !value.phpVersion) ctx.addIssue({ code: 'custom', path: ['phpVersion'], message: 'Choose a PHP version' });
  });
