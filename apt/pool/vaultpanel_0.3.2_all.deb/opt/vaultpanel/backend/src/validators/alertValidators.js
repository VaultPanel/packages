import { z } from 'zod';
import { ALERT_MAX_DURATION_SECONDS, ALERT_METRIC_KEYS, ALERT_METRICS, ALERT_SEVERITIES, SERVICE_NAME_PATTERN } from '@vaultpanel/shared';

const ruleFields = {
  name: z.string().trim().min(1, 'Required').max(100),
  metric: z.enum(ALERT_METRIC_KEYS),
  threshold: z.number().positive().max(1_000_000).nullable().optional(),
  durationSeconds: z.number().int().min(0).max(ALERT_MAX_DURATION_SECONDS),
  severity: z.enum(ALERT_SEVERITIES),
  serverId: z.uuid().nullable().optional(),
  serviceName: z.string().trim().max(100).regex(SERVICE_NAME_PATTERN, 'Must be a valid systemd service name').nullable().optional(),
  isEnabled: z.boolean().optional(),
};

// Cross-field rules: metric rules need a threshold in the metric's range,
// and only service rules may name a service.
function checkRule(rule, ctx) {
  const def = ALERT_METRICS[rule.metric];
  if (!def) return;
  if (def.kind === 'metric') {
    if (rule.threshold === null || rule.threshold === undefined) {
      ctx.addIssue({ code: 'custom', path: ['threshold'], message: 'Required' });
    } else if (rule.threshold < def.min || rule.threshold > def.max) {
      ctx.addIssue({ code: 'custom', path: ['threshold'], message: `Must be between ${def.min} and ${def.max}` });
    }
  }
  if (rule.serviceName && def.kind !== 'service') {
    ctx.addIssue({ code: 'custom', path: ['serviceName'], message: 'Only service rules watch a single service' });
  }
}

export const createRuleBody = z.object(ruleFields).superRefine(checkRule);

// Updates are checked again against the merged rule in the service layer.
export const updateRuleBody = z
  .object(Object.fromEntries(Object.entries(ruleFields).map(([k, v]) => [k, v.optional()])))
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export { checkRule };
