import { z } from 'zod';
import {
  DATABASE_NAME_MESSAGE,
  DATABASE_OBJECT_NAME_MESSAGE,
  DATABASE_OBJECT_NAME_PATTERN,
  DATABASE_NAME_PATTERN,
  DATABASE_PASSWORD_MESSAGE,
  DATABASE_PASSWORD_PATTERN,
  DATABASE_PRIVILEGE_KEYS,
  DATABASE_USER_MESSAGE,
  DATABASE_USER_PATTERN,
  MAX_QUERY_LENGTH,
  MAX_USER_DATABASES,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const name = z.string().trim().regex(DATABASE_NAME_PATTERN, DATABASE_NAME_MESSAGE);
const username = z.string().trim().regex(DATABASE_USER_PATTERN, DATABASE_USER_MESSAGE);
const password = z.string().regex(DATABASE_PASSWORD_PATTERN, DATABASE_PASSWORD_MESSAGE);
const privileges = z.enum(DATABASE_PRIVILEGE_KEYS);
const databaseIds = z.array(z.uuid()).max(MAX_USER_DATABASES, `Up to ${MAX_USER_DATABASES} databases`);

export const createDatabaseBody = z.object({
  serverId: z.uuid(),
  name,
  applicationId: z.uuid().nullable().optional(),
  // The website that uses it, so the website's backups can include it.
  websiteId: z.uuid().nullable().optional(),
  // Also create a user with access to it (named like the database unless given).
  createUser: z.boolean().default(true),
  username: username.optional(),
  privileges: privileges.default('all'),
  // Add DATABASE_URL and DB_* variables to the app (only those it lacks).
  addToAppEnv: z.boolean().default(true),
});
// null unlinks; a link left out is kept.
export const updateDatabaseBody = z
  .object({ applicationId: z.uuid().nullable().optional(), websiteId: z.uuid().nullable().optional() })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const createDatabaseUserBody = z.object({
  serverId: z.uuid(),
  username,
  // Generated when left out.
  password: password.optional(),
  privileges: privileges.default('all'),
  databaseIds: databaseIds.default([]),
});
export const updateDatabaseUserBody = z
  .object({
    password: password.optional(),
    generatePassword: z.boolean().optional(),
    privileges: privileges.optional(),
    databaseIds: databaseIds.optional(),
  })
  .refine((v) => !(v.password && v.generatePassword), 'Choose a password or generate one, not both')
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const databaseListQuery = listQuerySchema(['createdAt', 'name', 'size'], 'name', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
  applicationId: z.uuid().optional(),
  websiteId: z.uuid().optional(),
}, 'asc');
export const databaseUserListQuery = listQuerySchema(['createdAt', 'username'], 'username', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
}, 'asc');

// The database interface.
const objectName = z.string().max(64).regex(DATABASE_OBJECT_NAME_PATTERN, DATABASE_OBJECT_NAME_MESSAGE);
export const tableRowsBody = z.object({
  table: objectName,
  page: z.number().int().min(1).max(1_000_000).default(1),
  pageSize: z.number().int().min(1).max(500).default(50),
  orderBy: objectName.optional(),
  order: z.enum(['asc', 'desc']).default('asc'),
});
export const queryBody = z.object({
  sql: z.string().max(MAX_QUERY_LENGTH, `Up to ${MAX_QUERY_LENGTH} characters`).refine((v) => v.trim().length > 0, 'Enter some SQL'),
  allowChanges: z.boolean().default(false),
});
