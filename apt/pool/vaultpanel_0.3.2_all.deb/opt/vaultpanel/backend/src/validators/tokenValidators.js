import { z } from 'zod';
import { API_TOKEN_SCOPE_KEYS, MAX_API_TOKEN_DAYS } from '@vaultpanel/shared';

export const createTokenBody = z.object({
  name: z.string().trim().min(1, 'Required').max(100),
  scopes: z.array(z.enum(API_TOKEN_SCOPE_KEYS)).min(1, 'Choose what the token can do'),
  // Left out: the token does not expire until it is revoked.
  expiresInDays: z.coerce.number().int().min(1).max(MAX_API_TOKEN_DAYS).nullable().optional(),
});

export const tokenListQuery = z.object({
  all: z
    .enum(['true', 'false'])
    .optional()
    .transform((value) => value === 'true'),
});
