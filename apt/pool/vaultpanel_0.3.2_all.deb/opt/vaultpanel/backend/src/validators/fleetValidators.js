import { z } from 'zod';
import {
  BULK_MODE_KEYS,
  BULK_OPERATION_TYPES,
  MAX_BULK_SERVERS,
  MAX_GROUP_SERVERS,
  SERVER_GROUP_COLORS,
  SERVER_GROUP_NAME_MESSAGE,
  SERVER_GROUP_NAME_PATTERN,
} from '@vaultpanel/shared';

const groupName = z.string().trim().min(1, 'Required').max(60).regex(SERVER_GROUP_NAME_PATTERN, SERVER_GROUP_NAME_MESSAGE);
const description = z.string().trim().max(300);
const color = z.enum(SERVER_GROUP_COLORS);
const serverIds = (max) => z.array(z.uuid()).max(max, `At most ${max} servers`);

export const createGroupBody = z.object({
  name: groupName,
  description: description.default(''),
  color: color.default('blue'),
  serverIds: serverIds(MAX_GROUP_SERVERS).default([]),
});

export const updateGroupBody = z
  .object({ name: groupName, description, color, serverIds: serverIds(MAX_GROUP_SERVERS) })
  .partial()
  .refine((b) => Object.keys(b).length > 0, 'Nothing to change');

export const serverGroupsBody = z.object({ groupIds: z.array(z.uuid()).max(50) });

export const createBulkActionBody = z
  .object({
    type: z.enum(BULK_OPERATION_TYPES),
    params: z.record(z.string(), z.unknown()).default({}),
    serverIds: serverIds(MAX_BULK_SERVERS).optional(),
    groupId: z.uuid().optional(),
    mode: z.enum(BULK_MODE_KEYS).optional(),
    stopOnFailure: z.boolean().default(true),
  })
  .refine((b) => Boolean(b.groupId) !== Boolean(b.serverIds?.length), {
    message: 'Pick either a group or some servers',
    path: ['serverIds'],
  });
