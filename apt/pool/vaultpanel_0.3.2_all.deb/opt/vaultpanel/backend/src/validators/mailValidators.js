import { z } from 'zod';
import {
  DOMAIN_MESSAGE,
  DOMAIN_PATTERN,
  MAIL_ADDRESS_MESSAGE,
  MAIL_ADDRESS_PATTERN,
  MAIL_LOCAL_PART_MESSAGE,
  MAIL_LOCAL_PART_PATTERN,
  MAIL_PASSWORD,
  MAIL_QUOTA_MB,
  MAX_FORWARDER_DESTINATIONS,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const domain = z.string().trim().toLowerCase().transform((v) => v.replace(/\.$/, '')).pipe(z.string().regex(DOMAIN_PATTERN, DOMAIN_MESSAGE));
const localPart = z.string().trim().toLowerCase().regex(MAIL_LOCAL_PART_PATTERN, MAIL_LOCAL_PART_MESSAGE);
const password = z
  .string()
  .min(MAIL_PASSWORD.min, `At least ${MAIL_PASSWORD.min} characters`)
  .max(MAIL_PASSWORD.max, `At most ${MAIL_PASSWORD.max} characters`)
  .refine((v) => !/[\r\n]/.test(v), 'One line only');
const quotaMb = z.number().int().min(MAIL_QUOTA_MB.min).max(MAIL_QUOTA_MB.max, `At most ${MAIL_QUOTA_MB.max} MB`);
const destinations = z
  .array(z.string().trim().toLowerCase().regex(MAIL_ADDRESS_PATTERN, MAIL_ADDRESS_MESSAGE))
  .min(1, 'Add at least one address')
  .max(MAX_FORWARDER_DESTINATIONS, `At most ${MAX_FORWARDER_DESTINATIONS} addresses`)
  .transform((list) => [...new Set(list)]);

export const setupServerBody = z.object({ serverId: z.uuid(), hostname: domain });
export const serverIdParam = z.object({ serverId: z.uuid() });

export const createDomainBody = z.object({
  serverId: z.uuid(),
  domain,
  // Add MX, SPF, DKIM and DMARC records when the panel runs the domain's DNS.
  addDnsRecords: z.boolean().default(true),
});
export const removeQuery = z.object({ deleteMail: z.enum(['true', 'false']).default('true').transform((v) => v === 'true') });

export const createMailboxBody = z.object({
  localPart,
  // Generated (and shown once) unless given.
  password: password.optional(),
  displayName: z.string().trim().max(100).nullable().optional(),
  quotaMb: quotaMb.optional(),
});
export const updateMailboxBody = z
  .object({
    password: password.optional(),
    generatePassword: z.boolean().optional(),
    displayName: z.string().trim().max(100).nullable().optional(),
    quotaMb: quotaMb.optional(),
    enabled: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update')
  .refine((v) => !(v.password && v.generatePassword), 'Give a password or ask for one, not both');

export const createForwarderBody = z.object({ localPart, destinations });
export const updateForwarderBody = z.object({ destinations });

export const domainListQuery = listQuerySchema(['domain', 'createdAt'], 'domain', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
}, 'asc');

export const itemParams = z.object({ id: z.uuid(), itemId: z.uuid() });
