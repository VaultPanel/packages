import { z } from 'zod';
import { PANEL_EMAIL_MAX_RECIPIENTS, PANEL_EMAIL_SECURITY_KEYS, WEBHOOK_EVENT_KEYS } from '@vaultpanel/shared';
import { email } from './common.js';

// A host name or IP address, nothing else (no scheme, path or port).
const host = z
  .string()
  .trim()
  .toLowerCase()
  .max(253)
  .regex(/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$|^\[?[0-9a-f:.]+\]?$/, 'Enter a host name such as smtp.example.com');

const fields = {
  enabled: z.boolean(),
  host: z.union([host, z.literal('').transform(() => null)]),
  port: z.number().int().min(1).max(65535),
  security: z.enum(PANEL_EMAIL_SECURITY_KEYS),
  username: z.union([z.string().trim().max(254), z.null()]),
  password: z.union([z.string().max(500), z.null()]),
  fromAddress: z.union([email, z.literal('').transform(() => null)]),
  fromName: z.string().trim().max(100),
  alerts: z
    .object({
      events: z.array(z.enum(WEBHOOK_EVENT_KEYS)).max(WEBHOOK_EVENT_KEYS.length).transform((list) => [...new Set(list)]),
      toAdmins: z.boolean(),
      extra: z.array(email).max(PANEL_EMAIL_MAX_RECIPIENTS, `At most ${PANEL_EMAIL_MAX_RECIPIENTS} addresses`).transform((list) => [...new Set(list.map((e) => e.toLowerCase()))]),
    })
    .partial(),
};

export const emailSettingsBody = z.object(fields).partial();

export const emailTestBody = z.object({
  to: email,
  // Settings being edited and not saved yet; left out, the saved ones are used.
  settings: z.object(fields).omit({ alerts: true, enabled: true }).partial().optional(),
});

export const emailMessagesQuery = z.object({ limit: z.coerce.number().int().min(1).max(200).optional() });
