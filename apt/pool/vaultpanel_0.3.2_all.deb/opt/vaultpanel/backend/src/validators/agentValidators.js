import { z } from 'zod';
import { BACKUP_ID_PATTERN, CRON_OUTPUT_MAX_BYTES, CRON_RUN_STATUSES, CRON_RUN_TRIGGERS, isValidTimeZone } from '@vaultpanel/shared';

const bytes = z.number().nonnegative().max(Number.MAX_SAFE_INTEGER).nullable().optional();
const shortText = z.string().max(100).nullable().optional();

export const systemInfo = z.object({
  hostname: z.string().min(1).max(255),
  os: z.object({ name: shortText, version: shortText }).optional(),
  kernel: shortText,
  architecture: z.string().max(32).nullable().optional(),
  cpuCores: z.number().int().min(0).max(4096).nullable().optional(),
  memoryTotalBytes: bytes,
  diskTotalBytes: bytes,
  uptimeSeconds: bytes,
  // Sent by agents 0.5.0 and later.
  timezone: z.string().max(64).refine(isValidTimeZone, 'Unknown time zone').nullable().optional(),
});

export const metrics = z.object({
  cpuPercent: z.number().min(0).max(100),
  load: z.array(z.number().min(0)).length(3),
  memoryUsedBytes: bytes,
  memoryTotalBytes: bytes,
  swapUsedBytes: bytes,
  swapTotalBytes: bytes,
  diskUsedBytes: bytes,
  diskTotalBytes: bytes,
  netRxBytesPerSec: bytes,
  netTxBytesPerSec: bytes,
  processCount: z.number().int().min(0).nullable().optional(),
  uptimeSeconds: bytes,
});

const service = z.object({
  name: z.string().max(100),
  active: z.string().max(32),
  sub: z.string().max(32).nullable().optional(),
  enabled: z.string().max(32).nullable().optional(),
  description: z.string().max(255).nullable().optional(),
});

const filesystem = z.object({
  mount: z.string().min(1).max(255),
  device: z.string().max(255).nullable().optional(),
  fsType: z.string().max(32).nullable().optional(),
  totalBytes: z.number().nonnegative().max(Number.MAX_SAFE_INTEGER),
  usedBytes: z.number().nonnegative().max(Number.MAX_SAFE_INTEGER),
});

const webStack = z.object({
  nginx: z.boolean(),
  certbot: z.boolean(),
  phpVersions: z.array(z.string().regex(/^[5-9]\.[0-9]$/)).max(20),
  packageManager: z.string().max(16).nullable().optional(),
  // Sent by agents 0.4.0 and later.
  git: z.boolean().optional(),
  pm2: z.boolean().optional(),
  python: z.string().regex(/^3\.[0-9]{1,2}$/).nullable().optional(),
  node: z.string().max(32).nullable().optional(),
  mariadb: z.boolean().optional(),
  // Sent by agents 0.5.0 and later.
  cron: z.boolean().optional(),
  // Sent by agents 0.5.2 and later: the only Node.js is in a home folder (nvm).
  nodeInHome: z.boolean().optional(),
  // Sent by agents 0.12.0 and later: phpMyAdmin and the port NGINX serves it on.
  phpmyadmin: z
    .object({
      installed: z.boolean(),
      port: z.number().int().min(1).max(65535).nullable(),
      domain: z.string().max(253).nullable(),
    })
    .optional(),
  // Sent by agents 0.15.0 and later: BIND, and whether VaultPanel set it up.
  dns: z.object({ installed: z.boolean(), configured: z.boolean() }).optional(),
  mail: z.object({ installed: z.boolean(), configured: z.boolean(), hostname: z.string().max(253).nullable() }).optional(),
  // Sent by agents 0.18.0 and later: Apache, for sites with .htaccess files on.
  apache: z.boolean().optional(),
  // Go and Ruby apps, Composer for PHP sites from Git (0.32.0).
  go: z.boolean().optional(),
  ruby: z.boolean().optional(),
  composer: z.boolean().optional(),
});

const application = z.object({
  name: z.string().max(32),
  active: z.string().max(32),
  sub: z.string().max(32).nullable().optional(),
  enabled: z.string().max(32).nullable().optional(),
});

const database = z.object({
  name: z.string().max(64),
  sizeBytes: z.number().nonnegative().max(Number.MAX_SAFE_INTEGER),
});

const certificate = z.object({
  site: z.string().max(32),
  notBefore: z.iso.datetime(),
  notAfter: z.iso.datetime(),
  issuer: z.string().max(500).nullable().optional(),
  domains: z.array(z.string().max(253)).max(100),
  staging: z.boolean().optional(),
  // Agents from 0.28.0: an uploaded certificate, not one Certbot keeps.
  custom: z.boolean().optional(),
});

const backupFiles = z.object({
  checkedAt: z.iso.datetime(),
  files: z
    .array(z.object({ id: z.string().regex(BACKUP_ID_PATTERN), sizeBytes: z.number().nonnegative().max(Number.MAX_SAFE_INTEGER).optional() }))
    .max(5000),
});

// Sent by agents 0.6.0 and later, every few minutes.
const port = z.number().int().min(1).max(65535);
const securitySummary = z.object({
  checkedAt: z.iso.datetime(),
  firewall: z
    .object({ installed: z.boolean(), active: z.boolean(), incoming: z.string().max(16).nullable().optional(), rules: z.number().int().nonnegative().max(100_000) })
    .optional(),
  ssh: z
    .object({
      installed: z.boolean(),
      ports: z.array(port).max(20).optional(),
      permitRootLogin: z.string().max(32).nullable().optional(),
      passwordAuthentication: z.boolean().nullable().optional(),
      rootKeys: z.number().int().nonnegative().max(10_000).optional(),
    })
    .optional(),
  fail2ban: z.object({ installed: z.boolean(), active: z.boolean(), sshd: z.boolean(), banned: z.number().int().nonnegative().max(1_000_000) }).optional(),
  updates: z
    .object({
      installed: z.boolean(),
      automatic: z.boolean(),
      pendingSecurity: z.number().int().nonnegative().max(100_000).nullable().optional(),
      rebootRequired: z.boolean(),
    })
    .optional(),
  // Agents 0.36.0 and later: the user the agent runs as, and why root when it is.
  agent: z.object({ user: z.string().max(32), reason: z.string().max(500).nullable().optional() }).optional(),
});

// Sent by agents 0.39.0 and later, every few minutes: what the server's
// self-check found (shared/src/selfCheck.js).
const message = z.string().max(500);
const configTest = z.object({ ok: z.boolean(), error: message.nullable() });
const selfCheckReport = z.object({
  checkedAt: z.iso.datetime(),
  agent: z.object({ user: z.string().max(32), reason: message.nullable().optional() }).optional(),
  helper: z.object({ ok: z.boolean(), error: message.nullable() }).optional(),
  agentFiles: z.object({ dir: z.string().max(1000), unreadable: z.number().int().nonnegative().max(1_000_000), example: z.string().max(1000).nullable() }).optional(),
  fileWorker: configTest.optional(),
  nginx: configTest.optional(),
  apache: configTest.optional(),
  certbot: z
    .object({
      renewals: z.number().int().nonnegative().max(100_000),
      timer: z.string().max(64).nullable(),
      state: z.enum(['active', 'inactive', 'masked']).nullable(),
      lastRunFailed: z.boolean(),
      reloadHook: z.boolean().nullable(),
    })
    .optional(),
  clock: z.object({ synchronized: z.boolean() }).optional(),
  failedUnits: z.array(z.string().max(255)).max(20).optional(),
});

// Sent by agents 0.8.0 and later, every 15 minutes: how much disk each
// folder under the sites root (one per website and app) takes.
const diskUsage = z.object({
  checkedAt: z.iso.datetime(),
  folders: z.array(z.object({ name: z.string().max(64), sizeBytes: z.number().nonnegative().max(Number.MAX_SAFE_INTEGER) })).max(5000),
});

// Sent by agents 0.10.0 and later, with every heartbeat: Docker's state and
// one short line per container.
const dockerSummary = z.object({
  installed: z.boolean(),
  source: z.enum(['snap', 'package']).nullable(),
  service: z.string().max(64).nullable(),
  running: z.boolean(),
  version: z.string().max(64).nullable(),
  apiVersion: z.string().max(16).nullable().optional(),
  containers: z
    .array(
      z.object({
        id: z.string().regex(/^[a-f0-9]{12,64}$/),
        name: z.string().max(255),
        image: z.string().max(255),
        state: z.string().max(16),
        status: z.string().max(100).nullable(),
        managedId: z.uuid().nullable(),
        hostPorts: z.array(port).max(100),
        protected: z.boolean(),
      }),
    )
    .max(300),
});

export const agentVersion = z.string().regex(/^[0-9A-Za-z.+-]{1,32}$/);

export const registerBody = z.object({
  enrollmentToken: z.string().min(10).max(200),
  publicKey: z.string().min(40).max(1000),
  agentVersion,
  system: systemInfo,
});

export const heartbeatBody = z.object({
  agentVersion,
  system: systemInfo,
  metrics: metrics.nullable().optional(),
  services: z.array(service).max(100).optional(),
  // Sent by agents 0.2.0 and later.
  operations: z.array(z.string().regex(/^[A-Z][A-Z0-9_]{0,63}$/)).max(200).optional(),
  filesystems: z.array(filesystem).max(50).optional(),
  // Sent by agents 0.3.0 and later.
  webStack: webStack.optional(),
  certificates: z.array(certificate).max(500).optional(),
  addresses: z.array(z.union([z.ipv4(), z.ipv6()])).max(50).optional(),
  // Sent by agents 0.4.0 and later.
  applications: z.array(application).max(500).optional(),
  databases: z.array(database).max(1000).optional(),
  // Sent by agents 0.5.0 and later, every few minutes.
  backups: backupFiles.optional(),
  security: securitySummary.optional(),
  diskUsage: diskUsage.optional(),
  docker: dockerSummary.optional(),
  selfCheck: selfCheckReport.optional(),
});

// A piece of a backup the agent uploads for downloading (UPLOAD_BACKUP).
export const uploadChunkQuery = z.object({
  id: z.uuid(),
  offset: z.coerce.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
});

// A piece of a website file for a download (2 MiB of data, base64-encoded).
export const downloadChunkBody = z.object({
  offset: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  data: z.string().max(2_900_000).regex(/^[A-Za-z0-9+/]*={0,2}$/, 'base64 data'),
  final: z.boolean().optional(),
});

export const backupChunkBody = z.object({
  offset: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  // 2 MiB of data, base64-encoded.
  data: z.string().max(2_900_000).regex(/^[A-Za-z0-9+/]*={0,2}$/, 'base64 data'),
  final: z.boolean().optional(),
});

export const cronRun = z.object({
  runKey: z.uuid(),
  cronId: z.uuid(),
  trigger: z.enum(CRON_RUN_TRIGGERS),
  status: z.enum(Object.keys(CRON_RUN_STATUSES)),
  exitCode: z.number().int().min(-1).max(255).nullable().optional(),
  startedAt: z.iso.datetime(),
  finishedAt: z.iso.datetime().nullable().optional(),
  durationMs: z.number().int().nonnegative().max(2_147_483_647).nullable().optional(),
  output: z.string().max(CRON_OUTPUT_MAX_BYTES * 2).optional(),
  outputTruncated: z.boolean().optional(),
});

export const cronRunsBody = z.object({ runs: z.array(cronRun).min(1).max(100) });

export const jobLogsBody = z.object({
  lines: z
    .array(z.object({ stream: z.enum(['stdout', 'stderr']), message: z.string().max(8000) }))
    .min(1)
    .max(200),
});

export const jobResultBody = z.object({
  status: z.enum(['succeeded', 'failed']),
  output: z.unknown().optional(),
  error: z.object({ code: z.string().max(64), message: z.string().max(4000) }).optional(),
});
