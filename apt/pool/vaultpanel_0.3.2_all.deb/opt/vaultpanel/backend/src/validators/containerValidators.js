import { z } from 'zod';
import {
  CONTAINER_ACTION_KEYS,
  CONTAINER_COMMAND_PATTERN,
  CONTAINER_CPU_PERCENT,
  CONTAINER_HEALTH_SECONDS,
  CONTAINER_ID_PATTERN,
  CONTAINER_MEMORY_MB,
  CONTAINER_NAME_MESSAGE,
  CONTAINER_NAME_PATTERN,
  CONTAINER_PATH_PATTERN,
  ENV_KEY_MESSAGE,
  ENV_KEY_PATTERN,
  IMAGE_ID_PATTERN,
  IMAGE_REF_MESSAGE,
  IMAGE_REF_PATTERN,
  MAX_CONTAINER_COMMAND_LENGTH,
  MAX_CONTAINER_PORTS,
  MAX_CONTAINER_VOLUMES,
  MAX_ENV_VALUE_LENGTH,
  MAX_ENV_VARS,
  MAX_IMAGE_REF_LENGTH,
  PORT_BIND_ADDRESSES,
  RESTART_POLICY_KEYS,
  VOLUME_NAME_PATTERN,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const portNumber = z.number().int().min(1, 'Use a port from 1 to 65535').max(65535, 'Use a port from 1 to 65535');
const port = z.object({
  address: z.enum(Object.keys(PORT_BIND_ADDRESSES)).default('127.0.0.1'),
  hostPort: portNumber,
  containerPort: portNumber,
  protocol: z.enum(['tcp', 'udp']).default('tcp'),
});
const volume = z.object({
  volume: z.string().trim().regex(VOLUME_NAME_PATTERN, 'Use lowercase letters, digits and dashes, starting with a letter'),
  path: z
    .string()
    .trim()
    .max(200)
    .regex(CONTAINER_PATH_PATTERN, 'Use an absolute path inside the container, such as /var/lib/data')
    .refine((p) => !p.split('/').some((part) => part === '..' || part === '.'), 'The path cannot contain . or ..'),
  readOnly: z.boolean().default(false),
});
const envList = z
  .array(
    z.object({
      key: z.string().trim().regex(ENV_KEY_PATTERN, ENV_KEY_MESSAGE),
      value: z.string().max(MAX_ENV_VALUE_LENGTH, `Values are up to ${MAX_ENV_VALUE_LENGTH} characters`).refine((v) => !v.includes('\0'), 'Values are text'),
    }),
  )
  .max(MAX_ENV_VARS, `Up to ${MAX_ENV_VARS} variables`);
const image = z.string().trim().max(MAX_IMAGE_REF_LENGTH).regex(IMAGE_REF_PATTERN, IMAGE_REF_MESSAGE);
const command = z.string().max(MAX_CONTAINER_COMMAND_LENGTH, `Up to ${MAX_CONTAINER_COMMAND_LENGTH} characters`).regex(CONTAINER_COMMAND_PATTERN, 'Use one line');
const fields = {
  image,
  ports: z.array(port).max(MAX_CONTAINER_PORTS, `Up to ${MAX_CONTAINER_PORTS} ports`),
  volumes: z.array(volume).max(MAX_CONTAINER_VOLUMES, `Up to ${MAX_CONTAINER_VOLUMES} volumes`),
  env: envList,
  restartPolicy: z.enum(RESTART_POLICY_KEYS),
  memoryMb: z.number().int().min(CONTAINER_MEMORY_MB.min, `At least ${CONTAINER_MEMORY_MB.min} MB`).max(CONTAINER_MEMORY_MB.max).nullable(),
  cpuPercent: z.number().int().min(CONTAINER_CPU_PERCENT.min, `At least ${CONTAINER_CPU_PERCENT.min}%`).max(CONTAINER_CPU_PERCENT.max).nullable(),
  // Empty: the image's own command.
  command: command.nullable(),
  healthCheckSeconds: z.number().int().min(CONTAINER_HEALTH_SECONDS.min, `At least ${CONTAINER_HEALTH_SECONDS.min} seconds`).max(CONTAINER_HEALTH_SECONDS.max, `Up to ${CONTAINER_HEALTH_SECONDS.max} seconds`),
};

export const createContainerBody = z.object({
  serverId: z.uuid(),
  name: z.string().trim().regex(CONTAINER_NAME_PATTERN, CONTAINER_NAME_MESSAGE),
  image: fields.image,
  ports: fields.ports.default([]),
  volumes: fields.volumes.default([]),
  env: fields.env.default([]),
  restartPolicy: fields.restartPolicy.default('unless-stopped'),
  memoryMb: fields.memoryMb.optional(),
  cpuPercent: fields.cpuPercent.optional(),
  command: fields.command.optional(),
  healthCheckSeconds: fields.healthCheckSeconds.default(CONTAINER_HEALTH_SECONDS.default),
});

// Every field is optional; env, when given, replaces all variables.
export const updateContainerBody = z
  .object({
    image: fields.image.optional(),
    ports: fields.ports.optional(),
    volumes: fields.volumes.optional(),
    env: fields.env.optional(),
    restartPolicy: fields.restartPolicy.optional(),
    memoryMb: fields.memoryMb.optional(),
    cpuPercent: fields.cpuPercent.optional(),
    command: fields.command.optional(),
    healthCheckSeconds: fields.healthCheckSeconds.optional(),
    // Pull the image again even when it is already on the server.
    pull: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).some((k) => k !== 'pull'), 'Nothing to change');

export const redeployBody = z.object({ pull: z.boolean().default(true) });
export const removeQuery = z.object({ removeVolumes: z.stringbool().default(false) });
export const containerListQuery = listQuerySchema(['createdAt', 'name'], 'name', { search: z.string().max(100).optional(), serverId: z.uuid().optional() }, 'asc');

// A container on a server: its Docker ID, or the name of one VaultPanel deployed.
export const serverContainerParams = z.object({
  serverId: z.uuid(),
  ref: z.string().max(64).refine((v) => CONTAINER_ID_PATTERN.test(v) || CONTAINER_NAME_PATTERN.test(v), 'Must be a container ID or name'),
});
export const serverActionParams = serverContainerParams.extend({ action: z.enum(CONTAINER_ACTION_KEYS) });
export const containerActionParams = z.object({ id: z.uuid(), action: z.enum(CONTAINER_ACTION_KEYS) });
export const serverParams = z.object({ serverId: z.uuid() });
export const logsBody = z.object({ lines: z.number().int().min(10).max(2000).default(200) });
export const pullImageBody = z.object({ image });
export const removeImageBody = z.object({ imageId: z.string().regex(IMAGE_ID_PATTERN, 'Must be an image ID') });
