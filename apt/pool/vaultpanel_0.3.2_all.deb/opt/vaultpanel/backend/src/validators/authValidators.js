import { z } from 'zod';
import { RECOVERY_CODE_PATTERN } from '@vaultpanel/shared';
import { email, password, personName, totpCode } from './common.js';

export const setupBody = z.object({
  setupToken: z.string().min(1, 'Required').max(200),
  name: personName,
  email,
  password,
});
// Login does not enforce password rules: old passwords must still work.
export const loginBody = z.object({ email, password: z.string().min(1, 'Required').max(1024) });
// The second sign-in step takes an authenticator code or a recovery code.
export const twoFactorLoginBody = z
  .object({
    challengeToken: z.string().min(1).max(500),
    code: totpCode.optional(),
    recoveryCode: z.string().trim().regex(RECOVERY_CODE_PATTERN, 'Enter a recovery code such as abcde-12345').optional(),
  })
  .refine((b) => Boolean(b.code) !== Boolean(b.recoveryCode), { message: 'Enter the 6-digit code or a recovery code', path: ['code'] });
export const changePasswordBody = z.object({ currentPassword: z.string().min(1).max(1024), newPassword: password });
export const enableTotpBody = z.object({ code: totpCode });
export const disableTotpBody = z.object({ password: z.string().min(1).max(1024), code: totpCode });
export const resetRequestBody = z.object({ email });
export const resetTokenBody = z.object({ token: z.string().min(1).max(200) });
export const resetPasswordBody = z.object({ token: z.string().min(1).max(200), password });
