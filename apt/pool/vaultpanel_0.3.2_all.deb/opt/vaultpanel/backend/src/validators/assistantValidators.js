import { z } from 'zod';
import { ASSISTANT_MAX_QUESTION_LENGTH, ASSISTANT_MODEL_PATTERN, ASSISTANT_PROVIDER_KEYS, LOCAL_AI_MODEL_IDS } from '@vaultpanel/shared';

const question = z.string().trim().min(1, 'Ask a question').max(ASSISTANT_MAX_QUESTION_LENGTH, `Keep it under ${ASSISTANT_MAX_QUESTION_LENGTH} characters`);

export const askBody = z.object({ question });

// The provider's address: http(s) only, no credentials in it. Only owners and
// admins (settings.manage) set it; plain http is for a model on this network.
const baseUrl = z
  .string()
  .trim()
  .max(300)
  .refine((v) => {
    try {
      const url = new URL(v);
      return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password && !url.search && !url.hash;
    } catch {
      return false;
    }
  }, 'Enter an address such as https://api.openai.com/v1')
  .transform((v) => v.replace(/\/+$/, ''));

const settingsFields = {
  enabled: z.boolean(),
  provider: z.enum(ASSISTANT_PROVIDER_KEYS),
  model: z.string().trim().min(1, 'Required').max(100).regex(ASSISTANT_MODEL_PATTERN, 'Letters, digits and . _ : / @ - only'),
  baseUrl: z.union([baseUrl, z.literal('').transform(() => null), z.null()]),
  apiKey: z.union([z.string().trim().max(500), z.null()]),
};

export const settingsBody = z.object(settingsFields).partial();

export const localModelBody = z.object({ model: z.enum(LOCAL_AI_MODEL_IDS, 'Choose a model from the list') });
export const testSettingsBody = z.object(settingsFields).omit({ enabled: true }).partial();
