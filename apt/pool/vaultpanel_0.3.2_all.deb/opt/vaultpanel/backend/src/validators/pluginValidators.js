import { z } from 'zod';
import {
  MAX_PLUGIN_DIRECTORY_ENTRIES,
  PLUGIN_DIRECTORY_VERSION,
  PLUGIN_EVENT_KEYS,
  PLUGIN_HOSTING,
  PLUGIN_MANIFEST_VERSION,
  PLUGIN_PAGE_ICONS,
  PLUGIN_SCOPE_KEYS,
  PLUGIN_SLUG_PATTERN,
  WEBHOOK_DELIVERY_STATUSES,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const httpUrl = z
  .string()
  .trim()
  .max(2000)
  .refine((value) => {
    try {
      return ['http:', 'https:'].includes(new URL(value).protocol);
    } catch {
      return false;
    }
  }, 'Use a full http or https URL');

// A plugin's manifest (docs/plugins.md). Unknown keys are refused, so a typo
// in a permission or event name is an error rather than silently ignored.
export const pluginManifest = z
  .object({
    manifestVersion: z.literal(PLUGIN_MANIFEST_VERSION, { error: `manifestVersion must be ${PLUGIN_MANIFEST_VERSION}` }),
    id: z.string().trim().regex(PLUGIN_SLUG_PATTERN, 'Use 3 to 64 lowercase letters, digits and dashes, starting with a letter'),
    name: z.string().trim().min(1, 'Required').max(100),
    version: z.string().trim().min(1, 'Required').max(32),
    description: z.string().trim().max(500).optional(),
    author: z.string().trim().max(100).optional(),
    homepage: httpUrl.optional(),
    permissions: z.array(z.enum(PLUGIN_SCOPE_KEYS, { error: `Use ${PLUGIN_SCOPE_KEYS.join(', ')}` })).max(PLUGIN_SCOPE_KEYS.length).default([]),
    events: z.array(z.enum(PLUGIN_EVENT_KEYS, { error: 'Not an event plugins can receive' })).max(PLUGIN_EVENT_KEYS.length).default([]),
    webhookUrl: httpUrl.optional(),
    page: z
      .object({
        title: z.string().trim().min(1, 'Required').max(60),
        url: httpUrl,
        icon: z.enum(PLUGIN_PAGE_ICONS).default('plug'),
      })
      .strict()
      .optional(),
  })
  .strict()
  .superRefine((m, ctx) => {
    if (m.events.length && !m.webhookUrl) ctx.addIssue({ code: 'custom', path: ['webhookUrl'], message: 'Needed to receive events' });
    if (new Set(m.permissions).size !== m.permissions.length) ctx.addIssue({ code: 'custom', path: ['permissions'], message: 'Listed twice' });
    if (new Set(m.events).size !== m.events.length) ctx.addIssue({ code: 'custom', path: ['events'], message: 'Listed twice' });
  });

// A manifest is given either by URL (fetched by the panel) or pasted.
const manifestSource = {
  manifestUrl: httpUrl.optional(),
  manifest: z.record(z.string(), z.unknown()).optional(),
};
const oneSource = (body, ctx) => {
  if (Boolean(body.manifestUrl) === Boolean(body.manifest)) {
    ctx.addIssue({ code: 'custom', path: ['manifestUrl'], message: 'Give the manifest URL or paste the manifest, not both' });
  }
};

export const previewPluginBody = z.object(manifestSource).strict().superRefine(oneSource);

// approvedPermissions must repeat exactly what the manifest asks for: the
// person installing approves the whole request, not a part the plugin may
// not work with.
export const installPluginBody = z
  .object({ ...manifestSource, approvedPermissions: z.array(z.enum(PLUGIN_SCOPE_KEYS)).max(PLUGIN_SCOPE_KEYS.length) })
  .strict()
  .superRefine(oneSource);

// Updating takes a new manifest, or fetches the manifest URL again.
export const updatePluginBody = z
  .object({ ...manifestSource, approvedPermissions: z.array(z.enum(PLUGIN_SCOPE_KEYS)).max(PLUGIN_SCOPE_KEYS.length) })
  .strict();

export const pluginDeliveryParams = z.object({ id: z.uuid(), deliveryId: z.uuid() });
export const pluginDeliveryQuery = listQuerySchema(['createdAt'], 'createdAt', { status: z.enum(WEBHOOK_DELIVERY_STATUSES).optional() });
export const pluginLaunchQuery = z.object({ theme: z.enum(['light', 'dark']).default('light') });

// ---- Plugin directories (docs/plugins.md#plugin-directories) ------------------------

// The directory document. Its entries are checked one by one (below), so one
// bad entry is left out instead of hiding the whole directory.
export const pluginDirectoryDocument = z.object({
  directoryVersion: z.literal(PLUGIN_DIRECTORY_VERSION, { error: `directoryVersion must be ${PLUGIN_DIRECTORY_VERSION}` }),
  name: z.string().trim().min(1, 'Required').max(100),
  description: z.string().trim().max(500).optional(),
  homepage: httpUrl.optional(),
  plugins: z.array(z.unknown()).max(MAX_PLUGIN_DIRECTORY_ENTRIES, `Up to ${MAX_PLUGIN_DIRECTORY_ENTRIES} plugins`),
});

// One plugin in a directory. permissions and events are what the directory
// says the plugin asks for, to help choose; what is approved is always read
// from the plugin's own manifest.
export const pluginDirectoryEntry = z
  .object({
    id: z.string().trim().regex(PLUGIN_SLUG_PATTERN, 'Use 3 to 64 lowercase letters, digits and dashes, starting with a letter'),
    name: z.string().trim().min(1, 'Required').max(100),
    version: z.string().trim().min(1, 'Required').max(32),
    description: z.string().trim().max(500).optional(),
    author: z.string().trim().max(100).optional(),
    homepage: httpUrl.optional(),
    hosting: z.enum(PLUGIN_HOSTING).default('hosted'),
    manifestUrl: httpUrl.optional(),
    setupUrl: httpUrl.optional(),
    permissions: z.array(z.enum(PLUGIN_SCOPE_KEYS, { error: `Use ${PLUGIN_SCOPE_KEYS.join(', ')}` })).max(PLUGIN_SCOPE_KEYS.length).default([]),
    events: z.array(z.enum(PLUGIN_EVENT_KEYS, { error: 'Not an event plugins can receive' })).max(PLUGIN_EVENT_KEYS.length).default([]),
    icon: z.enum(PLUGIN_PAGE_ICONS).default('plug'),
    categories: z.array(z.string().trim().toLowerCase().min(1).max(30)).max(5).default([]),
  })
  .superRefine((e, ctx) => {
    if (e.hosting === 'hosted' && !e.manifestUrl) ctx.addIssue({ code: 'custom', path: ['manifestUrl'], message: 'A hosted plugin needs its manifest URL' });
    if (e.hosting === 'self-hosted' && !e.setupUrl && !e.homepage) ctx.addIssue({ code: 'custom', path: ['setupUrl'], message: 'Say where to find how to run it (setupUrl or homepage)' });
  });

export const addPluginDirectoryBody = z.object({ url: httpUrl }).strict();
export const pluginDirectoryParams = z.object({ directoryId: z.uuid() });
