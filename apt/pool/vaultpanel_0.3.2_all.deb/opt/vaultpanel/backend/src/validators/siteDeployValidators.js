import { z } from 'zod';
import {
  BRANCH_MESSAGE,
  BRANCH_PATTERN,
  DEFAULT_KEEP_RELEASES,
  MAX_COMMAND_LENGTH,
  MAX_COMMAND_LINES,
  MAX_KEEP_RELEASES,
  MAX_REPOSITORY_URL_LENGTH,
  REPOSITORY_URL_MESSAGE,
  REPOSITORY_URL_PATTERN,
  SITE_OUTPUT_DIR_MESSAGE,
  SITE_OUTPUT_DIR_PATTERN,
} from '@vaultpanel/shared';

const commands = z.string().max(MAX_COMMAND_LINES * (MAX_COMMAND_LENGTH + 1), 'Too long');
// "", "." and "./" all mean the repository itself.
const outputDir = z
  .string()
  .trim()
  .max(200)
  .transform((v) => v.replace(/^\.\/?$/, '').replace(/^\.\//, '').replace(/\/+$/, ''))
  .refine((v) => v === '' || SITE_OUTPUT_DIR_PATTERN.test(v), SITE_OUTPUT_DIR_MESSAGE);

// Turning Git deploy on for a static website, or changing its settings.
export const siteGitBody = z.object({
  repositoryUrl: z.string().trim().max(MAX_REPOSITORY_URL_LENGTH).regex(REPOSITORY_URL_PATTERN, REPOSITORY_URL_MESSAGE),
  branch: z.string().trim().regex(BRANCH_PATTERN, BRANCH_MESSAGE).default('main'),
  installCommand: commands.nullable().optional(),
  buildCommand: commands.nullable().optional(),
  outputDir: outputDir.default(''),
  keepReleases: z.number().int().min(1, 'Keep at least 1 release').max(MAX_KEEP_RELEASES, `Up to ${MAX_KEEP_RELEASES} releases`).default(DEFAULT_KEEP_RELEASES),
  deployNow: z.boolean().default(false),
});
export const siteRollbackBody = z.object({ deploymentId: z.uuid() });
