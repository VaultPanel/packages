import { z } from 'zod';
import {
  API_KEY_SCOPE_KEYS,
  BILLING_CYCLE_KEYS,
  CURRENCY_PATTERN,
  CUSTOMER_RESOURCE_TYPE_KEYS,
  CUSTOMER_STATUS_KEYS,
  EXTERNAL_ID_MESSAGE,
  EXTERNAL_ID_PATTERN,
  PLAN_APP_CAPS,
  PLAN_LIMITS,
  PLAN_NAME_MESSAGE,
  PLAN_NAME_PATTERN,
  REPORT_MONTHS,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';
import { email, password, personName } from './common.js';

const planName = z.string().trim().min(1, 'Required').max(60).regex(PLAN_NAME_PATTERN, PLAN_NAME_MESSAGE);
const limit = (def) => z.number().int().min(0, 'Use 0 or more').max(def.max, `Up to ${def.max}`).nullable();
const cap = (def) => z.number().int().min(def.min, `At least ${def.min}${def.unit === '%' ? '%' : ` ${def.unit}`}`).max(def.max, `Up to ${def.max}`).nullable();

const limits = z.object(Object.fromEntries(Object.entries(PLAN_LIMITS).map(([key, def]) => [key, limit(def)]))).partial();
const appCaps = z.object(Object.fromEntries(Object.entries(PLAN_APP_CAPS).map(([key, def]) => [key, cap(def)]))).partial();

const planFields = {
  name: planName,
  description: z.string().trim().max(300),
  isActive: z.boolean(),
  priceCents: z.number().int().min(0).max(100_000_000).nullable(),
  currency: z.string().trim().toUpperCase().regex(CURRENCY_PATTERN, 'A 3-letter currency code such as USD'),
  billingCycle: z.enum(BILLING_CYCLE_KEYS),
  serverGroupId: z.uuid().nullable(),
  limits,
  appCaps,
};

export const createPlanBody = z.object({
  ...planFields,
  description: planFields.description.default(''),
  isActive: planFields.isActive.default(true),
  priceCents: planFields.priceCents.default(null),
  currency: planFields.currency.default('USD'),
  billingCycle: planFields.billingCycle.default('monthly'),
  serverGroupId: planFields.serverGroupId.default(null),
  limits: limits.default({}),
  appCaps: appCaps.default({}),
});

export const updatePlanBody = z
  .object(planFields)
  .partial()
  .refine((b) => Object.keys(b).length > 0, 'Nothing to change');

const company = z.string().trim().max(120);
const externalId = z.string().trim().regex(EXTERNAL_ID_PATTERN, EXTERNAL_ID_MESSAGE);
const notes = z.string().max(1000);

export const customerListQuery = listQuerySchema(['createdAt', 'name'], 'createdAt', {
  search: z.string().max(100).optional(),
  status: z.enum(CUSTOMER_STATUS_KEYS).optional(),
  planId: z.uuid().optional(),
  serverId: z.uuid().optional(),
});

export const createCustomerBody = z.object({
  name: personName,
  email,
  company: company.optional(),
  planId: z.uuid(),
  serverId: z.uuid().nullable().optional(),
  externalId: externalId.optional(),
  password: password.optional(),
  notes: notes.optional(),
});

export const updateCustomerBody = z
  .object({ name: personName, email, company: company.nullable(), serverId: z.uuid(), externalId: externalId.nullable(), notes })
  .partial()
  .refine((b) => Object.keys(b).length > 0, 'Nothing to change');

export const changePlanBody = z.object({ planId: z.uuid() });
export const suspendBody = z.object({ reason: z.string().trim().max(300).optional() });
export const assignBody = z.object({ type: z.enum(CUSTOMER_RESOURCE_TYPE_KEYS), resourceId: z.uuid() });
export const resourceParams = z.object({ id: z.uuid(), type: z.enum(CUSTOMER_RESOURCE_TYPE_KEYS), resourceId: z.uuid() });

export const financialReportQuery = z.object({
  months: z.coerce.number().int().min(REPORT_MONTHS.min).max(REPORT_MONTHS.max).default(REPORT_MONTHS.default),
});

export const createApiKeyBody = z.object({
  name: z.string().trim().min(1, 'Required').max(100),
  scopes: z.array(z.enum(API_KEY_SCOPE_KEYS)).min(1, 'Choose what the key can do').default(['billing']),
});

// ---- Billing API ----------------------------------------------------------

// A customer by our id or the billing system's.
export const accountRefParam = z.object({ ref: z.string().trim().min(1).max(100).regex(/^[A-Za-z0-9._:-]+$/, 'An account id or billing id') });
const planRef = z.string().trim().min(1).max(60);

export const billingCreateBody = z.object({
  name: personName,
  email,
  company: company.optional(),
  plan: planRef,
  externalId: externalId.optional(),
  serverId: z.uuid().optional(),
  password: password.optional(),
});
export const billingPlanBody = z.object({ plan: planRef });
export const billingPasswordBody = z.object({ password: password.optional() });
