import { z } from 'zod';
import {
  BACKUP_RESOURCE_TYPES,
  BACKUP_STORAGE_PROVIDER_KEYS,
  BACKUP_STATUSES,
  BACKUP_TRIGGERS,
  CRON_NAME_PATTERN,
  CRON_OWNER_TYPE_KEYS,
  CRON_RUN_STATUSES,
  CRON_TIMEOUT_MAX,
  CRON_TIMEOUT_MIN,
  CRON_WORKING_DIR_MESSAGE,
  CRON_WORKING_DIR_PATTERN,
  MAX_BACKUP_KEEP,
  MAX_COMMAND_LENGTH,
  MAX_COMMAND_LINES,
  WEBHOOK_DELIVERY_STATUSES,
  WEBHOOK_EVENT_KEYS,
  WEBHOOK_FORMAT_KEYS,
  STORAGE_ACCESS_KEY_PATTERN,
  STORAGE_BUCKET_PATTERN,
  STORAGE_PREFIX_PATTERN,
  STORAGE_REGION_PATTERN,
  STORAGE_SECRET_PATTERN,
  SFTP_HOST_PATTERN,
  SFTP_PATH_PATTERN,
  SFTP_USER_PATTERN,
  isValidTimeZone,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const resourceType = z.enum(BACKUP_RESOURCE_TYPES);
const timezone = z.string().trim().max(64).refine(isValidTimeZone, 'Unknown time zone');
// Checked fully (with a readable message) by the service.
const schedule = z.string().trim().min(1, 'Required').max(100);

// ---- Backups ------------------------------------------------------------------

// storageId: also copy the backup to that storage (null: on the server only).
const storageId = z.uuid().nullable().default(null);
export const createBackupBody = z.object({ resourceType, resourceId: z.uuid(), storageId });
export const restoreBackupBody = z.object({
  // Save the current state as a backup first, to undo the restore.
  safetyBackup: z.boolean().default(true),
});
// With a website or app as resourceType and resourceId, includeDatabases=true
// also lists the backups (or schedules) of the databases linked to it.
const includeDatabases = z.stringbool().optional();
export const backupListQuery = listQuerySchema(['createdAt', 'size'], 'createdAt', {
  serverId: z.uuid().optional(),
  resourceType: resourceType.optional(),
  resourceId: z.uuid().optional(),
  includeDatabases,
  status: z.enum(BACKUP_STATUSES).optional(),
  trigger: z.enum(Object.keys(BACKUP_TRIGGERS)).optional(),
  search: z.string().max(100).optional(),
  storageId: z.uuid().optional(),
});

export const saveScheduleBody = z.object({
  resourceType,
  resourceId: z.uuid(),
  storageId,
  schedule,
  timezone: timezone.default('UTC'),
  keepCount: z.number().int().min(1).max(MAX_BACKUP_KEEP).default(7),
  enabled: z.boolean().default(true),
});
export const scheduleListQuery = listQuerySchema(['createdAt', 'nextRunAt'], 'nextRunAt', {
  serverId: z.uuid().optional(),
  resourceType: resourceType.optional(),
  resourceId: z.uuid().optional(),
  includeDatabases,
}, 'asc');

// ---- Backup storage -------------------------------------------------------------

function checkEndpoint(value, ctx) {
  if (!value) return;
  let url;
  try {
    url = new URL(value);
  } catch {
    ctx.addIssue({ code: 'custom', message: 'An address such as https://s3.us-east-1.amazonaws.com' });
    return;
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || (url.pathname !== '/' && url.pathname !== '')) {
    ctx.addIssue({ code: 'custom', message: 'Just the address, starting with https:// (no folder or bucket in it)' });
  }
}

const storageName = z.string().trim().min(1, 'Required').max(100);
const keepLocal = z.boolean().default(false);

const s3StorageBody = z.object({
  type: z.literal('s3'),
  name: storageName,
  provider: z.enum(BACKUP_STORAGE_PROVIDER_KEYS).default('other'),
  // Left blank for a provider whose address follows from the region.
  endpoint: z.string().trim().max(255).default('').superRefine(checkEndpoint),
  region: z.string().trim().toLowerCase().regex(STORAGE_REGION_PATTERN, 'Letters, digits and hyphens, such as us-east-1'),
  bucket: z.string().trim().regex(STORAGE_BUCKET_PATTERN, '3 to 63 letters, digits, dots and hyphens'),
  prefix: z
    .preprocess((v) => (typeof v === 'string' ? v.trim().replace(/^\/+|\/+$/g, '') : v), z.union([z.literal(''), z.string().max(200).regex(STORAGE_PREFIX_PATTERN, 'Folder names of letters, digits, ".", "_" and "-", separated by /')]))
    .default('vaultpanel'),
  pathStyle: z.boolean().default(false),
  accessKeyId: z.string().trim().regex(STORAGE_ACCESS_KEY_PATTERN, 'The access key ID, as the service shows it'),
  // Required when creating; blank keeps the saved one when editing.
  secretAccessKey: z.union([z.literal(''), z.string().trim().regex(STORAGE_SECRET_PATTERN, 'The secret key, as the service shows it')]).default(''),
  keepLocal,
});

// The panel makes the key pair itself; nothing secret is typed in.
const sftpStorageBody = z.object({
  type: z.literal('sftp'),
  name: storageName,
  host: z.string().trim().regex(SFTP_HOST_PATTERN, 'A host name or IP address, such as backup.example.com'),
  port: z.number().int().min(1).max(65535).default(22),
  username: z
    .string()
    .trim()
    .regex(SFTP_USER_PATTERN, 'A Linux user name on that server')
    .refine((v) => v !== 'root', 'Use a user made for backups, not root'),
  // A folder in the user's home (or an absolute one); created when needed.
  path: z
    .preprocess((v) => (typeof v === 'string' ? v.trim().replace(/\/+$/g, '') : v), z.union([z.literal(''), z.string().max(200).regex(SFTP_PATH_PATTERN, 'Folder names of letters, digits, ".", "_" and "-", separated by /')]))
    .default('vaultpanel-backups'),
  keepLocal,
  // Editing: forget the pinned host key, so the next check trusts the new one.
  trustNewHostKey: z.boolean().default(false),
});

// type defaults to s3 (the first kind of storage there was).
export const saveStorageBody = z.preprocess(
  (v) => (v && typeof v === 'object' && !Array.isArray(v) && v.type === undefined ? { ...v, type: 's3' } : v),
  z.discriminatedUnion('type', [s3StorageBody, sftpStorageBody]),
);
export const testStorageBody = z.object({ serverId: z.uuid() });

// ---- Cron jobs ------------------------------------------------------------------

const cronFields = {
  name: z.string().trim().regex(CRON_NAME_PATTERN, 'Up to 100 characters'),
  schedule,
  // One command per line, run in order; no shell (see the operations catalog).
  commands: z.string().trim().min(1, 'Required').max(MAX_COMMAND_LINES * (MAX_COMMAND_LENGTH + 1), 'Too long'),
  workingDir: z.union([z.literal(''), z.string().trim().regex(CRON_WORKING_DIR_PATTERN, CRON_WORKING_DIR_MESSAGE)]),
  timeoutSeconds: z.number().int().min(CRON_TIMEOUT_MIN).max(CRON_TIMEOUT_MAX),
  enabled: z.boolean(),
  appEnv: z.boolean(),
};

export const createCronBody = z.object({
  ownerType: z.enum(CRON_OWNER_TYPE_KEYS),
  ownerId: z.uuid(),
  ...cronFields,
  workingDir: cronFields.workingDir.default(''),
  timeoutSeconds: cronFields.timeoutSeconds.default(3600),
  enabled: cronFields.enabled.default(true),
  appEnv: cronFields.appEnv.default(false),
});
export const updateCronBody = z
  .object(Object.fromEntries(Object.entries(cronFields).map(([k, v]) => [k, v.optional()])))
  .refine((v) => Object.values(v).some((x) => x !== undefined), 'Nothing to update');
export const cronListQuery = listQuerySchema(['createdAt', 'name', 'lastRunAt'], 'name', {
  serverId: z.uuid().optional(),
  ownerType: z.enum(CRON_OWNER_TYPE_KEYS).optional(),
  ownerId: z.uuid().optional(),
  search: z.string().max(100).optional(),
}, 'asc');
export const cronRunsQuery = listQuerySchema(['startedAt'], 'startedAt', {
  status: z.enum(Object.keys(CRON_RUN_STATUSES)).optional(),
});

// ---- Webhooks ---------------------------------------------------------------------

const webhookFields = {
  name: z.string().trim().min(1, 'Required').max(100),
  url: z.string().trim().min(1, 'Required').max(2000),
  format: z.enum(WEBHOOK_FORMAT_KEYS),
  events: z.array(z.enum(WEBHOOK_EVENT_KEYS)).min(1, 'Choose at least one event').max(WEBHOOK_EVENT_KEYS.length),
  enabled: z.boolean(),
};
export const createWebhookBody = z.object({ ...webhookFields, format: webhookFields.format.default('json'), enabled: webhookFields.enabled.default(true) });
export const updateWebhookBody = z
  .object({ ...Object.fromEntries(Object.entries(webhookFields).map(([k, v]) => [k, v.optional()])), rotateSecret: z.boolean().optional() })
  .refine((v) => Object.entries(v).some(([k, x]) => x !== undefined && !(k === 'rotateSecret' && x === false)), 'Nothing to update');
export const webhookListQuery = listQuerySchema(['createdAt', 'name'], 'name', {}, 'asc');
export const deliveryListQuery = listQuerySchema(['createdAt'], 'createdAt', {
  status: z.enum(WEBHOOK_DELIVERY_STATUSES).optional(),
});
export const deliveryParams = z.object({ id: z.uuid(), deliveryId: z.uuid() });
