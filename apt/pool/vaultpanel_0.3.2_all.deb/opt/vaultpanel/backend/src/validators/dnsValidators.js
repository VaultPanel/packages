import { z } from 'zod';
import {
  CLOUDFLARE_TOKEN_PATTERN,
  DNS_CAA_TAGS,
  DNS_EMAIL_PATTERN,
  DNS_HOSTNAME_MESSAGE,
  DNS_HOSTNAME_PATTERN,
  DNS_PROVIDER_NAME_PATTERN,
  DNS_PROVIDER_TYPE_KEYS,
  DNS_RECORD_TYPE_KEYS,
  DNS_TTL,
  DOMAIN_MESSAGE,
  DOMAIN_PATTERN,
  isIPv4,
  isIPv6,
  MAX_DNS_NAMESERVERS,
  MAX_DNS_TXT_LENGTH,
  NAMECHEAP_KEY_PATTERN,
  NAMECHEAP_USER_PATTERN,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';

const domain = z.string().trim().toLowerCase().transform((v) => v.replace(/\.$/, '')).pipe(z.string().regex(DOMAIN_PATTERN, DOMAIN_MESSAGE));
const ttl = z.number().int().min(DNS_TTL.min, `At least ${DNS_TTL.min} seconds`).max(DNS_TTL.max, `At most ${DNS_TTL.max} seconds (a week)`);
const hostname = z.string().trim().toLowerCase().transform((v) => v.replace(/\.$/, '')).pipe(z.string().regex(DNS_HOSTNAME_PATTERN, DNS_HOSTNAME_MESSAGE));
const soaEmail = z.string().trim().toLowerCase().regex(DNS_EMAIL_PATTERN, 'Enter an email address such as hostmaster@example.com');
const int16 = z.number().int().min(0).max(65535);

export const createZoneBody = z.object({
  serverId: z.uuid(),
  domain,
  // Where the domain, www (and mail) point. The server's public address
  // unless given.
  ipv4: z.string().trim().refine(isIPv4, 'Enter an IPv4 address such as 203.0.113.10').optional(),
  ipv6: z.string().trim().refine(isIPv6, 'Enter an IPv6 address such as 2001:db8::10').nullable().optional(),
  // ns1 and ns2 of the domain unless given.
  nameservers: z.array(hostname).min(1).max(MAX_DNS_NAMESERVERS).optional(),
  // Also add mail, MX and SPF records.
  mailRecords: z.boolean().default(true),
  defaultTtl: ttl.optional(),
  soaEmail: soaEmail.optional(),
});

export const updateZoneBody = z
  .object({ defaultTtl: ttl.optional(), soaEmail: soaEmail.optional() })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

const recordFields = {
  name: z.string().trim().max(253),
  type: z.enum(DNS_RECORD_TYPE_KEYS),
  ttl: ttl.nullable().optional(),
  value: z.string().max(MAX_DNS_TXT_LENGTH),
  priority: int16.nullable().optional(),
  weight: int16.nullable().optional(),
  port: int16.nullable().optional(),
  tag: z.enum(DNS_CAA_TAGS).nullable().optional(),
};
export const createRecordBody = z.object(recordFields);
export const updateRecordBody = z
  .object(Object.fromEntries(Object.entries(recordFields).map(([k, v]) => [k, v.optional()])))
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const zoneListQuery = listQuerySchema(['domain', 'createdAt'], 'domain', {
  search: z.string().max(100).optional(),
  serverId: z.uuid().optional(),
}, 'asc');

export const recordParams = z.object({ id: z.uuid(), recordId: z.uuid() });

// A DNS provider's account. A blank secret on update keeps the saved one.
function dnsProviderBody({ secretRequired }) {
  return z
    .object({
      name: z.string().trim().regex(DNS_PROVIDER_NAME_PATTERN, 'Up to 60 letters, digits, spaces and . _ ( ) -, starting with a letter or digit'),
      type: z.enum(DNS_PROVIDER_TYPE_KEYS),
      username: z.string().trim().max(64).nullable().optional(),
      secret: z.string().trim().max(200).optional(),
    })
    .superRefine((v, ctx) => {
      if (v.type === 'namecheap' && !NAMECHEAP_USER_PATTERN.test(v.username ?? '')) ctx.addIssue({ code: 'custom', path: ['username'], message: 'Enter your Namecheap user name' });
      if (!v.secret) {
        if (secretRequired) ctx.addIssue({ code: 'custom', path: ['secret'], message: 'Required' });
      } else if (!(v.type === 'cloudflare' ? CLOUDFLARE_TOKEN_PATTERN : NAMECHEAP_KEY_PATTERN).test(v.secret)) {
        ctx.addIssue({ code: 'custom', path: ['secret'], message: v.type === 'cloudflare' ? 'Paste the Cloudflare API token' : 'Paste the Namecheap API key' });
      }
    });
}
export const createDnsProviderBody = dnsProviderBody({ secretRequired: true });
export const updateDnsProviderBody = dnsProviderBody({ secretRequired: false });

// The name servers customers on a server are told to use, and whether a
// zone is added there for each new customer domain.
export const customerDnsBody = z.object({
  nameservers: z.array(hostname).max(MAX_DNS_NAMESERVERS, `Up to ${MAX_DNS_NAMESERVERS} name servers`),
  autoZones: z.boolean(),
});
