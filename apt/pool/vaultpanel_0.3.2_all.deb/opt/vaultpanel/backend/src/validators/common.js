import { z } from 'zod';
import { PASSWORD_MAX_LENGTH, PASSWORD_MIN_LENGTH } from '../utils/password.js';

export const idParam = z.object({ id: z.uuid() });
export const email = z.string().trim().max(254).pipe(z.email('Enter a valid email address'));
export const password = z
  .string()
  .min(PASSWORD_MIN_LENGTH, `Use at least ${PASSWORD_MIN_LENGTH} characters`)
  .max(PASSWORD_MAX_LENGTH);
export const personName = z.string().trim().min(1, 'Required').max(120);
export const totpCode = z.string().trim().regex(/^\d{6}$/, 'Enter the 6-digit code');
