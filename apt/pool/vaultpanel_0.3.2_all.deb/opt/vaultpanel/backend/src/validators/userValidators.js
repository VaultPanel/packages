import { z } from 'zod';
import { STAFF_ROLE_NAMES } from '@vaultpanel/shared';
import { email, personName } from './common.js';

export const inviteUserBody = z.object({ email, name: personName, role: z.enum(STAFF_ROLE_NAMES) });
export const updateUserBody = z
  .object({ name: personName.optional(), role: z.enum(STAFF_ROLE_NAMES).optional(), isActive: z.boolean().optional() })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
