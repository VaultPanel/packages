import { z } from 'zod';
import { domain } from './websiteValidators.js';

export const panelDomainBody = z.object({
  domain,
  proxyPort: z.number().int().min(1).max(65535).optional(),
});

export const panelAddressBody = z.object({ use: z.boolean() });
