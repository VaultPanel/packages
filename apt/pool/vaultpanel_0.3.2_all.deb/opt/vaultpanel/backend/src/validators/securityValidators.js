import { z } from 'zod';
import {
  FAIL2BAN_LIMITS,
  FAIL2BAN_MAX_IGNORE,
  FIREWALL_ACTION_KEYS,
  FIREWALL_COMMENT_MESSAGE,
  FIREWALL_COMMENT_PATTERN,
  FIREWALL_DIRECTION_KEYS,
  FIREWALL_INCOMING_POLICY_KEYS,
  FIREWALL_OUTGOING_POLICY_KEYS,
  FIREWALL_PROTOCOL_KEYS,
  isAddressOrNetwork,
  PANEL_ACCESS_MAX_ADDRESSES,
  PANEL_ACCESS_NOTE_PATTERN,
  PANEL_ACCESS_SCOPE_KEYS,
  portSpecMessage,
  sourceMessage,
  SSH_FINGERPRINT_PATTERN,
  SSH_MAX_AUTH_TRIES_MAX,
  SSH_MAX_AUTH_TRIES_MIN,
  SSH_MAX_PORTS,
  SSH_PUBLIC_KEY_MESSAGE,
  SSH_PUBLIC_KEY_PATTERN,
  SSH_ROOT_LOGIN_KEYS,
  SSH_USER_PATTERN,
  sshPortMessage,
  TWO_FACTOR_POLICY_KEYS,
} from '@vaultpanel/shared';

const checked = (schema, check) => schema.superRefine((value, ctx) => {
  const message = check(value);
  if (message) ctx.addIssue({ code: 'custom', message });
});

const port = checked(z.string().trim().max(100), (v) => (v === '' ? null : portSpecMessage(v)));
const source = checked(z.string().trim().max(50), sourceMessage);

const rule = {
  action: z.enum(FIREWALL_ACTION_KEYS),
  direction: z.enum(FIREWALL_DIRECTION_KEYS).default('in'),
  protocol: z.enum(FIREWALL_PROTOCOL_KEYS).default('tcp'),
  port: port.default(''),
  source: source.default('any'),
  // Where an outgoing rule applies to.
  destination: source.default('any'),
};
const directionFits = (r) => (r.direction === 'in' ? r.destination === 'any' : r.source === 'any');

export const firewallStateBody = z.object({ enabled: z.boolean() });
export const firewallRuleBody = z
  .object({ ...rule, comment: z.string().trim().max(60).regex(FIREWALL_COMMENT_PATTERN, FIREWALL_COMMENT_MESSAGE).optional() })
  .refine(directionFits, { message: 'An incoming rule has a source; an outgoing rule has a destination', path: ['destination'] })
  .refine((r) => r.port || r.source !== 'any' || r.destination !== 'any', { message: 'Give a port, an address, or both', path: ['port'] })
  .refine((r) => !(r.protocol === 'any' && /[,:]/.test(r.port)), { message: 'Choose TCP or UDP for a list or range of ports', path: ['protocol'] });
export const firewallRuleDeleteBody = z
  .object({
    ...rule,
    app: z.string().max(64).regex(/^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/).optional(),
  })
  .refine(directionFits, { message: 'An incoming rule has a source; an outgoing rule has a destination', path: ['destination'] });
export const firewallDefaultBody = z
  .object({ incoming: z.enum(FIREWALL_INCOMING_POLICY_KEYS).optional(), outgoing: z.enum(FIREWALL_OUTGOING_POLICY_KEYS).optional() })
  .refine((b) => b.incoming || b.outgoing, { message: 'Choose a default', path: ['incoming'] });

export const sshSettingsBody = z.object({
  permitRootLogin: z.enum(SSH_ROOT_LOGIN_KEYS),
  passwordAuthentication: z.boolean(),
  maxAuthTries: z.number().int().min(SSH_MAX_AUTH_TRIES_MIN).max(SSH_MAX_AUTH_TRIES_MAX),
});
const sshUser = z.string().max(32).regex(SSH_USER_PATTERN, 'Must be a Linux account name').optional();
export const sshKeyBody = z.object({ key: z.string().trim().max(16_200).regex(SSH_PUBLIC_KEY_PATTERN, SSH_PUBLIC_KEY_MESSAGE), user: sshUser });
export const sshKeyDeleteBody = z.object({ fingerprint: z.string().regex(SSH_FINGERPRINT_PATTERN, 'Must be a SHA256 key fingerprint'), user: sshUser });
export const sshPortsBody = z.object({
  ports: z
    .array(checked(z.number().int(), sshPortMessage))
    .min(1)
    .max(SSH_MAX_PORTS)
    .refine((list) => new Set(list).size === list.length, 'Each port only once'),
});

const limit = (key) => z.number().int().min(FAIL2BAN_LIMITS[key].min).max(FAIL2BAN_LIMITS[key].max).default(FAIL2BAN_LIMITS[key].default);
export const loginBannerBody = z.object({ vaultpanelOnly: z.boolean() });
export const fail2banBody = z.object({
  enabled: z.boolean(),
  maxRetry: limit('maxRetry'),
  findTimeMinutes: limit('findTimeMinutes'),
  banTimeMinutes: limit('banTimeMinutes'),
  ignoreIps: z
    .array(checked(z.string().trim().max(50), (v) => (isAddressOrNetwork(v) ? null : 'Must be an IP address or network')))
    .max(FAIL2BAN_MAX_IGNORE)
    .refine((list) => new Set(list).size === list.length, 'Each address only once')
    .default([]),
});
export const unbanBody = z.object({ ip: checked(z.string().trim().max(45), (v) => (isAddressOrNetwork(v) && !v.includes('/') ? null : 'Must be an IP address')) });
export const autoUpdatesBody = z.object({ enabled: z.boolean() });
export const panelAccessBody = z.object({
  enabled: z.boolean(),
  scope: z.enum(PANEL_ACCESS_SCOPE_KEYS).default('everyone'),
  addresses: z
    .array(
      z.object({
        address: checked(z.string().trim().max(50), (v) => (isAddressOrNetwork(v) ? null : 'Must be an IP address or a network such as 203.0.113.0/24')),
        note: z.string().trim().max(60).regex(PANEL_ACCESS_NOTE_PATTERN, "Letters, digits, spaces and . , : _ ( ) / + ' - only").default(''),
      }),
    )
    .max(PANEL_ACCESS_MAX_ADDRESSES)
    .refine((list) => new Set(list.map((a) => a.address)).size === list.length, 'Each address only once'),
});
export const twoFactorPolicyBody = z.object({ twoFactorPolicy: z.enum(TWO_FACTOR_POLICY_KEYS) });
