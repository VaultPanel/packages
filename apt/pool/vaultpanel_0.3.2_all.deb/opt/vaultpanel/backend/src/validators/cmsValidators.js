import { z } from 'zod';
import {
  CMS_ADMIN_PASSWORD_MESSAGE,
  CMS_ADMIN_PASSWORD_PATTERN,
  CMS_ADMIN_USER_MESSAGE,
  CMS_ADMIN_USER_PATTERN,
  CMS_APP_KEYS,
  CMS_PATH_MESSAGE,
  CMS_PATH_PATTERN,
  CMS_TITLE_PATTERN,
  MAX_SITE_DOMAINS,
  PHP_VERSION_PATTERN,
  SITE_NAME_MESSAGE,
  SITE_NAME_PATTERN,
} from '@vaultpanel/shared';
import { listQuerySchema } from '../utils/pagination.js';
import { email } from './common.js';
import { domain } from './websiteValidators.js';

const blankToUndefined = (schema) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? undefined : v), schema.optional());

export const createCmsInstallBody = z
  .object({
    app: z.enum(CMS_APP_KEYS),
    // An existing PHP website, or a new one made with the app.
    websiteId: z.uuid().optional(),
    newWebsite: z
      .object({
        serverId: z.uuid(),
        name: z.string().trim().regex(SITE_NAME_PATTERN, SITE_NAME_MESSAGE),
        domains: z.array(domain).min(1, 'Add a domain').max(MAX_SITE_DOMAINS),
        phpVersion: z.string().regex(PHP_VERSION_PATTERN, 'Choose a PHP version'),
      })
      .optional(),
    // A folder of the document root (WordPress, Joomla) or the project folder
    // (Drupal, Laravel). Empty installs at the site's root.
    path: z.preprocess((v) => (typeof v === 'string' ? v.trim().replace(/^\/+|\/+$/g, '') : v), z.union([z.literal(''), z.string().regex(CMS_PATH_PATTERN, CMS_PATH_MESSAGE)]).default('')),
    title: blankToUndefined(z.string().trim().max(100).regex(CMS_TITLE_PATTERN, 'At most 100 characters')),
    adminUser: blankToUndefined(z.string().trim().regex(CMS_ADMIN_USER_PATTERN, CMS_ADMIN_USER_MESSAGE)),
    adminEmail: blankToUndefined(email),
    // Generated when left out.
    adminPassword: blankToUndefined(z.string().regex(CMS_ADMIN_PASSWORD_PATTERN, CMS_ADMIN_PASSWORD_MESSAGE)),
  })
  .superRefine((value, ctx) => {
    if (Boolean(value.websiteId) === Boolean(value.newWebsite)) {
      ctx.addIssue({ code: 'custom', path: ['websiteId'], message: 'Choose a website, or describe a new one' });
    }
  });

export const removeCmsInstallQuery = z.object({ removeDatabase: z.stringbool().default(false) });

export const cmsInstallListQuery = listQuerySchema(['createdAt'], 'createdAt', {
  websiteId: z.uuid().optional(),
  serverId: z.uuid().optional(),
});
