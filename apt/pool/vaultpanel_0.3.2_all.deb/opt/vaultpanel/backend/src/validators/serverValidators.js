import { z } from 'zod';
import { OPERATION_TYPES } from '@vaultpanel/shared';
import { METRIC_RANGES } from '../services/metricsService.js';

export const serverName = z
  .string()
  .trim()
  .min(1, 'Required')
  .max(100)
  .regex(/^[\p{L}\p{N} ._()-]+$/u, 'Use letters, numbers, spaces and . _ - ( )');

export const createServerBody = z.object({ name: serverName });
export const updateServerBody = z.object({ name: serverName });
export const metricsQuery = z.object({ range: z.enum(Object.keys(METRIC_RANGES)).default('1h') });
export const createJobBody = z.object({
  type: z.enum(OPERATION_TYPES),
  params: z.record(z.string(), z.unknown()).default({}),
});

// The size of the browser's terminal when it opens.
export const terminalBody = z
  .object({
    cols: z.coerce.number().int().min(2).max(1000).default(80),
    rows: z.coerce.number().int().min(2).max(500).default(24),
  })
  .default({ cols: 80, rows: 24 });
