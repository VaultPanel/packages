import { sendOk } from '../utils/response.js';

const databases = (req) => req.app.locals.services.databases;

export const databaseController = {
  async list(req, res) {
    sendOk(res, await databases(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await databases(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await databases(req).create(req.actor, req.valid.body), { status: 202, message: 'Creating the database on the server' });
  },
  async update(req, res) {
    sendOk(res, await databases(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'Saved' });
  },
  async remove(req, res) {
    sendOk(res, await databases(req).remove(req.actor, req.valid.params.id), { status: 202, message: 'Deleting the database' });
  },
  async retry(req, res) {
    sendOk(res, await databases(req).retry(req.actor, req.valid.params.id), { status: 202, message: 'Creating the database again' });
  },
  // The database interface answers with a job; the browser waits for its result.
  async tables(req, res) {
    sendOk(res, await databases(req).tables(req.actor, req.valid.params.id), { status: 202 });
  },
  async rows(req, res) {
    sendOk(res, await databases(req).tableRows(req.actor, req.valid.params.id, req.valid.body), { status: 202 });
  },
  async query(req, res) {
    sendOk(res, await databases(req).runQuery(req.actor, req.valid.params.id, req.valid.body), { status: 202 });
  },
  async phpmyadmin(req, res) {
    sendOk(res, await databases(req).openPhpMyAdmin(req.actor, req.valid.params.id), { status: 202 });
  },
};

export const databaseUserController = {
  async list(req, res) {
    sendOk(res, await databases(req).listUsers(req.actor, req.valid.query));
  },
  async create(req, res) {
    sendOk(res, await databases(req).createUser(req.actor, req.valid.body), { status: 202, message: 'Creating the user' });
  },
  async update(req, res) {
    sendOk(res, await databases(req).updateUser(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Updating the user' });
  },
  async remove(req, res) {
    sendOk(res, await databases(req).removeUser(req.actor, req.valid.params.id), { status: 202, message: 'Deleting the user' });
  },
  async password(req, res) {
    sendOk(res, await databases(req).revealPassword(req.actor, req.valid.params.id));
  },
};
