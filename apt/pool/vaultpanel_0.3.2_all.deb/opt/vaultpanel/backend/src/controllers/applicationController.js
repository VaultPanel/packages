import { sendOk } from '../utils/response.js';

const apps = (req) => req.app.locals.services.applications;

// Changes return 202: the app record is saved and a job carries the change
// out on the server. The UI follows the job.
const queued = (res, result, message) => sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? message : 'Saved' });

const CONTROL_MESSAGES = { start: 'Starting the app', stop: 'Stopping the app', restart: 'Restarting the app' };

export const applicationController = {
  async list(req, res) {
    sendOk(res, await apps(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await apps(req).get(req.actor, req.valid.params.id));
  },
  async suggestPort(req, res) {
    sendOk(res, await apps(req).suggestPort(req.actor, req.valid.query.serverId));
  },
  async create(req, res) {
    sendOk(res, await apps(req).create(req.actor, req.valid.body), { status: 202, message: 'App saved. The agent is setting it up on the server.' });
  },
  async update(req, res) {
    const result = await apps(req).update(req.actor, req.valid.params.id, req.valid.body);
    sendOk(res, result, { message: result.changed.length ? 'Settings saved' : 'Nothing to change' });
  },
  async getEnv(req, res) {
    sendOk(res, await apps(req).getEnv(req.actor, req.valid.params.id));
  },
  async setEnv(req, res) {
    sendOk(res, await apps(req).setEnv(req.actor, req.valid.params.id, req.valid.body), { message: 'Environment saved' });
  },
  async deploy(req, res) {
    queued(res, await apps(req).deploy(req.actor, req.valid.params.id), 'Deploying the app');
  },
  async rollback(req, res) {
    queued(res, await apps(req).rollback(req.actor, req.valid.params.id, req.valid.body), 'Rolling back');
  },
  async control(req, res) {
    const { id, action } = req.valid.params;
    queued(res, await apps(req).control(req.actor, id, action), CONTROL_MESSAGES[action]);
  },
  async apply(req, res) {
    queued(res, await apps(req).apply(req.actor, req.valid.params.id), 'Applying the settings and restarting the app');
  },
  async scale(req, res) {
    const result = await apps(req).scale(req.actor, req.valid.params.id, req.valid.body);
    sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? 'Changing how many copies of the app run' : 'Saved. It applies when the app next starts.' });
  },
  async refresh(req, res) {
    sendOk(res, await apps(req).refresh(req.actor, req.valid.params.id), { status: 202, message: 'Checking the app' });
  },
  async logs(req, res) {
    sendOk(res, await apps(req).logs(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Reading the log' });
  },
  async addWebsite(req, res) {
    queued(res, await apps(req).addWebsite(req.actor, req.valid.params.id, req.valid.body), 'Adding the domains');
  },
  async enableWebhook(req, res) {
    sendOk(res, await apps(req).enableWebhook(req.actor, req.valid.params.id), { message: 'Copy the webhook URL now: it is shown only once' });
  },
  async disableWebhook(req, res) {
    sendOk(res, await apps(req).disableWebhook(req.actor, req.valid.params.id), { message: 'Push to deploy turned off' });
  },
  async remove(req, res) {
    queued(res, await apps(req).remove(req.actor, req.valid.params.id, req.valid.query), 'Deleting the app from the server');
  },
  async hook(req, res) {
    const event = req.get('x-github-event') ?? req.get('x-gitlab-event') ?? req.get('x-gitea-event') ?? req.get('x-event-key') ?? null;
    const request = { event, get: (name) => req.get(name), rawBody: req.rawBody };
    // The token belongs to a website deployed from Git, or else to an app.
    const result =
      (await req.app.locals.services.siteDeploys.deployFromHook(req.valid.params.token, req.body, request)) ??
      (await apps(req).deployFromHook(req.valid.params.token, req.body, request));
    sendOk(res, result, { status: result.ignored ? 200 : 202, message: result.ignored ? result.reason : 'Deploying' });
  },
};

export const deploymentController = {
  async list(req, res) {
    sendOk(res, await apps(req).listDeployments(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await apps(req).getDeployment(req.actor, req.valid.params.id));
  },
};
