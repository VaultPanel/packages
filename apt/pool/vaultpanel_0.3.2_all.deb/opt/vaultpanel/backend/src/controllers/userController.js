import { sendOk } from '../utils/response.js';

const users = (req) => req.app.locals.services.users;

// Says whether the link went by email or has to be handed over.
export function linkMessage(start, what, email) {
  if (email?.sent) return `${start} The ${what} was emailed to ${email.to}.`;
  if (email) return `${start} The email could not be sent (${email.error}). Send them the ${what} yourself.`;
  return `${start} Send them the ${what}.`;
}

export const userController = {
  async list(req, res) {
    sendOk(res, await users(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await users(req).get(req.actor, req.valid.params.id));
  },
  async invite(req, res) {
    const result = await users(req).invite(req.actor, req.valid.body);
    sendOk(res, result, { status: 201, message: linkMessage('User created.', 'invite link', result.email) });
  },
  async update(req, res) {
    sendOk(res, await users(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'User updated' });
  },
  async issuePasswordReset(req, res) {
    const result = await users(req).issuePasswordReset(req.actor, req.valid.params.id);
    sendOk(res, result, { message: linkMessage('Reset link created.', 'link', result.email) });
  },
  async resetTwoFactor(req, res) {
    sendOk(res, await users(req).resetTwoFactor(req.actor, req.valid.params.id), {
      message: 'Two-factor sign-in turned off. They can sign in with their password and set it up again.',
    });
  },
  async listRoles(req, res) {
    sendOk(res, await req.app.locals.services.accessControl.listRoles(req.actor));
  },
  async listAudit(req, res) {
    sendOk(res, await req.app.locals.services.auditQuery.list(req.actor, req.valid.query));
  },
};
