import { sendOk } from '../utils/response.js';

const assistant = (req) => req.app.locals.services.assistant;

export const assistantController = {
  async status(req, res) {
    sendOk(res, await assistant(req).status(req.actor));
  },
  async getSettings(req, res) {
    sendOk(res, await assistant(req).getSettings(req.actor));
  },
  async updateSettings(req, res) {
    sendOk(res, await assistant(req).updateSettings(req.actor, req.valid.body), { message: 'Assistant settings saved' });
  },
  async testSettings(req, res) {
    sendOk(res, await assistant(req).testSettings(req.actor, req.valid.body), { message: 'The AI provider answered' });
  },
  async localModelStatus(req, res) {
    sendOk(res, await assistant(req).localModelStatus(req.actor));
  },
  async installLocalModel(req, res) {
    sendOk(res, await assistant(req).installLocalModel(req.actor, req.valid.body), { status: 202, message: 'Installing the model on this server' });
  },
  async removeLocalModel(req, res) {
    sendOk(res, await assistant(req).removeLocalModel(req.actor, req.valid.body), { status: 202, message: 'Removing the model' });
  },
  async uninstallLocalModel(req, res) {
    sendOk(res, await assistant(req).uninstallLocalModel(req.actor), { status: 202, message: 'Removing the models and Ollama' });
  },
  async listConversations(req, res) {
    sendOk(res, await assistant(req).listConversations(req.actor));
  },
  async startConversation(req, res) {
    sendOk(res, await assistant(req).startConversation(req.actor, req.valid.body), { status: 202, message: 'The assistant is looking into it' });
  },
  async getConversation(req, res) {
    sendOk(res, await assistant(req).getConversation(req.actor, req.valid.params.id));
  },
  async ask(req, res) {
    sendOk(res, await assistant(req).ask(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'The assistant is looking into it' });
  },
  async retry(req, res) {
    sendOk(res, await assistant(req).retry(req.actor, req.valid.params.id), { status: 202, message: 'Trying again' });
  },
  async removeConversation(req, res) {
    await assistant(req).removeConversation(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Conversation deleted' });
  },
  async approveAction(req, res) {
    const action = await assistant(req).approveAction(req.actor, req.valid.params.id);
    sendOk(res, action, { message: action.status === 'failed' ? 'The change could not start' : 'Change started' });
  },
  async cancelAction(req, res) {
    sendOk(res, await assistant(req).cancelAction(req.actor, req.valid.params.id), { message: 'Change cancelled' });
  },
};
