import { OPERATIONS } from '@vaultpanel/shared';
import { sendOk } from '../utils/response.js';

const jobs = (req) => req.app.locals.services.jobs;

export const jobController = {
  async list(req, res) {
    sendOk(res, await jobs(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await jobs(req).get(req.actor, req.valid.params.id, { afterLogId: req.valid.query.afterLogId }));
  },
  async cancel(req, res) {
    sendOk(res, await jobs(req).cancel(req.actor, req.valid.params.id), { message: 'Job cancelled' });
  },
  operations(req, res) {
    const items = Object.entries(OPERATIONS).map(([type, op]) => ({
      type,
      label: op.label,
      available: op.available,
      phase: op.phase ?? null,
      permission: op.permission ?? null,
      dangerous: Boolean(op.dangerous),
    }));
    sendOk(res, { items });
  },
};
