import { sendOk } from '../utils/response.js';

const subdomains = (req) => req.app.locals.services.subdomains;

export const subdomainController = {
  async parents(req, res) {
    sendOk(res, await subdomains(req).parents(req.actor));
  },
  async create(req, res) {
    sendOk(res, await subdomains(req).create(req.actor, req.valid.body), { status: 202, message: 'Subdomain saved. The agent is creating its site on the server.' });
  },
};
