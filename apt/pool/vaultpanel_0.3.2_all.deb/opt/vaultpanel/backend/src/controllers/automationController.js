import { sendOk } from '../utils/response.js';

const services = (req) => req.app.locals.services;

export const backupController = {
  async list(req, res) {
    sendOk(res, await services(req).backups.list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await services(req).backups.get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await services(req).backups.create(req.actor, req.valid.body), { status: 202, message: 'Backing up' });
  },
  async remove(req, res) {
    sendOk(res, await services(req).backups.remove(req.actor, req.valid.params.id), { status: 202, message: 'Deleting the backup' });
  },
  async restore(req, res) {
    sendOk(res, await services(req).backups.restore(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Restoring' });
  },
  async prepareDownload(req, res) {
    const result = await services(req).backups.prepareDownload(req.actor, req.valid.params.id);
    sendOk(res, result, { status: result.ready ? 200 : 202, message: result.ready ? 'Ready to download' : 'Copying the backup to the panel' });
  },
  async download(req, res, next) {
    const file = await services(req).backups.openDownload(req.actor, req.valid.params.id);
    res.set('Cache-Control', 'no-store');
    res.download(file.path, file.filename, { dotfiles: 'allow' }, (err) => {
      if (err && !res.headersSent) next(err);
    });
  },
};

export const backupStorageController = {
  async list(req, res) {
    sendOk(res, await services(req).backupStorage.list(req.actor));
  },
  async get(req, res) {
    sendOk(res, await services(req).backupStorage.get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await services(req).backupStorage.create(req.actor, req.valid.body), { status: 201, message: 'Storage added' });
  },
  async update(req, res) {
    sendOk(res, await services(req).backupStorage.update(req.actor, req.valid.params.id, req.valid.body), { message: 'Storage saved' });
  },
  async remove(req, res) {
    await services(req).backupStorage.remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Storage removed' });
  },
  async test(req, res) {
    sendOk(res, await services(req).backupStorage.test(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Checking the storage' });
  },
};

export const backupScheduleController = {
  async list(req, res) {
    sendOk(res, await services(req).backups.listSchedules(req.actor, req.valid.query));
  },
  async save(req, res) {
    sendOk(res, await services(req).backups.saveSchedule(req.actor, req.valid.body), { message: 'Schedule saved' });
  },
  async remove(req, res) {
    await services(req).backups.removeSchedule(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Schedule removed' });
  },
};

export const cronController = {
  async list(req, res) {
    sendOk(res, await services(req).cron.list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await services(req).cron.get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await services(req).cron.create(req.actor, req.valid.body), { status: 202, message: 'Saving the cron job on the server' });
  },
  async update(req, res) {
    const result = await services(req).cron.update(req.actor, req.valid.params.id, req.valid.body);
    sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? 'Saving the cron job on the server' : 'Saved' });
  },
  async remove(req, res) {
    sendOk(res, await services(req).cron.remove(req.actor, req.valid.params.id), { status: 202, message: 'Deleting the cron job' });
  },
  async run(req, res) {
    sendOk(res, await services(req).cron.run(req.actor, req.valid.params.id), { status: 202, message: 'Running' });
  },
  async runs(req, res) {
    sendOk(res, await services(req).cron.runs(req.actor, req.valid.params.id, req.valid.query));
  },
};

export const webhookController = {
  async list(req, res) {
    sendOk(res, await services(req).webhooks.list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await services(req).webhooks.get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await services(req).webhooks.create(req.actor, req.valid.body), { status: 201, message: 'Webhook added' });
  },
  async update(req, res) {
    sendOk(res, await services(req).webhooks.update(req.actor, req.valid.params.id, req.valid.body), { message: 'Saved' });
  },
  async remove(req, res) {
    await services(req).webhooks.remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Webhook deleted' });
  },
  async test(req, res) {
    sendOk(res, await services(req).webhooks.test(req.actor, req.valid.params.id));
  },
  async deliveries(req, res) {
    sendOk(res, await services(req).webhooks.deliveries(req.actor, req.valid.params.id, req.valid.query));
  },
  async redeliver(req, res) {
    sendOk(res, await services(req).webhooks.redeliver(req.actor, req.valid.params.id, req.valid.params.deliveryId));
  },
};
