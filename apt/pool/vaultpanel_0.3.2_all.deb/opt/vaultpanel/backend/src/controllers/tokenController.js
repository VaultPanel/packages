import { API_TOKEN_SCOPES } from '@vaultpanel/shared';
import { sendOk } from '../utils/response.js';

const tokens = (req) => req.app.locals.services.apiTokens;

export const tokenController = {
  async list(req, res) {
    sendOk(res, await tokens(req).list(req.actor, req.valid.query));
  },
  // The scopes this panel offers, so tools installed separately (the CLI from
  // npm) always describe the panel they talk to rather than their own copy.
  async scopes(req, res) {
    const items = Object.entries(API_TOKEN_SCOPES).map(([key, scope]) => ({
      key,
      label: scope.label,
      description: scope.description,
      permissions: scope.permissions.length,
    }));
    sendOk(res, { items });
  },
  async create(req, res) {
    sendOk(res, await tokens(req).create(req.actor, req.valid.body), {
      status: 201,
      message: 'API token created. Copy it now: it is not shown again.',
    });
  },
  async revoke(req, res) {
    sendOk(res, await tokens(req).revoke(req.actor, req.valid.params.id), { message: 'API token revoked' });
  },
};
