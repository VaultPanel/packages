import { sendOk } from '../utils/response.js';

const websites = (req) => req.app.locals.services.websites;
const monitor = (req) => req.app.locals.services.websiteMonitor;

// Changes return 202: the website record is saved and a job carries the
// change out on the server. The UI follows the job.
const queued = (res, result, message) => sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? message : 'Nothing to change' });

export const websiteController = {
  async list(req, res) {
    sendOk(res, await websites(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await websites(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await websites(req).create(req.actor, req.valid.body), { status: 202, message: 'Website saved. The agent is creating it on the server.' });
  },
  async update(req, res) {
    queued(res, await websites(req).update(req.actor, req.valid.params.id, req.valid.body), 'Applying the new settings on the server');
  },
  async enable(req, res) {
    queued(res, await websites(req).setEnabled(req.actor, req.valid.params.id, true), 'Enabling the website');
  },
  async disable(req, res) {
    queued(res, await websites(req).setEnabled(req.actor, req.valid.params.id, false), 'Disabling the website');
  },
  async retry(req, res) {
    queued(res, await websites(req).retry(req.actor, req.valid.params.id), 'Creating the website again');
  },
  async remove(req, res) {
    queued(res, await websites(req).remove(req.actor, req.valid.params.id, req.valid.query), 'Deleting the website from the server');
  },
  async issueSsl(req, res) {
    queued(res, await websites(req).issueSsl(req.actor, req.valid.params.id, req.valid.body), req.valid.body.wildcard || req.valid.body.dnsProviderId ? 'Requesting a wildcard certificate from Let’s Encrypt' : 'Requesting a certificate from Let’s Encrypt');
  },
  async installSsl(req, res) {
    queued(res, await websites(req).installSsl(req.actor, req.valid.params.id, req.valid.body), 'Installing the certificate');
  },
  async renewSsl(req, res) {
    queued(res, await websites(req).renewSsl(req.actor, req.valid.params.id, req.valid.body), 'Renewing the certificate');
  },
  async disableSsl(req, res) {
    queued(res, await websites(req).disableSsl(req.actor, req.valid.params.id), 'Turning HTTPS off');
  },
  async logs(req, res) {
    sendOk(res, await websites(req).logs(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Reading the log' });
  },
  async files(req, res) {
    const { id, action } = req.valid.params;
    sendOk(res, await websites(req).files(req.actor, id, action, req.valid.body), { status: 202, message: 'Queued' });
  },
  async checkDns(req, res) {
    sendOk(res, await websites(req).checkDns(req.actor, { websiteId: req.valid.params.id }), { message: 'DNS checked' });
  },
  async uptime(req, res) {
    sendOk(res, await monitor(req).get(req.actor, req.valid.params.id));
  },
  async setUptime(req, res) {
    const { enabled } = req.valid.body;
    sendOk(res, await monitor(req).setEnabled(req.actor, req.valid.params.id, enabled), { message: enabled ? 'Uptime monitoring is on' : 'Uptime monitoring is off' });
  },
  async checkUptime(req, res) {
    sendOk(res, await monitor(req).checkNow(req.actor, req.valid.params.id), { message: 'Checked' });
  },
};

export const domainController = {
  async list(req, res) {
    sendOk(res, await websites(req).listDomains(req.actor, req.valid.query));
  },
  async checkDns(req, res) {
    sendOk(res, await websites(req).checkDns(req.actor, { domainId: req.valid.params.id }), { message: 'DNS checked' });
  },
};

export const certificateController = {
  async list(req, res) {
    sendOk(res, await websites(req).listCertificates(req.actor, req.valid.query));
  },
  async getRenewal(req, res) {
    sendOk(res, await req.app.locals.services.sslRenewal.get(req.actor));
  },
  async updateRenewal(req, res) {
    const result = await req.app.locals.services.sslRenewal.update(req.actor, req.valid.body);
    sendOk(res, result, { message: 'Renewal settings saved' });
  },
};
