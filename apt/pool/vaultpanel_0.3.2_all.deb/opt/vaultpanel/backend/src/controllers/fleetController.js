import { sendOk } from '../utils/response.js';

const groups = (req) => req.app.locals.services.serverGroups;
const bulk = (req) => req.app.locals.services.bulkActions;

export const serverGroupController = {
  async list(req, res) {
    sendOk(res, await groups(req).list(req.actor));
  },
  async get(req, res) {
    sendOk(res, await groups(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await groups(req).create(req.actor, req.valid.body), { status: 201, message: 'Group created' });
  },
  async update(req, res) {
    sendOk(res, await groups(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'Group saved' });
  },
  async remove(req, res) {
    await groups(req).remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Group deleted. Its servers were not changed.' });
  },
  async setServerGroups(req, res) {
    sendOk(res, await groups(req).setServerGroups(req.actor, req.valid.params.id, req.valid.body.groupIds), { message: 'Groups saved' });
  },
};

export const bulkActionController = {
  async list(req, res) {
    sendOk(res, await bulk(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await bulk(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await bulk(req).create(req.actor, req.valid.body), { status: 202, message: 'Bulk action started' });
  },
  async cancel(req, res) {
    sendOk(res, await bulk(req).cancel(req.actor, req.valid.params.id), { message: 'Servers that had not started were cancelled' });
  },
};
