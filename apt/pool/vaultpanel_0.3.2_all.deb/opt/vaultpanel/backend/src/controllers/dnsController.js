import { sendOk } from '../utils/response.js';

const dns = (req) => req.app.locals.services.dns;
const providers = (req) => req.app.locals.services.dnsProviders;

export const dnsController = {
  async list(req, res) {
    sendOk(res, await dns(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await dns(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await dns(req).create(req.actor, req.valid.body), { status: 202, message: 'Adding the zone to the server' });
  },
  async update(req, res) {
    sendOk(res, await dns(req).update(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Saved' });
  },
  async remove(req, res) {
    sendOk(res, await dns(req).remove(req.actor, req.valid.params.id), { status: 202, message: 'Deleting the zone' });
  },
  async apply(req, res) {
    sendOk(res, await dns(req).apply(req.actor, req.valid.params.id), { status: 202, message: 'Applying the zone again' });
  },
  async setCustomerDns(req, res) {
    sendOk(res, await dns(req).setCustomerDns(req.actor, req.valid.params.id, req.valid.body), { message: 'Saved' });
  },
  async check(req, res) {
    sendOk(res, await dns(req).checkDelegation(req.actor, req.valid.params.id));
  },
  async addRecord(req, res) {
    sendOk(res, await dns(req).addRecord(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Record added' });
  },
  async updateRecord(req, res) {
    sendOk(res, await dns(req).updateRecord(req.actor, req.valid.params.id, req.valid.params.recordId, req.valid.body), { status: 202, message: 'Record saved' });
  },
  async removeRecord(req, res) {
    sendOk(res, await dns(req).removeRecord(req.actor, req.valid.params.id, req.valid.params.recordId), { status: 202, message: 'Record deleted' });
  },
  async listProviders(req, res) {
    sendOk(res, await providers(req).list(req.actor));
  },
  async getProvider(req, res) {
    sendOk(res, await providers(req).get(req.actor, req.valid.params.id));
  },
  async createProvider(req, res) {
    sendOk(res, await providers(req).create(req.actor, req.valid.body), { status: 201, message: 'DNS provider added' });
  },
  async updateProvider(req, res) {
    sendOk(res, await providers(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'DNS provider saved' });
  },
  async removeProvider(req, res) {
    await providers(req).remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'DNS provider removed' });
  },
};
