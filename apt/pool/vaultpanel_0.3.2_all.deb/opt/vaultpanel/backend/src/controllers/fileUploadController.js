import { sendOk } from '../utils/response.js';

const uploads = (req) => req.app.locals.services.fileUploads;
const downloads = (req) => req.app.locals.services.fileDownloads;

// Large uploads in the website file manager (services/fileUploadService.js).
export const fileUploadController = {
  async start(req, res) {
    sendOk(res, await uploads(req).start(req.actor, req.valid.params.id, req.valid.body), { status: 201, message: 'Upload started' });
  },
  async chunk(req, res) {
    const { id, uploadId, offset } = req.valid.params;
    sendOk(res, await uploads(req).receive(req.actor, id, uploadId, offset, req.body));
  },
  async finish(req, res) {
    const { id, uploadId } = req.valid.params;
    sendOk(res, await uploads(req).finish(req.actor, id, uploadId), { status: 202, message: 'Saving the file on the server' });
  },
  async startDownload(req, res) {
    sendOk(res, await downloads(req).start(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Fetching the file from the server' });
  },
  async downloadStatus(req, res) {
    const { id, downloadId } = req.valid.params;
    sendOk(res, await downloads(req).status(req.actor, id, downloadId));
  },
  // The file itself; ?inline=1 for the editor, which reads it as text.
  async downloadFile(req, res) {
    const { id, downloadId } = req.valid.params;
    const file = await downloads(req).open(req.actor, id, downloadId);
    if (req.query.inline !== '1') res.attachment(file.name);
    // Never rendered by the browser, whatever the file is.
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Length', String(file.size));
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store');
    await new Promise((resolve, reject) => {
      file.stream().on('error', reject).pipe(res).on('finish', resolve).on('error', reject);
    });
  },
};
