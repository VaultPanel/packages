import { sendOk } from '../utils/response.js';

const security = (req) => req.app.locals.services.security;
const queued = (message) => ({ status: 202, message });

export const securityController = {
  async overview(req, res) {
    sendOk(res, await security(req).overview(req.actor));
  },
  async server(req, res) {
    sendOk(res, await security(req).server(req.actor, req.valid.params.id));
  },
  async setFirewall(req, res) {
    const { enabled } = req.valid.body;
    sendOk(res, await security(req).setFirewall(req.actor, req.valid.params.id, req.valid.body), queued(enabled ? 'Turning the firewall on' : 'Turning the firewall off'));
  },
  async addRule(req, res) {
    sendOk(res, await security(req).addRule(req.actor, req.valid.params.id, req.valid.body), queued('Adding the rule'));
  },
  async deleteRule(req, res) {
    sendOk(res, await security(req).deleteRule(req.actor, req.valid.params.id, req.valid.body), queued('Deleting the rule'));
  },
  async setFirewallDefault(req, res) {
    sendOk(res, await security(req).setFirewallDefault(req.actor, req.valid.params.id, req.valid.body), queued('Changing the default'));
  },
  async configureSsh(req, res) {
    sendOk(res, await security(req).configureSsh(req.actor, req.valid.params.id, req.valid.body), queued('Applying SSH settings'));
  },
  async addSshKey(req, res) {
    sendOk(res, await security(req).addSshKey(req.actor, req.valid.params.id, req.valid.body), queued('Adding the key'));
  },
  async removeSshKey(req, res) {
    sendOk(res, await security(req).removeSshKey(req.actor, req.valid.params.id, req.valid.body), queued('Removing the key'));
  },
  async setSshPorts(req, res) {
    sendOk(res, await security(req).setSshPorts(req.actor, req.valid.params.id, req.valid.body), queued('Changing the SSH port'));
  },
  async setLoginBanner(req, res) {
    sendOk(res, await security(req).setLoginBanner(req.actor, req.valid.params.id, req.valid.body), queued('Changing the login message'));
  },
  async configureFail2ban(req, res) {
    sendOk(res, await security(req).configureFail2ban(req.actor, req.valid.params.id, req.valid.body), queued('Applying Fail2ban settings'));
  },
  async unban(req, res) {
    sendOk(res, await security(req).unban(req.actor, req.valid.params.id, req.valid.body), queued('Unblocking the address'));
  },
  async setAutoUpdates(req, res) {
    sendOk(res, await security(req).setAutoUpdates(req.actor, req.valid.params.id, req.valid.body), queued('Changing automatic updates'));
  },
  async installUpdates(req, res) {
    sendOk(res, await security(req).installUpdates(req.actor, req.valid.params.id), queued('Installing security updates'));
  },
  async authentication(req, res) {
    sendOk(res, await security(req).authentication(req.actor));
  },
  async setTwoFactorPolicy(req, res) {
    sendOk(res, await security(req).setTwoFactorPolicy(req.actor, req.valid.body), { message: 'Sign-in policy saved' });
  },
  async panelAccess(req, res) {
    sendOk(res, await req.app.locals.services.panelAccess.get(req.actor));
  },
  async setPanelAccess(req, res) {
    sendOk(res, await req.app.locals.services.panelAccess.set(req.actor, req.valid.body), { message: 'Panel access saved' });
  },
  async sessions(req, res) {
    sendOk(res, await security(req).sessions(req.actor));
  },
  async revokeSession(req, res) {
    await security(req).revokeSession(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Session signed out' });
  },
};
