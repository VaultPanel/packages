import { sendOk } from '../utils/response.js';

const alerts = (req) => req.app.locals.services.alerts;

export const alertController = {
  async summary(req, res) {
    sendOk(res, await alerts(req).summary(req.actor));
  },
  async listEvents(req, res) {
    sendOk(res, await alerts(req).listEvents(req.actor, req.valid.query));
  },
  async acknowledge(req, res) {
    sendOk(res, await alerts(req).acknowledge(req.actor, req.valid.params.id), { message: 'Alert acknowledged' });
  },
  async listRules(req, res) {
    sendOk(res, await alerts(req).listRules(req.actor));
  },
  async createRule(req, res) {
    sendOk(res, await alerts(req).createRule(req.actor, req.valid.body), { status: 201, message: 'Alert rule created' });
  },
  async updateRule(req, res) {
    sendOk(res, await alerts(req).updateRule(req.actor, req.valid.params.id, req.valid.body), { message: 'Alert rule updated' });
  },
  async deleteRule(req, res) {
    await alerts(req).deleteRule(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Alert rule deleted' });
  },
};

export const monitoringController = {
  async overview(req, res) {
    sendOk(res, await req.app.locals.services.monitoring.overview(req.actor));
  },
  async services(req, res) {
    sendOk(res, await req.app.locals.services.monitoring.services(req.actor, req.valid.query));
  },
};
