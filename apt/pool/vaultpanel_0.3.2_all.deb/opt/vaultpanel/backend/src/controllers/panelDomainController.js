import { sendOk } from '../utils/response.js';

const panelDomain = (req) => req.app.locals.services.panelDomain;

export const panelDomainController = {
  async get(req, res) {
    sendOk(res, await panelDomain(req).get(req.actor));
  },
  async set(req, res) {
    const result = await panelDomain(req).set(req.actor, req.valid.body);
    sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? 'The agent is putting the panel on the domain' : 'Nothing to change' });
  },
  async useDomain(req, res) {
    const result = await panelDomain(req).useDomain(req.actor, req.valid.body);
    sendOk(res, result, { message: `The panel's address is now ${result.address.current}` });
  },
  async remove(req, res) {
    sendOk(res, await panelDomain(req).remove(req.actor), { message: 'The panel is being taken off its domain' });
  },
};
