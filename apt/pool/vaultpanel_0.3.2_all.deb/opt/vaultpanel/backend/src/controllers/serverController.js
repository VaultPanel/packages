import { sendOk } from '../utils/response.js';

const servers = (req) => req.app.locals.services.servers;

export const serverController = {
  async list(req, res) {
    sendOk(res, await servers(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await servers(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await servers(req).create(req.actor, req.valid.body), {
      status: 201,
      message: 'Server added. Run the install command on it to connect the agent.',
    });
  },
  async update(req, res) {
    sendOk(res, await servers(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'Server updated' });
  },
  async remove(req, res) {
    await servers(req).remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Server removed and its agent revoked' });
  },
  async createEnrollment(req, res) {
    sendOk(res, await servers(req).createEnrollment(req.actor, req.valid.params.id), {
      status: 201,
      message: 'New enrollment token created; older ones no longer work',
    });
  },
  async metrics(req, res) {
    sendOk(res, await servers(req).metrics(req.actor, req.valid.params.id, req.valid.query.range));
  },
  // A one-time ticket for the terminal's WebSocket (routes/terminalSockets.js).
  async openTerminal(req, res) {
    sendOk(res, await req.app.locals.services.terminals.createTicket(req.actor, req.valid.params.id, req.valid.body), { status: 201 });
  },
  async updateAgent(req, res) {
    sendOk(res, await servers(req).updateAgent(req.actor, req.valid.params.id), { status: 202, message: 'Agent update queued' });
  },
  async createJob(req, res) {
    const job = await req.app.locals.services.jobs.create(req.actor, {
      serverId: req.valid.params.id,
      type: req.valid.body.type,
      params: req.valid.body.params,
    });
    sendOk(res, job, { status: 202, message: 'Job queued' });
  },
};
