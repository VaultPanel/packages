import { sendError, sendOk } from '../utils/response.js';

export const systemController = {
  // Liveness plus dependency checks. Reports what is down instead of a bare 500.
  async health(req, res) {
    const { db, redis } = req.app.locals;
    const checks = {};
    try {
      await db.raw('select 1');
      checks.database = 'ok';
    } catch {
      checks.database = 'unavailable';
    }
    try {
      checks.redis = (await redis.ping()) === 'PONG' ? 'ok' : 'unavailable';
    } catch {
      checks.redis = 'unavailable';
    }
    const healthy = Object.values(checks).every((v) => v === 'ok');
    if (healthy) return sendOk(res, { status: 'ok', checks });
    sendError(res, 503, { code: 'DEGRADED', message: 'A dependency is unavailable', details: checks });
  },
  async dashboard(req, res) {
    sendOk(res, await req.app.locals.services.dashboard.summary(req.actor));
  },
};
