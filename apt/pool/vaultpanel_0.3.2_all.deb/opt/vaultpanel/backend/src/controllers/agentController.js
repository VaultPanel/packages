import { createReadStream } from 'node:fs';
import path from 'node:path';
import { requestMeta } from '../middleware/requestId.js';
import { agentPackageAvailable, buildAgentPackage, REPO_ROOT } from '../utils/agentPackage.js';
import { AppError } from '../utils/errors.js';
import { sendOk } from '../utils/response.js';

const INSTALL_SCRIPT = path.join(REPO_ROOT, 'scripts/install-agent.sh');

const agents = (req) => req.app.locals.services.agents;
const jobs = (req) => req.app.locals.services.jobs;
const services = (req) => req.app.locals.services;

export const agentController = {
  installScript(req, res) {
    res.type('text/x-shellscript');
    createReadStream(INSTALL_SCRIPT).pipe(res);
  },

  // The certificate the panel serves HTTPS with (public information). The
  // install script fetches it over a connection pinned to its public key and
  // gives it to the agent, which then trusts exactly this certificate.
  panelCertificate(req, res) {
    const { tls } = req.app.locals.config;
    if (!tls) throw new AppError(404, 'NO_PANEL_CERTIFICATE', 'This panel does not serve HTTPS with its own certificate');
    res.type('application/x-pem-file');
    res.set('X-Panel-Pin', tls.pin);
    res.send(tls.certPem);
  },

  // The agent source as a tarball, built the same way every time so its hash
  // matches the one in agent update jobs. Fixed arguments, no shell.
  async agentPackage(req, res) {
    if (!agentPackageAvailable()) {
      throw new AppError(503, 'AGENT_PACKAGE_MISSING', 'The agent package is not available on this panel');
    }
    const pkg = await buildAgentPackage();
    res.type('application/gzip');
    res.set('Content-Disposition', 'attachment; filename="vaultpanel-agent.tgz"');
    res.set('X-Agent-Version', pkg.version ?? '');
    res.set('X-Content-SHA256', pkg.sha256);
    res.send(pkg.buffer);
  },

  async register(req, res) {
    const result = await agents(req).register(req.valid.body, requestMeta(req, res));
    sendOk(res, result, { status: 201, message: 'Agent registered' });
  },

  async heartbeat(req, res) {
    sendOk(res, await agents(req).heartbeat(req.agent, req.valid.body, requestMeta(req, res)));
  },

  async nextJob(req, res) {
    let aborted = false;
    req.on('close', () => {
      aborted = true;
    });
    const job = await agents(req).nextJob(req.agent, { isAborted: () => aborted });
    if (!job) return res.status(204).end();
    sendOk(res, job);
  },

  async jobStarted(req, res) {
    await jobs(req).markStarted(req.agent.server.id, req.valid.params.id);
    sendOk(res, null);
  },

  async jobLogs(req, res) {
    sendOk(res, await jobs(req).appendLogs(req.agent.server.id, req.valid.params.id, req.valid.body.lines));
  },

  async jobResult(req, res) {
    await jobs(req).complete(req.agent.server.id, req.valid.params.id, req.valid.body, req.agent.actor);
    sendOk(res, null, { message: 'Result recorded' });
  },

  async backupChunk(req, res) {
    sendOk(res, await services(req).backups.receiveChunk(req.agent.server.id, req.valid.params.id, req.valid.body));
  },

  async uploadChunk(req, res) {
    const { id, offset } = req.valid.params;
    sendOk(res, await services(req).fileUploads.chunkForAgent(req.agent.server.id, id, offset));
  },

  async downloadChunk(req, res) {
    sendOk(res, await services(req).fileDownloads.receiveChunk(req.agent.server.id, req.valid.params.id, req.valid.body));
  },

  async cronRuns(req, res) {
    sendOk(res, await services(req).cron.recordRuns(req.agent.server.id, req.valid.body.runs));
  },
};
