import { sendOk } from '../utils/response.js';

const containers = (req) => req.app.locals.services.containers;
const queued = (message) => ({ status: 202, message });
const ACTION_MESSAGES = { start: 'Starting the container', stop: 'Stopping the container', restart: 'Restarting the container' };

export const containerController = {
  async servers(req, res) {
    sendOk(res, await containers(req).servers(req.actor));
  },
  async list(req, res) {
    sendOk(res, await containers(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await containers(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await containers(req).create(req.actor, req.valid.body), queued('Deploying the container'));
  },
  async update(req, res) {
    sendOk(res, await containers(req).update(req.actor, req.valid.params.id, req.valid.body), queued('Deploying the change'));
  },
  async redeploy(req, res) {
    sendOk(res, await containers(req).redeploy(req.actor, req.valid.params.id, req.valid.body), queued('Redeploying the container'));
  },
  async remove(req, res) {
    sendOk(res, await containers(req).remove(req.actor, req.valid.params.id, req.valid.query), queued('Removing the container'));
  },
  async env(req, res) {
    sendOk(res, await containers(req).getEnv(req.actor, req.valid.params.id));
  },
  async actOn(req, res) {
    const { id, action } = req.valid.params;
    sendOk(res, await containers(req).actOn(req.actor, id, action), queued(ACTION_MESSAGES[action]));
  },

  // Any container on a server, and Docker itself.
  async dockerStatus(req, res) {
    sendOk(res, await containers(req).dockerStatus(req.actor, req.valid.params.serverId), queued('Reading Docker’s status'));
  },
  async installDocker(req, res) {
    sendOk(res, await containers(req).installDocker(req.actor, req.valid.params.serverId), queued('Installing or starting Docker'));
  },
  async listLive(req, res) {
    sendOk(res, await containers(req).listLive(req.actor, req.valid.params.serverId), queued('Listing containers'));
  },
  async act(req, res) {
    const { serverId, ref, action } = req.valid.params;
    sendOk(res, await containers(req).act(req.actor, serverId, ref, action), queued(ACTION_MESSAGES[action]));
  },
  async logs(req, res) {
    const { serverId, ref } = req.valid.params;
    sendOk(res, await containers(req).logs(req.actor, serverId, ref, req.valid.body), queued('Reading the logs'));
  },
  async inspect(req, res) {
    const { serverId, ref } = req.valid.params;
    sendOk(res, await containers(req).inspect(req.actor, serverId, ref), queued('Reading the container'));
  },
  async removeLive(req, res) {
    const { serverId, ref } = req.valid.params;
    sendOk(res, await containers(req).removeLive(req.actor, serverId, ref), queued('Removing the container'));
  },
  async listImages(req, res) {
    sendOk(res, await containers(req).listImages(req.actor, req.valid.params.serverId), queued('Listing images'));
  },
  async pullImage(req, res) {
    sendOk(res, await containers(req).pullImage(req.actor, req.valid.params.serverId, req.valid.body), queued('Pulling the image'));
  },
  async removeImage(req, res) {
    sendOk(res, await containers(req).removeImage(req.actor, req.valid.params.serverId, req.valid.body), queued('Removing the image'));
  },
};
