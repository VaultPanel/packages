import { clearSessionCookie, setSessionCookie } from '../middleware/auth.js';
import { requestMeta } from '../middleware/requestId.js';
import { anonymousActor } from '../services/actor.js';
import { AppError } from '../utils/errors.js';
import { sendOk } from '../utils/response.js';

const services = (req) => req.app.locals.services;
const config = (req) => req.app.locals.config;

function sessionResponse(req, res, session, message, status = 200) {
  setSessionCookie(res, config(req), session.token, session.expiresAt);
  return sendOk(res, { user: session.user, permissions: session.permissions, csrfToken: session.csrfToken, customer: session.customer ?? null, twoFactorSetupRequired: Boolean(session.twoFactorSetupRequired) }, { message, status });
}

export const authController = {
  async setupStatus(req, res) {
    const [needsSetup, passwordResetByEmail] = await Promise.all([services(req).auth.needsSetup(), services(req).email.isReady()]);
    sendOk(res, { needsSetup, passwordResetByEmail });
  },
  async setup(req, res) {
    const session = await services(req).auth.setupOwner(req.valid.body, requestMeta(req, res));
    sessionResponse(req, res, session, 'Owner account created', 201);
  },
  async login(req, res) {
    const result = await services(req).auth.login(req.valid.body, requestMeta(req, res));
    if (result.twoFactorRequired) {
      return sendOk(res, { twoFactorRequired: true, challengeToken: result.challengeToken }, { message: 'Enter your two-factor code' });
    }
    sessionResponse(req, res, result, 'Signed in');
  },
  async loginTwoFactor(req, res) {
    const session = await services(req).auth.completeTwoFactor(req.valid.body, requestMeta(req, res));
    if (session.recoveryCodesLeft !== undefined) {
      setSessionCookie(res, config(req), session.token, session.expiresAt);
      const left = session.recoveryCodesLeft;
      return sendOk(
        res,
        { user: session.user, permissions: session.permissions, csrfToken: session.csrfToken, customer: session.customer ?? null, twoFactorSetupRequired: Boolean(session.twoFactorSetupRequired), recoveryCodesLeft: left },
        { message: `Signed in with a recovery code. ${left} left.` },
      );
    }
    sessionResponse(req, res, session, 'Signed in');
  },
  // A one-time sign-in link from a billing system (/sso#token=...).
  async sso(req, res) {
    const session = await services(req).auth.loginWithLink(req.valid.body, requestMeta(req, res));
    sessionResponse(req, res, session, 'Signed in');
  },
  async logout(req, res) {
    await services(req).auth.logout(req.actor);
    clearSessionCookie(res, config(req));
    sendOk(res, null, { message: 'Signed out' });
  },
  async me(req, res) {
    sendOk(res, await services(req).auth.me(req.actor));
  },
  async changePassword(req, res) {
    await services(req).auth.changePassword(req.actor, req.valid.body);
    sendOk(res, null, { message: 'Password changed. Other sessions were signed out.' });
  },
  async beginTotpSetup(req, res) {
    sendOk(res, await services(req).auth.beginTotpSetup(req.actor), { message: 'Scan the code, then confirm it' });
  },
  async enableTotp(req, res) {
    sendOk(res, await services(req).auth.enableTotp(req.actor, req.valid.body), { message: 'Two-factor sign-in is on. Save your recovery codes.' });
  },
  async regenerateRecoveryCodes(req, res) {
    sendOk(res, await services(req).auth.regenerateRecoveryCodes(req.actor, req.valid.body), { message: 'New recovery codes made. The old ones no longer work.' });
  },
  async listSessions(req, res) {
    sendOk(res, await services(req).auth.listSessions(req.actor));
  },
  async revokeSession(req, res) {
    await services(req).auth.revokeSession(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Session signed out' });
  },
  async revokeOtherSessions(req, res) {
    const { count } = await services(req).auth.revokeOtherSessions(req.actor);
    sendOk(res, { count }, { message: count ? `Signed out ${count} other session${count === 1 ? '' : 's'}` : 'No other sessions' });
  },
  async disableTotp(req, res) {
    await services(req).auth.disableTotp(req.actor, req.valid.body);
    sendOk(res, null, { message: 'Two-factor sign-in is off' });
  },
  async inspectResetToken(req, res) {
    sendOk(res, await services(req).auth.inspectResetToken(req.valid.body.token));
  },
  // "Forgot password?": the answer is the same whether or not the address
  // has an account, and it comes before the work is done.
  async requestPasswordReset(req, res) {
    if (!(await services(req).email.isReady())) {
      throw new AppError(409, 'EMAIL_OFF', 'This panel cannot send email. Ask an administrator to reset your password.');
    }
    const actor = anonymousActor(requestMeta(req, res), req.valid.body.email);
    services(req)
      .users.requestPasswordReset(req.valid.body.email, actor)
      .catch((err) => req.log.error({ err }, 'password reset request failed'));
    sendOk(res, null, { status: 202, message: 'If this address has an account, a reset link is on its way.' });
  },
  async resetPassword(req, res) {
    await services(req).auth.resetPassword(req.valid.body, requestMeta(req, res));
    sendOk(res, null, { message: 'Password set. You can sign in now.' });
  },
};
