import { sendOk } from '../utils/response.js';

const email = (req) => req.app.locals.services.email;

export const panelEmailController = {
  async get(req, res) {
    sendOk(res, await email(req).getSettings(req.actor));
  },
  async update(req, res) {
    sendOk(res, await email(req).updateSettings(req.actor, req.valid.body), { message: 'Email settings saved' });
  },
  async test(req, res) {
    const result = await email(req).sendTest(req.actor, req.valid.body);
    sendOk(res, result, { message: `Test email sent to ${result.message.to}` });
  },
  async messages(req, res) {
    sendOk(res, await email(req).listMessages(req.actor, req.valid.query));
  },
};
