import { sendOk } from '../utils/response.js';

const cms = (req) => req.app.locals.services.cms;

export const cmsController = {
  async catalog(req, res) {
    sendOk(res, cms(req).catalog());
  },
  async list(req, res) {
    sendOk(res, await cms(req).list(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await cms(req).get(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await cms(req).create(req.actor, req.valid.body), { status: 202, message: 'Installing the app' });
  },
  async remove(req, res) {
    sendOk(res, await cms(req).remove(req.actor, req.valid.params.id, req.valid.query), { status: 202, message: 'Removing the app' });
  },
};
