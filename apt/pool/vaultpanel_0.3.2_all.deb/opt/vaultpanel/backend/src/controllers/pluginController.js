import { sendOk } from '../utils/response.js';

const plugins = (req) => req.app.locals.services.plugins;
const directories = (req) => req.app.locals.services.pluginDirectories;

export const pluginController = {
  async list(req, res) {
    sendOk(res, await plugins(req).list(req.actor));
  },
  async pages(req, res) {
    sendOk(res, await plugins(req).pages(req.actor));
  },
  async preview(req, res) {
    sendOk(res, await plugins(req).preview(req.actor, req.valid.body));
  },
  async directory(req, res) {
    sendOk(res, await directories(req).list(req.actor));
  },
  async refreshDirectories(req, res) {
    sendOk(res, await directories(req).refreshAll(req.actor));
  },
  async addDirectory(req, res) {
    sendOk(res, await directories(req).add(req.actor, req.valid.body), { status: 201, message: 'Plugin directory added' });
  },
  async refreshDirectory(req, res) {
    sendOk(res, await directories(req).refresh(req.actor, req.valid.params.directoryId), { message: 'Plugin directory read again' });
  },
  async removeDirectory(req, res) {
    await directories(req).remove(req.actor, req.valid.params.directoryId);
    sendOk(res, null, { message: 'Plugin directory removed' });
  },
  async install(req, res) {
    sendOk(res, await plugins(req).install(req.actor, req.valid.body), {
      status: 201,
      message: 'Plugin installed. Copy its token and signing secret now: they are not shown again.',
    });
  },
  async get(req, res) {
    sendOk(res, await plugins(req).get(req.actor, req.valid.params.id));
  },
  async update(req, res) {
    sendOk(res, await plugins(req).update(req.actor, req.valid.params.id, req.valid.body), { message: 'Plugin updated' });
  },
  async enable(req, res) {
    sendOk(res, await plugins(req).setEnabled(req.actor, req.valid.params.id, true), { message: 'Plugin turned on' });
  },
  async disable(req, res) {
    sendOk(res, await plugins(req).setEnabled(req.actor, req.valid.params.id, false), { message: 'Plugin turned off' });
  },
  async rotate(req, res) {
    sendOk(res, await plugins(req).rotateCredentials(req.actor, req.valid.params.id), {
      message: 'New token and signing secret made. The old ones no longer work.',
    });
  },
  async remove(req, res) {
    await plugins(req).remove(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Plugin removed' });
  },
  async deliveries(req, res) {
    sendOk(res, await plugins(req).deliveries(req.actor, req.valid.params.id, req.valid.query));
  },
  async test(req, res) {
    sendOk(res, await plugins(req).test(req.actor, req.valid.params.id));
  },
  async redeliver(req, res) {
    sendOk(res, await plugins(req).redeliver(req.actor, req.valid.params.id, req.valid.params.deliveryId));
  },
  async launch(req, res) {
    sendOk(res, await plugins(req).launch(req.actor, req.valid.params.id, req.valid.query));
  },
};
