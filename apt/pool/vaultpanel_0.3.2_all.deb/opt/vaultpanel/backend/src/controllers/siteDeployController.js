import { sendOk } from '../utils/response.js';

const siteDeploys = (req) => req.app.locals.services.siteDeploys;

// Git deploy for static websites. Deploys and rollbacks return 202: a job
// carries them out on the server and the UI follows it.
export const siteDeployController = {
  async configure(req, res) {
    const result = await siteDeploys(req).configure(req.actor, req.valid.params.id, req.valid.body);
    sendOk(res, result, { status: result.job || result.deployment ? 202 : 200, message: result.job ? 'Setting up Git deploy on the server' : 'Git deploy settings saved' });
  },
  async disable(req, res) {
    const result = await siteDeploys(req).disable(req.actor, req.valid.params.id);
    sendOk(res, result, { status: result.job ? 202 : 200, message: result.job ? 'Git deploy turned off. The site serves its previous folder again.' : 'Git deploy turned off' });
  },
  async getEnv(req, res) {
    sendOk(res, await siteDeploys(req).getEnv(req.actor, req.valid.params.id));
  },
  async setEnv(req, res) {
    sendOk(res, await siteDeploys(req).setEnv(req.actor, req.valid.params.id, req.valid.body), { message: 'Environment saved' });
  },
  async deployments(req, res) {
    sendOk(res, await siteDeploys(req).listDeployments(req.actor, req.valid.params.id));
  },
  async deploy(req, res) {
    sendOk(res, await siteDeploys(req).deploy(req.actor, req.valid.params.id), { status: 202, message: 'Deploying from Git' });
  },
  async rollback(req, res) {
    sendOk(res, await siteDeploys(req).rollback(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Rolling back' });
  },
  async enableWebhook(req, res) {
    sendOk(res, await siteDeploys(req).enableWebhook(req.actor, req.valid.params.id), { message: 'Copy the webhook URL now: it is shown only once' });
  },
  async disableWebhook(req, res) {
    sendOk(res, await siteDeploys(req).disableWebhook(req.actor, req.valid.params.id), { message: 'Push to deploy turned off' });
  },
};
