import { sendOk } from '../utils/response.js';

const mail = (req) => req.app.locals.services.mail;

export const mailController = {
  async listServers(req, res) {
    sendOk(res, await mail(req).listServers(req.actor));
  },
  async setupServer(req, res) {
    sendOk(res, await mail(req).setupServer(req.actor, req.valid.body), { status: 202, message: 'Setting up the mail server' });
  },
  async applyServer(req, res) {
    sendOk(res, await mail(req).applyServer(req.actor, req.valid.params.serverId), { status: 202, message: 'Applying the email settings again' });
  },
  async checkServer(req, res) {
    sendOk(res, await mail(req).checkServer(req.actor, req.valid.params.serverId));
  },
  async usage(req, res) {
    sendOk(res, await mail(req).refreshUsage(req.actor, req.valid.params.serverId), { status: 202, message: 'Checking mailbox sizes' });
  },
  async listDomains(req, res) {
    sendOk(res, await mail(req).listDomains(req.actor, req.valid.query));
  },
  async getDomain(req, res) {
    sendOk(res, await mail(req).getDomain(req.actor, req.valid.params.id));
  },
  async createDomain(req, res) {
    sendOk(res, await mail(req).createDomain(req.actor, req.valid.body), { status: 202, message: 'Adding the domain to the mail server' });
  },
  async removeDomain(req, res) {
    sendOk(res, await mail(req).removeDomain(req.actor, req.valid.params.id, req.valid.query), { status: 202, message: 'Removing the domain' });
  },
  async addDnsRecords(req, res) {
    sendOk(res, await mail(req).addDnsRecords(req.actor, req.valid.params.id), { status: 202, message: 'Records added to the DNS zone' });
  },
  async checkDns(req, res) {
    sendOk(res, await mail(req).checkDomainDns(req.actor, req.valid.params.id));
  },
  async createMailbox(req, res) {
    sendOk(res, await mail(req).createMailbox(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Mailbox added' });
  },
  async updateMailbox(req, res) {
    sendOk(res, await mail(req).updateMailbox(req.actor, req.valid.params.id, req.valid.params.itemId, req.valid.body), { status: 202, message: 'Mailbox saved' });
  },
  async removeMailbox(req, res) {
    sendOk(res, await mail(req).removeMailbox(req.actor, req.valid.params.id, req.valid.params.itemId, req.valid.query), { status: 202, message: 'Mailbox deleted' });
  },
  async createForwarder(req, res) {
    sendOk(res, await mail(req).createForwarder(req.actor, req.valid.params.id, req.valid.body), { status: 202, message: 'Forwarder added' });
  },
  async updateForwarder(req, res) {
    sendOk(res, await mail(req).updateForwarder(req.actor, req.valid.params.id, req.valid.params.itemId, req.valid.body), { status: 202, message: 'Forwarder saved' });
  },
  async removeForwarder(req, res) {
    sendOk(res, await mail(req).removeForwarder(req.actor, req.valid.params.id, req.valid.params.itemId), { status: 202, message: 'Forwarder deleted' });
  },
};
