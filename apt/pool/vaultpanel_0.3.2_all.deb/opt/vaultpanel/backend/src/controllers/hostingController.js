import { notFound } from '../utils/errors.js';
import { sendOk } from '../utils/response.js';
import { linkMessage } from './userController.js';

const hosting = (req) => req.app.locals.services.hosting;
const apiKeys = (req) => req.app.locals.services.apiKeys;

export const planController = {
  async list(req, res) {
    sendOk(res, await hosting(req).listPlans(req.actor));
  },
  async get(req, res) {
    sendOk(res, await hosting(req).getPlan(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    sendOk(res, await hosting(req).createPlan(req.actor, req.valid.body), { status: 201, message: 'Plan created' });
  },
  async update(req, res) {
    const result = await hosting(req).updatePlan(req.actor, req.valid.params.id, req.valid.body);
    const capped = result.appsCapped ? ` ${result.appsCapped} app${result.appsCapped === 1 ? ' gets' : 's get'} the new CPU or memory cap on its next deploy or apply.` : '';
    sendOk(res, result, { message: `Plan saved.${capped}` });
  },
  async remove(req, res) {
    await hosting(req).deletePlan(req.actor, req.valid.params.id);
    sendOk(res, null, { message: 'Plan deleted' });
  },
};

export const customerController = {
  async list(req, res) {
    sendOk(res, await hosting(req).listCustomers(req.actor, req.valid.query));
  },
  async get(req, res) {
    sendOk(res, await hosting(req).getCustomer(req.actor, req.valid.params.id));
  },
  async create(req, res) {
    const result = await hosting(req).createCustomer(req.actor, req.valid.body);
    sendOk(res, result, { status: 201, message: result.inviteUrl ? linkMessage('Customer created.', 'invite link', result.email) : 'Customer created' });
  },
  async update(req, res) {
    sendOk(res, await hosting(req).updateCustomer(req.actor, req.valid.params.id, req.valid.body), { message: 'Customer saved' });
  },
  async changePlan(req, res) {
    sendOk(res, await hosting(req).changePlan(req.actor, req.valid.params.id, req.valid.body.planId), { message: 'Plan changed' });
  },
  async suspend(req, res) {
    sendOk(res, await hosting(req).suspend(req.actor, req.valid.params.id, req.valid.body), { message: 'Account suspended' });
  },
  async unsuspend(req, res) {
    sendOk(res, await hosting(req).unsuspend(req.actor, req.valid.params.id), { message: 'Account unsuspended' });
  },
  async terminate(req, res) {
    sendOk(res, await hosting(req).terminate(req.actor, req.valid.params.id), { message: 'Account removed. Its websites, apps and databases are being deleted.' });
  },
  async passwordReset(req, res) {
    const result = await hosting(req).setPassword(req.actor, req.valid.params.id, {});
    sendOk(res, result, { message: linkMessage('Reset link created.', 'link', result.email) });
  },
  async assign(req, res) {
    sendOk(res, await hosting(req).assignResource(req.actor, req.valid.params.id, req.valid.body), { message: 'Moved to this customer' });
  },
  async unassign(req, res) {
    const { id, type, resourceId } = req.valid.params;
    sendOk(res, await hosting(req).unassignResource(req.actor, id, { type, resourceId }), { message: 'Taken back from this customer' });
  },
  async me(req, res) {
    sendOk(res, await hosting(req).myAccount(req.actor));
  },
  // The name servers to use and the account's domains the panel answers for.
  async myDns(req, res) {
    if (!req.actor?.customerId) throw notFound('No hosting account');
    sendOk(res, await req.app.locals.services.dns.customerView(req.actor.customerId));
  },
  async myDnsCheck(req, res) {
    if (!req.actor?.customerId) throw notFound('No hosting account');
    sendOk(res, { zone: await req.app.locals.services.dns.customerCheck(req.actor.customerId, req.valid.params.id) });
  },
};

export const reportController = {
  async financial(req, res) {
    sendOk(res, await req.app.locals.services.financialReport.report(req.actor, req.valid.query));
  },
};

export const apiKeyController = {
  async list(req, res) {
    sendOk(res, await apiKeys(req).list(req.actor));
  },
  async create(req, res) {
    sendOk(res, await apiKeys(req).create(req.actor, req.valid.body), { status: 201, message: 'API key created. Copy it now: it is not shown again.' });
  },
  async revoke(req, res) {
    sendOk(res, await apiKeys(req).revoke(req.actor, req.valid.params.id), { message: 'API key revoked' });
  },
};

// The billing API: what a billing system (WHMCS, Blesta...) calls with an
// API key. Accounts are found by our id or the billing system's id.
const account = async (req) => hosting(req).resolveCustomer(req.valid.params.ref);

export const billingController = {
  async plans(req, res) {
    sendOk(res, await hosting(req).listPlans(req.actor, { activeOnly: true }));
  },
  async list(req, res) {
    sendOk(res, await hosting(req).listCustomers(req.actor, req.valid.query));
  },
  async create(req, res) {
    sendOk(res, await hosting(req).createCustomer(req.actor, req.valid.body, { via: 'api' }), { status: 201, message: 'Account created' });
  },
  async get(req, res) {
    sendOk(res, await hosting(req).getCustomer(req.actor, await account(req)));
  },
  async suspend(req, res) {
    sendOk(res, await hosting(req).suspend(req.actor, await account(req), req.valid.body), { message: 'Account suspended' });
  },
  async unsuspend(req, res) {
    sendOk(res, await hosting(req).unsuspend(req.actor, await account(req)), { message: 'Account unsuspended' });
  },
  async changePlan(req, res) {
    sendOk(res, await hosting(req).changePlan(req.actor, await account(req), req.valid.body.plan), { message: 'Plan changed' });
  },
  async password(req, res) {
    sendOk(res, await hosting(req).setPassword(req.actor, await account(req), req.valid.body), { message: req.valid.body.password ? 'Password changed' : 'Reset link created' });
  },
  async terminate(req, res) {
    sendOk(res, await hosting(req).terminate(req.actor, await account(req)), { message: 'Account removed' });
  },
  async loginLink(req, res) {
    sendOk(res, await hosting(req).loginLink(req.actor, await account(req)), { message: 'Sign-in link created' });
  },
};
