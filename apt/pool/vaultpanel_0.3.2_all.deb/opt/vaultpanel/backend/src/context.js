import knex from 'knex';
import { Redis } from 'ioredis';
import { knexConfig } from './config/database.js';
import { createLogger } from './utils/logger.js';
import { createServices } from './services/index.js';
import { createAssistantQueue } from './jobs/queues.js';

// Builds everything a process needs (API server, worker, CLI): config,
// logger, database, Redis and the service layer.
export function createContext(config, { logger } = {}) {
  const log = logger ?? createLogger({ level: config.logLevel });
  const db = knex(knexConfig(config.databaseUrl));
  const redis = new Redis(config.redisUrl, { maxRetriesPerRequest: 2, lazyConnect: false });
  redis.on('error', (err) => log.error({ err }, 'redis error'));
  const assistantQueue = createAssistantQueue(config.redisUrl);
  const services = createServices({ db, redis, config, logger: log, enqueueAssistant: (data) => assistantQueue.add(data) });

  async function close() {
    await Promise.allSettled([db.destroy(), redis.quit(), assistantQueue.close()]);
  }

  return { config, logger: log, db, redis, services, close };
}
