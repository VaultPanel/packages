# Database

Knex migrations for the panel database. MariaDB 10.6+ / MySQL 8 is the
primary target; the schema avoids engine-specific features so PostgreSQL can
be supported later (the one MySQL-only piece, the audit log write guard, is
skipped on other engines).

Run from the repository root:

```sh
npm run db:migrate    # apply pending migrations and sync built-in roles
npm run db:rollback   # undo the last batch
```

See [docs/database.md](../docs/database.md) for the table reference.
