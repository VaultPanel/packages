// Environment variables for static websites deployed from Git: given to the
// install and build commands. Values are encrypted with the panel's secret
// key, like an app's.

export async function up(knex) {
  await knex.schema.createTable('website_environment_variables', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.string('key', 128).notNullable();
    t.text('value_encrypted').notNullable();
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.unique(['website_id', 'key']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('website_environment_variables');
}
