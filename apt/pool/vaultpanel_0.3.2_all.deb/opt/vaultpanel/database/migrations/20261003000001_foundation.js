// Phase 0/1 foundation: accounts, access control, sessions, servers, agents,
// metrics, jobs, audit log and settings. Tables for later phases (websites,
// databases, deployments, backups...) arrive with the migrations of those phases.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.createTable('users', (t) => {
    t.uuid('id').primary();
    t.string('email', 254).notNullable().unique();
    t.string('name', 120).notNullable();
    t.string('password_hash', 255).notNullable();
    t.boolean('is_active').notNullable().defaultTo(true);
    // AES-256-GCM sealed TOTP secret. Trusted only once totp_enabled is true.
    t.text('totp_secret_encrypted');
    t.boolean('totp_enabled').notNullable().defaultTo(false);
    // Last accepted TOTP time step, so a code cannot be replayed.
    t.bigInteger('totp_last_step');
    t.integer('failed_login_count').notNullable().defaultTo(0);
    t.datetime('locked_until', { precision: 3 });
    t.datetime('last_login_at', { precision: 3 });
    t.string('last_login_ip', 45);
    t.datetime('password_changed_at', { precision: 3 });
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
  });

  await knex.schema.createTable('roles', (t) => {
    t.increments('id').primary();
    t.string('name', 50).notNullable().unique();
    t.string('description', 255).notNullable().defaultTo('');
    t.integer('rank').notNullable().defaultTo(0);
    t.boolean('is_system').notNullable().defaultTo(false);
    ts(t, knex);
  });

  await knex.schema.createTable('permissions', (t) => {
    t.increments('id').primary();
    t.string('key', 64).notNullable().unique();
    t.string('description', 255).notNullable().defaultTo('');
  });

  await knex.schema.createTable('role_permissions', (t) => {
    t.integer('role_id').unsigned().notNullable().references('roles.id').onDelete('CASCADE');
    t.integer('permission_id').unsigned().notNullable().references('permissions.id').onDelete('CASCADE');
    t.primary(['role_id', 'permission_id']);
  });

  await knex.schema.createTable('user_roles', (t) => {
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    t.integer('role_id').unsigned().notNullable().references('roles.id').onDelete('CASCADE');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.primary(['user_id', 'role_id']);
  });

  // Teams are part of the schema now so ownership can be added without a
  // redesign; they are not exposed in the API until a later phase.
  await knex.schema.createTable('teams', (t) => {
    t.uuid('id').primary();
    t.string('name', 120).notNullable();
    t.string('slug', 120).notNullable().unique();
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
  });

  await knex.schema.createTable('team_members', (t) => {
    t.uuid('team_id').notNullable().references('teams.id').onDelete('CASCADE');
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    t.string('role', 32).notNullable().defaultTo('member');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.primary(['team_id', 'user_id']);
  });

  await knex.schema.createTable('sessions', (t) => {
    t.uuid('id').primary();
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    // SHA-256 of the cookie value; the raw token is never stored.
    t.string('token_hash', 64).notNullable().unique();
    t.string('ip', 45);
    t.string('user_agent', 512);
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('last_seen_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('expires_at', { precision: 3 }).notNullable();
    t.datetime('revoked_at', { precision: 3 });
    t.index(['user_id']);
    t.index(['expires_at']);
  });

  await knex.schema.createTable('password_reset_tokens', (t) => {
    t.uuid('id').primary();
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    t.string('token_hash', 64).notNullable().unique();
    t.string('purpose', 16).notNullable(); // 'reset' | 'invite'
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('expires_at', { precision: 3 }).notNullable();
    t.datetime('used_at', { precision: 3 });
    t.index(['user_id']);
  });

  await knex.schema.createTable('servers', (t) => {
    t.uuid('id').primary();
    t.string('name', 100).notNullable();
    t.string('status', 16).notNullable().defaultTo('pending');
    t.string('hostname', 255);
    t.string('public_ip', 45);
    t.string('os_name', 100);
    t.string('os_version', 100);
    t.string('kernel_version', 100);
    t.string('architecture', 32);
    t.integer('cpu_cores');
    t.bigInteger('memory_total_bytes');
    t.bigInteger('disk_total_bytes');
    t.bigInteger('uptime_seconds');
    t.string('agent_version', 32);
    t.datetime('last_seen_at', { precision: 3 });
    // Latest service states reported by the agent: [{ name, active, sub, enabled }].
    t.json('services_snapshot');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.index(['status']);
    t.index(['deleted_at']);
  });

  await knex.schema.createTable('server_enrollment_tokens', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('token_hash', 64).notNullable().unique();
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('expires_at', { precision: 3 }).notNullable();
    t.datetime('used_at', { precision: 3 });
    t.index(['server_id']);
  });

  await knex.schema.createTable('server_agents', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // Ed25519 public key (SPKI, PEM). The agent keeps the private key.
    t.text('public_key').notNullable();
    t.string('key_fingerprint', 64).notNullable();
    t.string('agent_version', 32);
    t.string('registered_ip', 45);
    t.datetime('registered_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('last_seen_at', { precision: 3 });
    t.datetime('revoked_at', { precision: 3 });
    t.string('revoked_reason', 255);
    t.index(['server_id']);
  });

  await knex.schema.createTable('server_metrics', (t) => {
    t.bigIncrements('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.datetime('collected_at', { precision: 3 }).notNullable();
    t.decimal('cpu_percent', 5, 2);
    t.decimal('load_1', 8, 2);
    t.decimal('load_5', 8, 2);
    t.decimal('load_15', 8, 2);
    t.bigInteger('memory_used_bytes');
    t.bigInteger('memory_total_bytes');
    t.bigInteger('swap_used_bytes');
    t.bigInteger('swap_total_bytes');
    t.bigInteger('disk_used_bytes');
    t.bigInteger('disk_total_bytes');
    t.bigInteger('net_rx_bytes_per_sec');
    t.bigInteger('net_tx_bytes_per_sec');
    t.integer('process_count');
    t.bigInteger('uptime_seconds');
    t.index(['server_id', 'collected_at']);
  });

  await knex.schema.createTable('jobs', (t) => {
    t.uuid('id').primary();
    t.string('type', 64).notNullable();
    t.uuid('server_id').references('servers.id').onDelete('CASCADE');
    t.string('requested_by_type', 16).notNullable(); // 'user' | 'system'
    t.uuid('requested_by').references('users.id').onDelete('SET NULL');
    t.json('params').notNullable();
    // SHA-256 of type + server + canonical params, used to refuse duplicates.
    t.string('params_hash', 64).notNullable();
    t.string('status', 16).notNullable().defaultTo('queued');
    t.integer('attempts').notNullable().defaultTo(0);
    t.integer('max_attempts').notNullable().defaultTo(1);
    t.integer('timeout_seconds').notNullable();
    t.string('request_id', 64);
    // Deadline for the agent to pick the job up.
    t.datetime('expires_at', { precision: 3 }).notNullable();
    t.datetime('dispatched_at', { precision: 3 });
    t.datetime('started_at', { precision: 3 });
    t.datetime('finished_at', { precision: 3 });
    t.uuid('cancelled_by').references('users.id').onDelete('SET NULL');
    t.json('output');
    t.string('error_code', 64);
    t.text('error_message');
    ts(t, knex);
    t.index(['server_id', 'status']);
    t.index(['status', 'expires_at']);
    t.index(['params_hash', 'status']);
    t.index(['created_at']);
  });

  await knex.schema.createTable('job_logs', (t) => {
    t.bigIncrements('id').primary();
    t.uuid('job_id').notNullable().references('jobs.id').onDelete('CASCADE');
    t.string('stream', 16).notNullable(); // 'stdout' | 'stderr' | 'system'
    t.text('message').notNullable();
    t.datetime('logged_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['job_id', 'id']);
  });

  await knex.schema.createTable('audit_logs', (t) => {
    t.bigIncrements('id').primary();
    t.datetime('occurred_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.string('actor_type', 16).notNullable(); // 'user' | 'agent' | 'system' | 'anonymous'
    // No foreign key: audit entries must outlive whatever they refer to.
    t.string('actor_id', 36);
    t.string('actor_label', 254);
    t.string('action', 64).notNullable();
    t.string('target_type', 32);
    t.string('target_id', 64);
    t.string('target_label', 255);
    t.string('result', 16).notNullable(); // 'success' | 'failure' | 'denied'
    t.string('ip', 45);
    t.string('user_agent', 512);
    t.string('request_id', 64);
    t.json('metadata');
    t.index(['occurred_at']);
    t.index(['action']);
    t.index(['actor_id']);
    t.index(['target_type', 'target_id']);
  });

  await knex.schema.createTable('settings', (t) => {
    t.string('key', 100).primary();
    t.text('value').notNullable();
    t.boolean('is_secret').notNullable().defaultTo(false);
    t.uuid('updated_by').references('users.id').onDelete('SET NULL');
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  });

  // The audit log is append-only: the database itself refuses updates and
  // deletes, so a bug or a compromised panel process cannot rewrite history.
  if (isMysql(knex)) {
    await knex.raw(`
      CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs
      FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs is append-only'`);
    await knex.raw(`
      CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
      FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs is append-only'`);
  }
}

export async function down(knex) {
  if (isMysql(knex)) {
    await knex.raw('DROP TRIGGER IF EXISTS audit_logs_no_update');
    await knex.raw('DROP TRIGGER IF EXISTS audit_logs_no_delete');
  }
  for (const table of [
    'settings',
    'audit_logs',
    'job_logs',
    'jobs',
    'server_metrics',
    'server_agents',
    'server_enrollment_tokens',
    'servers',
    'password_reset_tokens',
    'sessions',
    'team_members',
    'teams',
    'user_roles',
    'role_permissions',
    'permissions',
    'roles',
    'users',
  ]) {
    await knex.schema.dropTableIfExists(table);
  }
}

function isMysql(knex) {
  return ['mysql', 'mysql2'].includes(knex.client.config.client);
}
