// Apps put in a website by the app installer (WordPress, Joomla, Drupal,
// Laravel), with the database the panel made for each.

export async function up(knex) {
  await knex.schema.createTable('cms_installs', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.uuid('customer_id').references('customers.id').onDelete('SET NULL');
    // wordpress | joomla | drupal | laravel
    t.string('app', 32).notNullable();
    t.string('version', 32);
    // Where its files are, relative to the site's home folder, and the folder
    // under the document root it answers at ('' for the site's root).
    t.string('directory', 300).notNullable();
    t.string('url_path', 200).notNullable().defaultTo('');
    t.string('url', 400).notNullable();
    t.string('title', 100);
    t.string('admin_user', 60);
    t.string('admin_email', 254);
    t.uuid('database_id').references('databases.id').onDelete('SET NULL');
    t.uuid('database_user_id').references('database_users.id').onDelete('SET NULL');
    // The document root the site had before a Drupal or Laravel install
    // pointed it at the project's public folder.
    t.string('previous_document_root', 255);
    // waiting (for the website or database) | installing | installed | removing | failed
    t.string('status', 16).notNullable();
    // The install job's parameters with passwords, sealed, until it is queued.
    t.text('pending_params_encrypted');
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('installed_at', { precision: 3 });
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('deleted_at', { precision: 3 });
    t.index(['website_id']);
    t.index(['server_id', 'status']);
    t.index(['customer_id']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('cms_installs');
}
