// Uptime of websites, checked from the panel the way visitors reach them.
// The website keeps its current state; each check is kept for the history
// period (uptime percentages), and each stretch of downtime is an incident.
// A "Website down" alert rule is added so new and existing panels alert on it.
import { randomUUID } from 'node:crypto';

export async function up(knex) {
  await knex.schema.alterTable('websites', (t) => {
    t.boolean('uptime_enabled').notNullable().defaultTo(true);
    // up | down; null until the first check (or while monitoring is off).
    t.string('uptime_status', 16);
    // When the current status began.
    t.datetime('uptime_since', { precision: 3 });
    t.datetime('uptime_checked_at', { precision: 3 });
    t.string('uptime_message', 500);
    t.integer('uptime_response_ms');
    // The address checked, such as https://example.com/.
    t.string('uptime_url', 300);
    // The expiry of the certificate the site served on the last HTTPS check.
    t.datetime('uptime_cert_valid_to', { precision: 3 });
  });

  await knex.schema.createTable('website_checks', (t) => {
    t.bigIncrements('id');
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.datetime('checked_at', { precision: 3 }).notNullable();
    t.boolean('ok').notNullable();
    t.integer('status_code');
    t.integer('response_ms');
    t.string('message', 500);
    t.index(['website_id', 'checked_at']);
    t.index(['checked_at']);
  });

  await knex.schema.createTable('website_incidents', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.datetime('started_at', { precision: 3 }).notNullable();
    // Null while the website is still down.
    t.datetime('ended_at', { precision: 3 });
    t.string('message', 500);
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['website_id', 'started_at']);
  });

  const now = new Date();
  await knex('alert_rules').insert({ id: randomUUID(), name: 'Website down', metric: 'website_down', threshold: null, duration_seconds: 60, severity: 'critical', is_enabled: true, created_at: now, updated_at: now });
}

export async function down(knex) {
  await knex('alert_events').where({ metric: 'website_down' }).delete();
  await knex('alert_rules').where({ metric: 'website_down' }).delete();
  await knex.schema.dropTableIfExists('website_incidents');
  await knex.schema.dropTableIfExists('website_checks');
  await knex.schema.alterTable('websites', (t) => {
    t.dropColumns('uptime_enabled', 'uptime_status', 'uptime_since', 'uptime_checked_at', 'uptime_message', 'uptime_response_ms', 'uptime_url', 'uptime_cert_valid_to');
  });
}
