// Phase 4: Node.js and Python applications deployed from Git (with their
// deployments and environment variables), and MySQL / MariaDB databases and
// database users.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

// The last change's job and error, as websites have.
const lastChange = (t) => {
  t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
  t.string('last_error_code', 64);
  t.text('last_error');
};

export async function up(knex) {
  await knex.schema.createTable('applications', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // The NGINX site serving the app's domains (a reverse proxy to its port).
    t.uuid('website_id').references('websites.id').onDelete('SET NULL');
    // Also the Linux user and home folder; shares the namespace of websites.
    t.string('name', 32).notNullable();
    // Equal to name (and port) until the app is deleted, then null, so the
    // unique indexes allow them to be used again.
    t.string('name_key', 32);
    t.string('runtime', 16).notNullable(); // 'node' | 'python'
    t.string('repository_url', 500).notNullable();
    t.string('branch', 200).notNullable();
    t.text('install_command');
    t.text('build_command');
    t.text('start_command').notNullable();
    t.integer('port');
    t.integer('port_key');
    t.integer('keep_releases').notNullable().defaultTo(5);
    t.integer('health_check_seconds').notNullable().defaultTo(30);
    // creating | ready | deploying | updating | deleting | failed
    t.string('status', 16).notNullable();
    t.string('pending_action', 32);
    t.datetime('provisioned_at', { precision: 3 });
    // The live release, from the last successful deployment or rollback.
    t.uuid('current_deployment_id');
    t.string('current_release_id', 21);
    t.string('current_commit', 40);
    t.datetime('last_deployed_at', { precision: 3 });
    // When the start command, port and environment were last written to the
    // server. Settings saved after that are not live yet.
    t.datetime('config_applied_at', { precision: 3 });
    t.datetime('config_changed_at', { precision: 3 });
    t.text('deploy_public_key');
    // The process as the agent last reported it (systemd unit pm2-<name>).
    t.string('process_state', 16);
    t.json('process_info');
    t.datetime('process_checked_at', { precision: 3 });
    // Push-to-deploy: only a hash of the webhook token is stored.
    t.string('webhook_token_hash', 64).unique();
    t.datetime('webhook_created_at', { precision: 3 });
    lastChange(t);
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['server_id', 'name_key']);
    t.unique(['server_id', 'port_key']);
    t.index(['status']);
  });

  // The spec's environment_variables: per application, values encrypted with
  // the panel's secret key.
  await knex.schema.createTable('environment_variables', (t) => {
    t.uuid('id').primary();
    t.uuid('application_id').notNullable().references('applications.id').onDelete('CASCADE');
    t.string('key', 128).notNullable();
    t.text('value_encrypted').notNullable();
    ts(t, knex);
    t.unique(['application_id', 'key']);
  });

  // Deployment history. A deployment's logs are its job's logs (job_logs).
  await knex.schema.createTable('deployments', (t) => {
    t.uuid('id').primary();
    t.uuid('application_id').notNullable().references('applications.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.string('kind', 16).notNullable(); // 'deploy' | 'rollback'
    t.string('trigger', 16).notNullable(); // manual | create | webhook | rollback
    // queued | running | succeeded | failed | cancelled
    t.string('status', 16).notNullable();
    t.string('release_id', 21).notNullable();
    // A rollback points at the deployment whose release it brought back.
    t.uuid('source_deployment_id');
    t.string('repository_url', 500);
    t.string('branch', 200);
    t.string('commit_hash', 40);
    t.string('commit_message', 500);
    t.string('commit_author', 200);
    t.string('failed_stage', 32);
    t.string('error_code', 64);
    t.text('error_message');
    // Whether its release folder is still on the server (rollbacks need it).
    t.boolean('release_available').notNullable().defaultTo(false);
    t.uuid('requested_by').references('users.id').onDelete('SET NULL');
    t.datetime('started_at', { precision: 3 });
    t.datetime('finished_at', { precision: 3 });
    ts(t, knex);
    t.index(['application_id', 'created_at']);
    t.index(['status']);
  });

  await knex.schema.createTable('databases', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // 'mariadb' today; PostgreSQL later.
    t.string('engine', 16).notNullable().defaultTo('mariadb');
    t.string('name', 64).notNullable();
    t.string('name_key', 64);
    t.string('charset', 32).notNullable().defaultTo('utf8mb4');
    t.string('collation', 64).notNullable().defaultTo('utf8mb4_unicode_ci');
    // creating | active | deleting | failed
    t.string('status', 16).notNullable();
    t.bigInteger('size_bytes');
    t.datetime('size_checked_at', { precision: 3 });
    // Optional: the app this database is for.
    t.uuid('application_id').references('applications.id').onDelete('SET NULL');
    lastChange(t);
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['server_id', 'engine', 'name_key']);
  });

  await knex.schema.createTable('database_users', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('engine', 16).notNullable().defaultTo('mariadb');
    t.string('username', 32).notNullable();
    t.string('username_key', 32);
    // Encrypted with the panel's secret key so it can be shown to admins.
    t.text('password_encrypted').notNullable();
    t.string('privileges', 16).notNullable().defaultTo('all'); // all | readonly
    // creating | active | updating | deleting | failed
    t.string('status', 16).notNullable();
    // While a change runs: the access it will give, and the new password.
    t.json('pending_spec');
    t.text('pending_password_encrypted');
    lastChange(t);
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['server_id', 'engine', 'username_key']);
  });

  // Which databases a user can reach (as live on the server).
  await knex.schema.createTable('database_user_grants', (t) => {
    t.uuid('database_user_id').notNullable().references('database_users.id').onDelete('CASCADE');
    t.uuid('database_id').notNullable().references('databases.id').onDelete('CASCADE');
    t.primary(['database_user_id', 'database_id']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('database_user_grants');
  await knex.schema.dropTableIfExists('database_users');
  await knex.schema.dropTableIfExists('databases');
  await knex.schema.dropTableIfExists('deployments');
  await knex.schema.dropTableIfExists('environment_variables');
  await knex.schema.dropTableIfExists('applications');
}
