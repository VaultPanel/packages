// Plugin directories: lists of plugins to install, published as JSON at a URL
// (see shared/src/plugins.js and docs/plugins.md#plugin-directories). The
// panel keeps the latest copy it read, so the Directory tab opens at once and
// still works while a directory is unreachable.

export async function up(knex) {
  await knex.schema.createTable('plugin_directories', (t) => {
    t.uuid('id').primary();
    t.string('url', 2000).notNullable();
    // A hash of the URL keeps it unique without a 2000-character index.
    t.string('url_hash', 64).notNullable().unique();
    // From the directory itself; null until it has been read once.
    t.string('name', 100);
    t.string('description', 500);
    t.string('homepage', 500);
    // The valid entries from the last good read, and how many were left out.
    t.json('entries').notNullable();
    t.integer('skipped_count').notNullable().defaultTo(0);
    t.json('skipped');
    t.datetime('fetched_at', { precision: 3 });
    t.datetime('last_attempt_at', { precision: 3 });
    // Why the last read failed; cleared by a good one.
    t.string('last_error', 500);
    t.uuid('added_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('plugin_directories');
}
