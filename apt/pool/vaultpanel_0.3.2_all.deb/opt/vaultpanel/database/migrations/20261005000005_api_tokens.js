// Phase 10, part 2: API tokens for the REST API, the command-line tool and
// the SDK.
//
// A token belongs to a user and acts as that user, narrowed to its scopes.
// Only the SHA-256 of the token is kept, like sessions and billing keys, so a
// token cannot be shown again after it is created.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.createTable('api_tokens', (t) => {
    t.uuid('id').primary();
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    t.string('name', 100).notNullable();
    // The first characters of the token, to recognise it in the list.
    t.string('prefix', 16).notNullable();
    t.string('token_hash', 64).notNullable().unique();
    // Scope keys (see shared/src/tokens.js).
    t.json('scopes').notNullable();
    t.datetime('expires_at', { precision: 3 });
    t.datetime('last_used_at', { precision: 3 });
    t.string('last_used_ip', 45);
    t.integer('use_count').notNullable().defaultTo(0);
    t.datetime('revoked_at', { precision: 3 });
    t.uuid('revoked_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.index(['user_id', 'revoked_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('api_tokens');
}
