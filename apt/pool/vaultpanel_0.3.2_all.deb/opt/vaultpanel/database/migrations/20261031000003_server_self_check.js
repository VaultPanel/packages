// The server self-check (agent 0.39.0): the last report each agent sent, and
// a "Server self-check failed" alert rule so new and existing panels hear
// about a check that fails (shared/src/selfCheck.js).
import { randomUUID } from 'node:crypto';

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    t.json('self_check');
  });
  const now = new Date();
  await knex('alert_rules').insert({
    id: randomUUID(),
    name: 'Server self-check failed',
    metric: 'self_check_failed',
    threshold: null,
    // Longer than the agent's 5 minutes between reports, so one bad read
    // during a change does not send an alert.
    duration_seconds: 600,
    severity: 'warning',
    is_enabled: true,
    created_at: now,
    updated_at: now,
  });
}

export async function down(knex) {
  await knex('alert_events').where({ metric: 'self_check_failed' }).delete();
  await knex('alert_rules').where({ metric: 'self_check_failed' }).delete();
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('self_check');
  });
}
