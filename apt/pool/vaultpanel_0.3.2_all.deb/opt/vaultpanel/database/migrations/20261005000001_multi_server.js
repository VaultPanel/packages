// Phase 7: multi-server management. Server groups, and bulk actions: one
// operation run on several servers, all at once or one server at a time.
// Each server's part of a bulk action is an ordinary agent job.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.createTable('server_groups', (t) => {
    t.uuid('id').primary();
    t.string('name', 60).notNullable().unique();
    t.string('description', 300).notNullable().defaultTo('');
    t.string('color', 16).notNullable().defaultTo('blue');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
  });

  // A server can be in several groups (for example "Production" and "EU").
  await knex.schema.createTable('server_group_members', (t) => {
    t.uuid('group_id').notNullable().references('server_groups.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.primary(['group_id', 'server_id']);
    t.index(['server_id']);
  });

  await knex.schema.createTable('bulk_actions', (t) => {
    t.uuid('id').primary();
    t.string('type', 64).notNullable();
    // Validated operation parameters, the same for every server.
    t.json('params');
    // 'parallel' (every server at once) or 'rolling' (one server at a time).
    t.string('mode', 16).notNullable();
    t.boolean('stop_on_failure').notNullable().defaultTo(true);
    // running | succeeded | failed | cancelled
    t.string('status', 16).notNullable().defaultTo('running');
    // The group the servers were picked from, if any (its name is kept).
    t.uuid('group_id').references('server_groups.id').onDelete('SET NULL');
    t.string('group_name', 60);
    t.string('requested_by_type', 16).notNullable().defaultTo('user');
    t.uuid('requested_by').references('users.id').onDelete('SET NULL');
    t.string('request_id', 64);
    t.datetime('cancelled_at', { precision: 3 });
    t.uuid('cancelled_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('finished_at', { precision: 3 });
    t.index(['status']);
    t.index(['created_at']);
  });

  await knex.schema.createTable('bulk_action_targets', (t) => {
    t.uuid('id').primary();
    t.uuid('action_id').notNullable().references('bulk_actions.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('server_name', 100).notNullable();
    t.integer('position').notNullable();
    // waiting | running | verifying | succeeded | failed | skipped | cancelled
    t.string('status', 16).notNullable().defaultTo('waiting');
    t.uuid('job_id');
    t.string('message', 1000);
    // After a reboot or agent update: how long to wait for the server to come back.
    t.datetime('verify_until', { precision: 3 });
    t.datetime('started_at', { precision: 3 });
    t.datetime('finished_at', { precision: 3 });
    ts(t, knex);
    t.index(['action_id', 'position']);
    t.index(['job_id']);
    t.index(['status']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('bulk_action_targets');
  await knex.schema.dropTableIfExists('bulk_actions');
  await knex.schema.dropTableIfExists('server_group_members');
  await knex.schema.dropTableIfExists('server_groups');
}
