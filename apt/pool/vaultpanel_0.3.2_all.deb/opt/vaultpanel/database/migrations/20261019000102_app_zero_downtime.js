// Zero-downtime reloads for Node.js apps: the app runs in PM2 cluster mode
// and deploys, restarts and saved settings reload it copy by copy.

export async function up(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.boolean('zero_downtime').notNullable().defaultTo(false);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.dropColumn('zero_downtime');
  });
}
