// Name servers for hosting customers, and subdomains.
//
// servers.customer_nameservers: the name servers the host tells customers
// on this server to use (shown on My Hosting). customer_dns_zones: add a DNS
// zone on this server for each new customer domain.
// dns_zones.customer_id: the account a zone was added for automatically
// (removed with the account).
// websites.subdomain_of: the parent domain of a site added on the
// Subdomains page; dns_records: the records VaultPanel added for it, taken
// out again when the site is deleted.
// hosting_plans.max_subdomains: the plan's subdomain limit (null: no limit).

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    t.text('customer_nameservers').nullable();
    t.boolean('customer_dns_zones').notNullable().defaultTo(false);
  });
  await knex.schema.alterTable('dns_zones', (t) => {
    t.uuid('customer_id').nullable().references('customers.id').onDelete('SET NULL');
  });
  await knex.schema.alterTable('websites', (t) => {
    t.string('subdomain_of', 253).nullable();
    t.text('dns_records').nullable();
  });
  await knex.schema.alterTable('hosting_plans', (t) => {
    t.integer('max_subdomains').nullable();
  });
}

export async function down(knex) {
  await knex.schema.alterTable('hosting_plans', (t) => {
    t.dropColumn('max_subdomains');
  });
  await knex.schema.alterTable('websites', (t) => {
    t.dropColumn('subdomain_of');
    t.dropColumn('dns_records');
  });
  await knex.schema.alterTable('dns_zones', (t) => {
    t.dropForeign(['customer_id']);
    t.dropColumn('customer_id');
  });
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('customer_nameservers');
    t.dropColumn('customer_dns_zones');
  });
}
