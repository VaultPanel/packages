// Custom NGINX rules a staff member adds to a website's server block, and
// whether Apache serves the site so its .htaccess files apply.
export async function up(knex) {
  await knex.schema.alterTable('websites', (t) => {
    t.text('custom_nginx');
    t.boolean('htaccess').notNullable().defaultTo(false);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('websites', (t) => {
    t.dropColumn('custom_nginx');
    t.dropColumn('htaccess');
  });
}
