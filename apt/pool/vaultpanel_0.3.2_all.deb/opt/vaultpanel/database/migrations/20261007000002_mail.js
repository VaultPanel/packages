// Email hosting: the mail server on each server that hosts email, its
// domains, mailboxes and forwarders. The panel keeps them; the agent writes
// the whole set to Postfix, Dovecot and OpenDKIM each time something changes.

export async function up(knex) {
  await knex.schema.createTable('mail_servers', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // The name mail clients and other mail servers use (mail.example.com).
    t.string('hostname', 253).notNullable();
    // setting_up | active | failed
    t.string('status', 16).notNullable();
    // letsencrypt | self-signed, from the last set-up.
    t.string('tls', 16);
    // Raised on every change to the server's domains, mailboxes and
    // forwarders; the agent confirms the one it applied.
    t.bigInteger('serial').unsigned().notNullable().defaultTo(1);
    t.bigInteger('applied_serial').unsigned();
    t.datetime('applied_at', { precision: 3 });
    // Mailboxes and domains whose stored mail is still to be deleted.
    t.json('pending_purge');
    // What public DNS said on the last check (host name and reverse DNS).
    t.json('checks');
    t.datetime('checked_at', { precision: 3 });
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.unique(['server_id']);
  });

  await knex.schema.createTable('mail_domains', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('domain', 253).notNullable();
    // Equal to domain until the domain is removed, then null.
    t.string('domain_key', 253);
    // active | deleting
    t.string('status', 16).notNullable();
    t.string('dkim_selector', 32).notNullable();
    // Add the domain's records to its DNS zone here (when the panel has one),
    // including the DKIM record once the key is made.
    t.boolean('auto_dns').notNullable().defaultTo(true);
    // Reported by the agent once it made the key (base64, for the TXT record).
    t.text('dkim_public_key');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['domain_key']);
    t.index(['server_id']);
  });

  await knex.schema.createTable('mailboxes', (t) => {
    t.uuid('id').primary();
    t.uuid('domain_id').notNullable().references('mail_domains.id').onDelete('CASCADE');
    t.string('local_part', 64).notNullable();
    // local_part@domain, unique across the panel.
    t.string('address', 254).notNullable();
    t.string('display_name', 100);
    // SHA512-CRYPT; the password itself is never stored.
    t.string('password_hash', 140).notNullable();
    // MB; 0 = no limit.
    t.integer('quota_mb').notNullable();
    t.boolean('enabled').notNullable().defaultTo(true);
    t.bigInteger('used_bytes').unsigned();
    t.datetime('usage_checked_at', { precision: 3 });
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.unique(['address']);
    t.index(['domain_id']);
  });

  await knex.schema.createTable('mail_forwarders', (t) => {
    t.uuid('id').primary();
    t.uuid('domain_id').notNullable().references('mail_domains.id').onDelete('CASCADE');
    t.string('local_part', 64).notNullable();
    t.string('address', 254).notNullable();
    t.json('destinations').notNullable();
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.unique(['address']);
    t.index(['domain_id']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('mail_forwarders');
  await knex.schema.dropTableIfExists('mailboxes');
  await knex.schema.dropTableIfExists('mail_domains');
  await knex.schema.dropTableIfExists('mail_servers');
}
