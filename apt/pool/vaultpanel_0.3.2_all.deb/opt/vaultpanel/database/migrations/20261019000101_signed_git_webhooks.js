// A secret for each push-to-deploy webhook, encrypted with the panel's secret
// key: GitHub and others sign the request body with it, GitLab sends it as a
// token. Webhooks turned on before this have none and keep working on their
// URL alone until a new URL is created.

export async function up(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.text('webhook_secret_encrypted').nullable();
  });
  await knex.schema.alterTable('websites', (t) => {
    t.text('git_webhook_secret_encrypted').nullable();
  });
}

export async function down(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.dropColumn('webhook_secret_encrypted');
  });
  await knex.schema.alterTable('websites', (t) => {
    t.dropColumn('git_webhook_secret_encrypted');
  });
}
