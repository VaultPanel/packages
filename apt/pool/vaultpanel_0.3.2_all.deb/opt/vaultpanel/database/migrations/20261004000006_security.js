// Phase 6: security. The security summary each agent reports, recovery codes
// for two-factor sign-in, and resource limits for apps. The two-factor policy
// is a row in settings (auth.two_factor_policy).

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    // Firewall, SSH, Fail2ban and update state, from the heartbeat.
    t.json('security_summary');
  });

  await knex.schema.createTable('user_recovery_codes', (t) => {
    t.uuid('id').primary();
    t.uuid('user_id').notNullable().references('users.id').onDelete('CASCADE');
    // HMAC-SHA256 of the normalized code; codes are shown once.
    t.string('code_hash', 64).notNullable();
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('used_at', { precision: 3 });
    t.index(['user_id']);
  });

  await knex.schema.alterTable('applications', (t) => {
    // Percent of one CPU core (200 = two cores), and MiB. Null: no limit.
    t.integer('cpu_limit_percent');
    t.integer('memory_limit_mb');
  });
}

export async function down(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.dropColumn('cpu_limit_percent');
    t.dropColumn('memory_limit_mb');
  });
  await knex.schema.dropTableIfExists('user_recovery_codes');
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('security_summary');
  });
}
