// A database can be linked to the website that uses it, as it can to an app,
// so the website's Backups tab can back up its database as well as its files.
// Databases the app installer made (WordPress, Joomla…) are linked to their
// website.

export async function up(knex) {
  await knex.schema.alterTable('databases', (t) => {
    t.uuid('website_id').references('websites.id').onDelete('SET NULL');
  });
  const installs = await knex('cms_installs').whereNotNull('database_id').whereNull('deleted_at').select('database_id', 'website_id');
  for (const install of installs) {
    await knex('databases').where({ id: install.database_id }).whereNull('website_id').update({ website_id: install.website_id });
  }
}

export async function down(knex) {
  await knex.schema.alterTable('databases', (t) => {
    t.dropForeign(['website_id']);
    t.dropColumn('website_id');
  });
}
