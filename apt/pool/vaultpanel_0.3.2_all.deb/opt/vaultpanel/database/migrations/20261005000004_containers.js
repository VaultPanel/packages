// Phase 10, part 1: Docker containers.
//
// servers.docker_summary is what the agent reports with each heartbeat:
// whether Docker is installed and running, its version, and one short line
// per container (deployed by VaultPanel or not).
//
// containers holds the containers VaultPanel deploys. As with databases, a
// row describes what runs on the server; a change waits in pending_* while
// its deployment job runs and is applied when the agent reports success.
// Environment variables are sealed with the panel's secret key.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    t.json('docker_summary');
  });

  await knex.schema.createTable('containers', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('name', 32).notNullable();
    // Cleared when the container is removed, so the name can be used again.
    t.string('name_key', 32);
    t.string('image', 255).notNullable();
    // { ports, volumes, restartPolicy, memoryMb, cpuPercent, command, healthCheckSeconds }
    t.json('spec').notNullable();
    // Sealed JSON list of { key, value }.
    t.text('env_encrypted');
    // A change being deployed: applied when its job succeeds.
    t.string('pending_image', 255);
    t.json('pending_spec');
    t.text('pending_env_encrypted');
    // deploying | active | failed | removing
    t.string('status', 16).notNullable();
    // What Docker last reported: its ID and state (running, exited...).
    t.string('docker_id', 64);
    t.string('state', 16);
    t.string('state_detail', 100);
    t.datetime('state_checked_at', { precision: 3 });
    t.datetime('deployed_at', { precision: 3 });
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['server_id', 'name_key']);
    t.index(['status']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('containers');
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('docker_summary');
  });
}
