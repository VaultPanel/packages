// Static sites that are single-page apps (React, Vue...): paths with no file
// are answered with index.html.
export async function up(knex) {
  await knex.schema.alterTable('websites', (t) => {
    t.boolean('spa').notNullable().defaultTo(false);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('websites', (t) => {
    t.dropColumn('spa');
  });
}
