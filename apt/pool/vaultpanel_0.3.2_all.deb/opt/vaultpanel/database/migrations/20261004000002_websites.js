// Phase 3: websites, their domains and SSL certificates. Jobs can now point
// at the resource they act on, and servers remember their web stack and
// addresses (used to check where domains point).

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    // { nginx, certbot, phpVersions, packageManager } as the agent last reported it.
    t.json('web_stack');
    // The server's own non-loopback addresses, reported by the agent.
    t.json('ip_addresses');
  });

  await knex.schema.alterTable('jobs', (t) => {
    // What the job acts on, such as { type: 'website', id }. Lets the panel
    // update that record when the job finishes.
    t.string('resource_type', 32);
    t.string('resource_id', 64);
    t.index(['resource_type', 'resource_id']);
  });

  await knex.schema.createTable('websites', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // Also the Linux user, home folder and PHP pool name on the server.
    t.string('name', 32).notNullable();
    // Equal to name until the site is deleted, then null, so the unique
    // index below allows a deleted name to be used again.
    t.string('name_key', 32);
    t.string('type', 16).notNullable(); // 'static' | 'php' | 'proxy'
    t.string('document_root', 200).notNullable().defaultTo('public');
    t.string('php_version', 4);
    t.integer('proxy_port');
    t.boolean('is_enabled').notNullable().defaultTo(true);
    t.boolean('force_https').notNullable().defaultTo(false);
    // creating | active | updating | disabled | deleting | failed
    t.string('status', 16).notNullable();
    // While a change runs: what it is and the settings it will apply. The
    // columns above always describe what is live on the server.
    t.string('pending_action', 32);
    t.json('pending_spec');
    t.datetime('provisioned_at', { precision: 3 });
    t.string('health_status', 16); // 'ok' | 'failing'
    t.string('health_message', 500);
    t.datetime('health_checked_at', { precision: 3 });
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['server_id', 'name_key']);
    t.index(['status']);
  });

  await knex.schema.createTable('website_domains', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.string('domain', 253).notNullable();
    // Equal to domain while the site exists: one site per domain panel-wide.
    t.string('domain_key', 253).unique();
    t.boolean('is_primary').notNullable().defaultTo(false);
    // Last DNS check: 'ok' | 'mismatch' | 'unresolved' | 'error'.
    t.string('dns_status', 16);
    t.json('dns_addresses');
    t.datetime('dns_checked_at', { precision: 3 });
    ts(t, knex);
    t.index(['website_id']);
  });

  await knex.schema.createTable('ssl_certificates', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().unique().references('websites.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('cert_name', 64).notNullable();
    t.string('provider', 32).notNullable().defaultTo('letsencrypt');
    // pending | active | failed | inactive
    t.string('status', 16).notNullable();
    t.json('domains');
    t.string('issuer', 255);
    t.boolean('is_staging').notNullable().defaultTo(false);
    t.string('email', 254);
    t.datetime('not_before', { precision: 3 });
    t.datetime('not_after', { precision: 3 });
    t.datetime('issued_at', { precision: 3 });
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    ts(t, knex);
    t.index(['server_id']);
    t.index(['not_after']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('ssl_certificates');
  await knex.schema.dropTableIfExists('website_domains');
  await knex.schema.dropTableIfExists('websites');
  await knex.schema.alterTable('jobs', (t) => {
    t.dropIndex(['resource_type', 'resource_id']);
    t.dropColumn('resource_type');
    t.dropColumn('resource_id');
  });
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('web_stack');
    t.dropColumn('ip_addresses');
  });
}
