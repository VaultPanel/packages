// Downloads of website files bigger than one job can carry: the server's
// agent sends the file to the panel in pieces (VAULTPANEL_DATA_DIR/downloads),
// the browser downloads it from there, and the copy is removed after an hour.

export async function up(knex) {
  await knex.schema.createTable('file_downloads', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.string('path', 1024).notNullable();
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.bigInteger('size_bytes').unsigned();
    t.string('sha256', 64);
    // Set once the whole file is in and matches the agent's checksum.
    t.datetime('ready_at', { precision: 3 });
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('file_downloads');
}
