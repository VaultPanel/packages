// Static websites deployed from Git: the site's Git settings (empty while
// it is managed with the file manager), what is live, and each deployment.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.alterTable('websites', (t) => {
    // Set while Git deploy is on.
    t.string('git_repository_url', 500);
    t.string('git_branch', 200);
    t.text('git_install_command');
    t.text('git_build_command');
    // The folder in the repository that is served ('' = the repository itself).
    t.string('git_output_dir', 200);
    t.integer('git_keep_releases').notNullable().defaultTo(5);
    // The document root served before Git deploy, served again when it is turned off.
    t.string('git_previous_document_root', 200);
    t.text('git_deploy_public_key');
    t.uuid('git_current_deployment_id');
    t.string('git_current_release_id', 21);
    t.string('git_current_commit', 40);
    t.datetime('git_last_deployed_at', { precision: 3 });
    t.string('git_webhook_token_hash', 64).unique();
    t.datetime('git_webhook_created_at', { precision: 3 });
  });

  await knex.schema.createTable('website_deployments', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.string('kind', 16).notNullable(); // 'deploy' | 'rollback'
    t.string('trigger', 16).notNullable(); // manual | create | webhook | rollback
    t.string('status', 16).notNullable(); // queued | succeeded | failed | cancelled
    t.string('release_id', 21).notNullable();
    t.uuid('source_deployment_id');
    t.string('repository_url', 500);
    t.string('branch', 200);
    t.string('output_dir', 200);
    t.string('commit_hash', 40);
    t.string('commit_message', 500);
    t.string('commit_author', 200);
    t.string('failed_stage', 32);
    t.string('error_code', 64);
    t.text('error_message');
    t.boolean('release_available').notNullable().defaultTo(false);
    t.uuid('requested_by').references('users.id').onDelete('SET NULL');
    t.datetime('started_at', { precision: 3 });
    t.datetime('finished_at', { precision: 3 });
    ts(t, knex);
    t.index(['website_id', 'created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('website_deployments');
  await knex.schema.alterTable('websites', (t) => {
    t.dropUnique(['git_webhook_token_hash']);
    for (const column of [
      'git_repository_url',
      'git_branch',
      'git_install_command',
      'git_build_command',
      'git_output_dir',
      'git_keep_releases',
      'git_previous_document_root',
      'git_deploy_public_key',
      'git_current_deployment_id',
      'git_current_release_id',
      'git_current_commit',
      'git_last_deployed_at',
      'git_webhook_token_hash',
      'git_webhook_created_at',
    ]) {
      t.dropColumn(column);
    }
  });
}
