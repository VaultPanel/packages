// DNS zones served by BIND on one of the panel's servers, and their records.
// The panel keeps the records; the agent writes the whole zone from them
// each time something changes.

export async function up(knex) {
  await knex.schema.createTable('dns_zones', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('domain', 253).notNullable();
    // Equal to domain until the zone is deleted, then null, so the unique
    // index lets the domain be added again.
    t.string('domain_key', 253);
    // creating | active | failed | deleting
    t.string('status', 16).notNullable();
    t.integer('default_ttl').notNullable().defaultTo(3600);
    // The contact address in the SOA record.
    t.string('soa_email', 254).notNullable();
    // The serial of the records as they are now, and of the zone the server
    // last confirmed. A newer serial means a change is still on its way.
    t.bigInteger('serial').unsigned().notNullable();
    t.bigInteger('applied_serial').unsigned();
    t.datetime('applied_at', { precision: 3 });
    // What public DNS said about the zone's name servers on the last check.
    t.string('delegation_status', 16);
    t.json('delegation_nameservers');
    t.text('delegation_detail');
    t.datetime('delegation_checked_at', { precision: 3 });
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('deleted_at', { precision: 3 });
    t.unique(['domain_key']);
    t.index(['server_id']);
  });

  await knex.schema.createTable('dns_records', (t) => {
    t.uuid('id').primary();
    t.uuid('zone_id').notNullable().references('dns_zones.id').onDelete('CASCADE');
    // Relative to the zone: @, www, _dmarc, *.dev
    t.string('name', 200).notNullable();
    t.string('type', 8).notNullable();
    // Null uses the zone's default.
    t.integer('ttl');
    t.text('value').notNullable();
    // MX and SRV priority, SRV weight and port, CAA tag.
    t.integer('priority');
    t.integer('weight');
    t.integer('port');
    t.string('tag', 16);
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['zone_id', 'name']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('dns_records');
  await knex.schema.dropTableIfExists('dns_zones');
}
