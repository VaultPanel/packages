// DNS providers (Cloudflare, Namecheap) whose API the agent uses to add Let's
// Encrypt's check record for wildcard certificates, when a domain's DNS is not
// on the panel's servers. The secret is stored encrypted. A certificate
// remembers the provider it was checked through.

export async function up(knex) {
  await knex.schema.createTable('dns_providers', (t) => {
    t.uuid('id').primary();
    t.string('name', 60).notNullable().unique();
    // cloudflare | namecheap
    t.string('type', 16).notNullable();
    // Namecheap's API user; Cloudflare tokens need none.
    t.string('username', 64);
    // Cloudflare's API token or Namecheap's API key.
    t.text('secret_encrypted').notNullable();
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  });

  await knex.schema.alterTable('ssl_certificates', (t) => {
    t.uuid('dns_provider_id').references('dns_providers.id').onDelete('SET NULL');
  });
}

export async function down(knex) {
  await knex.schema.alterTable('ssl_certificates', (t) => {
    t.dropForeign(['dns_provider_id']);
    t.dropColumn('dns_provider_id');
  });
  await knex.schema.dropTableIfExists('dns_providers');
}
