// Marks the server the panel itself runs on, which is connected automatically
// (see backend/src/cli/connectLocal.js). At most one row has is_local set,
// including removed servers, so a server the user removed is not re-added.

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    t.boolean('is_local').notNullable().defaultTo(false);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('is_local');
  });
}
