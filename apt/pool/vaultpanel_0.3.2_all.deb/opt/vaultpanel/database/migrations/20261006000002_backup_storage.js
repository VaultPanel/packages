// Backup storage off the server: S3-compatible buckets and other servers
// over SFTP, set up by the owner and chosen per backup and per schedule. A
// backup copied there remembers its object key, and whether a copy is still
// kept on its server.

export async function up(knex) {
  await knex.schema.createTable('backup_storages', (t) => {
    t.uuid('id').primary();
    t.string('name', 100).notNullable().unique();
    // s3 | sftp
    t.string('type', 16).notNullable().defaultTo('s3');
    // S3: aws | b2 | wasabi | r2 | other, only to show and fill the form.
    t.string('provider', 16).notNullable().defaultTo('other');
    t.string('endpoint', 255);
    t.string('region', 40);
    t.string('bucket', 63);
    // The folder backups go into: in the bucket, or on the SFTP server.
    t.string('prefix', 200).notNullable().defaultTo('');
    t.boolean('path_style').notNullable().defaultTo(false);
    t.string('access_key_id', 128);
    t.text('secret_encrypted');
    // SFTP: where to connect, the panel's own key pair for it (the private
    // key encrypted), and the server's host key, pinned on the first check.
    t.string('host', 253);
    t.integer('port');
    t.string('username', 32);
    t.text('private_key_encrypted');
    t.string('public_key', 200);
    t.text('host_key');
    t.string('host_key_fingerprint', 80);
    // Also keep each backup on its server (faster restores, uses disk).
    t.boolean('keep_local').notNullable().defaultTo(false);
    // The last check (TEST_BACKUP_STORAGE): passed | failed.
    t.string('test_status', 16);
    t.text('test_message');
    t.uuid('test_job_id');
    t.datetime('tested_at', { precision: 3 });
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  });

  await knex.schema.alterTable('backups', (t) => {
    t.uuid('storage_id').references('backup_storages.id').onDelete('RESTRICT');
    // The object in the storage, once the copy is confirmed.
    t.string('storage_key', 512);
    // False when the backup is only in the storage.
    t.boolean('local_copy').notNullable().defaultTo(true);
    // Why the copy to the storage failed (the backup stays on the server).
    t.text('storage_error');
    t.index(['storage_id']);
  });

  await knex.schema.alterTable('backup_schedules', (t) => {
    t.uuid('storage_id').references('backup_storages.id').onDelete('RESTRICT');
  });
}

export async function down(knex) {
  await knex.schema.alterTable('backup_schedules', (t) => {
    t.dropForeign(['storage_id']);
    t.dropColumn('storage_id');
  });
  await knex.schema.alterTable('backups', (t) => {
    t.dropForeign(['storage_id']);
    t.dropIndex(['storage_id']);
    t.dropColumns('storage_id', 'storage_key', 'local_copy', 'storage_error');
  });
  await knex.schema.dropTableIfExists('backup_storages');
}
