// Each hosting customer's own app ports (see CUSTOMER_PORT_RANGE in
// shared/src/hosting.js). A port belongs to at most one customer per server,
// and a customer's apps can only use their own ports. The panel fills and
// trims each customer's ports to their plan's app limit.

export async function up(knex) {
  await knex.schema.createTable('customer_ports', (t) => {
    t.uuid('id').primary();
    t.uuid('customer_id').notNullable().references('customers.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.integer('port').notNullable();
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.unique(['server_id', 'port']);
    t.index(['customer_id']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('customer_ports');
}
