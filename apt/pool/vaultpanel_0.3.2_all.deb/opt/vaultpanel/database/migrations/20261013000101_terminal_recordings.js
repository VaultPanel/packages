// Recorded terminal sessions. Every terminal an owner opens gets a row here;
// what the shell showed (and, when turned on, what was typed) is kept as an
// asciicast v2 file in VAULTPANEL_DATA_DIR/terminal-recordings/<id>.cast.
// Old recordings are removed after the number of days in the settings.

export async function up(knex) {
  await knex.schema.createTable('terminal_sessions', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('server_name', 255);
    t.uuid('user_id').references('users.id').onDelete('SET NULL');
    t.string('user_label', 255);
    t.string('ip', 64);
    t.integer('cols').unsigned();
    t.integer('rows').unsigned();
    t.datetime('started_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('ended_at', { precision: 3 });
    t.integer('exit_code');
    t.string('end_reason', 300);
    t.bigInteger('output_bytes').unsigned().notNullable().defaultTo(0);
    // recording: 'off' (not recorded), 'output' or 'output_input'.
    t.string('recording', 16).notNullable().defaultTo('off');
    t.bigInteger('recording_bytes').unsigned().notNullable().defaultTo(0);
    // The recording stopped at the size limit; the session went on.
    t.boolean('recording_truncated').notNullable().defaultTo(false);
    t.index(['started_at']);
    t.index(['server_id', 'started_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('terminal_sessions');
}
