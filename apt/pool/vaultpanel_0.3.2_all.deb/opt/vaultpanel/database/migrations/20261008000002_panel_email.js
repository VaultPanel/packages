// Email the panel sends itself (System > Panel Email): invite and password reset
// links, alerts and test messages, through the SMTP server the owner set up.
// Each message is kept here so failed ones are retried and the Email page can
// show what went out. The body is sealed (it can carry a reset link).

export async function up(knex) {
  await knex.schema.createTable('email_messages', (t) => {
    t.uuid('id').primary();
    t.string('to_address', 254).notNullable();
    t.string('subject', 255).notNullable();
    // { text } sealed with the panel's secret key.
    t.text('body_encrypted').notNullable();
    // test | invite | reset | alert
    t.string('purpose', 16).notNullable();
    // For alerts: the event (backup.failed, server.offline...).
    t.string('event', 64);
    // pending | sent | failed
    t.string('status', 16).notNullable();
    t.integer('attempts').notNullable().defaultTo(0);
    t.datetime('next_attempt_at', { precision: 3 });
    t.text('error');
    t.datetime('sent_at', { precision: 3 });
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['status', 'next_attempt_at']);
    t.index(['created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('email_messages');
}
