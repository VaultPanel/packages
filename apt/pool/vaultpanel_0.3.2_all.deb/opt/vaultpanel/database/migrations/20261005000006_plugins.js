// Phase 10, part 3: plugins.
//
// A plugin is a separate program that works with the panel through the public
// API. The panel keeps its manifest, the scopes an owner or admin approved,
// a token for it (only the SHA-256 is kept, like API tokens) and a secret it
// signs events and page links with (encrypted, because it is needed again).
// Events reach the plugin through a webhook the plugin owns.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.createTable('plugins', (t) => {
    t.uuid('id').primary();
    // The manifest's id, such as "status-board".
    t.string('slug', 64).notNullable().unique();
    t.string('name', 100).notNullable();
    t.string('version', 32).notNullable();
    t.string('description', 500);
    t.string('author', 100);
    t.string('homepage', 500);
    // Where the manifest came from, to check for a newer one. Null when pasted.
    t.text('manifest_url');
    t.json('manifest').notNullable();
    // Approved scope keys (see shared/src/tokens.js) and the events it receives.
    t.json('scopes').notNullable();
    t.json('events').notNullable();
    t.string('page_title', 60);
    t.text('page_url');
    t.string('page_icon', 32);
    t.boolean('enabled').notNullable().defaultTo(true);
    t.string('token_prefix', 16).notNullable();
    t.string('token_hash', 64).notNullable().unique();
    t.text('secret_encrypted').notNullable();
    t.uuid('installed_by').references('users.id').onDelete('SET NULL');
    t.uuid('approved_by').references('users.id').onDelete('SET NULL');
    t.datetime('approved_at', { precision: 3 });
    t.datetime('last_used_at', { precision: 3 });
    t.string('last_used_ip', 45);
    t.integer('use_count').notNullable().defaultTo(0);
    ts(t, knex);
  });

  await knex.schema.alterTable('webhooks', (t) => {
    // Set for the webhook that carries a plugin's events. Those are managed on
    // the plugin's page, not on the Webhooks page.
    t.uuid('plugin_id').unique().references('plugins.id').onDelete('CASCADE');
  });
}

export async function down(knex) {
  await knex.schema.alterTable('webhooks', (t) => {
    t.dropForeign(['plugin_id']);
    t.dropUnique(['plugin_id']);
    t.dropColumn('plugin_id');
  });
  await knex.schema.dropTableIfExists('plugins');
}
