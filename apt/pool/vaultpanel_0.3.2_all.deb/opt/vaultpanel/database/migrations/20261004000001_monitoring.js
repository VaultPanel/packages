// Phase 2: server monitoring. Hourly metric rollups for long-range history,
// mounted filesystems and agent capabilities on servers, and alerting
// (rules plus the events they raise).
import { randomUUID } from 'node:crypto';

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

// Rules every new panel starts with, so a fresh install alerts on the usual
// problems without any setup. Users can change or delete them.
export const DEFAULT_ALERT_RULES = [
  { name: 'High CPU usage', metric: 'cpu_percent', threshold: 90, duration_seconds: 600, severity: 'warning' },
  { name: 'High memory usage', metric: 'memory_percent', threshold: 90, duration_seconds: 300, severity: 'warning' },
  { name: 'Disk almost full', metric: 'disk_percent', threshold: 90, duration_seconds: 60, severity: 'critical' },
  { name: 'Server offline', metric: 'server_offline', threshold: null, duration_seconds: 60, severity: 'critical' },
  { name: 'Service down', metric: 'service_down', threshold: null, duration_seconds: 60, severity: 'warning' },
];

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    // Operations the agent says it supports (null for agents older than 0.2.0).
    t.json('agent_operations');
    // Latest usage of each mounted filesystem: [{ mount, device, fsType, totalBytes, usedBytes }].
    t.json('filesystems_snapshot');
  });

  await knex.schema.createTable('server_metrics_hourly', (t) => {
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.datetime('hour_start', { precision: 3 }).notNullable();
    t.integer('samples').notNullable();
    t.decimal('cpu_percent', 5, 2);
    t.decimal('cpu_percent_max', 5, 2);
    t.decimal('load_1', 8, 2);
    t.decimal('load_5', 8, 2);
    t.decimal('load_15', 8, 2);
    t.bigInteger('memory_used_bytes');
    t.bigInteger('memory_total_bytes');
    t.bigInteger('swap_used_bytes');
    t.bigInteger('swap_total_bytes');
    t.bigInteger('disk_used_bytes');
    t.bigInteger('disk_total_bytes');
    t.bigInteger('net_rx_bytes_per_sec');
    t.bigInteger('net_tx_bytes_per_sec');
    t.integer('process_count');
    t.primary(['server_id', 'hour_start']);
    t.index(['hour_start']);
  });

  await knex.schema.createTable('alert_rules', (t) => {
    t.uuid('id').primary();
    t.string('name', 100).notNullable();
    t.string('metric', 32).notNullable();
    // Fires when the value is at or above the threshold (metric rules only).
    t.decimal('threshold', 10, 2);
    // How long the condition must hold before the alert fires.
    t.integer('duration_seconds').notNullable().defaultTo(300);
    t.string('severity', 16).notNullable().defaultTo('warning');
    // null applies the rule to every server.
    t.uuid('server_id').references('servers.id').onDelete('CASCADE');
    // service_down rules: one service, or null for every watched service.
    t.string('service_name', 100);
    t.boolean('is_enabled').notNullable().defaultTo(true);
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.index(['is_enabled']);
  });

  await knex.schema.createTable('alert_events', (t) => {
    t.uuid('id').primary();
    t.uuid('rule_id').references('alert_rules.id').onDelete('SET NULL');
    // Copied from the rule so history still reads well after the rule changes.
    t.string('rule_name', 100).notNullable();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.string('metric', 32).notNullable();
    // What on the server the alert is about: a mount point, a service name, or ''.
    t.string('subject', 255).notNullable().defaultTo('');
    t.string('severity', 16).notNullable();
    t.string('status', 16).notNullable(); // 'pending' | 'firing' | 'resolved'
    t.decimal('threshold', 10, 2);
    t.decimal('value', 16, 2);
    t.string('message', 500).notNullable();
    t.datetime('started_at', { precision: 3 }).notNullable();
    t.datetime('fired_at', { precision: 3 });
    t.datetime('resolved_at', { precision: 3 });
    t.datetime('acknowledged_at', { precision: 3 });
    t.uuid('acknowledged_by').references('users.id').onDelete('SET NULL');
    t.datetime('last_evaluated_at', { precision: 3 }).notNullable();
    // "<rule>:<server>:<subject>" while pending or firing, null once resolved.
    // The unique index guarantees one open event per condition, even if two
    // workers evaluate at the same time.
    t.string('open_key', 400).unique();
    ts(t, knex);
    t.index(['status', 'started_at']);
    t.index(['server_id', 'status']);
    t.index(['resolved_at']);
  });

  const now = new Date();
  await knex('alert_rules').insert(
    DEFAULT_ALERT_RULES.map((rule) => ({ id: randomUUID(), ...rule, is_enabled: true, created_at: now, updated_at: now })),
  );
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('alert_events');
  await knex.schema.dropTableIfExists('alert_rules');
  await knex.schema.dropTableIfExists('server_metrics_hourly');
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('agent_operations');
    t.dropColumn('filesystems_snapshot');
  });
  await knex('settings').where({ key: 'metrics.rolled_up_until' }).delete();
}
