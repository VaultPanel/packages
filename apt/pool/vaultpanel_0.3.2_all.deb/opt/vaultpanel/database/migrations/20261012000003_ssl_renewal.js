// Automatic SSL renewal and expiry notices: when the panel last asked a
// server to renew a certificate itself (if Certbot's timer did not), and
// which expiry notice was already sent for which expiry date.

export async function up(knex) {
  await knex.schema.alterTable('ssl_certificates', (t) => {
    t.datetime('auto_renew_attempted_at', { precision: 3 }).nullable();
    t.uuid('auto_renew_job_id').nullable();
    t.string('expiry_notice', 16).nullable();
    t.datetime('expiry_notice_for', { precision: 3 }).nullable();
  });
}

export async function down(knex) {
  await knex.schema.alterTable('ssl_certificates', (t) => {
    t.dropColumn('auto_renew_attempted_at');
    t.dropColumn('auto_renew_job_id');
    t.dropColumn('expiry_notice');
    t.dropColumn('expiry_notice_for');
  });
}
