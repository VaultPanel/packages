// Phase 5: backups (with schedules and restores), cron jobs (with their run
// history) and outgoing webhooks (with their deliveries).

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

export async function up(knex) {
  await knex.schema.alterTable('servers', (t) => {
    // The server's own time zone (cron jobs run in it). Sent by agents 0.5.0+.
    t.string('timezone', 64);
  });

  await knex.schema.createTable('backup_schedules', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // website | application | database, and that record's id (one schedule each).
    t.string('resource_type', 16).notNullable();
    t.uuid('resource_id').notNullable();
    t.string('schedule', 100).notNullable();
    t.string('timezone', 64).notNullable().defaultTo('UTC');
    // How many of this schedule's backups are kept; older ones are deleted.
    t.integer('keep_count').notNullable().defaultTo(7);
    t.boolean('enabled').notNullable().defaultTo(true);
    t.datetime('next_run_at', { precision: 3 });
    t.datetime('last_run_at', { precision: 3 });
    t.uuid('last_backup_id');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.unique(['resource_type', 'resource_id']);
    t.index(['enabled', 'next_run_at']);
  });

  await knex.schema.createTable('backups', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // The record it was made from. The name is kept as it was, so a backup
    // still reads well after its website, app or database is gone.
    t.string('resource_type', 16).notNullable();
    t.uuid('resource_id').notNullable();
    t.string('resource_name', 64).notNullable();
    // creating | completed | failed | deleting | missing
    t.string('status', 16).notNullable();
    // manual | schedule | pre_restore
    t.string('trigger', 16).notNullable();
    t.uuid('schedule_id').references('backup_schedules.id').onDelete('SET NULL');
    // Where the agent wrote it on the server, its size and checksum.
    t.string('file_path', 500);
    t.bigInteger('size_bytes');
    t.string('sha256', 64);
    // Apps: the release the backup holds.
    t.string('release_id', 21);
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.string('error_code', 64);
    t.text('error');
    t.datetime('completed_at', { precision: 3 });
    t.datetime('last_restored_at', { precision: 3 });
    // A copy on the panel for downloading, while it lasts.
    t.uuid('download_job_id');
    t.string('download_path', 500);
    t.datetime('download_ready_until', { precision: 3 });
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.index(['resource_type', 'resource_id', 'created_at']);
    t.index(['server_id', 'status']);
    t.index(['schedule_id', 'status']);
  });

  await knex.schema.createTable('backup_restores', (t) => {
    t.uuid('id').primary();
    t.uuid('backup_id').notNullable().references('backups.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    // The copy of the state before the restore, when one was made.
    t.uuid('safety_backup_id');
    // running | succeeded | failed
    t.string('status', 16).notNullable();
    t.string('error_code', 64);
    t.text('error');
    t.uuid('requested_by').references('users.id').onDelete('SET NULL');
    t.datetime('finished_at', { precision: 3 });
    ts(t, knex);
    t.index(['backup_id', 'created_at']);
  });

  await knex.schema.createTable('cron_jobs', (t) => {
    t.uuid('id').primary();
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // The website or app it runs as (its Linux user).
    t.string('owner_type', 16).notNullable();
    t.uuid('owner_id').notNullable();
    t.string('user_name', 32).notNullable();
    t.string('name', 100).notNullable();
    t.string('schedule', 100).notNullable();
    t.text('commands').notNullable();
    t.string('working_dir', 200);
    t.integer('timeout_seconds').notNullable().defaultTo(3600);
    t.boolean('enabled').notNullable().defaultTo(true);
    t.boolean('app_env').notNullable().defaultTo(false);
    // creating | active | updating | deleting | failed
    t.string('status', 16).notNullable();
    // While a change runs: the settings it will make live.
    t.json('pending_spec');
    t.uuid('last_job_id').references('jobs.id').onDelete('SET NULL');
    t.string('last_error_code', 64);
    t.text('last_error');
    t.datetime('last_run_at', { precision: 3 });
    t.string('last_run_status', 16);
    t.integer('last_run_exit_code');
    t.integer('last_run_duration_ms');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
    t.datetime('deleted_at', { precision: 3 });
    t.index(['server_id']);
    t.index(['owner_type', 'owner_id']);
  });

  await knex.schema.createTable('cron_runs', (t) => {
    t.bigIncrements('id');
    t.uuid('cron_job_id').notNullable().references('cron_jobs.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    // The agent's id for the run, so a report sent twice is stored once.
    t.string('run_key', 64).notNullable().unique();
    t.string('trigger', 16).notNullable(); // schedule | manual
    t.string('status', 16).notNullable(); // succeeded | failed | timed_out | skipped
    t.integer('exit_code');
    t.datetime('started_at', { precision: 3 }).notNullable();
    t.datetime('finished_at', { precision: 3 });
    t.integer('duration_ms');
    t.text('output', 'mediumtext');
    t.boolean('output_truncated').notNullable().defaultTo(false);
    t.uuid('job_id');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['cron_job_id', 'started_at']);
  });

  await knex.schema.createTable('webhooks', (t) => {
    t.uuid('id').primary();
    t.string('name', 100).notNullable();
    // Encrypted: chat webhook URLs are themselves secrets.
    t.text('url_encrypted').notNullable();
    // Shown in lists: scheme and host only.
    t.string('url_host', 255).notNullable();
    t.string('format', 16).notNullable().defaultTo('json');
    t.json('events').notNullable();
    t.text('secret_encrypted').notNullable();
    t.boolean('enabled').notNullable().defaultTo(true);
    t.datetime('last_delivery_at', { precision: 3 });
    t.string('last_delivery_status', 16);
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
  });

  await knex.schema.createTable('webhook_deliveries', (t) => {
    t.uuid('id').primary();
    t.uuid('webhook_id').notNullable().references('webhooks.id').onDelete('CASCADE');
    t.string('event', 64).notNullable();
    t.json('payload').notNullable();
    // pending | succeeded | failed
    t.string('status', 16).notNullable();
    t.integer('attempts').notNullable().defaultTo(0);
    t.datetime('next_attempt_at', { precision: 3 });
    t.integer('response_status');
    t.text('error');
    t.integer('duration_ms');
    t.datetime('delivered_at', { precision: 3 });
    ts(t, knex);
    t.index(['status', 'next_attempt_at']);
    t.index(['webhook_id', 'created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('webhook_deliveries');
  await knex.schema.dropTableIfExists('webhooks');
  await knex.schema.dropTableIfExists('cron_runs');
  await knex.schema.dropTableIfExists('cron_jobs');
  await knex.schema.dropTableIfExists('backup_restores');
  await knex.schema.dropTableIfExists('backups');
  await knex.schema.dropTableIfExists('backup_schedules');
  await knex.schema.alterTable('servers', (t) => {
    t.dropColumn('timezone');
  });
}
