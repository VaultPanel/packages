// Large uploads in the website file manager: the browser sends the file to
// the panel in pieces, then the server's agent fetches it from the panel and
// saves it in the site. The pieces live in VAULTPANEL_DATA_DIR/uploads until
// the agent has the file, and stale uploads are removed.

export async function up(knex) {
  await knex.schema.createTable('file_uploads', (t) => {
    t.uuid('id').primary();
    t.uuid('website_id').notNullable().references('websites.id').onDelete('CASCADE');
    t.uuid('server_id').notNullable().references('servers.id').onDelete('CASCADE');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    // Where the file goes, relative to the site's home folder.
    t.string('path', 1024).notNullable();
    t.boolean('overwrite').notNullable().defaultTo(false);
    t.bigInteger('size_bytes').unsigned().notNullable();
    t.bigInteger('received_bytes').unsigned().notNullable().defaultTo(0);
    t.string('sha256', 64);
    // The FILE_UPLOAD job, once every piece is in.
    t.uuid('job_id').references('jobs.id').onDelete('SET NULL');
    t.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
    t.index(['created_at']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('file_uploads');
}
