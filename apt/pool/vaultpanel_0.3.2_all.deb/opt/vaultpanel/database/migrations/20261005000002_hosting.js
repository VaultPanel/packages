// Phase 8: hosting plans, customers, quotas and API keys for billing systems.
//
// A customer is a hosting account: a sign-in (a user with the customer role),
// a plan with its limits and a home server where its new websites, apps and
// databases are created. Everything a customer owns carries its customer_id,
// which is how the panel scopes what a customer can see and change.

const ts = (table, knex) => {
  table.datetime('created_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
  table.datetime('updated_at', { precision: 3 }).notNullable().defaultTo(knex.fn.now(3));
};

// Tables whose rows a customer can own. jobs, backups and backup schedules
// take the owner of the record they act on, so a customer sees their history.
const OWNED_TABLES = ['websites', 'applications', 'databases', 'database_users', 'cron_jobs', 'backups', 'backup_schedules', 'jobs'];

export async function up(knex) {
  await knex.schema.createTable('hosting_plans', (t) => {
    t.uuid('id').primary();
    t.string('name', 60).notNullable().unique();
    t.string('description', 300).notNullable().defaultTo('');
    // Inactive plans keep their customers but cannot be given to new ones.
    t.boolean('is_active').notNullable().defaultTo(true);
    // For display and for billing systems; VaultPanel takes no payments.
    t.integer('price_cents');
    t.string('currency', 3).notNullable().defaultTo('USD');
    t.string('billing_cycle', 16).notNullable().defaultTo('monthly');
    // Where new customers on this plan are placed (the server of the group
    // with the fewest customers), unless a server is picked.
    t.uuid('server_group_id').references('server_groups.id').onDelete('SET NULL');
    // Limits; null = unlimited.
    t.integer('max_websites');
    t.integer('max_applications');
    t.integer('max_databases');
    t.integer('max_database_users');
    t.integer('max_cron_jobs');
    t.bigInteger('disk_mb');
    // Caps applied to each app's CPU and memory limits; null = no cap.
    t.integer('app_memory_mb');
    t.integer('app_cpu_percent');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
  });

  await knex.schema.createTable('customers', (t) => {
    t.uuid('id').primary();
    // The customer's sign-in. Kept (deactivated) when the account is removed.
    t.uuid('user_id').references('users.id').onDelete('SET NULL').unique();
    t.uuid('plan_id').notNullable().references('hosting_plans.id').onDelete('RESTRICT');
    // Where the account's new websites, apps and databases go.
    t.uuid('server_id').references('servers.id').onDelete('SET NULL');
    t.string('name', 120).notNullable();
    t.string('company', 120);
    t.string('email', 254).notNullable();
    // The billing system's id for this account (WHMCS service id...).
    t.string('external_id', 100).unique();
    // active | suspended | terminated
    t.string('status', 16).notNullable().defaultTo('active');
    t.string('suspend_reason', 300);
    t.datetime('suspended_at', { precision: 3 });
    // What suspending turned off, so unsuspending turns only that back on:
    // { websites: [ids], applications: [ids], cronJobs: [ids] }.
    t.json('suspended_resources');
    t.datetime('terminated_at', { precision: 3 });
    t.string('notes', 1000).notNullable().defaultTo('');
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    // created by a user or by a billing system's API key
    t.string('created_via', 16).notNullable().defaultTo('panel');
    ts(t, knex);
    t.index(['status']);
    t.index(['plan_id']);
    t.index(['server_id']);
  });

  for (const table of OWNED_TABLES) {
    await knex.schema.alterTable(table, (t) => {
      t.uuid('customer_id').references('customers.id').onDelete('SET NULL');
      t.index(['customer_id']);
    });
  }

  // Disk use of each site's and app's folder, reported by agents 0.8.0+.
  for (const table of ['websites', 'applications']) {
    await knex.schema.alterTable(table, (t) => {
      t.bigInteger('disk_bytes');
      t.datetime('disk_checked_at', { precision: 3 });
    });
  }

  await knex.schema.createTable('api_keys', (t) => {
    t.uuid('id').primary();
    t.string('name', 100).notNullable();
    // The first characters of the key, to recognise it in the list.
    t.string('prefix', 16).notNullable();
    // SHA-256 of the whole key; the key itself is shown once and not kept.
    t.string('key_hash', 64).notNullable().unique();
    t.json('scopes').notNullable();
    t.uuid('created_by').references('users.id').onDelete('SET NULL');
    t.datetime('last_used_at', { precision: 3 });
    t.string('last_used_ip', 45);
    t.datetime('revoked_at', { precision: 3 });
    t.uuid('revoked_by').references('users.id').onDelete('SET NULL');
    ts(t, knex);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('api_keys');
  for (const table of ['websites', 'applications']) {
    await knex.schema.alterTable(table, (t) => {
      t.dropColumn('disk_bytes');
      t.dropColumn('disk_checked_at');
    });
  }
  for (const table of OWNED_TABLES) {
    await knex.schema.alterTable(table, (t) => {
      t.dropForeign(['customer_id']);
      t.dropIndex(['customer_id']);
      t.dropColumn('customer_id');
    });
  }
  await knex.schema.dropTableIfExists('customers');
  await knex.schema.dropTableIfExists('hosting_plans');
}
