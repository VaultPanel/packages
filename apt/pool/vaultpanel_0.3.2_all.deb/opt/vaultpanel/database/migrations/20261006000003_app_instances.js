// How many copies of each app run on its server (PM2 cluster mode for
// Node.js apps, WEB_CONCURRENCY workers for Python apps). 1 is how apps ran
// before.

export async function up(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.integer('instances').notNullable().defaultTo(1);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('applications', (t) => {
    t.dropColumn('instances');
  });
}
