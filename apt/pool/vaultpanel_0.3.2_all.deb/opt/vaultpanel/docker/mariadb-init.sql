-- Test database used by `npm test` (see .env.test).
CREATE DATABASE IF NOT EXISTS vaultpanel_test;
GRANT ALL ON vaultpanel_test.* TO 'vaultpanel'@'%';
