#!/bin/sh
# Shown when someone logs in over SSH (/etc/update-motd.d/99-vaultpanel links here):
# the VaultPanel banner with the panel's address and whether it is running.
[ -x /usr/local/bin/vaultpanel ] && /usr/local/bin/vaultpanel motd 2>/dev/null
exit 0
