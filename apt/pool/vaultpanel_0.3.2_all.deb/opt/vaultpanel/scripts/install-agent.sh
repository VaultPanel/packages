#!/usr/bin/env bash
# Installs the VaultPanel agent on this server and connects it to a panel.
#
#   curl -fsSL https://panel.example.com/api/v1/agent/install.sh \
#     | sudo bash -s -- --panel https://panel.example.com --token vpe_...
#
# A panel that serves HTTPS with its own self-signed certificate (the default
# for install.sh) adds --panel-pin sha256//... to both commands, and curl gets
# --pinnedpubkey sha256//... -k: the agent then trusts exactly that certificate,
# so the panel needs no domain for servers to connect safely.
#
# To update an installed agent to the version the panel serves, keeping its
# registration and config:
#
#   curl -fsSL https://panel.example.com/api/v1/agent/install.sh \
#     | sudo bash -s -- --upgrade --panel https://panel.example.com
#
# The panel connects the server it runs on by itself (backend/src/cli/connectLocal.js).
# That uses two more options: --from <dir> copies the agent from a local
# checkout instead of downloading it, and --registered installs an agent whose
# config.json was already written, without registering again.
#
# Requirements: Linux with systemd, Node.js 20+, curl, tar. Run as root.
set -euo pipefail
# The agent's code must be readable by everyone: the agent runs as its own
# user (0.36.0) and the file manager's worker as each site's user. The panel
# runs this script under its own UMask=0077, which would leave it to root.
# The config and certificate get their own modes below.
umask 022

PANEL=""
TOKEN=""
INSECURE=""
PIN=""
UPGRADE=""
FROM=""
REGISTERED=""
INSTALL_DIR="/opt/vaultpanel-agent"
CONFIG_DIR="/etc/vaultpanel-agent"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel) PANEL="$2"; shift 2 ;;
    --token) TOKEN="$2"; shift 2 ;;
    --insecure-http) INSECURE="--insecure-http"; shift ;;
    --panel-pin) PIN="$2"; shift 2 ;;
    --upgrade) UPGRADE="1"; shift ;;
    --from) FROM="$2"; shift 2 ;;
    --registered) REGISTERED="1"; shift ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

fail() { echo "error: $*" >&2; exit 1; }
[[ -z "$PIN" || "$PIN" =~ ^sha256//[A-Za-z0-9+/]{43}=$ ]] || fail "--panel-pin must look like sha256//<44 base64 characters>"
[[ -z "$PIN" || "$PANEL" == https://* ]] || fail "--panel-pin needs an https:// panel address"

if [[ -n "$UPGRADE" || -n "$REGISTERED" ]]; then
  [[ -n "$PANEL" || -n "$FROM" ]] || fail "usage: install-agent.sh --upgrade --panel <url>"
  [[ -f "$CONFIG_DIR/config.json" ]] || fail "no agent is registered here ($CONFIG_DIR/config.json is missing); install with --token instead"
else
  [[ -n "$PANEL" && -n "$TOKEN" ]] || fail "usage: install-agent.sh --panel <url> --token <enrollment token>"
fi
[[ "$(id -u)" -eq 0 ]] || fail "run as root (sudo)"
command -v systemctl >/dev/null || fail "systemd is required"
[[ -n "$FROM" ]] || command -v curl >/dev/null || fail "curl is required"
command -v tar >/dev/null || fail "tar is required"
command -v node >/dev/null || fail "Node.js 20 or newer is required (https://nodejs.org/en/download)"
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[[ "$NODE_MAJOR" -ge 20 ]] || fail "Node.js 20 or newer is required (found $(node -v))"
NODE_BIN="$(command -v node)"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/extract"

# With a pin, every download from the panel is checked against the panel's
# public key instead of a certificate authority.
CURL_TLS=()
CA_FILE="$CONFIG_DIR/panel-ca.pem"
if [[ -n "$PIN" && -z "$FROM" ]]; then
  CURL_TLS=(--pinnedpubkey "$PIN" -k)
  echo "Checking the panel's certificate"
  curl -fsSL "${CURL_TLS[@]}" "$PANEL/api/v1/agent/panel-cert.pem" -o "$TMP/panel-ca.pem" \
    || fail "could not reach $PANEL with the pinned certificate. If the panel's certificate changed, copy a new install command from the panel."
  # The certificate the panel sent must carry the pinned key too.
  GOT="$(node -e 'const c=new (require("node:crypto").X509Certificate)(require("node:fs").readFileSync(process.argv[1]));process.stdout.write("sha256//"+require("node:crypto").createHash("sha256").update(c.publicKey.export({type:"spki",format:"der"})).digest("base64"))' "$TMP/panel-ca.pem")" \
    || fail "the panel sent something that is not a certificate"
  [[ "$GOT" == "$PIN" ]] || fail "the panel's certificate does not match the pin in the install command"
fi

if [[ -n "$FROM" ]]; then
  echo "Copying the agent from $FROM"
  tar -czf "$TMP/agent.tgz" -C "$FROM/.." agent/package.json agent/src
else
  echo "Downloading the agent from $PANEL"
  curl -fsSL "${CURL_TLS[@]}" "$PANEL/api/v1/agent/package.tgz" -o "$TMP/agent.tgz"
fi
tar -xzf "$TMP/agent.tgz" -C "$TMP/extract"
[[ -f "$TMP/extract/agent/src/cli.js" ]] || fail "downloaded package is not a VaultPanel agent"

rm -rf "$INSTALL_DIR.new"
mkdir -p "$INSTALL_DIR.new"
cp -r "$TMP/extract/agent/." "$INSTALL_DIR.new/"
rm -rf "$INSTALL_DIR"
mv "$INSTALL_DIR.new" "$INSTALL_DIR"
chown -R root:root "$INSTALL_DIR"
# Readable by everyone and changed only by root, whatever modes the package had.
chmod -R u=rwX,go=rX "$INSTALL_DIR"

# Saves the panel's certificate for the agent and points the units at it.
install_panel_ca() {
  [[ -f "$TMP/panel-ca.pem" ]] || return 0
  install -m 644 -o root -g root "$TMP/panel-ca.pem" "$CA_FILE"
  local unit
  for unit in /etc/systemd/system/vaultpanel-agent.service /etc/systemd/system/vaultpanel-agent-helper.service /etc/systemd/system/vaultpanel-agent.service.root; do
    [[ -f "$unit" ]] || continue
    grep -q '^Environment=NODE_EXTRA_CA_CERTS=' "$unit" && continue
    sed -i "s|^Environment=NODE_ENV=production\$|Environment=NODE_ENV=production\nEnvironment=NODE_EXTRA_CA_CERTS=$CA_FILE|" "$unit"
  done
}

if [[ -n "$UPGRADE" ]]; then
  if [[ -n "$PIN" ]]; then
    # The panel moved to HTTPS (or got a new certificate): keep the agent's
    # registration, and point it at the address and certificate given.
    install_panel_ca
    "$NODE_BIN" -e 'const fs=require("node:fs");const [file,url]=process.argv.slice(1);const c=JSON.parse(fs.readFileSync(file,"utf8"));c.panelUrl=url.replace(/\/+$/,"");c.allowInsecureHttp=false;fs.writeFileSync(file,JSON.stringify(c,null,2)+"\n")' "$CONFIG_DIR/config.json" "$PANEL"
    systemctl daemon-reload
  fi
  # An agent that runs as its own user (0.36.0): its user reads the config,
  # and the root helper starts again on the new code first.
  if id vaultpanel-agent >/dev/null 2>&1 && [[ -f /etc/systemd/system/vaultpanel-agent-helper.service ]]; then
    chgrp vaultpanel-agent "$CONFIG_DIR" "$CONFIG_DIR/config.json"
    chmod 750 "$CONFIG_DIR"
    chmod 640 "$CONFIG_DIR/config.json"
    systemctl try-restart vaultpanel-agent-helper.service
  fi
  systemctl restart vaultpanel-agent.service
  echo "Agent updated to $("$NODE_BIN" "$INSTALL_DIR/src/cli.js" version) and restarted"
  exit 0
fi

if [[ -z "$REGISTERED" ]]; then
  echo "Registering with the panel"
  mkdir -p "$CONFIG_DIR"
  chmod 700 "$CONFIG_DIR"
  if [[ -f "$TMP/panel-ca.pem" ]]; then
    install -m 644 -o root -g root "$TMP/panel-ca.pem" "$CA_FILE"
    NODE_EXTRA_CA_CERTS="$CA_FILE" "$NODE_BIN" "$INSTALL_DIR/src/cli.js" register --panel "$PANEL" --token "$TOKEN" --config "$CONFIG_DIR/config.json"
  else
    "$NODE_BIN" "$INSTALL_DIR/src/cli.js" register --panel "$PANEL" --token "$TOKEN" --config "$CONFIG_DIR/config.json" $INSECURE
  fi
fi

CA_ENV=""
[[ -n "$FROM" || ! -f "$CA_FILE" ]] || CA_ENV="Environment=NODE_EXTRA_CA_CERTS=$CA_FILE"

# The agent starts as root once: from 0.36.0 it then moves itself to two
# services, vaultpanel-agent as the vaultpanel-agent user and a root helper,
# vaultpanel-agent-helper, that only runs what the panel signed (see
# agent/src/services/agentMode.js). If that does not work it keeps this one.
cat > /etc/systemd/system/vaultpanel-agent.service <<UNIT
[Unit]
Description=VaultPanel server agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$NODE_BIN $INSTALL_DIR/src/cli.js run --config $CONFIG_DIR/config.json
Restart=always
RestartSec=5
Environment=NODE_ENV=production
$CA_ENV
ProtectHome=read-only
# Root's SSH keys are managed from the panel's SSH page.
ReadWritePaths=-/root/.ssh
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable vaultpanel-agent.service
systemctl restart vaultpanel-agent.service
echo "VaultPanel agent installed and running. It should show as online in the panel within a few seconds."
