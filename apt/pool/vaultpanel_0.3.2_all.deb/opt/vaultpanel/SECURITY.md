# Security policy

VaultPanel manages servers as root through its agent, so security problems matter more than most
bugs. Thank you for reporting them privately.

## Reporting a vulnerability

**Do not open a public issue.** Report it privately through GitHub:
**Security > Report a vulnerability** on [VaultPanel/packages](https://github.com/VaultPanel/packages),
VaultPanel's public repository
([private vulnerability reporting](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities/privately-reporting-a-security-vulnerability)).

Please include:

- what an attacker can do, and what they need first (a panel account and which role, a hosting
  customer account, network access to an agent, nothing at all);
- the steps to reproduce it, and the VaultPanel and agent versions (`vaultpanel version`);
- any proof of concept, logs or screenshots.

What to expect:

- an acknowledgement within **3 working days**;
- an assessment, and a plan or a request for more detail, within **10 working days**;
- a fix in a release as soon as it is ready, with a GitHub security advisory that credits you
  (unless you prefer not to be named).

Please give us a reasonable time to release a fix before you publish anything, and do not access
data that is not yours or disrupt servers you do not own while testing.

## Supported versions

Security fixes go into the latest release. Update with `sudo vaultpanel update`; servers' agents are
updated from the panel (**Servers**, or **Bulk actions > Update agents**).

| Version | Supported |
| --- | --- |
| Latest release | Yes |
| Older releases | No: update first |
| `main` branch | Best effort |

## Scope

In scope: the panel (API, web interface, worker), the agent and its root helper, the installers
(`install.sh`, `scripts/install-agent.sh`), the `vaultpanel` command, the CLI and the SDK.

Out of scope: software VaultPanel installs for you (NGINX, PHP, MariaDB, Postfix...) unless VaultPanel
configures it insecurely; what an owner or admin can already do by design (for example, run commands
as root in the browser terminal); denial of service by flooding; reports from automated scanners
without a demonstrated impact.

How VaultPanel protects itself is described in [docs/security.md](docs/security.md).
