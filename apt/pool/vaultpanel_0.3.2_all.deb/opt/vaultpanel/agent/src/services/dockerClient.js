import { request } from 'node:http';
import { access } from 'node:fs/promises';

// A small client for the Docker Engine API on its unix socket. The agent
// uses it instead of the docker command: replies are structured, nothing is
// parsed out of text, and no shell or argument list is ever involved.
//
// Paths carry no API version, so Docker answers with its own current
// version (Docker 29 refuses API versions older than 1.44, while older
// Docker releases do not know the newest ones).

export const DEFAULT_DOCKER_SOCKETS = ['/var/run/docker.sock', '/run/docker.sock'];

export class DockerError extends Error {
  constructor(status, message, code = null) {
    super(message);
    this.status = status;
    this.code = code ?? (status === 404 ? 'NOT_FOUND' : status === 409 ? 'CONFLICT' : 'DOCKER_ERROR');
  }
}

// The socket to use: the dockerSocket policy key, else the first that exists.
export async function findDockerSocket(policy = {}, candidates = DEFAULT_DOCKER_SOCKETS) {
  for (const socketPath of policy.dockerSocket ? [policy.dockerSocket] : candidates) {
    try {
      await access(socketPath);
      return socketPath;
    } catch {
      // try the next one
    }
  }
  return null;
}

export function createDockerClient({ socketPath, timeoutMs = 30_000 }) {
  // Sends one request. Resolves with { status, headers, body } where body is
  // a Buffer, or streams it to onData when given.
  function send(method, path, { query, body, timeout = timeoutMs, onData } = {}) {
    const qs = query ? `?${new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined).map(([k, v]) => [k, String(v)]))}` : '';
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
    return new Promise((resolve, reject) => {
      const req = request(
        {
          socketPath,
          method,
          path: `${path}${qs}`,
          headers: { Host: 'docker', ...(payload ? { 'Content-Type': 'application/json', 'Content-Length': payload.length } : {}) },
        },
        (res) => {
          const chunks = [];
          res.on('data', (chunk) => {
            if (onData && res.statusCode < 400) onData(chunk);
            else chunks.push(chunk);
          });
          res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
          res.on('error', reject);
        },
      );
      req.setTimeout(timeout, () => req.destroy(new DockerError(0, 'Docker did not answer in time', 'DOCKER_TIMEOUT')));
      req.on('error', (err) => {
        if (err instanceof DockerError) return reject(err);
        if (['ENOENT', 'ECONNREFUSED', 'EACCES'].includes(err.code)) {
          return reject(new DockerError(0, `Docker is not running (cannot connect to ${socketPath})`, 'DOCKER_NOT_RUNNING'));
        }
        reject(err);
      });
      if (payload) req.write(payload);
      req.end();
    });
  }

  async function call(method, path, options = {}) {
    const res = await send(method, path, options);
    if (res.status >= 400) {
      let message = res.body.toString('utf8').trim();
      try {
        message = JSON.parse(message).message ?? message;
      } catch {
        // plain text error
      }
      throw new DockerError(res.status, message || `Docker answered ${res.status}`);
    }
    if (options.raw) return res.body;
    const text = res.body.toString('utf8');
    return text ? JSON.parse(text) : null;
  }

  const id = (ref) => encodeURIComponent(ref);

  return {
    socketPath,
    ping: () => call('GET', '/_ping', { raw: true, timeout: 5000 }),
    version: () => call('GET', '/version', { timeout: 10_000 }),
    info: () => call('GET', '/info', { timeout: 10_000 }),

    listContainers: () => call('GET', '/containers/json', { query: { all: 'true' } }),
    inspectContainer: (ref) => call('GET', `/containers/${id(ref)}/json`),
    createContainer: (name, config) => call('POST', '/containers/create', { query: { name }, body: config }),
    startContainer: (ref) => call('POST', `/containers/${id(ref)}/start`, { raw: true, timeout: 120_000 }),
    stopContainer: (ref, seconds = 20) => call('POST', `/containers/${id(ref)}/stop`, { query: { t: seconds }, raw: true, timeout: (seconds + 30) * 1000 }),
    restartContainer: (ref, seconds = 20) => call('POST', `/containers/${id(ref)}/restart`, { query: { t: seconds }, raw: true, timeout: (seconds + 60) * 1000 }),
    removeContainer: (ref, { force = false } = {}) => call('DELETE', `/containers/${id(ref)}`, { query: { force }, raw: true, timeout: 60_000 }),
    renameContainer: (ref, name) => call('POST', `/containers/${id(ref)}/rename`, { query: { name }, raw: true }),
    // One sample of CPU and memory use.
    stats: (ref) => call('GET', `/containers/${id(ref)}/stats`, { query: { stream: 'false' }, timeout: 15_000 }),
    // The last lines of output. Without a TTY, Docker frames each chunk with
    // its stream (see demuxLogs).
    logs: (ref, { tail = 200, timestamps = true } = {}) =>
      call('GET', `/containers/${id(ref)}/logs`, { query: { stdout: 'true', stderr: 'true', tail, timestamps }, raw: true }),

    listImages: () => call('GET', '/images/json'),
    inspectImage: (ref) => call('GET', `/images/${id(ref)}/json`),
    removeImage: (ref) => call('DELETE', `/images/${id(ref)}`, { timeout: 60_000 }),
    // Pulls an image. Docker streams progress as JSON lines; errors arrive in
    // the stream with a 200 status, so they are collected and thrown here.
    async pullImage(ref, { onProgress = () => {}, timeout = 30 * 60_000 } = {}) {
      const { name, tag } = splitImageRef(ref);
      let partial = '';
      let failure = null;
      const handle = (line) => {
        if (!line.trim()) return;
        let event;
        try {
          event = JSON.parse(line);
        } catch {
          return;
        }
        if (event.error || event.errorDetail) failure = event.errorDetail?.message ?? event.error;
        else onProgress(event);
      };
      await call('POST', '/images/create', {
        query: { fromImage: name, tag },
        raw: true,
        timeout,
        onData: (chunk) => {
          const lines = (partial + chunk.toString('utf8')).split('\n');
          partial = lines.pop();
          lines.forEach(handle);
        },
      });
      handle(partial);
      if (failure) throw new DockerError(500, failure, 'PULL_FAILED');
    },

    listVolumes: () => call('GET', '/volumes'),
    removeVolume: (name) => call('DELETE', `/volumes/${id(name)}`, { raw: true }),
    listNetworks: () => call('GET', '/networks'),
    createNetwork: (name, labels = {}) => call('POST', '/networks/create', { body: { Name: name, Driver: 'bridge', CheckDuplicate: true, Labels: labels } }),
  };
}

// "nginx:1.27" -> { name: "nginx", tag: "1.27" }. The tag is the part after
// the last colon that comes after the last slash (a registry may have a port).
// A digest stays in the name and needs no tag.
export function splitImageRef(ref) {
  if (ref.includes('@')) return { name: ref, tag: undefined };
  const slash = ref.lastIndexOf('/');
  const colon = ref.lastIndexOf(':');
  if (colon > slash) return { name: ref.slice(0, colon), tag: ref.slice(colon + 1) };
  return { name: ref, tag: 'latest' };
}

// Splits Docker's multiplexed log stream: frames of
// [stream (1 = stdout, 2 = stderr), 0, 0, 0, size (4 bytes big-endian), payload].
// Containers with a TTY send plain text instead.
export function demuxLogs(buffer, tty = false) {
  if (tty) return [{ stream: 'stdout', text: buffer.toString('utf8') }];
  const out = [];
  let offset = 0;
  while (offset + 8 <= buffer.length) {
    const type = buffer[offset];
    const size = buffer.readUInt32BE(offset + 4);
    if (type > 2 || buffer[offset + 1] !== 0 || buffer[offset + 2] !== 0 || buffer[offset + 3] !== 0) {
      // Not a framed stream after all.
      return [{ stream: 'stdout', text: buffer.toString('utf8') }];
    }
    out.push({ stream: type === 2 ? 'stderr' : 'stdout', text: buffer.subarray(offset + 8, offset + 8 + size).toString('utf8') });
    offset += 8 + size;
  }
  return out;
}

// Turns a log stream into lines: { stream, time, message }.
export function logLines(buffer, tty = false) {
  const lines = [];
  for (const { stream, text } of demuxLogs(buffer, tty)) {
    for (const raw of text.split('\n')) {
      if (!raw) continue;
      const line = raw.replace(/\r$/, '');
      const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z) (.*)$/s.exec(line);
      lines.push({ stream, time: match ? match[1] : null, message: (match ? match[2] : line).slice(0, 4000) });
    }
  }
  return lines;
}
