#!/usr/bin/env node
import { constants } from 'node:fs';
import { lstat, mkdir, open, rename, unlink } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { dropPrivileges } from './fileWorker.js';

// Writes ~/.ssh/authorized_keys for one Linux account (0.34.0).
//
// The agent starts this as root and it switches to the account's own uid and
// gid before touching anything, so a .ssh folder or key file swapped for a
// symbolic link can only lead where that account could write anyway. When
// the agent's service runs with a read-only /home (ProtectHome), the agent
// starts it in the host's mount namespace instead (see ssh.js).

const MAX_BYTES = 256 * 1024;

export async function writeAuthorizedKeys({ home, content }) {
  if (typeof home !== 'string' || !path.isAbsolute(home) || home === '/') throw new Error('home must be an absolute path');
  if (typeof content !== 'string' || Buffer.byteLength(content) > MAX_BYTES) throw new Error('content must be text up to 256 KB');
  const dir = path.join(home, '.ssh');
  try {
    const info = await lstat(dir);
    if (!info.isDirectory()) throw new Error(`${dir} is not a folder`);
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    await mkdir(dir, { mode: 0o700 });
  }
  const target = path.join(dir, 'authorized_keys');
  try {
    if ((await lstat(target)).isSymbolicLink()) throw new Error(`${target} is a symbolic link`);
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
  const tmp = path.join(dir, `.authorized_keys.${randomBytes(6).toString('hex')}`);
  const handle = await open(tmp, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  try {
    await handle.writeFile(content);
    await handle.chmod(0o600);
  } finally {
    await handle.close();
  }
  try {
    await rename(tmp, target);
  } catch (err) {
    await unlink(tmp).catch(() => {});
    throw err;
  }
  return { path: target };
}

async function main() {
  const [, , flag, uid, gid] = process.argv;
  if (flag !== '--as') throw new Error('usage: keysWorker.js --as <uid> <gid>');
  dropPrivileges(uid, gid);
  process.umask(0o077);
  let input = '';
  for await (const chunk of process.stdin) {
    input += chunk;
    if (input.length > MAX_BYTES * 2) throw new Error('request too large');
  }
  return writeAuthorizedKeys(JSON.parse(input));
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  main().then(
    (result) => process.stdout.write(JSON.stringify({ result })),
    (err) => process.stdout.write(JSON.stringify({ error: { code: 'KEYS_NOT_WRITTEN', message: err.message } })),
  );
}
