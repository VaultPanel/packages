import os from 'node:os';
import { createDiskUsage } from '../monitoring/disk.js';
import { createWebInventory } from '../monitoring/web.js';
import { scanBackups } from '../operations/backups.js';
import { readDockerSummary } from '../operations/containers.js';
import { readDatabaseInventory } from '../operations/databases.js';
import { executeOperation } from '../operations/index.js';
import { reapplyLoginBanner, syncLoginBanner } from '../operations/loginBanner.js';
import { readSecuritySummary } from '../operations/security.js';
import { readSelfCheck } from '../operations/selfCheck.js';
import { runCommand } from '../utils/exec.js';
import { readPendingRuns } from './cronRunner.js';
import { openSession } from './terminal.js';

// Everything the agent does that needs root (0.36.0): running jobs, opening
// the terminal's shell, and the parts of the heartbeat that read root-only
// files (sites, certificates, databases, backups, Docker, the security
// summary, the self-check, disk use), plus the login message.
//
// The agent that runs as root uses this directly. The agent that runs as its
// own user reaches the same thing through the root helper (helper.js), which
// checks every job and terminal request against the panel's signature itself.
export function createPrivileged(config, logger) {
  const webInventory = createWebInventory(config, {
    readDatabases: () => readDatabaseInventory({ policy: config, run: runCommand, log: () => {}, timeoutMs: 20_000 }),
    readBackups: () => scanBackups(config),
    readSecurity: () => readSecuritySummary({ policy: config, run: runCommand, log: () => {} }),
    // The server's self-check (0.39.0).
    readSelfCheck: () => readSelfCheck({ policy: config, run: runCommand, log: () => {} }),
  });
  // Disk use per site and app folder, for hosting plan quotas (0.8.0).
  const diskUsage = config.allowWebsites || config.allowApplications ? createDiskUsage(config) : null;
  const isRoot = process.getuid?.() === 0;
  const bannerCtx = { policy: config, run: runCommand, log: () => {}, binDirs: config.binDirs };
  let bannerReady = Promise.resolve();

  return {
    webInventory,

    async inventory() {
      const [web, docker] = await Promise.all([
        webInventory.read().catch(() => null),
        // Docker and its containers (0.10.0): one call to its socket.
        readDockerSummary(config).catch(() => null),
      ]);
      return { web, docker, disk: diskUsage?.current() ?? null };
    },

    // Runs a job the caller already checked (helper.js checks it again).
    execute(job, ctx) {
      const { type, params } = job.envelope;
      return executeOperation(type, params, { ...ctx, policy: config, webInventory });
    },

    openShell: (options) => openSession({ ...options, config }),

    cronRuns: (limit) => readPendingRuns(config, limit),

    // "VaultPanel only" login message: on by default, and a package update may
    // have brought a login message script back. Only root can change it.
    started() {
      if (isRoot) bannerReady = reapplyLoginBanner(bannerCtx, { serverName: os.hostname(), panelUrl: config.panelUrl }).catch((err) => logger.warn('could not apply the login message', { err }));
    },

    // The heartbeat reply carries the panel's address for the login message (0.21.0).
    panelInfo(panel) {
      if (isRoot) bannerReady = bannerReady.then(() => syncLoginBanner(bannerCtx, panel)).catch((err) => logger.warn('could not update the login message', { err }));
    },

    alive() {},
  };
}
