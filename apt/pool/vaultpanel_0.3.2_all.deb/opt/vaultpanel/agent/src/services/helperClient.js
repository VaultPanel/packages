import net from 'node:net';
import { OperationError } from '../operations/errors.js';
import { errorMessage, PANEL_METHODS, readMessages, send } from './helperProtocol.js';

const REQUEST_TIMEOUT_MS = 90_000;
const CONNECT_WAIT_MS = 30_000;

// The agent's side of the link to the root helper (0.36.0; see helper.js).
// It offers what privileged.js offers, so the rest of the agent works the same
// whether it runs as root or as its own user. The link reconnects by itself
// when the helper restarts (after an agent update, for example).
export async function connectHelper(config, logger, { createConnection = net.createConnection } = {}) {
  const socketPath = config.helperSocket;
  const pending = new Map();
  const jobs = new Map();
  const shells = new Map();
  let nextId = 0;
  let socket = null;
  let connected = false;
  let waiters = [];
  let backoff = 250;
  let warned = false;
  let closed = false;

  function connect() {
    if (closed) return;
    const conn = createConnection(socketPath);
    conn.on('connect', () => {
      socket = conn;
      connected = true;
      backoff = 250;
      if (warned) logger.info('connected to the root helper again');
      warned = false;
      for (const wake of waiters) wake();
      waiters = [];
    });
    readMessages(conn, (msg) => handle(conn, msg));
    conn.on('error', (err) => {
      if (!warned) logger.warn('cannot reach the root helper; retrying', { socket: socketPath, err });
      warned = true;
    });
    conn.on('close', () => {
      if (socket === conn) {
        socket = null;
        connected = false;
        for (const entry of pending.values()) entry.reject(new OperationError('HELPER_UNAVAILABLE', 'The connection to the agent\'s root helper was lost'));
        pending.clear();
        jobs.clear();
        for (const shell of shells.values()) shell.end({ code: null, message: 'The terminal ended because the agent\'s root helper restarted' });
        shells.clear();
      }
      if (!closed) setTimeout(connect, backoff);
      backoff = Math.min(backoff * 2, 5000);
    });
  }

  async function ready() {
    if (connected) return socket;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        waiters = waiters.filter((w) => w !== wake);
        reject(new OperationError('HELPER_UNAVAILABLE', `The agent's root helper is not answering on ${socketPath}. On the server: systemctl status vaultpanel-agent-helper`));
      }, CONNECT_WAIT_MS);
      const wake = () => {
        clearTimeout(timer);
        resolve();
      };
      waiters.push(wake);
    });
    return socket;
  }

  // Sends a message that gets one `res` back.
  async function call(message, { timeoutMs = REQUEST_TIMEOUT_MS, onLog, onSent } = {}) {
    const conn = await ready();
    nextId += 1;
    const id = nextId;
    onSent?.(id, conn);
    return new Promise((resolve, reject) => {
      const timer = timeoutMs ? setTimeout(() => finish(reject, new OperationError('HELPER_TIMEOUT', 'The agent\'s root helper did not answer in time')), timeoutMs) : null;
      const finish = (fn, value) => {
        clearTimeout(timer);
        pending.delete(id);
        fn(value);
      };
      pending.set(id, { resolve: (v) => finish(resolve, v), reject: (e) => finish(reject, e), onLog });
      send(conn, { ...message, id });
    });
  }

  function handle(conn, msg) {
    if (msg.t === 'res') {
      const entry = pending.get(msg.id);
      if (!entry) return;
      if (msg.e) {
        const err = new OperationError(String(msg.e.code ?? 'AGENT_ERROR'), String(msg.e.message ?? 'The helper failed'));
        if (msg.e.output !== undefined) err.output = msg.e.output;
        entry.reject(err);
      } else entry.resolve(msg.r);
      return;
    }
    if (msg.t === 'log') return pending.get(msg.id)?.onLog?.(msg.s, msg.m);
    if (msg.t === 'sh') return shells.get(msg.id)?.event(msg.ev);
    if (msg.t === 'panel') return panelCall(conn, msg);
  }

  // A panel call the helper's operation needs, made here with the agent's key.
  async function panelCall(conn, msg) {
    const panel = jobs.get(msg.job);
    try {
      if (!panel || !PANEL_METHODS.includes(msg.m) || typeof panel[msg.m] !== 'function') throw new OperationError('UNSUPPORTED_OPERATION', 'That panel call is not available to this job');
      const result = await panel[msg.m](...(Array.isArray(msg.a) ? msg.a : []));
      send(conn, { t: 'pres', id: msg.id, r: Buffer.isBuffer(result) ? { base64: result.toString('base64') } : (result ?? null) });
    } catch (err) {
      send(conn, { t: 'pres', id: msg.id, e: errorMessage(err) });
    }
  }

  connect();

  return {
    close() {
      closed = true;
      socket?.destroy();
    },

    inventory: () => call({ t: 'req', m: 'inventory' }),

    async execute(job, ctx) {
      const jobId = job.envelope.jobId;
      jobs.set(jobId, ctx.panel);
      try {
        let sent;
        const result = await call({ t: 'job', job }, { timeoutMs: 0, onLog: ctx.log, onSent: (id, conn) => (sent = { id, conn }) });
        return {
          output: result?.output,
          // A reboot or an agent update happens in the helper, once the panel has the result.
          after: result?.after ? async () => send(sent.conn, { t: 'after', id: sent.id }) : undefined,
        };
      } finally {
        jobs.delete(jobId);
      }
    },

    async openShell({ id, envelope, signature, emit }) {
      if (shells.has(id)) throw new OperationError('TERMINAL_REJECTED', 'This terminal session was already opened');
      let end;
      const done = new Promise((resolve) => {
        end = resolve;
      });
      const shell = {
        event(ev) {
          if (!ev || typeof ev !== 'object') return;
          emit({ ...ev, session: id });
          if (ev.type === 'exit') {
            shells.delete(id);
            end();
          }
        },
        end(info) {
          emit({ type: 'exit', session: id, ...info });
          end();
        },
      };
      shells.set(id, shell);
      try {
        await call({ t: 'shell', envelope, signature });
      } catch (err) {
        shells.delete(id);
        throw err;
      }
      const conn = socket;
      const input = (message) => conn && send(conn, { t: 'shin', id, ...message });
      return {
        id,
        done,
        write: (data) => typeof data === 'string' && data.length && input({ op: 'input', data }),
        resize: async (cols, rows) => input({ op: 'resize', cols, rows }),
        pause: () => input({ op: 'pause' }),
        resume: () => input({ op: 'resume' }),
        async close() {
          input({ op: 'close' });
          await Promise.race([done, new Promise((r) => setTimeout(r, 5000))]);
        },
      };
    },

    async cronRuns(limit) {
      const { runs = [], token } = (await call({ t: 'req', m: 'cronRuns', a: { limit } })) ?? {};
      return { runs, remove: () => call({ t: 'req', m: 'cronRemove', a: { token } }) };
    },

    // The helper applies the login message when it starts.
    started() {},

    panelInfo(panel) {
      if (panel) call({ t: 'req', m: 'panelInfo', a: { panel } }).catch(() => {});
    },

    // Tells the helper the agent reaches the panel as its own user (see agentMode.js).
    alive() {
      call({ t: 'req', m: 'alive' }).catch(() => {});
    },
  };
}
