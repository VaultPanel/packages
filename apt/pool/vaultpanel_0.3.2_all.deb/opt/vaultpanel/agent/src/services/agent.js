import { readFile } from 'node:fs/promises';
import { collectFilesystems, collectSystemInfo, createMetricsSampler } from '../monitoring/system.js';
import { SUPPORTED_OPERATIONS } from '../operations/index.js';
import { helperProblem } from '../operations/selfCheck.js';
import { readServiceStates } from '../monitoring/services.js';
import { AGENT_VERSION } from '../utils/version.js';
import { connectHelper } from './helperClient.js';
import { createPanelClient, PanelError } from './panelClient.js';
import { createPrivileged } from './privileged.js';
import { runJob } from './jobRunner.js';
import { startTerminalLink } from './terminal.js';

const FATAL_CODES = new Set(['AGENT_REVOKED']);

// The long-running agent: a heartbeat loop that reports telemetry, and a job
// loop that long-polls the panel and runs one job at a time.
export async function startAgent(config, logger) {
  const privateKeyPem = await readFile(config.privateKeyPath, 'utf8');
  const client = createPanelClient({
    panelUrl: config.panelUrl,
    agentId: config.agentId,
    privateKeyPem,
    allowInsecureHttp: config.allowInsecureHttp,
  });
  const sampler = createMetricsSampler({ diskPath: config.diskPath });
  // Not root (0.36.0): what needs root goes through the root helper, which
  // checks each job and terminal request against the panel's key itself.
  const usesHelper = Boolean(config.helperSocket && process.getuid?.() !== 0);
  const privileged = usesHelper ? await connectHelper(config, logger) : createPrivileged(config, logger);
  const seen = new Set();
  let stopped = false;
  let heartbeatSeconds = config.heartbeatIntervalSeconds;

  const stop = (reason) => {
    if (!stopped) logger.warn('agent stopping', { reason });
    stopped = true;
  };

  const handleError = (err, what) => {
    if (err instanceof PanelError && FATAL_CODES.has(err.code)) {
      stop(`${err.message}. Re-register this server from the panel.`);
      return;
    }
    logger.warn(`${what} failed`, { err, status: err.status, code: err.code });
  };

  async function heartbeatLoop() {
    while (!stopped) {
      try {
        const [system, metrics, services, filesystems, { web, docker, disk, helperError }] = await Promise.all([
          collectSystemInfo({ diskPath: config.diskPath }),
          sampler.sample(),
          readServiceStates(config.watchServices),
          collectFilesystems(),
          privileged.inventory().catch((err) => {
            logger.warn('could not read the server inventory', { err });
            // Only the root helper's inventory fails as a whole: it does not answer.
            return usesHelper ? { helperError: err } : {};
          }),
        ]);
        const { appUnits = [], ...inventory } = web ?? {};
        // App states are read every heartbeat (one systemctl call); the list
        // of apps comes from the cached inventory.
        const appStates = appUnits.length ? await readServiceStates(appUnits.map((name) => `pm2-${name}`)) : [];
        const reply = await client.heartbeat({
          agentVersion: AGENT_VERSION,
          operations: SUPPORTED_OPERATIONS,
          system: { ...system, timezone: serverTimeZone() },
          metrics,
          services,
          filesystems,
          ...inventory,
          ...(web ? { applications: appUnits.map((name) => appState(name, appStates)) } : {}),
          ...(disk ? { diskUsage: disk } : {}),
          ...(docker ? { docker } : {}),
          // The self-check (0.39.0) comes with the inventory, or says why not.
          ...(helperError ? { selfCheck: helperProblem(config, helperError) } : {}),
        });
        heartbeatSeconds = reply?.heartbeatIntervalSeconds ?? heartbeatSeconds;
        privileged.panelInfo(reply?.panel);
        privileged.alive();
      } catch (err) {
        handleError(err, 'heartbeat');
      }
      await reportCronRuns().catch((err) => handleError(err, 'cron run report'));
      await sleep(heartbeatSeconds * 1000);
    }
  }

  async function jobLoop() {
    let backoff = 1000;
    while (!stopped) {
      try {
        const job = await client.nextJob();
        backoff = 1000;
        if (job) await runJob(job, { client, config, logger, seen, execute: privileged.execute });
      } catch (err) {
        handleError(err, 'job poll');
        await sleep(backoff);
        backoff = Math.min(backoff * 2, 60_000);
      }
    }
  }

  // Results of cron jobs started by cron, saved by `cron-run` until sent.
  async function reportCronRuns() {
    for (let batch = 0; batch < 10; batch += 1) {
      const pending = await privileged.cronRuns(50);
      if (!pending.runs.length) return;
      await client.cronRuns(pending.runs);
      await pending.remove();
    }
  }

  logger.info('agent started', { version: AGENT_VERSION, serverId: config.serverId, panel: config.panelUrl });
  // The server terminal (0.11.0) has its own connection to the panel.
  const terminal = startTerminalLink(config, logger, { privateKeyPem, openShell: privileged.openShell });
  privileged.started();
  await Promise.all([heartbeatLoop(), jobLoop()]);
  terminal.stop();
  return { stop };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// The server's time zone, which cron uses for schedules.
export function serverTimeZone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

function appState(name, states) {
  const unit = states.find((s) => s.name === `pm2-${name}`);
  return { name, active: unit?.active ?? 'unknown', sub: unit?.sub ?? null, enabled: unit?.enabled ?? null };
}
