import { chmod, chown, mkdir, unlink } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { OperationError } from '../operations/errors.js';
import { AGENT_VERSION } from '../utils/version.js';
import { errorMessage, PANEL_METHODS, readMessages, send } from './helperProtocol.js';
import { checkEnvelope } from './jobRunner.js';
import { createPrivileged } from './privileged.js';
import { checkTerminalEnvelope, clampSize, MAX_SESSIONS } from './terminal.js';

const LOG_LINE_BYTES = 8000;

// The root helper (0.36.0).
//
// The agent itself runs as the vaultpanel-agent user: it talks to the panel,
// sends the heartbeat and keeps the terminal link open. What needs root runs
// here, in a separate service that has no connection to the panel and only
// listens on a unix socket the agent's group can open.
//
// The helper does not take the agent's word for anything that changes the
// server: every job and every terminal session must carry an envelope signed
// by the panel's key from the root-owned config, addressed to this server, not
// expired and not seen before; the same checks the agent made when it ran as
// root. The rest of what it answers is read-only (the inventory for the
// heartbeat, finished cron runs) or the login message.
export async function startHelper(config, logger, { socketPath = config.helperSocket, groupId, privileged = createPrivileged(config, logger), onAlive = () => {}, exitProcess } = {}) {
  if (!socketPath) throw new Error('The helper needs helperSocket in the agent config');
  const jobsSeen = new Set();
  const shellsSeen = new Set();
  let shellCount = 0;

  await mkdir(path.dirname(socketPath), { recursive: true, mode: 0o750 });
  await unlink(socketPath).catch(() => {});
  const sockets = new Set();
  const server = net.createServer((socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
    serve(socket);
  });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(socketPath, () => {
      server.off('error', reject);
      resolve();
    });
  });
  // Only root and the agent's group may connect.
  await chmod(socketPath, 0o660);
  if (groupId !== undefined) {
    await chown(path.dirname(socketPath), 0, groupId);
    await chown(socketPath, 0, groupId);
  }
  logger.info('helper listening', { version: AGENT_VERSION, socket: socketPath });

  function serve(socket) {
    const afters = new Map();
    const shells = new Map();
    const calls = new Map();
    let callId = 0;
    const reply = (id, result) => send(socket, { t: 'res', id, r: result ?? null });
    const fail = (id, err) => send(socket, { t: 'res', id, e: errorMessage(err) });

    // A panel call an operation makes, asked of the agent.
    const panelFor = (jobId) =>
      Object.fromEntries(
        PANEL_METHODS.map((method) => [
          method,
          (...args) =>
            new Promise((resolve, reject) => {
              callId += 1;
              const id = `p${callId}`;
              calls.set(id, { resolve, reject, method });
              if (!send(socket, { t: 'panel', id, job: jobId, m: method, a: args }) && socket.destroyed) {
                calls.delete(id);
                reject(new Error('The agent is not connected'));
              }
            }),
        ]),
      );

    readMessages(socket, (msg) => {
      handle(msg).catch((err) => {
        logger.warn('helper request failed', { type: msg.t, err });
        if (msg.id !== undefined && ['req', 'job', 'shell'].includes(msg.t)) fail(msg.id, err);
      });
    });
    socket.on('error', (err) => logger.debug('helper connection error', { err }));
    socket.on('close', () => {
      for (const session of shells.values()) session.close().catch(() => {});
      shells.clear();
      for (const call of calls.values()) call.reject(new Error('The agent disconnected'));
      calls.clear();
    });

    async function handle(msg) {
      if (msg.t === 'req') return reply(msg.id, await request(msg.m, msg.a ?? {}));
      if (msg.t === 'job') return runJob(msg.id, msg.job);
      if (msg.t === 'after') {
        const after = afters.get(msg.id);
        afters.delete(msg.id);
        if (after) await after();
        return;
      }
      if (msg.t === 'pres') {
        const call = calls.get(msg.id);
        if (!call) return;
        calls.delete(msg.id);
        if (msg.e) return call.reject(Object.assign(new Error(String(msg.e.message ?? 'Panel call failed')), { code: msg.e.code }));
        return call.resolve(call.method === 'downloadAgentPackage' && typeof msg.r?.base64 === 'string' ? Buffer.from(msg.r.base64, 'base64') : msg.r);
      }
      if (msg.t === 'shell') return openShell(msg);
      if (msg.t === 'shin') return shellInput(msg);
    }

    async function request(method, args) {
      if (method === 'hello') return { version: AGENT_VERSION };
      if (method === 'inventory') return privileged.inventory();
      if (method === 'cronRuns') {
        const pending = await privileged.cronRuns(Math.min(Number(args.limit) || 50, 50));
        const token = `c${(callId += 1)}`;
        afters.set(token, pending.remove);
        return { runs: pending.runs, token };
      }
      if (method === 'cronRemove') {
        const remove = afters.get(String(args.token));
        afters.delete(String(args.token));
        if (remove) await remove();
        return null;
      }
      if (method === 'panelInfo') {
        privileged.panelInfo(panelInfo(args.panel));
        return null;
      }
      if (method === 'alive') {
        onAlive();
        return null;
      }
      throw new OperationError('UNKNOWN_REQUEST', `The helper does not know "${String(method).slice(0, 40)}"`);
    }

    async function runJob(id, job) {
      const rejection = checkEnvelope(job ?? {}, config, jobsSeen);
      if (rejection) {
        logger.warn('helper rejected a job', { jobId: job?.envelope?.jobId, ...rejection });
        return fail(id, rejection);
      }
      const { envelope } = job;
      jobsSeen.add(envelope.operationId);
      logger.info('helper running job', { jobId: envelope.jobId, type: envelope.type });
      const log = (stream, message) => send(socket, { t: 'log', id, s: stream === 'stderr' ? 'stderr' : 'stdout', m: String(message).slice(0, LOG_LINE_BYTES) });
      try {
        const result = await privileged.execute(job, {
          policy: config,
          log,
          timeoutMs: envelope.timeoutSeconds * 1000,
          panel: panelFor(envelope.jobId),
          ...(exitProcess ? { exit: exitProcess } : {}),
        });
        if (result?.after) afters.set(id, result.after);
        reply(id, { output: result?.output, after: Boolean(result?.after) });
      } catch (err) {
        fail(id, err instanceof OperationError ? err : { code: 'AGENT_ERROR', message: err.message });
      }
    }

    async function openShell(msg) {
      const id = msg.envelope?.sessionId;
      if (config.allowTerminal === false) return fail(msg.id, { code: 'TERMINAL_OFF', message: 'The terminal is turned off on this server' });
      const rejection = checkTerminalEnvelope(msg, config, shellsSeen);
      if (rejection) {
        logger.warn('helper rejected a terminal session', { sessionId: id, reason: rejection });
        return fail(msg.id, { code: 'TERMINAL_REJECTED', message: rejection });
      }
      if (shellCount >= MAX_SESSIONS) return fail(msg.id, { code: 'TOO_MANY_TERMINALS', message: 'Too many terminals are open on this server' });
      shellsSeen.add(id);
      shellCount += 1;
      const session = await privileged
        .openShell({
          id,
          cols: clampSize(msg.envelope.cols, 80, 1000),
          rows: clampSize(msg.envelope.rows, 24, 500),
          emit: (event) => send(socket, { t: 'sh', id, ev: event }),
          logger,
        })
        .catch((err) => {
          shellCount -= 1;
          throw err;
        });
      shells.set(id, session);
      session.done.then(() => {
        shells.delete(id);
        shellCount -= 1;
      });
      logger.info('helper opened a terminal', { sessionId: id, requestedBy: msg.envelope.requestedBy });
      reply(msg.id, { id });
    }

    async function shellInput(msg) {
      const session = shells.get(msg.id);
      if (!session) return;
      if (msg.op === 'input') session.write(msg.data);
      else if (msg.op === 'resize') await session.resize(msg.cols, msg.rows);
      else if (msg.op === 'pause') session.pause();
      else if (msg.op === 'resume') session.resume();
      else if (msg.op === 'close') await session.close();
    }
  }

  return {
    socketPath,
    close: () =>
      new Promise((resolve) => {
        server.close(() => resolve());
        for (const socket of sockets) socket.destroy();
      }),
  };
}

// The panel's details from the heartbeat reply, for the login message. Only
// an http(s) address goes through.
export function panelInfo(panel) {
  if (!panel || typeof panel !== 'object') return undefined;
  try {
    if (typeof panel.url !== 'string' || panel.url.length > 500 || !['http:', 'https:'].includes(new URL(panel.url).protocol)) return undefined;
    return { url: panel.url, ...(typeof panel.serverName === 'string' ? { serverName: panel.serverName.slice(0, 200) } : {}) };
  } catch {
    return undefined;
  }
}
