import { spawn } from 'node:child_process';
import { access as fileAccess, chmod, chown, copyFile, mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { runCommand } from '../utils/exec.js';
import { AGENT_ROOT } from '../operations/agentUpdate.js';

// Running the agent as its own user (0.36.0).
//
// The install script starts the agent as root, as before. When an agent from
// 0.36.0 starts as root under systemd from /opt/vaultpanel-agent, it moves
// itself to two services:
//
//   vaultpanel-agent.service        the agent, as the vaultpanel-agent user:
//                                   panel connection, heartbeat, terminal link
//   vaultpanel-agent-helper.service root: runs what the panel signed (helper.js)
//
// Agents that update from the panel do the same on their first start as
// 0.36.0. If the agent does not reach the panel as its own user within 10
// minutes, the helper puts the root service back and says why in the
// server's security checks; it does not try again until the state file is
// removed. "runAsRoot": true in config.json keeps (or puts back) one root
// service.

export const AGENT_USER = 'vaultpanel-agent';
export const HELPER_SOCKET = '/run/vaultpanel-agent-helper/helper.sock';
export const AGENT_UNIT = 'vaultpanel-agent.service';
export const HELPER_UNIT = 'vaultpanel-agent-helper.service';
export const STATE_FILE = '/var/lib/vaultpanel/agent-mode.json';
// A copy of Node.js the agent's user can run, when the one the agent was
// installed with is in a home folder (nvm) or otherwise out of its reach.
export const NODE_COPY = '/opt/vaultpanel-agent-node/node';
export const CONFIRM_MS = 10 * 60_000;
// The first version with the root helper. An agent put back to an older one
// (a rollback from the panel) runs as root again.
export const OWN_USER_MIN_VERSION = '0.36.0';
const RETRY_HINT = `To try again: rm ${STATE_FILE} && systemctl restart ${AGENT_UNIT}`;

export function modePaths(policy) {
  const unitDir = policy.systemdUnitDir ?? '/etc/systemd/system';
  return {
    unitDir,
    agentUnit: path.join(unitDir, AGENT_UNIT),
    helperUnit: path.join(unitDir, HELPER_UNIT),
    rootUnitBackup: path.join(unitDir, `${AGENT_UNIT}.root`),
    stateFile: policy.agentModeFile ?? STATE_FILE,
    socket: policy.helperSocket ?? HELPER_SOCKET,
    nodeCopy: policy.agentNodeCopy ?? NODE_COPY,
  };
}

// The panel's own certificate, when it serves HTTPS with a self-signed one:
// install-agent.sh saves it next to config.json after checking its pin, and
// Node.js trusts it through NODE_EXTRA_CA_CERTS (fetch and WebSocket too).
export function panelCaPath(configPath) {
  return path.join(path.dirname(configPath), 'panel-ca.pem');
}

export async function existingPanelCa(configPath) {
  const file = panelCaPath(configPath);
  return fileAccess(file).then(
    () => file,
    () => null,
  );
}

function caLine(extraCaCerts) {
  return extraCaCerts ? `\nEnvironment=NODE_EXTRA_CA_CERTS=${extraCaCerts}` : '';
}

// The unit files. The root one is the install script's.
export function renderAgentUnit({ nodeBin, installDir, configPath, ownUser, extraCaCerts = null }) {
  const exec = `ExecStart=${nodeBin} ${installDir}/src/cli.js run --config ${configPath}`;
  if (!ownUser) {
    return `[Unit]
Description=VaultPanel server agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
${exec}
Restart=always
RestartSec=5
Environment=NODE_ENV=production${caLine(extraCaCerts)}
ProtectHome=read-only
# Root's SSH keys are managed from the panel's SSH page.
ReadWritePaths=-/root/.ssh
PrivateTmp=true

[Install]
WantedBy=multi-user.target
`;
  }
  return `# Written by the VaultPanel agent. What needs root is done by ${HELPER_UNIT}.
[Unit]
Description=VaultPanel server agent
After=network-online.target ${HELPER_UNIT}
Wants=network-online.target ${HELPER_UNIT}

[Service]
Type=simple
User=${AGENT_USER}
Group=${AGENT_USER}
${exec}
Restart=always
RestartSec=5
Environment=NODE_ENV=production${caLine(extraCaCerts)}
NoNewPrivileges=yes
CapabilityBoundingSet=
AmbientCapabilities=
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
PrivateDevices=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
LockPersonality=yes

[Install]
WantedBy=multi-user.target
`;
}

export function renderHelperUnit({ nodeBin, installDir, configPath, extraCaCerts = null }) {
  return `# Written by the VaultPanel agent. Runs as root the jobs and terminals the
# panel signed, for ${AGENT_UNIT}, which runs as ${AGENT_USER}.
[Unit]
Description=VaultPanel agent root helper
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${nodeBin} ${installDir}/src/cli.js helper --config ${configPath}
Restart=always
RestartSec=3
Environment=NODE_ENV=production${caLine(extraCaCerts)}
RuntimeDirectory=vaultpanel-agent-helper
RuntimeDirectoryMode=0750
RuntimeDirectoryPreserve=yes
ProtectHome=read-only
# Root's SSH keys are managed from the panel's SSH page.
ReadWritePaths=-/root/.ssh
PrivateTmp=true

[Install]
WantedBy=multi-user.target
`;
}

export async function readModeState(policy) {
  try {
    return JSON.parse(await readFile(modePaths(policy).stateFile, 'utf8'));
  } catch {
    return null;
  }
}

async function writeModeState(policy, state) {
  const file = modePaths(policy).stateFile;
  await mkdir(path.dirname(file), { recursive: true, mode: 0o755 });
  const tmp = `${file}.tmp-${process.pid}`;
  await writeFile(tmp, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o644 });
  await rename(tmp, file);
}

// Why this root agent does not move to its own user, or null when it should.
export async function switchBlocker(policy, { agentRoot = AGENT_ROOT, env = process.env, exists = fileExists } = {}) {
  if (policy.runAsRoot === true) return 'runAsRoot is set in the agent config';
  const state = await readModeState(policy);
  if (state?.reverted) return `${state.reason} ${RETRY_HINT}`;
  const installDir = path.resolve(policy.agentInstallDir ?? '/opt/vaultpanel-agent');
  if (path.resolve(agentRoot) !== installDir) return `the agent runs from ${agentRoot}, not from ${installDir} where the install script puts it`;
  if (!env.INVOCATION_ID) return 'the agent was not started by systemd';
  if (!(await exists(modePaths(policy).agentUnit))) return `${modePaths(policy).agentUnit} is missing`;
  return null;
}

// Moves this root agent to the two services. Returns { switched: true } once
// the helper answers and systemd is restarting the agent as its own user, or
// { switched: false, reason } with everything put back.
export async function switchToOwnUser(
  policy,
  { configPath, nodeBin = process.execPath, run = runCommand, logger, connectTimeoutMs = 20_000, probe = probeSocket, access = ensureAgentAccess, nodeFor = nodeForUser } = {},
) {
  const paths = modePaths(policy);
  const installDir = path.resolve(policy.agentInstallDir ?? '/opt/vaultpanel-agent');
  let unitsWritten = false;
  try {
    const { uid, gid } = await ensureAgentUser(run);
    const agentNode = await nodeFor(nodeBin, uid, gid, paths.nodeCopy);
    await access(policy, configPath, uid, gid);
    const current = await readFile(paths.agentUnit, 'utf8');
    // Kept to put back if the agent cannot work as its own user.
    if (!current.includes(`User=${AGENT_USER}`)) await writeFile(paths.rootUnitBackup, current, { mode: 0o644 });
    const extraCaCerts = await existingPanelCa(configPath);
    await writeFile(paths.helperUnit, renderHelperUnit({ nodeBin, installDir, configPath, extraCaCerts }), { mode: 0o644 });
    await writeFile(paths.agentUnit, renderAgentUnit({ nodeBin: agentNode, installDir, configPath, ownUser: true, extraCaCerts }), { mode: 0o644 });
    unitsWritten = true;
    await systemctl(run, ['daemon-reload']);
    await systemctl(run, ['enable', HELPER_UNIT]);
    await systemctl(run, ['restart', HELPER_UNIT]);
    if (!(await waitFor(() => probe(paths.socket), connectTimeoutMs))) {
      const status = await run('systemctl', ['status', '--no-pager', '--lines=5', HELPER_UNIT], { timeoutMs: 15_000 });
      throw new Error(`the root helper did not start: ${(status.stdout || status.stderr || '').trim().split('\n').slice(-3).join(' ')}`);
    }
    await writeModeState(policy, { mode: 'own-user', user: AGENT_USER, since: new Date().toISOString(), confirmedAt: null });
    logger?.info('moving the agent to its own user', { user: AGENT_USER, node: agentNode });
    // systemd stops this process and starts the agent as vaultpanel-agent.
    await systemctl(run, ['--no-block', 'restart', AGENT_UNIT]);
    return { switched: true };
  } catch (err) {
    const reason = `Moving the agent to its own user failed: ${err.message}.`;
    logger?.warn('could not move the agent to its own user; it keeps running as root', { err });
    if (unitsWritten) await putRootBack(policy, run).catch(() => {});
    await writeModeState(policy, { mode: 'root', reverted: true, reason, at: new Date().toISOString() }).catch(() => {});
    return { switched: false, reason: `${reason} ${RETRY_HINT}` };
  }
}

// Back to one root service (the helper's watchdog, or runAsRoot).
export async function revertToRoot(policy, reason, { run = runCommand, logger } = {}) {
  logger?.warn('putting the agent back to running as root', { reason });
  await writeModeState(policy, { mode: 'root', reverted: true, reason, at: new Date().toISOString() });
  await putRootBack(policy, run);
  await systemctl(run, ['--no-block', 'restart', AGENT_UNIT]);
  await systemctl(run, ['--no-block', 'stop', HELPER_UNIT]);
}

// After an update or rollback, in the helper: both services start again on
// the new code. Code from before the helper only works as one root service,
// which is put back (without marking it as failed, so a later update to a
// version with the helper moves the agent to its own user again).
export async function restartAfterVersionChange(policy, { run = runCommand, logger, exit = (code) => process.exit(code) } = {}) {
  const installDir = path.resolve(policy.agentInstallDir ?? '/opt/vaultpanel-agent');
  const installed = await readFile(path.join(installDir, 'package.json'), 'utf8')
    .then((text) => JSON.parse(text).version)
    .catch(() => null);
  if (installed && compareVersions(installed, OWN_USER_MIN_VERSION) < 0) {
    logger?.info('the agent now installed runs as root', { version: installed });
    await writeModeState(policy, { mode: 'root', reverted: false, reason: `agent v${installed} runs as root`, at: new Date().toISOString() });
    await putRootBack(policy, run);
    await systemctl(run, ['--no-block', 'restart', AGENT_UNIT]);
    await systemctl(run, ['--no-block', 'stop', HELPER_UNIT]);
    return exit(0);
  }
  await systemctl(run, ['--no-block', 'restart', AGENT_UNIT]).catch((err) => logger?.warn('could not restart the agent', { err }));
  return exit(0);
}

export function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i += 1) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) < (pb[i] || 0) ? -1 : 1;
  }
  return 0;
}

async function putRootBack(policy, run) {
  const paths = modePaths(policy);
  let unit = await readFile(paths.rootUnitBackup, 'utf8').catch(() => null);
  if (!unit) {
    // No backup: the root unit with the helper's own command line.
    const helper = await readFile(paths.helperUnit, 'utf8');
    const match = /^ExecStart=(\S+) (\S+)\/src\/cli\.js helper --config (\S+)$/m.exec(helper);
    if (!match) throw new Error(`cannot rebuild ${paths.agentUnit}`);
    unit = renderAgentUnit({ nodeBin: match[1], installDir: match[2], configPath: match[3], ownUser: false, extraCaCerts: await existingPanelCa(match[3]) });
  }
  await writeFile(paths.agentUnit, unit, { mode: 0o644 });
  await systemctl(run, ['disable', HELPER_UNIT]).catch(() => {});
  await systemctl(run, ['daemon-reload']);
}

// The helper's check that the agent reaches the panel as its own user, and
// runAsRoot. Returns { alive() } for each heartbeat the agent got through.
export async function watchAgent(policy, { run = runCommand, logger, now = () => Date.now(), setTimer = setTimeout } = {}) {
  if (policy.runAsRoot === true) {
    await revertToRoot(policy, 'runAsRoot is set in the agent config.', { run, logger });
    return { alive() {} };
  }
  let state = await readModeState(policy);
  let timer = null;
  if (state?.mode === 'own-user' && !state.confirmedAt) {
    const since = Date.parse(state.since) || now();
    const wait = Math.max(CONFIRM_MS - (now() - since), 60_000);
    timer = setTimer(() => {
      revertToRoot(policy, `The agent did not reach the panel as the ${AGENT_USER} user within ${CONFIRM_MS / 60_000} minutes, so it runs as root again.`, { run, logger }).catch((err) =>
        logger?.error('could not put the agent back to root', { err }),
      );
    }, wait);
  }
  return {
    alive() {
      if (!timer || state?.confirmedAt) return;
      clearTimeout(timer);
      timer = null;
      state = { ...state, confirmedAt: new Date(now()).toISOString() };
      writeModeState(policy, state).catch(() => {});
      logger?.info('the agent reaches the panel as its own user', { user: AGENT_USER });
    },
  };
}

export async function ensureAgentUser(run = runCommand) {
  let uid = await run('id', ['-u', AGENT_USER], { timeoutMs: 10_000 });
  if (uid.exitCode !== 0) {
    const added = await run('useradd', ['--system', '--user-group', '--no-create-home', '--home-dir', '/nonexistent', '--shell', '/usr/sbin/nologin', '--comment', 'VaultPanel agent', AGENT_USER], { timeoutMs: 30_000 });
    if (added.exitCode !== 0) throw new Error(`useradd failed: ${(added.stderr || added.stdout).trim()}`);
    uid = await run('id', ['-u', AGENT_USER], { timeoutMs: 10_000 });
  }
  const gid = await run('id', ['-g', AGENT_USER], { timeoutMs: 10_000 });
  const ids = { uid: Number(uid.stdout.trim()), gid: Number(gid.stdout.trim()) };
  if (!Number.isInteger(ids.uid) || !Number.isInteger(ids.gid) || ids.uid === 0) throw new Error(`unexpected ids for ${AGENT_USER}`);
  return ids;
}

// The agent's user reads the config and its key, and nothing writes them but
// root: the panel's public key in config.json is what the helper trusts.
export async function ensureAgentAccess(policy, configPath, uid, gid) {
  const dir = path.dirname(configPath);
  await chown(dir, 0, gid);
  await chmod(dir, 0o750);
  await chown(configPath, 0, gid);
  await chmod(configPath, 0o640);
  if (policy.privateKeyPath) {
    await chown(policy.privateKeyPath, uid, gid);
    await chmod(policy.privateKeyPath, 0o600);
  }
}

// Node.js the agent's user can run: the agent's own unless it lives in a
// home folder (hidden from the agent's service) or the user cannot run it.
export async function nodeForUser(nodeBin, uid, gid, copyPath = NODE_COPY) {
  const inHome = /^\/(root|home)\//.test(nodeBin);
  if (!inHome && (await runsAs(nodeBin, uid, gid))) return nodeBin;
  await mkdir(path.dirname(copyPath), { recursive: true, mode: 0o755 });
  await chmod(path.dirname(copyPath), 0o755);
  await copyFile(nodeBin, `${copyPath}.new`);
  await chmod(`${copyPath}.new`, 0o755);
  await rename(`${copyPath}.new`, copyPath);
  if (!(await runsAs(copyPath, uid, gid))) throw new Error(`${AGENT_USER} cannot run Node.js (${copyPath})`);
  return copyPath;
}

function runsAs(file, uid, gid) {
  return new Promise((resolve) => {
    const child = spawn(file, ['-e', '0'], { uid, gid, cwd: '/', stdio: 'ignore', timeout: 20_000 });
    child.on('error', () => resolve(false));
    child.on('close', (code) => resolve(code === 0));
  });
}

export function probeSocket(socketPath) {
  return new Promise((resolve) => {
    const conn = net.createConnection(socketPath);
    const done = (ok) => {
      conn.destroy();
      resolve(ok);
    };
    conn.once('connect', () => done(true));
    conn.once('error', () => done(false));
    conn.setTimeout(2000, () => done(false));
  });
}

async function waitFor(check, timeoutMs) {
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    if (await check()) return true;
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

async function systemctl(run, args) {
  const result = await run('systemctl', args, { timeoutMs: 60_000 });
  if (result.exitCode !== 0) throw new Error(`systemctl ${args.join(' ')} failed: ${(result.stderr || result.stdout || '').trim()}`);
  return result;
}

async function fileExists(file) {
  try {
    await stat(file);
    return true;
  } catch {
    return false;
  }
}
