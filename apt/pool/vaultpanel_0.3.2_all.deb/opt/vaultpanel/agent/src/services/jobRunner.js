import { executeOperation, OperationError } from '../operations/index.js';
import { verifyEnvelopeSignature } from '../security/signing.js';

const LOG_FLUSH_MS = 1000;
const LOG_BATCH = 100;

// Checks a job envelope before anything runs. Returns an error object or null.
export function checkEnvelope({ envelope, signature }, config, seen, now = Date.now()) {
  if (!envelope || typeof envelope !== 'object') return { code: 'ENVELOPE_REJECTED', message: 'Malformed job' };
  if (!verifyEnvelopeSignature(envelope, signature, config.panelPublicKey)) {
    return { code: 'ENVELOPE_REJECTED', message: 'Job signature does not match the panel key this agent trusts' };
  }
  if (envelope.serverId !== config.serverId) {
    return { code: 'ENVELOPE_REJECTED', message: 'Job is addressed to a different server' };
  }
  if (Date.parse(envelope.expiresAt) < now) return { code: 'ENVELOPE_EXPIRED', message: 'Job envelope expired' };
  if (seen.has(envelope.operationId)) return { code: 'DUPLICATE_OPERATION', message: 'Operation already executed' };
  return null;
}

// Runs one job end to end: verify, report start, execute with streamed logs,
// report the result, then run any post-report step (such as a reboot).
// execute(job, ctx) runs the checked job: directly as root, or through the
// root helper, which checks it again (0.36.0).
export async function runJob(job, { client, config, logger, seen, execute = executeDirectly }) {
  const { envelope } = job;
  const rejection = checkEnvelope(job, config, seen);
  if (rejection) {
    logger.warn('rejected job', { jobId: envelope?.jobId, ...rejection });
    // Only report back for jobs that are really ours; a forged envelope gets no reply.
    if (rejection.code !== 'ENVELOPE_REJECTED' && envelope?.jobId) {
      await client.jobResult(envelope.jobId, { status: 'failed', error: rejection }).catch(() => {});
    }
    return { status: 'rejected', error: rejection };
  }
  seen.add(envelope.operationId);
  logger.info('starting job', { jobId: envelope.jobId, type: envelope.type, attempt: envelope.attempt });
  await client.jobStarted(envelope.jobId);

  let buffer = [];
  const flush = async () => {
    if (!buffer.length) return;
    const lines = buffer;
    buffer = [];
    await client.jobLogs(envelope.jobId, lines).catch((err) => logger.warn('could not send job logs', { err }));
  };
  const timer = setInterval(flush, LOG_FLUSH_MS);
  const log = (stream, message) => {
    buffer.push({ stream, message: String(message).slice(0, 8000) });
    if (buffer.length >= LOG_BATCH) flush();
  };

  let outcome;
  try {
    const result = await execute(job, {
      policy: config,
      log,
      timeoutMs: envelope.timeoutSeconds * 1000,
      panel: client,
    });
    outcome = { status: 'succeeded', output: result.output, after: result.after };
  } catch (err) {
    const error =
      err instanceof OperationError
        ? { code: err.code, message: err.message }
        : { code: 'AGENT_ERROR', message: err.message ?? 'Unexpected agent error' };
    // An operation may report what it did before failing (a cron run, a safety backup).
    outcome = { status: 'failed', error, output: err instanceof OperationError ? err.output : undefined };
  } finally {
    clearInterval(timer);
  }
  await flush();
  await client.jobResult(envelope.jobId, { status: outcome.status, output: outcome.output, error: outcome.error });
  logger.info('finished job', { jobId: envelope.jobId, status: outcome.status, error: outcome.error });

  if (outcome.after) {
    setTimeout(() => outcome.after().catch((err) => logger.error('post-job step failed', { err })), 3000);
  }
  return { status: outcome.status, error: outcome.error };
}

const executeDirectly = (job, ctx) => executeOperation(job.envelope.type, job.envelope.params, ctx);
