#!/usr/bin/env node
import { constants } from 'node:fs';
import { chmod, lstat, mkdir, open, readdir, readlink, realpath, rename, rm, stat, symlink, unlink } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { FILE_PATH_PATTERN, MAX_FILE_BYTES, MAX_FILE_PATH_LENGTH } from '../security/webRules.js';

// Performs one file manager request inside a site's home directory.
//
// The agent runs this as a separate process under the site's own Linux user
// (see siteFiles.js), never as root. So even if a site's files are changed
// while a request runs (a directory swapped for a symlink, say), the request
// can only touch what the site user could touch anyway. The path checks
// below are a second line of defence on top of that.

const MAX_LIST_ENTRIES = 2000;

export class FileError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

const within = (root, p) => p === root || p.startsWith(root + path.sep);

function checkRelative(rel, { allowRoot = false } = {}) {
  if (typeof rel !== 'string' || rel.length > MAX_FILE_PATH_LENGTH || !FILE_PATH_PATTERN.test(rel)) {
    throw new FileError('INVALID_PATH', 'The path must stay inside the site');
  }
  if (!allowRoot && rel === '') throw new FileError('INVALID_PATH', 'This needs a file or folder inside the site, not the site itself');
  return rel;
}

// Real path of an existing file or folder, refused if it resolves outside home.
async function resolveExisting(home, rel) {
  const realHome = await realpath(home);
  const real = await realpath(path.join(realHome, rel));
  if (!within(realHome, real)) throw new FileError('OUTSIDE_SITE', 'This path leads outside the site (through a symbolic link)');
  return { realHome, real };
}

// For creating, renaming or deleting: the parent must exist inside home; the
// entry itself is not followed if it is a symlink.
async function resolveEntry(home, rel) {
  const realHome = await realpath(home);
  const parentReal = await realpath(path.join(realHome, path.dirname(rel)));
  if (!within(realHome, parentReal)) throw new FileError('OUTSIDE_SITE', 'This path leads outside the site (through a symbolic link)');
  return { realHome, target: path.join(parentReal, path.basename(rel)) };
}

async function entryInfo(fullPath, name) {
  const info = await lstat(fullPath);
  const type = info.isSymbolicLink() ? 'link' : info.isDirectory() ? 'dir' : info.isFile() ? 'file' : 'other';
  return {
    name,
    type,
    size: type === 'file' ? info.size : null,
    mode: (info.mode & 0o7777).toString(8).padStart(4, '0'),
    modifiedAt: info.mtime.toISOString(),
  };
}

async function exists(p) {
  try {
    await lstat(p);
    return true;
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    throw err;
  }
}

// Text unless it has NUL bytes or is not valid UTF-8.
function looksBinary(buffer) {
  if (buffer.subarray(0, 8000).includes(0)) return true;
  try {
    new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    return false;
  } catch {
    return true;
  }
}

async function list({ home, path: rel = '' }) {
  checkRelative(rel, { allowRoot: true });
  const { real } = await resolveExisting(home, rel);
  if (!(await stat(real)).isDirectory()) throw new FileError('NOT_A_DIRECTORY', 'This is a file, not a folder');
  const dirents = await readdir(real);
  const entries = [];
  for (const name of dirents.slice(0, MAX_LIST_ENTRIES)) {
    try {
      entries.push(await entryInfo(path.join(real, name), name));
    } catch {
      // Removed while listing.
    }
  }
  entries.sort((a, b) => (a.type === 'dir') !== (b.type === 'dir') ? (a.type === 'dir' ? -1 : 1) : a.name.localeCompare(b.name));
  return { path: rel, entries, total: dirents.length, truncated: dirents.length > MAX_LIST_ENTRIES };
}

async function read({ home, path: rel }) {
  checkRelative(rel);
  const { real } = await resolveExisting(home, rel);
  const handle = await open(real, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const info = await handle.stat();
    if (!info.isFile()) throw new FileError('NOT_A_FILE', 'Only regular files can be opened');
    if (info.size > MAX_FILE_BYTES) {
      throw new FileError('FILE_TOO_LARGE', `This file is ${info.size} bytes; the file manager opens files up to ${MAX_FILE_BYTES} bytes`);
    }
    const buffer = await handle.readFile();
    const binary = looksBinary(buffer);
    return {
      path: rel,
      size: buffer.length,
      modifiedAt: info.mtime.toISOString(),
      encoding: binary ? 'base64' : 'utf8',
      content: buffer.toString(binary ? 'base64' : 'utf8'),
    };
  } finally {
    await handle.close();
  }
}

// One piece of a file, for downloads and for opening files too big to send
// in one job (the agent sends the pieces to the panel).
const MAX_RANGE_BYTES = 2 * 1024 * 1024;
async function readRange({ home, path: rel, offset = 0, length = MAX_RANGE_BYTES }) {
  checkRelative(rel);
  if (!Number.isInteger(offset) || offset < 0) throw new FileError('INVALID_PARAMS', 'offset must be a whole number');
  if (!Number.isInteger(length) || length < 1 || length > MAX_RANGE_BYTES) throw new FileError('INVALID_PARAMS', 'length is out of range');
  const { real } = await resolveExisting(home, rel);
  const handle = await open(real, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const info = await handle.stat();
    if (!info.isFile()) throw new FileError('NOT_A_FILE', 'Only regular files can be downloaded');
    const buffer = Buffer.alloc(Math.max(0, Math.min(length, info.size - offset)));
    const { bytesRead } = buffer.length ? await handle.read(buffer, 0, buffer.length, offset) : { bytesRead: 0 };
    return { path: rel, size: info.size, modifiedAt: info.mtime.toISOString(), offset, data: buffer.subarray(0, bytesRead).toString('base64') };
  } finally {
    await handle.close();
  }
}

// Permissions, as the site's user (it owns its files). Only the read, write
// and run bits: never setuid, setgid or sticky. Links are skipped, not
// followed; with recursive, folders get mode and files fileMode.
const MAX_CHMOD_ENTRIES = 100_000;
async function changeMode({ home, path: rel, mode, recursive = false, fileMode }) {
  // Not the home folder itself: the web server needs to reach into it.
  checkRelative(rel);
  const checkMode = (m, field) => {
    if (!Number.isInteger(m) || m < 0 || m > 0o777) throw new FileError('INVALID_PARAMS', `${field} must be a mode such as 755`);
    return m;
  };
  checkMode(mode, 'mode');
  if (recursive) checkMode(fileMode, 'fileMode');
  const { target: top } = await resolveEntry(home, rel);
  const info = await lstat(top);
  if (info.isSymbolicLink()) throw new FileError('IS_SYMLINK', 'This is a symbolic link; permissions belong to what it points to');
  if (!info.isDirectory() && !info.isFile()) throw new FileError('NOT_A_FILE', 'Only files and folders have permissions here');
  let changed = 0;
  await chmod(top, info.isDirectory() || !recursive ? mode : fileMode);
  changed += 1;
  if (recursive && info.isDirectory()) {
    const stack = [top];
    while (stack.length) {
      const dir = stack.pop();
      for (const name of await readdir(dir)) {
        const full = path.join(dir, name);
        const entry = await lstat(full).catch(() => null);
        if (!entry || entry.isSymbolicLink()) continue;
        if (entry.isDirectory()) {
          await chmod(full, mode);
          stack.push(full);
        } else if (entry.isFile()) {
          await chmod(full, fileMode);
        } else continue;
        changed += 1;
        if (changed > MAX_CHMOD_ENTRIES) throw new FileError('TOO_MANY_FILES', `Stopped after ${MAX_CHMOD_ENTRIES} entries`);
      }
    }
  }
  return { path: rel, mode: mode.toString(8).padStart(3, '0'), fileMode: recursive ? fileMode.toString(8).padStart(3, '0') : null, changed };
}

// Modes the agent may ask for when it writes app configuration (.env files
// stay private to the app user).
const WRITE_MODES = [0o600, 0o640, 0o644];

async function write({ home, path: rel, content = '', encoding = 'utf8', overwrite = true, mode: forcedMode }) {
  checkRelative(rel);
  if (forcedMode !== undefined && !WRITE_MODES.includes(forcedMode)) throw new FileError('INVALID_PARAMS', 'Unsupported file mode');
  if (typeof content !== 'string') throw new FileError('INVALID_PARAMS', 'content must be text');
  if (!['utf8', 'base64'].includes(encoding)) throw new FileError('INVALID_PARAMS', 'encoding must be utf8 or base64');
  const data = Buffer.from(content, encoding);
  if (data.length > MAX_FILE_BYTES) throw new FileError('FILE_TOO_LARGE', `Files up to ${MAX_FILE_BYTES} bytes can be saved here`);
  const { target } = await resolveEntry(home, rel);
  let mode = 0o644;
  if (await exists(target)) {
    const info = await lstat(target);
    if (info.isSymbolicLink()) throw new FileError('IS_SYMLINK', 'This is a symbolic link; the file manager does not write through links');
    if (!info.isFile()) throw new FileError('NOT_A_FILE', 'A folder with this name already exists');
    if (!overwrite) throw new FileError('FILE_EXISTS', 'A file with this name already exists');
    mode = info.mode & 0o777;
  }
  if (forcedMode !== undefined) mode = forcedMode;
  // Write next to the target, then rename over it, so a failed write never
  // leaves a half-written file behind.
  const tmp = path.join(path.dirname(target), `.vp-upload-${randomBytes(6).toString('hex')}`);
  const handle = await open(tmp, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, mode);
  try {
    await handle.writeFile(data);
    await handle.chmod(mode);
  } finally {
    await handle.close();
  }
  try {
    await rename(tmp, target);
  } catch (err) {
    await unlink(tmp).catch(() => {});
    throw err;
  }
  return { path: rel, size: data.length };
}

// Large uploads: the agent downloads the file from the panel into a staging
// folder (an unguessable name the site user can read), then this copies it
// into the site as the site user, the same way write does.
async function importFile({ home, source, path: rel, overwrite = false }) {
  checkRelative(rel);
  if (typeof source !== 'string' || !path.isAbsolute(source)) throw new FileError('INVALID_PARAMS', 'source must be an absolute path');
  const input = await open(source, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    if (!(await input.stat()).isFile()) throw new FileError('NOT_A_FILE', 'The uploaded file is missing');
    const { target } = await resolveEntry(home, rel);
    let mode = 0o644;
    if (await exists(target)) {
      const info = await lstat(target);
      if (info.isSymbolicLink()) throw new FileError('IS_SYMLINK', 'This is a symbolic link; the file manager does not write through links');
      if (!info.isFile()) throw new FileError('NOT_A_FILE', 'A folder with this name already exists');
      if (!overwrite) throw new FileError('FILE_EXISTS', 'A file with this name already exists');
      mode = info.mode & 0o777;
    }
    const tmp = path.join(path.dirname(target), `.vp-upload-${randomBytes(6).toString('hex')}`);
    const output = await open(tmp, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, mode);
    let size = 0;
    try {
      const buffer = Buffer.alloc(1024 * 1024);
      for (;;) {
        const { bytesRead } = await input.read(buffer, 0, buffer.length, null);
        if (!bytesRead) break;
        await output.write(buffer, 0, bytesRead);
        size += bytesRead;
      }
      await output.chmod(mode);
    } catch (err) {
      await output.close();
      await unlink(tmp).catch(() => {});
      throw err;
    }
    await output.close();
    try {
      await rename(tmp, target);
    } catch (err) {
      await unlink(tmp).catch(() => {});
      throw err;
    }
    return { path: rel, size };
  } finally {
    await input.close();
  }
}

// The real path of a file or folder inside home, for commands the agent runs
// as the site user (unzip, tar, zip).
async function locate({ home, path: rel = '', type }) {
  checkRelative(rel, { allowRoot: true });
  const { real } = await resolveExisting(home, rel);
  const info = await stat(real);
  const found = info.isDirectory() ? 'dir' : info.isFile() ? 'file' : 'other';
  if (type === 'dir' && found !== 'dir') throw new FileError('NOT_A_DIRECTORY', `${rel || 'This'} is not a folder`);
  if (type === 'file' && found !== 'file') throw new FileError('NOT_A_FILE', `${rel} is not a file`);
  return { path: rel, real, type: found, size: found === 'file' ? info.size : null };
}

async function makeDirectory({ home, path: rel }) {
  checkRelative(rel);
  const { target } = await resolveEntry(home, rel);
  if (await exists(target)) throw new FileError('FILE_EXISTS', 'Something with this name already exists');
  await mkdir(target, { mode: 0o755 });
  return { path: rel };
}

async function move({ home, from, to }) {
  checkRelative(from);
  checkRelative(to);
  const source = await resolveEntry(home, from);
  const destination = await resolveEntry(home, to);
  if (!(await exists(source.target))) throw new FileError('FILE_NOT_FOUND', `${from} does not exist`);
  if (await exists(destination.target)) throw new FileError('FILE_EXISTS', `${to} already exists`);
  const sourceInfo = await lstat(source.target);
  if (sourceInfo.isDirectory() && within(source.target, destination.target)) {
    throw new FileError('INVALID_PATH', 'A folder cannot be moved into itself');
  }
  await rename(source.target, destination.target);
  return { from, to };
}

async function remove({ home, path: rel }) {
  checkRelative(rel);
  const { target } = await resolveEntry(home, rel);
  if (!(await exists(target))) throw new FileError('FILE_NOT_FOUND', `${rel} does not exist`);
  const info = await lstat(target);
  if (info.isDirectory()) await rm(target, { recursive: true, force: false });
  else await unlink(target);
  return { path: rel, type: info.isDirectory() ? 'dir' : 'file' };
}

// Provisioning: creates the site's folders and, when the document root is
// empty, a placeholder page so the new site answers straight away.
async function init({ home, documentRoot, folders = [], indexFile }) {
  checkRelative(documentRoot);
  const realHome = await realpath(home);
  for (const rel of [documentRoot, ...folders]) {
    checkRelative(rel);
    let current = realHome;
    for (const part of rel.split('/')) {
      current = path.join(current, part);
      try {
        await mkdir(current, { mode: 0o755 });
      } catch (err) {
        if (err.code !== 'EEXIST') throw err;
      }
      const info = await lstat(current);
      // A site deployed from Git serves "current", a link to its live release.
      if (rel === documentRoot && current === path.join(realHome, rel) && info.isSymbolicLink()) continue;
      if (!info.isDirectory()) throw new FileError('NOT_A_DIRECTORY', `${path.relative(realHome, current)} exists and is not a folder`);
    }
  }
  let created = null;
  if (indexFile) {
    const root = path.join(realHome, documentRoot);
    if ((await lstat(root)).isDirectory() && (await readdir(root)).length === 0) {
      const rel = `${documentRoot}/${indexFile.name}`;
      await write({ home, path: rel, content: indexFile.content, overwrite: false });
      created = rel;
    }
  }
  return { documentRoot, created };
}

// Site deletion: empties the home directory, as the site user.
async function clear({ home }) {
  const realHome = await realpath(home);
  const names = await readdir(realHome);
  for (const name of names) await rm(path.join(realHome, name), { recursive: true, force: true });
  return { removed: names.length };
}

// ---- Applications --------------------------------------------------------

const FOLDER_MODES = [0o700, 0o750, 0o755];

// Creates an app's folders (one level each) with the given modes.
async function appInit({ home, folders = [] }) {
  const realHome = await realpath(home);
  const created = [];
  for (const { path: rel, mode } of folders) {
    checkRelative(rel);
    if (rel.includes('/')) throw new FileError('INVALID_PATH', 'App folders are created at the top of the home folder');
    if (!FOLDER_MODES.includes(mode)) throw new FileError('INVALID_PARAMS', 'Unsupported folder mode');
    const target = path.join(realHome, rel);
    try {
      await mkdir(target, { mode });
      created.push(rel);
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
    }
    const info = await lstat(target);
    if (!info.isDirectory()) throw new FileError('NOT_A_DIRECTORY', `${rel} exists and is not a folder`);
    await chmod(target, mode);
  }
  return { created };
}

// The last lines of a log file inside home, without following links.
async function tail({ home, path: rel, lines = 200, maxBytes = 1024 * 1024 }) {
  checkRelative(rel);
  const { target } = await resolveEntry(home, rel);
  let handle;
  try {
    handle = await open(target, constants.O_RDONLY | constants.O_NOFOLLOW);
  } catch (err) {
    if (err.code === 'ENOENT') return { path: rel, lines: [], missing: true };
    throw err;
  }
  try {
    const info = await handle.stat();
    if (!info.isFile()) throw new FileError('NOT_A_FILE', 'Only regular files can be read');
    const length = Math.min(info.size, maxBytes);
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, info.size - length);
    const all = buffer.toString('utf8').split('\n').filter(Boolean);
    if (length < info.size) all.shift();
    return { path: rel, lines: all.slice(-lines).map((line) => line.slice(0, 4000)), missing: false, size: info.size };
  } finally {
    await handle.close();
  }
}

// Where a symbolic link inside home points (relative to home), or null.
async function readLink({ home, path: rel }) {
  checkRelative(rel);
  const { realHome, target } = await resolveEntry(home, rel);
  try {
    const info = await lstat(target);
    if (!info.isSymbolicLink()) return { path: rel, target: null };
  } catch (err) {
    if (err.code === 'ENOENT') return { path: rel, target: null };
    throw err;
  }
  const value = await readlink(target);
  const resolved = path.resolve(path.dirname(target), value);
  return { path: rel, target: within(realHome, resolved) ? path.relative(realHome, resolved) : null };
}

// Points a link (such as "current") at a folder inside home, atomically:
// a new link is made beside it and renamed over the old one.
async function activate({ home, path: rel, target: targetRel }) {
  checkRelative(rel);
  checkRelative(targetRel);
  const { realHome, target: linkPath } = await resolveEntry(home, rel);
  const destination = path.join(realHome, targetRel);
  const info = await lstat(destination);
  if (!info.isDirectory() || info.isSymbolicLink()) throw new FileError('NOT_A_DIRECTORY', `${targetRel} is not a folder`);
  if (await exists(linkPath)) {
    const current = await lstat(linkPath);
    if (!current.isSymbolicLink()) throw new FileError('FILE_EXISTS', `${rel} exists and is not a link`);
  }
  const previous = (await readLink({ home, path: rel })).target;
  const tmp = path.join(path.dirname(linkPath), `.vp-link-${randomBytes(6).toString('hex')}`);
  await symlink(path.relative(path.dirname(linkPath), destination), tmp);
  try {
    await rename(tmp, linkPath);
  } catch (err) {
    await unlink(tmp).catch(() => {});
    throw err;
  }
  return { path: rel, target: targetRel, previous };
}

// ---- Backups ----------------------------------------------------------------

const RESTORE_DIR_PATTERN = /^\.vp-restore-[a-z0-9]{1,32}$/;
const TOP_LEVEL_NAME = /^[^/\p{Cc}]{1,255}$/u;

function checkTopLevel(names, field) {
  if (!Array.isArray(names) || names.length > 20 || !names.every((n) => typeof n === 'string' && TOP_LEVEL_NAME.test(n) && n !== '.' && n !== '..')) {
    throw new FileError('INVALID_PARAMS', `${field} must list names at the top of the home folder`);
  }
  return names;
}

async function isRealDirectory(p) {
  try {
    const info = await lstat(p);
    return info.isDirectory() && !info.isSymbolicLink();
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    throw err;
  }
}

// Restores a backup that was unpacked into <staging> inside home: the
// current entries move aside into <staging>-old and the backup's entries
// take their place. Names in keep stay as they are on the server; folders in
// merge (an app's releases) are merged child by child. If a step fails, the
// steps already done are reversed. The caller removes the two folders after.
async function restoreSwap({ home, staging, keep = [], merge = [] }) {
  if (typeof staging !== 'string' || !RESTORE_DIR_PATTERN.test(staging)) throw new FileError('INVALID_PARAMS', 'Invalid staging folder');
  checkTopLevel(keep, 'keep');
  checkTopLevel(merge, 'merge');
  const realHome = await realpath(home);
  const stagingDir = path.join(realHome, staging);
  if (!(await isRealDirectory(stagingDir))) throw new FileError('NOT_A_DIRECTORY', 'The unpacked backup is missing');
  const oldName = `${staging}-old`;
  const oldDir = path.join(realHome, oldName);
  await mkdir(oldDir, { mode: 0o700 });

  const done = [];
  const step = async (from, to) => {
    await rename(from, to);
    done.push([from, to]);
  };
  const isOurs = (name) => name === staging || name === oldName || RESTORE_DIR_PATTERN.test(name.replace(/-old$/, ''));
  try {
    let replaced = 0;
    for (const name of await readdir(realHome)) {
      if (isOurs(name) || keep.includes(name) || merge.includes(name)) continue;
      await step(path.join(realHome, name), path.join(oldDir, name));
      replaced += 1;
    }
    let restored = 0;
    for (const name of await readdir(stagingDir)) {
      if (keep.includes(name) || isOurs(name)) continue;
      const from = path.join(stagingDir, name);
      const to = path.join(realHome, name);
      if (merge.includes(name) && (await isRealDirectory(from)) && (await isRealDirectory(to))) {
        await mkdir(path.join(oldDir, name), { mode: 0o700 });
        for (const child of await readdir(from)) {
          if (await exists(path.join(to, child))) await step(path.join(to, child), path.join(oldDir, name, child));
          await step(path.join(from, child), path.join(to, child));
        }
      } else {
        if (await exists(to)) await step(to, path.join(oldDir, `${name}.replaced`));
        await step(from, to);
      }
      restored += 1;
    }
    return { restored, replaced, old: oldName };
  } catch (err) {
    for (const [from, to] of done.reverse()) await rename(to, from).catch(() => {});
    throw err;
  }
}

// ---- App installer ------------------------------------------------------

const PLACEHOLDER_MAX_BYTES = 8192;

// What is in a folder an app is about to go into. It counts as free when it
// is missing, empty, or holds only small placeholder files named in
// replaceable (the page a new site starts with).
async function inspectTarget({ home, path: rel, replaceable = [] }) {
  checkRelative(rel);
  if (!Array.isArray(replaceable) || !replaceable.every((n) => typeof n === 'string' && TOP_LEVEL_NAME.test(n))) {
    throw new FileError('INVALID_PARAMS', 'replaceable must list file names');
  }
  const { realHome, target } = await resolveEntry(home, rel);
  if (!(await exists(target))) return { path: rel, exists: false, free: true, blocking: [], placeholders: [] };
  const info = await lstat(target);
  if (info.isSymbolicLink() || !info.isDirectory()) return { path: rel, exists: true, free: false, blocking: [path.basename(rel)], placeholders: [] };
  const real = await realpath(target);
  if (!within(realHome, real)) throw new FileError('OUTSIDE_SITE', 'This path leads outside the site (through a symbolic link)');
  const blocking = [];
  const placeholders = [];
  for (const name of await readdir(real)) {
    const entry = await lstat(path.join(real, name));
    if (replaceable.includes(name) && entry.isFile() && entry.size <= PLACEHOLDER_MAX_BYTES) placeholders.push(name);
    else blocking.push(name);
  }
  return { path: rel, exists: true, free: blocking.length === 0, blocking: blocking.slice(0, 10), placeholders };
}

// Moves everything in `from` into `to` (created with its parents when
// missing). `to` must be free as inspectTarget says; its placeholder files
// are removed first. Returns the names moved, for undoing.
async function place({ home, from, to, replaceable = [] }) {
  checkRelative(from);
  const state = await inspectTarget({ home, path: to, replaceable });
  if (!state.free) throw new FileError('FOLDER_NOT_EMPTY', `${to} already has files in it (${state.blocking.join(', ')})`);
  const { realHome, real: source } = await resolveExisting(home, from);
  if (!(await stat(source)).isDirectory()) throw new FileError('NOT_A_DIRECTORY', `${from} is not a folder`);
  let current = realHome;
  let created = null;
  for (const part of to.split('/')) {
    current = path.join(current, part);
    try {
      await mkdir(current, { mode: 0o755 });
      created ??= path.relative(realHome, current);
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
    }
    const info = await lstat(current);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new FileError('NOT_A_DIRECTORY', `${path.relative(realHome, current)} is not a folder`);
  }
  for (const name of state.placeholders) await unlink(path.join(current, name));
  const moved = [];
  for (const name of await readdir(source)) {
    await rename(path.join(source, name), path.join(current, name));
    moved.push(name);
  }
  return { path: to, moved, created, replaced: state.placeholders };
}

// The server's self-check (0.39.0) starts the worker to see that it loads.
async function ping() {
  return { pong: true };
}

const ACTIONS = { list, read, readRange, chmod: changeMode, write, importFile, locate, mkdir: makeDirectory, rename: move, delete: remove, init, clear, appInit, tail, readlink: readLink, activate, restoreSwap, inspectTarget, place, ping };

const ERRNO = {
  ENOENT: ['FILE_NOT_FOUND', 'No such file or folder'],
  EACCES: ['FILE_PERMISSION_DENIED', 'The site user does not have permission for this'],
  EPERM: ['FILE_PERMISSION_DENIED', 'The site user does not have permission for this'],
  EEXIST: ['FILE_EXISTS', 'Something with this name already exists'],
  ENOTEMPTY: ['FOLDER_NOT_EMPTY', 'The folder is not empty'],
  ELOOP: ['IS_SYMLINK', 'This is a symbolic link; the file manager does not follow it here'],
  ENOTDIR: ['NOT_A_DIRECTORY', 'Part of this path is a file, not a folder'],
  EISDIR: ['NOT_A_FILE', 'This is a folder'],
  ENOSPC: ['DISK_FULL', 'The disk is full'],
  ENAMETOOLONG: ['INVALID_PATH', 'The name is too long'],
};

export async function performFileRequest(request) {
  const action = ACTIONS[request?.action];
  if (!action) return { error: { code: 'INVALID_PARAMS', message: 'Unknown file action' } };
  if (typeof request.home !== 'string' || !path.isAbsolute(request.home)) {
    return { error: { code: 'INVALID_PARAMS', message: 'home must be an absolute path' } };
  }
  try {
    return { result: await action(request) };
  } catch (err) {
    if (err instanceof FileError) return { error: { code: err.code, message: err.message } };
    const [code, message] = ERRNO[err.code] ?? ['FILE_OPERATION_FAILED', err.message];
    return { error: { code, message } };
  }
}

// Switches this process to the site user for good: groups, then gid, then
// uid (after which it cannot switch back). Refuses root and checks the
// switch took effect, so a request never runs with more rights than the
// site user has.
export function dropPrivileges(uidText, gidText, proc = process) {
  const uid = Number(uidText);
  const gid = Number(gidText);
  if (!Number.isInteger(uid) || !Number.isInteger(gid) || uid <= 0 || gid <= 0) {
    throw new FileError('NOT_ALLOWED', 'File requests never run as root');
  }
  proc.setgroups([gid]);
  proc.setgid(gid);
  proc.setuid(uid);
  if (proc.getuid() !== uid || proc.geteuid() !== uid || proc.getgid() !== gid || proc.getegid() !== gid) {
    throw new FileError('NOT_ALLOWED', 'Could not switch to the site user');
  }
}

async function main() {
  const as = process.argv.indexOf('--as');
  if (as !== -1) {
    try {
      dropPrivileges(process.argv[as + 1], process.argv[as + 2]);
    } catch (err) {
      process.stdout.write(JSON.stringify({ error: { code: err.code ?? 'NOT_ALLOWED', message: err.message } }));
      process.exitCode = 1;
      return;
    }
  }
  process.umask(0o022);
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  let request;
  try {
    request = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    process.stdout.write(JSON.stringify({ error: { code: 'INVALID_PARAMS', message: 'Malformed request' } }));
    return;
  }
  process.stdout.write(JSON.stringify(await performFileRequest(request)));
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await main();
}
