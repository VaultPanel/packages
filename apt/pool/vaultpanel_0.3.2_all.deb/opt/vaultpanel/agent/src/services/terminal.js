import { execFile, spawn } from 'node:child_process';
import { open, readFile, readlink } from 'node:fs/promises';
import { verifyEnvelopeSignature, signRequest } from '../security/signing.js';
import { AGENT_VERSION } from '../utils/version.js';
import { BANNER_FILE } from '../operations/loginBanner.js';

// The server terminal (0.11.0).
//
// This is not an operation: operations are allow-listed and checked, and a
// terminal is a root shell. It is its own channel, so the allow-list stays as
// it is. The agent keeps one WebSocket open to the panel; the panel asks for a
// session with an envelope signed by its key (as for jobs), the agent starts a
// login shell for root on a pseudo-terminal and passes bytes both ways.
// Setting "allowTerminal": false in the agent's config turns it off.

export const TERMINAL_PATH = '/api/v1/agent/terminal';
export const MAX_SESSIONS = 10;
const FLUSH_MS = 12;
const FLUSH_BYTES = 32 * 1024;
const SILENCE_MS = 90_000;
const SAFE_SHELL = /^\/[A-Za-z0-9._/-]+$/;
const FALLBACK_SHELLS = ['/bin/bash', '/bin/sh'];

// Checks a terminal envelope from the panel. Returns an error message or null.
export function checkTerminalEnvelope({ envelope, signature }, config, seen, now = Date.now()) {
  if (!envelope || typeof envelope !== 'object' || envelope.kind !== 'terminal') return 'Malformed terminal request';
  if (!verifyEnvelopeSignature(envelope, signature, config.panelPublicKey)) {
    return 'The terminal request is not signed by the panel this agent trusts';
  }
  if (envelope.serverId !== config.serverId) return 'The terminal request is for a different server';
  if (!(Date.parse(envelope.expiresAt) >= now)) return 'The terminal request expired';
  if (typeof envelope.sessionId !== 'string' || seen.has(envelope.sessionId)) return 'This terminal session was already opened';
  return null;
}

// The URL the agent connects to, with the request signature in the query
// (a WebSocket handshake cannot carry custom headers from Node's client).
export function terminalUrl({ panelUrl, agentId, privateKeyPem }) {
  const url = new URL(TERMINAL_PATH, panelUrl.replace(/\/+$/, '') + '/');
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  const headers = signRequest({ agentId, privateKeyPem, method: 'GET', path: TERMINAL_PATH, body: '' });
  url.searchParams.set('agentId', headers['X-VaultPanel-Agent-Id']);
  url.searchParams.set('timestamp', headers['X-VaultPanel-Timestamp']);
  url.searchParams.set('nonce', headers['X-VaultPanel-Nonce']);
  url.searchParams.set('signature', headers['X-VaultPanel-Signature']);
  return url.toString();
}

export const clampSize = (value, fallback, max) => {
  const n = Number(value);
  return Number.isInteger(n) && n >= 2 && n <= max ? n : fallback;
};

// Root's login shell from the password file, if it is a plain path.
export async function rootShell(passwdFile = '/etc/passwd') {
  try {
    const line = (await readFile(passwdFile, 'utf8')).split('\n').find((l) => l.startsWith('root:'));
    const shell = line?.split(':')[6]?.trim();
    if (shell && SAFE_SHELL.test(shell) && !/(?:nologin|false)$/.test(shell)) return shell;
  } catch {
    // fall through
  }
  return FALLBACK_SHELLS[0];
}

// The command that starts the shell. `script` (util-linux, on every Debian and
// Ubuntu) gives it a pseudo-terminal using only what is installed. The agent's
// service is sandboxed (ProtectHome=read-only, PrivateTmp), so when it runs in
// its own mount namespace the shell is started in the host's instead: the
// terminal sees the server as an SSH session would.
export function shellCommand({ shell, cols, rows, hostNamespace }) {
  if (!SAFE_SHELL.test(shell)) throw new Error('Unsafe shell path');
  // With the login message set to "VaultPanel only" (0.21.0), the banner
  // greets the Terminal too, as it does an SSH login.
  const inner = `stty rows ${rows} cols ${cols} 2>/dev/null; cd "$HOME" 2>/dev/null; cat ${BANNER_FILE} 2>/dev/null; exec ${shell} -l`;
  const script = ['script', '-q', '-f', '-e', '-c', inner, '/dev/null'];
  return hostNamespace ? ['nsenter', '--mount=/proc/1/ns/mnt', '--', ...script] : script;
}

// True when the agent runs in its own mount namespace and may enter the
// host's (root with the usual capabilities). Otherwise the shell starts where
// the agent runs, which still works, with the service's sandbox applied.
export async function needsHostNamespace() {
  try {
    const [own, host] = await Promise.all([readlink('/proc/self/ns/mnt'), readlink('/proc/1/ns/mnt')]);
    if (own === host) return false;
    await (await open('/proc/1/ns/mnt', 'r')).close();
    return true;
  } catch {
    return false;
  }
}

export function shellEnv(shell) {
  return {
    TERM: 'xterm-256color',
    COLORTERM: 'truecolor',
    HOME: '/root',
    USER: 'root',
    LOGNAME: 'root',
    SHELL: shell,
    PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
    LANG: process.env.LANG || 'C.UTF-8',
  };
}

// One shell on a pseudo-terminal. `emit` receives {type, ...} messages for
// the panel.
export async function openSession({ id, cols, rows, emit, config, spawnImpl = spawn, logger }) {
  const shell = await rootShell(config.passwdFile);
  const [cmd, ...args] = shellCommand({ shell, cols, rows, hostNamespace: config.terminalHostNamespace !== false && (await needsHostNamespace()) });
  const child = spawnImpl(cmd, args, { cwd: '/', env: shellEnv(shell), stdio: ['pipe', 'pipe', 'pipe'] });

  let pending = [];
  let pendingBytes = 0;
  let timer = null;
  let exited = false;
  let shellTty = null;
  const flush = () => {
    clearTimeout(timer);
    timer = null;
    if (!pendingBytes) return;
    const data = Buffer.concat(pending).toString('base64');
    pending = [];
    pendingBytes = 0;
    emit({ type: 'data', session: id, data });
  };
  const onOutput = (chunk) => {
    pending.push(chunk);
    pendingBytes += chunk.length;
    if (pendingBytes >= FLUSH_BYTES) flush();
    else timer ??= setTimeout(flush, FLUSH_MS);
  };
  child.stdout.on('data', onOutput);
  child.stderr.on('data', onOutput);
  child.stdin.on('error', () => {});

  const done = new Promise((resolve) => {
    child.on('error', (err) => {
      if (exited) return;
      exited = true;
      flush();
      const message = err.code === 'ENOENT' ? `The terminal needs the ${cmd} command (util-linux) on this server` : err.message;
      emit({ type: 'exit', session: id, code: null, message });
      resolve();
    });
    child.on('close', (code, signal) => {
      if (exited) return;
      exited = true;
      flush();
      emit({ type: 'exit', session: id, code, signal });
      resolve();
    });
  });

  // The shell is the child of `script`; its terminal device is what a
  // resize has to change (the kernel then tells the shell with SIGWINCH).
  async function findShell() {
    if (shellTty) return shellTty;
    const children = (await readFile(`/proc/${child.pid}/task/${child.pid}/children`, 'utf8')).trim().split(/\s+/).filter(Boolean);
    for (const pid of children) {
      const tty = await readlink(`/proc/${pid}/fd/0`).catch(() => null);
      if (tty?.startsWith('/dev/pts/')) {
        shellTty = { pid: Number(pid), tty };
        return shellTty;
      }
    }
    return null;
  }

  return {
    id,
    done,
    write(data) {
      if (!exited && typeof data === 'string' && data.length) child.stdin.write(Buffer.from(data, 'utf8'));
    },
    async resize(newCols, newRows) {
      const c = clampSize(newCols, null, 1000);
      const r = clampSize(newRows, null, 500);
      if (exited || !c || !r) return;
      const target = await findShell().catch(() => null);
      if (!target) return;
      await new Promise((resolve) => execFile('stty', ['-F', target.tty, 'rows', String(r), 'cols', String(c)], { timeout: 5000 }, () => resolve()));
    },
    pause: () => child.stdout.pause(),
    resume: () => child.stdout.resume(),
    async close() {
      if (exited) return;
      const target = await findShell().catch(() => null);
      try {
        if (target) process.kill(target.pid, 'SIGHUP');
        child.kill('SIGTERM');
      } catch (err) {
        logger?.debug?.('terminal close', { err });
      }
      const kill = setTimeout(() => !exited && child.kill('SIGKILL'), 3000);
      await done;
      clearTimeout(kill);
    },
  };
}

// Keeps the terminal connection to the panel open and runs the sessions the
// panel asks for. Returns { stop }.
export function startTerminalLink(config, logger, { privateKeyPem, WebSocketImpl = globalThis.WebSocket, openShell = openSession } = {}) {
  const enabled = config.allowTerminal !== false;
  if (!WebSocketImpl) {
    logger.warn('the server terminal needs Node.js 22 or later for the agent; it is not available on this server');
    return { stop() {} };
  }
  const sessions = new Map();
  // Sessions the panel closed while they were still opening.
  const closedEarly = new Set();
  const seen = new Set();
  let stopped = false;
  let socket = null;
  let backoff = 500;

  const closeAll = () => {
    for (const session of sessions.values()) session.close();
    sessions.clear();
  };

  function connect() {
    if (stopped) return;
    let openedAt = null;
    let silence = null;
    const ws = new WebSocketImpl(terminalUrl({ panelUrl: config.panelUrl, agentId: config.agentId, privateKeyPem }));
    socket = ws;
    const send = (msg) => {
      if (ws.readyState === 1) ws.send(JSON.stringify(msg));
    };
    const heard = () => {
      clearTimeout(silence);
      // The panel pings every 30 seconds; silence means the link is gone.
      silence = setTimeout(() => ws.close(), SILENCE_MS);
    };

    ws.addEventListener('open', () => {
      openedAt = Date.now();
      heard();
      send({ type: 'hello', version: AGENT_VERSION, enabled, reason: enabled ? null : 'The terminal is turned off in this server\'s agent settings (allowTerminal)' });
    });
    ws.addEventListener('message', (event) => {
      heard();
      let msg;
      try {
        msg = JSON.parse(typeof event.data === 'string' ? event.data : '');
      } catch {
        return;
      }
      handle(msg, send).catch((err) => logger.warn('terminal message failed', { err }));
    });
    // Node's WebSocket reports a failed connection with "error" and no
    // "close", so either one ends this attempt (once).
    let ended = false;
    const onEnd = () => {
      if (ended) return;
      ended = true;
      clearTimeout(silence);
      closeAll();
      try {
        ws.close();
      } catch {
        // already closed
      }
      if (stopped) return;
      // A link that stayed up a while reconnects at once; repeated failures back off.
      backoff = openedAt && Date.now() - openedAt > 30_000 ? 1000 : Math.min(backoff * 2, 30_000);
      logger.debug('terminal link closed; reconnecting', { inMs: backoff });
      setTimeout(connect, backoff);
    };
    ws.addEventListener('error', onEnd);
    ws.addEventListener('close', onEnd);
  }

  async function handle(msg, send) {
    if (msg.type === 'ping') return send({ type: 'pong' });
    const session = sessions.get(msg.session);
    if (msg.type === 'open') {
      const id = msg.envelope?.sessionId;
      const rejection = enabled ? checkTerminalEnvelope(msg, config, seen) : 'The terminal is turned off on this server';
      if (!rejection && sessions.size >= MAX_SESSIONS) return send({ type: 'exit', session: id, code: null, message: 'Too many terminals are open on this server' });
      if (rejection) {
        logger.warn('rejected terminal session', { sessionId: id, reason: rejection });
        return send({ type: 'exit', session: id, code: null, message: rejection });
      }
      seen.add(id);
      const { envelope } = msg;
      logger.info('terminal session opened', { sessionId: id, requestedBy: envelope.requestedBy });
      let opened;
      try {
        // The root helper checks the envelope again before it opens a shell (0.36.0).
        opened = await openShell({
          id,
          cols: clampSize(envelope.cols, 80, 1000),
          rows: clampSize(envelope.rows, 24, 500),
          emit: send,
          config,
          logger,
          envelope,
          signature: msg.signature,
        });
      } catch (err) {
        closedEarly.delete(id);
        logger.warn('could not open a terminal', { sessionId: id, err });
        return send({ type: 'exit', session: id, code: null, message: err.message });
      }
      sessions.set(id, opened);
      send({ type: 'opened', session: id });
      if (closedEarly.delete(id)) opened.close();
      opened.done.then(() => {
        sessions.delete(id);
        logger.info('terminal session ended', { sessionId: id });
      });
      return;
    }
    if (!session) {
      if (msg.type === 'close' && seen.has(msg.session)) closedEarly.add(msg.session);
      return;
    }
    if (msg.type === 'input') session.write(msg.data);
    else if (msg.type === 'resize') await session.resize(msg.cols, msg.rows);
    else if (msg.type === 'pause') session.pause();
    else if (msg.type === 'resume') session.resume();
    else if (msg.type === 'close') await session.close();
  }

  connect();
  return {
    stop() {
      stopped = true;
      closeAll();
      socket?.close();
    },
  };
}
