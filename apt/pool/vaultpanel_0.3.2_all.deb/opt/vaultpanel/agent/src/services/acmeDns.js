import { Resolver } from 'node:dns/promises';
import { mkdir, readFile, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { saveSecretFile } from '../config.js';
import { detectDns, dnsPaths, findBinary } from '../monitoring/web.js';
import { OperationError } from '../operations/errors.js';
import { writeFileAtomic } from '../operations/sites.js';
import { DOMAIN_PATTERN, SITE_NAME_PATTERN } from '../security/webRules.js';
import { checkDnsProvider, dnsProviderFor } from './dnsProviders.js';

// Wildcard certificates need Let's Encrypt's DNS check: a TXT record named
// _acme-challenge.<domain> holding a value Certbot is given. Certbot runs
// the hook below (vaultpanel-agent acme-dns-hook auth|cleanup) for each name;
// the hook adds the record to the zone this server serves for the domain
// (DNS zones in the panel), reloads BIND and waits until BIND answers with
// it, and removes it again afterwards.
//
// The record goes into the zone file without changing its serial. BIND loads
// a primary zone again when its file changes, and the panel's next zone
// update (same or higher serial) replaces the file as usual; a higher serial
// here would make the agent keep this file and skip the panel's changes.
//
// A domain whose DNS is elsewhere (0.38.0) is checked through its provider's
// API instead (dnsProviders.js). Certbot then runs the hook with the
// certificate's name (acme-dns-hook auth vp-<site>), and the provider's
// credentials wait for it, and for each renewal, in <acmeDnsDir>/vp-<site>.json,
// readable by root only.

const CLI_PATH = fileURLToPath(new URL('../cli.js', import.meta.url));
const SAFE_PATH = /^\/[A-Za-z0-9._/+-]+$/;
const VALUE_PATTERN = /^[A-Za-z0-9_-]{1,128}$/;
const MARK = '; vaultpanel-acme';
export const DEFAULT_ACME_HOOK = '/usr/local/lib/vaultpanel/acme-dns-hook';

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function acmeHookPath(policy) {
  return policy.acmeHookPath ?? DEFAULT_ACME_HOOK;
}

// The script Certbot runs. Written again before every wildcard request, so
// it follows the agent when Node.js or the agent moves.
export function renderAcmeHook({ nodePath = process.execPath, cliPath = CLI_PATH, configPath = null } = {}) {
  for (const p of [nodePath, cliPath, configPath].filter(Boolean)) {
    if (!SAFE_PATH.test(p)) throw new OperationError('ACME_HOOK_PATH_UNSAFE', `The agent's path ${p} has characters a shell could misread`);
  }
  const config = configPath ? ` --config '${configPath}'` : '';
  return `#!/bin/sh\n# Installed by VaultPanel: adds and removes Let's Encrypt DNS checks, in the zones on this server or at a DNS provider.\nexec '${nodePath}' '${cliPath}' acme-dns-hook "$@"${config}\n`;
}

// ---- Credentials of DNS providers ------------------------------------------

export const DEFAULT_ACME_DNS_DIR = '/etc/vaultpanel-agent/acme-dns';

function credentialsFile(policy, certName) {
  if (typeof certName !== 'string' || !certName.startsWith('vp-') || !SITE_NAME_PATTERN.test(certName.slice(3))) throw invalid('The certificate name must be vp-<site>');
  return path.join(policy.acmeDnsDir ?? DEFAULT_ACME_DNS_DIR, `${certName}.json`);
}

// The provider a certificate is checked through, or null for this server's zones.
export async function readProviderCredentials(policy, certName) {
  const text = await readFile(credentialsFile(policy, certName), 'utf8').catch(() => null);
  return text === null ? null : checkDnsProvider(JSON.parse(text));
}

// Puts the provider's credentials where the hook finds them. Returns how to
// put back what was there, for when Certbot fails: the certificate in place
// then keeps renewing as it did.
export async function stageProviderCredentials(policy, certName, provider) {
  const file = credentialsFile(policy, certName);
  const previous = await readFile(file, 'utf8').catch(() => null);
  await saveSecretFile(file, `${JSON.stringify(checkDnsProvider(provider), null, 2)}\n`);
  return {
    async restore() {
      if (previous === null) await rm(file, { force: true });
      else await saveSecretFile(file, previous);
    },
  };
}

export async function removeProviderCredentials(policy, certName) {
  await rm(credentialsFile(policy, certName), { force: true });
}

// Waits until the name servers of the record's zone answer with it, since
// Let's Encrypt asks them. Gives up after a while without failing: Let's
// Encrypt may still find it, and says so when it does not.
export async function waitPublished(name, value, { timeoutMs = 240_000, intervalMs = 10_000, lookup = authoritativeTxt } = {}) {
  const until = Date.now() + timeoutMs;
  for (;;) {
    const answers = await lookup(name).catch(() => null);
    if (answers?.includes(value)) return true;
    if (Date.now() >= until) return false;
    await sleep(intervalMs);
  }
}

// The TXT values of a name, asked of its zone's own name servers.
async function authoritativeTxt(name) {
  const system = new Resolver({ timeout: 5000, tries: 2 });
  const labels = name.split('.');
  let servers = null;
  for (let i = 1; i < labels.length - 1 && !servers; i += 1) {
    const ns = await system.resolveNs(labels.slice(i).join('.')).catch(() => null);
    if (ns?.length) servers = ns;
  }
  if (!servers) return null;
  const addresses = (await Promise.all(servers.slice(0, 4).map((host) => system.resolve4(host).catch(() => [])))).flat();
  if (!addresses.length) return null;
  const direct = new Resolver({ timeout: 5000, tries: 2 });
  direct.setServers(addresses.slice(0, 4));
  return (await direct.resolveTxt(name)).map((parts) => parts.join(''));
}

export async function ensureAcmeHook(ctx) {
  const hook = acmeHookPath(ctx.policy);
  const text = renderAcmeHook({ configPath: ctx.policy.configPath ?? null });
  const current = await readFile(hook, 'utf8').catch(() => null);
  if (current !== text) await writeFileAtomic(hook, text, 0o755);
  return hook;
}

// Each zone on this server that could hold the record, most specific first.
function candidateZones(domain) {
  const labels = domain.split('.');
  const out = [];
  for (let i = 0; i < labels.length - 1; i += 1) out.push(labels.slice(i).join('.'));
  return out;
}

export async function findZone(policy, domain) {
  const paths = dnsPaths(policy);
  for (const zone of candidateZones(domain)) {
    if (await stat(paths.zoneFile(zone)).then((s) => s.isFile(), () => false)) return { zone, file: paths.zoneFile(zone) };
  }
  return null;
}

// The name a wildcard certificate is for must be in a zone this server
// serves (the zone itself or a parent zone).
export async function requireAcmeZone(ctx, zone) {
  if (ctx.policy.allowDns === false) throw new OperationError('NOT_ALLOWED', 'DNS zones are disabled in this agent config');
  const state = await detectDns(ctx.policy, ctx.binDirs);
  if (!state.installed || !state.configured) {
    throw new OperationError('DNS_NOT_SET_UP', 'Wildcard certificates use this server\'s DNS server, which is not set up. Set it up on the DNS Zones page and add the zone first.');
  }
  const found = await findZone(ctx.policy, zone);
  if (!found) {
    throw new OperationError('DNS_ZONE_MISSING', `There is no DNS zone for ${zone} on this server. Add it on the DNS Zones page (on this server) and point the domain's name servers at it first.`);
  }
  return found;
}

// One change to a zone file at a time (two names are checked for every
// wildcard certificate, and Certbot may run them back to back).
async function withLock(file, fn) {
  const lock = `${file}.vp-acme-lock`;
  for (let i = 0; ; i += 1) {
    try {
      await mkdir(lock);
      break;
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
      const age = await stat(lock).then((s) => Date.now() - s.mtimeMs, () => 0);
      if (age > 5 * 60_000) await rm(lock, { recursive: true, force: true });
      else if (i > 120) throw new OperationError('DNS_ZONE_BUSY', `${path.basename(file)} is being changed by something else`);
      else await sleep(500);
    }
  }
  try {
    return await fn();
  } finally {
    await rm(lock, { recursive: true, force: true });
  }
}

function checkInput(domain, value) {
  if (typeof domain !== 'string' || !DOMAIN_PATTERN.test(domain)) throw invalid('CERTBOT_DOMAIN must be a domain name');
  if (typeof value !== 'string' || !VALUE_PATTERN.test(value)) throw invalid('CERTBOT_VALIDATION is not a Let\'s Encrypt check value');
}

const recordLine = (domain, value) => `_acme-challenge.${domain}.\t60\tIN\tTXT\t"${value}" ${MARK}`;

async function checkAndWrite(ctx, zone, file, text) {
  if (await findBinary('named-checkzone', ctx.binDirs)) {
    const draft = `${file}.vp-check`;
    await writeFileAtomic(draft, text);
    const check = await ctx.run('named-checkzone', ['-k', 'fail', '-i', 'local', zone, draft], { timeoutMs: 30_000 });
    await rm(draft, { force: true });
    if (check.timedOut || check.error || check.exitCode !== 0) {
      throw new OperationError('DNS_ZONE_INVALID', `BIND refused the zone with the check record: ${String(check.stdout || check.stderr || '').trim().split('\n').slice(-3).join(' ')}`);
    }
  }
  await writeFileAtomic(file, text);
  const reload = await ctx.run('systemctl', ['reload', 'named.service'], { timeoutMs: 60_000 });
  if (reload.timedOut || reload.error || reload.exitCode !== 0) {
    throw new OperationError('COMMAND_FAILED', `systemctl reload named failed: ${String(reload.stderr || reload.error || '').trim().slice(0, 300)}`);
  }
}

// Waits until this server's BIND answers with the value.
async function waitServed(ctx, domain, value, tries) {
  if (!(await findBinary('dig', ctx.binDirs))) return null;
  for (let i = 0; i < tries; i += 1) {
    const result = await ctx.run('dig', ['+short', '+norecurse', '+time=2', '+tries=1', '@127.0.0.1', `_acme-challenge.${domain}`, 'TXT'], { timeoutMs: 10_000 });
    if (String(result.stdout ?? '').includes(`"${value}"`)) return true;
    await sleep(ctx.retryDelayMs ?? 1000);
  }
  return false;
}

// With the certificate's name, its DNS provider when it has one.
async function providerClient(ctx, certName) {
  const provider = certName ? await readProviderCredentials(ctx.policy, certName) : null;
  return provider ? (ctx.dnsProviderFor ?? dnsProviderFor)(provider) : null;
}

export async function addChallenge(ctx, domain, value, { tries = 30, certName = null } = {}) {
  checkInput(domain, value);
  const client = await providerClient(ctx, certName);
  if (client) {
    const name = `_acme-challenge.${domain}`;
    const { zone } = await client.add(name, value);
    const served = await (ctx.waitPublished ?? waitPublished)(name, value);
    return { zone, provider: client.label, served };
  }
  const found = await findZone(ctx.policy, domain);
  if (!found) throw new OperationError('DNS_ZONE_MISSING', `No DNS zone on this server covers ${domain}`);
  await withLock(found.file, async () => {
    const text = await readFile(found.file, 'utf8');
    const line = recordLine(domain, value);
    if (text.split('\n').includes(line)) return;
    await checkAndWrite(ctx, found.zone, found.file, `${text.replace(/\n*$/, '\n')}${line}\n`);
  });
  const served = await waitServed(ctx, domain, value, tries);
  if (served === false) throw new OperationError('DNS_ZONE_NOT_LOADED', `BIND on this server does not answer with the check record for ${domain}`);
  return { zone: found.zone, served };
}

export async function removeChallenge(ctx, domain, value, { certName = null } = {}) {
  checkInput(domain, value);
  const client = await providerClient(ctx, certName);
  if (client) return { removed: (await client.remove(`_acme-challenge.${domain}`, value)).removed > 0, provider: client.label };
  const found = await findZone(ctx.policy, domain);
  if (!found) return { removed: false };
  return withLock(found.file, async () => {
    const text = await readFile(found.file, 'utf8');
    const line = recordLine(domain, value);
    const lines = text.split('\n');
    if (!lines.includes(line)) return { removed: false };
    await checkAndWrite(ctx, found.zone, found.file, lines.filter((l) => l !== line).join('\n'));
    return { removed: true, zone: found.zone };
  });
}
