import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { OperationError } from '../operations/errors.js';
import { performFileRequest } from './fileWorker.js';

const WORKER = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fileWorker.js');
const MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
const HOME_FOLDER = /^\/(root|home)(\/|$)/;

// How to start the worker as the site user. Normally the kernel starts it
// with the site's uid and gid. When Node.js or the agent lives in a home
// folder (nvm installs Node.js in /root/.nvm), the site user cannot even
// reach the binary, so the worker starts as root and drops to the site
// user itself before it reads the request (see fileWorker.js).
export function workerLaunch(account, { execPath = process.execPath, worker = WORKER } = {}) {
  if (HOME_FOLDER.test(execPath) || HOME_FOLDER.test(worker)) {
    return { args: [worker, '--as', String(account.uid), String(account.gid)], ids: {} };
  }
  return { args: [worker], ids: { uid: account.uid, gid: account.gid } };
}

// Finds a local account in /etc/passwd. Returns null if it does not exist.
export async function lookupUser(name, passwdFile = '/etc/passwd') {
  const text = await readFile(passwdFile, 'utf8');
  for (const line of text.split('\n')) {
    const [user, , uid, gid, , home, shell] = line.split(':');
    if (user === name) return { name: user, uid: Number(uid), gid: Number(gid), home, shell };
  }
  return null;
}

// Runs a fileWorker request as the given account (uid/gid), in a separate
// Node.js process with an empty environment. Throws an OperationError with
// the worker's error code when the request fails.
export function runAsSiteUser(account, request, { timeoutMs = 60_000 } = {}) {
  if (!account || !Number.isInteger(account.uid) || account.uid === 0) {
    return Promise.reject(new OperationError('NOT_ALLOWED', 'File requests never run as root'));
  }
  return new Promise((resolve, reject) => {
    const launch = workerLaunch(account);
    const child = spawn(process.execPath, launch.args, {
      ...launch.ids,
      cwd: '/',
      env: { PATH: '/usr/bin:/bin', LANG: 'C.UTF-8', HOME: account.home },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let size = 0;
    const timer = setTimeout(() => child.kill('SIGKILL'), timeoutMs);
    child.stdout.on('data', (chunk) => {
      size += chunk.length;
      if (size <= MAX_RESPONSE_BYTES) stdout += chunk.toString('utf8');
    });
    child.stderr.on('data', (chunk) => {
      if (stderr.length < 4000) stderr += chunk.toString('utf8');
    });
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(new OperationError('COMMAND_FAILED', `Could not start the file worker: ${err.message}`));
    });
    child.on('close', (code, signal) => {
      clearTimeout(timer);
      if (signal) return reject(new OperationError('TIMEOUT', 'The file request did not finish in time'));
      let reply;
      try {
        reply = JSON.parse(stdout);
      } catch {
        return reject(new OperationError('COMMAND_FAILED', `The file worker failed (exit ${code}): ${stderr.trim().slice(0, 500)}`));
      }
      settle(reply, resolve, reject);
    });
    child.stdin.end(JSON.stringify(request));
  });
}

// The same request in this process, without changing user. Used by tests.
export async function runInProcess(_account, request) {
  return new Promise((resolve, reject) => {
    performFileRequest(request).then((reply) => settle(reply, resolve, reject), reject);
  });
}

function settle(reply, resolve, reject) {
  if (reply.error) reject(new OperationError(reply.error.code, reply.error.message));
  else resolve(reply.result);
}
