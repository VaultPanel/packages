import { randomUUID } from 'node:crypto';
import { mkdir, open, readdir, readFile, realpath, rm, stat, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { parseCommands } from '../security/appRules.js';
import { CRON_OUTPUT_MAX_BYTES } from '../security/automationRules.js';
import { runCommand } from '../utils/exec.js';
import { appSearchPath, parseEnvFile } from './appConfig.js';
import { lookupUser, runAsSiteUser } from './siteFiles.js';
import { appNodeDir } from '../monitoring/web.js';

// Runs one cron job: the commands saved for it, one after another without a
// shell, as the site's or app's own user, in its home folder. Used by cron
// itself (`vaultpanel-agent cron-run <id>`, see cron.js for the crontab) and by
// "Run now" in the panel. A run that would overlap the previous one is
// skipped. The result (exit code, duration, the end of the output) is kept
// until the agent has reported it to the panel.

export function cronPaths(policy, id) {
  return {
    spec: path.join(policy.cronSpecDir, `${id}.json`),
    lock: path.join(policy.cronStateDir, `${id}.lock`),
    pending: path.join(policy.cronStateDir, 'pending'),
  };
}

export async function readCronSpec(policy, id) {
  try {
    return JSON.parse(await readFile(cronPaths(policy, id).spec, 'utf8'));
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
}

function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM';
  }
}

// An exclusive lock file holding the running process's pid. A lock left by
// a process that no longer exists is taken over.
// The cron folder is private, but its parent (/var/lib/vaultpanel) is shared
// with the Let's Encrypt challenge folder NGINX must reach, so it is created
// 0755 first: mkdir -p would otherwise give it the same 0700.
async function makePrivateDir(dir) {
  await mkdir(path.dirname(dir), { recursive: true, mode: 0o755 });
  await mkdir(dir, { recursive: true, mode: 0o700 });
}

async function acquireLock(file) {
  await makePrivateDir(path.dirname(file));
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const handle = await open(file, 'wx', 0o600);
      await handle.writeFile(String(process.pid));
      await handle.close();
      return true;
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
      const pid = Number((await readFile(file, 'utf8').catch(() => '')).trim());
      if (Number.isInteger(pid) && pid > 0 && pid !== process.pid && isAlive(pid)) return false;
      await unlink(file).catch(() => {});
    }
  }
  return false;
}

// Keeps the last `max` bytes of what a run prints.
function outputTail(max) {
  let text = '';
  let truncated = false;
  return {
    add(line) {
      text += `${line}\n`;
      if (text.length > max) {
        text = text.slice(text.length - max);
        truncated = true;
      }
    },
    result: () => ({ output: text, outputTruncated: truncated }),
  };
}

async function workingDirectory(home, rel) {
  const realHome = await realpath(home);
  if (!rel) return realHome;
  let real;
  try {
    real = await realpath(path.join(realHome, rel));
  } catch {
    throw Object.assign(new Error(`The folder ${rel} does not exist in ${home}`), { code: 'CRON_DIR_MISSING' });
  }
  if (real !== realHome && !real.startsWith(realHome + path.sep)) {
    throw Object.assign(new Error(`${rel} leads outside ${home}`), { code: 'CRON_DIR_MISSING' });
  }
  if (!(await stat(real)).isDirectory()) throw Object.assign(new Error(`${rel} is not a folder`), { code: 'CRON_DIR_MISSING' });
  return real;
}

// Runs a saved job. deps lets tests replace the user lookup, the command
// runner and the file worker. Returns the run record.
export async function runCron(spec, { policy, trigger = 'schedule', onLine, timeoutMs, deps = {} }) {
  const run = deps.run ?? runCommand;
  const lookup = deps.lookupUser ?? ((name) => lookupUser(name, policy.passwdFile));
  const asUser = deps.runAsSiteUser ?? runAsSiteUser;
  const startedAt = new Date();
  const record = (status, extra = {}) => {
    const finishedAt = new Date();
    return {
      runKey: randomUUID(),
      cronId: spec.id,
      trigger,
      status,
      exitCode: null,
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: finishedAt - startedAt,
      output: '',
      outputTruncated: false,
      ...extra,
    };
  };
  const tail = outputTail(CRON_OUTPUT_MAX_BYTES);
  const note = (stream, line) => {
    tail.add(line);
    onLine?.(stream, line);
  };

  const account = await lookup(spec.user);
  const home = path.join(policy.sitesRoot, spec.user);
  if (!account || account.uid === 0 || account.home !== home) {
    note('stderr', `The site or app user ${spec.user} does not exist on this server`);
    return record('failed', tail.result());
  }
  const { lock } = cronPaths(policy, spec.id);
  if (!(await acquireLock(lock))) {
    note('stderr', 'The previous run is still going, so this one was skipped');
    return record('skipped', tail.result());
  }
  try {
    const parsed = parseCommands(spec.commands);
    if (parsed.error) {
      note('stderr', parsed.error);
      return record('failed', tail.result());
    }
    let cwd;
    try {
      cwd = await workingDirectory(home, spec.workingDir);
    } catch (err) {
      note('stderr', err.message);
      return record('failed', tail.result());
    }
    const nodeBinDir = appNodeDir(policy) ?? path.dirname(process.execPath);
    const isApp = await stat(path.join(home, 'releases')).then((s) => s.isDirectory(), () => false);
    let env = {};
    if (spec.appEnv && isApp) {
      try {
        const file = await asUser(account, { action: 'read', home, path: 'shared/.env' }, { timeoutMs: 30_000 });
        env = parseEnvFile(file.content);
      } catch (err) {
        note('stderr', `Could not read the app's .env (${err.message}); running without it`);
      }
    }
    env = {
      ...env,
      HOME: home,
      USER: spec.user,
      LOGNAME: spec.user,
      LANG: env.LANG ?? 'C.UTF-8',
      PATH: isApp ? appSearchPath(path.join(home, 'current'), nodeBinDir) : ['/usr/local/bin', '/usr/bin', '/bin', nodeBinDir].join(':'),
    };

    const limit = Math.min(timeoutMs ?? Infinity, spec.timeoutSeconds * 1000);
    const deadline = Date.now() + limit;
    for (const argv of parsed.commands) {
      note('stdout', `$ ${argv.join(' ')}`);
      const result = await run(argv[0], argv.slice(1), {
        uid: account.uid,
        gid: account.gid,
        cwd,
        env,
        timeoutMs: Math.max(1000, deadline - Date.now()),
        onLine: note,
        maxOutputBytes: 64 * 1024,
      });
      if (result.timedOut) {
        note('stderr', `Stopped after ${Math.round(limit / 1000)} seconds`);
        return record('timed_out', tail.result());
      }
      if (result.error) {
        note('stderr', result.error.code === 'ENOENT' ? `${argv[0]}: command not found` : result.error.message);
        return record('failed', { exitCode: 127, ...tail.result() });
      }
      if (result.exitCode !== 0) {
        note('stderr', `Exited with code ${result.exitCode ?? result.signal}`);
        return record('failed', { exitCode: result.exitCode, ...tail.result() });
      }
    }
    return record('succeeded', { exitCode: 0, ...tail.result() });
  } finally {
    await rm(lock, { force: true });
  }
}

// ---- Results waiting to be reported ----------------------------------------

export async function savePendingRun(policy, run) {
  const dir = cronPaths(policy, run.cronId).pending;
  await makePrivateDir(policy.cronStateDir);
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await writeFile(path.join(dir, `${Date.parse(run.finishedAt)}-${run.runKey}.json`), JSON.stringify(run), { mode: 0o600 });
}

// Up to `limit` saved runs, oldest first, with a remove() for each batch.
export async function readPendingRuns(policy, limit = 50) {
  const dir = path.join(policy.cronStateDir, 'pending');
  let names;
  try {
    names = (await readdir(dir)).filter((n) => /^[0-9]+-[0-9a-f-]{36}\.json$/.test(n)).sort();
  } catch {
    return { runs: [], remove: async () => {} };
  }
  const picked = names.slice(0, limit);
  const runs = [];
  for (const name of picked) {
    try {
      runs.push(JSON.parse(await readFile(path.join(dir, name), 'utf8')));
    } catch {
      await unlink(path.join(dir, name)).catch(() => {});
    }
  }
  return { runs, remove: () => Promise.all(picked.map((name) => unlink(path.join(dir, name)).catch(() => {}))) };
}
