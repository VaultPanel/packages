import path from 'node:path';
import { OperationError } from '../operations/errors.js';
import {
  DOCUMENT_ROOT_PATTERN,
  isWildcardDomain,
  MAX_SITE_DOMAINS,
  PHP_VERSION_PATTERN,
  RESERVED_SITE_NAMES,
  customNginxProblem,
  SITE_DOMAIN_PATTERN,
  SITE_NAME_PATTERN,
  SITE_TYPES,
} from '../security/webRules.js';

// Turns website parameters from the panel into a checked site definition,
// and renders the NGINX and PHP-FPM files for it. Configuration is always
// generated here from these checked fields. The one exception is a site's
// custom NGINX rules, which go in as text only after customNginxProblem
// accepts every directive in them.

export const SITE_SPEC_KEYS = ['name', 'type', 'domains', 'documentRoot', 'phpVersion', 'proxyPort', 'enabled', 'ssl', 'forceHttps', 'customNginx', 'htaccess', 'spa'];

const invalid = (message) => new OperationError('INVALID_PARAMS', message);

export function checkSiteName(name) {
  if (typeof name !== 'string' || !SITE_NAME_PATTERN.test(name)) throw invalid('name must be a valid site name');
  if (RESERVED_SITE_NAMES.has(name)) throw new OperationError('NOT_ALLOWED', `"${name}" is a reserved system name`);
  return name;
}

export function checkPhpVersion(version) {
  if (typeof version !== 'string' || !PHP_VERSION_PATTERN.test(version)) throw invalid('phpVersion must be a PHP version such as 8.3');
  return version;
}

export function checkSiteSpec(params) {
  const name = checkSiteName(params.name);
  if (!SITE_TYPES.includes(params.type)) throw invalid(`type must be one of ${SITE_TYPES.join(', ')}`);
  const { domains } = params;
  if (!Array.isArray(domains) || domains.length < 1 || domains.length > MAX_SITE_DOMAINS) {
    throw invalid(`domains must list 1 to ${MAX_SITE_DOMAINS} domains`);
  }
  for (const domain of domains) {
    if (typeof domain !== 'string' || !SITE_DOMAIN_PATTERN.test(domain)) throw invalid(`"${String(domain).slice(0, 80)}" is not a valid domain`);
  }
  if (new Set(domains).size !== domains.length) throw invalid('domains must be unique');
  const documentRoot = params.documentRoot ?? 'public';
  if (typeof documentRoot !== 'string' || !DOCUMENT_ROOT_PATTERN.test(documentRoot)) throw invalid('documentRoot must be a folder inside the site');
  const spec = {
    name,
    type: params.type,
    domains: [...domains],
    documentRoot,
    phpVersion: null,
    proxyPort: null,
    enabled: params.enabled ?? true,
    ssl: params.ssl ?? false,
    forceHttps: params.forceHttps ?? false,
  };
  if (params.customNginx !== undefined && params.customNginx !== null) {
    const problem = customNginxProblem(params.customNginx);
    if (problem) throw invalid(`customNginx: ${problem}`);
    if (params.customNginx.trim()) spec.customNginx = params.customNginx.trim();
  }
  if (params.htaccess !== undefined && typeof params.htaccess !== 'boolean') throw invalid('htaccess must be true or false');
  if (params.htaccess) {
    if (spec.type === 'proxy') throw invalid('A reverse proxy site cannot use .htaccess files');
    spec.htaccess = true;
  }
  // A single-page app (React, Vue...): paths with no file get index.html.
  if (params.spa !== undefined && typeof params.spa !== 'boolean') throw invalid('spa must be true or false');
  if (params.spa) {
    if (spec.type !== 'static') throw invalid('Only static sites can be single-page apps');
    if (spec.htaccess) throw invalid('A single-page app cannot also use .htaccess files; add the fallback to .htaccess instead');
    spec.spa = true;
  }
  for (const flag of ['enabled', 'ssl', 'forceHttps']) {
    if (typeof spec[flag] !== 'boolean') throw invalid(`${flag} must be true or false`);
  }
  if (spec.type === 'php') spec.phpVersion = checkPhpVersion(params.phpVersion);
  if (spec.type === 'proxy') {
    if (!Number.isInteger(params.proxyPort) || params.proxyPort < 1 || params.proxyPort > 65535) throw invalid('proxyPort must be a port from 1 to 65535');
    spec.proxyPort = params.proxyPort;
  }
  return spec;
}

// A name requests for the site can use: the first domain that is not a
// wildcard, or a name under the wildcard (health checks).
export function siteHost(domains) {
  return domains.find((d) => !isWildcardDomain(d)) ?? `vaultpanel-check${domains[0].slice(1)}`;
}

// Every path a site uses on the server, from the agent config.
export function sitePaths(policy, name) {
  const home = path.join(policy.sitesRoot, name);
  return {
    home,
    tmp: path.join(home, 'tmp'),
    logs: path.join(home, 'logs'),
    nginxAvailable: path.join(policy.nginxSitesAvailable, `${name}.conf`),
    nginxEnabled: path.join(policy.nginxSitesEnabled, `${name}.conf`),
    accessLog: path.join(policy.nginxLogDir, `vp-${name}.access.log`),
    errorLog: path.join(policy.nginxLogDir, `vp-${name}.error.log`),
    phpSocket: path.join(policy.phpRunDir, `vp-${name}.sock`),
    phpPool: (version) => path.join(policy.phpConfRoot, version, 'fpm', 'pool.d', `${name}.conf`),
    apacheAvailable: path.join(policy.apacheSitesAvailable ?? '/etc/apache2/sites-available', `vp-${name}.conf`),
    apacheEnabled: path.join(policy.apacheSitesEnabled ?? '/etc/apache2/sites-enabled', `vp-${name}.conf`),
    apacheAccessLog: path.join(policy.apacheLogDir ?? '/var/log/apache2', `vp-${name}.access.log`),
    apacheErrorLog: path.join(policy.apacheLogDir ?? '/var/log/apache2', `vp-${name}.error.log`),
    certName: `vp-${name}`,
    certDir: path.join(policy.letsencryptDir, 'live', `vp-${name}`),
  };
}

export const SHARED_NGINX_CONFIG = `# Managed by VaultPanel. Shared settings for the sites it manages.
map $http_upgrade $vp_connection_upgrade {
    default upgrade;
    '' close;
}
`;

const HEADER = '# Managed by VaultPanel. Changes made here are overwritten when the site is saved in the panel.';

function siteBody(spec, paths, policy) {
  const root = path.join(paths.home, spec.documentRoot);
  const lines = [
    `    root ${root};`,
    `    index ${spec.type === 'php' ? 'index.php ' : ''}index.html index.htm;`,
    `    access_log ${paths.accessLog};`,
    `    error_log ${paths.errorLog};`,
    '    client_max_body_size 64m;',
    '',
    '    # Hidden files such as .env and .git are never served.',
    '    location ~ /\\.(?!well-known/) {',
    '        deny all;',
    '    }',
    '',
  ];
  if (spec.customNginx) {
    lines.push('    # Custom rules from the panel', ...spec.customNginx.split('\n').map((l) => (l.trim() ? `    ${l.trimEnd()}` : '')), '    # End of custom rules', '');
  }
  if (spec.htaccess) {
    // Apache serves the site so its .htaccess files apply.
    lines.push(
      '    # .htaccess files are on: Apache serves this site.',
      '    location / {',
      `        proxy_pass http://127.0.0.1:${apachePort(policy)};`,
      '        proxy_set_header Host $host;',
      '        proxy_set_header X-Real-IP $remote_addr;',
      '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;',
      '        proxy_set_header X-Forwarded-Proto $scheme;',
      '        proxy_read_timeout 300s;',
      '    }',
    );
  } else if (spec.type === 'static') {
    lines.push('    location / {', `        try_files $uri $uri/ ${spec.spa ? '/index.html' : '=404'};`, '    }');
  } else if (spec.type === 'php') {
    lines.push(
      '    location / {',
      '        try_files $uri $uri/ /index.php?$query_string;',
      '    }',
      '',
      '    location ~ \\.php$ {',
      '        try_files $uri =404;',
      '        include fastcgi_params;',
      '        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;',
      '        fastcgi_param DOCUMENT_ROOT $realpath_root;',
      `        fastcgi_pass unix:${paths.phpSocket};`,
      '        fastcgi_read_timeout 300s;',
      '    }',
    );
  } else {
    lines.push(
      '    location / {',
      `        proxy_pass http://127.0.0.1:${spec.proxyPort};`,
      '        proxy_http_version 1.1;',
      '        proxy_set_header Host $host;',
      '        proxy_set_header X-Real-IP $remote_addr;',
      '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;',
      '        proxy_set_header X-Forwarded-Proto $scheme;',
      '        proxy_set_header Upgrade $http_upgrade;',
      '        proxy_set_header Connection $vp_connection_upgrade;',
      '        proxy_read_timeout 300s;',
      '    }',
    );
  }
  return lines;
}

// The NGINX server blocks for a site. With ssl, a second block serves HTTPS
// with the site's Let's Encrypt certificate; forceHttps redirects HTTP to it.
// The ACME challenge path is always served over HTTP so certificates can be
// issued and renewed. IPv6 listeners are left out on servers without IPv6,
// where NGINX would refuse to start with them.
export function renderNginxSite(spec, paths, policy, { ipv6 = true } = {}) {
  const listen = (port) => [`    listen ${port};`, ...(ipv6 ? [`    listen [::]:${port};`] : [])];
  const names = spec.domains.join(' ');
  const acme = ['    location ^~ /.well-known/acme-challenge/ {', `        root ${policy.acmeWebroot};`, '        default_type text/plain;', '    }', ''];
  const http = ['server {', ...listen('80'), `    server_name ${names};`, '', ...acme];
  if (spec.ssl && spec.forceHttps) {
    http.push(`    access_log ${paths.accessLog};`, `    error_log ${paths.errorLog};`, '', '    location / {', '        return 301 https://$host$request_uri;', '    }');
  } else {
    http.push(...siteBody(spec, paths, policy));
  }
  http.push('}');
  const blocks = [HEADER, `# Site: ${spec.name} (${spec.type})`, '', ...http];
  if (spec.ssl) {
    blocks.push(
      '',
      'server {',
      ...listen('443 ssl http2'),
      `    server_name ${names};`,
      '',
      `    ssl_certificate ${path.join(paths.certDir, 'fullchain.pem')};`,
      `    ssl_certificate_key ${path.join(paths.certDir, 'privkey.pem')};`,
      '    ssl_protocols TLSv1.2 TLSv1.3;',
      '    ssl_prefer_server_ciphers off;',
      '',
      ...siteBody(spec, paths, policy),
      '}',
    );
  }
  return `${blocks.join('\n')}\n`;
}

export const apachePort = (policy) => policy?.apachePort ?? 8080;
export const apacheUser = (policy) => policy?.apacheUser ?? 'vp-apache';

// What .htaccess files may contain besides the AuthConfig, Indexes and Limit
// groups: rewrites, redirects, headers, caching and file types. SetHandler,
// SetEnv and the like are left out so a site cannot send requests to another
// site's PHP or change PHP's settings.
export const HTACCESS_DIRECTIVES = [
  'RewriteEngine', 'RewriteBase', 'RewriteCond', 'RewriteRule', 'RewriteOptions',
  'Redirect', 'RedirectMatch', 'RedirectPermanent', 'RedirectTemp',
  'ErrorDocument', 'Header', 'ExpiresActive', 'ExpiresByType', 'ExpiresDefault',
  'AddType', 'AddCharset', 'AddDefaultCharset', 'AddEncoding', 'AddLanguage', 'DefaultLanguage',
  'FileETag',
];

// The Apache side of a site with .htaccess files on. Apache listens on
// 127.0.0.1 only, behind NGINX, and hands PHP to the site's own PHP-FPM pool.
// .htaccess files may rewrite, redirect, set headers and protect folders,
// but not follow symlinks to other users' files.
// ServerName takes no wildcard, so a wildcard domain is always an alias; a
// site with only wildcards gets a name no request uses.
export function renderApacheSite(spec, paths, policy) {
  const root = path.join(paths.home, spec.documentRoot);
  const serverName = spec.domains.find((d) => !isWildcardDomain(d)) ?? `${paths.certName}.invalid`;
  const aliases = spec.domains.filter((d) => d !== serverName);
  const lines = [
    HEADER,
    `# Site: ${spec.name} (${spec.type}), behind NGINX`,
    `<VirtualHost 127.0.0.1:${apachePort(policy)}>`,
    `    ServerName ${serverName}`,
    ...(aliases.length ? [`    ServerAlias ${aliases.join(' ')}`] : []),
    `    DocumentRoot ${root}`,
    `    ErrorLog ${paths.apacheErrorLog}`,
    `    CustomLog ${paths.apacheAccessLog} combined`,
    `    DirectoryIndex ${spec.type === 'php' ? 'index.php ' : ''}index.html index.htm`,
    `    <Directory ${paths.home}>`,
    '        Options SymLinksIfOwnerMatch',
    '        AllowOverride AuthConfig Indexes Limit Options=Indexes,MultiViews,SymLinksIfOwnerMatch',
    `        AllowOverrideList ${HTACCESS_DIRECTIVES.join(' ')}`,
    '        Require all granted',
    '    </Directory>',
    '    <FilesMatch "^\\.(?!well-known)">',
    '        Require all denied',
    '    </FilesMatch>',
  ];
  if (spec.type === 'php') {
    lines.push('    <FilesMatch "\\.php$">', `        SetHandler "proxy:unix:${paths.phpSocket}|fcgi://localhost"`, '    </FilesMatch>');
  }
  lines.push('</VirtualHost>');
  return `${lines.join('\n')}\n`;
}

// A PHP-FPM pool that runs the site's PHP as the site's own user, limited to
// its own directory.
// With .htaccess files on, only Apache's own user may use the socket.
export function renderPhpPool(spec, paths, policy) {
  const socketUser = spec.htaccess ? apacheUser(policy) : policy.webServerUser;
  // PHP-FPM pool files are INI: comments start with ";", not "#".
  return `${HEADER.replace(/^#/, ';')}
[${spec.name}]
user = ${spec.name}
group = ${spec.name}
listen = ${paths.phpSocket}
listen.owner = ${socketUser}
listen.group = ${socketUser}
listen.mode = 0660

pm = ondemand
pm.max_children = 10
pm.process_idle_timeout = 30s
pm.max_requests = 500

chdir = /
php_admin_value[open_basedir] = ${paths.home}/:/usr/share/php/:/tmp/
php_admin_value[upload_tmp_dir] = ${paths.tmp}
php_admin_value[session.save_path] = ${paths.tmp}
php_admin_value[sys_temp_dir] = ${paths.tmp}
php_admin_value[error_log] = ${path.join(paths.logs, 'php-error.log')}
php_admin_flag[log_errors] = on
php_admin_value[upload_max_filesize] = 64M
php_admin_value[post_max_size] = 64M
`;
}
