// The link between the agent and its root helper (0.36.0): one JSON object
// per line over a unix socket. Messages carry a type `t` and an `id` that ties
// replies, job logs and terminal output to what they belong to.

// The agent package (up to 50 MB) travels as base64 in one message.
export const MAX_MESSAGE_BYTES = 80 * 1024 * 1024;

// The panel calls an operation may make while it runs, made by the agent for
// the helper. Each one only reaches the panel's agent API, as the agent.
export const PANEL_METHODS = ['downloadAgentPackage', 'downloadUploadChunk', 'uploadDownloadChunk', 'uploadBackupChunk'];

export function send(socket, message) {
  if (socket.destroyed || !socket.writable) return false;
  return socket.write(`${JSON.stringify(message)}\n`);
}

// Calls onMessage with each message read from the socket. A line that is not
// JSON, or too long, ends the connection.
export function readMessages(socket, onMessage, { maxBytes = MAX_MESSAGE_BYTES } = {}) {
  let chunks = [];
  let size = 0;
  socket.on('data', (data) => {
    let start = 0;
    let newline = data.indexOf(10);
    while (newline !== -1) {
      chunks.push(data.subarray(start, newline));
      const line = Buffer.concat(chunks).toString('utf8');
      chunks = [];
      size = 0;
      start = newline + 1;
      newline = data.indexOf(10, start);
      if (!line) continue;
      let message;
      try {
        message = JSON.parse(line);
      } catch {
        socket.destroy(new Error('The other side of the helper link sent something that is not JSON'));
        return;
      }
      if (message && typeof message === 'object') onMessage(message);
    }
    const rest = data.subarray(start);
    size += rest.length;
    if (size > maxBytes) {
      socket.destroy(new Error('A message on the helper link is too large'));
      return;
    }
    if (rest.length) chunks.push(rest);
  });
}

// An error as it crosses the link, and back.
export const errorMessage = (err) => ({ code: err?.code ?? 'AGENT_ERROR', message: err?.message ?? 'Unexpected agent error', ...(err?.output !== undefined ? { output: err.output } : {}) });
