import { isIPv4 } from 'node:net';
import { OperationError } from '../operations/errors.js';
import { CLOUDFLARE_TOKEN_PATTERN, DNS_PROVIDER_TYPES, NAMECHEAP_KEY_PATTERN, NAMECHEAP_USER_PATTERN } from '../security/dnsRules.js';
import { DOMAIN_PATTERN } from '../security/webRules.js';

// DNS hosted elsewhere (0.38.0): Let's Encrypt's check record for a wildcard
// certificate (a TXT record named _acme-challenge.<domain>) is added and
// removed through the provider's API. The panel sends the credentials inside
// the ISSUE_SSL job; acmeDns.js keeps them for renewals in a file only root
// reads.

const TIMEOUT_MS = 30_000;
const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const failed = (message) => new OperationError('DNS_PROVIDER_FAILED', message);

export const DNS_PROVIDER_LABELS = { cloudflare: 'Cloudflare', namecheap: 'Namecheap' };
const FIELDS = {
  cloudflare: { apiToken: CLOUDFLARE_TOKEN_PATTERN },
  namecheap: { apiUser: NAMECHEAP_USER_PATTERN, apiKey: NAMECHEAP_KEY_PATTERN, clientIp: null, domain: DOMAIN_PATTERN },
};

// The provider's settings, checked: its type and exactly its own fields.
export function checkDnsProvider(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw invalid('dnsProvider must be an object');
  if (!DNS_PROVIDER_TYPES.includes(value.type)) throw invalid(`dnsProvider.type must be one of ${DNS_PROVIDER_TYPES.join(', ')}`);
  const fields = FIELDS[value.type];
  const out = { type: value.type };
  for (const key of Object.keys(value)) {
    if (key !== 'type' && !Object.hasOwn(fields, key)) throw invalid(`dnsProvider.${key} is not a ${DNS_PROVIDER_LABELS[value.type]} setting`);
  }
  for (const [key, pattern] of Object.entries(fields)) {
    const v = value[key];
    const ok = typeof v === 'string' && (pattern ? pattern.test(v) : isIPv4(v));
    if (!ok) throw invalid(`dnsProvider.${key} is missing or not valid`);
    out[key] = v;
  }
  return out;
}

// { label, add(name, value), remove(name, value) } for a checked provider.
export function dnsProviderFor(provider, { fetch: send = globalThis.fetch } = {}) {
  return provider.type === 'cloudflare' ? cloudflare(provider, send) : namecheap(provider, send);
}

async function request(send, what, url, options) {
  try {
    return await send(url, { ...options, signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (err) {
    throw failed(`${what} could not be reached: ${err.message}`);
  }
}

// ---- Cloudflare -------------------------------------------------------------

const CLOUDFLARE_API = 'https://api.cloudflare.com/client/v4';
const CLOUDFLARE_ID = /^[a-f0-9]{32}$/;
// "An identical record already exists."
const CLOUDFLARE_DUPLICATE = 81058;

function cloudflare({ apiToken }, send) {
  async function api(method, path, body) {
    const res = await request(send, 'Cloudflare', `${CLOUDFLARE_API}${path}`, {
      method,
      headers: { Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json' },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) {
      const message = data?.errors?.map((e) => e.message).filter(Boolean).join('; ') || `HTTP ${res.status}`;
      const hint = [401, 403].includes(res.status) ? ' The API token needs the Zone > DNS > Edit permission for this domain.' : '';
      const err = failed(`Cloudflare: ${message}.${hint}`);
      err.providerCodes = data?.errors?.map((e) => e.code) ?? [];
      throw err;
    }
    return data.result;
  }

  // The Cloudflare zone a name is in: the nearest of its parents the token sees.
  async function zoneFor(name) {
    const labels = name.split('.');
    for (let i = 1; i < labels.length - 1; i += 1) {
      const zones = await api('GET', `/zones?name=${encodeURIComponent(labels.slice(i).join('.'))}`);
      const zone = zones?.find((z) => CLOUDFLARE_ID.test(z.id));
      if (zone) return zone;
    }
    throw failed(`Cloudflare: the API token sees no zone that holds ${name.replace(/^_acme-challenge\./, '')}. Add the domain to that Cloudflare account, or give the token access to it.`);
  }

  return {
    label: 'Cloudflare',
    async add(name, value) {
      const zone = await zoneFor(name);
      try {
        await api('POST', `/zones/${zone.id}/dns_records`, { type: 'TXT', name, content: value, ttl: 60 });
      } catch (err) {
        if (!err.providerCodes?.includes(CLOUDFLARE_DUPLICATE)) throw err;
      }
      return { zone: zone.name };
    },
    async remove(name, value) {
      const zone = await zoneFor(name);
      const records = await api('GET', `/zones/${zone.id}/dns_records?type=TXT&name=${encodeURIComponent(name)}&per_page=100`);
      // Cloudflare may keep TXT values in quotes.
      const ours = (records ?? []).filter((r) => CLOUDFLARE_ID.test(r.id) && (r.content === value || r.content === `"${value}"`));
      for (const r of ours) await api('DELETE', `/zones/${zone.id}/dns_records/${r.id}`);
      return { zone: zone.name, removed: ours.length };
    },
  };
}

// ---- Namecheap --------------------------------------------------------------

// Namecheap has no call that adds one record: setHosts replaces them all.
// So every record getHosts returned is sent back as it was, with the domain's
// email setting, and nothing is written when the list cannot be read exactly.

const NAMECHEAP_API = 'https://api.namecheap.com/xml.response';
const EMAIL_TYPES = ['MX', 'MXE', 'FWD', 'OX', 'GMAIL'];

function namecheap({ apiUser, apiKey, clientIp, domain }, send) {
  const dot = domain.indexOf('.');
  const sld = domain.slice(0, dot);
  const tld = domain.slice(dot + 1);

  async function call(command, extra = {}) {
    const body = new URLSearchParams({ ApiUser: apiUser, ApiKey: apiKey, UserName: apiUser, ClientIp: clientIp, Command: command, SLD: sld, TLD: tld, ...extra });
    const res = await request(send, 'Namecheap', NAMECHEAP_API, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
    const xml = await res.text();
    if (/<ApiResponse\b[^>]*\bStatus="([^"]*)"/.exec(xml)?.[1] !== 'OK') {
      const errors = [...xml.matchAll(/<Error\b[^>]*>([^<]*)<\/Error>/g)].map((m) => decodeXml(m[1]).trim()).filter(Boolean);
      const message = errors.join('; ') || `HTTP ${res.status}`;
      const hint = /\bip\b|whitelist/i.test(message) ? ` Whitelist ${clientIp} under Profile > Tools > Namecheap API Access.` : '';
      throw failed(`Namecheap: ${message}.${hint}`);
    }
    return xml;
  }

  async function save(hosts, emailType) {
    const extra = {};
    hosts.forEach((h, i) => {
      Object.assign(extra, { [`HostName${i + 1}`]: h.name, [`RecordType${i + 1}`]: h.type, [`Address${i + 1}`]: h.address, [`MXPref${i + 1}`]: h.mxPref, [`TTL${i + 1}`]: h.ttl });
    });
    if (emailType) extra.EmailType = emailType;
    const xml = await call('namecheap.domains.dns.setHosts', extra);
    if (!/<DomainDNSSetHostsResult\b[^>]*\bIsSuccess="true"/i.test(xml)) throw failed(`Namecheap did not confirm the change to the records of ${domain}`);
  }

  // _acme-challenge.shop.example.com -> _acme-challenge.shop
  function hostName(name) {
    if (!name.endsWith(`.${domain}`)) throw failed(`${name} is not under ${domain}`);
    return name.slice(0, -domain.length - 1);
  }
  const isOurs = (host, value) => (h) => h.type === 'TXT' && h.name === host && h.address === value;

  return {
    label: 'Namecheap',
    async add(name, value) {
      const host = hostName(name);
      const { hosts, emailType } = parseNamecheapHosts(await call('namecheap.domains.dns.getHosts'), domain);
      if (!hosts.some(isOurs(host, value))) await save([...hosts, { name: host, type: 'TXT', address: value, mxPref: '10', ttl: '60' }], emailType);
      return { zone: domain };
    },
    async remove(name, value) {
      const host = hostName(name);
      const { hosts, emailType } = parseNamecheapHosts(await call('namecheap.domains.dns.getHosts'), domain);
      const rest = hosts.filter((h) => !isOurs(host, value)(h));
      if (rest.length !== hosts.length) await save(rest, emailType);
      return { zone: domain, removed: hosts.length - rest.length };
    },
  };
}

// The records and email setting in a getHosts answer. Refuses a list it
// cannot read exactly, since writing it back short would delete records.
export function parseNamecheapHosts(xml, domain) {
  const result = /<DomainDNSGetHostsResult\b([^>]*)>/.exec(xml);
  if (!result) throw failed(`Namecheap did not return the DNS records of ${domain}`);
  const info = attributes(result[1]);
  if (String(info.IsUsingOurDNS ?? 'true').toLowerCase() !== 'true') {
    throw failed(`${domain} does not use Namecheap's name servers, so its records cannot be changed there. Choose the DNS provider whose name servers the domain uses.`);
  }
  const tags = xml.match(/<host\b/g) ?? [];
  // Whole quoted attributes, so a ">" inside a value cannot cut a record short.
  const hosts = [...xml.matchAll(/<host\b((?:\s+[A-Za-z_][\w.-]*="[^"]*")*)\s*\/?>/g)].map((m) => attributes(m[1]));
  if (hosts.length !== tags.length || hosts.some((h) => !h.Name || !h.Type || h.Address === undefined)) {
    throw failed(`The DNS records of ${domain} could not be read exactly, so none were changed`);
  }
  const emailType = String(info.EmailType ?? '').toUpperCase();
  return {
    emailType: EMAIL_TYPES.includes(emailType) ? emailType : null,
    hosts: hosts.map((h) => ({ name: h.Name, type: h.Type, address: h.Address, mxPref: h.MXPref ?? '10', ttl: h.TTL ?? '1800' })),
  };
}

function attributes(text) {
  const out = {};
  for (const m of text.matchAll(/([A-Za-z_][\w.-]*)="([^"]*)"/g)) out[m[1]] = decodeXml(m[2]);
  return out;
}

function decodeXml(text) {
  return text
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(Number(dec)))
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}
