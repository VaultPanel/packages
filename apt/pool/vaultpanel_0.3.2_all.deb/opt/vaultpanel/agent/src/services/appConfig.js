import path from 'node:path';
import { OperationError } from '../operations/errors.js';
import {
  APP_PORT_MAX,
  APP_PORT_MIN,
  APP_RUNTIMES,
  BRANCH_PATTERN,
  ENV_KEY_PATTERN,
  MAX_ENV_VALUE_LENGTH,
  MAX_ENV_VARS,
  MAX_KEEP_RELEASES,
  MAX_REPOSITORY_URL_LENGTH,
  parseCommands,
  RELEASE_ID_PATTERN,
  REPOSITORY_URL_PATTERN,
  RESERVED_ENV_KEYS,
} from '../security/appRules.js';
import { checkSiteName } from './siteConfig.js';

// Checks application parameters from the panel and renders the files that
// run an app: its systemd unit (which starts PM2 as the app's user) and its
// PM2 process file. Like site configuration, these are generated here from
// checked values only.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);

export const APP_HEADER = '# Managed by VaultPanel. Changes made here are overwritten when the app is deployed or its settings are saved in the panel.';
export const APP_LOG_FILES = { output: 'logs/app-output.log', error: 'logs/app-error.log' };

export const checkAppName = checkSiteName;

export function checkRuntime(runtime) {
  if (!APP_RUNTIMES.includes(runtime)) throw invalid(`runtime must be one of ${APP_RUNTIMES.join(', ')}`);
  return runtime;
}

export function checkRepository(url) {
  if (typeof url !== 'string' || url.length > MAX_REPOSITORY_URL_LENGTH || !REPOSITORY_URL_PATTERN.test(url)) {
    throw invalid('repository must be an https:// or SSH Git URL without credentials');
  }
  return url;
}

export function checkBranch(branch) {
  if (typeof branch !== 'string' || !BRANCH_PATTERN.test(branch)) throw invalid('branch must be a valid branch name');
  return branch;
}

export function checkReleaseId(id) {
  if (typeof id !== 'string' || !RELEASE_ID_PATTERN.test(id)) throw invalid('releaseId must be a release id');
  return id;
}

export function checkPort(port, { required = false } = {}) {
  if (port === undefined || port === null) {
    if (required) throw invalid('port is required');
    return null;
  }
  if (!Number.isInteger(port) || port < APP_PORT_MIN || port > APP_PORT_MAX) throw invalid(`port must be from ${APP_PORT_MIN} to ${APP_PORT_MAX}`);
  return port;
}

export function checkInteger(value, field, min, max, fallback) {
  const v = value ?? fallback;
  if (!Number.isInteger(v) || v < min || v > max) throw invalid(`${field} must be an integer from ${min} to ${max}`);
  return v;
}

export function checkKeepReleases(value) {
  return checkInteger(value, 'keepReleases', 1, MAX_KEEP_RELEASES, 5);
}

// "KEY=value" entries to an object, refusing the keys VaultPanel sets itself.
export function checkEnv(entries = []) {
  if (!Array.isArray(entries) || entries.length > MAX_ENV_VARS) throw invalid(`env must list up to ${MAX_ENV_VARS} variables`);
  const env = {};
  for (const entry of entries) {
    if (typeof entry !== 'string') throw invalid('env entries must be KEY=value');
    const i = entry.indexOf('=');
    const key = entry.slice(0, i);
    const value = entry.slice(i + 1);
    if (i < 1 || !ENV_KEY_PATTERN.test(key)) throw invalid('env entries must be KEY=value');
    if (RESERVED_ENV_KEYS.includes(key)) throw invalid(`${key} is set by VaultPanel`);
    if (Object.hasOwn(env, key)) throw invalid(`${key} is listed twice`);
    if (value.length > MAX_ENV_VALUE_LENGTH || value.includes('\0')) throw invalid(`The value of ${key} is too long`);
    env[key] = value;
  }
  return env;
}

// Commands as lists of arguments. $PORT and ${PORT} are replaced by the port.
export function checkCommands(text, field, { single = false, port = null } = {}) {
  if (text === undefined || text === null || text === '') {
    if (single) throw invalid(`${field} is required`);
    return [];
  }
  const parsed = parseCommands(text);
  if (parsed.error) throw invalid(`${field}: ${parsed.error}`);
  if (single && parsed.commands.length !== 1) throw invalid(`${field} must be a single command`);
  return parsed.commands.map((argv) => argv.map((arg) => (port === null ? arg : arg.replace(/\$\{PORT\}|\$PORT\b/g, String(port)))));
}

// Every path an app uses. Relative paths are inside its home folder.
export function appPaths(policy, name) {
  const home = path.join(policy.sitesRoot, name);
  return {
    home,
    unitName: `pm2-${name}`,
    unitFile: path.join(policy.systemdUnitDir ?? '/etc/systemd/system', `pm2-${name}.service`),
    pm2Home: path.join(home, '.pm2'),
    sshDir: path.join(home, '.ssh'),
    deployKey: path.join(home, '.ssh', 'id_ed25519'),
    knownHosts: path.join(home, '.ssh', 'known_hosts'),
    rel: {
      releases: 'releases',
      current: 'current',
      shared: 'shared',
      env: 'shared/.env',
      ecosystem: 'shared/ecosystem.json',
      clusterStart: 'shared/cluster-start.cjs',
      deployKeyPub: '.ssh/id_ed25519.pub',
      release: (id) => `releases/${id}`,
      ...APP_LOG_FILES,
    },
  };
}

// Folders created for every app (relative to home) and their modes.
export const APP_FOLDERS = [
  { path: 'releases', mode: 0o750 },
  { path: 'shared', mode: 0o750 },
  { path: 'logs', mode: 0o750 },
  { path: 'tmp', mode: 0o750 },
  { path: '.ssh', mode: 0o700 },
];

// The PATH for an app's commands and processes: its virtual environment and
// node_modules/.bin first, then Node.js and the system.
export function appSearchPath(releaseDir, nodeBinDir) {
  return [path.join(releaseDir, '.venv', 'bin'), path.join(releaseDir, 'node_modules', '.bin'), nodeBinDir, '/usr/local/bin', '/usr/bin', '/bin']
    .filter((dir, i, all) => dir && all.indexOf(dir) === i)
    .join(':');
}

// The environment commands and the app run with.
// Python apps run as one process; Gunicorn and Uvicorn start as many workers
// as WEB_CONCURRENCY says, so that is how they get several copies.
// Ruby gems are installed into the release (vendor/bundle), and Ruby and Go
// apps run in production mode unless the app's own variables say otherwise.
export function appEnvironment({ name, home, releaseDir, runtime, env, port, nodeBinDir, instances = 1 }) {
  return {
    ...(runtime === 'ruby' ? { RACK_ENV: 'production', RAILS_ENV: 'production', RAILS_LOG_TO_STDOUT: '1' } : {}),
    ...(runtime === 'go' ? { GIN_MODE: 'release' } : {}),
    ...env,
    HOME: home,
    USER: name,
    LANG: env.LANG ?? 'C.UTF-8',
    PATH: appSearchPath(releaseDir, nodeBinDir),
    ...(runtime === 'python' ? { VIRTUAL_ENV: path.join(releaseDir, '.venv') } : {}),
    ...(runtime === 'python' && instances > 1 ? { WEB_CONCURRENCY: String(instances) } : {}),
    ...(runtime === 'ruby' ? { BUNDLE_PATH: 'vendor/bundle' } : {}),
    ...(port ? { PORT: String(port) } : {}),
  };
}

// Whether two process files both run the app in PM2 cluster mode, so the
// change from one to the other can be a reload: PM2 starts the new copies
// before stopping the old ones, and the port keeps answering throughout.
export function bothCluster(before, after) {
  const mode = (text) => {
    try {
      return JSON.parse(text)?.apps?.[0]?.exec_mode ?? null;
    } catch {
      return null;
    }
  };
  return mode(before) === 'cluster' && mode(after) === 'cluster';
}

// The systemd unit that keeps the app's PM2 running as the app's user. PM2
// runs in the foreground (pm2-runtime) so systemd owns its lifecycle: it
// starts at boot, and stopping the unit stops the app.
//
// The sandboxing keeps the app to its own folder: it cannot see /home or
// /root, has its own /tmp, cannot gain privileges, load kernel modules or
// change kernel settings. limits caps its CPU (percent of one core) and
// memory (MiB); systemd stops the app if it goes over the memory limit, and
// restarts it.
export function renderAppUnit({ name, paths, pm2Runtime, nodeBinDir, limits = null }) {
  const limitLines = [
    ...(limits?.cpuPercent ? [`CPUQuota=${limits.cpuPercent}%`] : []),
    ...(limits?.memoryMb ? [`MemoryMax=${limits.memoryMb}M`] : []),
  ];
  return `${APP_HEADER}
[Unit]
Description=VaultPanel app ${name} (PM2)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${name}
Group=${name}
WorkingDirectory=${paths.home}
Environment=HOME=${paths.home}
Environment=PM2_HOME=${paths.pm2Home}
Environment=PATH=${[nodeBinDir, '/usr/local/bin', '/usr/bin', '/bin'].filter((d, i, a) => a.indexOf(d) === i).join(':')}
ExecStart=${pm2Runtime} start ${path.join(paths.home, paths.rel.ecosystem)}
Restart=always
RestartSec=5
TimeoutStopSec=30
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
LimitNOFILE=65535
${limitLines.length ? `${limitLines.join('\n')}\n` : ''}
[Install]
WantedBy=multi-user.target
`;
}

// The PM2 process file. cwd is the "current" link, so a rollback only has
// to move the link and restart.
//
// cluster ({ script, args, nodeArgs, instances }) runs that many copies of a
// Node.js script in PM2 cluster mode: they share the app's port and PM2
// spreads connections between them. Without it the start command runs as a
// single process, whatever program it is.
// In cluster mode PM2 runs shared/cluster-start.cjs (see renderClusterStart),
// which runs the script.
export function renderEcosystem({ name, paths, argv, env, cluster = null }) {
  const run = cluster
    ? {
        script: path.join(paths.home, paths.rel.clusterStart),
        args: cluster.args,
        ...(cluster.nodeArgs.length ? { node_args: cluster.nodeArgs } : {}),
        exec_mode: 'cluster',
        instances: cluster.instances,
        // A reload waits this long for each new copy to listen before it
        // stops the old one.
        listen_timeout: 15_000,
      }
    : { script: argv[0], args: argv.slice(1), interpreter: 'none' };
  const app = {
    name,
    ...run,
    cwd: path.join(paths.home, paths.rel.current),
    env,
    out_file: path.join(paths.home, paths.rel.output),
    error_file: path.join(paths.home, paths.rel.error),
    merge_logs: true,
    time: true,
    autorestart: true,
    max_restarts: 15,
    min_uptime: 10_000,
    restart_delay: 3000,
    kill_timeout: 8000,
  };
  return `${JSON.stringify({ apps: [app] }, null, 2)}\n`;
}

// Starts the app's script in each copy PM2 runs in cluster mode. Under
// pm2-runtime (how the app's unit runs PM2), Node.js hands every copy
// pm2-runtime's own arguments ("start <ecosystem file>") before the app's;
// this removes them so the app sees only its own, then loads the script
// (CommonJS, or an ES module).
export function renderClusterStart({ paths, script }) {
  const ecosystem = path.join(paths.home, paths.rel.ecosystem);
  return `// ${APP_HEADER.slice(2)}
'use strict';
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const script = path.resolve(${JSON.stringify(script)});
if (process.argv[2] === 'start' && process.argv[3] === ${JSON.stringify(ecosystem)}) process.argv.splice(2, 2);
process.argv[1] = script;
const fail = (err) => {
  console.error(err);
  process.exit(1);
};
if (/\\.mjs$/.test(script)) import(pathToFileURL(script).href).catch(fail);
else {
  try {
    require(script);
  } catch (err) {
    if (err?.code !== 'ERR_REQUIRE_ESM' && err?.code !== 'ERR_REQUIRE_ASYNC_MODULE') throw err;
    import(pathToFileURL(script).href).catch(fail);
  }
}
`;
}

// A .env file with the app's variables, for running commands by hand.
export function renderEnvFile(env) {
  const quote = (v) => `"${v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')}"`;
  return `# ${APP_HEADER.slice(2)}\n${Object.entries(env)
    .map(([k, v]) => `${k}=${quote(v)}`)
    .join('\n')}\n`;
}

// Reads a .env file written by renderEnvFile back into variables.
export function parseEnvFile(text) {
  const env = {};
  for (const line of String(text ?? '').split('\n')) {
    const match = /^([A-Za-z_][A-Za-z0-9_]{0,127})=(.*)$/.exec(line);
    if (!match) continue;
    let value = match[2];
    if (value.length >= 2 && value.startsWith('"') && value.endsWith('"')) {
      value = value.slice(1, -1).replace(/\\(n|"|\\)/g, (_, c) => (c === 'n' ? '\n' : c));
    }
    env[match[1]] = value;
  }
  return env;
}

// Node.js options that take the next argument as their value.
const NODE_OPTIONS_WITH_VALUE = new Set(['-r', '--require', '--import', '--loader', '--experimental-loader', '--env-file', '--conditions', '-C', '--input-type', '--title']);

// How a start command runs in PM2 cluster mode, which can only run Node.js
// scripts: "node [options] app.js [args]" or a program that is itself a
// Node.js script (node_modules/.bin/next, a .js file...). isNodeScript(file)
// says whether a file is one. Returns null when the command is something
// else (npm start, a shell script, a binary).
export async function clusterStart(argv, { isNodeScript, instances }) {
  const program = path.basename(argv[0]);
  if (program === 'node' || program === 'nodejs') {
    const nodeArgs = [];
    let i = 1;
    while (i < argv.length && argv[i].startsWith('-')) {
      nodeArgs.push(argv[i]);
      if (NODE_OPTIONS_WITH_VALUE.has(argv[i]) && i + 1 < argv.length) nodeArgs.push(argv[++i]);
      i += 1;
    }
    if (i >= argv.length || ['-e', '--eval', '-p', '--print', '-'].some((f) => nodeArgs.includes(f))) return null;
    return { script: argv[i], args: argv.slice(i + 1), nodeArgs, instances };
  }
  if (await isNodeScript(argv[0])) return { script: argv[0], args: argv.slice(1), nodeArgs: [], instances };
  return null;
}

// Whether the start of a file shows a Node.js script.
export function looksLikeNodeScript(file, head) {
  if (/\.(?:js|mjs|cjs)$/.test(file)) return true;
  const firstLine = String(head).split('\n')[0];
  return /^#!.*\bnode(?:js)?\b/.test(firstLine);
}

// Turns `pm2 jlist` output into the app's process state. An app in cluster
// mode has one entry per copy; the totals cover them all, and instances
// lists each copy.
// PM2 may print notices ("[PM2] ...") before the JSON line.
export function parsePm2List(text, name) {
  let list = null;
  for (const line of String(text).split('\n').reverse()) {
    if (!line.startsWith('[')) continue;
    try {
      list = JSON.parse(line);
      break;
    } catch {
      // a notice, not the list
    }
  }
  const entries = Array.isArray(list) ? list.filter((p) => p?.name === name) : [];
  if (!entries.length) return null;
  const copies = entries.map((entry) => {
    const env = entry.pm2_env ?? {};
    return {
      id: Number.isInteger(entry.pm_id) ? entry.pm_id : null,
      status: String(env.status ?? 'unknown'),
      pid: Number.isInteger(entry.pid) && entry.pid > 0 ? entry.pid : null,
      restarts: Number.isInteger(env.restart_time) ? env.restart_time : 0,
      memoryBytes: Number.isFinite(entry.monit?.memory) ? entry.monit.memory : null,
      cpuPercent: Number.isFinite(entry.monit?.cpu) ? entry.monit.cpu : null,
      startedAt: Number.isFinite(env.pm_uptime) ? new Date(env.pm_uptime).toISOString() : null,
    };
  });
  const online = copies.filter((c) => c.status === 'online').length;
  const sum = (key) => (copies.some((c) => c[key] !== null) ? copies.reduce((total, c) => total + (c[key] ?? 0), 0) : null);
  const started = copies.map((c) => c.startedAt).filter(Boolean).sort();
  // One copy that is not online does not make the app down while others serve it.
  const status = online > 0 ? 'online' : copies[0].status;
  return {
    status,
    pid: copies[0].pid,
    restarts: sum('restarts') ?? 0,
    memoryBytes: sum('memoryBytes'),
    cpuPercent: sum('cpuPercent'),
    startedAt: started[0] ?? null,
    count: copies.length,
    online,
    instances: copies,
  };
}
