import { signRequest } from '../security/signing.js';

export class PanelError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function assertSecureUrl(panelUrl, allowInsecureHttp) {
  const url = new URL(panelUrl);
  if (url.protocol === 'https:') return;
  if (url.protocol === 'http:' && (allowInsecureHttp || isLoopbackHost(url.hostname))) return;
  throw new Error('The panel URL must use https:// (use --insecure-http only for local development)');
}

// A panel on this same machine may be reached over plain HTTP: the traffic
// never leaves it.
export function isLoopbackHost(hostname) {
  const h = hostname.replace(/^\[|\]$/g, '');
  return h === 'localhost' || h === '::1' || /^127\.\d+\.\d+\.\d+$/.test(h);
}

// HTTP client for the panel API. Every request after registration is signed
// with the agent's Ed25519 key.
export function createPanelClient({ panelUrl, agentId, privateKeyPem, allowInsecureHttp = false, fetchImpl = fetch }) {
  assertSecureUrl(panelUrl, allowInsecureHttp);
  const base = panelUrl.replace(/\/+$/, '');

  async function request(method, path, body, { timeoutMs = 15_000, signed = true } = {}) {
    const fullPath = `/api/v1/agent${path}`;
    const payload = body === undefined ? '' : JSON.stringify(body);
    const headers = { Accept: 'application/json' };
    if (payload) headers['Content-Type'] = 'application/json';
    if (signed) Object.assign(headers, signRequest({ agentId, privateKeyPem, method, path: fullPath, body: payload }));

    const res = await fetchImpl(`${base}${fullPath}`, {
      method,
      headers,
      body: payload || undefined,
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (res.status === 204) return null;
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.success) {
      throw new PanelError(res.status, json?.error?.code ?? 'HTTP_ERROR', json?.error?.message ?? `HTTP ${res.status}`);
    }
    return json.data;
  }

  // The agent package the panel serves (unsigned, like the install script:
  // an update job carries the package's hash, which the agent checks).
  async function downloadAgentPackage({ maxBytes = 50 * 1024 * 1024, timeoutMs = 120_000 } = {}) {
    const res = await fetchImpl(`${base}/api/v1/agent/package.tgz`, { signal: AbortSignal.timeout(timeoutMs) });
    if (!res.ok) throw new PanelError(res.status, 'HTTP_ERROR', `HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    if (buffer.length > maxBytes) throw new PanelError(res.status, 'TOO_LARGE', 'The package is larger than expected');
    return buffer;
  }

  return {
    downloadAgentPackage,
    register: (body) => request('POST', '/register', body, { signed: false }),
    heartbeat: (body) => request('POST', '/heartbeat', body),
    nextJob: () => request('GET', '/jobs/next', undefined, { timeoutMs: 40_000 }),
    jobStarted: (jobId) => request('POST', `/jobs/${jobId}/start`, {}),
    jobLogs: (jobId, lines) => request('POST', `/jobs/${jobId}/logs`, { lines }),
    jobResult: (jobId, result) => request('POST', `/jobs/${jobId}/result`, result),
    uploadBackupChunk: (backupId, chunk) => request('POST', `/backups/${backupId}/chunks`, chunk, { timeoutMs: 120_000 }),
    // A piece of a file uploaded in the file manager, as base64.
    downloadUploadChunk: (uploadId, offset) => request('GET', `/uploads/${uploadId}/chunks/${offset}`, undefined, { timeoutMs: 120_000 }),
    // A piece of a site file the panel will offer for download.
    uploadDownloadChunk: (downloadId, chunk) => request('POST', `/downloads/${downloadId}/chunks`, chunk, { timeoutMs: 120_000 }),
    cronRuns: (runs) => request('POST', '/cron-runs', { runs }),
  };
}
