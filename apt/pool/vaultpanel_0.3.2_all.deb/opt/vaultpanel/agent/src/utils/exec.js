import { spawn } from 'node:child_process';

export const DEFAULT_PATH = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';

// Runs a program with a fixed argument list. Never uses a shell, so
// arguments cannot be interpreted as shell syntax. Output is streamed line by
// line to onLine and also returned (capped).
//
// uid/gid run it as another user (only root can), cwd sets its folder and
// input is written to its stdin. The program gets its own process group, so a
// timeout also stops whatever it started (npm scripts, build tools).
export function runCommand(file, args, { timeoutMs = 30_000, onLine, maxOutputBytes = 1024 * 1024, env, uid, gid, cwd, input } = {}) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(file, args, {
        shell: false,
        stdio: [input === undefined ? 'ignore' : 'pipe', 'pipe', 'pipe'],
        env: env ?? { PATH: DEFAULT_PATH, LANG: 'C' },
        detached: true,
        ...(uid !== undefined ? { uid, gid } : {}),
        ...(cwd ? { cwd } : {}),
      });
    } catch (error) {
      resolve({ exitCode: null, error, stdout: '', stderr: '', timedOut: false });
      return;
    }
    const chunks = { stdout: '', stderr: '' };
    const partial = { stdout: '', stderr: '' };
    let timedOut = false;
    let settled = false;

    const killGroup = (signal) => {
      try {
        process.kill(-child.pid, signal);
      } catch {
        child.kill(signal);
      }
    };
    const timer = setTimeout(() => {
      timedOut = true;
      killGroup('SIGTERM');
      setTimeout(() => killGroup('SIGKILL'), 5000).unref();
    }, timeoutMs);

    const collect = (stream) => (data) => {
      const text = data.toString('utf8');
      if (chunks[stream].length < maxOutputBytes) chunks[stream] += text;
      if (!onLine) return;
      const lines = (partial[stream] + text).split('\n');
      partial[stream] = lines.pop();
      for (const line of lines) onLine(stream, line);
    };
    child.stdout.on('data', collect('stdout'));
    child.stderr.on('data', collect('stderr'));
    if (input !== undefined) {
      child.stdin.on('error', () => {});
      child.stdin.end(input);
    }

    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (onLine) {
        for (const stream of ['stdout', 'stderr']) if (partial[stream]) onLine(stream, partial[stream]);
      }
      resolve({ ...result, stdout: chunks.stdout, stderr: chunks.stderr, timedOut });
    };
    child.on('error', (err) => finish({ exitCode: null, error: err }));
    child.on('close', (exitCode, signal) => finish({ exitCode, signal }));
  });
}
