import { readFileSync } from 'node:fs';

export const AGENT_VERSION = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')).version;
