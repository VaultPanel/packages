import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGunzip, createGzip } from 'node:zlib';
import { DEFAULT_PATH } from './exec.js';

// Streaming counterparts of runCommand for backups: a program's output is
// compressed into a file (pipeToFile), or a compressed file is fed to a
// program (pipeFromFile). Like runCommand they never use a shell, can run as
// another user and stop the whole process group on timeout.

function measure() {
  const hash = createHash('sha256');
  let bytes = 0;
  const stream = new Transform({
    transform(chunk, _enc, done) {
      hash.update(chunk);
      bytes += chunk.length;
      done(null, chunk);
    },
  });
  return { stream, result: () => ({ sizeBytes: bytes, sha256: hash.digest('hex') }) };
}

function start(file, args, { env, uid, gid, cwd, stdin }) {
  return spawn(file, args, {
    shell: false,
    stdio: [stdin ? 'pipe' : 'ignore', stdin ? 'ignore' : 'pipe', 'pipe'],
    env: env ?? { PATH: DEFAULT_PATH, LANG: 'C' },
    detached: true,
    ...(uid !== undefined ? { uid, gid } : {}),
    ...(cwd ? { cwd } : {}),
  });
}

function supervise(child, { timeoutMs, onLine }) {
  let stderr = '';
  let partial = '';
  let timedOut = false;
  const killGroup = (signal) => {
    try {
      process.kill(-child.pid, signal);
    } catch {
      child.kill(signal);
    }
  };
  const timer = setTimeout(() => {
    timedOut = true;
    killGroup('SIGTERM');
    setTimeout(() => killGroup('SIGKILL'), 5000).unref();
  }, timeoutMs);
  child.stderr.on('data', (data) => {
    const text = data.toString('utf8');
    if (stderr.length < 64 * 1024) stderr += text;
    if (!onLine) return;
    const lines = (partial + text).split('\n');
    partial = lines.pop();
    for (const line of lines) onLine('stderr', line);
  });
  const exited = new Promise((resolve) => {
    child.on('error', (error) => resolve({ exitCode: null, error }));
    child.on('close', (exitCode, signal) => resolve({ exitCode, signal }));
  });
  return {
    async done() {
      const result = await exited;
      clearTimeout(timer);
      if (partial && onLine) onLine('stderr', partial);
      return { ...result, stderr, timedOut };
    },
    kill: () => killGroup('SIGKILL'),
  };
}

// Runs a program and writes its standard output, gzip-compressed, to target
// (created new, mode 600). Returns the program's result plus the written
// file's size and SHA-256.
export async function pipeToFile(file, args, { target, timeoutMs = 3_600_000, onLine, env, uid, gid, cwd } = {}) {
  let child;
  try {
    child = start(file, args, { env, uid, gid, cwd });
  } catch (error) {
    return { exitCode: null, error, stderr: '', timedOut: false };
  }
  const watch = supervise(child, { timeoutMs, onLine });
  const measured = measure();
  let streamError = null;
  try {
    await pipeline(child.stdout, createGzip({ level: 6 }), measured.stream, createWriteStream(target, { flags: 'wx', mode: 0o600 }));
  } catch (err) {
    streamError = err;
    watch.kill();
  }
  const result = await watch.done();
  return { ...result, streamError, ...measured.result() };
}

// Feeds a gzip-compressed file to a program's standard input.
export async function pipeFromFile(file, args, { source, timeoutMs = 3_600_000, onLine, env, uid, gid, cwd } = {}) {
  let child;
  try {
    child = start(file, args, { env, uid, gid, cwd, stdin: true });
  } catch (error) {
    return { exitCode: null, error, stderr: '', timedOut: false };
  }
  // Without stdout the program's output would be lost; it goes to stderr's
  // handler only when it writes there, which tar and mysql do for errors.
  const watch = supervise(child, { timeoutMs, onLine });
  let streamError = null;
  child.stdin.on('error', () => {});
  try {
    await pipeline(createReadStream(source), createGunzip(), child.stdin);
  } catch (err) {
    // EPIPE: the program stopped reading (it failed); its exit says why.
    if (err.code !== 'EPIPE' && err.code !== 'ERR_STREAM_PREMATURE_CLOSE') streamError = err;
    if (err.code === 'Z_DATA_ERROR' || err.code === 'Z_BUF_ERROR') streamError = err;
    watch.kill();
  }
  const result = await watch.done();
  return { ...result, streamError };
}

// SHA-256 and size of a file.
export async function hashFile(source) {
  const hash = createHash('sha256');
  let sizeBytes = 0;
  for await (const chunk of createReadStream(source)) {
    hash.update(chunk);
    sizeBytes += chunk.length;
  }
  return { sizeBytes, sha256: hash.digest('hex') };
}
