import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import { DEFAULT_PATH, runCommand } from './exec.js';

// Backup storage on another server over SFTP, through OpenSSH's own sftp
// client (openssh-client, on every Ubuntu and Debian server). It offers the
// same calls as the S3 client (utils/s3.js), so backups use either alike.
//
// The panel sends the private key and the pinned host key with each job.
// They are written to a fresh folder only root can read, used with
// StrictHostKeyChecking=yes (a changed host key is refused, never accepted),
// and removed when the call ends. The commands go to sftp's batch mode on
// stdin; no shell is involved, and every path is checked beforehand to hold
// only letters, digits, ".", "_", "-" and "/".

export class SftpError extends Error {
  constructor(code, message, { status = null } = {}) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

const SSH_OPTIONS = ['IdentitiesOnly=yes', 'BatchMode=yes', 'StrictHostKeyChecking=yes', 'GlobalKnownHostsFile=/dev/null', 'ConnectTimeout=20', 'ServerAliveInterval=15', 'ServerAliveCountMax=4', 'LogLevel=ERROR'];

function explain(stderr, storage) {
  const text = stderr ?? '';
  const at = `${storage.username}@${storage.host}`;
  if (/Host key verification failed|REMOTE HOST IDENTIFICATION HAS CHANGED|No .* host key is known/i.test(text)) {
    return new SftpError('HOST_KEY_CHANGED', `The host key of ${storage.host} is not the one the panel trusts. If the server was reinstalled on purpose, edit the storage and choose "Trust the server's new host key", then check it again.`);
  }
  if (/Permission denied/i.test(text)) return new SftpError('SFTP_AUTH_FAILED', `${at} refused the panel's key. Add the storage's public key to ~/.ssh/authorized_keys of ${storage.username} on ${storage.host}.`);
  if (/Could not resolve hostname/i.test(text)) return new SftpError('SFTP_HOST_NOT_FOUND', `${storage.host} could not be found (DNS).`);
  if (/Connection refused/i.test(text)) return new SftpError('SFTP_CONNECTION_REFUSED', `Nothing accepts SSH connections on ${storage.host} port ${storage.port}.`);
  if (/timed out/i.test(text)) return new SftpError('SFTP_TIMEOUT', `The connection to ${storage.host} port ${storage.port} timed out. Check that its firewall lets this server in.`);
  if (/subsystem request failed|Connection closed/i.test(text)) return new SftpError('SFTP_UNAVAILABLE', `${storage.host} accepted the key but does not offer SFTP for ${storage.username}.`);
  if (/(not found|No such file)/i.test(text)) return new SftpError('NOT_FOUND', 'The backup is not on the storage server any more.', { status: 404 });
  if (/No space left|Failure|disk quota/i.test(text)) return new SftpError('SFTP_WRITE_FAILED', `The storage server could not write the file (disk full or no permission on the folder): ${lastLine(text)}`);
  return new SftpError('SFTP_FAILED', `sftp failed: ${lastLine(text) || 'no details'}`);
}

function lastLine(text) {
  return (text ?? '').trim().split('\n').filter(Boolean).slice(-1)[0] ?? '';
}

export function hostKeyFingerprint(knownHosts) {
  const line = (knownHosts ?? '').split('\n').find((l) => l.trim());
  const blob = line?.trim().split(/\s+/)[2];
  return blob ? `SHA256:${createHash('sha256').update(Buffer.from(blob, 'base64')).digest('base64').replace(/=+$/, '')}` : null;
}

// run, binDirs and timeoutMs come from the operation's context (tests fake them).
export function createSftpClient(storage, { run = runCommand, binDirs, timeoutMs = 3_600_000 } = {}) {
  const target = storage.host.includes(':') ? `[${storage.host}]` : storage.host;
  const remote = (key) => (storage.path ? `${storage.path.replace(/\/+$/, '')}/${key}` : key);

  async function binary(name) {
    const found = await findBinary(name, binDirs);
    if (!found) throw new SftpError('SFTP_NOT_INSTALLED', `${name} is not installed on this server. Install it with: apt-get install openssh-client`);
    return found;
  }

  // Runs sftp with a batch of commands in a private folder holding the keys.
  async function batch(commands, { timeout = timeoutMs } = {}) {
    if (!storage.knownHosts) throw new SftpError('HOST_KEY_UNKNOWN', 'The storage server’s host key is not known yet. Check the storage once from the Backups > Storage tab first.');
    const sftp = await binary('sftp');
    const dir = await mkdtemp(path.join(tmpdir(), 'vp-sftp-'));
    try {
      const keyFile = path.join(dir, 'id');
      const knownHosts = path.join(dir, 'known_hosts');
      await writeFile(keyFile, storage.privateKey.endsWith('\n') ? storage.privateKey : `${storage.privateKey}\n`, { mode: 0o600 });
      await writeFile(knownHosts, `${storage.knownHosts.trim()}\n`, { mode: 0o600 });
      const args = ['-b', '-', '-F', '/dev/null', '-P', String(storage.port), '-i', keyFile, ...SSH_OPTIONS.flatMap((o) => ['-o', o]), '-o', `UserKnownHostsFile=${knownHosts}`, `${storage.username}@${target}`];
      const result = await run(sftp, args, { input: `${commands.join('\n')}\n`, timeoutMs: timeout, env: { PATH: DEFAULT_PATH, LANG: 'C', HOME: dir } });
      if (result.timedOut) throw new SftpError('SFTP_TIMEOUT', 'The transfer did not finish in time');
      if (result.exitCode !== 0) throw explain(`${result.stderr ?? ''}\n${result.error?.message ?? ''}`, storage);
      return result.stdout ?? '';
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }

  // "-mkdir" for each folder above the file ("-": already there is fine).
  function mkdirs(file) {
    const parts = file.split('/').slice(0, -1);
    const out = [];
    for (let i = 1; i <= parts.length; i += 1) {
      const dir = parts.slice(0, i).join('/');
      if (dir) out.push(`-mkdir "${dir}"`);
    }
    return out;
  }

  async function uploadFile(key, file, { sizeBytes, onProgress = () => {} } = {}) {
    const dest = remote(key);
    // Written under a temporary name, then renamed, so a cut transfer never looks complete.
    await batch([...mkdirs(dest), `put "${file}" "${dest}.partial"`, `-rm "${dest}"`, `rename "${dest}.partial" "${dest}"`]);
    onProgress(sizeBytes);
    return { key, parts: 1 };
  }

  async function headObject(key) {
    let out;
    try {
      out = await batch([`ls -l "${remote(key)}"`], { timeout: 120_000 });
    } catch (err) {
      if (err.status === 404) return { exists: false };
      throw err;
    }
    const line = out.split('\n').find((l) => l.trim() && !l.startsWith('sftp>'));
    const size = Number(line?.trim().split(/\s+/)[4]);
    return Number.isFinite(size) ? { exists: true, sizeBytes: size, sha256: null } : { exists: false };
  }

  async function downloadFile(key, local) {
    await batch([`get "${remote(key)}" "${local}"`]);
    const hash = createHash('sha256');
    let sizeBytes = 0;
    for await (const chunk of createReadStream(local)) {
      hash.update(chunk);
      sizeBytes += chunk.length;
    }
    return { sizeBytes, sha256: hash.digest('hex') };
  }

  async function deleteObject(key) {
    await batch([`-rm "${remote(key)}"`], { timeout: 120_000 });
  }

  // For the storage check: a small file through a local temporary copy.
  async function putObject(key, body) {
    const dir = await mkdtemp(path.join(tmpdir(), 'vp-sftp-put-'));
    try {
      const file = path.join(dir, 'check');
      await writeFile(file, body, { mode: 0o600 });
      await batch([...mkdirs(remote(key)), `put "${file}" "${remote(key)}"`], { timeout: 120_000 });
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }

  async function getObject(key) {
    const dir = await mkdtemp(path.join(tmpdir(), 'vp-sftp-get-'));
    try {
      const file = path.join(dir, 'check');
      await batch([`get "${remote(key)}" "${file}"`], { timeout: 120_000 });
      const chunks = [];
      for await (const chunk of createReadStream(file)) chunks.push(chunk);
      return { body: Buffer.concat(chunks).toString('utf8') };
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }

  // The server's host keys, to pin on the first check.
  async function scanHostKey() {
    const keyscan = await binary('ssh-keyscan');
    const result = await run(keyscan, ['-T', '15', '-p', String(storage.port), '-t', 'ed25519,ecdsa,rsa', storage.host], { timeoutMs: 30_000 });
    const lines = (result.stdout ?? '')
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'))
      .sort((a, b) => Number(!a.includes('ssh-ed25519')) - Number(!b.includes('ssh-ed25519')));
    if (!lines.length) throw explain(result.stderr || 'Connection timed out', storage);
    const knownHosts = lines.slice(0, 3).join('\n');
    return { knownHosts, fingerprint: hostKeyFingerprint(knownHosts) };
  }

  return { uploadFile, headObject, downloadFile, deleteObject, putObject, getObject, scanHostKey };
}
