// Minimal structured logger: one JSON object per line on stdout/stderr, which
// journald captures when the agent runs under systemd.
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

export function createLogger(level = process.env.VAULTPANEL_AGENT_LOG_LEVEL || 'info') {
  const min = LEVELS[level] ?? LEVELS.info;
  const write = (lvl, msg, fields = {}) => {
    if (LEVELS[lvl] < min) return;
    const entry = { time: new Date().toISOString(), level: lvl, msg, ...serialize(fields) };
    (lvl === 'error' || lvl === 'warn' ? process.stderr : process.stdout).write(`${JSON.stringify(entry)}\n`);
  };
  return {
    debug: (msg, f) => write('debug', msg, f),
    info: (msg, f) => write('info', msg, f),
    warn: (msg, f) => write('warn', msg, f),
    error: (msg, f) => write('error', msg, f),
  };
}

function serialize(fields) {
  const out = { ...fields };
  if (out.err instanceof Error) out.err = { message: out.err.message, code: out.err.code, stack: out.err.stack };
  return out;
}
