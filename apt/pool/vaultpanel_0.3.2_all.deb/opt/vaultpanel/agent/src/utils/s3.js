import { createHash, createHmac } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

// A small S3 client for backup storage, built on Node's own http, https and
// crypto (the agent has no dependencies). It speaks the subset of the S3 API
// every S3-compatible service offers (Amazon S3, Backblaze B2, Wasabi,
// Cloudflare R2, MinIO): PUT, GET, HEAD and DELETE of one object, and
// multipart uploads for large files. Requests are signed with AWS
// Signature Version 4, including the SHA-256 of every body, so the service
// rejects a file that changed on the way.

// Files up to this size are sent in one PUT; larger ones in parts.
export const SINGLE_PUT_MAX_BYTES = 256 * 1024 * 1024;
const MIN_PART_BYTES = 64 * 1024 * 1024;
const MAX_PARTS = 9000;
const IDLE_TIMEOUT_MS = 120_000;
const EMPTY_SHA256 = createHash('sha256').update('').digest('hex');

export class S3Error extends Error {
  constructor(code, message, { status = null, retryable = false } = {}) {
    super(message);
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}

// RFC 3986 encoding, as Signature Version 4 wants it.
function encode(value) {
  return encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

const sha256Hex = (data) => createHash('sha256').update(data).digest('hex');
const hmac = (key, data) => createHmac('sha256', key).update(data).digest();

function amzDate(now) {
  return now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

// The URL of an object (or of the bucket, for key ''), path-style or
// virtual-hosted-style.
export function objectUrl(storage, key, query = {}) {
  const endpoint = new URL(storage.endpoint);
  const path = key ? `/${key.split('/').map(encode).join('/')}` : '/';
  const base = storage.pathStyle
    ? `${endpoint.protocol}//${endpoint.host}/${encode(storage.bucket)}${key ? path : ''}`
    : `${endpoint.protocol}//${storage.bucket}.${endpoint.host}${path}`;
  const url = new URL(base);
  const search = Object.keys(query)
    .sort()
    .map((k) => `${encode(k)}=${encode(query[k])}`)
    .join('&');
  return { url, canonicalQuery: search };
}

// The headers of a signed request (Authorization included).
export function signRequest(storage, { method, url, canonicalQuery, headers = {}, payloadHash, now = new Date() }) {
  const date = amzDate(now);
  const day = date.slice(0, 8);
  const region = storage.region || 'us-east-1';
  const all = { ...headers, host: url.host, 'x-amz-content-sha256': payloadHash, 'x-amz-date': date };
  const names = Object.keys(all)
    .map((n) => n.toLowerCase())
    .sort();
  const lower = Object.fromEntries(Object.entries(all).map(([k, v]) => [k.toLowerCase(), String(v).trim().replace(/\s+/g, ' ')]));
  const canonicalHeaders = names.map((n) => `${n}:${lower[n]}\n`).join('');
  const signedHeaders = names.join(';');
  const canonicalRequest = [method, url.pathname, canonicalQuery, canonicalHeaders, signedHeaders, payloadHash].join('\n');
  const scope = `${day}/${region}/s3/aws4_request`;
  const stringToSign = ['AWS4-HMAC-SHA256', date, scope, sha256Hex(canonicalRequest)].join('\n');
  const key = hmac(hmac(hmac(hmac(`AWS4${storage.secretAccessKey}`, day), region), 's3'), 'aws4_request');
  const signature = createHmac('sha256', key).update(stringToSign).digest('hex');
  return {
    ...Object.fromEntries(Object.entries(all).filter(([n]) => n !== 'host')),
    authorization: `AWS4-HMAC-SHA256 Credential=${storage.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
  };
}

function xmlValue(xml, tag) {
  const match = new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`).exec(xml ?? '');
  return match ? match[1].replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&') : null;
}

// Plain-language messages for what S3 services answer most often.
const FRIENDLY = {
  AccessDenied: 'The storage refused access. Check that the key may read, write and delete objects in this bucket.',
  InvalidAccessKeyId: 'The access key ID is not known to the storage service.',
  SignatureDoesNotMatch: 'The secret access key is wrong (the storage could not verify the request signature).',
  NoSuchBucket: 'The bucket does not exist at this endpoint. Check its name, the region and the endpoint.',
  PermanentRedirect: 'The bucket is in another region. Use the endpoint of the region it was created in.',
  AuthorizationHeaderMalformed: 'The region does not match the bucket. Use the region the bucket was created in.',
  RequestTimeTooSkewed: 'This server’s clock is too far off for the storage to accept requests. Turn on time sync (timedatectl set-ntp true).',
  NoSuchKey: 'The backup is not in the storage any more.',
  EntityTooLarge: 'The storage refused a file this large.',
  QuotaExceeded: 'The storage account is full or over its quota.',
};

function responseError(status, body) {
  const code = xmlValue(body, 'Code') ?? (status === 404 ? 'NoSuchKey' : status === 403 ? 'AccessDenied' : `HTTP${status}`);
  const message = FRIENDLY[code] ?? xmlValue(body, 'Message') ?? `The storage answered HTTP ${status}`;
  return new S3Error(code, `${message} (${code})`, { status, retryable: status >= 500 || status === 429 || code === 'RequestTimeout' });
}

function networkError(err, url) {
  if (err instanceof S3Error) return err;
  const messages = {
    ENOTFOUND: `The storage endpoint ${url.host} could not be found (DNS).`,
    ECONNREFUSED: `Nothing answered at ${url.host}.`,
    ETIMEDOUT: `The connection to ${url.host} timed out.`,
    ECONNRESET: `The connection to ${url.host} was reset.`,
    CERT_HAS_EXPIRED: `The certificate of ${url.host} has expired.`,
    DEPTH_ZERO_SELF_SIGNED_CERT: `${url.host} uses a self-signed certificate, which is not trusted.`,
    SELF_SIGNED_CERT_IN_CHAIN: `${url.host} uses a certificate this server does not trust.`,
    ERR_TLS_CERT_ALTNAME_INVALID: `The certificate of ${url.host} is not valid for that name. With a custom endpoint, try path-style URLs.`,
  };
  return new S3Error(err.code ?? 'NETWORK_ERROR', messages[err.code] ?? `Could not reach the storage: ${err.message}`, { retryable: true });
}

// Sends one signed request. body: a Buffer, a function returning a fresh
// readable stream, or nothing. With sink, a 2xx body is piped into it.
// transport, singlePutMaxBytes and minPartBytes are for tests.
export function createS3Client(storage, { transport, singlePutMaxBytes = SINGLE_PUT_MAX_BYTES, minPartBytes = MIN_PART_BYTES } = {}) {
  function send({ method, key = '', query = {}, headers = {}, body, payloadHash, contentLength, sink }) {
    const { url, canonicalQuery } = objectUrl(storage, key, query);
    const hash = payloadHash ?? (Buffer.isBuffer(body) ? sha256Hex(body) : EMPTY_SHA256);
    const length = contentLength ?? (Buffer.isBuffer(body) ? body.length : 0);
    const signed = signRequest(storage, { method, url, canonicalQuery, headers: { ...headers, 'content-length': length }, payloadHash: hash });
    const requestFn = transport ?? (url.protocol === 'http:' ? http.request : https.request);
    const target = `${url.pathname}${canonicalQuery ? `?${canonicalQuery}` : ''}`;
    return new Promise((resolve, reject) => {
      let settled = false;
      const done = (fn, value) => {
        if (settled) return;
        settled = true;
        fn(value);
      };
      const req = requestFn({ method, protocol: url.protocol, hostname: url.hostname, port: url.port || undefined, path: target, headers: signed, timeout: IDLE_TIMEOUT_MS }, (res) => {
        const status = res.statusCode;
        if (sink && status >= 200 && status < 300) {
          pipeline(res, sink)
            .then(() => done(resolve, { status, headers: res.headers, body: '' }))
            .catch((err) => done(reject, networkError(err, url)));
          return;
        }
        const chunks = [];
        let size = 0;
        res.on('data', (chunk) => {
          if (size < 256 * 1024) chunks.push(chunk);
          size += chunk.length;
        });
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          if (status >= 200 && status < 300) done(resolve, { status, headers: res.headers, body: text });
          else done(reject, responseError(status, method === 'HEAD' ? '' : text));
        });
        res.on('error', (err) => done(reject, networkError(err, url)));
      });
      req.on('timeout', () => req.destroy(Object.assign(new Error('timed out'), { code: 'ETIMEDOUT' })));
      req.on('error', (err) => done(reject, networkError(err, url)));
      if (typeof body === 'function') {
        pipeline(body(), req).catch((err) => {
          req.destroy();
          done(reject, networkError(err, url));
        });
      } else {
        req.end(body ?? undefined);
      }
    });
  }

  // Retries what may succeed on a second try (5xx, 429, a dropped connection).
  async function withRetry(fn, attempts = 3) {
    let last;
    for (let i = 0; i < attempts; i += 1) {
      try {
        return await fn();
      } catch (err) {
        last = err;
        if (!err.retryable || i === attempts - 1) throw err;
        await new Promise((r) => setTimeout(r, 1000 * 2 ** i));
      }
    }
    throw last;
  }

  async function putObject(key, body, { sha256 } = {}) {
    return withRetry(() => send({ method: 'PUT', key, body, payloadHash: sha256, headers: { 'content-type': 'application/octet-stream' } }));
  }

  async function getObject(key) {
    return withRetry(() => send({ method: 'GET', key }));
  }

  async function headObject(key) {
    try {
      const res = await withRetry(() => send({ method: 'HEAD', key }));
      return { exists: true, sizeBytes: Number(res.headers['content-length'] ?? 0), sha256: res.headers['x-amz-meta-sha256'] ?? null };
    } catch (err) {
      if (err.status === 404) return { exists: false };
      throw err;
    }
  }

  async function deleteObject(key) {
    try {
      await withRetry(() => send({ method: 'DELETE', key }));
    } catch (err) {
      if (err.status !== 404) throw err;
    }
  }

  // Hash of a byte range of a file (for a part's signature).
  async function hashRange(file, start, end) {
    const hash = createHash('sha256');
    for await (const chunk of createReadStream(file, { start, end })) hash.update(chunk);
    return hash.digest('hex');
  }

  // Uploads a file. sha256 is the whole file's checksum, kept as metadata.
  async function uploadFile(key, file, { sizeBytes, sha256, onProgress = () => {} }) {
    const meta = { 'content-type': 'application/octet-stream', 'x-amz-meta-sha256': sha256 };
    if (sizeBytes <= singlePutMaxBytes) {
      await withRetry(() => send({ method: 'PUT', key, headers: meta, body: () => createReadStream(file), payloadHash: sha256, contentLength: sizeBytes }));
      onProgress(sizeBytes);
      return { key, parts: 1 };
    }
    const partBytes = Math.max(minPartBytes, Math.ceil(sizeBytes / MAX_PARTS));
    const created = await withRetry(() => send({ method: 'POST', key, query: { uploads: '' }, headers: meta }));
    const uploadId = xmlValue(created.body, 'UploadId');
    if (!uploadId) throw new S3Error('BAD_RESPONSE', 'The storage did not start the upload (no UploadId in its answer)');
    const parts = [];
    try {
      for (let start = 0, number = 1; start < sizeBytes; start += partBytes, number += 1) {
        const end = Math.min(start + partBytes, sizeBytes) - 1;
        const partHash = await hashRange(file, start, end);
        const res = await withRetry(() =>
          send({ method: 'PUT', key, query: { partNumber: String(number), uploadId }, body: () => createReadStream(file, { start, end }), payloadHash: partHash, contentLength: end - start + 1 }),
        );
        const etag = res.headers.etag;
        if (!etag) throw new S3Error('BAD_RESPONSE', `The storage did not confirm part ${number}`);
        parts.push({ number, etag });
        onProgress(end + 1);
      }
      const xml = `<CompleteMultipartUpload>${parts.map((p) => `<Part><PartNumber>${p.number}</PartNumber><ETag>${p.etag.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</ETag></Part>`).join('')}</CompleteMultipartUpload>`;
      const done = await withRetry(() => send({ method: 'POST', key, query: { uploadId }, body: Buffer.from(xml), headers: { 'content-type': 'application/xml' } }));
      // S3 can answer 200 and still report an error in the body.
      if (/<Error>/.test(done.body)) throw responseError(500, done.body);
      return { key, parts: parts.length };
    } catch (err) {
      await send({ method: 'DELETE', key, query: { uploadId } }).catch(() => {});
      throw err;
    }
  }

  // Downloads an object into a file and returns its size and SHA-256.
  async function downloadFile(key, target) {
    return withRetry(async () => {
      const hash = createHash('sha256');
      let sizeBytes = 0;
      const measure = new Transform({
        transform(chunk, _enc, cb) {
          hash.update(chunk);
          sizeBytes += chunk.length;
          cb(null, chunk);
        },
      });
      const out = createWriteStream(target, { mode: 0o600 });
      const writing = pipeline(measure, out);
      try {
        await send({ method: 'GET', key, sink: measure });
        await writing;
      } catch (err) {
        measure.destroy();
        await writing.catch(() => {});
        throw err;
      }
      return { sizeBytes, sha256: hash.digest('hex') };
    });
  }

  return { send, putObject, getObject, headObject, deleteObject, uploadFile, downloadFile };
}
