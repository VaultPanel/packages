#!/usr/bin/env node
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { DEFAULT_CONFIG_PATH, loadConfig, saveSecretFile, withDefaults } from './config.js';
import { collectFilesystems, collectSystemInfo, createMetricsSampler } from './monitoring/system.js';
import { readServiceStates } from './monitoring/services.js';
import { DEFAULT_WATCH_SERVICES } from './security/policy.js';
import { generateAgentKeyPair } from './security/signing.js';
import { assertSecureUrl, createPanelClient } from './services/panelClient.js';
import { startAgent } from './services/agent.js';
import { AGENT_USER, ensureAgentAccess, ensureAgentUser, HELPER_SOCKET, restartAfterVersionChange, switchBlocker, switchToOwnUser, watchAgent } from './services/agentMode.js';
import { startHelper } from './services/helper.js';
import { createPrivileged } from './services/privileged.js';
import { readCronSpec, runCron, savePendingRun } from './services/cronRunner.js';
import { addChallenge, removeChallenge } from './services/acmeDns.js';
import { runCommand } from './utils/exec.js';
import { createLogger } from './utils/logger.js';
import { AGENT_VERSION } from './utils/version.js';

const USAGE = `vaultpanel-agent ${AGENT_VERSION}

Usage:
  vaultpanel-agent register --panel <url> --token <enrollment token> [--config <path>] [--insecure-http]
  vaultpanel-agent run [--config <path>]
  vaultpanel-agent helper [--config <path>]         The root helper (vaultpanel-agent-helper.service)
  vaultpanel-agent cron-run <id> [--config <path>]  Run a cron job (used by /etc/cron.d/vaultpanel)
  vaultpanel-agent acme-dns-hook auth|cleanup [vp-<site>] [--config <path>]  Let's Encrypt DNS check (run by Certbot)
  vaultpanel-agent status         Print one telemetry snapshot (no panel needed)
  vaultpanel-agent version`;

const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: {
    panel: { type: 'string' },
    token: { type: 'string' },
    config: { type: 'string', default: DEFAULT_CONFIG_PATH },
    'insecure-http': { type: 'boolean', default: false },
    help: { type: 'boolean', short: 'h', default: false },
  },
});

const logger = createLogger();
const command = positionals[0];

try {
  if (values.help || !command) console.log(USAGE);
  else if (command === 'version') console.log(AGENT_VERSION);
  else if (command === 'status') await status();
  else if (command === 'register') await register();
  else if (command === 'run') await runAgent();
  else if (command === 'helper') await runHelper();
  else if (command === 'cron-run') await cronRun(positionals[1]);
  else if (command === 'acme-dns-hook') await acmeDnsHook(positionals[1], positionals[2]);
  else {
    console.error(`Unknown command "${command}"\n\n${USAGE}`);
    process.exitCode = 2;
  }
} catch (err) {
  logger.error(err.message, { code: err.code });
  process.exitCode = 1;
}

async function register() {
  if (!values.panel || !values.token) throw new Error('register needs --panel and --token');
  assertSecureUrl(values.panel, values['insecure-http']);
  const keys = generateAgentKeyPair();
  const client = createPanelClient({
    panelUrl: values.panel,
    agentId: 'unregistered',
    privateKeyPem: keys.privateKeyPem,
    allowInsecureHttp: values['insecure-http'],
  });
  const result = await client.register({
    enrollmentToken: values.token,
    publicKey: keys.publicKeyPem,
    agentVersion: AGENT_VERSION,
    system: await collectSystemInfo(),
  });
  const configDir = path.dirname(values.config);
  const privateKeyPath = path.join(configDir, 'agent.key');
  await saveSecretFile(privateKeyPath, keys.privateKeyPem);
  const config = withDefaults({
    panelUrl: values.panel.replace(/\/+$/, ''),
    agentId: result.agentId,
    serverId: result.serverId,
    panelPublicKey: result.panelPublicKey,
    privateKeyPath,
    heartbeatIntervalSeconds: result.heartbeatIntervalSeconds,
    allowInsecureHttp: values['insecure-http'],
  });
  await saveSecretFile(values.config, `${JSON.stringify(config, null, 2)}\n`);
  logger.info('registered with panel', { serverId: result.serverId, agentId: result.agentId, config: values.config });
}

async function runAgent() {
  const configPath = path.resolve(values.config);
  const config = { ...(await loadConfig(configPath)), configPath };
  if (process.getuid?.() === 0) {
    // As root under systemd, the agent moves itself to its own user (0.36.0).
    const blocker = await switchBlocker(config);
    const outcome = blocker ? { switched: false, reason: blocker } : await switchToOwnUser(config, { configPath, logger });
    if (outcome.switched) {
      // systemd stops this process now; if it does not, carry on as root.
      await new Promise((r) => setTimeout(r, 60_000));
      outcome.reason = 'systemd did not restart the agent as its own user';
    }
    if (!blocker) logger.warn('the agent runs as root', { reason: outcome.reason });
    config.agentMode = { user: 'root', reason: outcome.reason };
  } else {
    config.helperSocket ??= existsSync(HELPER_SOCKET) ? HELPER_SOCKET : undefined;
    config.agentMode = { user: os.userInfo().username, reason: config.helperSocket ? null : 'no root helper is running, so the agent can only report' };
  }
  await startAgent(config, logger);
}

// The root helper (0.36.0; see services/helper.js).
async function runHelper() {
  if (process.getuid?.() !== 0) throw new Error('The helper must run as root');
  const configPath = path.resolve(values.config);
  const config = { ...(await loadConfig(configPath)), configPath, agentMode: { user: AGENT_USER, reason: null } };
  const { uid, gid } = await ensureAgentUser();
  // The panel may have rewritten the config (its own server's agent).
  await ensureAgentAccess(config, configPath, uid, gid);
  const watch = await watchAgent(config, { logger });
  const privileged = createPrivileged(config, logger);
  privileged.started();
  await startHelper(config, logger, {
    socketPath: config.helperSocket ?? HELPER_SOCKET,
    groupId: gid,
    privileged,
    onAlive: watch.alive,
    // After an agent update (or rollback) both services start again on the new code.
    exitProcess: () => restartAfterVersionChange(config, { logger }),
  });
}

// Started by cron: runs the job as its site or app user and keeps the result
// for the agent to report.
async function cronRun(id) {
  if (!id || !/^[0-9a-f-]{36}$/.test(id)) throw new Error('cron-run needs a cron job id');
  const config = await loadConfig(values.config);
  const spec = await readCronSpec(config, id);
  if (!spec || !spec.enabled) return;
  const run = await runCron(spec, { policy: config, trigger: 'schedule' });
  await savePendingRun(config, run);
  if (run.status !== 'succeeded') process.exitCode = 1;
}

// Run by Certbot for wildcard certificates (see services/acmeDns.js), with
// the name and value in CERTBOT_DOMAIN and CERTBOT_VALIDATION.
// certName (vp-<site>, 0.38.0) is given when the certificate is checked
// through a DNS provider; without it the record goes into this server's zone.
async function acmeDnsHook(step, certName) {
  if (!['auth', 'cleanup'].includes(step)) throw new Error('acme-dns-hook needs auth or cleanup');
  const config = await loadConfig(values.config);
  const ctx = { policy: config, run: runCommand, binDirs: config.binDirs, log: () => {} };
  const domain = process.env.CERTBOT_DOMAIN;
  const value = process.env.CERTBOT_VALIDATION;
  const options = { certName: certName || null };
  if (step === 'auth') {
    const result = await addChallenge(ctx, domain, value, options);
    const where = result.provider ? `at ${result.provider} (${result.zone})` : `to the ${result.zone} zone`;
    console.error(`Added the Let's Encrypt check record for ${domain} ${where}`);
    if (result.served === false) console.error(`The name servers of ${result.zone} do not answer with it yet; asking Let's Encrypt anyway`);
  } else {
    await removeChallenge(ctx, domain, value, options);
  }
}

async function status() {
  const sampler = createMetricsSampler();
  await new Promise((r) => setTimeout(r, 500));
  const [system, metrics, services, filesystems] = await Promise.all([
    collectSystemInfo(),
    sampler.sample(),
    readServiceStates(DEFAULT_WATCH_SERVICES),
    collectFilesystems(),
  ]);
  console.log(JSON.stringify({ version: AGENT_VERSION, system, metrics, services, filesystems }, null, 2));
}
