import { mkdir } from 'node:fs/promises';
import { appNodeDir, BIN_DIRS, detectWebStack, findBinary, NODE_IN_HOME_MESSAGE } from '../monitoring/web.js';
import { onlyKeys, OperationError } from './errors.js';
import { openWebPorts, readFirewall } from './firewall.js';
import { installApache } from './apache.js';

// Installs server software from the distribution's packages (and PM2 from
// npm). Only these fixed package lists can be installed.
export const WEB_STACK_PACKAGES = {
  nginx: ['nginx'],
  php: ['php-fpm', 'php-cli', 'php-mysql', 'php-curl', 'php-gd', 'php-mbstring', 'php-xml', 'php-zip', 'php-intl'],
  certbot: ['certbot'],
  git: ['git', 'openssh-client'],
  python: ['python3', 'python3-venv', 'python3-pip'],
  go: ['golang-go'],
  // build-essential and ruby-dev (in ruby-full) build gems with native code.
  ruby: ['ruby-full', 'ruby-bundler', 'build-essential'],
  composer: ['composer', 'php-cli', 'unzip'],
  mariadb: ['mariadb-server', 'mariadb-client'],
  cron: ['cron'],
};
// Installed and set up on its own (see apache.js).
const SPECIAL = ['apache'];
// Installed with npm, next to the Node.js the agent runs on.
export const NPM_PACKAGES = { pm2: ['pm2@6'] };
const COMPONENTS = [...Object.keys(WEB_STACK_PACKAGES), ...Object.keys(NPM_PACKAGES), ...SPECIAL];

export const APT_ENV = {
  PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
  LANG: 'C',
  DEBIAN_FRONTEND: 'noninteractive',
};

export async function aptInstall(ctx, packages, remaining, { keepConfig = false } = {}) {
  if (!(await findBinary('apt-get', ctx.binDirs))) {
    throw new OperationError('UNSUPPORTED_SYSTEM', 'Installing software needs apt (Ubuntu or Debian). Install the packages with your distribution’s tools instead.');
  }
  ctx.log('stdout', '$ apt-get update');
  const update = await ctx.run('apt-get', ['-o', 'DPkg::Lock::Timeout=120', 'update'], { timeoutMs: remaining(), onLine: ctx.log, env: APT_ENV });
  if (update.timedOut) throw new OperationError('TIMEOUT', 'apt-get update did not finish in time');
  if (update.exitCode !== 0) ctx.log('stderr', 'apt-get update reported problems; trying the install anyway');

  ctx.log('stdout', `$ apt-get install ${packages.join(' ')}`);
  const install = await ctx.run(
    'apt-get',
    [
      '-o',
      'DPkg::Lock::Timeout=120',
      // Keep configuration files VaultPanel wrote before the install.
      ...(keepConfig ? ['-o', 'Dpkg::Options::=--force-confdef', '-o', 'Dpkg::Options::=--force-confold'] : []),
      'install',
      '--yes',
      '--no-install-recommends',
      ...packages,
    ],
    { timeoutMs: remaining(), onLine: ctx.log, env: APT_ENV },
  );
  if (install.timedOut) throw new OperationError('TIMEOUT', 'apt-get install did not finish in time');
  if (install.error || install.exitCode !== 0) {
    const detail = (install.stderr || '').trim().split('\n').slice(-6).join('\n');
    throw new OperationError('INSTALL_FAILED', `apt-get could not install the packages${detail ? `:\n${detail}` : ''}`);
  }
}

async function npmInstall(ctx, packages, remaining) {
  const nodeDir = appNodeDir(ctx.policy);
  if (!nodeDir) throw new OperationError('NODE_IN_HOME_FOLDER', NODE_IN_HOME_MESSAGE);
  const npm = await findBinary('npm', [nodeDir, ...(ctx.binDirs ?? BIN_DIRS)]);
  if (!npm) {
    throw new OperationError('NPM_NOT_INSTALLED', `npm is not installed next to Node.js (${nodeDir}). Install Node.js with npm (for example from NodeSource) to install PM2.`);
  }
  // The agent's service keeps home folders read-only, so npm gets its own
  // cache folder (its logs go there too).
  const cache = ctx.policy.npmCacheDir ?? '/var/cache/vaultpanel/npm';
  await mkdir(cache, { recursive: true, mode: 0o700 });
  ctx.log('stdout', `$ npm install --global ${packages.join(' ')}`);
  const result = await ctx.run(npm, ['install', '--global', '--no-audit', '--no-fund', ...packages], {
    timeoutMs: remaining(),
    onLine: ctx.log,
    env: { ...APT_ENV, PATH: `${nodeDir}:${APT_ENV.PATH}`, HOME: '/root', npm_config_cache: cache, npm_config_update_notifier: 'false' },
  });
  if (result.timedOut) throw new OperationError('TIMEOUT', 'npm install did not finish in time');
  if (result.error || result.exitCode !== 0) {
    const detail = (result.stderr || '').trim().split('\n').slice(-6).join('\n');
    throw new OperationError('INSTALL_FAILED', `npm could not install ${packages.join(', ')}${detail ? `:\n${detail}` : ''}`);
  }
}

export const WEB_STACK_OPERATIONS = {
  WEB_STACK_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, ['components']);
      const { components } = params;
      if (!Array.isArray(components) || !components.length || components.some((c) => !COMPONENTS.includes(c)) || new Set(components).size !== components.length) {
        throw new OperationError('INVALID_PARAMS', `components must list some of: ${COMPONENTS.join(', ')}`);
      }
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());

      const packages = components.flatMap((c) => WEB_STACK_PACKAGES[c] ?? []);
      if (packages.length) await aptInstall(ctx, packages, remaining);
      const npmPackages = components.flatMap((c) => NPM_PACKAGES[c] ?? []);
      if (npmPackages.length) await npmInstall(ctx, npmPackages, remaining);
      if (components.includes('apache')) await installApache(ctx, remaining);

      const webStack = await detectWebStack(ctx.policy, ctx.binDirs);
      // With the firewall already on, a new NGINX would be unreachable.
      if (components.includes('nginx') && webStack.nginx) {
        const ufw = await findBinary('ufw', ctx.binDirs);
        try {
          if (ufw && (await readFirewall(ctx)).active && (await openWebPorts(ctx, ufw))) ctx.log('stdout', 'The firewall is on: opened ports 80 and 443 for websites');
        } catch (err) {
          ctx.log('stderr', `Could not open ports 80 and 443 in the firewall (${err.message}). Add a rule for them on the Firewall page.`);
        }
      }
      ctx.webInventory?.invalidate();
      ctx.log(
        'stdout',
        `Installed. NGINX: ${yes(webStack.nginx)}, PHP-FPM: ${webStack.phpVersions.join(', ') || 'none'}, Certbot: ${yes(webStack.certbot)}, Git: ${yes(webStack.git)}, PM2: ${yes(webStack.pm2)}, Python: ${webStack.python ?? 'no'}, Go: ${yes(webStack.go)}, Ruby: ${yes(webStack.ruby)}, Composer: ${yes(webStack.composer)}, MariaDB: ${yes(webStack.mariadb)}, Apache: ${yes(webStack.apache)}`,
      );
      return { output: { components, packages: [...packages, ...npmPackages, ...(components.includes('apache') ? ['apache2'] : [])], webStack } };
    },
  },
};

const yes = (v) => (v ? 'yes' : 'no');
