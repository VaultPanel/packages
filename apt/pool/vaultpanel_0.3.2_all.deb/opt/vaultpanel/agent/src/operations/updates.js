import { access, chmod, readFile, rename, writeFile } from 'node:fs/promises';
import { findBinary } from '../monitoring/web.js';
import { onlyKeys, OperationError } from './errors.js';
import { APT_ENV } from './webStack.js';

// Automatic security updates (unattended-upgrades) and the updates still
// waiting. Counting waiting updates reads the package lists, which takes a
// few seconds, so the count is kept for a while.

const COUNT_TTL_MS = 6 * 3600_000;
let pendingCache = { at: 0, value: null };

export function resetPendingCache() {
  pendingCache = { at: 0, value: null };
}

const periodicFile = (policy) => policy.autoUpgradesFile ?? '/etc/apt/apt.conf.d/20auto-upgrades';

export function parsePeriodic(text) {
  const on = (key) => new RegExp(`^\\s*APT::Periodic::${key}\\s+"(\\d+)"`, 'm').exec(text ?? '')?.[1];
  return Number(on('Unattended-Upgrade') ?? 0) > 0 && Number(on('Update-Package-Lists') ?? 0) > 0;
}

export function renderPeriodic(enabled) {
  const v = enabled ? '1' : '0';
  return `// Written by VaultPanel.\nAPT::Periodic::Update-Package-Lists "${v}";\nAPT::Periodic::Unattended-Upgrade "${v}";\n`;
}

// `apt-get -s upgrade` lists each upgrade as "Inst <pkg> [old] (new <suites>)".
export function countSimulatedUpgrades(text) {
  const lines = (text ?? '').split('\n').filter((l) => l.startsWith('Inst '));
  return { total: lines.length, security: lines.filter((l) => /-security\b/.test(l)).length };
}

async function countPending(ctx, { refresh = false } = {}) {
  if (!refresh && pendingCache.value && Date.now() - pendingCache.at < COUNT_TTL_MS) return pendingCache.value;
  if (!(await findBinary('apt-get', ctx.binDirs))) return null;
  const result = await ctx.run('apt-get', ['-s', '-o', 'Debug::NoLocking=true', 'upgrade'], { timeoutMs: 60_000, env: APT_ENV, maxOutputBytes: 8 * 1024 * 1024 });
  if (result.exitCode !== 0) return pendingCache.value;
  pendingCache = { at: Date.now(), value: { ...countSimulatedUpgrades(result.stdout), checkedAt: new Date().toISOString() } };
  return pendingCache.value;
}

export async function readUpdates(ctx, { refresh = false, count = true } = {}) {
  if (!(await findBinary('apt-get', ctx.binDirs))) return { supported: false };
  const [binary, periodic] = await Promise.all([findBinary('unattended-upgrade', ctx.binDirs), readFile(periodicFile(ctx.policy), 'utf8').catch(() => null)]);
  const rebootRequired = await access(ctx.policy.rebootRequiredFile ?? '/var/run/reboot-required').then(() => true, () => false);
  const pending = count ? await countPending(ctx, { refresh }) : pendingCache.value;
  return {
    supported: true,
    installed: Boolean(binary),
    automatic: Boolean(binary) && parsePeriodic(periodic),
    rebootRequired,
    pendingTotal: pending?.total ?? null,
    pendingSecurity: pending?.security ?? null,
    pendingCheckedAt: pending?.checkedAt ?? null,
  };
}

export const UPDATE_OPERATIONS = {
  AUTO_UPDATES_CONFIGURE: {
    async run(params, ctx) {
      onlyKeys(params, ['enabled']);
      if (typeof params.enabled !== 'boolean') throw new OperationError('INVALID_PARAMS', 'enabled must be true or false');
      if (ctx.policy.allowUpdates === false) throw new OperationError('NOT_ALLOWED', 'Update changes are disabled in this agent config');
      if (params.enabled && !(await findBinary('unattended-upgrade', ctx.binDirs))) {
        throw new OperationError('NOT_INSTALLED', 'unattended-upgrades is not installed. Install it from the Security software card first.');
      }
      const file = periodicFile(ctx.policy);
      ctx.log('stdout', `Writing ${file}`);
      const tmp = `${file}.tmp-${process.pid}`;
      await writeFile(tmp, renderPeriodic(params.enabled), { mode: 0o644 });
      await chmod(tmp, 0o644);
      await rename(tmp, file);
      ctx.webInventory?.invalidate();
      return { output: { updates: await readUpdates(ctx, { count: false }) } };
    },
  },

  SECURITY_UPDATES_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, []);
      if (ctx.policy.allowUpdates === false) throw new OperationError('NOT_ALLOWED', 'Update changes are disabled in this agent config');
      const binary = await findBinary('unattended-upgrade', ctx.binDirs);
      if (!binary) throw new OperationError('NOT_INSTALLED', 'unattended-upgrades is not installed. Install it from the Security software card first.');
      ctx.log('stdout', '$ apt-get update');
      await ctx.run('apt-get', ['-o', 'DPkg::Lock::Timeout=120', 'update'], { timeoutMs: 600_000, onLine: ctx.log, env: APT_ENV });
      // unattended-upgrade installs only what its configuration allows:
      // security updates, by default.
      ctx.log('stdout', '$ unattended-upgrade --verbose');
      const result = await ctx.run(binary, ['--verbose'], { timeoutMs: Math.max(60_000, ctx.timeoutMs - 660_000), onLine: ctx.log, env: APT_ENV, maxOutputBytes: 4 * 1024 * 1024 });
      if (result.timedOut) throw new OperationError('TIMEOUT', 'Installing updates did not finish in time');
      if (result.exitCode !== 0) throw new OperationError('UPDATE_FAILED', `unattended-upgrade failed: ${(result.stderr || result.stdout).trim().split('\n').slice(-5).join('\n')}`);
      ctx.webInventory?.invalidate();
      return { output: { updates: await readUpdates(ctx, { refresh: true }) } };
    },
  },
};
