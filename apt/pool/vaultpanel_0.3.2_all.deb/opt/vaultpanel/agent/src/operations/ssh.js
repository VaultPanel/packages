import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { constants } from 'node:fs';
import { chmod, lstat, mkdir, open, readFile, rename, rm, writeFile } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readServiceStates } from '../monitoring/services.js';
import { findBinary } from '../monitoring/web.js';
import {
  SSH_FINGERPRINT_PATTERN,
  SSH_KEY_TYPES,
  SSH_MAX_AUTH_TRIES_MAX,
  SSH_MAX_AUTH_TRIES_MIN,
  SSH_MAX_PORTS,
  SSH_PUBLIC_KEY_PATTERN,
  SSH_RESERVED_PORTS,
  SSH_ROOT_LOGIN_KEYS,
  SSH_USER_PATTERN,
} from '../security/securityRules.js';
import { needsHostNamespace } from '../services/terminal.js';
import { onlyKeys, OperationError } from './errors.js';
import { updateJailPorts } from './fail2ban.js';
import { readFirewall, portOpenToAll, ufwRun } from './firewall.js';

// SSH settings, the ports SSH listens on, and the SSH keys of root and the
// server's other login accounts.
//
// Settings go into one drop-in file that sshd reads before its own config
// (sshd keeps the first value it sees), so they win over the distribution's
// defaults and cloud-init's. Every change is tested with `sshd -t` and
// checked against `sshd -T` before sshd reloads; on any failure the previous
// file comes back.
//
// Lockout guard: a change (or removing a key) is refused unless someone can
// still sign in afterwards as an administrator: root with a key or a
// password, or a sudo user with a key or a password.
//
// Moving SSH to another port (0.34.0) opens the new port in the firewall
// first, and is only kept once sshd answers on every port it should; on any
// failure the previous ports come back. SSH can listen on two ports at once,
// so the old one can stay until someone has signed in on the new one.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const ENV = { PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', LANG: 'C' };
export const SSH_HEADER = '# Managed by VaultPanel. Changes made here are replaced from the panel.';
const ADMIN_GROUPS = new Set(['sudo', 'admin', 'wheel']);
const KEYS_WORKER = path.join(path.dirname(fileURLToPath(import.meta.url)), '../services/keysWorker.js');
const KEEP_SSH_COMMENT = 'VaultPanel: keep SSH reachable';

function sshPaths(policy) {
  const configDir = policy.sshConfigDir ?? '/etc/ssh';
  return {
    mainConfig: path.join(configDir, 'sshd_config'),
    dropIn: path.join(configDir, 'sshd_config.d', '00-vaultpanel.conf'),
    rootKeys: policy.rootAuthorizedKeys ?? '/root/.ssh/authorized_keys',
    passwd: policy.passwdFile ?? '/etc/passwd',
    group: policy.groupFile ?? '/etc/group',
    shadow: policy.shadowFile ?? '/etc/shadow',
  };
}

const readText = (file) => readFile(file, 'utf8').catch(() => null);

// `sshd -T` prints every effective setting as "<lowercase name> <value>".
export function parseSshdT(text) {
  const values = {};
  const ports = [];
  for (const line of (text ?? '').split('\n')) {
    const i = line.indexOf(' ');
    if (i <= 0) continue;
    const key = line.slice(0, i);
    const value = line.slice(i + 1).trim();
    if (key === 'port') ports.push(Number(value));
    else if (!(key in values)) values[key] = value;
  }
  const rootLogin = values.permitrootlogin === 'without-password' ? 'prohibit-password' : (values.permitrootlogin ?? 'prohibit-password');
  return {
    ports: ports.filter((p) => p > 0 && p < 65536),
    permitRootLogin: rootLogin,
    passwordAuthentication: values.passwordauthentication !== 'no',
    keyboardInteractive: values.kbdinteractiveauthentication === 'yes',
    pubkeyAuthentication: values.pubkeyauthentication !== 'no',
    maxAuthTries: Number(values.maxauthtries ?? 6),
  };
}

// The key blob's SHA256 fingerprint, as `ssh-keygen -l` prints it.
export function keyFingerprint(blob) {
  return `SHA256:${createHash('sha256').update(Buffer.from(blob, 'base64')).digest('base64').replace(/=+$/, '')}`;
}

// The keys in an authorized_keys file. Lines with options in front of the
// key (from="…", command="…") are listed too, flagged as restricted.
export function parseAuthorizedKeys(text) {
  const keys = [];
  for (const [index, raw] of (text ?? '').split('\n').entries()) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const tokens = line.split(/\s+/);
    const at = tokens.findIndex((t) => SSH_KEY_TYPES.includes(t));
    if (at < 0 || !tokens[at + 1]) continue;
    keys.push({
      line: index,
      type: tokens[at],
      fingerprint: keyFingerprint(tokens[at + 1]),
      comment: tokens.slice(at + 2).join(' ').slice(0, 100),
      restricted: at > 0,
    });
  }
  return keys;
}

// Reads a key file without following a symbolic link at the file or its
// folder: another account's keys are read as root, and that account could
// otherwise point them at any file on the server.
export async function readKeysFile(file) {
  try {
    if (!(await lstat(path.dirname(file))).isDirectory()) return '';
    const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      if (!(await handle.stat()).isFile()) return '';
      return (await handle.readFile('utf8')).slice(0, 256 * 1024);
    } finally {
      await handle.close();
    }
  } catch {
    return '';
  }
}

// Accounts people can sign in to over SSH: root, and accounts with a uid of
// 1000 or more and a login shell (website and app users have none).
// admin: a member of sudo, admin or wheel. hasPassword reads /etc/shadow.
export async function readLoginAccounts(policy) {
  const p = sshPaths(policy);
  const [passwd, group, shadow] = await Promise.all([readText(p.passwd), readText(p.group), readText(p.shadow)]);
  const admins = new Set();
  for (const line of (group ?? '').split('\n')) {
    const [name, , , members] = line.split(':');
    if (ADMIN_GROUPS.has(name)) for (const m of (members ?? '').split(',')) if (m) admins.add(m.trim());
  }
  const passwords = new Map();
  for (const line of (shadow ?? '').split('\n')) {
    const [name, hash] = line.split(':');
    // "!", "*" and "" mean no usable password; "!$6$…" is a locked one.
    if (name) passwords.set(name, Boolean(hash) && !hash.startsWith('!') && !hash.startsWith('*'));
  }
  const accounts = [];
  for (const line of (passwd ?? '').split('\n')) {
    const [name, , uidText, gidText, , home, shell] = line.split(':');
    if (!name || !home || !SSH_USER_PATTERN.test(name)) continue;
    const uid = Number(uidText);
    const isRoot = uid === 0 && name === 'root';
    if (!isRoot && (uid < 1000 || uid >= 60000)) continue;
    if (/(nologin|false)$/.test(shell ?? '') || !path.isAbsolute(home)) continue;
    const keysFile = isRoot ? p.rootKeys : path.join(home, '.ssh', 'authorized_keys');
    const keys = parseAuthorizedKeys(isRoot ? await readText(keysFile) : await readKeysFile(keysFile));
    accounts.push({ name, uid, gid: Number(gidText), home, root: isRoot, admin: isRoot || admins.has(name), keysFile, keyList: keys, keys: keys.length, hasPassword: passwords.get(name) ?? false });
    if (accounts.length >= 50) break;
  }
  return accounts;
}

// The accounts that can administer the server, for the lockout guard.
export async function readAdminAccounts(policy) {
  return (await readLoginAccounts(policy)).filter((a) => a.admin);
}

// Whether an administrator can still sign in with these settings. Returns
// null if so, or the reason why not.
export function lockoutReason(settings, accounts) {
  const ok = accounts.some((a) => {
    if (a.root) {
      if (settings.permitRootLogin === 'no') return false;
      const byKey = settings.pubkeyAuthentication && a.keys > 0;
      const byPassword = settings.permitRootLogin === 'yes' && settings.passwordAuthentication && a.hasPassword;
      return byKey || byPassword;
    }
    return (settings.pubkeyAuthentication && a.keys > 0) || (settings.passwordAuthentication && a.hasPassword);
  });
  if (ok) return null;
  if (settings.permitRootLogin === 'no') {
    return 'With root sign-in off, nobody could sign in: no sudo user has an SSH key' + (settings.passwordAuthentication ? ' or a password' : '') + '. Create a sudo user with a key first.';
  }
  if (!settings.passwordAuthentication) {
    return 'With passwords off, nobody could sign in: no administrator account (root, or a sudo user) has an SSH key. Add your public key first.';
  }
  if (settings.permitRootLogin !== 'yes') {
    return 'Root could not sign in with these settings, and no sudo user has a password or an SSH key. Add a key for root, or create a sudo user first.';
  }
  return 'No administrator account could sign in with these settings.';
}

async function sshdTest(ctx, sshd, args, what) {
  const result = await ctx.run(sshd, args, { timeoutMs: 15_000, env: ENV });
  if (result.exitCode !== 0) {
    throw new OperationError('SSHD_CONFIG_INVALID', `${what}: ${(result.stderr || result.stdout || result.error?.message || '').trim().split('\n').slice(-3).join('\n')}`);
  }
  return result.stdout;
}

export async function readSsh(ctx) {
  const sshd = await findBinary('sshd', ctx.binDirs);
  if (!sshd) return { installed: false };
  const p = sshPaths(ctx.policy);
  const result = await ctx.run(sshd, ['-T'], { timeoutMs: 15_000, env: ENV });
  const effective = result.exitCode === 0 ? parseSshdT(result.stdout) : null;
  const [dropIn, rootKeys, accounts] = await Promise.all([readText(p.dropIn), readText(p.rootKeys), readLoginAccounts(ctx.policy)]);
  const keyList = (list) => list.map(({ line, ...key }) => key);
  return {
    installed: true,
    ...(effective ?? { ports: [22] }),
    readable: Boolean(effective),
    managed: Boolean(dropIn?.startsWith(SSH_HEADER)),
    // The ports the panel set, when it set them.
    managedPorts: parseDropIn(dropIn).ports ?? null,
    rootKeys: keyList(parseAuthorizedKeys(rootKeys)),
    accounts: accounts.filter((a) => a.admin).map(({ name, root, keys, hasPassword }) => ({ name, root, keys, hasPassword })),
    // Every login account and its keys (0.34.0).
    users: accounts.map(({ name, root, admin, home, keysFile, keyList: keys, hasPassword }) => ({ name, root, admin, home, keysFile, hasPassword, keys: keyList(keys) })),
  };
}

// The settings in the agent's drop-in file, or {} if it is not the agent's.
export function parseDropIn(text) {
  if (!text?.startsWith(SSH_HEADER)) return {};
  const values = {};
  const ports = [];
  for (const line of text.split('\n')) {
    const match = /^(\w+)\s+(\S+)$/.exec(line.trim());
    if (!match) continue;
    const [, key, value] = match;
    if (key === 'Port') ports.push(Number(value));
    else if (key === 'PermitRootLogin') values.permitRootLogin = value;
    else if (key === 'PasswordAuthentication') values.passwordAuthentication = value === 'yes';
    else if (key === 'MaxAuthTries') values.maxAuthTries = Number(value);
  }
  if (ports.length) values.ports = ports;
  return values;
}

// Each setting is written only when given, so the file can hold just the
// ports, just the sign-in settings, or both.
export function renderDropIn({ permitRootLogin, passwordAuthentication, maxAuthTries, ports }) {
  return [
    SSH_HEADER,
    ...(ports ?? []).map((port) => `Port ${port}`),
    ...(permitRootLogin ? [`PermitRootLogin ${permitRootLogin}`] : []),
    ...(passwordAuthentication === undefined ? [] : [`PasswordAuthentication ${passwordAuthentication ? 'yes' : 'no'}`]),
    // Keyboard-interactive sign-in also asks for the password through PAM.
    ...(passwordAuthentication === false ? ['KbdInteractiveAuthentication no'] : []),
    ...(maxAuthTries ? [`MaxAuthTries ${maxAuthTries}`] : []),
    '',
  ].join('\n');
}

async function writeAtomic(file, content, mode) {
  await mkdir(path.dirname(file), { recursive: true, mode: 0o755 });
  const tmp = `${file}.tmp-${process.pid}`;
  await writeFile(tmp, content, { mode });
  await chmod(tmp, mode);
  await rename(tmp, file);
}

// Reloads sshd so new connections use the new settings. Sessions already
// open stay open. With socket activation (Ubuntu 22.10+), an idle sshd
// reads the config on the next connection by itself.
async function reloadSsh(ctx) {
  const states = await readServiceStates(['ssh', 'sshd'], { run: ctx.run });
  const unit = states.find((s) => s.active === 'active');
  if (!unit) {
    ctx.log('stdout', 'sshd is not running as a service; new connections read the new settings');
    return;
  }
  ctx.log('stdout', `$ systemctl reload ${unit.name}`);
  const result = await ctx.run('systemctl', ['reload', `${unit.name}.service`], { timeoutMs: 30_000, env: ENV });
  if (result.exitCode !== 0) throw new OperationError('RELOAD_FAILED', `Reloading ${unit.name} failed: ${(result.stderr || '').trim()}`);
}

function requireAllowed(ctx) {
  if (ctx.policy.allowSshConfig === false) throw new OperationError('NOT_ALLOWED', 'SSH changes are disabled in this agent config');
}

export function checkSshSettings(params) {
  if (!SSH_ROOT_LOGIN_KEYS.includes(params.permitRootLogin)) throw invalid(`permitRootLogin must be one of ${SSH_ROOT_LOGIN_KEYS.join(', ')}`);
  if (typeof params.passwordAuthentication !== 'boolean') throw invalid('passwordAuthentication must be true or false');
  if (!Number.isInteger(params.maxAuthTries) || params.maxAuthTries < SSH_MAX_AUTH_TRIES_MIN || params.maxAuthTries > SSH_MAX_AUTH_TRIES_MAX) {
    throw invalid(`maxAuthTries must be from ${SSH_MAX_AUTH_TRIES_MIN} to ${SSH_MAX_AUTH_TRIES_MAX}`);
  }
  return { permitRootLogin: params.permitRootLogin, passwordAuthentication: params.passwordAuthentication, maxAuthTries: params.maxAuthTries };
}

async function readRootKeys(p) {
  try {
    return await readFile(p.rootKeys, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return '';
    throw err;
  }
}

async function writeRootKeys(p, text) {
  try {
    await mkdir(path.dirname(p.rootKeys), { recursive: true, mode: 0o700 });
    await writeAtomic(p.rootKeys, text, 0o600);
  } catch (err) {
    if (err.code === 'EROFS' || err.code === 'EACCES') {
      throw new OperationError('KEYS_NOT_WRITABLE', `The agent cannot write ${p.rootKeys} (${err.code}). Update the agent with the command on the server page; it allows writing root's .ssh folder.`);
    }
    throw err;
  }
}

export const SSH_OPERATIONS = {
  SSH_CONFIGURE: {
    async run(params, ctx) {
      onlyKeys(params, ['permitRootLogin', 'passwordAuthentication', 'maxAuthTries']);
      const wanted = checkSshSettings(params);
      requireAllowed(ctx);
      const sshd = await findBinary('sshd', ctx.binDirs);
      if (!sshd) throw new OperationError('SSH_NOT_INSTALLED', 'The OpenSSH server is not installed on this server');
      const p = sshPaths(ctx.policy);
      const main = await readText(p.mainConfig);
      if (!/^\s*Include\s+\S*sshd_config\.d\/\*\.conf/im.test(main ?? '')) {
        throw new OperationError('UNSUPPORTED_SYSTEM', `${p.mainConfig} does not include sshd_config.d/*.conf, so the agent cannot change SSH settings safely here`);
      }
      const current = parseSshdT(await sshdTest(ctx, sshd, ['-T'], 'sshd cannot read its current settings'));
      const reason = lockoutReason({ ...current, ...wanted }, await readAdminAccounts(ctx.policy));
      if (reason) throw new OperationError('LOCKOUT_REFUSED', reason);

      const previous = await readText(p.dropIn);
      const restore = async () => {
        if (previous === null) await rm(p.dropIn, { force: true });
        else await writeAtomic(p.dropIn, previous, 0o644);
      };
      ctx.log('stdout', `Writing ${p.dropIn}`);
      await writeAtomic(p.dropIn, renderDropIn({ ...wanted, ports: parseDropIn(previous).ports }), 0o644);
      try {
        await sshdTest(ctx, sshd, ['-t'], 'sshd refused the new settings');
        const effective = parseSshdT(await sshdTest(ctx, sshd, ['-T'], 'sshd cannot read the new settings'));
        const differs = ['permitRootLogin', 'passwordAuthentication', 'maxAuthTries'].filter((k) => effective[k] !== wanted[k]);
        if (differs.length) {
          throw new OperationError('SSHD_OVERRIDDEN', `Another sshd setting comes first and overrides ${differs.join(', ')}. Check ${p.mainConfig} for lines above its Include line.`);
        }
        await reloadSsh(ctx);
      } catch (err) {
        ctx.log('stderr', 'Putting the previous SSH settings back');
        await restore();
        throw err;
      }
      ctx.webInventory?.invalidate();
      ctx.log('stdout', 'SSH settings applied. Sessions already open stay open.');
      return { output: { ssh: await readSsh(ctx) } };
    },
  },

  SSH_KEY_ADD: {
    async run(params, ctx) {
      onlyKeys(params, ['key', 'user']);
      const key = typeof params.key === 'string' ? params.key.trim() : '';
      if (!SSH_PUBLIC_KEY_PATTERN.test(key)) throw invalid('key must be one public key line (type, key and an optional comment)');
      const [type, blob] = key.split(' ');
      // The blob starts with the key type, length-prefixed.
      const decoded = Buffer.from(blob, 'base64');
      if (decoded.length < 8 || decoded.readUInt32BE(0) !== type.length || decoded.subarray(4, 4 + type.length).toString() !== type) {
        throw invalid('That does not look like a valid public key (its data does not match its type)');
      }
      requireAllowed(ctx);
      const account = await keyAccount(ctx, params.user);
      const text = await readAccountKeys(ctx, account);
      const fingerprint = keyFingerprint(blob);
      if (parseAuthorizedKeys(text).some((k) => k.fingerprint === fingerprint)) {
        throw new OperationError('KEY_EXISTS', `${account.root ? 'Root' : account.name} already has this key`);
      }
      ctx.log('stdout', `Adding ${type} key ${fingerprint} to ${account.keysFile}`);
      await writeAccountKeys(ctx, account, `${text}${text && !text.endsWith('\n') ? '\n' : ''}${key}\n`);
      ctx.webInventory?.invalidate();
      return { output: { fingerprint, user: account.name, ssh: await readSsh(ctx) } };
    },
  },

  SSH_KEY_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['fingerprint', 'user']);
      if (typeof params.fingerprint !== 'string' || !SSH_FINGERPRINT_PATTERN.test(params.fingerprint)) throw invalid('fingerprint must be a SHA256 fingerprint');
      requireAllowed(ctx);
      const account = await keyAccount(ctx, params.user);
      const text = await readAccountKeys(ctx, account);
      const keys = parseAuthorizedKeys(text);
      const target = keys.find((k) => k.fingerprint === params.fingerprint);
      if (!target) throw new OperationError('KEY_NOT_FOUND', `${account.root ? 'Root' : account.name} does not have that key any more. Refresh the list.`);

      if (account.admin) {
        const accounts = (await readAdminAccounts(ctx.policy)).map((a) => (a.name === account.name ? { ...a, keys: a.keys - 1 } : a));
        const sshd = await findBinary('sshd', ctx.binDirs);
        if (sshd) {
          const result = await ctx.run(sshd, ['-T'], { timeoutMs: 15_000, env: ENV });
          if (result.exitCode === 0) {
            const reason = lockoutReason(parseSshdT(result.stdout), accounts);
            if (reason) throw new OperationError('LOCKOUT_REFUSED', `Removing this key could lock everyone out. ${reason}`);
          }
        }
      }
      const lines = text.split('\n');
      lines.splice(target.line, 1);
      ctx.log('stdout', `Removing key ${target.fingerprint} from ${account.keysFile}`);
      await writeAccountKeys(ctx, account, lines.join('\n'));
      ctx.webInventory?.invalidate();
      return { output: { user: account.name, ssh: await readSsh(ctx) } };
    },
  },

  SSH_PORTS_SET: {
    async run(params, ctx) {
      onlyKeys(params, ['ports', 'protectedPorts']);
      const wanted = checkPorts(params.ports);
      requireAllowed(ctx);
      const sshd = await findBinary('sshd', ctx.binDirs);
      if (!sshd) throw new OperationError('SSH_NOT_INSTALLED', 'The OpenSSH server is not installed on this server');
      const p = sshPaths(ctx.policy);
      const main = await readText(p.mainConfig);
      if (!/^\s*Include\s+\S*sshd_config\.d\/\*\.conf/im.test(main ?? '')) {
        throw new OperationError('UNSUPPORTED_SYSTEM', `${p.mainConfig} does not include sshd_config.d/*.conf, so the agent cannot change SSH settings safely here`);
      }
      const current = parseSshdT(await sshdTest(ctx, sshd, ['-T'], 'sshd cannot read its current settings'));
      const panelPorts = Array.isArray(params.protectedPorts) ? params.protectedPorts : [];
      const taken = wanted.find((port) => panelPorts.includes(port));
      if (taken) throw invalid(`Port ${taken} is the panel's`);
      const added = wanted.filter((port) => !current.ports.includes(port));
      const listeners = await listeningPorts(ctx);
      for (const port of added) {
        const owner = listeners.get(port);
        if (owner && !owner.includes('sshd')) throw new OperationError('PORT_IN_USE', `Port ${port} is already used by ${owner.join(', ') || 'another program'}`);
      }
      if (sameList(wanted, current.ports)) {
        ctx.log('stdout', `SSH already listens on ${wanted.join(', ')}`);
        return { output: { ssh: await readSsh(ctx) } };
      }

      // The new ports must be reachable before sshd moves to them.
      const ufw = await findBinary('ufw', ctx.binDirs);
      const firewall = ufw ? await readFirewall(ctx) : null;
      if (firewall?.active) {
        for (const port of added) {
          if (portOpenToAll(firewall.rules, port)) continue;
          await ufwRun(ctx, ufw, ['allow', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', String(port), 'comment', KEEP_SSH_COMMENT], `Allowing port ${port}`);
        }
      }

      const previous = await readText(p.dropIn);
      const restore = async () => {
        if (previous === null) await rm(p.dropIn, { force: true });
        else await writeAtomic(p.dropIn, previous, 0o644);
      };
      ctx.log('stdout', `Writing ${p.dropIn}`);
      await writeAtomic(p.dropIn, renderDropIn({ ...parseDropIn(previous), ports: wanted }), 0o644);
      try {
        await sshdTest(ctx, sshd, ['-t'], 'sshd refused the new settings');
        const effective = parseSshdT(await sshdTest(ctx, sshd, ['-T'], 'sshd cannot read the new settings'));
        if (!sameList(effective.ports, wanted)) {
          throw new OperationError(
            'SSHD_OVERRIDDEN',
            `sshd would listen on ${effective.ports.join(', ')}, not ${wanted.join(', ')}. Another Port line, in ${p.mainConfig} or another file in sshd_config.d, adds to it; remove it first.`,
          );
        }
        await restartSsh(ctx);
        const silent = [];
        for (const port of wanted) if (!(await answersSsh(ctx, port))) silent.push(port);
        if (silent.length) throw new OperationError('SSH_NOT_LISTENING', `sshd did not answer on port ${silent.join(', ')} after the change`);
      } catch (err) {
        ctx.log('stderr', 'Putting the previous SSH ports back');
        await restore();
        await restartSsh(ctx).catch((restartErr) => ctx.log('stderr', `Restarting SSH failed: ${restartErr.message}`));
        throw err;
      }

      if (await updateJailPorts(ctx, wanted).catch(() => false)) ctx.log('stdout', `Fail2ban now watches port ${wanted.join(', ')}`);
      // Rules the agent itself added for ports SSH has left.
      const removed = current.ports.filter((port) => !wanted.includes(port) && !panelPorts.includes(port));
      if (ufw && removed.length) {
        const { rules } = await readFirewall(ctx);
        for (const rule of rules) {
          if (rule.direction !== 'in' || rule.action !== 'allow' || rule.comment !== KEEP_SSH_COMMENT || !removed.includes(Number(rule.port))) continue;
          await ufwRun(ctx, ufw, ['delete', 'allow', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', rule.port], `Closing port ${rule.port}`).catch((err) => ctx.log('stderr', err.message));
        }
      }
      ctx.webInventory?.invalidate();
      ctx.log('stdout', `SSH listens on port ${wanted.join(', ')}. Sessions already open stay open.`);
      return { output: { ssh: await readSsh(ctx) } };
    },
  },
};

// ---- Ports --------------------------------------------------------------------------

const sameList = (a, b) => a.length === b.length && [...a].sort().every((v, i) => v === [...b].sort()[i]);

export function checkPorts(ports) {
  if (!Array.isArray(ports) || !ports.length || ports.length > SSH_MAX_PORTS) throw invalid(`ports must list 1 or ${SSH_MAX_PORTS} ports`);
  for (const port of ports) {
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw invalid('Each port must be from 1 to 65535');
    if (SSH_RESERVED_PORTS.includes(port)) throw invalid(`Port ${port} is for websites`);
  }
  if (new Set(ports).size !== ports.length) throw invalid('Each port only once');
  return [...ports];
}

// TCP ports something listens on, with the names of the programs (`ss -ltnp`).
export function parseSs(text) {
  const ports = new Map();
  for (const line of (text ?? '').split('\n')) {
    const fields = line.trim().split(/\s+/);
    if (fields.length < 4) continue;
    const port = Number(/:(\d+)$/.exec(fields[3])?.[1]);
    if (!port) continue;
    const names = [...line.matchAll(/\("([^"]+)"/g)].map((m) => m[1]);
    ports.set(port, [...new Set([...(ports.get(port) ?? []), ...names])]);
  }
  return ports;
}

async function listeningPorts(ctx) {
  const ss = await findBinary('ss', ctx.binDirs);
  if (!ss) return new Map();
  const result = await ctx.run(ss, ['-ltnpH'], { timeoutMs: 15_000, env: ENV });
  return result.exitCode === 0 ? parseSs(result.stdout) : new Map();
}

// Applies new ports. With socket activation (Ubuntu 22.10 and later)
// systemd listens for sshd, and reads the ports from sshd's settings when it
// reloads; otherwise sshd re-reads them when it reloads.
async function restartSsh(ctx) {
  const show = await ctx.run('systemctl', ['show', 'ssh.socket', '--property=ActiveState', '--no-pager'], { timeoutMs: 15_000, env: ENV });
  const socket = show.exitCode === 0 && /ActiveState=active/.test(show.stdout);
  const steps = socket ? [['daemon-reload'], ['restart', 'ssh.socket']] : [];
  for (const args of steps) {
    ctx.log('stdout', `$ systemctl ${args.join(' ')}`);
    const result = await ctx.run('systemctl', args, { timeoutMs: 60_000, env: ENV });
    if (result.exitCode !== 0) throw new OperationError('RELOAD_FAILED', `systemctl ${args.join(' ')} failed: ${(result.stderr || '').trim()}`);
  }
  const states = await readServiceStates(['ssh', 'sshd'], { run: ctx.run });
  const unit = states.find((st) => st.active === 'active');
  if (!unit) return;
  // With the socket, sshd takes its listening sockets from systemd, so it
  // restarts to get the new ones. Open sessions are not part of the restart.
  const args = socket ? ['restart', `${unit.name}.service`] : ['reload', `${unit.name}.service`];
  ctx.log('stdout', `$ systemctl ${args.join(' ')}`);
  const result = await ctx.run('systemctl', args, { timeoutMs: 60_000, env: ENV });
  if (result.exitCode !== 0) throw new OperationError('RELOAD_FAILED', `systemctl ${args.join(' ')} failed: ${(result.stderr || '').trim()}`);
}

// Whether sshd greets on a port of this server ("SSH-2.0-…").
async function answersSsh(ctx, port) {
  if (ctx.probeSsh) return ctx.probeSsh(port);
  const deadline = Date.now() + (ctx.sshProbeMs ?? 10_000);
  while (Date.now() < deadline) {
    for (const host of ['127.0.0.1', '::1']) {
      if (await greets(host, port)) return true;
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

function greets(host, port) {
  return new Promise((resolve) => {
    const socket = net.connect({ host, port });
    let text = '';
    const done = (ok) => {
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(3000, () => done(false));
    socket.on('error', () => done(false));
    socket.on('data', (chunk) => {
      text += chunk.toString('latin1');
      if (text.includes('\n') || text.length > 200) done(text.startsWith('SSH-'));
    });
    socket.on('end', () => done(text.startsWith('SSH-')));
  });
}

// ---- Keys of other accounts -----------------------------------------------------------

async function keyAccount(ctx, user = 'root') {
  if (typeof user !== 'string' || !SSH_USER_PATTERN.test(user)) throw invalid('user must be a Linux account name');
  const account = (await readLoginAccounts(ctx.policy)).find((a) => a.name === user);
  if (!account) throw new OperationError('USER_NOT_FOUND', `${user} is not an account people can sign in to over SSH (it needs a login shell and a uid of 1000 or more)`);
  return account;
}

async function readAccountKeys(ctx, account) {
  if (account.root) return readRootKeys(sshPaths(ctx.policy));
  return readKeysFile(account.keysFile);
}

async function writeAccountKeys(ctx, account, text) {
  if (account.root) return writeRootKeys(sshPaths(ctx.policy), text);
  return (ctx.writeUserKeys ?? writeUserKeys)(account, text);
}

// Writes another account's keys as that account (see keysWorker.js). The
// agent's service sees /home read-only, so the worker starts in the host's
// mount namespace when the agent runs in its own.
export async function writeUserKeys(account, content, { hostNamespace } = {}) {
  const host = hostNamespace ?? (await needsHostNamespace());
  const command = [process.execPath, KEYS_WORKER, '--as', String(account.uid), String(account.gid)];
  const [file, ...args] = host ? ['nsenter', '--mount=/proc/1/ns/mnt', '--', ...command] : command;
  const reply = await new Promise((resolve, reject) => {
    const child = spawn(file, args, { cwd: '/', env: { PATH: ENV.PATH, LANG: 'C', HOME: account.home }, stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => child.kill('SIGKILL'), 30_000);
    child.stdout.on('data', (c) => (stdout += c));
    child.stderr.on('data', (c) => (stderr = (stderr + c).slice(-2000)));
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', () => {
      clearTimeout(timer);
      try {
        resolve(JSON.parse(stdout));
      } catch {
        resolve({ error: { message: stderr.trim() || 'the key writer stopped' } });
      }
    });
    child.stdin.end(JSON.stringify({ home: account.home, content }));
  });
  if (reply.error) throw new OperationError('KEYS_NOT_WRITABLE', `Could not write ${account.keysFile}: ${reply.error.message}`);
}
