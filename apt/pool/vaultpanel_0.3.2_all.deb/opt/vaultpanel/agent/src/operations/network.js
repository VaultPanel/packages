import { assertCommandOk, onlyKeys } from './errors.js';

// Network lookups (phase 9): which TCP ports the server listens on and the
// programs behind them, read with `ss`. Read-only.

const MAX_SOCKETS = 500;

// Parses `ss -H -ltnp` lines: State Recv-Q Send-Q Local:Port Peer:Port [users:((...))]
export function parseListeningSockets(stdout) {
  const sockets = [];
  for (const line of stdout.split('\n')) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 5 || parts[0] !== 'LISTEN') continue;
    const local = parts[3];
    const colon = local.lastIndexOf(':');
    const port = Number(local.slice(colon + 1));
    if (colon < 0 || !Number.isInteger(port)) continue;
    const address = local.slice(0, colon).replace(/^\[|\]$/g, '').replace(/%.*$/, '');
    const users = parts.slice(5).join(' ');
    const processes = [];
    for (const match of users.matchAll(/\("([^"]{1,64})",pid=(\d+)/g)) {
      if (!processes.some((p) => p.pid === Number(match[2]))) processes.push({ name: match[1], pid: Number(match[2]) });
    }
    sockets.push({ protocol: 'tcp', address, port, processes });
  }
  return sockets.sort((a, b) => a.port - b.port || a.address.localeCompare(b.address)).slice(0, MAX_SOCKETS);
}

export const NETWORK_OPERATIONS = {
  LISTENING_PORTS: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const result = assertCommandOk(await ctx.run('ss', ['-H', '-ltnp'], { timeoutMs: 15_000 }), 'Listing listening ports');
      return { output: { sockets: parseListeningSockets(result.stdout) } };
    },
  },
};
