import { readdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { findBinary } from '../monitoring/web.js';
import { parseCommands } from '../security/appRules.js';
import { BACKUP_ID_PATTERN, checkCronSchedule, CRON_TIMEOUT_MAX, CRON_TIMEOUT_MIN, CRON_WORKING_DIR_PATTERN } from '../security/automationRules.js';
import { DEFAULT_CONFIG_PATH, saveSecretFile } from '../config.js';
import { checkSiteName, sitePaths } from '../services/siteConfig.js';
import { cronPaths, readCronSpec, runCron } from '../services/cronRunner.js';
import { onlyKeys, OperationError } from './errors.js';
import { requireSiteAccount, writeFileAtomic } from './sites.js';

// Cron jobs. Each job's settings are saved as <cronSpecDir>/<id>.json (root
// only) and every enabled job becomes one line of /etc/cron.d/vaultpanel:
//
//   */5 * * * * root /usr/bin/node /opt/vaultpanel-agent/src/cli.js cron-run <id>
//
// The line holds only the checked schedule and the job's id; the commands
// stay in the settings file and are run by `cron-run` as the site's or app's
// own user, without a shell (see services/cronRunner.js).

const CLI_PATH = fileURLToPath(new URL('../cli.js', import.meta.url));
const SAFE_PATH = /^\/[A-Za-z0-9._/+-]+$/;
const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const SPEC_KEYS = ['id', 'user', 'schedule', 'commands', 'workingDir', 'timeoutSeconds', 'enabled', 'appEnv'];

export const CRONTAB_HEADER = '# Managed by VaultPanel. Changes made here are overwritten when cron jobs are saved in the panel.';

export function requireCron(policy) {
  if (policy.allowCron === false) throw new OperationError('NOT_ALLOWED', 'Cron jobs are disabled in this agent config');
}

function checkId(id) {
  if (typeof id !== 'string' || !BACKUP_ID_PATTERN.test(id)) throw invalid('id must be a cron job id');
  return id;
}

export function checkCronSpec(params) {
  onlyKeys(params, SPEC_KEYS);
  const spec = { id: checkId(params.id), user: checkSiteName(params.user) };
  if (!checkCronSchedule(params.schedule)) throw invalid('schedule must have five cron fields');
  spec.schedule = params.schedule;
  const parsed = parseCommands(params.commands);
  if (parsed.error) throw invalid(`commands: ${parsed.error}`);
  spec.commands = params.commands;
  if (params.workingDir !== undefined && params.workingDir !== null && params.workingDir !== '') {
    if (typeof params.workingDir !== 'string' || !CRON_WORKING_DIR_PATTERN.test(params.workingDir)) throw invalid('workingDir must be a folder inside the site');
    spec.workingDir = params.workingDir;
  } else spec.workingDir = '';
  const timeout = params.timeoutSeconds ?? 3600;
  if (!Number.isInteger(timeout) || timeout < CRON_TIMEOUT_MIN || timeout > CRON_TIMEOUT_MAX) throw invalid(`timeoutSeconds must be from ${CRON_TIMEOUT_MIN} to ${CRON_TIMEOUT_MAX}`);
  spec.timeoutSeconds = timeout;
  spec.enabled = params.enabled ?? true;
  spec.appEnv = params.appEnv ?? false;
  if (typeof spec.enabled !== 'boolean' || typeof spec.appEnv !== 'boolean') throw invalid('enabled and appEnv must be true or false');
  return spec;
}

// The crontab for every enabled job. Paths go into it only when they are
// plain absolute paths.
export function renderCrontab(specs, { nodePath = process.execPath, cliPath = CLI_PATH, configPath = null } = {}) {
  for (const p of [nodePath, cliPath, configPath].filter(Boolean)) {
    if (!SAFE_PATH.test(p)) throw new OperationError('CRON_PATH_UNSAFE', `The agent's path ${p} has characters cron could misread`);
  }
  const config = configPath && configPath !== DEFAULT_CONFIG_PATH ? ` --config ${configPath}` : '';
  const lines = specs
    .filter((spec) => spec.enabled && checkCronSchedule(spec.schedule) && BACKUP_ID_PATTERN.test(spec.id))
    .sort((a, b) => a.id.localeCompare(b.id))
    .map((spec) => `${spec.schedule} root ${nodePath} ${cliPath} cron-run ${spec.id}${config} >/dev/null 2>&1`);
  return `${CRONTAB_HEADER}\nSHELL=/bin/sh\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n${lines.join('\n')}${lines.length ? '\n' : ''}`;
}

async function readAllSpecs(policy) {
  let names;
  try {
    names = await readdir(policy.cronSpecDir);
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  const specs = [];
  for (const name of names) {
    const match = /^([0-9a-f-]{36})\.json$/.exec(name);
    if (!match) continue;
    const spec = await readCronSpec(policy, match[1]).catch(() => null);
    if (spec?.id === match[1]) specs.push(spec);
  }
  return specs;
}

export async function writeCrontab(ctx) {
  const specs = await readAllSpecs(ctx.policy);
  const content = renderCrontab(specs, { configPath: ctx.policy.configPath ?? null, ...(ctx.crontabPaths ?? {}) });
  await writeFileAtomic(ctx.policy.cronFile, content, 0o644);
  return specs.filter((s) => s.enabled).length;
}

async function cronInstalled(ctx) {
  return Boolean(await findBinary('cron', ctx.binDirs));
}

export const CRON_OPERATIONS = {
  // Creates or replaces a job.
  CREATE_CRON: {
    async run(params, ctx) {
      const spec = checkCronSpec(params);
      requireCron(ctx.policy);
      await requireSiteAccount(ctx, spec.user, sitePaths(ctx.policy, spec.user));
      await saveSecretFile(cronPaths(ctx.policy, spec.id).spec, `${JSON.stringify({ ...spec, savedAt: new Date().toISOString() }, null, 2)}\n`);
      const active = await writeCrontab(ctx);
      ctx.log('stdout', `Saved; ${ctx.policy.cronFile} now has ${active} job${active === 1 ? '' : 's'}`);
      ctx.log('stdout', spec.enabled ? `Runs "${spec.schedule}" as ${spec.user}` : 'The job is paused');
      const installed = await cronInstalled(ctx);
      if (!installed) ctx.log('stderr', 'Cron is not installed on this server, so the job will not run on its schedule until it is. Install it from the Software card on the server page.');
      return { output: { id: spec.id, enabled: spec.enabled, cronInstalled: installed } };
    },
  },

  DELETE_CRON: {
    async run(params, ctx) {
      onlyKeys(params, ['id']);
      const id = checkId(params.id);
      requireCron(ctx.policy);
      const paths = cronPaths(ctx.policy, id);
      await rm(paths.spec, { force: true });
      const active = await writeCrontab(ctx);
      ctx.log('stdout', `Removed; ${ctx.policy.cronFile} now has ${active} job${active === 1 ? '' : 's'}`);
      return { output: { id } };
    },
  },

  // Runs a saved job now and reports the run as the job's result (also when
  // the job's commands fail).
  RUN_CRON: {
    async run(params, ctx) {
      onlyKeys(params, ['id']);
      const id = checkId(params.id);
      requireCron(ctx.policy);
      const spec = await readCronSpec(ctx.policy, id);
      if (!spec) throw new OperationError('CRON_NOT_FOUND', 'This cron job is not saved on the server. Save it again from the panel.');
      const run = await runCron(spec, {
        policy: ctx.policy,
        trigger: 'manual',
        onLine: ctx.log,
        // Leave time to report before the panel's own timeout.
        timeoutMs: Math.max(5000, (ctx.timeoutMs ?? 3_600_000) - 60_000),
        deps: ctx.cronDeps,
      });
      if (run.status !== 'succeeded') {
        const why = { failed: run.exitCode === null ? 'The job failed' : `The job exited with code ${run.exitCode}`, timed_out: 'The job ran out of time', skipped: 'The job is already running' }[run.status];
        const error = new OperationError(`CRON_${run.status.toUpperCase()}`, why);
        error.output = { run };
        throw error;
      }
      return { output: { run } };
    },
  },
};

export { CLI_PATH };
