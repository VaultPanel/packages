import { chmod, lstat, mkdir, readdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { readServiceStates } from '../monitoring/services.js';
import { findBinary } from '../monitoring/web.js';
import { onlyKeys, OperationError } from './errors.js';

// The login message (0.21.0): "VaultPanel only" makes an SSH login and the
// panel's Terminal show the VaultPanel banner and nothing else.
//
// Turning it on:
// - every other script in /etc/update-motd.d (Ubuntu's welcome, help links,
//   news, update and restart notices) loses its execute bit, and the names
//   are remembered so turning it off gives exactly those back;
// - /etc/motd (Debian's legal notice) is set aside as /etc/motd.vaultpanel-saved
//   and replaced by the banner;
// - sshd still prints "Last login" after the banner (0.23.0; 0.21.0 and 0.22.0 hid it
//   with an sshd_config.d drop-in, which is removed again);
// - the Terminal page prints the same banner (terminal.js reads BANNER_FILE).
// A server installed with install.sh keeps its own 99-vaultpanel script (it
// also shows whether the panel is running), so /etc/motd stays empty there.
//
// It is on by default (0.21.0): the first time the agent starts on a server,
// it turns "VaultPanel only" on by itself. Turning it off in the panel is
// remembered, and the agent leaves the system's message alone from then on.
// The agent applies it again when it starts, so a package update that brings
// a motd script back does not undo it.

const ENV = { PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', LANG: 'C' };
export const BANNER_FILE = '/etc/vaultpanel-agent/banner.txt';
const OWN_SCRIPT = '99-vaultpanel';
const MARK = '# Written by the VaultPanel agent (login message: VaultPanel only).';

const ART = [
  ' __     __          _ _   ____                  _',
  ' \\ \\   / /_ _ _   _| | |_|  _ \\ __ _ _ __   ___| |',
  "  \\ \\ / / _` | | | | | __| |_) / _` | '_ \\ / _ \\ |",
  '   \\ V / (_| | |_| | | |_|  __/ (_| | | | |  __/ |',
  '    \\_/ \\__,_|\\__,_|_|\\__|_|   \\__,_|_| |_|\\___|_|',
];

export function bannerPaths(policy = {}) {
  const sshConfigDir = policy.sshConfigDir ?? '/etc/ssh';
  return {
    motdDir: policy.motdDir ?? '/etc/update-motd.d',
    motdFile: policy.motdFile ?? '/etc/motd',
    savedMotd: `${policy.motdFile ?? '/etc/motd'}.vaultpanel-saved`,
    sshMain: path.join(sshConfigDir, 'sshd_config'),
    sshDropIn: path.join(sshConfigDir, 'sshd_config.d', '01-vaultpanel-login.conf'),
    stateFile: policy.loginBannerStateFile ?? '/etc/vaultpanel-agent/login-banner.json',
    bannerFile: policy.bannerFile ?? BANNER_FILE,
  };
}

// Printable text only: the name and address come from the panel.
const clean = (s, max) => (typeof s === 'string' ? s.replace(/[^\x20-\x7e]/g, '').trim().slice(0, max) : '');

// The links under the art (the user's wording, 2026-10-12).
export const BANNER_LINKS = [
  ['Website', 'https://www.vaultpanel.net'],
  ['Documentation', 'https://www.vaultpanel.net/docs/'],
  ['Best Practices', 'https://www.vaultpanel.net/docs/best-practices/'],
];

const withSlash = (url) => (url && !url.endsWith('/') ? `${url}/` : url);

// serverName is kept in the state file but not shown.
export function renderBanner({ panelUrl } = {}) {
  const url = withSlash(clean(panelUrl, 300));
  const rows = [...BANNER_LINKS, ...(url ? [['VaultPanel', url]] : []), ['VaultPanel CLI', 'vaultpanel']];
  return ['', ...ART, '', ...rows.map(([label, value]) => ` * ${`${label}:`.padEnd(17)}${value}`), '', ''].join('\n');
}

const readJson = async (file) => JSON.parse(await readFile(file, 'utf8').catch(() => 'null'));
const exists = (file) => lstat(file).then(() => true, () => false);
const isOwnScript = async (file) => (await readFile(file, 'utf8').catch(() => '')).includes(MARK);

async function writeAtomic(file, content, mode) {
  await mkdir(path.dirname(file), { recursive: true, mode: 0o755 });
  const tmp = `${file}.tmp-${process.pid}`;
  await writeFile(tmp, content, { mode });
  await chmod(tmp, mode);
  await rename(tmp, file);
}

export async function readLoginBanner(policy) {
  const state = await readJson(bannerPaths(policy).stateFile);
  return { vaultpanelOnly: Boolean(state?.vaultpanelOnly) };
}

// Scripts in update-motd.d that run at login, other than VaultPanel's own.
// Symlinks are left alone: chmod would change the file they point at.
async function otherMotdScripts(dir) {
  const names = await readdir(dir).catch(() => []);
  const found = [];
  for (const name of names.sort()) {
    if (name === OWN_SCRIPT || name.startsWith('.')) continue;
    const file = path.join(dir, name);
    const info = await lstat(file).catch(() => null);
    if (info?.isFile() && info.mode & 0o111) found.push(name);
  }
  return found;
}

async function setLastLog(ctx, p) {
  if (!(await exists(p.sshDropIn))) return;
  ctx.log('stdout', `Removing ${p.sshDropIn} ("Last login" shows again)`);
  await rm(p.sshDropIn, { force: true });
  const sshd = await findBinary('sshd', ctx.binDirs);
  if (!sshd) return;
  const test = await ctx.run(sshd, ['-t'], { timeoutMs: 15_000, env: ENV });
  if (test.exitCode !== 0) return;
  const states = await readServiceStates(['ssh', 'sshd'], { run: ctx.run });
  const unit = states.find((s) => s.active === 'active');
  if (unit) await ctx.run('systemctl', ['reload', `${unit.name}.service`], { timeoutMs: 30_000, env: ENV });
}

export async function applyVaultpanelOnly(ctx, { serverName, panelUrl } = {}) {
  const p = bannerPaths(ctx.policy);
  const previous = (await readJson(p.stateFile)) ?? {};
  const state = {
    vaultpanelOnly: true,
    serverName: serverName ?? previous.serverName ?? '',
    panelUrl: panelUrl ?? previous.panelUrl ?? '',
    disabled: [...(previous.vaultpanelOnly ? previous.disabled ?? [] : [])],
    motdSaved: previous.vaultpanelOnly ? Boolean(previous.motdSaved) : false,
  };
  const banner = renderBanner(state);
  await writeAtomic(p.bannerFile, banner, 0o644);

  for (const name of await otherMotdScripts(p.motdDir)) {
    const file = path.join(p.motdDir, name);
    ctx.log('stdout', `Hiding ${file}`);
    await chmod(file, (await stat(file)).mode & 0o7666);
    if (!state.disabled.includes(name)) state.disabled.push(name);
  }

  // An installer's 99-vaultpanel (a link to scripts/motd.sh) shows the banner;
  // otherwise /etc/motd carries it.
  const own = path.join(p.motdDir, OWN_SCRIPT);
  const installerScript = (await exists(own)) && !(await isOwnScript(own));
  const current = await readFile(p.motdFile, 'utf8').catch(() => null);
  if (current !== null && !state.motdSaved && current !== banner && current.trim()) {
    ctx.log('stdout', `Keeping ${p.motdFile} as ${p.savedMotd}`);
    await rename(p.motdFile, p.savedMotd);
    state.motdSaved = true;
  }
  await writeAtomic(p.motdFile, installerScript ? '' : banner, 0o644);

  // "Last login" shows after the banner: undo 0.21.0's drop-in if it is there.
  await setLastLog(ctx, p);
  await writeAtomic(p.stateFile, `${JSON.stringify(state, null, 2)}\n`, 0o600);
  ctx.log('stdout', 'New logins show only the VaultPanel banner.');
  return state;
}

export async function restoreDefault(ctx) {
  const p = bannerPaths(ctx.policy);
  const state = await readJson(p.stateFile);
  for (const name of state?.disabled ?? []) {
    const file = path.join(p.motdDir, name);
    const info = await lstat(file).catch(() => null);
    if (!info?.isFile()) continue;
    ctx.log('stdout', `Showing ${file} again`);
    await chmod(file, (info.mode & 0o7777) | 0o755);
  }
  if (state?.motdSaved && (await exists(p.savedMotd))) {
    ctx.log('stdout', `Putting ${p.motdFile} back`);
    await rename(p.savedMotd, p.motdFile);
  } else if (state?.vaultpanelOnly) {
    await rm(p.motdFile, { force: true });
  }
  await setLastLog(ctx, p);
  await rm(p.bannerFile, { force: true });
  // Kept, so the agent does not turn the default back on at its next start.
  await writeAtomic(p.stateFile, `${JSON.stringify({ vaultpanelOnly: false }, null, 2)}\n`, 0o600);
  ctx.log('stdout', 'New logins show the system’s usual login message again.');
}

// From each heartbeat reply (0.23.0): the panel's address, so the banner's
// VaultPanel line follows System > Panel Domain without a click.
export async function syncLoginBanner(ctx, panel) {
  if (typeof panel?.url !== 'string') return null;
  const state = await readJson(bannerPaths(ctx.policy).stateFile);
  if (!state?.vaultpanelOnly || state.panelUrl === panel.url) return null;
  return applyVaultpanelOnly(ctx, { serverName: typeof panel.serverName === 'string' ? panel.serverName : undefined, panelUrl: panel.url });
}

const isLoopback = (url) => {
  try {
    return ['localhost', '127.0.0.1', '[::1]'].includes(new URL(url).hostname);
  } catch {
    return true;
  }
};

// At agent start: turn "VaultPanel only" on the first time (the default), and
// keep it in force after package updates. Off stays off once chosen.
export async function reapplyLoginBanner(ctx, { serverName = '', panelUrl = '' } = {}) {
  const p = bannerPaths(ctx.policy);
  const state = await readJson(p.stateFile);
  if (state?.vaultpanelOnly) return applyVaultpanelOnly(ctx, {});
  if (state || ctx.policy.allowSshConfig === false) return null;
  if (!(await exists(p.motdDir)) && !(await exists(p.motdFile))) return null;
  ctx.log('stdout', 'Turning on the VaultPanel login message (the default)');
  // The panel sends the real name and address the next time it changes the
  // setting; an agent that reaches the panel on 127.0.0.1 shows no address.
  return applyVaultpanelOnly(ctx, { serverName, panelUrl: isLoopback(panelUrl) ? '' : panelUrl });
}

export const LOGIN_BANNER_OPERATIONS = {
  LOGIN_BANNER_SET: {
    async run(params, ctx) {
      onlyKeys(params, ['vaultpanelOnly', 'serverName', 'panelUrl']);
      if (typeof params.vaultpanelOnly !== 'boolean') throw new OperationError('INVALID_PARAMS', 'vaultpanelOnly must be true or false');
      if (ctx.policy.allowSshConfig === false) throw new OperationError('NOT_ALLOWED', 'Login and SSH changes are disabled in this agent config');
      if (params.vaultpanelOnly) await applyVaultpanelOnly(ctx, { serverName: params.serverName ?? '', panelUrl: params.panelUrl ?? '' });
      else await restoreDefault(ctx);
      return { output: { loginBanner: await readLoginBanner(ctx.policy) } };
    },
  },
};
