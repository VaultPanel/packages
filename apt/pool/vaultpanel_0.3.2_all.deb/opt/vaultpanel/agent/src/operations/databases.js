import { createHash } from 'node:crypto';
import { findBinary } from '../monitoring/web.js';
import {
  DATABASE_NAME_PATTERN,
  DATABASE_PASSWORD_PATTERN,
  DATABASE_PRIVILEGES,
  DATABASE_USER_PATTERN,
  MAX_USER_DATABASES,
  RESERVED_DATABASE_NAMES,
  RESERVED_DATABASE_USERS,
} from '../security/appRules.js';
import { onlyKeys, OperationError } from './errors.js';

// MySQL / MariaDB databases and users. The agent talks to the local server
// with the mysql client as root over the unix socket (the default on Ubuntu
// and Debian), or with the client options file in the mysqlDefaultsFile
// policy key. SQL goes through stdin, never the command line, so passwords
// do not show in the process list. Every name is checked against a strict
// pattern before it is quoted into a statement.

// Each user exists for both ways a local app connects: the socket
// (localhost) and TCP to 127.0.0.1.
export const DATABASE_USER_HOSTS = ['localhost', '127.0.0.1'];

const invalid = (message) => new OperationError('INVALID_PARAMS', message);

export function requireDatabases(policy) {
  if (policy.allowDatabases === false) throw new OperationError('NOT_ALLOWED', 'Database management is disabled in this agent config');
}

export function checkDatabaseName(name) {
  if (typeof name !== 'string' || !DATABASE_NAME_PATTERN.test(name)) throw invalid('name must be a valid database name');
  if (RESERVED_DATABASE_NAMES.has(name)) throw new OperationError('NOT_ALLOWED', `"${name}" is a system database`);
  return name;
}

export function checkDatabaseUser(name) {
  if (typeof name !== 'string' || !DATABASE_USER_PATTERN.test(name)) throw invalid('username must be a valid database user name');
  if (RESERVED_DATABASE_USERS.has(name)) throw new OperationError('NOT_ALLOWED', `"${name}" is a reserved database user`);
  return name;
}

function checkPassword(password, { required }) {
  if (password === undefined || password === null) {
    if (required) throw invalid('password is required');
    return null;
  }
  if (typeof password !== 'string' || !DATABASE_PASSWORD_PATTERN.test(password)) throw invalid('password has characters that are not allowed');
  return password;
}

function checkGrants(params) {
  const databases = params.databases ?? [];
  if (!Array.isArray(databases) || databases.length > MAX_USER_DATABASES || new Set(databases).size !== databases.length) {
    throw invalid(`databases must list up to ${MAX_USER_DATABASES} different databases`);
  }
  databases.forEach(checkDatabaseName);
  const privileges = params.privileges ?? 'all';
  if (!DATABASE_PRIVILEGES.includes(privileges)) throw invalid(`privileges must be one of ${DATABASE_PRIVILEGES.join(', ')}`);
  return { databases, privileges };
}

// Quoting. Names have passed the patterns above, which already exclude every
// quote character; escaping is a second line of defence.
export const ident = (name) => `\`${String(name).replace(/`/g, '``')}\``;
export const literal = (value) => `'${String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
// In GRANT ... ON `db`.*, "_" and "%" are wildcards; escape them so a grant
// on my_db does not also cover myxdb.
export const grantDatabase = (name) => ident(String(name).replace(/[\\_%]/g, '\\$&'));
const account = (user, host) => `${literal(user)}@${literal(host)}`;

export function createUserSql(username, password) {
  return DATABASE_USER_HOSTS.flatMap((host) => [
    `CREATE USER IF NOT EXISTS ${account(username, host)} IDENTIFIED BY ${literal(password)};`,
    `ALTER USER ${account(username, host)} IDENTIFIED BY ${literal(password)};`,
  ]);
}

export function grantsSql(username, databases, privileges, hosts = DATABASE_USER_HOSTS) {
  const what = privileges === 'readonly' ? 'SELECT, SHOW VIEW' : 'ALL PRIVILEGES';
  return hosts.flatMap((host) => [
    `REVOKE ALL PRIVILEGES, GRANT OPTION FROM ${account(username, host)};`,
    ...databases.map((db) => `GRANT ${what} ON ${grantDatabase(db)}.* TO ${account(username, host)};`),
  ]);
}

// The account names have a "-", which panel database users cannot have, so
// they never clash with one.
export function browserAccount(database, mode) {
  return `vp-sql-${createHash('sha256').update(database).digest('hex').slice(0, 12)}-${mode === 'write' ? 'rw' : 'ro'}`;
}

// Removes both accounts of a database (when it is deleted).
export function dropBrowserAccountsSql(database) {
  const accounts = ['read', 'write'].flatMap((mode) => DATABASE_USER_HOSTS.map((host) => account(browserAccount(database, mode), host)));
  return [`DROP USER IF EXISTS ${accounts.join(', ')};`];
}

export async function mysqlClient(ctx) {
  const client = (await findBinary('mariadb', ctx.binDirs)) ?? (await findBinary('mysql', ctx.binDirs));
  if (!client) {
    throw new OperationError('DATABASE_SERVER_NOT_INSTALLED', 'MariaDB is not installed on this server. Install it from the Software card on the server page.');
  }
  return client;
}

// How the mysql client and mariadb-dump sign in as the administrator. An
// options file must come first.
export function mysqlArgs(policy) {
  return [...(policy.mysqlDefaultsFile ? [`--defaults-extra-file=${policy.mysqlDefaultsFile}`] : []), '--user=root'];
}

const DOWN = /Can't connect|No such file or directory.*socket|Connection refused/i;
const PORT_TAKEN = /Address already in use|Bind on TCP\/IP port|another mysqld server running|another .*server running on port/i;
const DATABASE_UNITS = ['mariadb', 'mysql'];

// The database server is installed but not running: start it once. When it
// will not start, the reason from its journal goes into the error.
export async function startDatabaseServer(ctx) {
  let journal = '';
  for (const unit of DATABASE_UNITS) {
    ctx.log('stdout', `The database server is not running; $ systemctl start ${unit}`);
    const start = await ctx.run('systemctl', ['start', `${unit}.service`], { timeoutMs: 90_000 });
    if (!start.error && start.exitCode === 0) return { started: true, unit };
    if (/not (be )?found|not loaded/i.test(`${start.stderr ?? ''}`)) continue;
    const log = await ctx.run('journalctl', ['--unit', `${unit}.service`, '--lines', '15', '--no-pager', '--output', 'cat'], { timeoutMs: 15_000 });
    journal = `${log.stdout ?? ''}`.trim();
    return { started: false, unit, journal };
  }
  return { started: false, unit: null, journal };
}

function serverDownError(detail, start) {
  if (start?.journal && PORT_TAKEN.test(start.journal)) {
    return new OperationError(
      'DATABASE_PORT_IN_USE',
      'MariaDB cannot start because port 3306 is already used by another program, often the panel\'s own MariaDB running in Docker. Move that one to another port (docker/compose.yml publishes it on 3307 now), then start mariadb from the Services tab.',
    );
  }
  const why = start?.journal ? `\n${start.journal.split('\n').slice(-6).join('\n')}` : '';
  return new OperationError('DATABASE_SERVER_DOWN', `The database server is not running and could not be started: ${detail}.${why}`);
}

// Runs SQL as the database administrator. Returns stdout rows (tab separated).
export async function runSql(ctx, statements, options = {}) {
  try {
    return await runSqlOnce(ctx, statements, options);
  } catch (err) {
    if (err.code !== 'DATABASE_SERVER_DOWN') throw err;
    const start = await startDatabaseServer(ctx);
    if (!start.started) throw serverDownError(err.detail, start);
    ctx.log('stdout', `Started ${start.unit}`);
    try {
      return await runSqlOnce(ctx, statements, { ...options, log: false });
    } catch (again) {
      if (again.code === 'DATABASE_SERVER_DOWN') throw serverDownError(again.detail, null);
      throw again;
    }
  }
}

async function runSqlOnce(ctx, statements, { log = true } = {}) {
  const client = await mysqlClient(ctx);
  const args = [...mysqlArgs(ctx.policy), '--batch', '--skip-column-names', '--connect-timeout=10'];
  const sql = statements.join('\n');
  if (log) ctx.log('stdout', statements.map(redactSql).join('\n'));
  const result = await ctx.run(client, args, { input: `${sql}\n`, timeoutMs: ctx.timeoutMs ?? 60_000 });
  if (result.timedOut) throw new OperationError('TIMEOUT', 'The database server did not answer in time');
  if (result.error || result.exitCode !== 0) {
    const detail = (result.stderr || result.error?.message || '').trim().split('\n').slice(-4).join('\n');
    if (DOWN.test(detail)) {
      const err = new OperationError('DATABASE_SERVER_DOWN', `The database server is not running: ${detail}`);
      err.detail = detail;
      throw err;
    }
    if (/Access denied/i.test(detail)) {
      throw new OperationError('DATABASE_ACCESS_DENIED', `The agent could not sign in to the database server as root: ${detail}. Set mysqlDefaultsFile in the agent config to a client options file with the root credentials.`);
    }
    throw new OperationError('DATABASE_COMMAND_FAILED', detail || `The mysql client failed (exit ${result.exitCode})`);
  }
  return result.stdout
    .split('\n')
    .filter(Boolean)
    .map((line) => line.split('\t'));
}

// Passwords never reach the job log.
export function redactSql(statement) {
  return statement.replace(/IDENTIFIED BY '(?:[^'\\]|\\.)*'/g, "IDENTIFIED BY '********'");
}

async function databaseExists(ctx, name) {
  const rows = await runSql(ctx, [`SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ${literal(name)};`], { log: false });
  return rows.length > 0;
}

// The hosts a user exists for.
async function userHosts(ctx, username) {
  const rows = await runSql(ctx, [`SELECT Host FROM mysql.user WHERE User = ${literal(username)};`], { log: false });
  return rows.map(([host]) => host);
}

// Databases on the server with their size, for the heartbeat.
export async function readDatabaseInventory(ctx) {
  const rows = await runSql(
    ctx,
    [
      `SELECT s.SCHEMA_NAME, COALESCE(SUM(t.DATA_LENGTH + t.INDEX_LENGTH), 0) FROM information_schema.SCHEMATA s LEFT JOIN information_schema.TABLES t ON t.TABLE_SCHEMA = s.SCHEMA_NAME GROUP BY s.SCHEMA_NAME;`,
    ],
    { log: false },
  );
  return rows
    .filter(([name]) => DATABASE_NAME_PATTERN.test(name) && !RESERVED_DATABASE_NAMES.has(name))
    .slice(0, 1000)
    .map(([name, size]) => ({ name, sizeBytes: Number(size) || 0 }));
}

export const DATABASE_OPERATIONS = {
  CREATE_DATABASE: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      const name = checkDatabaseName(params.name);
      requireDatabases(ctx.policy);
      const existed = await databaseExists(ctx, name);
      await runSql(ctx, [`CREATE DATABASE IF NOT EXISTS ${ident(name)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`]);
      ctx.log('stdout', existed ? `Database ${name} already existed; it was kept as it is` : `Created database ${name}`);
      ctx.webInventory?.invalidate();
      return { output: { name, existed, charset: 'utf8mb4', collation: 'utf8mb4_unicode_ci' } };
    },
  },

  DELETE_DATABASE: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      const name = checkDatabaseName(params.name);
      requireDatabases(ctx.policy);
      // MariaDB keeps privileges on a dropped database; remove them so a new
      // database with the same name does not inherit old users' access.
      const patterns = [...new Set([name, name.replace(/[\\_%]/g, '\\$&')])].map(literal).join(', ');
      await runSql(ctx, [`DROP DATABASE IF EXISTS ${ident(name)};`, `DELETE FROM mysql.db WHERE Db IN (${patterns});`, ...dropBrowserAccountsSql(name), 'FLUSH PRIVILEGES;']);
      ctx.log('stdout', `Database ${name} deleted, with the access users had to it`);
      ctx.webInventory?.invalidate();
      return { output: { name } };
    },
  },

  CREATE_DATABASE_USER: {
    async run(params, ctx) {
      onlyKeys(params, ['username', 'password', 'databases', 'privileges']);
      const username = checkDatabaseUser(params.username);
      const password = checkPassword(params.password, { required: true });
      const { databases, privileges } = checkGrants(params);
      requireDatabases(ctx.policy);
      const existed = (await userHosts(ctx, username)).length > 0;
      await runSql(ctx, [...createUserSql(username, password), ...grantsSql(username, databases, privileges), 'FLUSH PRIVILEGES;']);
      ctx.log('stdout', `${existed ? 'Updated' : 'Created'} user ${username} with ${privileges === 'readonly' ? 'read-only' : 'full'} access to ${databases.length ? databases.join(', ') : 'no databases'}`);
      return { output: { username, hosts: DATABASE_USER_HOSTS, databases, privileges, existed } };
    },
  },

  UPDATE_DATABASE_USER: {
    async run(params, ctx) {
      onlyKeys(params, ['username', 'password', 'databases', 'privileges']);
      const username = checkDatabaseUser(params.username);
      const password = checkPassword(params.password, { required: false });
      const { databases, privileges } = checkGrants(params);
      requireDatabases(ctx.policy);
      const existing = (await userHosts(ctx, username)).filter((host) => DATABASE_USER_HOSTS.includes(host));
      if (!existing.length) {
        throw new OperationError('DATABASE_USER_NOT_FOUND', `The user ${username} does not exist on the database server`);
      }
      // A new password (re)creates the user for every host; without one,
      // only the hosts it already has are changed (never a user without a password).
      const statements = password ? createUserSql(username, password) : [];
      const hosts = password ? DATABASE_USER_HOSTS : existing;
      await runSql(ctx, [...statements, ...grantsSql(username, databases, privileges, hosts), 'FLUSH PRIVILEGES;']);
      ctx.log('stdout', `${password ? 'Password changed. ' : ''}Access: ${databases.length ? databases.join(', ') : 'none'} (${privileges})`);
      return { output: { username, databases, privileges, passwordChanged: Boolean(password) } };
    },
  },

  DELETE_DATABASE_USER: {
    async run(params, ctx) {
      onlyKeys(params, ['username']);
      const username = checkDatabaseUser(params.username);
      requireDatabases(ctx.policy);
      await runSql(ctx, [`DROP USER IF EXISTS ${DATABASE_USER_HOSTS.map((host) => account(username, host)).join(', ')};`, 'FLUSH PRIVILEGES;']);
      ctx.log('stdout', `User ${username} deleted`);
      return { output: { username } };
    },
  },
};
