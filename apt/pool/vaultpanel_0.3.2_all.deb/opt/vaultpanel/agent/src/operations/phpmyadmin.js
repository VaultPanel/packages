import { access, chmod, chown, mkdir, readdir, readFile, rm, stat, symlink, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { findBinary, installedPhpVersions, PHPMYADMIN_ROOT, PHPMYADMIN_SITE } from '../monitoring/web.js';
import { DOMAIN_PATTERN } from '../security/webRules.js';
import { onlyKeys, OperationError } from './errors.js';
import { portOpenToAll, readFirewall, ufwRun } from './firewall.js';
import { httpCheck, reloadNginx, requireNginx, testNginx, writeFileAtomic } from './sites.js';
import { lookupUser } from '../services/siteFiles.js';
import { accountPassword, browserAccountSql } from './databaseBrowser.js';
import { browserAccount, checkDatabaseName, requireDatabases, runSql } from './databases.js';
import { aptInstall } from './webStack.js';

// phpMyAdmin, from the distribution's package (so it gets security updates
// with the rest of the system), served by NGINX on a port of its own through
// the default PHP-FPM pool. People sign in with a database user and its
// password; root and empty passwords are refused. With the panel's domain
// and its certificate, it is served over HTTPS.

const CONF_D = '/etc/phpmyadmin/conf.d';
const SETTINGS_FILE = 'vaultpanel.inc.php';
// Ports the panel and common services use; phpMyAdmin may not take them.
export const RESERVED_PORTS = new Set([22, 25, 53, 80, 443, 3000, 3306, 3307, 4000, 5173, 6379, 8090]);
export const DEFAULT_PHPMYADMIN_PORT = 8081;

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const exists = (p) => access(p).then(() => true, () => false);

const SETTINGS = `<?php
// Managed by VaultPanel. Overwritten when phpMyAdmin is set up again from the panel.
$cfg['Servers'][1]['host'] = 'localhost';
$cfg['Servers'][1]['auth_type'] = 'cookie';
$cfg['Servers'][1]['AllowRoot'] = false;
$cfg['Servers'][1]['AllowNoPassword'] = false;
$cfg['LoginCookieValidity'] = 3600;
$cfg['VersionCheck'] = false;
// One-click sign-in from the panel (vaultpanel-signon.php). Logging out ends
// it and leads back to the normal login form above.
$cfg['Servers'][2]['verbose'] = 'Signed in from VaultPanel';
$cfg['Servers'][2]['host'] = 'localhost';
$cfg['Servers'][2]['auth_type'] = 'signon';
$cfg['Servers'][2]['SignonSession'] = 'VaultPanelSignon';
$cfg['Servers'][2]['SignonCookieParams'] = ['lifetime' => 0, 'path' => '/', 'domain' => '', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax'];
$cfg['Servers'][2]['SignonURL'] = 'index.php?server=1';
$cfg['Servers'][2]['LogoutURL'] = 'vaultpanel-signon.php?logout=1';
$cfg['Servers'][2]['AllowRoot'] = false;
$cfg['ServerDefault'] = 1;
$cfg['DisplayServersList'] = false;
`;

// Where the agent leaves one-time sign-in tickets for vaultpanel-signon.php
// (tmpfs: gone after a reboot).
export const SIGNON_DIR = '/run/vaultpanel-phpmyadmin';
export const SIGNON_SCRIPT = 'vaultpanel-signon.php';
export const SIGNON_TTL_SECONDS = 120;

// Exchanges a one-time token for a phpMyAdmin session. The ticket file is
// named by the token's SHA-256, claimed with a rename (so only one request
// can use it), read and deleted.
export const signonScript = (dir = SIGNON_DIR) => `<?php
// Managed by VaultPanel: one-click sign-in to phpMyAdmin. Overwritten by the agent.
$back = 'index.php?server=1';
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'domain' => '', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
session_name('VaultPanelSignon');
if (isset($_GET['logout'])) {
    // phpMyAdmin ends its own session on logout; end the sign-in too, so the
    // next visit shows the login form.
    if (isset($_COOKIE['VaultPanelSignon'])) {
        session_start();
        $_SESSION = [];
        session_destroy();
        setcookie('VaultPanelSignon', '', ['expires' => 1, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
    }
    header('Location: ' . $back);
    exit;
}
$token = isset($_GET['token']) && is_string($_GET['token']) ? $_GET['token'] : '';
if (!preg_match('/^[A-Za-z0-9_-]{43}$/', $token)) { header('Location: ' . $back); exit; }
$file = '${dir}/' . hash('sha256', $token) . '.json';
$claimed = $file . '.used.' . bin2hex(random_bytes(8));
if (!@rename($file, $claimed)) { header('Location: ' . $back); exit; }
$ticket = json_decode((string) @file_get_contents($claimed), true);
@unlink($claimed);
if (!is_array($ticket) || !isset($ticket['user'], $ticket['password'], $ticket['database'], $ticket['expires']) || $ticket['expires'] < time()) {
    header('Location: ' . $back);
    exit;
}
session_start();
session_regenerate_id(true);
$_SESSION['PMA_single_signon_user'] = $ticket['user'];
$_SESSION['PMA_single_signon_password'] = $ticket['password'];
$_SESSION['PMA_single_signon_host'] = 'localhost';
session_write_close();
header('Cache-Control: no-store');
header('Location: index.php?server=2&route=/database/structure&db=' . rawurlencode($ticket['database']));
`;

const TOKEN_HASH = /^[a-f0-9]{64}$/;

// Removes tickets nobody used, and claimed ones a failed request left behind.
async function sweepTickets(dir) {
  const names = await readdir(dir).catch(() => []);
  const cutoff = Date.now() - SIGNON_TTL_SECONDS * 1000;
  for (const name of names) {
    const file = path.join(dir, name);
    const info = await stat(file).catch(() => null);
    if (info?.isFile() && info.mtimeMs < cutoff) await rm(file, { force: true });
  }
}

const DEBCONF = ['phpmyadmin phpmyadmin/dbconfig-install boolean false', 'phpmyadmin phpmyadmin/reconfigure-webserver multiselect'].join('\n');

export function phpMyAdminSite({ port, socket, tls, ipv6 = true }) {
  const ssl = tls ? ' ssl' : '';
  return [
    '# Managed by VaultPanel: phpMyAdmin. Changes made here are overwritten when it is set up again.',
    `# vaultpanel-phpmyadmin port=${port}${tls ? ` domain=${tls.domain}` : ''}`,
    'limit_req_zone $binary_remote_addr zone=vp_phpmyadmin:10m rate=10r/s;',
    'server {',
    `    listen ${port}${ssl};`,
    ...(ipv6 ? [`    listen [::]:${port}${ssl};`] : []),
    `    server_name ${tls ? tls.domain : '_'};`,
    ...(tls
      ? [
          `    ssl_certificate ${tls.fullchain};`,
          `    ssl_certificate_key ${tls.privkey};`,
          '    ssl_protocols TLSv1.2 TLSv1.3;',
          // Plain http:// on this port gets sent to https://.
          '    error_page 497 =301 https://$host:$server_port$request_uri;',
        ]
      : []),
    `    root ${PHPMYADMIN_ROOT};`,
    '    index index.php;',
    '    client_max_body_size 64m;',
    '    access_log /var/log/nginx/phpmyadmin.access.log;',
    '    error_log /var/log/nginx/phpmyadmin.error.log;',
    '    add_header X-Frame-Options SAMEORIGIN always;',
    '    add_header X-Content-Type-Options nosniff always;',
    '    add_header Referrer-Policy no-referrer always;',
    '    location ~ ^/(setup|libraries|templates|sql|vendor)(/|$) { deny all; }',
    '    location ~ /\\. { deny all; }',
    '    location / {',
    '        try_files $uri $uri/ =404;',
    '    }',
    '    location ~ \\.php$ {',
    '        limit_req zone=vp_phpmyadmin burst=60 nodelay;',
    '        try_files $uri =404;',
    '        include fastcgi_params;',
    '        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;',
    ...(tls ? ['        fastcgi_param HTTPS on;'] : []),
    `        fastcgi_pass unix:${socket};`,
    '    }',
    '}',
    '',
  ].join('\n');
}

function checkPort(value) {
  const port = value ?? DEFAULT_PHPMYADMIN_PORT;
  if (!Number.isInteger(port) || port < 1024 || port > 65535 || RESERVED_PORTS.has(port)) {
    throw invalid('port must be a free port from 1024 to 65535 that VaultPanel does not use itself');
  }
  return port;
}

async function certificateFor(policy, domain, certName) {
  if (domain === undefined || domain === null) {
    if (certName !== undefined && certName !== null) throw invalid('certName needs a domain');
    return null;
  }
  if (typeof domain !== 'string' || !DOMAIN_PATTERN.test(domain)) throw invalid('domain must be a domain name');
  if (typeof certName !== 'string' || !/^vp-[a-z0-9][a-z0-9-]{0,62}$/.test(certName)) throw invalid('certName must be a VaultPanel certificate name');
  const live = path.join(policy.letsencryptDir, 'live', certName);
  const tls = { domain, fullchain: path.join(live, 'fullchain.pem'), privkey: path.join(live, 'privkey.pem') };
  if (!(await exists(tls.fullchain)) || !(await exists(tls.privkey))) {
    throw new OperationError('CERTIFICATE_NOT_FOUND', `There is no certificate for ${domain} on this server`);
  }
  return tls;
}

// The newest PHP version with a running default pool.
async function phpSocket(ctx) {
  const versions = await installedPhpVersions(ctx.policy.phpConfRoot, ctx.binDirs);
  if (!versions.length) throw new OperationError('PHP_NOT_INSTALLED', 'phpMyAdmin needs PHP-FPM. Install it from the Software card on the server page.');
  const version = [...versions].sort((a, b) => Number(b) - Number(a))[0];
  const unit = `php${version}-fpm`;
  ctx.log('stdout', `$ systemctl start ${unit}`);
  await ctx.run('systemctl', ['start', `${unit}.service`], { timeoutMs: 60_000 });
  return path.join(ctx.policy.phpRunDir, `php${version}-fpm.sock`);
}

async function openPort(ctx, port) {
  const ufw = await findBinary('ufw', ctx.binDirs);
  if (!ufw) return false;
  const firewall = await readFirewall(ctx);
  if (!firewall.active || portOpenToAll(firewall.rules, port)) return false;
  await ufwRun(ctx, ufw, ['allow', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', String(port), 'comment', 'VaultPanel: phpMyAdmin'], `Allowing port ${port} for phpMyAdmin`);
  return true;
}

export const PHPMYADMIN_OPERATIONS = {
  PHPMYADMIN_SETUP: {
    async run(params, ctx) {
      onlyKeys(params, ['port', 'domain', 'certName']);
      const port = checkPort(params.port);
      const tls = await certificateFor(ctx.policy, params.domain, params.certName);
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
      await requireNginx(ctx);
      if (!(await findBinary('mariadbd', ctx.binDirs)) && !(await findBinary('mysqld', ctx.binDirs))) {
        throw new OperationError('DATABASE_SERVER_NOT_INSTALLED', 'MariaDB is not installed on this server. Install it from the Software card on the server page.');
      }
      const socket = await phpSocket(ctx);
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());

      if (!(await exists(path.join(PHPMYADMIN_ROOT, 'index.php')))) {
        // Answer the package's questions up front: no database of its own,
        // no Apache or lighttpd configuration.
        const debconf = await ctx.run('debconf-set-selections', [], { input: `${DEBCONF}\n`, timeoutMs: 30_000 });
        if (debconf.exitCode !== 0) ctx.log('stderr', 'debconf-set-selections failed; installing anyway');
        await aptInstall(ctx, ['phpmyadmin', 'php-mbstring', 'php-zip', 'php-gd', 'php-curl'], remaining);
      } else {
        ctx.log('stdout', 'phpMyAdmin is already installed; updating its VaultPanel settings');
      }
      await writeFileAtomic(path.join(CONF_D, SETTINGS_FILE), SETTINGS);
      await writeFileAtomic(path.join(PHPMYADMIN_ROOT, SIGNON_SCRIPT), signonScript());
      await chmod(path.join(PHPMYADMIN_ROOT, SIGNON_SCRIPT), 0o644);

      const available = path.join(ctx.policy.nginxSitesAvailable, PHPMYADMIN_SITE);
      const enabled = path.join(ctx.policy.nginxSitesEnabled, PHPMYADMIN_SITE);
      const previous = await readFile(available, 'utf8').catch(() => null);
      const ipv6 = await exists(ctx.policy.ipv6ProcFile ?? '/proc/net/if_inet6');
      await writeFileAtomic(available, phpMyAdminSite({ port, socket, tls, ipv6 }));
      await unlink(enabled).catch(() => {});
      await symlink(available, enabled);
      const test = await testNginx(ctx);
      if (!test.ok) {
        if (previous === null) {
          await rm(enabled, { force: true });
          await rm(available, { force: true });
        } else {
          await writeFileAtomic(available, previous);
        }
        throw new OperationError('NGINX_CONFIG_INVALID', `NGINX refused the phpMyAdmin configuration:\n${test.detail}`);
      }
      await reloadNginx(ctx);

      let opened = false;
      try {
        opened = await openPort(ctx, port);
      } catch (err) {
        ctx.log('stderr', `Could not open port ${port} in the firewall (${err.message}). Add a rule for it on the Firewall page.`);
      }
      if (opened) ctx.log('stdout', `The firewall is on: opened port ${port} for phpMyAdmin`);

      // NGINX may still be binding the new port right after the reload.
      let check;
      for (let i = 0; i < 5; i += 1) {
        check = await httpCheck({ port, host: tls?.domain ?? 'localhost', https: Boolean(tls) });
        if (!check.error) break;
        await new Promise((r) => setTimeout(r, 1000));
      }
      if (check.error || check.status >= 500) {
        throw new OperationError(
          'PHPMYADMIN_NOT_ANSWERING',
          `phpMyAdmin does not answer on port ${port} (${check.error ?? `HTTP ${check.status}`}). Another program may be using the port; try another one.`,
        );
      }
      ctx.webInventory?.invalidate();
      ctx.log('stdout', `phpMyAdmin is on port ${port}${tls ? ` (https://${tls.domain}:${port})` : ''}`);
      return { output: { port, domain: tls?.domain ?? null, https: Boolean(tls), firewallOpened: opened } };
    },
  },

  // Leaves a one-time ticket that vaultpanel-signon.php turns into a
  // phpMyAdmin session as the database's own full-access account (never
  // root). The panel keeps the token and sends only its SHA-256 here, so the
  // job record cannot be used to sign in.
  PHPMYADMIN_SIGNON: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'tokenHash']);
      const database = checkDatabaseName(params.name);
      if (typeof params.tokenHash !== 'string' || !TOKEN_HASH.test(params.tokenHash)) throw invalid('tokenHash must be a SHA-256 in hex');
      requireDatabases(ctx.policy);
      const root = ctx.policy.phpMyAdminRoot ?? PHPMYADMIN_ROOT;
      const dir = ctx.policy.phpMyAdminSignonDir ?? SIGNON_DIR;
      const served = await exists(path.join(ctx.policy.nginxSitesEnabled, PHPMYADMIN_SITE));
      if (!served || !(await exists(path.join(root, 'index.php')))) {
        throw new OperationError('PHPMYADMIN_NOT_SET_UP', 'phpMyAdmin is not set up on this server. Set it up from the phpMyAdmin card on the Databases page.');
      }
      const web = await lookupUser(ctx.policy.webServerUser ?? 'www-data', ctx.policy.passwdFile).catch(() => null);
      if (!web) throw new OperationError('WEB_USER_NOT_FOUND', 'The web server account (www-data) does not exist on this server');

      // Servers set up before one-click sign-in get the settings and script now.
      await writeFileAtomic(path.join(ctx.policy.phpMyAdminConfDir ?? CONF_D, SETTINGS_FILE), SETTINGS);
      await writeFileAtomic(path.join(root, SIGNON_SCRIPT), signonScript(dir));
      await chmod(path.join(root, SIGNON_SCRIPT), 0o644);

      // PHP (as the web server's group) may claim a ticket whose name it
      // knows but cannot list the folder.
      await mkdir(dir, { recursive: true, mode: 0o730 });
      if (process.getuid?.() === 0) await chown(dir, 0, web.gid);
      await chmod(dir, 0o730);
      await sweepTickets(dir);

      const user = browserAccount(database, 'write');
      const password = await accountPassword(ctx, user);
      await runSql(ctx, browserAccountSql(database, 'write', password), { log: false });

      const file = path.join(dir, `${params.tokenHash}.json`);
      const expires = Math.floor(Date.now() / 1000) + SIGNON_TTL_SECONDS;
      await writeFile(file, JSON.stringify({ user, password, database, expires }), { mode: 0o640, flag: 'wx' });
      if (process.getuid?.() === 0) await chown(file, 0, web.gid);
      ctx.log('stdout', `phpMyAdmin sign-in for ${database} is ready for ${SIGNON_TTL_SECONDS / 60} minutes`);
      return { output: { database, user, expiresAt: new Date(expires * 1000).toISOString() } };
    },
  },

  // Stops serving phpMyAdmin. The package stays installed (with its updates).
  PHPMYADMIN_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, []);
      await requireNginx(ctx);
      await rm(path.join(ctx.policy.nginxSitesEnabled, PHPMYADMIN_SITE), { force: true });
      await rm(path.join(ctx.policy.nginxSitesAvailable, PHPMYADMIN_SITE), { force: true });
      const test = await testNginx(ctx);
      if (!test.ok) throw new OperationError('NGINX_CONFIG_INVALID', `NGINX reports a problem in another configuration:\n${test.detail}`);
      await reloadNginx(ctx);
      ctx.webInventory?.invalidate();
      ctx.log('stdout', 'phpMyAdmin is no longer served. Its firewall rule, if any, can be removed on the Firewall page.');
      return { output: { removed: true } };
    },
  },
};
