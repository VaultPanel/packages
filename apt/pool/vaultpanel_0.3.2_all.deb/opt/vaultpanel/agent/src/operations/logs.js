import { findBinary } from '../monitoring/web.js';
import { LOG_PRIORITY_KEYS, LOG_SEARCH_PATTERN, LOG_SOURCE_KEYS } from '../security/automationRules.js';
import { onlyKeys, OperationError } from './errors.js';

// Server-wide logs from the systemd journal: everything, the kernel,
// authentication (SSH, sudo) or cron. A search is plain text matched
// without regard to case, in the agent, over the most recent lines.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
// How far back a search looks.
const SEARCH_WINDOW = 20_000;

const SOURCE_ARGS = {
  journal: [],
  kernel: ['--dmesg'],
  // auth and authpriv syslog facilities.
  auth: ['SYSLOG_FACILITY=4', 'SYSLOG_FACILITY=10'],
  cron: ['_SYSTEMD_UNIT=cron.service', '+', 'SYSLOG_IDENTIFIER=CRON'],
};

export function journalArgs({ source, priority, sinceMinutes, lines, search }, now = Date.now()) {
  const args = ['--no-pager', '--quiet', '--output=short-iso', `--lines=${search ? SEARCH_WINDOW : lines}`, `--priority=${priority}`];
  if (sinceMinutes) args.push(`--since=@${Math.floor((now - sinceMinutes * 60_000) / 1000)}`);
  return [...args, ...SOURCE_ARGS[source]];
}

function checkParams(params) {
  onlyKeys(params, ['source', 'priority', 'search', 'sinceMinutes', 'lines']);
  const spec = {
    source: params.source,
    priority: params.priority ?? 'debug',
    search: params.search ?? null,
    sinceMinutes: params.sinceMinutes ?? null,
    lines: params.lines ?? 300,
  };
  if (!LOG_SOURCE_KEYS.includes(spec.source)) throw invalid(`source must be one of ${LOG_SOURCE_KEYS.join(', ')}`);
  if (!LOG_PRIORITY_KEYS.includes(spec.priority)) throw invalid(`priority must be one of ${LOG_PRIORITY_KEYS.join(', ')}`);
  if (spec.search !== null && (typeof spec.search !== 'string' || !LOG_SEARCH_PATTERN.test(spec.search))) throw invalid('search must be plain text');
  if (spec.sinceMinutes !== null && (!Number.isInteger(spec.sinceMinutes) || spec.sinceMinutes < 1 || spec.sinceMinutes > 60 * 24 * 31)) throw invalid('sinceMinutes must be from 1 to 44640');
  if (!Number.isInteger(spec.lines) || spec.lines < 10 || spec.lines > 2000) throw invalid('lines must be from 10 to 2000');
  return spec;
}

export const LOG_OPERATIONS = {
  SYSTEM_LOGS: {
    async run(params, ctx) {
      const spec = checkParams(params);
      const journalctl = await findBinary('journalctl', ctx.binDirs);
      if (!journalctl) throw new OperationError('LOGS_UNAVAILABLE', 'journalctl is not available on this server (the agent reads logs from the systemd journal)');
      const result = await ctx.run(journalctl, journalArgs(spec), { timeoutMs: 45_000, maxOutputBytes: 16 * 1024 * 1024 });
      if (result.timedOut) throw new OperationError('TIMEOUT', 'journalctl did not finish in time. Narrow the time range.');
      if (result.error || result.exitCode !== 0) {
        throw new OperationError('COMMAND_FAILED', (result.stderr || result.error?.message || 'journalctl failed').trim().split('\n').slice(-3).join('\n'));
      }
      let lines = result.stdout.split('\n').filter((line) => line.length && !line.startsWith('-- '));
      const scanned = lines.length;
      if (spec.search) {
        const needle = spec.search.toLowerCase();
        lines = lines.filter((line) => line.toLowerCase().includes(needle));
      }
      const matched = lines.length;
      return {
        output: {
          source: spec.source,
          lines: lines.slice(-spec.lines).map((line) => line.slice(0, 4000)),
          scanned,
          matched,
          truncated: matched > spec.lines,
        },
      };
    },
  },
};
