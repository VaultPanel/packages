import { createHash, randomBytes } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { access, chmod, mkdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { findBinary } from '../monitoring/web.js';
import {
  CMS_ADMIN_PASSWORD_PATTERN,
  CMS_ADMIN_USER_PATTERN,
  CMS_APP_KEYS,
  CMS_DIRECTORY_PATTERN,
  CMS_RESERVED_FOLDERS,
  CMS_TITLE_PATTERN,
  CMS_URL_PATTERN,
  CMS_VERSION_PATTERN,
} from '../security/cmsRules.js';
import { DATABASE_PASSWORD_PATTERN } from '../security/appRules.js';
import { EMAIL_PATTERN } from '../security/webRules.js';
import { checkPhpVersion, checkSiteName, sitePaths } from '../services/siteConfig.js';
import { DEFAULT_PATH } from '../utils/exec.js';
import { AGENT_VERSION } from '../utils/version.js';
import { checkDatabaseName, checkDatabaseUser, requireDatabases } from './databases.js';
import { onlyKeys, OperationError } from './errors.js';
import { fileRunner, requireSiteAccount, requireWebsites } from './sites.js';
import { aptInstall } from './webStack.js';

// The app installer: WordPress, Joomla, Drupal and Laravel in a website.
//
// The panel has already created the app's database and its user. The agent
// downloads the app from its own project and checks it before anything is
// unpacked: WordPress against the SHA-1 wordpress.org publishes next to each
// release, Joomla against the SHA-256 GitHub records for each release file.
// Drupal and Laravel come through Composer, their projects' own way of
// installing, which checks every package it downloads.
//
// Everything in the site runs as the site's own Linux user: unpacking,
// Composer and each app's installer. Passwords reach the installers through
// their environment, never their command line (which every user can read).
// A failed install removes what it put in the site.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const exists = (p) => access(p).then(() => true, () => false);

export const CMS_MIN_PHP = { wordpress: '7.4', joomla: '8.1', drupal: '8.1', laravel: '8.2' };
// Joomla's PHP needs by major version (the newest release this PHP can run is used).
export const JOOMLA_MIN_PHP = { 4: '7.2', 5: '8.1', 6: '8.3' };
const PROJECT_APPS = { drupal: 'web', laravel: 'public' };
// What a new site starts with (sites.js placeholderPage); it may be replaced.
const PLACEHOLDERS = ['index.php', 'index.html'];
const MAX_DOWNLOAD_BYTES = 256 * 1024 * 1024;
const FETCH_HOSTS = new Set(['api.wordpress.org', 'wordpress.org', 'downloads.wordpress.org', 'api.github.com', 'github.com']);

export function phpAtLeast(version, minimum) {
  const a = String(version).split('.').map(Number);
  const b = String(minimum).split('.').map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const x = a[i] ?? 0;
    const y = b[i] ?? 0;
    if (x !== y) return x > y;
  }
  return true;
}

function compareVersions(a, b) {
  return phpAtLeast(a, b) ? (phpAtLeast(b, a) ? 0 : 1) : -1;
}

function checkDirectory(value) {
  if (typeof value !== 'string' || value.length > 300 || !CMS_DIRECTORY_PATTERN.test(value)) throw invalid('directory must be a folder inside the site');
  if (value.split('/').some((part) => /^\.+$/.test(part))) throw invalid('directory must be a folder inside the site');
  if (CMS_RESERVED_FOLDERS.includes(value.split('/')[0])) throw new OperationError('NOT_ALLOWED', `${value.split('/')[0]} belongs to the site itself`);
  return value;
}

function optional(params, key, pattern, message) {
  const value = params[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string' || !pattern.test(value)) throw invalid(message);
  return value;
}

export function checkInstall(params) {
  if (!CMS_APP_KEYS.includes(params.app)) throw invalid(`app must be one of ${CMS_APP_KEYS.join(', ')}`);
  const spec = {
    app: params.app,
    site: checkSiteName(params.site),
    phpVersion: checkPhpVersion(params.phpVersion),
    directory: checkDirectory(params.directory),
    databaseName: checkDatabaseName(params.databaseName),
    databaseUser: checkDatabaseUser(params.databaseUser),
    databasePassword: null,
    title: optional(params, 'title', CMS_TITLE_PATTERN, 'title must be up to 100 characters'),
    adminUser: optional(params, 'adminUser', CMS_ADMIN_USER_PATTERN, 'adminUser must be 3 to 60 letters, digits, dots, dashes or underscores'),
    adminEmail: optional(params, 'adminEmail', EMAIL_PATTERN, 'adminEmail must be an email address'),
    adminPassword: optional(params, 'adminPassword', CMS_ADMIN_PASSWORD_PATTERN, 'adminPassword must be 12 to 128 characters without spaces'),
  };
  if (typeof params.databasePassword !== 'string' || !DATABASE_PASSWORD_PATTERN.test(params.databasePassword)) throw invalid('databasePassword is not a valid database password');
  spec.databasePassword = params.databasePassword;
  if (typeof params.url !== 'string' || params.url.length > 400 || !CMS_URL_PATTERN.test(params.url)) throw invalid('url must be the address of the app');
  spec.url = params.url.replace(/\/$/, '');
  if (spec.app !== 'laravel') {
    for (const key of ['title', 'adminUser', 'adminEmail', 'adminPassword']) {
      if (!spec[key]) throw invalid(`${key} is required for ${spec.app}`);
    }
  }
  if (PROJECT_APPS[spec.app] && spec.directory.includes('/')) throw invalid(`${spec.app} goes in a folder at the top of the site`);
  return spec;
}

// ---- Downloads ----------------------------------------------------------

function checkUrl(url) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || !FETCH_HOSTS.has(parsed.hostname)) throw new OperationError('CMS_SOURCE_UNAVAILABLE', `Refusing to download from ${parsed.hostname}`);
  return parsed;
}

async function request(ctx, url, { json = false } = {}) {
  checkUrl(url);
  const fetcher = ctx.fetch ?? fetch;
  let res;
  try {
    res = await fetcher(url, {
      headers: { 'User-Agent': `VaultPanel-Agent/${AGENT_VERSION}`, Accept: json && new URL(url).hostname === 'api.github.com' ? 'application/vnd.github+json' : '*/*' },
      redirect: 'follow',
      signal: AbortSignal.timeout(ctx.downloadTimeoutMs ?? 600_000),
    });
  } catch (err) {
    throw new OperationError('CMS_SOURCE_UNAVAILABLE', `Could not reach ${new URL(url).hostname}: ${err.cause?.message ?? err.message}`);
  }
  if (!res.ok) throw new OperationError('CMS_SOURCE_UNAVAILABLE', `${url} answered HTTP ${res.status}`);
  if (res.url && !res.url.startsWith('https://')) throw new OperationError('CMS_SOURCE_UNAVAILABLE', `${url} redirected away from HTTPS`);
  return res;
}

async function getJson(ctx, url) {
  const res = await request(ctx, url, { json: true });
  const text = await res.text();
  if (text.length > 4 * 1024 * 1024) throw new OperationError('CMS_SOURCE_UNAVAILABLE', `${url} sent too much data`);
  try {
    return JSON.parse(text);
  } catch {
    throw new OperationError('CMS_SOURCE_UNAVAILABLE', `${url} did not send JSON`);
  }
}

// Streams a download to file and returns its size and hashes.
async function download(ctx, url, file) {
  const res = await request(ctx, url);
  const hashes = { sha1: createHash('sha1'), sha256: createHash('sha256') };
  let size = 0;
  const body = Readable.fromWeb(res.body);
  body.on('data', (chunk) => {
    size += chunk.length;
    if (size > MAX_DOWNLOAD_BYTES) body.destroy(new OperationError('CMS_DOWNLOAD_TOO_LARGE', `${url} is larger than ${MAX_DOWNLOAD_BYTES / 1024 / 1024} MB`));
    for (const hash of Object.values(hashes)) hash.update(chunk);
  });
  try {
    await pipeline(body, createWriteStream(file, { mode: 0o644 }));
  } catch (err) {
    if (err instanceof OperationError) throw err;
    throw new OperationError('CMS_SOURCE_UNAVAILABLE', `The download from ${url} failed: ${err.message}`);
  }
  return { size, sha1: hashes.sha1.digest('hex'), sha256: hashes.sha256.digest('hex') };
}

// The newest WordPress release and its published SHA-1.
export async function resolveWordPress(ctx) {
  const data = await getJson(ctx, 'https://api.wordpress.org/core/version-check/1.7/');
  const offers = Array.isArray(data?.offers) ? data.offers : [];
  const offer = offers.find((o) => ['upgrade', 'latest'].includes(o?.response)) ?? offers[0];
  const version = offer?.current ?? offer?.version;
  if (typeof version !== 'string' || !CMS_VERSION_PATTERN.test(version)) throw new OperationError('CMS_SOURCE_UNAVAILABLE', 'wordpress.org did not say which WordPress version is current');
  const url = `https://wordpress.org/wordpress-${version}.tar.gz`;
  const sum = (await (await request(ctx, `${url}.sha1`)).text()).trim().slice(0, 40);
  if (!/^[a-f0-9]{40}$/.test(sum)) throw new OperationError('CMS_SOURCE_UNAVAILABLE', 'wordpress.org did not publish a checksum for this release');
  const minPhp = typeof offer.php_version === 'string' && /^\d+\.\d+/.test(offer.php_version) ? offer.php_version.match(/^\d+\.\d+/)[0] : null;
  return { version, url, file: `wordpress-${version}.tar.gz`, checksum: { algorithm: 'sha1', value: sum }, minPhp };
}

// The newest Joomla release this PHP version can run, from the project's
// GitHub releases, with the SHA-256 GitHub keeps for the full package.
export async function resolveJoomla(ctx, phpVersion) {
  const releases = await getJson(ctx, 'https://api.github.com/repos/joomla/joomla-cms/releases?per_page=40');
  if (!Array.isArray(releases)) throw new OperationError('CMS_SOURCE_UNAVAILABLE', 'GitHub did not list the Joomla releases');
  const stable = releases
    .filter((r) => r && !r.draft && !r.prerelease && typeof r.tag_name === 'string' && CMS_VERSION_PATTERN.test(r.tag_name))
    .sort((a, b) => compareVersions(b.tag_name, a.tag_name));
  let tooNew = null;
  for (const release of stable) {
    const min = JOOMLA_MIN_PHP[Number(release.tag_name.split('.')[0])];
    if (!min) continue;
    if (!phpAtLeast(phpVersion, min)) {
      tooNew ??= { version: release.tag_name, min };
      continue;
    }
    const asset = (release.assets ?? []).find((a) => /^Joomla_[0-9.]+-Stable-Full_Package\.tar\.gz$/.test(a?.name ?? ''));
    const digest = /^sha256:([a-f0-9]{64})$/.exec(asset?.digest ?? '')?.[1];
    const prefix = `https://github.com/joomla/joomla-cms/releases/download/${release.tag_name}/`;
    if (!asset || !digest || !String(asset.browser_download_url).startsWith(prefix)) continue;
    return { version: release.tag_name, url: asset.browser_download_url, file: asset.name, checksum: { algorithm: 'sha256', value: digest } };
  }
  if (tooNew) throw new OperationError('CMS_PHP_TOO_OLD', `Joomla ${tooNew.version} needs PHP ${tooNew.min} or newer. Switch the website to a newer PHP version first.`);
  throw new OperationError('CMS_SOURCE_UNAVAILABLE', 'No Joomla release with a published checksum was found on GitHub');
}

// ---- Packages -------------------------------------------------------------

export function packagesFor(app, phpVersion) {
  const ext = ['cli', 'mysql', 'xml', 'mbstring', 'curl', 'zip', 'gd', 'intl'];
  if (app === 'laravel') ext.push('bcmath');
  if (phpVersion === '7.4') ext.push('json');
  const packages = ext.map((e) => `php${phpVersion}-${e}`);
  if (PROJECT_APPS[app]) packages.push('composer', 'unzip');
  return packages;
}

async function missingPackages(ctx, packages) {
  const result = await ctx.run('dpkg-query', ['-W', '-f=${Package}\t${db:Status-Status}\n', ...packages], { timeoutMs: 30_000 });
  const installed = new Set(
    (result.stdout ?? '')
      .split('\n')
      .map((line) => line.split('\t'))
      .filter(([, status]) => status === 'installed')
      .map(([name]) => name),
  );
  return packages.filter((p) => !installed.has(p));
}

async function ensurePackages(ctx, spec, remaining) {
  const missing = await missingPackages(ctx, packagesFor(spec.app, spec.phpVersion));
  if (!missing.length) return;
  if (ctx.policy.allowWebStackInstall === false) {
    throw new OperationError('NOT_ALLOWED', `${spec.app} needs ${missing.join(', ')}, and installing packages is disabled in this agent config`);
  }
  ctx.log('stdout', `Installing what ${spec.app} needs: ${missing.join(' ')}`);
  await aptInstall(ctx, missing, remaining);
  // PHP-FPM loads new extensions on reload.
  const reload = await ctx.run('systemctl', ['reload', `php${spec.phpVersion}-fpm.service`], { timeoutMs: 60_000 });
  if (reload.exitCode !== 0) ctx.log('stderr', `php${spec.phpVersion}-fpm did not reload; restart it from the Services tab if the app reports a missing extension`);
}

// ---- Running things as the site user --------------------------------------

function lastLines(result, count = 10) {
  return `${result.stderr ?? ''}\n${result.stdout ?? ''}`.trim().split('\n').filter(Boolean).slice(-count).join('\n');
}

function siteEnv(ctx, home, extra = {}) {
  const proxy = ctx.policy.deployEnv && typeof ctx.policy.deployEnv === 'object' ? ctx.policy.deployEnv : {};
  const safe = Object.fromEntries(Object.entries(proxy).filter(([k, v]) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === 'string'));
  return { ...safe, PATH: DEFAULT_PATH, LANG: 'C.UTF-8', HOME: home, ...extra };
}

async function runAsSite(ctx, env, file, args, { cwd, extraEnv = {}, input, what, log = true }) {
  const result = await ctx.run(file, args, {
    uid: env.account.uid,
    gid: env.account.gid,
    cwd,
    env: siteEnv(ctx, env.paths.home, extraEnv),
    input,
    timeoutMs: env.remaining(),
    onLine: log ? ctx.log : undefined,
  });
  if (result.timedOut) throw new OperationError('TIMEOUT', `${what} did not finish in time`);
  if (result.error || result.exitCode !== 0) {
    throw new OperationError('CMS_INSTALL_FAILED', `${what} failed: ${lastLines(result) || result.error?.message || `exit code ${result.exitCode}`}`);
  }
  return result;
}

// PHP code given on stdin, so nothing secret is in a file or on the command line.
function runPhp(ctx, env, script, { cwd, extraEnv, what }) {
  return runAsSite(ctx, env, env.php, ['-d', 'display_errors=stderr', '-d', 'memory_limit=1024M'], { cwd, extraEnv, input: script, what });
}

// Runs a PHP command-line program with the given arguments, through PHP on
// stdin, so the arguments (passwords among them) never show in the process list.
const ARGV_WRAPPER = `<?php
$args = json_decode((string) getenv('VP_ARGV'), true);
putenv('VP_ARGV');
unset($_ENV['VP_ARGV'], $_SERVER['VP_ARGV']);
$_SERVER['argv'] = $GLOBALS['argv'] = $args;
$_SERVER['argc'] = $GLOBALS['argc'] = count($args);
require getcwd() . '/' . $args[0];
`;

function runPhpProgram(ctx, env, argv, { cwd, what }) {
  return runPhp(ctx, env, ARGV_WRAPPER, { cwd, extraEnv: { VP_ARGV: JSON.stringify(argv) }, what });
}

function composerEnv(home) {
  const dir = path.join(home, 'tmp', '.vp-composer');
  return { COMPOSER_HOME: dir, COMPOSER_CACHE_DIR: path.join(dir, 'cache'), COMPOSER_NO_INTERACTION: '1', COMPOSER_PROCESS_TIMEOUT: '900' };
}

function runComposer(ctx, env, args, { cwd, what }) {
  return runAsSite(ctx, env, env.php, [env.composer, ...args, '--no-interaction', '--no-progress', '--no-ansi'], { cwd, extraEnv: composerEnv(env.paths.home), what });
}

// Removes a folder the site user may have made read-only (Drupal does).
async function removeFolder(ctx, env, rel) {
  const abs = path.join(env.paths.home, rel);
  if (!(await exists(abs))) return;
  await ctx.run('chmod', ['-R', 'u+w', abs], { uid: env.account.uid, gid: env.account.gid, timeoutMs: 120_000 });
  await env.files({ action: 'delete', path: rel }, 600_000);
}

// ---- Apps -----------------------------------------------------------------

const RANDOM_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#%()*+,-./:;<=>?@[]^_{|}~';
function randomText(length, alphabet = RANDOM_ALPHABET) {
  const bytes = randomBytes(length);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}

const phpString = (value) => `'${String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;

export function wordpressConfig(spec) {
  const salts = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'];
  return `<?php
// Written by VaultPanel when it installed WordPress.
define( 'DB_NAME', ${phpString(spec.databaseName)} );
define( 'DB_USER', ${phpString(spec.databaseUser)} );
define( 'DB_PASSWORD', ${phpString(spec.databasePassword)} );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );

${salts.map((key) => `define( '${key}', ${phpString(randomText(64))} );`).join('\n')}

$table_prefix = 'wp_';

define( 'WP_DEBUG', false );
// Files belong to the site's own user, which PHP runs as: updates and
// plugins install directly.
define( 'FS_METHOD', 'direct' );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}
require_once ABSPATH . 'wp-settings.php';
`;
}

// Runs WordPress's own installer (what its setup page does), without
// sending the welcome email.
const WORDPRESS_INSTALL = `<?php
$url = getenv('VP_URL');
$parts = parse_url($url);
$_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'] = $parts['host'];
$_SERVER['REQUEST_URI'] = ($parts['path'] ?? '') . '/wp-admin/install.php';
$_SERVER['SERVER_PORT'] = $parts['scheme'] === 'https' ? 443 : 80;
if ($parts['scheme'] === 'https') { $_SERVER['HTTPS'] = 'on'; }
define('WP_INSTALLING', true);
function wp_new_blog_notification($blog_title = '', $blog_url = '', $user_id = 0, $password = '') {}
require getcwd() . '/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
if (is_blog_installed()) { fwrite(STDERR, "WordPress is already installed in this database\\n"); exit(3); }
$result = wp_install(getenv('VP_TITLE'), getenv('VP_ADMIN_USER'), getenv('VP_ADMIN_EMAIL'), true, '', wp_slash(getenv('VP_ADMIN_PASSWORD')));
if (is_wp_error($result)) { fwrite(STDERR, $result->get_error_message() . "\\n"); exit(4); }
update_option('siteurl', $url);
update_option('home', $url);
echo "WordPress " . get_bloginfo('version') . " is installed\\n";
`;

async function installWordPress(ctx, env, spec) {
  await env.files({ action: 'write', path: `${spec.directory}/wp-config.php`, content: wordpressConfig(spec), overwrite: false, mode: 0o600 });
  ctx.log('stdout', 'Wrote wp-config.php; running the WordPress installer');
  await runPhp(ctx, env, WORDPRESS_INSTALL, {
    cwd: path.join(env.paths.home, spec.directory),
    extraEnv: { VP_URL: spec.url, VP_TITLE: spec.title, VP_ADMIN_USER: spec.adminUser, VP_ADMIN_EMAIL: spec.adminEmail, VP_ADMIN_PASSWORD: spec.adminPassword },
    what: 'The WordPress installer',
  });
}

async function installJoomla(ctx, env, spec) {
  const prefix = `${randomText(4, 'abcdefghijklmnopqrstuvwxyz')}_`;
  ctx.log('stdout', 'Running the Joomla installer');
  await runPhpProgram(
    ctx,
    env,
    [
      'installation/joomla.php',
      'install',
      '--no-interaction',
      `--site-name=${spec.title}`,
      `--admin-user=${spec.adminUser}`,
      `--admin-username=${spec.adminUser}`,
      `--admin-password=${spec.adminPassword}`,
      `--admin-email=${spec.adminEmail}`,
      '--db-type=mysqli',
      '--db-host=localhost',
      `--db-user=${spec.databaseUser}`,
      `--db-pass=${spec.databasePassword}`,
      `--db-name=${spec.databaseName}`,
      `--db-prefix=${prefix}`,
      '--db-encryption=0',
    ],
    { cwd: path.join(env.paths.home, spec.directory), what: 'The Joomla installer' },
  );
  // The installer is not needed again; Joomla refuses to run while it is there.
  if (await exists(path.join(env.paths.home, spec.directory, 'installation'))) {
    await removeFolder(ctx, env, `${spec.directory}/installation`);
  }
}

// Sets KEY=value in a .env file, replacing the line (even commented out)
// or adding it.
export function setEnvValue(text, key, value) {
  const quoted = /^[A-Za-z0-9_.:/@-]*$/.test(value) ? value : `"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
  const line = new RegExp(`^#?\\s*${key}=.*$`, 'm');
  return line.test(text) ? text.replace(line, `${key}=${quoted}`) : `${text.replace(/\n?$/, '\n')}${key}=${quoted}\n`;
}

async function installLaravel(ctx, env, spec) {
  ctx.log('stdout', '$ composer create-project laravel/laravel');
  await runComposer(ctx, env, ['create-project', 'laravel/laravel', spec.directory, '--prefer-dist', '--no-scripts'], { cwd: env.paths.home, what: 'composer create-project' });
  const root = path.join(env.paths.home, spec.directory);
  const example = await env.files({ action: 'read', path: `${spec.directory}/.env.example` }).catch(() => ({ content: '' }));
  let text = example.encoding === 'base64' ? '' : (example.content ?? '');
  const values = {
    APP_NAME: spec.title ?? 'Laravel',
    APP_ENV: 'production',
    APP_DEBUG: 'false',
    APP_URL: spec.url,
    DB_CONNECTION: 'mysql',
    DB_HOST: '127.0.0.1',
    DB_PORT: '3306',
    DB_DATABASE: spec.databaseName,
    DB_USERNAME: spec.databaseUser,
    DB_PASSWORD: spec.databasePassword,
  };
  for (const [key, value] of Object.entries(values)) text = setEnvValue(text, key, value);
  await env.files({ action: 'write', path: `${spec.directory}/.env`, content: text, mode: 0o600 });
  ctx.log('stdout', 'Wrote .env with the database settings');
  for (const [args, what] of [
    [['artisan', 'package:discover'], 'php artisan package:discover'],
    [['artisan', 'key:generate', '--force'], 'php artisan key:generate'],
    [['artisan', 'migrate', '--force'], 'php artisan migrate'],
  ]) {
    ctx.log('stdout', `$ ${what}`);
    await runAsSite(ctx, env, env.php, args, { cwd: root, what });
  }
  const about = await runAsSite(ctx, env, env.php, ['artisan', '--version'], { cwd: root, what: 'php artisan --version', log: false });
  return /(\d+\.\d+\.\d+)/.exec(about.stdout ?? '')?.[1] ?? null;
}

async function installDrupal(ctx, env, spec) {
  ctx.log('stdout', '$ composer create-project drupal/recommended-project');
  await runComposer(ctx, env, ['create-project', 'drupal/recommended-project', spec.directory], { cwd: env.paths.home, what: 'composer create-project' });
  const root = path.join(env.paths.home, spec.directory);
  ctx.log('stdout', '$ composer require drush/drush');
  await runComposer(ctx, env, ['require', 'drush/drush'], { cwd: root, what: 'composer require drush/drush' });
  ctx.log('stdout', '$ drush site:install standard');
  const dbUrl = `mysql://${encodeURIComponent(spec.databaseUser)}:${encodeURIComponent(spec.databasePassword)}@localhost/${spec.databaseName}`;
  await runPhpProgram(
    ctx,
    env,
    [
      'vendor/bin/drush',
      'site:install',
      'standard',
      '--yes',
      `--uri=${spec.url}`,
      `--db-url=${dbUrl}`,
      `--site-name=${spec.title}`,
      `--site-mail=${spec.adminEmail}`,
      `--account-name=${spec.adminUser}`,
      `--account-mail=${spec.adminEmail}`,
      `--account-pass=${spec.adminPassword}`,
    ],
    { cwd: root, what: 'drush site:install' },
  );
  const status = await runAsSite(ctx, env, env.php, ['vendor/bin/drush', 'status', '--field=drupal-version'], { cwd: root, what: 'drush status', log: false });
  return /(\d+\.\d+\.\d+)/.exec(status.stdout ?? '')?.[1] ?? null;
}

// Where releases are downloaded to. tar runs as the site user and opens the
// file itself, so the folder must be passable for everyone. Its parent
// (/var/cache/vaultpanel) may have been created closed (0700) for npm's
// cache; it only needs to be passable, not listable.
async function ensureCacheDir(policy) {
  const cacheDir = policy.cmsCacheDir ?? '/var/cache/vaultpanel/cms';
  await mkdir(cacheDir, { recursive: true, mode: 0o755 });
  const parent = await stat(path.dirname(cacheDir));
  if ((parent.mode & 0o011) !== 0o011) await chmod(path.dirname(cacheDir), (parent.mode & 0o7777) | 0o011);
  await chmod(cacheDir, 0o755);
  return cacheDir;
}

// Downloads and checks a release, unpacks it as the site user and moves it
// into place. Returns what was placed, for undoing.
async function placeRelease(ctx, env, spec, source) {
  const cacheDir = await ensureCacheDir(ctx.policy);
  const archive = path.join(cacheDir, `${randomBytes(6).toString('hex')}-${source.file}`);
  const staging = `.vp-cms-${randomBytes(6).toString('hex')}`;
  try {
    ctx.log('stdout', `Downloading ${source.url}`);
    const got = await download(ctx, source.url, archive);
    if (got[source.checksum.algorithm] !== source.checksum.value) {
      throw new OperationError('CMS_CHECKSUM_MISMATCH', `The download does not match its published ${source.checksum.algorithm.toUpperCase()} (${source.checksum.value}), so it was thrown away`);
    }
    ctx.log('stdout', `${(got.size / 1024 / 1024).toFixed(1)} MB, ${source.checksum.algorithm.toUpperCase()} ${source.checksum.value} matches the published checksum`);
    await chmod(archive, 0o644);
    await env.files({ action: 'appInit', folders: [{ path: staging, mode: 0o700 }] });
    try {
      ctx.log('stdout', `Unpacking as ${spec.site}`);
      await runAsSite(ctx, env, 'tar', ['-xzf', archive, '-C', path.join(env.paths.home, staging), '--no-same-owner', '--no-same-permissions'], {
        cwd: env.paths.home,
        what: 'Unpacking the release',
        log: false,
      });
      // Releases usually unpack into one folder (wordpress/); its contents are the app.
      const listing = await env.files({ action: 'list', path: staging });
      const only = listing.entries.length === 1 && listing.entries[0].type === 'dir' ? listing.entries[0].name : null;
      const from = only ? `${staging}/${only}` : staging;
      const placed = await env.files({ action: 'place', from, to: spec.directory, replaceable: PLACEHOLDERS });
      if (placed.replaced.length) ctx.log('stdout', `Replaced the site's starter page (${placed.replaced.join(', ')})`);
      ctx.log('stdout', `Put ${placed.moved.length} files and folders in ${spec.directory}`);
      return placed;
    } finally {
      await env.files({ action: 'delete', path: staging }, 300_000).catch(() => {});
    }
  } finally {
    await rm(archive, { force: true });
  }
}

async function undoPlace(ctx, env, spec, placed) {
  if (!placed) return;
  ctx.log('stderr', `Removing what the install put in ${spec.directory}`);
  try {
    if (placed.created) await removeFolder(ctx, env, placed.created);
    else for (const name of placed.moved) await removeFolder(ctx, env, `${spec.directory}/${name}`);
  } catch (err) {
    ctx.log('stderr', `Could not remove everything (${err.message}); clean ${spec.directory} with the file manager`);
  }
}

export const CMS_OPERATIONS = {
  CMS_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, ['app', 'site', 'phpVersion', 'directory', 'url', 'databaseName', 'databaseUser', 'databasePassword', 'title', 'adminUser', 'adminEmail', 'adminPassword']);
      const spec = checkInstall(params);
      requireWebsites(ctx.policy);
      requireDatabases(ctx.policy);
      const deadline = Date.now() + (ctx.timeoutMs ?? 1_800_000);
      const remaining = () => Math.max(10_000, deadline - Date.now());
      const paths = sitePaths(ctx.policy, spec.site);
      const account = await requireSiteAccount(ctx, spec.site, paths);
      const run = fileRunner(ctx);
      const files = (req, timeoutMs = 120_000) => run(account, { ...req, home: paths.home }, { timeoutMs });

      if (!phpAtLeast(spec.phpVersion, CMS_MIN_PHP[spec.app])) {
        throw new OperationError('CMS_PHP_TOO_OLD', `${spec.app} needs PHP ${CMS_MIN_PHP[spec.app]} or newer; this site runs PHP ${spec.phpVersion}. Switch its PHP version first.`);
      }
      if (!(await exists(path.join(ctx.policy.phpConfRoot, spec.phpVersion, 'fpm')))) {
        throw new OperationError('PHP_NOT_INSTALLED', `PHP ${spec.phpVersion} is not installed on this server`);
      }
      const target = await files({ action: 'inspectTarget', path: spec.directory, replaceable: PROJECT_APPS[spec.app] ? [] : PLACEHOLDERS });
      if (!target.free) {
        throw new OperationError('CMS_TARGET_NOT_EMPTY', `${spec.directory} already has files in it (${target.blocking.join(', ')}). Pick another folder, or empty it with the file manager.`);
      }

      await ensurePackages(ctx, spec, remaining);
      const php = await findBinary(`php${spec.phpVersion}`, ctx.binDirs);
      if (!php) throw new OperationError('PHP_NOT_INSTALLED', `The PHP ${spec.phpVersion} command line (php${spec.phpVersion}) is missing`);
      const composer = PROJECT_APPS[spec.app] ? await findBinary('composer', ctx.binDirs) : null;
      if (PROJECT_APPS[spec.app] && !composer) throw new OperationError('INSTALL_FAILED', 'Composer is not installed');
      const env = { account, paths, files, php, composer, remaining };

      let version;
      let placed = null;
      try {
        if (spec.app === 'wordpress' || spec.app === 'joomla') {
          const source = spec.app === 'wordpress' ? await resolveWordPress(ctx) : await resolveJoomla(ctx, spec.phpVersion);
          if (source.minPhp && !phpAtLeast(spec.phpVersion, source.minPhp)) {
            throw new OperationError('CMS_PHP_TOO_OLD', `${spec.app === 'wordpress' ? 'WordPress' : 'Joomla'} ${source.version} needs PHP ${source.minPhp} or newer`);
          }
          ctx.log('stdout', `${spec.app === 'wordpress' ? 'WordPress' : 'Joomla'} ${source.version} from ${new URL(source.url).hostname}`);
          version = source.version;
          placed = await placeRelease(ctx, env, spec, source);
          if (spec.app === 'wordpress') await installWordPress(ctx, env, spec);
          else await installJoomla(ctx, env, spec);
        } else {
          placed = { created: spec.directory, moved: [] };
          version = spec.app === 'laravel' ? await installLaravel(ctx, env, spec) : await installDrupal(ctx, env, spec);
        }
      } catch (err) {
        await undoPlace(ctx, env, spec, placed);
        throw err;
      } finally {
        if (PROJECT_APPS[spec.app]) await rm(path.join(paths.home, 'tmp', '.vp-composer'), { recursive: true, force: true }).catch(() => {});
      }
      const publicDirectory = PROJECT_APPS[spec.app] ? `${spec.directory}/${PROJECT_APPS[spec.app]}` : null;
      ctx.log('stdout', `${spec.app} ${version ?? ''} is installed in ${spec.directory}`.replace(/ {2}/, ' '));
      ctx.webInventory?.invalidate();
      return { output: { app: spec.app, version, directory: spec.directory, publicDirectory, url: spec.url } };
    },
  },

  // Removes an installed app's files. The site's document root itself is
  // emptied and kept (keepFolder). Its database is removed by the panel.
  CMS_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['site', 'directory', 'keepFolder']);
      const site = checkSiteName(params.site);
      const directory = checkDirectory(params.directory);
      const keepFolder = params.keepFolder ?? false;
      if (typeof keepFolder !== 'boolean') throw invalid('keepFolder must be true or false');
      requireWebsites(ctx.policy);
      const paths = sitePaths(ctx.policy, site);
      const account = await requireSiteAccount(ctx, site, paths);
      const run = fileRunner(ctx);
      const files = (req, timeoutMs = 600_000) => run(account, { ...req, home: paths.home }, { timeoutMs });
      const env = { account, paths, files };
      if (!(await exists(path.join(paths.home, directory)))) {
        ctx.log('stdout', `${directory} is already gone`);
      } else {
        ctx.log('stdout', `Removing ${directory}`);
        await removeFolder(ctx, env, directory);
      }
      if (keepFolder) await files({ action: 'init', documentRoot: directory, folders: [] });
      ctx.webInventory?.invalidate();
      return { output: { directory, removed: true } };
    },
  },
};
