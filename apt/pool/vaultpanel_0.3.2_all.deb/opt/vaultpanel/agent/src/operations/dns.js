import net from 'node:net';
import { mkdir, readdir, readFile, rm } from 'node:fs/promises';
import { detectDns, dnsPaths, DNS_MANAGED_MARK, findBinary } from '../monitoring/web.js';
import {
  DNS_CAA_TAGS,
  DNS_CAA_VALUE_PATTERN,
  DNS_EMAIL_PATTERN,
  DNS_HOSTNAME_PATTERN,
  DNS_RECORD_NAME_PATTERN,
  DNS_RECORD_TYPES,
  DNS_TTL,
  DNS_TXT_PATTERN,
  MAX_DNS_RECORDS,
} from '../security/dnsRules.js';
import { DOMAIN_PATTERN } from '../security/webRules.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';
import { allowServicePorts } from './firewall.js';
import { writeFileAtomic } from './sites.js';
import { aptInstall } from './webStack.js';

// DNS zones, served by BIND from this server. BIND runs as an authoritative
// name server only: it answers for the zones VaultPanel wrote and refuses to
// look up other names for anyone (an open resolver gets abused for attacks).
//
// The panel sends the whole zone each time. The agent checks every record
// again, writes the zone file, has named-checkzone check it before it goes
// live, and keeps the previous file when anything fails. A zone never goes
// back to an older serial.

const PACKAGES = ['bind9', 'bind9-utils', 'bind9-dnsutils'];
const MARK = DNS_MANAGED_MARK;
const invalid = (message) => new OperationError('INVALID_PARAMS', message);

export const OPTIONS = `${MARK}. Overwritten when the DNS server is set up again from the panel.
// The file it replaced is kept as named.conf.options.vaultpanel-orig.
options {
	directory "/var/cache/bind";
	// Authoritative only: answers for the zones on this server and never
	// looks up other names for anyone.
	recursion no;
	allow-query { any; };
	allow-transfer { none; };
	dnssec-validation auto;
	listen-on { any; };
	listen-on-v6 { any; };
	version none;
	minimal-responses yes;
	rate-limit { responses-per-second 20; window 5; };
};
`;

const exists = (p) => readFile(p).then(() => true, () => false);

// ---- Checking the zone ------------------------------------------------------

function checkRecord(r, index) {
  const where = `records[${index}]`;
  if (!r || typeof r !== 'object' || Array.isArray(r)) throw invalid(`${where} must be an object`);
  onlyKeys(r, ['name', 'type', 'ttl', 'value', 'priority', 'weight', 'port', 'tag']);
  if (typeof r.name !== 'string' || !DNS_RECORD_NAME_PATTERN.test(r.name)) throw invalid(`${where}: name must be @ or a name inside the zone`);
  if (!DNS_RECORD_TYPES.includes(r.type)) throw invalid(`${where}: type must be one of ${DNS_RECORD_TYPES.join(', ')}`);
  if (r.ttl !== undefined && r.ttl !== null && (!Number.isInteger(r.ttl) || r.ttl < DNS_TTL.min || r.ttl > DNS_TTL.max)) throw invalid(`${where}: ttl is out of range`);
  const value = r.value;
  const ok = {
    A: () => net.isIPv4(value),
    AAAA: () => net.isIPv6(value),
    TXT: () => typeof value === 'string' && DNS_TXT_PATTERN.test(value),
    CAA: () => DNS_CAA_TAGS.includes(r.tag) && typeof value === 'string' && DNS_CAA_VALUE_PATTERN.test(value),
  }[r.type] ?? (() => typeof value === 'string' && DNS_HOSTNAME_PATTERN.test(value));
  if (!ok()) throw invalid(`${where}: ${r.name} ${r.type} has an invalid value`);
  const int16 = (field, min = 0) => {
    if (!Number.isInteger(r[field]) || r[field] < min || r[field] > 65535) throw invalid(`${where}: ${field} must be from ${min} to 65535`);
  };
  if (r.type === 'MX' || r.type === 'SRV') int16('priority');
  if (r.type === 'SRV') {
    int16('weight');
    int16('port', 1);
  }
  if (r.type === 'CNAME' && r.name === '@') throw invalid('The zone itself cannot be a CNAME');
  return r;
}

export function checkZone(params) {
  onlyKeys(params, ['zone', 'serial', 'ttl', 'email', 'records']);
  const { zone, serial, ttl, email, records } = params;
  if (typeof zone !== 'string' || !DOMAIN_PATTERN.test(zone)) throw invalid('zone must be a domain name');
  if (!Number.isInteger(serial) || serial < 1 || serial > 4_294_967_295) throw invalid('serial must be a 32-bit number');
  if (!Number.isInteger(ttl) || ttl < DNS_TTL.min || ttl > DNS_TTL.max) throw invalid('ttl is out of range');
  if (typeof email !== 'string' || !DNS_EMAIL_PATTERN.test(email)) throw invalid('email must be an email address');
  if (!Array.isArray(records) || !records.length || records.length > MAX_DNS_RECORDS) throw invalid(`records must list 1 to ${MAX_DNS_RECORDS} records`);
  records.forEach(checkRecord);
  if (!records.some((r) => r.type === 'NS' && r.name === '@')) throw invalid('The zone needs an NS record for @');
  for (const r of records.filter((x) => x.type === 'CNAME')) {
    if (records.some((o) => o !== r && o.name === r.name)) throw invalid(`${r.name} has a CNAME record, so it cannot have other records`);
  }
  return { zone, serial, ttl, email, records };
}

// ---- Writing the zone ---------------------------------------------------------

// TXT data as quoted strings of at most 255 characters each.
export function txtData(value) {
  const parts = [];
  for (let i = 0; i < value.length; i += 255) parts.push(`"${value.slice(i, i + 255).replace(/[\\"]/g, '\\$&')}"`);
  return parts.join(' ');
}

function rdata(r) {
  switch (r.type) {
    case 'A':
    case 'AAAA':
      return r.value;
    case 'MX':
      return `${r.priority} ${r.value}.`;
    case 'SRV':
      return `${r.priority} ${r.weight} ${r.port} ${r.value}.`;
    case 'TXT':
      return txtData(r.value);
    case 'CAA':
      return `0 ${r.tag} "${r.value}"`;
    default:
      return `${r.value}.`;
  }
}

// hostmaster@example.com is written hostmaster.example.com. (dots in the
// part before the @ are escaped).
export function soaMailbox(email) {
  const [local, domain] = email.split('@');
  return `${local.replace(/[\\.]/g, '\\$&')}.${domain}.`;
}

export function renderZone({ zone, serial, ttl, email, records }) {
  const primary = records.find((r) => r.type === 'NS' && r.name === '@').value;
  const order = ['NS', 'A', 'AAAA', 'CNAME', 'MX', 'TXT', 'SRV', 'CAA'];
  const sorted = [...records].sort((a, b) => (a.name === '@' ? 0 : 1) - (b.name === '@' ? 0 : 1) || a.name.localeCompare(b.name) || order.indexOf(a.type) - order.indexOf(b.type));
  return [
    `; Managed by VaultPanel: the DNS zone for ${zone}. Changes made here are overwritten when the zone changes in the panel.`,
    `$ORIGIN ${zone}.`,
    `$TTL ${ttl}`,
    `@\tIN\tSOA\t${primary}. ${soaMailbox(email)} (`,
    `\t\t${serial} ; serial`,
    '\t\t3600 ; refresh',
    '\t\t900 ; retry',
    '\t\t1209600 ; expire',
    '\t\t300 ) ; how long "no such name" is remembered',
    ...sorted.map((r) => `${r.name}\t${r.ttl ?? ''}\tIN\t${r.type}\t${rdata(r)}`),
    '',
  ].join('\n');
}

export async function zoneSerial(file) {
  const text = await readFile(file, 'utf8').catch(() => null);
  const match = text && /^\s*(\d+) ; serial$/m.exec(text);
  return match ? Number(match[1]) : null;
}

// zones.conf lists every zone file VaultPanel wrote.
export async function renderZonesConf(paths) {
  const files = await readdir(paths.dir).catch(() => []);
  const zones = files
    .filter((f) => f.endsWith('.db'))
    .map((f) => f.slice(0, -3))
    .filter((z) => DOMAIN_PATTERN.test(z))
    .sort();
  return [
    `${MARK}: one entry per DNS zone. Rewritten whenever a zone is added or removed.`,
    ...zones.map((z) => `zone "${z}" {\n\ttype master;\n\tfile "${paths.zoneFile(z)}";\n\tallow-transfer { none; };\n};`),
    '',
  ].join('\n');
}

async function checkConf(ctx) {
  const result = await ctx.run('named-checkconf', [], { timeoutMs: 30_000 });
  if (result.timedOut || result.error || result.exitCode !== 0) {
    return { ok: false, detail: (result.stdout || result.stderr || result.error?.message || '').trim().split('\n').slice(-6).join('\n') };
  }
  return { ok: true };
}

async function reloadNamed(ctx) {
  const active = await ctx.run('systemctl', ['is-active', '--quiet', 'named.service'], { timeoutMs: 15_000 });
  const verb = active.exitCode === 0 ? 'reload' : 'start';
  ctx.log('stdout', `$ systemctl ${verb} named`);
  assertCommandOk(await ctx.run('systemctl', [verb, 'named.service'], { timeoutMs: 60_000 }), `systemctl ${verb} named`);
}

async function requireDnsServer(ctx, paths) {
  if (ctx.policy.allowDns === false) throw new OperationError('NOT_ALLOWED', 'DNS zones are disabled in this agent config');
  const state = await detectDns(ctx.policy, ctx.binDirs);
  if (!state.installed || !state.configured) {
    throw new OperationError('DNS_NOT_SET_UP', 'The DNS server is not set up on this server. Set it up from the DNS page first.');
  }
  await mkdir(paths.dir, { recursive: true, mode: 0o755 });
}

// Asks the local name server for the zone's serial, a few times while BIND
// reloads.
async function servedSerial(ctx, zone, tries = 10) {
  if (!(await findBinary('dig', ctx.binDirs))) return undefined;
  let serial = null;
  for (let i = 0; i < tries; i += 1) {
    const result = await ctx.run('dig', ['+short', '+norecurse', '+time=2', '+tries=1', '@127.0.0.1', zone, 'SOA'], { timeoutMs: 10_000 });
    const fields = (result.stdout ?? '').trim().split(/\s+/);
    serial = fields.length >= 3 && /^\d+$/.test(fields[2]) ? Number(fields[2]) : null;
    if (serial !== null) return serial;
    await new Promise((r) => setTimeout(r, ctx.retryDelayMs ?? 500));
  }
  return serial;
}

async function namedLog(ctx) {
  const result = await ctx.run('journalctl', ['--unit=named.service', '--lines=8', '--no-pager', '--output=cat', '--quiet'], { timeoutMs: 15_000 });
  return (result.stdout ?? '').trim();
}

// Rewrites zones.conf and reloads BIND; puts things back when BIND refuses.
async function commit(ctx, paths, undo) {
  const previousConf = await readFile(paths.zonesConf, 'utf8').catch(() => null);
  await writeFileAtomic(paths.zonesConf, await renderZonesConf(paths));
  const check = await checkConf(ctx);
  if (!check.ok) {
    await undo();
    if (previousConf === null) await rm(paths.zonesConf, { force: true });
    else await writeFileAtomic(paths.zonesConf, previousConf);
    throw new OperationError('DNS_CONFIG_INVALID', `BIND refused the configuration:\n${check.detail}`);
  }
  await reloadNamed(ctx);
}

export const DNS_OPERATIONS = {
  DNS_SETUP: {
    async run(params, ctx) {
      onlyKeys(params, []);
      if (ctx.policy.allowDns === false) throw new OperationError('NOT_ALLOWED', 'DNS zones are disabled in this agent config');
      const paths = dnsPaths(ctx.policy);
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());
      const missing = [];
      for (const binary of ['named', 'named-checkzone', 'dig']) if (!(await findBinary(binary, ctx.binDirs))) missing.push(binary);
      if (missing.length) {
        if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
        await aptInstall(ctx, PACKAGES, remaining);
      } else {
        ctx.log('stdout', 'BIND is already installed; updating its VaultPanel settings');
      }

      const previous = await readFile(paths.options, 'utf8').catch(() => null);
      const backup = `${paths.options}.vaultpanel-orig`;
      if (previous !== null && !previous.startsWith(MARK) && !(await exists(backup))) await writeFileAtomic(backup, previous);
      await writeFileAtomic(paths.options, OPTIONS);
      await mkdir(paths.dir, { recursive: true, mode: 0o755 });
      await writeFileAtomic(paths.zonesConf, await renderZonesConf(paths));
      const local = await readFile(paths.local, 'utf8').catch(() => '');
      if (!local.includes(paths.includeLine)) await writeFileAtomic(paths.local, `${local.replace(/\n*$/, local ? '\n' : '')}${paths.includeLine}\n`);

      const check = await checkConf(ctx);
      if (!check.ok) {
        if (previous !== null) await writeFileAtomic(paths.options, previous);
        throw new OperationError('DNS_CONFIG_INVALID', `BIND refused the configuration:\n${check.detail}`);
      }
      ctx.log('stdout', '$ systemctl enable named');
      await ctx.run('systemctl', ['enable', 'named.service'], { timeoutMs: 30_000 });
      ctx.log('stdout', '$ systemctl restart named');
      assertCommandOk(await ctx.run('systemctl', ['restart', 'named.service'], { timeoutMs: 60_000 }), 'systemctl restart named');
      const active = await ctx.run('systemctl', ['is-active', '--quiet', 'named.service'], { timeoutMs: 15_000 });
      if (active.exitCode !== 0) {
        throw new OperationError('DNS_NOT_RUNNING', `BIND did not start. Another program may already use port 53.\n${await namedLog(ctx)}`);
      }

      let opened = false;
      try {
        opened = await allowServicePorts(ctx, [53], { protocol: 'any', comment: 'VaultPanel: DNS' });
      } catch (err) {
        ctx.log('stderr', `Could not open port 53 in the firewall (${err.message}). Add a rule for it (TCP and UDP) on the Firewall page.`);
      }
      if (opened) ctx.log('stdout', 'The firewall is on: opened port 53 (TCP and UDP) for DNS');
      ctx.webInventory?.invalidate();
      ctx.log('stdout', 'The DNS server is running. It answers only for the zones VaultPanel adds.');
      return { output: { dns: await detectDns(ctx.policy, ctx.binDirs), firewallOpened: opened } };
    },
  },

  DNS_ZONE_APPLY: {
    async run(params, ctx) {
      const spec = checkZone(params);
      const paths = dnsPaths(ctx.policy);
      await requireDnsServer(ctx, paths);
      const file = paths.zoneFile(spec.zone);
      const current = await zoneSerial(file);
      if (current !== null && current > spec.serial) {
        ctx.log('stdout', `The zone on this server is newer (serial ${current}); keeping it`);
        return { output: { zone: spec.zone, serial: current, skipped: true } };
      }

      const text = renderZone(spec);
      const draft = `${file}.vp-check`;
      await writeFileAtomic(draft, text);
      ctx.log('stdout', `$ named-checkzone ${spec.zone}`);
      const zoneCheck = await ctx.run('named-checkzone', ['-k', 'fail', '-i', 'local', spec.zone, draft], { timeoutMs: 30_000 });
      await rm(draft, { force: true });
      if (zoneCheck.timedOut || zoneCheck.error || zoneCheck.exitCode !== 0) {
        const detail = (zoneCheck.stdout || zoneCheck.stderr || zoneCheck.error?.message || '')
          .trim()
          .split('\n')
          .filter((line) => !/^zone .*: loaded serial/.test(line) && line !== 'OK')
          .slice(-6)
          .map((line) => line.replace(`${draft}`, `${spec.zone}`))
          .join('\n');
        throw new OperationError('DNS_ZONE_INVALID', `BIND refused the zone:\n${detail}`);
      }

      const previous = await readFile(file, 'utf8').catch(() => null);
      await writeFileAtomic(file, text);
      await commit(ctx, paths, async () => {
        if (previous === null) await rm(file, { force: true });
        else await writeFileAtomic(file, previous);
      });

      const served = await servedSerial(ctx, spec.zone);
      if (served === undefined) {
        ctx.log('stderr', 'dig is not installed, so the agent could not ask BIND for the zone. Set up the DNS server again to install it.');
      } else if (served !== spec.serial) {
        throw new OperationError('DNS_ZONE_NOT_LOADED', `BIND did not load the zone (it answers with serial ${served ?? 'none'}).\n${await namedLog(ctx)}`);
      } else {
        ctx.log('stdout', `BIND answers for ${spec.zone} with serial ${spec.serial}`);
      }
      return { output: { zone: spec.zone, serial: spec.serial, records: spec.records.length } };
    },
  },

  DNS_ZONE_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['zone']);
      const { zone } = params;
      if (typeof zone !== 'string' || !DOMAIN_PATTERN.test(zone)) throw invalid('zone must be a domain name');
      const paths = dnsPaths(ctx.policy);
      const file = paths.zoneFile(zone);
      const previous = await readFile(file, 'utf8').catch(() => null);
      if (previous === null) {
        ctx.log('stdout', `There is no zone for ${zone} on this server`);
        return { output: { zone, removed: false } };
      }
      await rm(file, { force: true });
      await rm(`${file}.jnl`, { force: true });
      await commit(ctx, paths, () => writeFileAtomic(file, previous));
      ctx.log('stdout', `This server no longer answers for ${zone}`);
      return { output: { zone, removed: true } };
    },
  },
};
