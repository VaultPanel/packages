import { access, chmod, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { readServiceStates } from '../monitoring/services.js';
import { findBinary } from '../monitoring/web.js';
import { FAIL2BAN_LIMITS, FAIL2BAN_MAX_IGNORE, isAddressOrNetwork } from '../security/securityRules.js';
import { onlyKeys, OperationError } from './errors.js';
import { sshPorts } from './firewall.js';

// Fail2ban's SSH jail: blocks addresses that keep failing to sign in. The
// agent writes one jail file of its own; Fail2ban reads it after the
// distribution's defaults, so its values win.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const ENV = { PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', LANG: 'C' };
export const FAIL2BAN_HEADER = '# Managed by VaultPanel. Changes made here are replaced from the panel.';
// Never blocked: this server itself.
const ALWAYS_IGNORED = ['127.0.0.1/8', '::1'];

const jailFile = (policy) => policy.fail2banJailFile ?? '/etc/fail2ban/jail.d/vaultpanel.local';
const readText = (file) => readFile(file, 'utf8').catch(() => null);

export function renderJail({ enabled, maxRetry, findTimeMinutes, banTimeMinutes, ignoreIps, ports, backend }) {
  return [
    FAIL2BAN_HEADER,
    '[sshd]',
    `enabled = ${enabled ? 'true' : 'false'}`,
    `port = ${ports.join(',')}`,
    ...(backend ? [`backend = ${backend}`] : []),
    `maxretry = ${maxRetry}`,
    `findtime = ${findTimeMinutes}m`,
    `bantime = ${banTimeMinutes}m`,
    `ignoreip = ${[...ALWAYS_IGNORED, ...ignoreIps].join(' ')}`,
    '',
  ].join('\n');
}

// Reads back the settings from the agent's jail file.
export function parseJail(text) {
  if (!text?.startsWith(FAIL2BAN_HEADER)) return null;
  const get = (key) => new RegExp(`^${key}\\s*=\\s*(.*)$`, 'm').exec(text)?.[1]?.trim() ?? null;
  const minutes = (value, fallback) => {
    const match = /^(\d+)m$/.exec(value ?? '');
    return match ? Number(match[1]) : fallback;
  };
  return {
    enabled: get('enabled') === 'true',
    maxRetry: Number(get('maxretry')) || FAIL2BAN_LIMITS.maxRetry.default,
    findTimeMinutes: minutes(get('findtime'), FAIL2BAN_LIMITS.findTimeMinutes.default),
    banTimeMinutes: minutes(get('bantime'), FAIL2BAN_LIMITS.banTimeMinutes.default),
    ignoreIps: (get('ignoreip') ?? '').split(/\s+/).filter((ip) => ip && !ALWAYS_IGNORED.includes(ip)),
  };
}

// `fail2ban-client status sshd`.
export function parseJailStatus(text) {
  const get = (label) => new RegExp(`${label}:\\s*(.*)$`, 'm').exec(text ?? '')?.[1]?.trim() ?? null;
  const number = (label) => (get(label) === null ? null : Number(get(label)));
  return {
    currentlyFailed: number('Currently failed'),
    totalFailed: number('Total failed'),
    currentlyBanned: number('Currently banned'),
    totalBanned: number('Total banned'),
    banned: (get('Banned IP list') ?? '').split(/\s+/).filter(Boolean).slice(0, 500),
  };
}

export async function readFail2ban(ctx, { live = true } = {}) {
  const client = await findBinary('fail2ban-client', ctx.binDirs);
  if (!client) return { installed: false, active: false, sshd: false };
  const [state] = await readServiceStates(['fail2ban'], { run: ctx.run });
  const active = state?.active === 'active';
  const settings = parseJail(await readText(jailFile(ctx.policy)));
  let jail = null;
  if (active) {
    const result = await ctx.run(client, ['status', 'sshd'], { timeoutMs: 15_000, env: ENV });
    jail = result.exitCode === 0 ? parseJailStatus(result.stdout) : null;
  }
  return {
    installed: true,
    active,
    enabledAtBoot: state?.enabled === 'enabled',
    sshd: Boolean(jail),
    settings,
    ...(live ? { status: jail } : { banned: jail?.currentlyBanned ?? 0 }),
  };
}

function checkSettings(params) {
  const value = {
    enabled: params.enabled,
    maxRetry: params.maxRetry ?? FAIL2BAN_LIMITS.maxRetry.default,
    findTimeMinutes: params.findTimeMinutes ?? FAIL2BAN_LIMITS.findTimeMinutes.default,
    banTimeMinutes: params.banTimeMinutes ?? FAIL2BAN_LIMITS.banTimeMinutes.default,
    ignoreIps: params.ignoreIps ?? [],
  };
  if (typeof value.enabled !== 'boolean') throw invalid('enabled must be true or false');
  for (const key of ['maxRetry', 'findTimeMinutes', 'banTimeMinutes']) {
    const { min, max } = FAIL2BAN_LIMITS[key];
    if (!Number.isInteger(value[key]) || value[key] < min || value[key] > max) throw invalid(`${key} must be from ${min} to ${max}`);
  }
  if (!Array.isArray(value.ignoreIps) || value.ignoreIps.length > FAIL2BAN_MAX_IGNORE || value.ignoreIps.some((ip) => !isAddressOrNetwork(ip))) {
    throw invalid(`ignoreIps must list up to ${FAIL2BAN_MAX_IGNORE} addresses or networks`);
  }
  return value;
}

async function requireFail2ban(ctx) {
  if (ctx.policy.allowFail2ban === false) throw new OperationError('NOT_ALLOWED', 'Fail2ban changes are disabled in this agent config');
  const client = await findBinary('fail2ban-client', ctx.binDirs);
  if (!client) throw new OperationError('FAIL2BAN_NOT_INSTALLED', 'Fail2ban is not installed. Install it from the Security software card first.');
  return client;
}

// Where Fail2ban reads SSH sign-ins: the journal needs python3-systemd;
// without it, /var/log/auth.log (rsyslog) works with the default backend.
export async function pickBackend(ctx) {
  const python = await findBinary('python3', ctx.binDirs);
  if (python && (await findBinary('journalctl', ctx.binDirs))) {
    const probe = await ctx.run(python, ['-c', 'import systemd.journal'], { timeoutMs: 15_000, env: ENV });
    if (probe.exitCode === 0) return 'systemd';
  }
  const authLog = ctx.policy.authLogFile ?? '/var/log/auth.log';
  if (await access(authLog).then(() => true, () => false)) return 'auto';
  return 'systemd';
}

async function waitForJail(ctx, client) {
  for (let i = 0; i < 6; i += 1) {
    const result = await ctx.run(client, ['status', 'sshd'], { timeoutMs: 5000, env: ENV });
    if (result.exitCode === 0) return true;
    await new Promise((r) => setTimeout(r, ctx.waitMs ?? 500));
  }
  return false;
}

async function waitForPing(ctx, client) {
  for (let i = 0; i < 20; i += 1) {
    const result = await ctx.run(client, ['ping'], { timeoutMs: 5000, env: ENV });
    if (result.exitCode === 0) return true;
    await new Promise((r) => setTimeout(r, ctx.waitMs ?? 500));
  }
  return false;
}

// After SSH moves to other ports (0.34.0): points the agent's jail at them,
// if the agent manages the jail. Returns whether it changed anything.
export async function updateJailPorts(ctx, ports) {
  const file = jailFile(ctx.policy);
  const text = await readText(file);
  if (!text?.startsWith(FAIL2BAN_HEADER)) return false;
  const next = text.replace(/^port = .*$/m, `port = ${ports.join(',')}`);
  if (next === text) return false;
  const tmp = `${file}.tmp-${process.pid}`;
  await writeFile(tmp, next, { mode: 0o644 });
  await chmod(tmp, 0o644);
  await rename(tmp, file);
  const client = await findBinary('fail2ban-client', ctx.binDirs);
  if (client) {
    const result = await ctx.run(client, ['reload'], { timeoutMs: 60_000, env: ENV });
    if (result.exitCode !== 0) ctx.log('stderr', `Fail2ban did not reload: ${(result.stderr || result.stdout).trim()}`);
  }
  return true;
}

export const FAIL2BAN_OPERATIONS = {
  FAIL2BAN_CONFIGURE: {
    async run(params, ctx) {
      onlyKeys(params, ['enabled', 'maxRetry', 'findTimeMinutes', 'banTimeMinutes', 'ignoreIps']);
      const settings = checkSettings(params);
      const client = await requireFail2ban(ctx);
      const file = jailFile(ctx.policy);
      const backend = await pickBackend(ctx);
      const previous = await readText(file);
      const content = renderJail({ ...settings, ports: await sshPorts(ctx), backend });
      ctx.log('stdout', `Writing ${file}`);
      await mkdir(path.dirname(file), { recursive: true, mode: 0o755 });
      const tmp = `${file}.tmp-${process.pid}`;
      await writeFile(tmp, content, { mode: 0o644 });
      await chmod(tmp, 0o644);
      await rename(tmp, file);
      try {
        const test = await ctx.run(client, ['--test'], { timeoutMs: 30_000, env: ENV });
        if (test.exitCode !== 0) {
          throw new OperationError('CONFIG_INVALID', `Fail2ban refused the settings: ${(test.stderr || test.stdout).trim().split('\n').slice(-3).join('\n')}`);
        }
        for (const args of [['enable', 'fail2ban.service'], ['restart', 'fail2ban.service']]) {
          ctx.log('stdout', `$ systemctl ${args.join(' ')}`);
          const result = await ctx.run('systemctl', args, { timeoutMs: 60_000, env: ENV });
          if (result.exitCode !== 0) throw new OperationError('RESTART_FAILED', `systemctl ${args[0]} fail2ban failed: ${(result.stderr || '').trim()}`);
        }
        if (!(await waitForPing(ctx, client))) throw new OperationError('RESTART_FAILED', 'Fail2ban did not answer after restarting. See its log on the Logs page.');
        if (settings.enabled && !(await waitForJail(ctx, client))) {
          throw new OperationError(
            'JAIL_FAILED',
            backend === 'systemd'
              ? 'Fail2ban runs, but could not start watching SSH: reading the system journal needs python3-systemd. Install it with "apt install python3-systemd", then save again.'
              : 'Fail2ban runs, but could not start watching SSH. See /var/log/fail2ban.log.',
          );
        }
      } catch (err) {
        ctx.log('stderr', 'Putting the previous Fail2ban settings back');
        if (previous === null) await rm(file, { force: true });
        else await writeFile(file, previous, { mode: 0o644 });
        await ctx.run('systemctl', ['restart', 'fail2ban.service'], { timeoutMs: 60_000, env: ENV });
        throw err;
      }
      ctx.webInventory?.invalidate();
      ctx.log('stdout', settings.enabled ? 'Fail2ban is protecting SSH' : 'The SSH jail is off');
      return { output: { fail2ban: await readFail2ban(ctx) } };
    },
  },

  FAIL2BAN_UNBAN: {
    async run(params, ctx) {
      onlyKeys(params, ['ip']);
      if (typeof params.ip !== 'string' || params.ip.includes('/') || !isAddressOrNetwork(params.ip)) throw invalid('ip must be an IP address');
      const client = await requireFail2ban(ctx);
      ctx.log('stdout', `$ fail2ban-client unban ${params.ip}`);
      const result = await ctx.run(client, ['unban', params.ip], { timeoutMs: 30_000, env: ENV });
      if (result.exitCode !== 0) throw new OperationError('COMMAND_FAILED', `Unblocking failed: ${(result.stderr || result.stdout).trim()}`);
      // fail2ban-client prints how many jails released the address.
      if (/^0$/m.test(result.stdout.trim())) throw new OperationError('NOT_BANNED', `${params.ip} is not blocked`);
      ctx.webInventory?.invalidate();
      return { output: { fail2ban: await readFail2ban(ctx) } };
    },
  },
};
