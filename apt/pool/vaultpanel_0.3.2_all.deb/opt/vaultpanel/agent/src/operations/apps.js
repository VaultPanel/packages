import { lstat, readFile, rm } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { appNodeDir, BIN_DIRS, findBinary, NODE_IN_HOME_MESSAGE } from '../monitoring/web.js';
import {
  APP_FOLDERS,
  APP_HEADER,
  APP_LOG_FILES,
  appEnvironment,
  appPaths,
  bothCluster,
  checkAppName,
  checkBranch,
  checkCommands,
  checkEnv,
  checkInteger,
  checkKeepReleases,
  checkPort,
  checkReleaseId,
  checkRepository,
  checkRuntime,
  clusterStart,
  looksLikeNodeScript,
  parsePm2List,
  renderAppUnit,
  renderClusterStart,
  renderEcosystem,
  renderEnvFile,
} from '../services/appConfig.js';
import { APP_CPU_LIMIT, APP_INSTANCES, APP_MEMORY_LIMIT_MB } from '../security/securityRules.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';
import { ensureSiteUser, fileRunner, requireSiteAccount, SITE_OPERATIONS, writeFileAtomic } from './sites.js';

// Node.js, Python, Go and Ruby applications: Git deployments into release folders,
// a "current" link to the live release, and PM2 (run by a systemd unit as
// the app's own user) to keep the app running.
//
// /var/www/<app>/
//   releases/<id>/      one folder per deployment (the newest few are kept)
//   current -> releases/<id>
//   shared/ecosystem.json, shared/.env   (mode 600)
//   logs/app-output.log, logs/app-error.log
//   .ssh/id_ed25519     the app's deploy key for private repositories
//
// Everything inside the home folder is done as the app's user (git, npm,
// pip, the build, file writes). Only the systemd unit is written as root.
// A deployment that fails before the switch leaves the running release
// untouched; one that fails its health check is switched back.

const PROCESS_KEYS = ['name', 'runtime', 'startCommand', 'port', 'env', 'healthCheckSeconds', 'cpuPercent', 'memoryMb', 'instances', 'zeroDowntime'];

// What each runtime needs on the server to install and build an app, and the
// Software card entry that installs it.
const RUNTIME_TOOLS = {
  go: { binary: 'go', message: 'Go is not installed on this server. Install it from the Software card on the server page.' },
  ruby: { binary: 'bundle', message: 'Ruby and Bundler are not installed on this server. Install Ruby from the Software card on the server page.' },
};
// Where a runtime's dependencies are named, for the "not installed" message.
const DEPENDENCY_FILES = { node: 'package.json', python: 'requirements.txt', go: 'go.mod', ruby: 'Gemfile' };

function nodeBinDir(ctx) {
  const dir = appNodeDir(ctx.policy);
  if (!dir) throw new OperationError('NODE_IN_HOME_FOLDER', NODE_IN_HOME_MESSAGE);
  return dir;
}

function binDirs(ctx) {
  return [...(ctx.binDirs ?? BIN_DIRS), nodeBinDir(ctx)];
}

async function requireBinary(ctx, name, code, message) {
  const found = await findBinary(name, binDirs(ctx));
  if (!found) throw new OperationError(code, message);
  return found;
}

// Git and ssh-keygen come with the system, not with Node.js, so finding them
// does not need a Node.js apps can use (static websites deploy without one).
async function requireSystemBinary(ctx, name, code, message) {
  const found = await findBinary(name, ctx.binDirs ?? BIN_DIRS);
  if (!found) throw new OperationError(code, message);
  return found;
}

function sleep(ctx, ms) {
  return ctx.sleep ? ctx.sleep(ms) : new Promise((r) => setTimeout(r, ms));
}

// Runs a command as the app's user.
export function runAsApp(ctx, account, file, args, { cwd, env, timeoutMs, log = true } = {}) {
  return ctx.run(file, args, {
    uid: account.uid,
    gid: account.gid,
    cwd,
    env,
    timeoutMs: timeoutMs ?? 60_000,
    onLine: log ? ctx.log : undefined,
  });
}

export function files(ctx, account, home) {
  const run = fileRunner(ctx);
  return (request, timeoutMs = 60_000) => run(account, { ...request, home }, { timeoutMs });
}

export function deadlineFor(ctx) {
  const deadline = Date.now() + (ctx.timeoutMs ?? 600_000);
  return () => Math.max(10_000, deadline - Date.now());
}

export function lastLines(result, count = 12) {
  return (result.stderr || result.stdout || result.error?.message || '').trim().split('\n').slice(-count).join('\n');
}

// ---- Process and systemd -----------------------------------------------

export async function systemctl(ctx, args, what) {
  return assertCommandOk(await ctx.run('systemctl', args, { timeoutMs: 60_000 }), what ?? `systemctl ${args.join(' ')}`);
}

export async function unitState(ctx, paths) {
  const result = await ctx.run(
    'systemctl',
    ['show', `${paths.unitName}.service`, '--property=LoadState,ActiveState,SubState,MainPID,NRestarts,ActiveEnterTimestamp,MemoryCurrent', '--no-pager'],
    { timeoutMs: 15_000 },
  );
  const props = {};
  for (const line of (result.stdout ?? '').split('\n')) {
    const i = line.indexOf('=');
    if (i > 0) props[line.slice(0, i)] = line.slice(i + 1);
  }
  const memory = Number(props.MemoryCurrent);
  const since = props.ActiveEnterTimestamp ? new Date(props.ActiveEnterTimestamp.replace(/^\w{3} /, '')) : null;
  return {
    exists: props.LoadState === 'loaded',
    active: props.ActiveState ?? 'unknown',
    sub: props.SubState ?? null,
    restarts: Number.isFinite(Number(props.NRestarts)) ? Number(props.NRestarts) : null,
    memoryBytes: Number.isFinite(memory) && memory < 2 ** 53 ? memory : null,
    since: since && !Number.isNaN(since.getTime()) ? since.toISOString() : null,
  };
}

// Runs the pm2 command against the app's own PM2 (the one its unit runs).
// Only while the unit runs: asking an idle PM2 would start a new PM2 daemon
// outside the unit.
async function pm2Command(ctx, account, paths, args, { log = false, timeoutMs = 15_000 } = {}) {
  const pm2 = await findBinary('pm2', binDirs(ctx));
  if (!pm2) return null;
  return runAsApp(ctx, account, pm2, args, {
    cwd: paths.home,
    env: { HOME: paths.home, PM2_HOME: paths.pm2Home, PATH: [nodeBinDir(ctx), '/usr/bin', '/bin'].join(':'), LANG: 'C' },
    timeoutMs,
    log,
  });
}

// The process as PM2 sees it.
async function pm2Status(ctx, account, paths, name) {
  const result = await pm2Command(ctx, account, paths, ['jlist']);
  if (!result || result.exitCode !== 0) return null;
  return parsePm2List(result.stdout, name);
}

async function writeUnit(ctx, name, paths, limits = null) {
  const pm2Runtime = await requireBinary(ctx, 'pm2-runtime', 'PM2_NOT_INSTALLED', 'PM2 is not installed on this server. Install it from the Software card on the server page.');
  const content = renderAppUnit({ name, paths, pm2Runtime, nodeBinDir: nodeBinDir(ctx), limits });
  let previous = null;
  try {
    previous = await readFile(paths.unitFile, 'utf8');
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
  if (previous !== content) {
    ctx.log('stdout', `Writing ${paths.unitFile}`);
    await writeFileAtomic(paths.unitFile, content);
    await systemctl(ctx, ['daemon-reload']);
    return previous !== null;
  }
  return false;
}

// Something other than the app listening on its port would answer the
// health check, so a port in use before the app starts is an error.
function portOpen(ctx, port) {
  if (ctx.connectPort) return ctx.connectPort(port);
  return new Promise((resolve) => {
    const socket = net.connect({ host: '127.0.0.1', port, timeout: 2000 });
    const done = (open) => {
      socket.destroy();
      resolve(open);
    };
    socket.once('connect', () => done(true));
    socket.once('timeout', () => done(false));
    socket.once('error', () => done(false));
  });
}

// Waits for the app to come up: the unit stays active and, for apps with a
// port, something accepts connections on it twice, two seconds apart (an
// app that crashes right after starting fails). Apps without a port must
// still be online in PM2 after a few seconds.
export async function healthCheck(ctx, account, paths, name, port, seconds) {
  const deadline = Date.now() + seconds * 1000;
  ctx.log('stdout', port ? `Waiting up to ${seconds}s for the app to answer on port ${port}` : 'Checking the app stays up');
  if (!port) {
    await sleep(ctx, 5000);
    const unit = await unitState(ctx, paths);
    const proc = unit.active === 'active' ? await pm2Status(ctx, account, paths, name) : null;
    if (unit.active === 'active' && (!proc || proc.status === 'online')) {
      if (proc && proc.count > 1) {
        const copies = await allCopiesOnline(ctx, account, paths, name, deadline);
        if (!copies.ok) return copies;
        return { ok: true, message: `The app is running (${proc.count} copies)` };
      }
      return { ok: true, message: 'The app is running' };
    }
    return { ok: false, message: `The app is not running (${proc?.status ?? unit.active}). See the error log.` };
  }
  let opened = false;
  while (Date.now() < deadline) {
    const unit = await unitState(ctx, paths);
    if (unit.active === 'failed' || unit.active === 'inactive') {
      return { ok: false, message: `The PM2 service ${unit.active === 'failed' ? 'failed' : 'stopped'}. See the error log.` };
    }
    if (await portOpen(ctx, port)) {
      if (opened) {
        const copies = await allCopiesOnline(ctx, account, paths, name, deadline);
        if (!copies.ok) return copies;
        return { ok: true, message: `The app answers on port ${port}${copies.count > 1 ? ` (${copies.count} copies running)` : ''}` };
      }
      opened = true;
      await sleep(ctx, 2000);
      continue;
    }
    opened = false;
    await sleep(ctx, 1000);
  }
  const proc = await pm2Status(ctx, account, paths, name);
  const why = proc && proc.status !== 'online' ? ` PM2 reports it as ${proc.status} after ${proc.restarts} restarts.` : '';
  return { ok: false, message: `Nothing answered on port ${port} within ${seconds} seconds. Make sure the app listens on the PORT environment variable (${port}).${why} See the error log.` };
}

// An app running several copies is only up when every copy is: the port
// answers as soon as the first one listens.
async function allCopiesOnline(ctx, account, paths, name, deadline) {
  for (;;) {
    const proc = await pm2Status(ctx, account, paths, name);
    if (!proc || proc.count <= 1) return { ok: true, count: proc?.count ?? 1 };
    if (proc.online === proc.count) return { ok: true, count: proc.count };
    if (Date.now() >= deadline) {
      return { ok: false, message: `Only ${proc.online} of ${proc.count} copies of the app are running. See the error log.` };
    }
    await sleep(ctx, 1000);
  }
}

export async function startOrRestart(ctx, paths, reload = null) {
  const state = await unitState(ctx, paths);
  if (state.active === 'active' && reload && (await reloadRunning(ctx, reload.account, paths, reload.name))) return 'reloaded';
  if (state.active === 'active' || state.active === 'activating') {
    ctx.log('stdout', `$ systemctl restart ${paths.unitName}`);
    await systemctl(ctx, ['restart', `${paths.unitName}.service`]);
    return 'restarted';
  } else {
    ctx.log('stdout', `$ systemctl enable --now ${paths.unitName}`);
    await systemctl(ctx, ['enable', '--now', `${paths.unitName}.service`]);
    return 'started';
  }
}

// Zero-downtime reload of an app in PM2 cluster mode: PM2 rereads the
// process file (new release, environment, start command), starts each new
// copy and stops an old one only once the new one listens, so the port keeps
// answering. Returns false if PM2 could not do it (the caller restarts).
async function reloadRunning(ctx, account, paths, name) {
  const ecosystem = path.join(paths.home, paths.rel.ecosystem);
  ctx.log('stdout', `$ pm2 reload ${name} --update-env (zero downtime)`);
  const result = await pm2Command(ctx, account, paths, ['reload', ecosystem, '--update-env'], { timeoutMs: 300_000 });
  if (result?.exitCode === 0) {
    ctx.log('stdout', 'PM2 replaced every copy while the others kept serving');
    return true;
  }
  ctx.log('stderr', `PM2 could not reload the app${result ? `: ${lastLines(result, 3)}` : ''}. Restarting it instead.`);
  return false;
}

// ---- Setup ----------------------------------------------------------------

export function requireApps(policy) {
  if (policy.allowApplications === false) throw new OperationError('NOT_ALLOWED', 'Application management is disabled in this agent config');
}

async function prepareApp(ctx, name) {
  requireApps(ctx.policy);
  const paths = appPaths(ctx.policy, name);
  const account = await ensureSiteUser(ctx, { name }, paths);
  const fs = files(ctx, account, paths.home);
  await fs({ action: 'appInit', folders: APP_FOLDERS });
  return { paths, account, fs };
}

export async function ensureDeployKey(ctx, account, paths, fs) {
  let exists = true;
  try {
    await lstat(`${paths.deployKey}.pub`);
  } catch {
    exists = false;
  }
  if (!exists) {
    const sshKeygen = await requireSystemBinary(ctx, 'ssh-keygen', 'SSH_NOT_INSTALLED', 'ssh-keygen is not installed, so there is no deploy key for SSH repositories. Install Git from the Software card on the server page (it adds openssh-client).');
    ctx.log('stdout', 'Creating the deploy key');
    const result = await runAsApp(ctx, account, sshKeygen, ['-q', '-t', 'ed25519', '-N', '', '-C', `vaultpanel-${account.name}`, '-f', paths.deployKey], {
      cwd: paths.home,
      env: { HOME: paths.home, PATH: '/usr/bin:/bin' },
      timeoutMs: 30_000,
    });
    assertCommandOk(result, 'ssh-keygen');
  }
  const pub = await fs({ action: 'read', path: paths.rel.deployKeyPub });
  return pub.content.trim();
}

// ---- Deployment stages ------------------------------------------------------

export class StageError extends OperationError {}

export function stage(name, ctx) {
  ctx.log('stdout', `==> ${name}`);
}

// Extra variables for git, npm and pip during deployments, from the agent
// config (deployEnv), such as HTTPS_PROXY on a server behind a proxy.
export function deployEnv(ctx) {
  const extra = ctx.policy.deployEnv;
  if (!extra || typeof extra !== 'object') return {};
  return Object.fromEntries(Object.entries(extra).filter(([k, v]) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === 'string'));
}

export function gitEnv(ctx, paths) {
  return {
    ...deployEnv(ctx),
    HOME: paths.home,
    PATH: '/usr/local/bin:/usr/bin:/bin',
    LANG: 'C.UTF-8',
    GIT_TERMINAL_PROMPT: '0',
    GIT_ALLOW_PROTOCOL: 'https:ssh',
    GIT_CONFIG_NOSYSTEM: '1',
    // Git runs this through a shell; every part is a path VaultPanel chose.
    GIT_SSH_COMMAND: `ssh -i ${paths.deployKey} -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=${paths.knownHosts}`,
  };
}

export async function fetchRelease(ctx, { account, paths, repository, branch, releaseDir, remaining, keyHint = ' If the repository is private, add the app’s deploy key to it (shown on the app’s Settings tab).' }) {
  const git = await requireSystemBinary(ctx, 'git', 'GIT_NOT_INSTALLED', 'Git is not installed on this server. Install it from the Software card on the server page.');
  ctx.log('stdout', `$ git clone --depth 1 --branch ${branch} ${repository}`);
  const clone = await runAsApp(ctx, account, git, ['clone', '--quiet', '--depth', '1', '--single-branch', '--no-tags', '--branch', branch, '--', repository, releaseDir], {
    cwd: paths.home,
    env: gitEnv(ctx, paths),
    timeoutMs: Math.min(remaining(), 600_000),
  });
  if (clone.timedOut) throw new StageError('CLONE_FAILED', 'Cloning the repository did not finish in time');
  if (clone.exitCode !== 0) {
    const detail = lastLines(clone, 6);
    const hint = /Permission denied \(publickey\)|Could not read from remote|Authentication failed|could not read Username/i.test(detail)
      ? keyHint
      : /Remote branch .* not found/i.test(detail)
        ? ` Check that the branch ${branch} exists.`
        : '';
    throw new StageError('CLONE_FAILED', `git clone failed: ${detail}${hint}`);
  }
  const info = await runAsApp(ctx, account, git, ['-C', releaseDir, 'log', '-1', '--format=%H%n%an%n%s'], { cwd: paths.home, env: gitEnv(ctx, paths), timeoutMs: 15_000, log: false });
  const [commit = null, author = null, message = null] = info.exitCode === 0 ? info.stdout.split('\n') : [];
  if (commit) ctx.log('stdout', `Commit ${commit.slice(0, 12)}: ${message ?? ''}`);
  return { commit: commit || null, author: author?.slice(0, 200) || null, message: message?.slice(0, 500) || null };
}

export async function fileExists(file) {
  try {
    await lstat(file);
    return true;
  } catch {
    return false;
  }
}

// The install commands to run: the app's own, or a sensible default.
async function installCommands(ctx, { runtime, installCommand, releaseDir, port }) {
  const custom = checkCommands(installCommand, 'installCommand', { port });
  if (runtime === 'go') {
    if (custom.length) return custom;
    if (await fileExists(path.join(releaseDir, 'go.mod'))) return [['go', 'mod', 'download']];
    ctx.log('stdout', 'No go.mod: nothing to download');
    return [];
  }
  if (runtime === 'ruby') {
    if (custom.length) return custom;
    if (await fileExists(path.join(releaseDir, 'Gemfile'))) return [['bundle', 'install', '--jobs', '4']];
    ctx.log('stdout', 'No Gemfile: nothing to install');
    return [];
  }
  if (runtime === 'node') {
    if (custom.length) return custom;
    if (await fileExists(path.join(releaseDir, 'package-lock.json'))) return [['npm', 'ci', '--include=dev', '--no-audit', '--no-fund']];
    if (await fileExists(path.join(releaseDir, 'package.json'))) return [['npm', 'install', '--include=dev', '--no-audit', '--no-fund']];
    ctx.log('stdout', 'No package.json: nothing to install');
    return [];
  }
  if (custom.length) return custom;
  if (await fileExists(path.join(releaseDir, 'requirements.txt'))) {
    return [[path.join(releaseDir, '.venv', 'bin', 'pip'), 'install', '--disable-pip-version-check', '--no-input', '-r', 'requirements.txt']];
  }
  ctx.log('stdout', 'No requirements.txt: nothing to install');
  return [];
}

export async function runCommands(ctx, account, commands, { cwd, env, remaining, code, what }) {
  for (const argv of commands) {
    ctx.log('stdout', `$ ${argv.join(' ')}`);
    const result = await runAsApp(ctx, account, argv[0], argv.slice(1), { cwd, env, timeoutMs: remaining() });
    if (result.timedOut) throw new StageError(code, `${what} did not finish in time: ${argv.join(' ')}`);
    if (result.error?.code === 'ENOENT') throw new StageError(code, `${what} failed: command not found: ${argv[0]}`);
    if (result.error || result.exitCode !== 0) {
      throw new StageError(code, `${what} failed: ${argv.join(' ')} exited with ${result.exitCode ?? result.error?.message}\n${lastLines(result)}`);
    }
  }
}

// Finds the program a start command names, the way the app's PATH would,
// and returns it as a path through "current" so a rollback keeps working.
async function resolveStart(ctx, { runtime, argv, releaseDir, paths }) {
  const [program] = argv;
  const current = path.join(paths.home, paths.rel.current);
  // A program built into the release, such as ./server from "go build -o server".
  if (/^\.\//.test(program) && !program.includes('/../')) {
    if (await fileExists(path.join(releaseDir, program))) return [path.join(current, program.slice(2)), ...argv.slice(1)];
    throw new StageError('CONFIGURE_FAILED', `The start command runs ${program}, which is not in the release. Check that the build command creates it (for example go build -o ${program.slice(2)} .).`);
  }
  if (program.includes('/')) return argv;
  const candidates = [
    [path.join(releaseDir, '.venv', 'bin', program), path.join(current, '.venv', 'bin', program)],
    [path.join(releaseDir, 'node_modules', '.bin', program), path.join(current, 'node_modules', '.bin', program)],
  ];
  for (const [inRelease, viaCurrent] of candidates) {
    if (await fileExists(inRelease)) return [viaCurrent, ...argv.slice(1)];
  }
  const found = await findBinary(program, [nodeBinDir(ctx), '/usr/local/bin', '/usr/bin', '/bin']);
  if (found) return [found, ...argv.slice(1)];
  throw new StageError('CONFIGURE_FAILED', `The start command runs "${program}", which is not installed in the app or on the server. Add it to the app’s dependencies (${DEPENDENCY_FILES[runtime] ?? 'package.json or requirements.txt'}).`);
}

// Whether a program of the start command is a Node.js script, read (as the
// app's user) in the release being started; the command names it through
// "current".
function nodeScriptCheck(fs, paths, releaseDir) {
  const current = path.join(paths.home, paths.rel.current);
  return async (file) => {
    const inRelease = file.startsWith(`${current}/`) ? path.join(releaseDir, file.slice(current.length + 1)) : path.resolve(releaseDir, file);
    const rel = path.relative(paths.home, inRelease);
    if (rel.startsWith('..') || path.isAbsolute(rel)) return /\.(?:js|mjs|cjs)$/.test(file);
    try {
      const { content, encoding } = await fs({ action: 'read', path: rel });
      return encoding === 'utf8' && looksLikeNodeScript(file, content.slice(0, 200));
    } catch {
      return false;
    }
  };
}

// How the app's processes run: one, or several copies. Node.js apps get
// PM2 cluster mode, which needs the start command to run a Node.js script.
// Zero-downtime reloads use cluster mode too, even for one copy.
async function processPlan(ctx, { runtime, releaseDir, paths, fs, argv, instances, zeroDowntime = false }) {
  if (instances <= 1 && !zeroDowntime) return null;
  if (runtime === 'go' || runtime === 'ruby') {
    throw new StageError('CONFIGURE_FAILED', `${runtime === 'go' ? 'Go' : 'Ruby'} apps run as one process. Set copies back to 1, and start more workers inside the app (Puma: WEB_CONCURRENCY) if it needs them.`);
  }
  if (runtime === 'python') {
    const program = path.basename(argv[0]);
    if (['gunicorn', 'uvicorn'].includes(program)) ctx.log('stdout', `Running ${instances} ${program} workers (WEB_CONCURRENCY=${instances})`);
    else ctx.log('stderr', `WEB_CONCURRENCY is set to ${instances}. Gunicorn and Uvicorn start that many workers; "${program}" may ignore it and run one process.`);
    return null;
  }
  if (!releaseDir) return null;
  const cluster = await clusterStart(argv, { isNodeScript: nodeScriptCheck(fs, paths, releaseDir), instances });
  if (!cluster) {
    const command = argv.map((a, i) => (i === 0 ? path.basename(a) : a)).join(' ');
    if (instances <= 1) {
      throw new StageError(
        'CONFIGURE_FAILED',
        `Zero-downtime reloads need the start command to run a Node.js file, such as "node server.js". "${command}" cannot be reloaded by PM2: use the command your package.json start script runs, or turn zero-downtime reloads off.`,
      );
    }
    throw new StageError(
      'CONFIGURE_FAILED',
      `To run ${instances} copies, the start command must run a Node.js file, such as "node server.js". "${command}" cannot run in PM2 cluster mode: use the command your package.json start script runs, or set copies back to 1.`,
    );
  }
  if (instances > 1) ctx.log('stdout', `Running ${instances} copies in PM2 cluster mode; they share the app’s port and PM2 spreads connections between them`);
  else ctx.log('stdout', 'Running in PM2 cluster mode so deploys and restarts reload the app without downtime');
  return cluster;
}

// Writes shared/.env and shared/ecosystem.json for the given release.
// Returns whether only the number of copies changed (so a running app can
// be scaled without a restart), and whether the running app can take the
// new configuration as a zero-downtime reload.
async function writeProcessConfig(ctx, { name, runtime, paths, fs, releaseDir, startArgv, env, port, limits, instances = 1, zeroDowntime = false }) {
  const argv = releaseDir ? await resolveStart(ctx, { runtime, argv: startArgv, releaseDir, paths }) : startArgv;
  const cluster = await processPlan(ctx, { runtime, releaseDir, paths, fs, argv, instances, zeroDowntime });
  const current = path.join(paths.home, paths.rel.current);
  const processEnv = appEnvironment({ name, home: paths.home, releaseDir: current, runtime, env, port, nodeBinDir: nodeBinDir(ctx), instances });
  const content = renderEcosystem({ name, paths, argv, env: processEnv, cluster });
  const previous = await readEcosystem(fs, paths);
  ctx.log('stdout', `Writing ${paths.rel.ecosystem} and ${paths.rel.env} (${Object.keys(env).length} variables)`);
  await fs({ action: 'write', path: paths.rel.env, content: renderEnvFile({ ...env, ...(port ? { PORT: String(port) } : {}) }), mode: 0o600 });
  if (cluster) await fs({ action: 'write', path: paths.rel.clusterStart, content: renderClusterStart({ paths, script: cluster.script }), mode: 0o600 });
  await fs({ action: 'write', path: paths.rel.ecosystem, content, mode: 0o600 });
  const unitChanged = await writeUnit(ctx, name, paths, limits);
  // A new unit (limits) only applies on a restart.
  const reloadable = zeroDowntime && !unitChanged && bothCluster(previous, content);
  return { argv, onlyInstancesChanged: onlyInstancesDiffer(previous, content), reloadable };
}

async function readEcosystem(fs, paths) {
  try {
    return (await fs({ action: 'read', path: paths.rel.ecosystem })).content ?? null;
  } catch {
    return null;
  }
}

// Both files run the app in cluster mode and differ only in how many copies.
export function onlyInstancesDiffer(before, after) {
  const parse = (text) => {
    try {
      return JSON.parse(text)?.apps?.[0] ?? null;
    } catch {
      return null;
    }
  };
  const a = parse(before);
  const b = parse(after);
  if (!a || !b || a.exec_mode !== 'cluster' || b.exec_mode !== 'cluster' || a.instances === b.instances) return false;
  return JSON.stringify({ ...a, instances: 0 }) === JSON.stringify({ ...b, instances: 0 });
}

export async function listReleases(fs, paths) {
  try {
    const listing = await fs({ action: 'list', path: paths.rel.releases });
    return listing.entries.filter((e) => e.type === 'dir' && /^[0-9]{14}-[a-f0-9]{6}$/.test(e.name)).map((e) => e.name).sort();
  } catch (err) {
    if (err.code === 'FILE_NOT_FOUND') return [];
    throw err;
  }
}

async function currentRelease(fs, paths) {
  const { target } = await fs({ action: 'readlink', path: paths.rel.current });
  const match = target?.match(/^releases\/([0-9]{14}-[a-f0-9]{6})$/);
  return match ? match[1] : null;
}

export async function removeRelease(ctx, fs, paths, id) {
  try {
    await fs({ action: 'delete', path: paths.rel.release(id) }, 300_000);
  } catch (err) {
    ctx.log('stderr', `Could not remove release ${id}: ${err.message}`);
  }
}

// Keeps the newest releases, and always the current and previous ones.
async function pruneReleases(ctx, fs, paths, keep, protect) {
  const releases = await listReleases(fs, paths);
  const newest = new Set(releases.slice(-keep));
  for (const id of releases) {
    if (newest.has(id) || protect.includes(id)) continue;
    ctx.log('stdout', `Removing old release ${id}`);
    await removeRelease(ctx, fs, paths, id);
  }
  return listReleases(fs, paths);
}

// Points "current" at a release, (re)starts the app and checks it. If the
// check fails and there was a previous release, switches back to it.
async function switchAndCheck(ctx, { name, account, paths, fs, releaseId, port, healthCheckSeconds, writeConfig, reloadable = false }) {
  const previous = await currentRelease(fs, paths);
  const unit = await unitState(ctx, paths);
  if (port && unit.active !== 'active' && (await portOpen(ctx, port))) {
    throw new StageError('START_FAILED', `Port ${port} is already used by another program on this server. Stop it or choose another port for the app.`);
  }
  stage('Start', ctx);
  ctx.log('stdout', `Switching current to release ${releaseId}${previous ? ` (was ${previous})` : ''}`);
  await fs({ action: 'activate', path: paths.rel.current, target: paths.rel.release(releaseId) });
  const how = await startOrRestart(ctx, paths, reloadable ? { account, name } : null);

  stage('Health check', ctx);
  const health = await healthCheck(ctx, account, paths, name, port, healthCheckSeconds);
  ctx.log(health.ok ? 'stdout' : 'stderr', health.message);
  if (health.ok) return { previous, health, rolledBack: false, how };

  if (previous && previous !== releaseId) {
    ctx.log('stderr', `Switching back to release ${previous}`);
    const back = await writeConfig?.(path.join(paths.home, paths.rel.release(previous)));
    await fs({ action: 'activate', path: paths.rel.current, target: paths.rel.release(previous) });
    await startOrRestart(ctx, paths, back?.reloadable ? { account, name } : null);
    throw new StageError('HEALTH_CHECK_FAILED', `${health.message} The previous release (${previous}) is running again.`);
  }
  throw new StageError('HEALTH_CHECK_FAILED', health.message);
}

function processParams(params, { requireStart = true } = {}) {
  const name = checkAppName(params.name);
  const runtime = checkRuntime(params.runtime);
  const port = checkPort(params.port);
  const env = checkEnv(params.env ?? []);
  const [startArgv] = checkCommands(params.startCommand, 'startCommand', { single: requireStart, port });
  const healthCheckSeconds = checkInteger(params.healthCheckSeconds, 'healthCheckSeconds', 5, 300, 30);
  const limits = {
    cpuPercent: params.cpuPercent == null ? null : checkInteger(params.cpuPercent, 'cpuPercent', APP_CPU_LIMIT.min, APP_CPU_LIMIT.max),
    memoryMb: params.memoryMb == null ? null : checkInteger(params.memoryMb, 'memoryMb', APP_MEMORY_LIMIT_MB.min, APP_MEMORY_LIMIT_MB.max),
  };
  const instances = checkInteger(params.instances, 'instances', APP_INSTANCES.min, APP_INSTANCES.max, 1);
  const zeroDowntime = params.zeroDowntime ?? false;
  if (typeof zeroDowntime !== 'boolean') throw new OperationError('INVALID_PARAMS', 'zeroDowntime must be true or false');
  if (zeroDowntime && runtime !== 'node') throw new OperationError('INVALID_PARAMS', 'Zero-downtime reloads are for Node.js apps');
  return { name, runtime, port, env, startArgv, healthCheckSeconds, limits, instances, zeroDowntime };
}

// Changes how many copies of an app in cluster mode run, without
// restarting the copies that keep running. Returns false if PM2 could not
// do it (the caller restarts the app instead).
async function scaleRunning(ctx, account, paths, name, instances) {
  ctx.log('stdout', `$ pm2 scale ${name} ${instances}`);
  // PM2 prints its whole process table; the log keeps only the outcome.
  const result = await pm2Command(ctx, account, paths, ['scale', name, String(instances)], { timeoutMs: 120_000 });
  if (result?.exitCode === 0) {
    ctx.log('stdout', `PM2 now runs ${instances} copies`);
    return true;
  }
  ctx.log('stderr', `PM2 could not change the number of copies in place${result ? `: ${lastLines(result, 3)}` : ''}. Restarting the app instead.`);
  return false;
}

async function processSummary(ctx, account, paths, name) {
  const unit = await unitState(ctx, paths);
  const proc = unit.active === 'active' ? await pm2Status(ctx, account, paths, name) : null;
  return { unit, process: proc };
}

// ---- Operations -------------------------------------------------------------

export const APP_OPERATIONS = {
  CREATE_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'runtime']);
      const name = checkAppName(params.name);
      checkRuntime(params.runtime);
      const { paths, account, fs } = await prepareApp(ctx, name);
      // The deploy key is only needed for SSH repositories; deploying from
      // one without ssh-keygen fails with a clear message instead.
      let deployKey = null;
      try {
        deployKey = await ensureDeployKey(ctx, account, paths, fs);
      } catch (err) {
        if (err.code !== 'SSH_NOT_INSTALLED') throw err;
        ctx.log('stderr', err.message);
      }
      ctx.log('stdout', `App user ${name} and folders ready in ${paths.home}`);
      return { output: { name, home: paths.home, user: account.name, deployKey } };
    },
  },

  DEPLOY_GIT: {
    async run(params, ctx) {
      onlyKeys(params, [...PROCESS_KEYS, 'repository', 'branch', 'installCommand', 'buildCommand', 'releaseId', 'keepReleases']);
      const { name, runtime, port, env, startArgv, healthCheckSeconds, limits, instances, zeroDowntime } = processParams(params);
      const repository = checkRepository(params.repository);
      const branch = checkBranch(params.branch);
      const releaseId = checkReleaseId(params.releaseId);
      const keep = checkKeepReleases(params.keepReleases);
      checkCommands(params.installCommand, 'installCommand');
      const buildCommands = checkCommands(params.buildCommand, 'buildCommand', { port });
      const remaining = deadlineFor(ctx);
      const stages = [];
      const timed = async (key, fn) => {
        const started = Date.now();
        try {
          const value = await fn();
          stages.push({ stage: key, status: 'succeeded', durationMs: Date.now() - started });
          return value;
        } catch (err) {
          stages.push({ stage: key, status: 'failed', durationMs: Date.now() - started });
          throw err;
        }
      };

      stage('Prepare', ctx);
      const prepared = await timed('prepare', async () => {
        try {
          return await prepareApp(ctx, name);
        } catch (err) {
          if (err.code === 'SITE_USER_CONFLICT' || err.code === 'NOT_ALLOWED') throw err;
          throw new StageError('PREPARE_FAILED', `Could not prepare the app: ${err.message}`);
        }
      });
      const { paths, account, fs } = prepared;
      if (!/^https:/.test(repository)) await ensureDeployKey(ctx, account, paths, fs);
      const releaseRel = paths.rel.release(releaseId);
      const releaseDir = path.join(paths.home, releaseRel);
      const switched = { done: false };
      try {
        stage('Fetch', ctx);
        const commit = await timed('fetch', () => fetchRelease(ctx, { account, paths, repository, branch, releaseDir, remaining }));

        const commandEnv = { ...deployEnv(ctx), ...appEnvironment({ name, home: paths.home, releaseDir, runtime, env, port, nodeBinDir: nodeBinDir(ctx) }) };
        stage('Install', ctx);
        await timed('install', async () => {
          if (runtime === 'python') {
            const python = await requireBinary(ctx, 'python3', 'INSTALL_FAILED', 'Python 3 is not installed on this server. Install Python from the Software card on the server page.');
            ctx.log('stdout', '$ python3 -m venv .venv');
            const venv = await runAsApp(ctx, account, python, ['-m', 'venv', '.venv'], { cwd: releaseDir, env: commandEnv, timeoutMs: Math.min(remaining(), 300_000) });
            if (venv.exitCode !== 0) {
              throw new StageError('INSTALL_FAILED', `Creating the virtual environment failed: ${lastLines(venv, 4)} (install Python from the Software card, which adds python3-venv)`);
            }
          }
          const tool = RUNTIME_TOOLS[runtime];
          if (tool) await requireBinary(ctx, tool.binary, 'INSTALL_FAILED', tool.message);
          const commands = await installCommands(ctx, { runtime, installCommand: params.installCommand, releaseDir, port });
          await runCommands(ctx, account, commands, { cwd: releaseDir, env: commandEnv, remaining, code: 'INSTALL_FAILED', what: 'Installing dependencies' });
        });

        stage('Build', ctx);
        await timed('build', async () => {
          if (!buildCommands.length) ctx.log('stdout', 'No build command');
          await runCommands(ctx, account, buildCommands, { cwd: releaseDir, env: commandEnv, remaining, code: 'BUILD_FAILED', what: 'The build' });
        });

        stage('Configure', ctx);
        const writeConfig = (dir) => writeProcessConfig(ctx, { name, runtime, account, paths, fs, releaseDir: dir, startArgv, env, port, limits, instances, zeroDowntime });
        const config = await timed('configure', async () => {
          try {
            return await writeConfig(releaseDir);
          } catch (err) {
            if (err instanceof StageError || err.code === 'PM2_NOT_INSTALLED') throw err;
            throw new StageError('CONFIGURE_FAILED', `Could not write the app configuration: ${err.message}`);
          }
        });

        switched.done = true;
        // "start" covers the switch and the health check.
        const outcome = await timed('start', () => switchAndCheck(ctx, { name, account, paths, fs, releaseId, port, healthCheckSeconds, writeConfig, reloadable: config.reloadable }));
        const releases = await pruneReleases(ctx, fs, paths, keep, [releaseId, outcome.previous].filter(Boolean));
        ctx.webInventory?.invalidate();
        const summary = await processSummary(ctx, account, paths, name);
        return {
          output: { releaseId, branch, ...commit, previousRelease: outcome.previous, releases, health: outcome.health, reloaded: outcome.how === 'reloaded', stages, ...summary },
        };
      } catch (err) {
        // Nothing switched yet: the running release is untouched, so the new
        // folder can go. After a switch-back it is not needed either.
        const current = await currentRelease(fs, paths).catch(() => null);
        if (current !== releaseId) await removeRelease(ctx, fs, paths, releaseId);
        if (switched.done) ctx.webInventory?.invalidate();
        throw err;
      }
    },
  },

  ROLLBACK_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, [...PROCESS_KEYS, 'releaseId']);
      const { name, runtime, port, env, startArgv, healthCheckSeconds, limits, instances, zeroDowntime } = processParams(params);
      const releaseId = checkReleaseId(params.releaseId);
      requireApps(ctx.policy);
      const paths = appPaths(ctx.policy, name);
      const account = await requireSiteAccount(ctx, name, paths);
      const fs = files(ctx, account, paths.home);
      const releases = await listReleases(fs, paths);
      if (!releases.includes(releaseId)) {
        throw new OperationError('RELEASE_NOT_FOUND', `Release ${releaseId} is no longer on the server (only the newest releases are kept). Deploy it again instead.`);
      }
      const releaseDir = path.join(paths.home, paths.rel.release(releaseId));
      const writeConfig = (dir) => writeProcessConfig(ctx, { name, runtime, account, paths, fs, releaseDir: dir, startArgv, env, port, limits, instances, zeroDowntime });
      stage('Configure', ctx);
      const config = await writeConfig(releaseDir);
      const outcome = await switchAndCheck(ctx, { name, account, paths, fs, releaseId, port, healthCheckSeconds, writeConfig, reloadable: config.reloadable });
      ctx.webInventory?.invalidate();
      return { output: { releaseId, previousRelease: outcome.previous, releases, health: outcome.health, ...(await processSummary(ctx, account, paths, name)) } };
    },
  },

  CONFIGURE_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, [...PROCESS_KEYS, 'restart']);
      const { name, runtime, port, env, startArgv, healthCheckSeconds, limits, instances, zeroDowntime } = processParams(params);
      const restart = params.restart ?? true;
      if (typeof restart !== 'boolean') throw new OperationError('INVALID_PARAMS', 'restart must be true or false');
      requireApps(ctx.policy);
      const paths = appPaths(ctx.policy, name);
      const account = await requireSiteAccount(ctx, name, paths);
      const fs = files(ctx, account, paths.home);
      const current = await currentRelease(fs, paths);
      const { onlyInstancesChanged, reloadable } = await writeProcessConfig(ctx, {
        name,
        runtime,
        account,
        paths,
        fs,
        releaseDir: current ? path.join(paths.home, paths.rel.release(current)) : null,
        startArgv,
        env,
        port,
        limits,
        instances,
        zeroDowntime,
      });
      let health = null;
      const unit = await unitState(ctx, paths);
      if (!current) ctx.log('stdout', 'Saved. The app has not been deployed yet, so nothing was restarted.');
      else if (restart && unit.active === 'active' && onlyInstancesChanged && (await scaleRunning(ctx, account, paths, name, instances))) {
        // Copies were added or removed while the others kept serving.
        health = await healthCheck(ctx, account, paths, name, port, healthCheckSeconds);
        ctx.log(health.ok ? 'stdout' : 'stderr', health.message);
        if (!health.ok) throw new OperationError('HEALTH_CHECK_FAILED', `The app now runs ${instances} copies, but not all of them came up: ${health.message}`);
      } else if (restart && unit.active === 'active') {
        await startOrRestart(ctx, paths, reloadable ? { account, name } : null);
        health = await healthCheck(ctx, account, paths, name, port, healthCheckSeconds);
        ctx.log(health.ok ? 'stdout' : 'stderr', health.message);
        if (!health.ok) throw new OperationError('HEALTH_CHECK_FAILED', `The new settings are saved, but the app did not come back up: ${health.message}`);
      } else if (unit.active !== 'active') ctx.log('stdout', 'Saved. The app is stopped; the settings apply when it starts.');
      return { output: { current, restarted: Boolean(health), health, ...(await processSummary(ctx, account, paths, name)) } };
    },
  },

  START_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'port', 'healthCheckSeconds']);
      return control(ctx, params, 'start');
    },
  },

  STOP_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      return control(ctx, params, 'stop');
    },
  },

  RESTART_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'port', 'healthCheckSeconds', 'zeroDowntime']);
      return control(ctx, params, 'restart');
    },
  },

  DELETE_APPLICATION: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'removeFiles', 'removeSite']);
      const name = checkAppName(params.name);
      const removeFiles = params.removeFiles ?? false;
      const removeSite = params.removeSite ?? false;
      if (typeof removeFiles !== 'boolean' || typeof removeSite !== 'boolean') {
        throw new OperationError('INVALID_PARAMS', 'removeFiles and removeSite must be true or false');
      }
      requireApps(ctx.policy);
      const paths = appPaths(ctx.policy, name);
      if (await fileExists(paths.unitFile)) {
        ctx.log('stdout', `$ systemctl disable --now ${paths.unitName}`);
        const stop = await ctx.run('systemctl', ['disable', '--now', `${paths.unitName}.service`], { timeoutMs: 60_000 });
        if (stop.exitCode !== 0) ctx.log('stderr', `systemctl disable reported: ${lastLines(stop, 3)}`);
        await rm(paths.unitFile, { force: true });
        await ctx.run('systemctl', ['daemon-reload'], { timeoutMs: 60_000 });
      }
      let site = null;
      if (removeSite || removeFiles) {
        ctx.log('stdout', removeFiles ? 'Removing the app’s NGINX site, files and user' : 'Removing the app’s NGINX site');
        site = (await SITE_OPERATIONS.DELETE_SITE.run({ name, removeFiles }, ctx)).output;
      } else {
        ctx.log('stdout', `Files and the user ${name} were kept in ${paths.home}.`);
      }
      ctx.webInventory?.invalidate();
      return { output: { name, filesRemoved: Boolean(site?.filesRemoved), siteRemoved: Boolean(site) } };
    },
  },

  APP_STATUS: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      const name = checkAppName(params.name);
      requireApps(ctx.policy);
      const paths = appPaths(ctx.policy, name);
      const account = await requireSiteAccount(ctx, name, paths);
      const fs = files(ctx, account, paths.home);
      const [summary, releases, current] = await Promise.all([processSummary(ctx, account, paths, name), listReleases(fs, paths), currentRelease(fs, paths)]);
      return { output: { ...summary, releases, current } };
    },
  },

  APP_LOGS: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'log', 'lines']);
      const name = checkAppName(params.name);
      if (!Object.hasOwn(APP_LOG_FILES, params.log)) throw new OperationError('INVALID_PARAMS', 'log must be output or error');
      const lines = checkInteger(params.lines, 'lines', 10, 2000, 200);
      requireApps(ctx.policy);
      const paths = appPaths(ctx.policy, name);
      const account = await requireSiteAccount(ctx, name, paths);
      const result = await files(ctx, account, paths.home)({ action: 'tail', path: APP_LOG_FILES[params.log], lines });
      return { output: { log: params.log, file: path.join(paths.home, APP_LOG_FILES[params.log]), lines: result.lines, missing: result.missing } };
    },
  },
};

async function control(ctx, params, verb) {
  const name = checkAppName(params.name);
  const port = checkPort(params.port);
  const seconds = checkInteger(params.healthCheckSeconds, 'healthCheckSeconds', 5, 300, 30);
  requireApps(ctx.policy);
  const paths = appPaths(ctx.policy, name);
  const account = await requireSiteAccount(ctx, name, paths);
  if (!(await fileExists(paths.unitFile))) {
    throw new OperationError('APP_NOT_DEPLOYED', 'This app has not been deployed yet. Deploy it first.');
  }
  if (verb === 'stop') {
    ctx.log('stdout', `$ systemctl disable --now ${paths.unitName}`);
    await systemctl(ctx, ['disable', '--now', `${paths.unitName}.service`]);
  } else {
    if (verb === 'start') {
      const unit = await unitState(ctx, paths);
      if (port && unit.active !== 'active' && (await portOpen(ctx, port))) {
        throw new OperationError('PORT_IN_USE', `Port ${port} is already used by another program on this server`);
      }
      ctx.log('stdout', `$ systemctl enable --now ${paths.unitName}`);
      await systemctl(ctx, ['enable', '--now', `${paths.unitName}.service`]);
    } else {
      // An app in cluster mode with zero-downtime reloads on is reloaded.
      const ecosystem = params.zeroDowntime === true ? await readEcosystem(files(ctx, account, paths.home), paths) : null;
      const reloaded = bothCluster(ecosystem, ecosystem) && (await unitState(ctx, paths)).active === 'active' && (await reloadRunning(ctx, account, paths, name));
      if (!reloaded) {
        ctx.log('stdout', `$ systemctl restart ${paths.unitName}`);
        await systemctl(ctx, ['restart', `${paths.unitName}.service`]);
      }
    }
    const health = await healthCheck(ctx, account, paths, name, port, seconds);
    ctx.log(health.ok ? 'stdout' : 'stderr', health.message);
    if (!health.ok) throw new OperationError('HEALTH_CHECK_FAILED', health.message);
  }
  ctx.webInventory?.invalidate();
  return { output: { name, ...(await processSummary(ctx, account, paths, name)) } };
}

export { APP_HEADER };
