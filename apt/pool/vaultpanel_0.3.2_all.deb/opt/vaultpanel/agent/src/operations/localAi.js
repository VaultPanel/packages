import { createHash } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import os from 'node:os';
import { chmod, chown, mkdir, readFile, rename, rm, stat, statfs, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { findBinary } from '../monitoring/web.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';
import { lookup, writeFileAtomic } from './sites.js';
import { aptInstall } from './webStack.js';

// The AI assistant's free model on the panel's own server: Ollama, run by its
// own system account as vaultpanel-ai.service, listening on 127.0.0.1 only.
// Ollama has no password, so a firewall rule (nftables, set up and taken down
// by the service itself, see guardScript) lets only root and the panel's own
// account reach it: websites and apps on this server cannot use or change it.
//
// The Ollama release is fixed here with its SHA-256 for each architecture,
// so a changed download is refused; a newer agent brings a newer Ollama. The
// models are this agent's own list, whatever the panel asks for.

// The SHA-256s are the release's own sha256sum.txt. Ollama ships no CPU-only
// archive: the full one is downloaded (and checked), and the GPU libraries
// are left out when unpacking.
export const OLLAMA = Object.freeze({
  version: '0.40.16',
  port: 21434,
  assets: {
    x64: { file: 'ollama-linux-amd64.tar.zst', sha256: '87bfafb2acbc89b2e6a1be0a9043de6aa75fb450696f86bc426e65fc448f788d' },
    arm64: { file: 'ollama-linux-arm64.tar.zst', sha256: 'e45b8e6dcb86cb9f3057396351655079c9a4879b4ced2678c9350d375dcbc224' },
  },
  url: (file) => `https://github.com/ollama/ollama/releases/download/v${OLLAMA.version}/${file}`,
});

const GB = 1024 ** 3;

// The models this agent downloads (the panel's list is LOCAL_AI_MODELS in
// @vaultpanel/shared): their download size, for the disk check, and about
// what they need loaded, for the memory check.
export const LOCAL_AI_MODELS = Object.freeze({
  'qwen3.5:2b-q4_K_M': { downloadBytes: 1_945_781_358, memoryBytes: 2.5 * GB },
  'granite4.1:3b': { downloadBytes: 2_099_520_281, memoryBytes: 3.5 * GB },
  'qwen3.5:4b': { downloadBytes: 3_324_173_934, memoryBytes: 4.5 * GB },
  'qwen3.5:9b': { downloadBytes: 6_550_825_550, memoryBytes: 8 * GB },
});

// The archive (about 1.6 GB) and what is kept of it, while both are on disk.
const PROGRAM_BYTES = 2 * GB;
// Memory the model's service may never take from the rest of the server.
const MEMORY_RESERVE = 1 * GB;

const SERVICE = 'vaultpanel-ai';
const ACCOUNT = 'vaultpanel-ai';
const TABLE = 'vaultpanel_ai';

export function localAiPaths(policy = {}) {
  const dir = policy.localAiDir ?? '/opt/vaultpanel-ai';
  const data = policy.localAiDataDir ?? '/var/lib/vaultpanel-ai';
  return {
    dir,
    data,
    models: path.join(data, 'models'),
    downloads: path.join(data, 'download'),
    binary: path.join(dir, 'bin', 'ollama'),
    versionFile: path.join(dir, 'VERSION'),
    guard: path.join(dir, 'guard'),
    unit: policy.localAiUnitPath ?? `/etc/systemd/system/${SERVICE}.service`,
  };
}

// Run by the service before Ollama starts (and after it stops): only root and
// the panel's account may connect to its port. If this fails, Ollama does
// not start, so it is never reachable without the rule. The rule is an
// nftables table of its own, which UFW (turning it on or off flushes
// iptables' chains), Docker and iptables commands leave alone; it is
// replaced in one step, so starting again never leaves a gap.
export function guardScript(panelUid, port = OLLAMA.port) {
  return `#!/bin/sh
# Managed by VaultPanel: only root and the panel (uid ${panelUid}) may reach the
# assistant's model on 127.0.0.1:${port}. Run by ${SERVICE}.service.
set -e
PATH=/usr/sbin:/usr/bin:/sbin:/bin
case "$1" in
  start)
    nft -f - <<'RULES'
table inet ${TABLE}
delete table inet ${TABLE}
table inet ${TABLE} {
  chain output {
    type filter hook output priority 0; policy accept;
    oifname "lo" tcp dport ${port} meta skuid != { 0, ${panelUid} } reject with tcp reset
  }
}
RULES
    ;;
  stop)
    nft delete table inet ${TABLE} 2>/dev/null || true
    ;;
  *)
    echo "usage: guard start|stop" >&2
    exit 2
    ;;
esac
`;
}

// One model loaded at a time, one answer at a time (each would need memory of
// its own), a context large enough for the assistant's tools, and a lower
// priority than websites and the panel. Ollama checks no memory before
// loading a model on a CPU, so the service has a memory limit (the kernel
// stops the model, not the panel's database, when it runs out) and is the
// first the kernel stops when the whole server runs out. Hardened like the
// panel's services; no Ollama cloud features.
export function serviceUnit(paths, { memoryMaxBytes = null } = {}) {
  const memoryMax = memoryMaxBytes ? `MemoryMax=${Math.floor(memoryMaxBytes)}\n` : '';
  return `# Managed by VaultPanel: the AI assistant's model on this server.
[Unit]
Description=VaultPanel assistant model (Ollama)
After=network-online.target
Wants=network-online.target

[Service]
Type=exec
User=${ACCOUNT}
Group=${ACCOUNT}
ExecStartPre=+${paths.guard} start
ExecStart=${paths.binary} serve
ExecStopPost=+${paths.guard} stop
Environment=HOME=${paths.data}
Environment=OLLAMA_HOST=127.0.0.1:${OLLAMA.port}
Environment=OLLAMA_MODELS=${paths.models}
Environment=OLLAMA_CONTEXT_LENGTH=8192
Environment=OLLAMA_NUM_PARALLEL=1
Environment=OLLAMA_MAX_LOADED_MODELS=1
Environment=OLLAMA_KEEP_ALIVE=10m
Environment=OLLAMA_NO_CLOUD=1
Restart=on-failure
RestartSec=5
Nice=10
CPUWeight=50
${memoryMax}OOMScoreAdjust=500
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=${paths.data}
ProtectHome=true
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
RestrictRealtime=true
LockPersonality=true

[Install]
WantedBy=multi-user.target
`;
}

function apiUrl(ctx) {
  return ctx.localAiUrl ?? `http://127.0.0.1:${OLLAMA.port}`;
}

async function api(ctx, route, { method = 'GET', body, timeoutMs = 10_000 } = {}) {
  const res = await (ctx.fetch ?? fetch)(`${apiUrl(ctx)}${route}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeoutMs),
  });
  return res;
}

async function apiJson(ctx, route, options) {
  const res = await api(ctx, route, options);
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new OperationError('OLLAMA_ERROR', `Ollama answered ${res.status} to ${route}: ${data?.error ?? res.statusText}`);
  return data;
}

async function listModels(ctx) {
  const data = await apiJson(ctx, '/api/tags');
  return (data?.models ?? []).map((m) => ({ id: m.name ?? m.model, sizeBytes: m.size ?? null }));
}

// Waits for Ollama to answer after (re)starting.
async function waitForApi(ctx, timeoutMs = 60_000) {
  const until = Date.now() + timeoutMs;
  for (;;) {
    try {
      const data = await apiJson(ctx, '/api/version', { timeoutMs: 3000 });
      return data?.version ?? null;
    } catch (err) {
      if (Date.now() > until) {
        throw new OperationError('OLLAMA_NOT_STARTING', `Ollama did not start (${err.message}). See: journalctl -u ${SERVICE}`);
      }
      await new Promise((r) => setTimeout(r, ctx.pollMs ?? 1000));
    }
  }
}

async function installedVersion(paths) {
  try {
    const [version] = await Promise.all([readFile(paths.versionFile, 'utf8'), stat(paths.binary)]);
    return version.trim();
  } catch {
    return null;
  }
}

async function freeBytes(dir) {
  // The nearest folder that exists (the data folder may not yet).
  for (let at = dir; ; at = path.dirname(at)) {
    try {
      const s = await statfs(at);
      return s.bavail * s.bsize;
    } catch (err) {
      if (path.dirname(at) === at) throw err;
    }
  }
}

function gb(bytes) {
  return `${(bytes / GB).toFixed(1)} GB`;
}

// Streams a download to disk, hashing it on the way, with progress lines.
async function download(ctx, url, target, remaining) {
  const res = await (ctx.fetch ?? fetch)(url, { redirect: 'follow', signal: AbortSignal.timeout(remaining()) });
  if (!res.ok || !res.body) throw new OperationError('DOWNLOAD_FAILED', `Could not download ${url} (HTTP ${res.status})`);
  const total = Number(res.headers.get('content-length')) || null;
  const hash = createHash('sha256');
  let done = 0;
  let next = 0.1;
  const meter = new Transform({
    transform(chunk, _enc, callback) {
      hash.update(chunk);
      done += chunk.length;
      if (total && done / total >= next) {
        ctx.log('stdout', `Downloaded ${Math.floor((done / total) * 100)}% (${gb(done)} of ${gb(total)})`);
        next += 0.1;
      }
      callback(null, chunk);
    },
  });
  await pipeline(Readable.fromWeb(res.body), meter, createWriteStream(target, { mode: 0o600 }));
  return hash.digest('hex');
}

// Downloads the fixed Ollama release, checks its SHA-256 and puts it in place
// (the CPU build only: GPU libraries are left out).
async function installProgram(ctx, paths, release, asset, remaining) {
  await mkdir(paths.downloads, { recursive: true, mode: 0o700 });
  const archive = path.join(paths.downloads, asset.file);
  const url = release.url(asset.file);
  ctx.log('stdout', `Downloading Ollama ${release.version} from ${new URL(url).host}`);
  try {
    const sha256 = await download(ctx, url, archive, remaining);
    if (sha256 !== asset.sha256) {
      throw new OperationError('DOWNLOAD_FAILED', `The Ollama download does not match its known SHA-256 (got ${sha256}). It was not installed.`);
    }
    ctx.log('stdout', 'SHA-256 checked');
    const staging = `${paths.dir}.new`;
    await rm(staging, { recursive: true, force: true });
    await mkdir(staging, { recursive: true, mode: 0o755 });
    ctx.log('stdout', `Unpacking into ${paths.dir}`);
    assertCommandOk(await ctx.run('tar', [...TAR_FLAGS(asset.file), '-x', '--no-same-owner', '-f', archive, '-C', staging, ...TAR_EXCLUDES], { timeoutMs: remaining() }), 'Unpacking Ollama');
    await stat(path.join(staging, 'bin', 'ollama')).catch(() => {
      throw new OperationError('INSTALL_FAILED', 'The Ollama archive has no bin/ollama');
    });
    await writeFile(path.join(staging, 'VERSION'), `${release.version}\n`, { mode: 0o644 });
    const old = `${paths.dir}.old`;
    await rm(old, { recursive: true, force: true });
    await rename(paths.dir, old).catch((err) => {
      if (err.code !== 'ENOENT') throw err;
    });
    await rename(staging, paths.dir);
    await rm(old, { recursive: true, force: true });
  } finally {
    await rm(archive, { force: true });
  }
}

const TAR_FLAGS = (file) => (file.endsWith('.zst') ? ['--zstd'] : file.endsWith('.tgz') || file.endsWith('.gz') ? ['-z'] : []);
// GPU builds: a VPS has no GPU, and they are most of the archive.
const TAR_EXCLUDES = ['--exclude=lib/ollama/cuda_*', '--exclude=lib/ollama/rocm*', '--exclude=lib/ollama/vulkan*'];

async function ensureAccount(ctx, paths) {
  let account = await lookup(ctx, ACCOUNT);
  if (!account) {
    ctx.log('stdout', `$ useradd ${ACCOUNT}`);
    assertCommandOk(await ctx.run('useradd', ['--system', '--user-group', '--home-dir', paths.data, '--no-create-home', '--shell', '/usr/sbin/nologin', ACCOUNT], { timeoutMs: 30_000 }), 'useradd');
    account = await lookup(ctx, ACCOUNT);
  }
  if (!account || account.uid === 0) throw new OperationError('COMMAND_FAILED', `The ${ACCOUNT} account could not be created`);
  for (const dir of [paths.data, paths.models]) {
    await mkdir(dir, { recursive: true, mode: 0o750 });
    await (ctx.chown ?? chown)(dir, account.uid, account.gid);
    await chmod(dir, 0o750);
  }
  return account;
}

async function systemctl(ctx, args, what) {
  ctx.log('stdout', `$ systemctl ${args.join(' ')}`);
  return assertCommandOk(await ctx.run('systemctl', args, { timeoutMs: 120_000, onLine: ctx.log }), what);
}

// Writes the guard and the unit; true when either changed.
async function writeService(ctx, paths, panelUid, totalMemory) {
  let changed = false;
  for (const [file, content, mode] of [
    [paths.guard, guardScript(panelUid), 0o755],
    [paths.unit, serviceUnit(paths, { memoryMaxBytes: Math.max(GB, totalMemory - MEMORY_RESERVE) }), 0o644],
  ]) {
    const before = await readFile(file, 'utf8').catch(() => null);
    if (before !== content) {
      await writeFileAtomic(file, content, mode);
      changed = true;
    }
  }
  return changed;
}

// Downloads a model through Ollama, with a line for each step and every 10%.
async function pullModel(ctx, model, remaining) {
  ctx.log('stdout', `Downloading the model ${model}`);
  const res = await api(ctx, '/api/pull', { method: 'POST', body: { model, stream: true }, timeoutMs: remaining() });
  if (!res.ok || !res.body) throw new OperationError('MODEL_DOWNLOAD_FAILED', `Ollama could not start downloading ${model} (HTTP ${res.status})`);
  let lastStatus = '';
  let next = 0.1;
  let success = false;
  let buffered = '';
  const handle = (line) => {
    if (!line.trim()) return;
    let event;
    try {
      event = JSON.parse(line);
    } catch {
      return;
    }
    if (event.error) throw new OperationError('MODEL_DOWNLOAD_FAILED', `Ollama could not download ${model}: ${event.error}`);
    if (event.status === 'success') success = true;
    if (event.total && event.completed !== undefined) {
      const share = event.completed / event.total;
      if (share >= next || share === 1) {
        if (event.total > 50 * 1024 * 1024) ctx.log('stdout', `${Math.floor(share * 100)}% of ${gb(event.total)}`);
        next = share === 1 ? 0.1 : Math.floor(share * 10) / 10 + 0.1;
      }
    } else if (event.status && event.status !== lastStatus) {
      ctx.log('stdout', event.status);
      lastStatus = event.status;
      next = 0.1;
    }
  };
  const decoder = new TextDecoder();
  for await (const chunk of res.body) {
    buffered += decoder.decode(chunk, { stream: true });
    const lines = buffered.split('\n');
    buffered = lines.pop();
    for (const line of lines) handle(line);
  }
  handle(buffered + decoder.decode());
  if (!success) throw new OperationError('MODEL_DOWNLOAD_FAILED', `The download of ${model} stopped before it finished`);
}

function checkModel(params) {
  if (!Object.hasOwn(LOCAL_AI_MODELS, params.model ?? '')) {
    throw new OperationError('INVALID_PARAMS', `model must be one of: ${Object.keys(LOCAL_AI_MODELS).join(', ')}`);
  }
  return params.model;
}

async function requireTools(ctx, names) {
  for (const name of names) {
    if (!(await findBinary(name, ctx.binDirs))) {
      throw new OperationError('UNSUPPORTED_SYSTEM', `The model on this server needs ${name}, which this server does not have.`);
    }
  }
}

export const LOCAL_AI_OPERATIONS = {
  LOCAL_AI_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, ['model', 'panelUid']);
      const model = checkModel(params);
      const panelUid = params.panelUid;
      if (!Number.isInteger(panelUid) || panelUid < 0 || panelUid > 2 ** 31 - 2) throw new OperationError('INVALID_PARAMS', 'panelUid must be a user id');
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing software is disabled in this agent config');
      // Tests pass a release of their own.
      const release = ctx.ollamaRelease ?? OLLAMA;
      const asset = release.assets[ctx.arch ?? process.arch];
      if (!asset) throw new OperationError('UNSUPPORTED_SYSTEM', 'Ollama runs on 64-bit Intel/AMD (x86-64) and ARM (arm64) servers only.');
      await requireTools(ctx, ['systemctl', 'tar', 'useradd']);
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());
      const paths = localAiPaths(ctx.policy);

      const spec = LOCAL_AI_MODELS[model];
      const totalMemory = ctx.totalMemoryBytes ?? os.totalmem();
      if (totalMemory < spec.memoryBytes) {
        throw new OperationError('NOT_ENOUGH_MEMORY', `${model} needs about ${gb(spec.memoryBytes)} of memory, and this server has ${gb(totalMemory)} in all. Choose a smaller model.`);
      }
      const have = await installedVersion(paths);
      const programNeeded = have !== release.version;
      const needed = spec.downloadBytes + (programNeeded ? PROGRAM_BYTES : 0) + 1 * GB;
      const free = await (ctx.freeBytes ?? freeBytes)(paths.data);
      if (free < needed) {
        throw new OperationError('NO_SPACE', `This needs about ${gb(needed)} of free disk space, and the server has ${gb(free)}. Free some space and try again.`);
      }

      // nft for the guard (Debian's cloud images lack it), zstd to unpack.
      const packages = [];
      if (!(await findBinary('nft', ctx.binDirs))) packages.push('nftables');
      if (programNeeded && asset.file.endsWith('.zst') && !(await findBinary('zstd', ctx.binDirs))) packages.push('zstd');
      if (packages.length) await aptInstall(ctx, packages, remaining);

      if (programNeeded) {
        await installProgram(ctx, paths, release, asset, remaining);
      } else {
        ctx.log('stdout', `Ollama ${have} is already installed`);
      }
      await ensureAccount(ctx, paths);
      const changed = await writeService(ctx, paths, panelUid, totalMemory);
      if (changed) await systemctl(ctx, ['daemon-reload'], 'systemctl daemon-reload');
      await systemctl(ctx, ['enable', `${SERVICE}.service`], `Enabling ${SERVICE}`);
      await systemctl(ctx, [programNeeded || changed ? 'restart' : 'start', `${SERVICE}.service`], `Starting ${SERVICE}`);
      const version = await waitForApi(ctx);
      ctx.log('stdout', `Ollama ${version ?? release.version} is running on 127.0.0.1:${OLLAMA.port}, reachable only by the panel and root`);

      await pullModel(ctx, model, remaining);
      const models = await listModels(ctx);
      if (!models.some((m) => m.id === model)) throw new OperationError('MODEL_DOWNLOAD_FAILED', `Ollama does not list ${model} after downloading it`);
      ctx.log('stdout', `${model} is installed. Choose it on System > Assistant Settings to use it.`);
      return { output: { version: version ?? release.version, model, models } };
    },
  },

  LOCAL_AI_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['model']);
      const model = checkModel(params);
      const paths = localAiPaths(ctx.policy);
      if (!(await installedVersion(paths))) throw new OperationError('NOT_INSTALLED', 'Ollama is not installed on this server');
      await systemctl(ctx, ['start', `${SERVICE}.service`], `Starting ${SERVICE}`);
      const version = await waitForApi(ctx);
      ctx.log('stdout', `Removing ${model}`);
      const res = await api(ctx, '/api/delete', { method: 'DELETE', body: { model } });
      if (!res.ok && res.status !== 404) {
        const data = await res.json().catch(() => null);
        throw new OperationError('OLLAMA_ERROR', `Ollama could not remove ${model}: ${data?.error ?? res.statusText}`);
      }
      if (res.status === 404) ctx.log('stdout', `${model} was not installed`);
      const models = await listModels(ctx);
      return { output: { version, model, models } };
    },
  },

  LOCAL_AI_UNINSTALL: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const paths = localAiPaths(ctx.policy);
      const unit = await readFile(paths.unit, 'utf8').catch(() => null);
      if (unit) {
        // Stopping also takes the firewall rule away (the unit's ExecStopPost).
        const stop = await ctx.run('systemctl', ['disable', '--now', `${SERVICE}.service`], { timeoutMs: 120_000, onLine: ctx.log });
        if (stop.exitCode !== 0) ctx.log('stderr', `${SERVICE} did not stop cleanly; removing it anyway`);
        await rm(paths.unit, { force: true });
        await systemctl(ctx, ['daemon-reload'], 'systemctl daemon-reload');
      }
      // In case the service never stopped cleanly.
      if (await stat(paths.guard).catch(() => null)) await ctx.run(paths.guard, ['stop'], { timeoutMs: 30_000 });
      ctx.log('stdout', `Deleting ${paths.dir} and ${paths.data} (the models)`);
      await rm(paths.dir, { recursive: true, force: true });
      await rm(paths.data, { recursive: true, force: true });
      if (await lookup(ctx, ACCOUNT)) {
        const del = await ctx.run('userdel', [ACCOUNT], { timeoutMs: 30_000 });
        if (del.exitCode !== 0) ctx.log('stderr', `Could not delete the ${ACCOUNT} account: ${(del.stderr || '').trim()}`);
      }
      ctx.log('stdout', 'Ollama and its models are removed from this server');
      return { output: { removed: true } };
    },
  },
};
