import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import { apachePort, apacheUser } from '../services/siteConfig.js';
import { OperationError } from './errors.js';
import { lookup } from './sites.js';
import { aptInstall } from './webStack.js';

// Apache for .htaccess files. It runs behind NGINX on 127.0.0.1 only, so
// NGINX keeps ports 80 and 443, certificates and every other site. Sites
// with .htaccess on are passed to it; it hands PHP to each site's own pool.
export const APACHE_MARKER = '# Managed by VaultPanel';
export const APACHE_MODULES = ['proxy_fcgi', 'setenvif', 'rewrite', 'remoteip', 'headers', 'expires'];
// server-status could be reached through a RewriteRule's handler flag.
export const APACHE_MODULES_OFF = ['status', 'info', 'cgi', 'cgid', 'userdir'];

const confRoot = (ctx) => ctx.policy.apacheConfRoot ?? '/etc/apache2';

export function apachePortsConf(policy) {
  return `${APACHE_MARKER}: Apache listens on 127.0.0.1 only, behind NGINX.\nListen 127.0.0.1:${apachePort(policy)}\n`;
}

// Apache runs as its own user, which joins only the groups of sites with
// .htaccess on, and owns only their PHP sockets. The rest of the sites root is
// closed, and settings for PHP sent along with a request are dropped, so one
// site's .htaccess cannot reach another site's files or loosen PHP's limits.
export function apacheVaultpanelConf(policy) {
  const user = apacheUser(policy);
  return `${APACHE_MARKER}: requests come from NGINX on this server.
ServerName localhost
User ${user}
Group ${user}
RemoteIPHeader X-Forwarded-For
RemoteIPInternalProxy 127.0.0.1
SetEnvIf X-Forwarded-Proto https HTTPS=on
ServerTokens Prod
ServerSignature Off
ProxyFCGISetEnvIf "true" !PHP_VALUE
ProxyFCGISetEnvIf "true" !PHP_ADMIN_VALUE
<Directory ${policy.sitesRoot}>
    AllowOverride None
    Require all denied
</Directory>
`;
}

const exists = (file) => access(file).then(() => true, () => false);

async function run(ctx, file, args, what) {
  ctx.log('stdout', `$ ${file} ${args.join(' ')}`);
  const result = await ctx.run(file, args, { timeoutMs: 60_000, onLine: ctx.log });
  if (result.timedOut || result.error || result.exitCode !== 0) {
    const detail = (result.stderr || result.error?.message || '').trim().split('\n').slice(-4).join('\n');
    throw new OperationError('APACHE_SETUP_FAILED', `${what} failed${detail ? `: ${detail}` : ''}`);
  }
}

export async function installApache(ctx, remaining) {
  const root = confRoot(ctx);
  const portsFile = path.join(root, 'ports.conf');
  const ports = await readFile(portsFile, 'utf8').catch(() => null);
  // An Apache someone else set up (on port 80, say) is left alone.
  if ((await findBinary('apache2', ctx.binDirs)) && ports !== null && !ports.startsWith(APACHE_MARKER)) {
    throw new OperationError('APACHE_IN_USE', `Apache is already installed and not set up by VaultPanel (${portsFile}). VaultPanel runs Apache only behind NGINX on 127.0.0.1:${apachePort(ctx.policy)}; remove the other set-up first.`);
  }
  // Written before the package so Apache never tries to take port 80 from NGINX.
  await mkdir(root, { recursive: true });
  await writeFile(portsFile, apachePortsConf(ctx.policy));
  await aptInstall(ctx, ['apache2'], remaining, { keepConfig: true });

  if (!(await lookup(ctx, apacheUser(ctx.policy)))) {
    await run(ctx, 'useradd', ['--system', '--no-create-home', '--home-dir', '/nonexistent', '--shell', '/usr/sbin/nologin', '--user-group', apacheUser(ctx.policy)], 'Creating the Apache user');
  }
  await run(ctx, 'a2enmod', ['-q', ...APACHE_MODULES], 'Turning on Apache modules');
  for (const mod of APACHE_MODULES_OFF) {
    if (await exists(path.join(root, 'mods-enabled', `${mod}.load`))) await run(ctx, 'a2dismod', ['-q', '-f', mod], `Turning off Apache's ${mod} module`);
  }
  await run(ctx, 'a2dissite', ['-q', '000-default'], 'Turning off the default Apache site').catch((err) => ctx.log('stderr', err.message));
  await mkdir(path.join(root, 'conf-available'), { recursive: true });
  await writeFile(path.join(root, 'conf-available', 'vaultpanel.conf'), apacheVaultpanelConf(ctx.policy));
  await run(ctx, 'a2enconf', ['-q', 'vaultpanel'], 'Turning on the VaultPanel Apache settings');
  await run(ctx, 'apache2ctl', ['configtest'], 'Checking the Apache configuration');
  await run(ctx, 'systemctl', ['enable', 'apache2.service'], 'Enabling Apache');
  await run(ctx, 'systemctl', ['restart', 'apache2.service'], 'Starting Apache');
  ctx.log('stdout', `Apache is running on 127.0.0.1:${apachePort(ctx.policy)} behind NGINX. Turn on .htaccess files in a website's settings.`);
}
