// The error every operation throws on purpose: a stable code the panel shows
// and a message written for the person who asked for the operation.
export class OperationError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

export function onlyKeys(params, keys) {
  const extra = Object.keys(params ?? {}).filter((k) => !keys.includes(k));
  if (extra.length) throw new OperationError('INVALID_PARAMS', `Unknown parameters: ${extra.join(', ')}`);
}

// Throws COMMAND_FAILED (or TIMEOUT) unless a runCommand result succeeded.
export function assertCommandOk(result, what) {
  if (result.timedOut) throw new OperationError('TIMEOUT', `${what} did not finish in time`);
  if (result.error) throw new OperationError('COMMAND_FAILED', `${what} could not run: ${result.error.message}`);
  if (result.exitCode !== 0) {
    const detail = (result.stderr || result.stdout || '').trim().split('\n').slice(-8).join('\n');
    throw new OperationError('COMMAND_FAILED', `${what} failed${detail ? `: ${detail}` : ` (exit code ${result.exitCode})`}`);
  }
  return result;
}
