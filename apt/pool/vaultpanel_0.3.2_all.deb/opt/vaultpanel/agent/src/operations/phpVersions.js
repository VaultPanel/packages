import { mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { detectWebStack, findBinary, PHPMYADMIN_SITE } from '../monitoring/web.js';
import { parseOsRelease } from '../monitoring/system.js';
import { PHP_VERSIONS } from '../security/webRules.js';
import { onlyKeys, OperationError } from './errors.js';
import { APT_ENV, aptInstall } from './webStack.js';

// Extra PHP versions next to the system's own, so each website can run the
// version it needs. A version the distribution ships comes from it; any
// other from the repository Ubuntu and Debian users rely on for this:
// ondrej/php on Launchpad (Ubuntu) or packages.sury.org (Debian), both
// maintained by Debian's PHP maintainer.
export const PHP_EXTENSIONS = ['fpm', 'cli', 'mysql', 'curl', 'gd', 'mbstring', 'xml', 'zip', 'intl'];

export function phpPackages(version) {
  // Before PHP 8.0, JSON was a separate package.
  const extensions = Number(version) < 8 ? [...PHP_EXTENSIONS, 'json'] : PHP_EXTENSIONS;
  return extensions.map((e) => `php${version}-${e}`);
}

const ONDREJ_KEY = '14AA40EC0831756756D7F66C4F4EA0AAE5267A6C';
export const PHP_REPOSITORIES = {
  ubuntu: {
    name: 'ondrej/php',
    keyUrl: `https://keyserver.ubuntu.com/pks/lookup?op=get&options=mr&search=0x${ONDREJ_KEY}`,
    url: 'https://ppa.launchpadcontent.net/ondrej/php/ubuntu',
  },
  debian: {
    name: 'packages.sury.org',
    keyUrl: 'https://packages.sury.org/php/apt.gpg',
    url: 'https://packages.sury.org/php/',
  },
};
export const PHP_SOURCE_FILE = 'vaultpanel-php.list';
const CODENAME_PATTERN = /^[a-z]{2,20}$/;

function checkVersion(params) {
  onlyKeys(params, ['version']);
  if (!PHP_VERSIONS.includes(params.version)) throw new OperationError('INVALID_PARAMS', `version must be one of: ${PHP_VERSIONS.join(', ')}`);
  return params.version;
}

async function requireApt(ctx) {
  if (!(await findBinary('apt-get', ctx.binDirs))) {
    throw new OperationError('UNSUPPORTED_SYSTEM', 'Installing PHP versions needs apt (Ubuntu or Debian).');
  }
}

// The version apt would install for a package, or null when no source has it.
async function aptCandidate(ctx, pkg) {
  const result = await ctx.run('apt-cache', ['policy', pkg], { timeoutMs: 60_000, env: APT_ENV });
  const candidate = /Candidate:\s*(\S+)/.exec(result.stdout ?? '')?.[1];
  return candidate && candidate !== '(none)' ? candidate : null;
}

async function aptUpdate(ctx, remaining) {
  ctx.log('stdout', '$ apt-get update');
  const update = await ctx.run('apt-get', ['-o', 'DPkg::Lock::Timeout=120', 'update'], { timeoutMs: remaining(), onLine: ctx.log, env: APT_ENV });
  if (update.timedOut) throw new OperationError('TIMEOUT', 'apt-get update did not finish in time');
  return update.exitCode === 0;
}

async function osRelease(ctx) {
  try {
    return parseOsRelease(await readFile(ctx.policy.osReleaseFile ?? '/etc/os-release', 'utf8'));
  } catch {
    return {};
  }
}

async function download(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(30_000), redirect: 'follow' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const body = Buffer.from(await res.arrayBuffer());
  if (body.length > 256 * 1024) throw new Error('the key is too large');
  return body;
}

// apt reads a signing key in ASCII armor from a .asc file and a binary
// OpenPGP key from a .gpg file. Anything else is not a key.
function keyExtension(body) {
  if (body.toString('utf8', 0, 64).startsWith('-----BEGIN PGP PUBLIC KEY BLOCK-----')) return '.asc';
  return body.length > 0 && (body[0] & 0x80) !== 0 ? '.gpg' : null;
}

// Adds the PHP repository for this system. Returns a function that takes it
// away again, for when it turns out not to have the version.
async function addRepository(ctx, os) {
  const repo = PHP_REPOSITORIES[os.ID];
  const codename = os.VERSION_CODENAME;
  if (!repo || !CODENAME_PATTERN.test(codename ?? '')) return null;
  const keyrings = ctx.policy.aptKeyringsDir ?? '/etc/apt/keyrings';
  const sources = ctx.policy.aptSourcesDir ?? '/etc/apt/sources.list.d';
  const sourcePath = path.join(sources, PHP_SOURCE_FILE);
  ctx.log('stdout', `Adding the ${repo.name} repository for ${os.PRETTY_NAME ?? `${os.ID} ${codename}`}`);
  let key;
  try {
    key = await (ctx.download ?? download)(repo.keyUrl);
  } catch (err) {
    throw new OperationError('DOWNLOAD_FAILED', `Could not download the signing key of the ${repo.name} repository from ${new URL(repo.keyUrl).host} (${err.message}). Check that this server can reach it.`);
  }
  const extension = keyExtension(key);
  if (!extension) throw new OperationError('DOWNLOAD_FAILED', `${new URL(repo.keyUrl).host} did not return a signing key`);
  const keyPath = path.join(keyrings, `vaultpanel-php${extension}`);
  await mkdir(keyrings, { recursive: true, mode: 0o755 });
  await mkdir(sources, { recursive: true, mode: 0o755 });
  await writeFile(keyPath, key, { mode: 0o644 });
  await writeFile(sourcePath, `# Managed by VaultPanel: extra PHP versions.\ndeb [signed-by=${keyPath}] ${repo.url} ${codename} main\n`, { mode: 0o644 });
  return { name: repo.name, remove: () => Promise.all([rm(keyPath, { force: true }), rm(sourcePath, { force: true })]) };
}

async function hasRepository(ctx) {
  const text = await readFile(path.join(ctx.policy.aptSourcesDir ?? '/etc/apt/sources.list.d', PHP_SOURCE_FILE), 'utf8').catch(() => null);
  return Boolean(text);
}

// Sites whose PHP-FPM pool runs on this version, and whether phpMyAdmin does.
async function versionUsers(ctx, version) {
  const poolDir = path.join(ctx.policy.phpConfRoot, version, 'fpm', 'pool.d');
  const pools = await readdir(poolDir).catch(() => []);
  const sites = pools.filter((f) => f.endsWith('.conf') && f !== 'www.conf').map((f) => f.slice(0, -5));
  const pma = await readFile(path.join(ctx.policy.nginxSitesEnabled, PHPMYADMIN_SITE), 'utf8').catch(() => '');
  return { sites, phpMyAdmin: pma.includes(`php${version}-fpm.sock`) };
}

async function installedPackages(ctx, version) {
  const result = await ctx.run('dpkg-query', ['-W', '-f', '${Package} ${db:Status-Abbrev}\\n', `php${version}*`], { timeoutMs: 60_000, env: APT_ENV });
  const own = new RegExp(`^php${version.replace(/[\\.]/g, '\\$&')}(?:-|$)`);
  return (result.stdout ?? '')
    .split('\n')
    .map((line) => line.trim().split(/\s+/))
    .filter(([name, status]) => name && own.test(name) && /^[ih]i/.test(status ?? ''))
    .map(([name]) => name);
}

export const PHP_VERSION_OPERATIONS = {
  PHP_VERSION_INSTALL: {
    async run(params, ctx) {
      const version = checkVersion(params);
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
      await requireApt(ctx);
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());
      const packages = phpPackages(version);

      await aptUpdate(ctx, remaining);
      let source = 'distribution';
      if (!(await aptCandidate(ctx, `php${version}-fpm`))) {
        const os = await osRelease(ctx);
        const system = os.PRETTY_NAME ?? 'this system';
        if (await hasRepository(ctx)) {
          throw new OperationError('PHP_VERSION_UNAVAILABLE', `PHP ${version} is not available for ${system}, neither from the system nor from the extra PHP repository.`);
        }
        const added = await addRepository(ctx, os);
        if (!added) throw new OperationError('PHP_VERSION_UNAVAILABLE', `PHP ${version} is not available for ${system}. Extra PHP versions need Ubuntu or Debian.`);
        await aptUpdate(ctx, remaining);
        if (!(await aptCandidate(ctx, `php${version}-fpm`))) {
          // Leave apt as it was: a repository without this release makes
          // every later apt-get update complain.
          await added.remove();
          await aptUpdate(ctx, remaining);
          throw new OperationError('PHP_VERSION_UNAVAILABLE', `PHP ${version} is not available for ${system} yet: ${added.name} has no packages for it. Try another version.`);
        }
        source = added.name;
      }

      await aptInstall(ctx, packages, remaining);
      ctx.log('stdout', `$ systemctl enable --now php${version}-fpm.service`);
      const start = await ctx.run('systemctl', ['enable', '--now', `php${version}-fpm.service`], { timeoutMs: 60_000, onLine: ctx.log });
      if (start.exitCode !== 0) ctx.log('stderr', `PHP-FPM ${version} did not start; see its status on the Services page`);

      ctx.webInventory?.invalidate();
      const webStack = await detectWebStack(ctx.policy, ctx.binDirs);
      ctx.log('stdout', `Installed PHP ${version}${source === 'distribution' ? '' : ` from ${source}`}. PHP versions on this server: ${webStack.phpVersions.join(', ') || 'none'}`);
      return { output: { version, packages, source, webStack } };
    },
  },

  PHP_VERSION_REMOVE: {
    async run(params, ctx) {
      const version = checkVersion(params);
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Removing packages is disabled in this agent config');
      await requireApt(ctx);
      const users = await versionUsers(ctx, version);
      if (users.sites.length) {
        throw new OperationError('PHP_VERSION_IN_USE', `PHP ${version} runs ${users.sites.length === 1 ? 'the website' : 'these websites'}: ${users.sites.join(', ')}. Move them to another PHP version first.`);
      }
      if (users.phpMyAdmin) throw new OperationError('PHP_VERSION_IN_USE', `phpMyAdmin runs on PHP ${version}. Set phpMyAdmin up again after installing another version, or remove it first.`);

      const packages = await installedPackages(ctx, version);
      if (!packages.length) throw new OperationError('PHP_VERSION_NOT_INSTALLED', `PHP ${version} is not installed on this server`);

      // apt may want to take other software with it (the system's php-fpm,
      // phpMyAdmin...): refuse rather than break it.
      const simulate = await ctx.run('apt-get', ['-s', 'purge', ...packages], { timeoutMs: 120_000, env: APT_ENV });
      if (simulate.exitCode !== 0) {
        throw new OperationError('REMOVE_FAILED', `apt-get cannot remove PHP ${version}: ${(simulate.stderr || '').trim().split('\n').slice(-3).join(' ')}`);
      }
      const removed = [...(simulate.stdout ?? '').matchAll(/^(?:Purg|Remv) (\S+)/gm)].map((m) => m[1]);
      const own = new RegExp(`^php${version.replace(/[\\.]/g, '\\$&')}(?:-|$)`);
      const others = removed.filter((name) => !own.test(name));
      if (others.length) {
        throw new OperationError('PHP_VERSION_NEEDED', `Removing PHP ${version} would also remove ${others.join(', ')}, which need it. It is kept.`);
      }

      const deadline = Date.now() + ctx.timeoutMs;
      ctx.log('stdout', `$ apt-get purge ${packages.join(' ')}`);
      const purge = await ctx.run('apt-get', ['-o', 'DPkg::Lock::Timeout=120', 'purge', '--yes', ...packages], {
        timeoutMs: Math.max(10_000, deadline - Date.now()),
        onLine: ctx.log,
        env: APT_ENV,
      });
      if (purge.timedOut) throw new OperationError('TIMEOUT', 'apt-get purge did not finish in time');
      if (purge.error || purge.exitCode !== 0) {
        const detail = (purge.stderr || '').trim().split('\n').slice(-6).join('\n');
        throw new OperationError('REMOVE_FAILED', `apt-get could not remove PHP ${version}${detail ? `:\n${detail}` : ''}`);
      }
      ctx.webInventory?.invalidate();
      const webStack = await detectWebStack(ctx.policy, ctx.binDirs);
      ctx.log('stdout', `Removed PHP ${version}. PHP versions on this server: ${webStack.phpVersions.join(', ') || 'none'}`);
      return { output: { version, packages, webStack } };
    },
  },
};
