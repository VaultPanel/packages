import { createHash, randomBytes } from 'node:crypto';
import { chmod, mkdir, open, rm, stat, statfs } from 'node:fs/promises';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import { checkSiteName, sitePaths } from '../services/siteConfig.js';
import { FILE_NAME_PATTERN, FILE_PATH_PATTERN, MAX_COMPRESS_NAMES, MAX_FILE_BYTES, MAX_FILE_PATH_LENGTH, MAX_UPLOAD_BYTES } from '../security/webRules.js';
import { DEFAULT_PATH } from '../utils/exec.js';
import { onlyKeys, OperationError } from './errors.js';
import { fileRunner, requireSiteAccount, requireWebsites } from './sites.js';
import { aptInstall } from './webStack.js';

// The file manager. Each request runs as the site's own Linux user inside
// the site's home directory (see services/fileWorker.js).

function checkPath(value, field, { allowRoot = false } = {}) {
  const rel = value ?? '';
  if (typeof rel !== 'string' || rel.length > MAX_FILE_PATH_LENGTH || !FILE_PATH_PATTERN.test(rel) || (!allowRoot && rel === '')) {
    throw new OperationError('INVALID_PARAMS', `${field} must be a path inside the site`);
  }
  return rel;
}

function fileOperation(keys, build, describe) {
  return {
    async run(params, ctx) {
      onlyKeys(params, ['name', ...keys]);
      const name = checkSiteName(params.name);
      requireWebsites(ctx.policy);
      const paths = sitePaths(ctx.policy, name);
      const account = await requireSiteAccount(ctx, name, paths);
      const request = { ...build(params), home: paths.home };
      if (describe) ctx.log('stdout', describe(params));
      const result = await fileRunner(ctx)(account, request, { timeoutMs: ctx.timeoutMs });
      return { output: result };
    },
  };
}

// ---- Uploads, archives -------------------------------------------------------

const UPLOAD_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const SHA256 = /^[0-9a-f]{64}$/;
// Archives are unpacked only when they fit this and the free disk space.
const DEFAULT_MAX_EXTRACT_BYTES = 20 * 1024 * 1024 * 1024;

export const ARCHIVE_KINDS = {
  zip: { pattern: /\.zip$/i, tool: 'unzip', apt: 'unzip' },
  tgz: { pattern: /\.(tar\.gz|tgz)$/i, tool: 'tar', apt: 'tar' },
  tar: { pattern: /\.tar$/i, tool: 'tar', apt: 'tar' },
};

export function archiveKind(name) {
  return Object.entries(ARCHIVE_KINDS).find(([, k]) => k.pattern.test(name))?.[0] ?? null;
}

// The site's account and a way to run file worker requests as it.
async function siteContext(ctx, params) {
  const name = checkSiteName(params.name);
  requireWebsites(ctx.policy);
  const paths = sitePaths(ctx.policy, name);
  const account = await requireSiteAccount(ctx, name, paths);
  const run = fileRunner(ctx);
  const files = (request, timeoutMs = ctx.timeoutMs) => run(account, { ...request, home: paths.home }, { timeoutMs });
  return { name, paths, account, files };
}

// unzip, zip and tar, installed with apt when missing (they are small and
// standard; installing can be turned off in the agent config).
async function requireTool(ctx, tool, apt) {
  if (await findBinary(tool, ctx.binDirs)) return;
  if (ctx.policy.allowWebStackInstall === false) {
    throw new OperationError('TOOL_NOT_INSTALLED', `${tool} is not installed on this server, and installing packages is disabled in this agent config`);
  }
  ctx.log('stdout', `${tool} is not installed; installing it`);
  const until = Date.now() + Math.max(60_000, (ctx.timeoutMs ?? 600_000) / 2);
  await aptInstall(ctx, [apt], () => Math.max(10_000, until - Date.now()));
}

function asSite(site, extra = {}) {
  return { uid: site.account.uid, gid: site.account.gid, env: { PATH: DEFAULT_PATH, LANG: 'C.UTF-8', HOME: site.paths.home }, ...extra };
}

function lastLines(text, count = 6) {
  return (text ?? '').trim().split('\n').slice(-count).join('\n');
}

// How many bytes an archive unpacks to, read with the archive tool as the
// site user (which also checks the archive can be read at all).
async function unpackedSize(ctx, site, kind, archive) {
  if (kind === 'zip') {
    // zipinfo's totals line: "3 files, 12345 bytes uncompressed, 678 bytes compressed:  94.5%"
    const result = await ctx.run('unzip', ['-Z', '-t', archive], asSite(site, { timeoutMs: 120_000 }));
    const match = /([0-9]+) files?, ([0-9]+) bytes? uncompressed/.exec(result.stdout ?? '');
    if (result.timedOut || result.exitCode !== 0 || !match) {
      throw new OperationError('ARCHIVE_INVALID', `This is not a zip file unzip can read${lastLines(result.stderr || result.stdout) ? `: ${lastLines(result.stderr || result.stdout, 2)}` : ''}`);
    }
    return { files: Number(match[1]), bytes: Number(match[2]) };
  }
  let files = 0;
  let bytes = 0;
  const args = ['-t', '-v', ...(kind === 'tgz' ? ['-z'] : []), '-f', archive];
  const result = await ctx.run('tar', args, asSite(site, {
    timeoutMs: 300_000,
    maxOutputBytes: 64 * 1024,
    onLine: (stream, line) => {
      if (stream !== 'stdout') return;
      const size = Number(line.trim().split(/\s+/)[2]);
      files += 1;
      if (Number.isFinite(size)) bytes += size;
    },
  }));
  if (result.timedOut || result.exitCode !== 0) {
    throw new OperationError('ARCHIVE_INVALID', `tar could not read this archive${lastLines(result.stderr) ? `: ${lastLines(result.stderr, 2)}` : ''}`);
  }
  return { files, bytes };
}

async function checkSpace(ctx, home, bytes) {
  const max = ctx.policy.maxExtractBytes ?? DEFAULT_MAX_EXTRACT_BYTES;
  if (bytes > max) throw new OperationError('ARCHIVE_TOO_LARGE', `This archive unpacks to ${gb(bytes)}, more than the ${gb(max)} the file manager unpacks`);
  const fs = await (ctx.statfs ?? statfs)(home);
  const free = Number(fs.bavail) * Number(fs.bsize);
  if (bytes > free * 0.9) throw new OperationError('DISK_FULL', `This archive unpacks to ${gb(bytes)}, but only ${gb(free)} is free on the disk`);
}

const gb = (bytes) => (bytes >= 1024 ** 3 ? `${(bytes / 1024 ** 3).toFixed(1)} GB` : `${(bytes / 1024 ** 2).toFixed(1)} MB`);

// Where uploads wait between the panel and the site: the folder is passable
// but not listable, and each file has an unguessable name, so the site user
// can open only the file it is told about.
async function uploadStaging(policy) {
  const dir = policy.uploadStagingDir ?? '/var/cache/vaultpanel/uploads';
  await mkdir(path.dirname(dir), { recursive: true, mode: 0o755 });
  await mkdir(dir, { recursive: true, mode: 0o711 });
  const parent = await stat(path.dirname(dir));
  if ((parent.mode & 0o011) !== 0o011) await chmod(path.dirname(dir), (parent.mode & 0o7777) | 0o011);
  await chmod(dir, 0o711);
  return dir;
}

// Copies an upload from the panel in chunks, checking size and SHA-256.
async function fetchUpload(ctx, { uploadId, size, sha256 }, file) {
  if (!ctx.panel?.downloadUploadChunk) throw new OperationError('UNSUPPORTED_OPERATION', 'Uploads need the panel connection');
  const hash = createHash('sha256');
  const handle = await open(file, 'wx', 0o600);
  let offset = 0;
  let reported = 0;
  try {
    while (offset < size) {
      const chunk = await ctx.panel.downloadUploadChunk(uploadId, offset);
      const bytes = Buffer.from(chunk.data ?? '', 'base64');
      if (!bytes.length) throw new OperationError('UPLOAD_INCOMPLETE', `The panel sent no data at ${offset} of ${size} bytes`);
      if (offset + bytes.length > size) throw new OperationError('UPLOAD_CORRUPT', 'The panel sent more data than the upload holds');
      await handle.write(bytes);
      hash.update(bytes);
      offset += bytes.length;
      if (offset - reported >= 50 * 1024 * 1024 || offset === size) {
        ctx.log('stdout', `Received ${gb(offset)} of ${gb(size)}`);
        reported = offset;
      }
    }
  } finally {
    await handle.close();
  }
  if (hash.digest('hex') !== sha256) throw new OperationError('UPLOAD_CORRUPT', 'The file received does not match the upload’s checksum. Upload it again.');
}

function checkName(value, field) {
  if (typeof value !== 'string' || !FILE_NAME_PATTERN.test(value)) {
    throw new OperationError('INVALID_PARAMS', `${field} must be names in the folder, without slashes`);
  }
  return value;
}

const ARCHIVE_OPERATIONS = {
  FILE_UPLOAD: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'path', 'uploadId', 'size', 'sha256', 'overwrite']);
      const rel = checkPath(params.path, 'path');
      const { uploadId, size, sha256 } = params;
      const overwrite = params.overwrite ?? false;
      if (typeof uploadId !== 'string' || !UPLOAD_ID.test(uploadId)) throw new OperationError('INVALID_PARAMS', 'uploadId must be an upload id');
      if (!Number.isInteger(size) || size < 0 || size > MAX_UPLOAD_BYTES) throw new OperationError('INVALID_PARAMS', 'size is out of range');
      if (typeof sha256 !== 'string' || !SHA256.test(sha256)) throw new OperationError('INVALID_PARAMS', 'sha256 must be a SHA-256 in hex');
      if (typeof overwrite !== 'boolean') throw new OperationError('INVALID_PARAMS', 'overwrite must be true or false');
      const site = await siteContext(ctx, params);
      const staging = await uploadStaging(ctx.policy);
      const file = path.join(staging, `${randomBytes(16).toString('hex')}.upload`);
      ctx.log('stdout', `Receiving ${rel} (${gb(size)})`);
      try {
        await fetchUpload(ctx, { uploadId, size, sha256 }, file);
        await chmod(file, 0o644);
        const result = await site.files({ action: 'importFile', source: file, path: rel, overwrite });
        ctx.log('stdout', `Saved ${rel}`);
        return { output: result };
      } finally {
        await rm(file, { force: true });
      }
    },
  },

  // Unpacks a zip, .tar.gz or .tar file into a folder, as the site user.
  FILE_EXTRACT: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'path', 'to', 'overwrite']);
      const rel = checkPath(params.path, 'path');
      const to = checkPath(params.to ?? '', 'to', { allowRoot: true });
      const overwrite = params.overwrite ?? false;
      if (typeof overwrite !== 'boolean') throw new OperationError('INVALID_PARAMS', 'overwrite must be true or false');
      const kind = archiveKind(rel);
      if (!kind) throw new OperationError('ARCHIVE_UNSUPPORTED', 'The file manager unpacks .zip, .tar.gz, .tgz and .tar files');
      const site = await siteContext(ctx, params);
      const archive = await site.files({ action: 'locate', path: rel, type: 'file' });
      // The folder to unpack into is created when missing (one level).
      let dest;
      try {
        dest = await site.files({ action: 'locate', path: to, type: 'dir' });
      } catch (err) {
        if (err.code !== 'FILE_NOT_FOUND' || !to) throw err;
        await site.files({ action: 'mkdir', path: to });
        dest = await site.files({ action: 'locate', path: to, type: 'dir' });
      }
      await requireTool(ctx, ARCHIVE_KINDS[kind].tool, ARCHIVE_KINDS[kind].apt);
      const { files, bytes } = await unpackedSize(ctx, site, kind, archive.real);
      await checkSpace(ctx, site.paths.home, bytes);
      ctx.log('stdout', `Unpacking ${rel} (${files} files, ${gb(bytes)}) into ${to || 'the home folder'}${overwrite ? ', replacing existing files' : ', keeping existing files'}`);
      const args =
        kind === 'zip'
          ? ['-q', overwrite ? '-o' : '-n', archive.real, '-d', dest.real]
          : ['-x', ...(kind === 'tgz' ? ['-z'] : []), '-f', archive.real, '-C', dest.real, '--no-same-owner', '--no-same-permissions', overwrite ? '--overwrite' : '--skip-old-files'];
      const result = await ctx.run(ARCHIVE_KINDS[kind].tool, args, asSite(site, { cwd: dest.real, timeoutMs: ctx.timeoutMs ?? 1_800_000 }));
      // unzip exits 1 for warnings (such as names it skipped as unsafe).
      const okExit = result.exitCode === 0 || (kind === 'zip' && result.exitCode === 1);
      if (result.timedOut) throw new OperationError('TIMEOUT', 'Unpacking did not finish in time');
      if (result.error || !okExit) {
        throw new OperationError('EXTRACT_FAILED', `Unpacking failed: ${lastLines(result.stderr || result.stdout) || result.error?.message || `exit code ${result.exitCode}`}`);
      }
      if (result.exitCode === 1 && lastLines(result.stderr)) ctx.log('stderr', lastLines(result.stderr));
      return { output: { path: rel, to, files, bytes } };
    },
  },

  // Makes a zip of files and folders that sit in one folder, as the site user.
  FILE_COMPRESS: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'folder', 'names', 'to']);
      const folder = checkPath(params.folder ?? '', 'folder', { allowRoot: true });
      const to = checkPath(params.to, 'to');
      if (!/\.zip$/i.test(to)) throw new OperationError('INVALID_PARAMS', 'to must be a .zip file');
      if (!Array.isArray(params.names) || params.names.length === 0 || params.names.length > MAX_COMPRESS_NAMES) {
        throw new OperationError('INVALID_PARAMS', `names must list 1 to ${MAX_COMPRESS_NAMES} files or folders`);
      }
      const names = [...new Set(params.names.map((n) => checkName(n, 'names')))];
      const site = await siteContext(ctx, params);
      const base = await site.files({ action: 'locate', path: folder, type: 'dir' });
      for (const n of names) await site.files({ action: 'locate', path: folder ? `${folder}/${n}` : n });
      const parent = await site.files({ action: 'locate', path: to.includes('/') ? to.slice(0, to.lastIndexOf('/')) : '', type: 'dir' });
      const target = path.join(parent.real, path.basename(to));
      const existing = await site.files({ action: 'locate', path: to }).catch((err) => (err.code === 'FILE_NOT_FOUND' ? null : Promise.reject(err)));
      if (existing) throw new OperationError('FILE_EXISTS', `${to} already exists`);
      await requireTool(ctx, 'zip', 'zip');
      ctx.log('stdout', `Compressing ${names.length === 1 ? names[0] : `${names.length} items`} into ${to}`);
      // -y keeps symbolic links as links instead of following them; "./"
      // keeps a name that starts with "-" from being read as an option.
      const result = await ctx.run('zip', ['-r', '-q', '-y', target, ...names.map((n) => `./${n}`)], asSite(site, { cwd: base.real, timeoutMs: ctx.timeoutMs ?? 1_800_000 }));
      if (result.timedOut) throw new OperationError('TIMEOUT', 'Compressing did not finish in time');
      if (result.error || result.exitCode !== 0) {
        await site.files({ action: 'delete', path: to }).catch(() => {});
        throw new OperationError('COMPRESS_FAILED', `zip failed: ${lastLines(result.stderr || result.stdout) || result.error?.message || `exit code ${result.exitCode}`}`);
      }
      const made = await site.files({ action: 'locate', path: to, type: 'file' });
      ctx.log('stdout', `Created ${to} (${gb(made.size)})`);
      return { output: { path: to, size: made.size, names } };
    },
  },
};

// Pieces the file worker reads and the agent sends to the panel.
const DOWNLOAD_CHUNK_BYTES = 2 * 1024 * 1024;
const MODE = /^[0-7]{3}$/;

const TRANSFER_OPERATIONS = {
  // Sends a file to the panel in pieces, read as the site user, so it can be
  // downloaded or opened in the editor whatever its size.
  FILE_DOWNLOAD: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'path', 'downloadId', 'maxBytes']);
      const rel = checkPath(params.path, 'path');
      if (typeof params.downloadId !== 'string' || !UPLOAD_ID.test(params.downloadId)) throw new OperationError('INVALID_PARAMS', 'downloadId must be a download id');
      const maxBytes = params.maxBytes ?? MAX_UPLOAD_BYTES;
      if (!Number.isInteger(maxBytes) || maxBytes < 1 || maxBytes > MAX_UPLOAD_BYTES) throw new OperationError('INVALID_PARAMS', 'maxBytes is out of range');
      if (!ctx.panel?.uploadDownloadChunk) throw new OperationError('UNSUPPORTED_OPERATION', 'Downloads need the panel connection');
      const site = await siteContext(ctx, params);
      const hash = createHash('sha256');
      let offset = 0;
      let size = null;
      let reported = 0;
      for (;;) {
        const piece = await site.files({ action: 'readRange', path: rel, offset, length: DOWNLOAD_CHUNK_BYTES });
        // The size when the download started; a file that grows meanwhile is cut there.
        if (size === null) {
          size = piece.size;
          if (size > maxBytes) throw new OperationError('FILE_TOO_LARGE', `This file is ${gb(size)}; downloads go up to ${gb(maxBytes)}`);
          ctx.log('stdout', `Sending ${rel} (${gb(size)}) to the panel`);
        }
        let bytes = Buffer.from(piece.data, 'base64');
        if (offset + bytes.length > size) bytes = bytes.subarray(0, size - offset);
        const final = offset + bytes.length >= size || bytes.length === 0;
        hash.update(bytes);
        await ctx.panel.uploadDownloadChunk(params.downloadId, { offset, data: bytes.toString('base64'), final });
        offset += bytes.length;
        if (offset - reported >= 50 * 1024 * 1024 || final) {
          ctx.log('stdout', `Sent ${gb(offset)} of ${gb(size)}`);
          reported = offset;
        }
        if (final) break;
      }
      if (offset < size) throw new OperationError('FILE_CHANGED', 'The file got smaller while it was being read. Try again.');
      return { output: { path: rel, size: offset, sha256: hash.digest('hex') } };
    },
  },

  // Permissions as an octal mode such as 755 (no setuid, setgid or sticky).
  FILE_CHMOD: fileOperation(
    ['path', 'mode', 'recursive', 'fileMode'],
    (p) => {
      const recursive = p.recursive ?? false;
      if (typeof recursive !== 'boolean') throw new OperationError('INVALID_PARAMS', 'recursive must be true or false');
      if (typeof p.mode !== 'string' || !MODE.test(p.mode)) throw new OperationError('INVALID_PARAMS', 'mode must be three digits from 0 to 7, such as 755');
      if (recursive && (typeof p.fileMode !== 'string' || !MODE.test(p.fileMode))) throw new OperationError('INVALID_PARAMS', 'fileMode must be three digits from 0 to 7, such as 644');
      if (!recursive && p.fileMode !== undefined) throw new OperationError('INVALID_PARAMS', 'fileMode is only used with recursive');
      return { action: 'chmod', path: checkPath(p.path, 'path'), mode: parseInt(p.mode, 8), recursive, ...(recursive ? { fileMode: parseInt(p.fileMode, 8) } : {}) };
    },
    (p) => `Setting permissions of ${p.path} to ${p.mode}${p.recursive ? ` (folders inside ${p.mode}, files ${p.fileMode})` : ''}`,
  ),
};

export const FILE_OPERATIONS = {
  ...ARCHIVE_OPERATIONS,
  ...TRANSFER_OPERATIONS,
  FILE_LIST: fileOperation(['path'], (p) => ({ action: 'list', path: checkPath(p.path, 'path', { allowRoot: true }) })),
  FILE_READ: fileOperation(['path'], (p) => ({ action: 'read', path: checkPath(p.path, 'path') })),
  FILE_WRITE: fileOperation(
    ['path', 'content', 'encoding', 'overwrite'],
    (p) => {
      const encoding = p.encoding ?? 'utf8';
      if (!['utf8', 'base64'].includes(encoding)) throw new OperationError('INVALID_PARAMS', 'encoding must be utf8 or base64');
      const content = p.content ?? '';
      if (typeof content !== 'string' || content.length > Math.ceil(MAX_FILE_BYTES / 3) * 4) {
        throw new OperationError('FILE_TOO_LARGE', `Files up to ${MAX_FILE_BYTES} bytes can be saved here`);
      }
      const overwrite = p.overwrite ?? true;
      if (typeof overwrite !== 'boolean') throw new OperationError('INVALID_PARAMS', 'overwrite must be true or false');
      return { action: 'write', path: checkPath(p.path, 'path'), content, encoding, overwrite };
    },
    (p) => `Saving ${p.path}`,
  ),
  FILE_MKDIR: fileOperation(['path'], (p) => ({ action: 'mkdir', path: checkPath(p.path, 'path') }), (p) => `Creating folder ${p.path}`),
  FILE_RENAME: fileOperation(
    ['from', 'to'],
    (p) => ({ action: 'rename', from: checkPath(p.from, 'from'), to: checkPath(p.to, 'to') }),
    (p) => `Moving ${p.from} to ${p.to}`,
  ),
  FILE_DELETE: fileOperation(['path'], (p) => ({ action: 'delete', path: checkPath(p.path, 'path') }), (p) => `Deleting ${p.path}`),
};
