import path from 'node:path';
import { createPrivateKey, createPublicKey, generateKeyPairSync } from 'node:crypto';
import { chmod, chown, lstat, mkdir, readdir, readFile, rm } from 'node:fs/promises';
import { detectMail, findBinary, MAIL_MANAGED_MARK, mailPaths } from '../monitoring/web.js';
import {
  MAIL_ADDRESS_PATTERN,
  MAIL_DKIM_SELECTOR_PATTERN,
  MAIL_FIREWALL_PORTS,
  MAIL_PASSWORD_HASH_PATTERN,
  MAIL_QUOTA_MB,
  MAX_FORWARDER_DESTINATIONS,
  MAX_MAIL_DOMAINS,
  MAX_MAIL_FORWARDERS,
  MAX_MAILBOXES,
} from '../security/mailRules.js';
import { DOMAIN_PATTERN } from '../security/webRules.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';
import { allowServicePorts } from './firewall.js';
import { lookup, writeFileAtomic } from './sites.js';
import { aptInstall } from './webStack.js';

// Email hosting: Postfix receives mail from the internet and sends mail for
// signed-in users, Dovecot keeps the mailboxes (IMAP and POP3, TLS only) and
// OpenDKIM signs what leaves the server.
//
// Mailboxes are virtual: they are not Linux accounts. Mail lives in
// <mailRoot>/<domain>/<name>/Maildir, owned by one "vmail" account. The panel
// sends every domain, mailbox and forwarder of the server each time (with
// password hashes only, never passwords); the agent checks them again and
// rewrites Postfix's lookup tables, Dovecot's user list and OpenDKIM's key
// tables from them. An older change never replaces a newer one.

const PACKAGES = ['postfix', 'dovecot-imapd', 'dovecot-pop3d', 'dovecot-lmtpd', 'opendkim', 'openssl'];
const BINARIES = ['postfix', 'postconf', 'postmap', 'dovecot', 'doveconf', 'opendkim', 'openssl'];
const VMAIL = 'vmail';
const MARK = MAIL_MANAGED_MARK;
const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const exists = (p) => lstat(p).then(() => true, () => false);
// The kernel lists IPv6 addresses here only when IPv6 is enabled; listening
// on :: fails without it.
const ipv6Available = (policy) => exists(policy.ipv6ProcFile ?? '/proc/net/if_inet6');

function requireAllowed(policy) {
  if (policy.allowMail === false) throw new OperationError('NOT_ALLOWED', 'Email hosting is disabled in this agent config');
}

function checkHostname(hostname) {
  if (typeof hostname !== 'string' || !DOMAIN_PATTERN.test(hostname)) throw invalid('hostname must be a host name such as mail.example.com');
  return hostname;
}

// ---- Checking what the panel sent ---------------------------------------------

export function checkMailState(params) {
  onlyKeys(params, ['hostname', 'serial', 'domains', 'mailboxes', 'forwarders', 'purge']);
  const { serial, domains, mailboxes, forwarders, purge = [] } = params;
  const hostname = checkHostname(params.hostname);
  if (!Number.isSafeInteger(serial) || serial < 1) throw invalid('serial must be a positive number');
  const list = (value, name, max) => {
    if (!Array.isArray(value) || value.length > max) throw invalid(`${name} must list at most ${max} items`);
    value.forEach((item, i) => {
      if (!item || typeof item !== 'object' || Array.isArray(item)) throw invalid(`${name}[${i}] must be an object`);
    });
    return value;
  };

  const domainNames = new Set();
  for (const [i, d] of list(domains, 'domains', MAX_MAIL_DOMAINS).entries()) {
    onlyKeys(d, ['domain', 'selector']);
    if (typeof d.domain !== 'string' || !DOMAIN_PATTERN.test(d.domain)) throw invalid(`domains[${i}]: domain must be a domain name`);
    if (typeof d.selector !== 'string' || !MAIL_DKIM_SELECTOR_PATTERN.test(d.selector)) throw invalid(`domains[${i}]: selector must be lower-case letters and digits`);
    if (domainNames.has(d.domain)) throw invalid(`${d.domain} is listed twice`);
    domainNames.add(d.domain);
  }
  const domainOf = (address) => address.slice(address.lastIndexOf('@') + 1);
  const addresses = new Set();
  for (const [i, m] of list(mailboxes, 'mailboxes', MAX_MAILBOXES).entries()) {
    onlyKeys(m, ['address', 'hash', 'quotaMb', 'enabled']);
    if (typeof m.address !== 'string' || !MAIL_ADDRESS_PATTERN.test(m.address)) throw invalid(`mailboxes[${i}]: address must be an email address`);
    if (!domainNames.has(domainOf(m.address))) throw invalid(`${m.address} is not in one of the server's email domains`);
    if (typeof m.hash !== 'string' || !MAIL_PASSWORD_HASH_PATTERN.test(m.hash)) throw invalid(`${m.address}: hash must be a SHA512-CRYPT hash`);
    if (!Number.isInteger(m.quotaMb) || m.quotaMb < MAIL_QUOTA_MB.min || m.quotaMb > MAIL_QUOTA_MB.max) throw invalid(`${m.address}: quotaMb is out of range`);
    if (typeof m.enabled !== 'boolean') throw invalid(`${m.address}: enabled must be true or false`);
    if (addresses.has(m.address)) throw invalid(`${m.address} is listed twice`);
    addresses.add(m.address);
  }
  for (const [i, f] of list(forwarders, 'forwarders', MAX_MAIL_FORWARDERS).entries()) {
    onlyKeys(f, ['address', 'destinations']);
    if (typeof f.address !== 'string' || !MAIL_ADDRESS_PATTERN.test(f.address)) throw invalid(`forwarders[${i}]: address must be an email address`);
    if (!domainNames.has(domainOf(f.address))) throw invalid(`${f.address} is not in one of the server's email domains`);
    if (addresses.has(f.address)) throw invalid(`${f.address} is listed twice`);
    if (!Array.isArray(f.destinations) || !f.destinations.length || f.destinations.length > MAX_FORWARDER_DESTINATIONS) {
      throw invalid(`${f.address}: destinations must list 1 to ${MAX_FORWARDER_DESTINATIONS} addresses`);
    }
    for (const to of f.destinations) if (typeof to !== 'string' || !MAIL_ADDRESS_PATTERN.test(to)) throw invalid(`${f.address}: every destination must be an email address`);
    addresses.add(f.address);
  }
  if (!Array.isArray(purge) || purge.length > MAX_MAILBOXES) throw invalid('purge must be a list');
  for (const p of purge) if (typeof p !== 'string' || !(MAIL_ADDRESS_PATTERN.test(p) || DOMAIN_PATTERN.test(p))) throw invalid('purge must list addresses or domains');
  return { hostname, serial, domains, mailboxes, forwarders, purge };
}

// ---- Files written from the state -------------------------------------------

export function renderMaps({ domains, mailboxes, forwarders }) {
  const head = (what) => `${MARK}: ${what}. Rewritten whenever email changes in the panel.`;
  const local = (address) => address.slice(0, address.lastIndexOf('@'));
  const domainOf = (address) => address.slice(address.lastIndexOf('@') + 1);
  return {
    domains: [head('the email domains of this server'), ...domains.map((d) => `${d.domain}\tOK`), ''].join('\n'),
    mailboxes: [head('the mailboxes'), ...mailboxes.map((m) => `${m.address}\t${domainOf(m.address)}/${local(m.address)}/Maildir/`), ''].join('\n'),
    forwarders: [head('the forwarders'), ...forwarders.map((f) => `${f.address}\t${f.destinations.join(',')}`), ''].join('\n'),
    // Who may send as an address once signed in: a mailbox as itself only.
    senders: [head('which signed-in user may send as each address'), ...mailboxes.filter((m) => m.enabled).map((m) => `${m.address}\t${m.address}`), ''].join('\n'),
  };
}

// Dovecot's passwd-file: address, password hash, then extra fields (the
// size limit, named differently since Dovecot 2.4).
export function renderUsers(mailboxes, dovecot = '2.3') {
  const quota = (mb) => (dovecot === '2.4' ? `userdb_quota_storage_size=${mb}M` : `userdb_quota_rule=*:storage=${mb}M`);
  return [
    `${MARK}: the mailboxes and their password hashes. Rewritten whenever email changes in the panel.`,
    ...mailboxes.map((m) => `${m.address}:{SHA512-CRYPT}${m.hash}::::::${m.quotaMb > 0 ? quota(m.quotaMb) : ''}`),
    '',
  ].join('\n');
}

// Mailboxes that are turned off: they still receive mail, but nobody can
// sign in to them, to read mail or to send.
export function renderDenied(mailboxes) {
  return [`${MARK}: mailboxes that are turned off.`, ...mailboxes.filter((m) => !m.enabled).map((m) => m.address), ''].join('\n');
}

// Dovecot 2.3 and 2.4 read different setting names; the version comes from
// "dovecot --version".
export function dovecotSeries(versionText) {
  const match = /^2\.([34])\./.exec((versionText ?? '').trim());
  return match ? `2.${match[1]}` : null;
}

export function renderDovecotConf({ dovecot = '2.3', ...options }) {
  return dovecot === '2.4' ? renderDovecot24Conf(options) : renderDovecot23Conf(options);
}

function renderDovecot23Conf({ hostname, paths, vmail, tls, ipv6 = true }) {
  return `${MARK}. Overwritten when the mail server is set up again from the panel.
# Mail host name: ${hostname}
protocols = imap pop3 lmtp
listen = ${ipv6 ? '*, ::' : '*'}
mail_location = maildir:${paths.mailRoot}/%d/%n/Maildir
# Only the vmail account reads and writes mail; no Linux account can sign in.
first_valid_uid = ${vmail.uid}
last_valid_uid = ${vmail.uid}
first_valid_gid = ${vmail.gid}
last_valid_gid = ${vmail.gid}
disable_plaintext_auth = yes
auth_mechanisms = plain login
auth_username_format = %Lu
ssl = required
ssl_cert = <${tls.cert}
ssl_key = <${tls.key}
ssl_min_protocol = TLSv1.2
ssl_prefer_server_ciphers = yes
recipient_delimiter = +
lmtp_save_to_detail_mailbox = no

passdb {
  driver = passwd-file
  deny = yes
  args = username_format=%Lu ${paths.dovecotDenied}
}
passdb {
  driver = passwd-file
  args = scheme=SHA512-CRYPT username_format=%Lu ${paths.dovecotUsers}
}
userdb {
  driver = passwd-file
  args = username_format=%Lu ${paths.dovecotUsers}
  default_fields = uid=${VMAIL} gid=${VMAIL} home=${paths.mailRoot}/%d/%n
}

mail_plugins = $mail_plugins quota
protocol imap {
  mail_plugins = $mail_plugins imap_quota
}
protocol lmtp {
  postmaster_address = postmaster@${hostname}
}
plugin {
  quota = maildir:Mailbox
  quota_exceeded_message = The mailbox is full.
}

# Postfix hands mail over and checks passwords through these sockets.
service lmtp {
  unix_listener /var/spool/postfix/private/dovecot-lmtp {
    mode = 0600
    user = postfix
    group = postfix
  }
}
service auth {
  unix_listener /var/spool/postfix/private/auth {
    mode = 0660
    user = postfix
    group = postfix
  }
}
# Mail clients connect with TLS from the start (993 and 995) only.
service imap-login {
  inet_listener imap {
    port = 0
  }
}
service pop3-login {
  inet_listener pop3 {
    port = 0
  }
}

namespace inbox {
  mailbox Drafts {
    auto = subscribe
    special_use = \\Drafts
  }
  mailbox Sent {
    auto = subscribe
    special_use = \\Sent
  }
  mailbox Junk {
    auto = subscribe
    special_use = \\Junk
  }
  mailbox Trash {
    auto = subscribe
    special_use = \\Trash
  }
}
`;
}

// The same settings in Dovecot 2.4's names (Ubuntu 25.04 and later, Debian 13).
function renderDovecot24Conf({ hostname, paths, vmail, tls, ipv6 = true }) {
  const home = `${paths.mailRoot}/%{user | domain}/%{user | username}`;
  return `${MARK}. Overwritten when the mail server is set up again from the panel.
# Mail host name: ${hostname}
protocols = imap pop3 lmtp
listen = ${ipv6 ? '*, ::' : '*'}
mail_driver = maildir
mail_home = ${home}
mail_path = ~/Maildir
# INBOX at the top of the Maildir, as with Dovecot 2.3 (not in .INBOX).
mail_inbox_path = ~/Maildir
mail_uid = ${VMAIL}
mail_gid = ${VMAIL}
# Only the vmail account reads and writes mail; no Linux account can sign in.
first_valid_uid = ${vmail.uid}
last_valid_uid = ${vmail.uid}
first_valid_gid = ${vmail.gid}
last_valid_gid = ${vmail.gid}
auth_allow_cleartext = no
auth_mechanisms = plain login
# Addresses are matched in lower case (Dovecot 2.4's default auth_username_format).
ssl = required
ssl_server_cert_file = ${tls.cert}
ssl_server_key_file = ${tls.key}
ssl_min_protocol = TLSv1.2
ssl_server_prefer_ciphers = server
recipient_delimiter = +
lmtp_save_to_detail_mailbox = no

passdb vaultpanel-denied {
  driver = passwd-file
  passwd_file_path = ${paths.dovecotDenied}
  deny = yes
}
passdb vaultpanel-users {
  driver = passwd-file
  passwd_file_path = ${paths.dovecotUsers}
  default_password_scheme = SHA512-CRYPT
}
userdb vaultpanel-users {
  driver = passwd-file
  passwd_file_path = ${paths.dovecotUsers}
}

mail_plugins {
  quota = yes
}
protocol imap {
  mail_plugins {
    imap_quota = yes
  }
}
protocol lmtp {
  postmaster_address = postmaster@${hostname}
  # Ubuntu's 20-lmtp.conf drops the domain here; mailboxes are full addresses.
  auth_username_format = %{user | lower}
}
quota "Mailbox" {
  driver = maildir
}
quota_exceeded_message = The mailbox is full.

# Postfix hands mail over and checks passwords through these sockets.
service lmtp {
  unix_listener /var/spool/postfix/private/dovecot-lmtp {
    mode = 0600
    user = postfix
    group = postfix
  }
}
service auth {
  unix_listener /var/spool/postfix/private/auth {
    mode = 0660
    user = postfix
    group = postfix
  }
}
# Mail clients connect with TLS from the start (993 and 995) only.
service imap-login {
  inet_listener imap {
    port = 0
  }
}
service pop3-login {
  inet_listener pop3 {
    port = 0
  }
}

namespace inbox {
  inbox = yes
  mailbox Drafts {
    auto = subscribe
    special_use = \\Drafts
  }
  mailbox Sent {
    auto = subscribe
    special_use = \\Sent
  }
  mailbox Junk {
    auto = subscribe
    special_use = \\Junk
  }
  mailbox Trash {
    auto = subscribe
    special_use = \\Trash
  }
}
`;
}

export function renderOpendkimConf(paths) {
  return `${MARK}. Overwritten when the mail server is set up again from the panel.
# The file it replaced is kept as opendkim.conf.vaultpanel-orig.
Syslog			yes
SyslogSuccess		yes
Canonicalization	relaxed/simple
OversignHeaders		From
Mode			sv
UserID			opendkim
UMask			007
Socket			inet:8891@127.0.0.1
PidFile			/run/opendkim/opendkim.pid
TrustAnchorFile		/usr/share/dns/root.key
KeyTable		file:${paths.keyTable}
SigningTable		refile:${paths.signingTable}
ExternalIgnoreList	refile:${paths.trustedHosts}
InternalHosts		refile:${paths.trustedHosts}
# Mail sent by signed-in users (ports 587 and 465) is signed.
MTA			ORIGINATING
`;
}

// Postfix's main.cf settings, set with postconf (one argument each).
export function postfixSettings({ hostname, paths, tls, ipv6 = true }) {
  const map = (file) => `hash:${file}`;
  return [
    `myhostname=${hostname}`,
    'mydestination=localhost',
    // Only the server itself relays without signing in (apps sending mail).
    `mynetworks=127.0.0.0/8${ipv6 ? ' [::1]/128' : ''}`,
    'inet_interfaces=all',
    `inet_protocols=${ipv6 ? 'all' : 'ipv4'}`,
    'smtpd_banner=$myhostname ESMTP',
    'biff=no',
    'append_dot_mydomain=no',
    'disable_vrfy_command=yes',
    'smtpd_helo_required=yes',
    `smtpd_tls_cert_file=${tls.cert}`,
    `smtpd_tls_key_file=${tls.key}`,
    'smtpd_tls_security_level=may',
    'smtpd_tls_auth_only=yes',
    'smtpd_tls_protocols=>=TLSv1.2',
    'smtpd_tls_mandatory_protocols=>=TLSv1.2',
    'smtp_tls_security_level=may',
    'smtpd_sasl_type=dovecot',
    'smtpd_sasl_path=private/auth',
    'smtpd_sasl_auth_enable=no',
    'smtpd_relay_restrictions=permit_mynetworks,permit_sasl_authenticated,defer_unauth_destination',
    `smtpd_sender_login_maps=${map(path.join(paths.postfixMaps, 'senders'))}`,
    `virtual_mailbox_domains=${map(paths.domainsMap)}`,
    `virtual_mailbox_maps=${map(paths.mailboxesMap)}`,
    `virtual_alias_maps=${map(paths.forwardersMap)}`,
    'virtual_transport=lmtp:unix:private/dovecot-lmtp',
    'mailbox_size_limit=0',
    'message_size_limit=52428800',
    'recipient_delimiter=+',
    'milter_default_action=accept',
    'milter_protocol=6',
    'smtpd_milters=inet:127.0.0.1:8891',
    'non_smtpd_milters=$smtpd_milters',
  ];
}

// The ports for mail clients in master.cf: 587 (STARTTLS) and 465 (TLS).
// Both need a signed-in user, who may send only as their own address.
export function postfixServices() {
  const common = [
    'smtpd_sasl_auth_enable=yes',
    'smtpd_client_restrictions=permit_sasl_authenticated,reject',
    'smtpd_sender_restrictions=reject_sender_login_mismatch',
    'smtpd_relay_restrictions=permit_sasl_authenticated,reject',
    'milter_macro_daemon_name=ORIGINATING',
  ];
  return [
    { entry: 'submission/inet=submission inet n - y - - smtpd', params: ['syslog_name=postfix/submission', 'smtpd_tls_security_level=encrypt', ...common].map((p) => `submission/inet/${p}`) },
    { entry: 'smtps/inet=smtps inet n - y - - smtpd', params: ['syslog_name=postfix/smtps', 'smtpd_tls_wrappermode=yes', ...common].map((p) => `smtps/inet/${p}`) },
  ];
}

const RENEW_HOOK = `#!/bin/sh
${MARK}: reloads the mail server after Certbot renews its certificate.
systemctl reload postfix.service dovecot.service >/dev/null 2>&1 || true
`;

// ---- Steps --------------------------------------------------------------------

async function vmailAccount(ctx, paths) {
  let account = await lookup(ctx, VMAIL);
  if (!account) {
    ctx.log('stdout', `$ useradd ${VMAIL}`);
    assertCommandOk(
      await ctx.run('useradd', ['--system', '--user-group', '--home-dir', paths.mailRoot, '--no-create-home', '--shell', '/usr/sbin/nologin', VMAIL], { timeoutMs: 30_000 }),
      'useradd',
    );
    account = await lookup(ctx, VMAIL);
  }
  if (!account || account.uid === 0) throw new OperationError('COMMAND_FAILED', `The ${VMAIL} account could not be created`);
  await mkdir(paths.mailRoot, { recursive: true, mode: 0o770 });
  await (ctx.chown ?? chown)(paths.mailRoot, account.uid, account.gid);
  await chmod(paths.mailRoot, 0o770);
  return account;
}

// A certificate from Let's Encrypt for the host name when there is one (a
// website for the host name with SSL), otherwise one made here.
async function certificate(ctx, paths, hostname) {
  const live = path.join(paths.letsencryptDir, 'live', hostname);
  if ((await exists(path.join(live, 'fullchain.pem'))) && (await exists(path.join(live, 'privkey.pem')))) {
    ctx.log('stdout', `Using the Let's Encrypt certificate for ${hostname}`);
    if (await exists(paths.letsencryptDir)) await writeFileAtomic(paths.renewHook, RENEW_HOOK, 0o755);
    return { kind: 'letsencrypt', cert: path.join(live, 'fullchain.pem'), key: path.join(live, 'privkey.pem') };
  }
  await mkdir(paths.tlsDir, { recursive: true, mode: 0o700 });
  const cert = path.join(paths.tlsDir, `${hostname}.crt`);
  const key = path.join(paths.tlsDir, `${hostname}.key`);
  if (!(await exists(cert)) || !(await exists(key))) {
    ctx.log('stdout', `$ openssl req -x509 (a certificate made on this server for ${hostname})`);
    assertCommandOk(
      await ctx.run('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-sha256', '-days', '3650', '-subj', `/CN=${hostname}`, '-addext', `subjectAltName=DNS:${hostname}`, '-keyout', key, '-out', cert], {
        timeoutMs: 60_000,
      }),
      'openssl req',
    );
    await chmod(key, 0o600);
  }
  ctx.log('stderr', `No Let's Encrypt certificate for ${hostname} yet: mail clients will warn about the server's own certificate. Add a website for ${hostname}, issue its SSL certificate, then set up the mail server again.`);
  return { kind: 'self-signed', cert, key };
}

async function postconf(ctx, args, what) {
  assertCommandOk(await ctx.run('postconf', args, { timeoutMs: 30_000 }), what);
}

async function postmap(ctx, file) {
  assertCommandOk(await ctx.run('postmap', [`hash:${file}`], { timeoutMs: 60_000 }), `postmap ${path.basename(file)}`);
}

// Turns off Dovecot's sign-in with Linux accounts (PAM): mailboxes are the
// only accounts. The line is commented out, never deleted.
async function disableSystemAuth(paths) {
  const text = await readFile(paths.dovecotAuth, 'utf8').catch(() => null);
  if (text === null) return;
  const next = text.replace(/^!include auth-system\.conf\.ext\s*$/m, '#!include auth-system.conf.ext # turned off by VaultPanel: only mailboxes sign in');
  if (next !== text) await writeFileAtomic(paths.dovecotAuth, next);
}

async function writeOwned(ctx, file, content, mode, owner) {
  await writeFileAtomic(file, content, mode);
  if (owner) await (ctx.chown ?? chown)(file, owner.uid, owner.gid);
}

async function lastLines(result) {
  return (result.stdout || result.stderr || result.error?.message || '').trim().split('\n').slice(-6).join('\n');
}

async function restart(ctx, unit) {
  ctx.log('stdout', `$ systemctl enable --now ${unit} && systemctl restart ${unit}`);
  await ctx.run('systemctl', ['enable', `${unit}.service`], { timeoutMs: 30_000 });
  const result = await ctx.run('systemctl', ['restart', `${unit}.service`], { timeoutMs: 90_000 });
  const active = await ctx.run('systemctl', ['is-active', '--quiet', `${unit}.service`], { timeoutMs: 15_000 });
  if (result.exitCode !== 0 || active.exitCode !== 0) {
    const log = await ctx.run('journalctl', [`--unit=${unit}.service`, '--lines=8', '--no-pager', '--output=cat', '--quiet'], { timeoutMs: 15_000 });
    throw new OperationError('MAIL_NOT_RUNNING', `${unit} did not start.\n${(log.stdout ?? '').trim()}`);
  }
}

async function reloadUnit(ctx, unit) {
  const active = await ctx.run('systemctl', ['is-active', '--quiet', `${unit}.service`], { timeoutMs: 15_000 });
  const verb = active.exitCode === 0 ? 'reload' : 'start';
  ctx.log('stdout', `$ systemctl ${verb} ${unit}`);
  assertCommandOk(await ctx.run('systemctl', [verb, `${unit}.service`], { timeoutMs: 60_000 }), `systemctl ${verb} ${unit}`);
}

// The DKIM key of a domain: made once, kept until the domain is removed.
// Returns the public key for its DNS record.
async function dkimKey(ctx, paths, domain, selector, owner) {
  const dir = path.join(paths.dkimKeys, domain);
  const file = path.join(dir, `${selector}.private`);
  let pem = await readFile(file, 'utf8').catch(() => null);
  if (pem === null) {
    ctx.log('stdout', `Making a DKIM key for ${domain}`);
    pem = generateKeyPairSync('rsa', { modulusLength: 2048, privateKeyEncoding: { type: 'pkcs8', format: 'pem' }, publicKeyEncoding: { type: 'spki', format: 'pem' } }).privateKey;
    await mkdir(dir, { recursive: true, mode: 0o700 });
    await writeOwned(ctx, file, pem, 0o600, owner);
    if (owner) await (ctx.chown ?? chown)(dir, owner.uid, owner.gid);
  }
  const publicKey = createPublicKey(createPrivateKey(pem)).export({ type: 'spki', format: 'der' }).toString('base64');
  return { file, publicKey };
}

async function readSerial(file) {
  const text = await readFile(file, 'utf8').catch(() => null);
  return text && /^\d+$/.test(text.trim()) ? Number(text.trim()) : null;
}

// Deletes stored mail of removed mailboxes and domains, only inside the mail
// folder and never for one still in use.
async function purgeMail(ctx, paths, { purge, domains, mailboxes }) {
  const removed = [];
  const keepDomains = new Set(domains.map((d) => d.domain));
  const keepBoxes = new Set(mailboxes.map((m) => m.address));
  for (const item of purge) {
    let dir;
    if (item.includes('@')) {
      if (keepBoxes.has(item)) continue;
      const at = item.lastIndexOf('@');
      dir = path.join(paths.mailRoot, item.slice(at + 1), item.slice(0, at));
    } else {
      if (keepDomains.has(item)) continue;
      dir = path.join(paths.mailRoot, item);
    }
    if (!dir.startsWith(`${paths.mailRoot}/`)) continue;
    if (await exists(dir)) {
      await rm(dir, { recursive: true, force: true });
      ctx.log('stdout', `Deleted the stored mail of ${item}`);
    }
    removed.push(item);
  }
  return removed;
}

async function dovecotVersion(ctx) {
  const version = await ctx.run('dovecot', ['--version'], { timeoutMs: 15_000 });
  const series = dovecotSeries(version.stdout);
  if (!series) {
    throw new OperationError(
      'MAIL_UNSUPPORTED',
      `VaultPanel sets up Dovecot 2.3 and 2.4 (Ubuntu 22.04 and later, Debian 12 and 13). This server has Dovecot ${(version.stdout ?? '').trim() || 'of an unknown version'}.`,
    );
  }
  return series;
}

async function requireMailServer(ctx) {
  requireAllowed(ctx.policy);
  const state = await detectMail(ctx.policy, ctx.binDirs);
  if (!state.installed || !state.configured) {
    throw new OperationError('MAIL_NOT_SET_UP', 'The mail server is not set up on this server. Set it up from the Email page first.');
  }
  return state;
}

// Bytes in one Maildir: the total Dovecot keeps for the size limit, or the
// files themselves.
async function maildirBytes(dir) {
  const sizes = await readFile(path.join(dir, 'maildirsize'), 'utf8').catch(() => null);
  if (sizes !== null) {
    let total = 0;
    for (const line of sizes.split('\n').slice(1)) {
      const n = Number(line.trim().split(/\s+/)[0]);
      if (Number.isFinite(n)) total += n;
    }
    return Math.max(0, total);
  }
  let total = 0;
  let seen = 0;
  const walk = async (d) => {
    for (const entry of await readdir(d, { withFileTypes: true }).catch(() => [])) {
      if (++seen > 200_000) return;
      const p = path.join(d, entry.name);
      if (entry.isDirectory()) await walk(p);
      else if (entry.isFile()) total += (await lstat(p).catch(() => ({ size: 0 }))).size;
    }
  };
  await walk(dir);
  return total;
}

export const MAIL_OPERATIONS = {
  MAIL_SETUP: {
    async run(params, ctx) {
      onlyKeys(params, ['hostname']);
      const hostname = checkHostname(params.hostname);
      requireAllowed(ctx.policy);
      const paths = mailPaths(ctx.policy);
      const deadline = Date.now() + ctx.timeoutMs;
      const remaining = () => Math.max(10_000, deadline - Date.now());

      const missing = [];
      for (const binary of BINARIES) if (!(await findBinary(binary, ctx.binDirs))) missing.push(binary);
      if (missing.length) {
        if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
        // Answer Postfix's questions up front.
        const debconf = await ctx.run('debconf-set-selections', [], {
          input: `postfix postfix/main_mailer_type select Internet Site\npostfix postfix/mailname string ${hostname}\n`,
          timeoutMs: 30_000,
        });
        if (debconf.exitCode !== 0) ctx.log('stderr', 'debconf-set-selections failed; installing anyway');
        await aptInstall(ctx, PACKAGES, remaining);
      } else {
        ctx.log('stdout', 'Postfix, Dovecot and OpenDKIM are installed; updating their VaultPanel settings');
      }

      const dovecot = await dovecotVersion(ctx);

      const vmail = await vmailAccount(ctx, paths);
      const dovecotUser = await lookup(ctx, 'dovecot');
      const opendkimUser = await lookup(ctx, 'opendkim');
      const tls = await certificate(ctx, paths, hostname);
      const ipv6 = await ipv6Available(ctx.policy);

      // Lookup tables: kept when they exist (the panel rewrites them next).
      await mkdir(paths.postfixMaps, { recursive: true, mode: 0o755 });
      const empty = renderMaps({ domains: [], mailboxes: [], forwarders: [] });
      for (const [name, file] of [['domains', paths.domainsMap], ['mailboxes', paths.mailboxesMap], ['forwarders', paths.forwardersMap], ['senders', path.join(paths.postfixMaps, 'senders')]]) {
        if (!(await exists(file))) await writeFileAtomic(file, empty[name]);
        await postmap(ctx, file);
      }

      ctx.log('stdout', '$ postconf -e (VaultPanel mail settings)');
      await postconf(ctx, ['-e', ...postfixSettings({ hostname, paths, tls, ipv6 })], 'postconf -e');
      for (const service of postfixServices()) {
        await postconf(ctx, ['-M', service.entry], 'postconf -M');
        await postconf(ctx, ['-P', ...service.params], 'postconf -P');
      }
      const postfixCheck = await ctx.run('postfix', ['check'], { timeoutMs: 30_000 });
      if (postfixCheck.exitCode !== 0) throw new OperationError('MAIL_CONFIG_INVALID', `Postfix refused the configuration:\n${await lastLines(postfixCheck)}`);

      // Dovecot: the user list (when missing), then the settings, checked.
      if (!(await exists(paths.dovecotUsers))) {
        await mkdir(path.dirname(paths.dovecotUsers), { recursive: true, mode: 0o755 });
        await writeOwned(ctx, paths.dovecotUsers, renderUsers([], dovecot), 0o640, dovecotUser ? { uid: 0, gid: dovecotUser.gid } : null);
      }
      if (!(await exists(paths.dovecotDenied))) await writeFileAtomic(paths.dovecotDenied, renderDenied([]));
      const previousConf = await readFile(paths.dovecotConf, 'utf8').catch(() => null);
      const previousAuth = await readFile(paths.dovecotAuth, 'utf8').catch(() => null);
      await writeFileAtomic(paths.dovecotConf, renderDovecotConf({ dovecot, hostname, paths, vmail, tls, ipv6 }));
      await disableSystemAuth(paths);
      const doveconf = await ctx.run('doveconf', ['-n'], { timeoutMs: 30_000 });
      if (doveconf.exitCode !== 0) {
        if (previousConf === null) await rm(paths.dovecotConf, { force: true });
        else await writeFileAtomic(paths.dovecotConf, previousConf);
        if (previousAuth !== null) await writeFileAtomic(paths.dovecotAuth, previousAuth);
        throw new OperationError('MAIL_CONFIG_INVALID', `Dovecot refused the configuration:\n${await lastLines(doveconf)}`);
      }

      // OpenDKIM: our settings (the original kept once), tables when missing.
      const original = await readFile(paths.opendkimConf, 'utf8').catch(() => null);
      const backup = `${paths.opendkimConf}.vaultpanel-orig`;
      if (original !== null && !original.startsWith(MARK) && !(await exists(backup))) await writeFileAtomic(backup, original);
      await writeFileAtomic(paths.opendkimConf, renderOpendkimConf(paths));
      // OpenDKIM reads its tables after dropping to its own account.
      for (const dir of [path.dirname(paths.dkim), paths.dkim]) {
        await mkdir(dir, { recursive: true, mode: 0o755 });
        await chmod(dir, 0o755);
      }
      await mkdir(paths.dkimKeys, { recursive: true, mode: 0o700 });
      if (opendkimUser) await (ctx.chown ?? chown)(paths.dkimKeys, opendkimUser.uid, opendkimUser.gid);
      if (!(await exists(paths.trustedHosts))) await writeFileAtomic(paths.trustedHosts, '127.0.0.1\n::1\nlocalhost\n');
      if (!(await exists(paths.keyTable))) await writeFileAtomic(paths.keyTable, '');
      if (!(await exists(paths.signingTable))) await writeFileAtomic(paths.signingTable, '');

      for (const unit of ['opendkim', 'dovecot', 'postfix']) await restart(ctx, unit);

      let opened = false;
      try {
        opened = await allowServicePorts(ctx, MAIL_FIREWALL_PORTS, { protocol: 'tcp', comment: 'VaultPanel: email' });
      } catch (err) {
        ctx.log('stderr', `Could not open the mail ports in the firewall (${err.message}). Add a rule for TCP ${MAIL_FIREWALL_PORTS.join(', ')} on the Firewall page.`);
      }
      if (opened) ctx.log('stdout', `The firewall is on: opened ports ${MAIL_FIREWALL_PORTS.join(', ')} for email`);
      ctx.webInventory?.invalidate();
      ctx.log('stdout', `The mail server is running as ${hostname}.`);
      return { output: { mail: await detectMail(ctx.policy, ctx.binDirs), tls: tls.kind, firewallOpened: opened } };
    },
  },

  MAIL_APPLY: {
    async run(params, ctx) {
      const spec = checkMailState(params);
      const state = await requireMailServer(ctx);
      const paths = mailPaths(ctx.policy);
      if (state.hostname !== spec.hostname) ctx.log('stderr', `The mail server was set up as ${state.hostname}; the panel has ${spec.hostname}. Set it up again to change the host name.`);
      const current = await readSerial(paths.serialFile);
      if (current !== null && current > spec.serial) {
        ctx.log('stdout', `The email settings on this server are newer (change ${current}); keeping them`);
        return { output: { serial: current, skipped: true, dkim: [] } };
      }

      // DKIM keys first: a domain signs from the moment it receives mail.
      const opendkimUser = await lookup(ctx, 'opendkim');
      const dkim = [];
      for (const d of spec.domains) dkim.push({ domain: d.domain, selector: d.selector, ...(await dkimKey(ctx, paths, d.domain, d.selector, opendkimUser)) });
      await writeFileAtomic(paths.keyTable, `${dkim.map((k) => `${k.selector}._domainkey.${k.domain} ${k.domain}:${k.selector}:${k.file}`).join('\n')}\n`);
      await writeFileAtomic(paths.signingTable, `${dkim.map((k) => `*@${k.domain} ${k.selector}._domainkey.${k.domain}`).join('\n')}\n`);
      const keep = new Set(spec.domains.map((d) => d.domain));
      for (const entry of await readdir(paths.dkimKeys).catch(() => [])) {
        if (!keep.has(entry) && DOMAIN_PATTERN.test(entry)) await rm(path.join(paths.dkimKeys, entry), { recursive: true, force: true });
      }

      const maps = renderMaps(spec);
      for (const [name, file] of [['domains', paths.domainsMap], ['mailboxes', paths.mailboxesMap], ['forwarders', paths.forwardersMap], ['senders', path.join(paths.postfixMaps, 'senders')]]) {
        await writeFileAtomic(file, maps[name]);
        await postmap(ctx, file);
      }
      const dovecotUser = await lookup(ctx, 'dovecot');
      await writeFileAtomic(paths.dovecotDenied, renderDenied(spec.mailboxes));
      await writeOwned(ctx, paths.dovecotUsers, renderUsers(spec.mailboxes, await dovecotVersion(ctx)), 0o640, dovecotUser ? { uid: 0, gid: dovecotUser.gid } : null);
      await reloadUnit(ctx, 'postfix');
      await reloadUnit(ctx, 'opendkim');

      const purged = await purgeMail(ctx, paths, spec);
      await writeFileAtomic(paths.serialFile, `${spec.serial}\n`);
      ctx.log('stdout', `${spec.domains.length} domain${spec.domains.length === 1 ? '' : 's'}, ${spec.mailboxes.length} mailbox${spec.mailboxes.length === 1 ? '' : 'es'} and ${spec.forwarders.length} forwarder${spec.forwarders.length === 1 ? '' : 's'} are in place`);
      return { output: { serial: spec.serial, dkim: dkim.map(({ domain, selector, publicKey }) => ({ domain, selector, publicKey })), purged } };
    },
  },

  MAIL_USAGE: {
    async run(params, ctx) {
      onlyKeys(params, []);
      await requireMailServer(ctx);
      const paths = mailPaths(ctx.policy);
      const mailboxes = [];
      for (const domain of await readdir(paths.mailRoot).catch(() => [])) {
        if (!DOMAIN_PATTERN.test(domain)) continue;
        for (const local of await readdir(path.join(paths.mailRoot, domain)).catch(() => [])) {
          const address = `${local}@${domain}`;
          if (!MAIL_ADDRESS_PATTERN.test(address)) continue;
          mailboxes.push({ address, bytes: await maildirBytes(path.join(paths.mailRoot, domain, local, 'Maildir')) });
          if (mailboxes.length >= MAX_MAILBOXES) break;
        }
      }
      return { output: { mailboxes } };
    },
  },
};
