import { readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { appNodeDir, BIN_DIRS, findBinary, NODE_IN_HOME_MESSAGE } from '../monitoring/web.js';
import { appPaths, checkBranch, checkCommands, checkEnv, checkKeepReleases, checkReleaseId, checkRepository, renderEnvFile } from '../services/appConfig.js';
import { checkSiteName, checkSiteSpec, SITE_SPEC_KEYS, sitePaths } from '../services/siteConfig.js';
import { DOCUMENT_ROOT_PATTERN } from '../security/webRules.js';
import {
  deadlineFor,
  deployEnv,
  ensureDeployKey,
  fetchRelease,
  fileExists,
  files,
  listReleases,
  removeRelease,
  runCommands,
  stage,
  StageError,
} from './apps.js';
import { onlyKeys, OperationError } from './errors.js';
import { applyNginxConfig, checkSiteHealth, requireNginx, requireSiteAccount, requireWebsites, syncApache } from './sites.js';

// Static and PHP websites deployed from Git, like apps but with nothing to
// run: each deployment is cloned (and optionally built) into its own release
// folder, and NGINX (with PHP-FPM for PHP sites) serves "current", a link to
// the release's output folder. PHP sites get their Composer dependencies
// installed, and their variables written to the release's .env file, which
// frameworks such as Laravel and Symfony read.
//
// /var/www/<site>/
//   public/             the files served before Git deploy was turned on (kept)
//   releases/<id>/      one folder per deployment (the newest few are kept)
//   current -> releases/<id>[/<output folder>]
//   .ssh/id_ed25519     the site's deploy key for private repositories
//
// Clones, installs and builds run as the site's own user. A deployment that
// fails before the switch leaves the live release untouched; one whose site
// stops answering afterwards is switched back.

export const GIT_DOCUMENT_ROOT = 'current';
const SITE_GIT_FOLDERS = [
  { path: 'releases', mode: 0o750 },
  { path: '.ssh', mode: 0o700 },
];
const KEY_HINT = ' If the repository is private, add the site’s deploy key to it (shown on the website’s Deployments tab).';
const NODE_COMMANDS = new Set(['npm', 'npx', 'node', 'yarn', 'pnpm', 'corepack']);
const RELEASE_LINK = /^releases\/([0-9]{14}-[a-f0-9]{6})(?:\/.*)?$/;

function checkOutputDir(value) {
  if (value === undefined || value === null || value === '' || value === '.') return '';
  if (typeof value !== 'string' || !DOCUMENT_ROOT_PATTERN.test(value)) {
    throw new OperationError('INVALID_PARAMS', 'outputDir must be a folder inside the repository, such as dist');
  }
  return value;
}

// The site definition sent with a deployment: a static or PHP site serving
// "current" (PHP sites from agent 0.32.0).
function checkGitSpec(params) {
  const spec = checkSiteSpec(Object.fromEntries(SITE_SPEC_KEYS.filter((k) => k in params).map((k) => [k, params[k]])));
  if (spec.type !== 'static' && spec.type !== 'php') throw new OperationError('INVALID_PARAMS', 'Only static and PHP websites deploy from Git');
  if (spec.documentRoot !== GIT_DOCUMENT_ROOT) throw new OperationError('INVALID_PARAMS', `documentRoot must be ${GIT_DOCUMENT_ROOT} for a site deployed from Git`);
  return spec;
}

async function prepareSite(ctx, name) {
  requireWebsites(ctx.policy);
  const paths = appPaths(ctx.policy, name);
  const account = await requireSiteAccount(ctx, name, paths);
  const fs = files(ctx, account, paths.home);
  await fs({ action: 'appInit', folders: SITE_GIT_FOLDERS });
  return { paths, account, fs };
}

async function liveRelease(fs, paths) {
  const { target } = await fs({ action: 'readlink', path: paths.rel.current });
  return target ? { target, id: target.match(RELEASE_LINK)?.[1] ?? null } : null;
}

// The output folder must be a real folder inside the release, so a link in
// the repository cannot make NGINX serve something else on the server.
async function outputTarget(paths, releaseId, outputDir) {
  const releaseRel = paths.rel.release(releaseId);
  const releaseDir = path.join(paths.home, releaseRel);
  const wanted = path.join(releaseDir, outputDir);
  let real;
  try {
    real = await realpath(wanted);
  } catch {
    throw new StageError('OUTPUT_NOT_FOUND', `The output folder ${outputDir || '(the repository itself)'} does not exist after the build. Check the build command and the output folder (for example dist or build).`);
  }
  const realRelease = await realpath(releaseDir);
  if (real !== realRelease && !real.startsWith(`${realRelease}/`)) {
    throw new StageError('OUTPUT_NOT_FOUND', `The output folder ${outputDir} points outside the repository`);
  }
  return outputDir ? `${releaseRel}/${outputDir}` : releaseRel;
}

// NGINX (and Apache with .htaccess on) serve "current" once a site's first
// release is live; until then they keep serving the old document root.
async function serveCurrent(ctx, spec) {
  const paths = sitePaths(ctx.policy, spec.name);
  const config = await readFile(paths.nginxAvailable, 'utf8').catch(() => null);
  if (config?.includes(`root ${path.join(paths.home, GIT_DOCUMENT_ROOT)};`)) return false;
  ctx.log('stdout', `Serving ${path.join(paths.home, GIT_DOCUMENT_ROOT)} from now on`);
  await syncApache(ctx, spec, paths);
  await applyNginxConfig(ctx, spec, paths);
  return true;
}

// Switches "current" to a release, makes sure the web server serves it and
// asks NGINX for the front page. A site that stops answering is switched back.
async function switchAndCheck(ctx, { spec, fs, paths, target, releaseId }) {
  const previous = await liveRelease(fs, paths);
  stage('Publish', ctx);
  ctx.log('stdout', `Switching current to ${target}${previous ? ` (was ${previous.target})` : ''}`);
  await fs({ action: 'activate', path: paths.rel.current, target });
  try {
    await serveCurrent(ctx, spec);
  } catch (err) {
    if (previous) await fs({ action: 'activate', path: paths.rel.current, target: previous.target });
    throw new StageError('PUBLISH_FAILED', err.message);
  }
  stage('Health check', ctx);
  const health = await checkSiteHealth(ctx, spec);
  if (health.ok) return { previous: previous?.id ?? null, health };
  if (previous && previous.id !== releaseId) {
    ctx.log('stderr', `Switching back to ${previous.target}`);
    await fs({ action: 'activate', path: paths.rel.current, target: previous.target });
    throw new StageError('HEALTH_CHECK_FAILED', `${health.message} The previous release (${previous.id ?? previous.target}) is live again.`);
  }
  throw new StageError('HEALTH_CHECK_FAILED', health.message);
}

// Keeps the newest releases, and always the live and previous ones.
async function pruneReleases(ctx, fs, paths, keep, protect) {
  const releases = await listReleases(fs, paths);
  const newest = new Set(releases.slice(-keep));
  for (const id of releases) {
    if (newest.has(id) || protect.includes(id)) continue;
    ctx.log('stdout', `Removing old release ${id}`);
    await removeRelease(ctx, fs, paths, id);
  }
  return listReleases(fs, paths);
}

// The commands that install the build's dependencies: the site's own, or
// Composer for a PHP site with a composer.json, or npm when there is a build
// and a package.json.
async function installCommands(ctx, { installCommand, building, releaseDir, php }) {
  const custom = checkCommands(installCommand, 'installCommand');
  if (custom.length) return custom;
  const commands = [];
  if (php && (await fileExists(path.join(releaseDir, 'composer.json')))) {
    commands.push(['composer', 'install', '--no-dev', '--no-interaction', '--no-progress', '--prefer-dist', '--optimize-autoloader']);
  }
  if (php && !building) {
    if (!commands.length) ctx.log('stdout', 'No composer.json: nothing to install');
    return commands;
  }
  if (commands.length && !(await fileExists(path.join(releaseDir, 'package.json')))) return commands;
  if (!building) return [];
  if (await fileExists(path.join(releaseDir, 'package-lock.json'))) return [...commands, ['npm', 'ci', '--include=dev', '--no-audit', '--no-fund']];
  if (await fileExists(path.join(releaseDir, 'package.json'))) return [...commands, ['npm', 'install', '--include=dev', '--no-audit', '--no-fund']];
  if (!commands.length) ctx.log('stdout', 'No package.json: nothing to install');
  return commands;
}

// A PHP site's variables go into the release's .env file, where PHP
// frameworks read them at run time. Only when the site serves a folder inside
// the release (such as public), so the file is never in the web root, and
// only if the repository has no .env of its own.
async function writePhpEnv(ctx, { fs, paths, releaseId, outputDir, variables }) {
  if (!Object.keys(variables).length) return;
  const rel = `${paths.rel.release(releaseId)}/.env`;
  if (!outputDir) {
    ctx.log('stderr', 'The variables were not written to .env because the site serves the whole repository. Set the output folder (for example public) to have them written.');
    return;
  }
  if (await fileExists(path.join(paths.home, rel))) {
    ctx.log('stderr', 'The repository has its own .env file, so the site’s variables were not written to it.');
    return;
  }
  ctx.log('stdout', `Writing the site’s variables to .env (${Object.keys(variables).length})`);
  await fs({ action: 'write', path: rel, content: renderEnvFile(variables), mode: 0o600 });
}

// The site's own variables (agent 0.24.0) come first; HOME, USER and PATH
// are always VaultPanel's.
function buildEnvironment(ctx, { name, home, releaseDir, nodeDir, variables }) {
  return {
    ...deployEnv(ctx),
    ...variables,
    HOME: home,
    USER: name,
    LANG: 'C.UTF-8',
    PATH: [path.join(releaseDir, 'node_modules', '.bin'), nodeDir, '/usr/local/bin', '/usr/bin', '/bin'].filter(Boolean).join(':'),
  };
}

export const SITE_GIT_OPERATIONS = {
  // Creates the folders and the deploy key when Git deploy is turned on.
  SITE_GIT_SETUP: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      const name = checkSiteName(params.name);
      const { paths, account, fs } = await prepareSite(ctx, name);
      let deployKey = null;
      try {
        deployKey = await ensureDeployKey(ctx, account, paths, fs);
      } catch (err) {
        if (err.code !== 'SSH_NOT_INSTALLED') throw err;
        ctx.log('stderr', err.message);
      }
      ctx.log('stdout', `Ready to deploy ${name} from Git into ${path.join(paths.home, paths.rel.releases)}`);
      return { output: { name, deployKey } };
    },
  },

  DEPLOY_SITE_GIT: {
    async run(params, ctx) {
      onlyKeys(params, [...SITE_SPEC_KEYS, 'repository', 'branch', 'installCommand', 'buildCommand', 'outputDir', 'releaseId', 'keepReleases', 'env']);
      const spec = checkGitSpec(params);
      const variables = checkEnv(params.env ?? []);
      const repository = checkRepository(params.repository);
      const branch = checkBranch(params.branch);
      const releaseId = checkReleaseId(params.releaseId);
      const keep = checkKeepReleases(params.keepReleases);
      const outputDir = checkOutputDir(params.outputDir);
      const buildCommands = checkCommands(params.buildCommand, 'buildCommand');
      checkCommands(params.installCommand, 'installCommand');
      await requireNginx(ctx);
      const remaining = deadlineFor(ctx);
      const stages = [];
      const timed = async (key, fn) => {
        const started = Date.now();
        try {
          const value = await fn();
          stages.push({ stage: key, status: 'succeeded', durationMs: Date.now() - started });
          return value;
        } catch (err) {
          stages.push({ stage: key, status: 'failed', durationMs: Date.now() - started });
          throw err;
        }
      };

      stage('Prepare', ctx);
      const { paths, account, fs } = await timed('prepare', async () => {
        try {
          return await prepareSite(ctx, spec.name);
        } catch (err) {
          if (['SITE_USER_CONFLICT', 'SITE_NOT_FOUND', 'NOT_ALLOWED'].includes(err.code)) throw err;
          throw new StageError('PREPARE_FAILED', `Could not prepare the site: ${err.message}`);
        }
      });
      if (!/^https:/.test(repository)) await ensureDeployKey(ctx, account, paths, fs);
      const releaseDir = path.join(paths.home, paths.rel.release(releaseId));
      try {
        stage('Fetch', ctx);
        const commit = await timed('fetch', () => fetchRelease(ctx, { account, paths, repository, branch, releaseDir, remaining, keyHint: KEY_HINT }));

        const php = spec.type === 'php';
        const installs = await installCommands(ctx, { installCommand: params.installCommand, building: buildCommands.length > 0, releaseDir, php });
        if (installs.some(([program]) => program === 'composer') && !(await findBinary('composer', ctx.binDirs ?? BIN_DIRS))) {
          throw new StageError('INSTALL_FAILED', 'This site has a composer.json, but Composer is not installed on this server. Install it from the Software card on the server page.');
        }
        const nodeDir = appNodeDir(ctx.policy);
        if (!nodeDir && [...installs, ...buildCommands].some(([program]) => NODE_COMMANDS.has(program))) {
          throw new StageError(installs.length ? 'INSTALL_FAILED' : 'BUILD_FAILED', NODE_IN_HOME_MESSAGE);
        }
        const env = buildEnvironment(ctx, { name: spec.name, home: paths.home, releaseDir, nodeDir, variables });
        const names = Object.keys(variables);
        if (names.length) ctx.log('stdout', `Environment variables for the install and build: ${names.join(', ')}`);
        stage('Install', ctx);
        await timed('install', async () => {
          if (!installs.length) ctx.log('stdout', 'Nothing to install');
          await runCommands(ctx, account, installs, { cwd: releaseDir, env, remaining, code: 'INSTALL_FAILED', what: 'Installing dependencies' });
        });
        stage('Build', ctx);
        await timed('build', async () => {
          if (!buildCommands.length) ctx.log('stdout', 'No build command: the files are served as they are in the repository');
          await runCommands(ctx, account, buildCommands, { cwd: releaseDir, env, remaining, code: 'BUILD_FAILED', what: 'The build' });
          if (php) await writePhpEnv(ctx, { fs, paths, releaseId, outputDir, variables });
        });

        const target = await timed('publish', async () => {
          const found = await outputTarget(paths, releaseId, outputDir);
          const names = php ? ['index.php', 'index.html'] : ['index.html', 'index.htm'];
          const present = await Promise.all(names.map((f) => fileExists(path.join(paths.home, found, f))));
          if (!present.some(Boolean)) {
            ctx.log('stderr', `There is no ${names[0]} in ${outputDir || 'the repository'}, so the front page will not load. Check the output folder${php ? ' (public for Laravel and Symfony)' : ''}.`);
          }
          return found;
        });
        const outcome = await timed('health_check', () => switchAndCheck(ctx, { spec, fs, paths, target, releaseId }));
        const releases = await pruneReleases(ctx, fs, paths, keep, [releaseId, outcome.previous].filter(Boolean));
        ctx.webInventory?.invalidate();
        return { output: { releaseId, branch, outputDir, ...commit, previousRelease: outcome.previous, releases, health: outcome.health, stages } };
      } catch (err) {
        // Not live: the new folder can go (after a switch-back too).
        const live = await liveRelease(fs, paths).catch(() => null);
        if (live?.id !== releaseId) await removeRelease(ctx, fs, paths, releaseId);
        throw err;
      }
    },
  },

  ROLLBACK_SITE_GIT: {
    async run(params, ctx) {
      onlyKeys(params, [...SITE_SPEC_KEYS, 'releaseId', 'outputDir']);
      const spec = checkGitSpec(params);
      const releaseId = checkReleaseId(params.releaseId);
      const outputDir = checkOutputDir(params.outputDir);
      requireWebsites(ctx.policy);
      await requireNginx(ctx);
      const paths = appPaths(ctx.policy, spec.name);
      const account = await requireSiteAccount(ctx, spec.name, paths);
      const fs = files(ctx, account, paths.home);
      const releases = await listReleases(fs, paths);
      if (!releases.includes(releaseId)) {
        throw new OperationError('RELEASE_NOT_FOUND', `Release ${releaseId} is no longer on the server (only the newest releases are kept). Deploy again instead.`);
      }
      const target = await outputTarget(paths, releaseId, outputDir);
      const outcome = await switchAndCheck(ctx, { spec, fs, paths, target, releaseId });
      ctx.webInventory?.invalidate();
      return { output: { releaseId, previousRelease: outcome.previous, releases, health: outcome.health } };
    },
  },
};
