import { access } from 'node:fs/promises';
import { BIN_DIRS, findBinary } from '../monitoring/web.js';
import {
  CONTAINER_COMMAND_PATTERN,
  CONTAINER_CPU_PERCENT,
  CONTAINER_HEALTH_SECONDS,
  CONTAINER_ID_PATTERN,
  CONTAINER_LABELS,
  CONTAINER_MEMORY_MB,
  CONTAINER_NAME_PATTERN,
  CONTAINER_NETWORK,
  dockerVolumeName,
  IMAGE_ID_PATTERN,
  IMAGE_REF_PATTERN,
  MANAGED_ID_PATTERN,
  MAX_CONTAINER_COMMAND_ARGS,
  MAX_CONTAINER_COMMAND_LENGTH,
  MAX_CONTAINER_PORTS,
  MAX_CONTAINER_VOLUMES,
  MAX_IMAGE_REF_LENGTH,
  parsePortMapping,
  parseVolumeMapping,
  RESTART_POLICY_KEYS,
} from '../security/containerRules.js';
import { ENV_KEY_PATTERN, MAX_ENV_VALUE_LENGTH, MAX_ENV_VARS } from '../security/appRules.js';
import { createDockerClient, DockerError, findDockerSocket, logLines } from '../services/dockerClient.js';
import { onlyKeys, OperationError } from './errors.js';
import { APT_ENV, aptInstall } from './webStack.js';

// Docker containers (phase 10), through the Docker Engine API on its socket.
//
// Containers VaultPanel deploys carry its labels and are built only from the
// fields of CONTAINER_DEPLOY: never privileged, never on the host's network,
// no added capabilities or devices, no folder of the host mounted inside
// (data lives in Docker volumes named vp-<container>-<volume>), and with
// no-new-privileges and capped log files. Containers VaultPanel did not
// deploy can be listed, started, stopped, restarted, read and removed.
//
// Containers VaultPanel itself depends on (its own MariaDB and Redis, when
// they run in Docker on this server) are protected: the panel sends the host
// ports they publish, and they may also carry the io.vaultpanel.protected
// label. The agent refuses to stop, restart or remove them.

const SNAP_BIN_DIR = '/snap/bin';
const PREVIOUS_SUFFIX = '-vp-previous';
const STOP_SECONDS = 20;
// Docker's progress lines that only move a progress bar.
const QUIET_PULL_STATUSES = new Set(['Downloading', 'Extracting', 'Waiting', 'Verifying Checksum']);

function requireAllowed(policy) {
  if (policy.allowContainers === false) throw new OperationError('NOT_ALLOWED', 'Container management is disabled in this agent config');
}

// What is installed and whether the daemon answers.
export async function detectDocker(ctx) {
  const dirs = ctx.binDirs ?? BIN_DIRS;
  const snapDir = ctx.snapBinDir ?? SNAP_BIN_DIR;
  const [client, daemon, snap] = await Promise.all([findBinary('docker', dirs), findBinary('dockerd', dirs), exists(`${snapDir}/docker`)]);
  const source = snap ? 'snap' : client || daemon ? 'package' : null;
  const status = {
    installed: Boolean(source),
    source,
    // The systemd unit that runs the daemon.
    service: source === 'snap' ? 'snap.docker.dockerd' : source ? 'docker' : null,
    running: false,
    version: null,
    apiVersion: null,
  };
  const docker = await clientFor(ctx);
  if (!docker) return status;
  try {
    const version = await docker.version();
    status.running = true;
    status.installed = true;
    status.version = version.Version ?? null;
    status.apiVersion = version.ApiVersion ?? null;
  } catch {
    // not running
  }
  return status;
}

async function clientFor(ctx) {
  if (ctx.docker !== undefined) return ctx.docker;
  const socketPath = await findDockerSocket(ctx.policy);
  return socketPath ? createDockerClient({ socketPath }) : null;
}

// A client for a running Docker, or an error saying what to do.
async function dockerFor(ctx) {
  requireAllowed(ctx.policy);
  const docker = await clientFor(ctx);
  if (docker) {
    try {
      await docker.ping();
      return docker;
    } catch {
      // explained below
    }
  }
  const status = await detectDocker({ ...ctx, docker: null });
  if (!status.installed) throw new OperationError('DOCKER_NOT_INSTALLED', 'Docker is not installed on this server. Install it from the Containers page.');
  throw new OperationError(
    'DOCKER_NOT_RUNNING',
    status.source === 'snap'
      ? 'Docker (the snap) is installed but not running. Start it from the Containers page, or run: snap start --enable docker'
      : 'Docker is installed but not running. Start it from the Containers page, or run: systemctl enable --now docker',
  );
}

// Turns Docker's errors into the agent's.
async function docker$(promise, what) {
  try {
    return await promise;
  } catch (err) {
    if (err instanceof DockerError) {
      const code = err.code === 'NOT_FOUND' ? 'NOT_FOUND' : err.code === 'CONFLICT' ? 'CONFLICT' : err.code;
      throw new OperationError(code, `${what}: ${err.message}`);
    }
    throw err;
  }
}

async function exists(file) {
  try {
    await access(file);
    return true;
  } catch {
    return false;
  }
}

// ---- Reading -------------------------------------------------------------

const labelsOf = (labels) => labels ?? {};

function publishedPorts(ports) {
  const seen = new Set();
  const out = [];
  for (const p of ports ?? []) {
    if (!p.PublicPort) continue;
    // Docker lists a port once for IPv4 and once for IPv6.
    const address = p.IP === '::' ? '0.0.0.0' : p.IP === '::1' ? '127.0.0.1' : p.IP;
    const key = `${address}:${p.PublicPort}:${p.PrivatePort}/${p.Type}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ address, hostPort: p.PublicPort, containerPort: p.PrivatePort, protocol: p.Type });
  }
  return out;
}

function inspectPorts(info) {
  const out = [];
  for (const [spec, bindings] of Object.entries(info.HostConfig?.PortBindings ?? {})) {
    const [containerPort, protocol = 'tcp'] = spec.split('/');
    for (const b of bindings ?? []) {
      out.push({ address: b.HostIp || '0.0.0.0', hostPort: Number(b.HostPort), containerPort: Number(containerPort), protocol });
    }
  }
  return out;
}

const isProtected = (labels, ports, protectedPorts = []) =>
  labels[CONTAINER_LABELS.protected] === 'true' || ports.some((p) => protectedPorts.includes(p.hostPort));

const managedIdOf = (labels) => (labels[CONTAINER_LABELS.managed] === 'true' ? (labels[CONTAINER_LABELS.id] ?? null) : null);

// One container as the list shows it.
export function summarizeContainer(c, protectedPorts = []) {
  const labels = labelsOf(c.Labels);
  const ports = publishedPorts(c.Ports);
  return {
    id: c.Id,
    name: (c.Names?.[0] ?? '').replace(/^\//, ''),
    image: c.Image,
    imageId: c.ImageID ?? null,
    state: c.State,
    status: c.Status ?? null,
    createdAt: c.Created ? new Date(c.Created * 1000).toISOString() : null,
    ports,
    managedId: managedIdOf(labels),
    protected: isProtected(labels, ports, protectedPorts),
    compose: labels['com.docker.compose.project'] ? { project: labels['com.docker.compose.project'], service: labels['com.docker.compose.service'] ?? null } : null,
  };
}

// What the heartbeat reports: Docker's state and a short line per container.
export async function readDockerSummary(policy, ctx = {}) {
  if (policy.allowContainers === false) return null;
  const status = await detectDocker({ policy, ...ctx });
  if (!status.running) return { ...status, containers: [] };
  const docker = await clientFor({ policy, ...ctx });
  try {
    const list = await docker.listContainers();
    return {
      ...status,
      containers: list.slice(0, 300).map((c) => {
        const s = summarizeContainer(c);
        return { id: s.id.slice(0, 12), name: s.name, image: s.image.slice(0, 255), state: s.state, status: s.status, managedId: s.managedId, hostPorts: [...new Set(s.ports.map((p) => p.hostPort))], protected: s.protected };
      }),
    };
  } catch {
    return { ...status, containers: [] };
  }
}

function checkProtectedPorts(params) {
  const ports = params.protectedPorts ?? [];
  if (!Array.isArray(ports) || ports.length > 10 || ports.some((p) => !Number.isInteger(p) || p < 1 || p > 65535)) {
    throw new OperationError('INVALID_PARAMS', 'protectedPorts must list up to 10 ports');
  }
  return ports;
}

function checkRef(ref) {
  if (typeof ref !== 'string' || ref.length > 64 || !(CONTAINER_ID_PATTERN.test(ref) || CONTAINER_NAME_PATTERN.test(ref))) {
    throw new OperationError('INVALID_PARAMS', 'container must be a container ID or name');
  }
  return ref;
}

async function findContainer(docker, ref) {
  try {
    return await docker.inspectContainer(ref);
  } catch (err) {
    if (err instanceof DockerError && err.code === 'NOT_FOUND') return null;
    throw err instanceof DockerError ? new OperationError(err.code, err.message) : err;
  }
}

async function requireContainer(docker, ref) {
  const info = await findContainer(docker, ref);
  if (!info) throw new OperationError('CONTAINER_NOT_FOUND', `There is no container ${ref} on this server`);
  return info;
}

const nameOf = (info) => (info.Name ?? '').replace(/^\//, '');

function refuseProtected(info, protectedPorts, verb) {
  if (isProtected(labelsOf(info.Config?.Labels), inspectPorts(info), protectedPorts)) {
    throw new OperationError('PROTECTED_CONTAINER', `${nameOf(info)} runs part of VaultPanel itself (its database or Redis), so the agent will not ${verb} it`);
  }
}

// Recent output, for error messages.
async function tailOf(docker, info, lines = 20) {
  try {
    return logLines(await docker.logs(info.Id, { tail: lines, timestamps: false }), Boolean(info.Config?.Tty)).map((l) => l.message);
  } catch {
    return [];
  }
}

function stateOf(info) {
  const s = info.State ?? {};
  return {
    status: s.Status ?? null,
    running: Boolean(s.Running),
    restarting: Boolean(s.Restarting),
    exitCode: s.ExitCode ?? null,
    error: s.Error || null,
    health: s.Health?.Status ?? null,
    startedAt: validDate(s.StartedAt),
    finishedAt: validDate(s.FinishedAt),
    restartCount: info.RestartCount ?? 0,
  };
}

const validDate = (value) => (value && !value.startsWith('0001-') ? value : null);

export function cpuPercent(stats) {
  const cpu = stats?.cpu_stats;
  const pre = stats?.precpu_stats;
  if (!cpu?.cpu_usage || !pre?.cpu_usage) return null;
  const cpuDelta = cpu.cpu_usage.total_usage - pre.cpu_usage.total_usage;
  const systemDelta = (cpu.system_cpu_usage ?? 0) - (pre.system_cpu_usage ?? 0);
  const cores = cpu.online_cpus || cpu.cpu_usage.percpu_usage?.length || 1;
  if (cpuDelta < 0 || systemDelta <= 0) return null;
  return Math.round((cpuDelta / systemDelta) * cores * 1000) / 10;
}

export function memoryUsed(stats) {
  const m = stats?.memory_stats;
  if (!m?.usage) return null;
  // Page cache is not counted (as docker stats does).
  return m.usage - (m.stats?.inactive_file ?? m.stats?.total_inactive_file ?? m.stats?.cache ?? 0);
}

export function describeContainer(info, protectedPorts = []) {
  const labels = labelsOf(info.Config?.Labels);
  const ports = inspectPorts(info);
  return {
    id: info.Id,
    name: nameOf(info),
    image: info.Config?.Image ?? null,
    imageId: info.Image ?? null,
    createdAt: info.Created ?? null,
    state: stateOf(info),
    restartPolicy: info.HostConfig?.RestartPolicy?.Name || 'no',
    ports,
    mounts: (info.Mounts ?? []).map((m) => ({ type: m.Type, name: m.Name ?? null, source: m.Type === 'bind' ? m.Source : null, destination: m.Destination, readOnly: m.RW === false })),
    // Variable names only: values can hold secrets.
    envKeys: (info.Config?.Env ?? []).map((e) => e.split('=')[0]).slice(0, 200),
    command: [...(info.Config?.Entrypoint ?? []), ...(info.Config?.Cmd ?? [])].join(' ').slice(0, 1000) || null,
    networks: Object.keys(info.NetworkSettings?.Networks ?? {}),
    limits: { memoryBytes: info.HostConfig?.Memory || null, cpuPercent: info.HostConfig?.NanoCpus ? info.HostConfig.NanoCpus / 1e7 : null },
    managedId: managedIdOf(labels),
    protected: isProtected(labels, ports, protectedPorts),
    privileged: Boolean(info.HostConfig?.Privileged),
    compose: labels['com.docker.compose.project'] ? { project: labels['com.docker.compose.project'], service: labels['com.docker.compose.service'] ?? null } : null,
  };
}

// ---- Deploying -------------------------------------------------------------

// Checks CONTAINER_DEPLOY's parameters again, independently of the panel.
export function checkDeploy(params) {
  onlyKeys(params, ['id', 'name', 'image', 'ports', 'env', 'volumes', 'restartPolicy', 'memoryMb', 'cpuPercent', 'command', 'healthCheckSeconds', 'pull']);
  const fail = (message) => {
    throw new OperationError('INVALID_PARAMS', message);
  };
  if (typeof params.id !== 'string' || !MANAGED_ID_PATTERN.test(params.id)) fail('id must be the container record id');
  if (typeof params.name !== 'string' || !CONTAINER_NAME_PATTERN.test(params.name)) fail('name must be 3 to 32 lowercase letters, digits and dashes');
  if (typeof params.image !== 'string' || params.image.length > MAX_IMAGE_REF_LENGTH || !IMAGE_REF_PATTERN.test(params.image)) fail('image must be an image reference');

  const ports = (params.ports ?? []).map((p) => parsePortMapping(p) ?? fail(`Invalid port ${String(p).slice(0, 40)}`));
  if (ports.length > MAX_CONTAINER_PORTS) fail(`Up to ${MAX_CONTAINER_PORTS} ports`);
  const hostKeys = ports.map((p) => `${p.hostPort}/${p.protocol}`);
  if (new Set(hostKeys).size !== hostKeys.length) fail('Each host port can be published once');

  const env = params.env ?? [];
  if (!Array.isArray(env) || env.length > MAX_ENV_VARS) fail(`Up to ${MAX_ENV_VARS} environment variables`);
  for (const entry of env) {
    const eq = typeof entry === 'string' ? entry.indexOf('=') : -1;
    if (eq < 1 || !ENV_KEY_PATTERN.test(entry.slice(0, eq)) || entry.length - eq - 1 > MAX_ENV_VALUE_LENGTH || entry.includes('\0')) fail('env entries must be KEY=value');
  }

  const volumes = (params.volumes ?? []).map((v) => parseVolumeMapping(v) ?? fail(`Invalid volume ${String(v).slice(0, 60)}`));
  if (volumes.length > MAX_CONTAINER_VOLUMES) fail(`Up to ${MAX_CONTAINER_VOLUMES} volumes`);
  if (new Set(volumes.map((v) => v.volume)).size !== volumes.length) fail('Each volume can be mounted once');
  if (new Set(volumes.map((v) => v.path)).size !== volumes.length) fail('Each path can have one volume');

  const restartPolicy = params.restartPolicy ?? 'unless-stopped';
  if (!RESTART_POLICY_KEYS.includes(restartPolicy)) fail(`restartPolicy must be one of ${RESTART_POLICY_KEYS.join(', ')}`);
  const range = (value, { min, max }, what) => {
    if (value === undefined || value === null) return null;
    if (!Number.isInteger(value) || value < min || value > max) fail(`${what} must be from ${min} to ${max}`);
    return value;
  };
  const memoryMb = range(params.memoryMb, CONTAINER_MEMORY_MB, 'memoryMb');
  const cpu = range(params.cpuPercent, CONTAINER_CPU_PERCENT, 'cpuPercent');
  const healthCheckSeconds = range(params.healthCheckSeconds ?? CONTAINER_HEALTH_SECONDS.default, CONTAINER_HEALTH_SECONDS, 'healthCheckSeconds');

  const command = params.command ?? [];
  if (!Array.isArray(command) || command.length > MAX_CONTAINER_COMMAND_ARGS) fail(`command must be up to ${MAX_CONTAINER_COMMAND_ARGS} arguments`);
  if (command.some((a) => typeof a !== 'string' || a.length > MAX_CONTAINER_COMMAND_LENGTH || !CONTAINER_COMMAND_PATTERN.test(a))) fail('command arguments must be one line of text');
  if (params.pull !== undefined && typeof params.pull !== 'boolean') fail('pull must be true or false');

  return { id: params.id, name: params.name, image: params.image, ports, env, volumes, restartPolicy, memoryMb, cpuPercent: cpu, command, healthCheckSeconds, pull: params.pull ?? true };
}

// The Docker configuration of a container VaultPanel deploys. Everything that
// could reach past the container (privileged mode, host networking,
// capabilities, devices, host folders) is fixed here, not taken from params.
export function containerConfig(spec) {
  const exposed = {};
  const bindings = {};
  for (const p of spec.ports) {
    const key = `${p.containerPort}/${p.protocol}`;
    exposed[key] = {};
    (bindings[key] ??= []).push({ HostIp: p.address, HostPort: String(p.hostPort) });
  }
  const labels = { [CONTAINER_LABELS.managed]: 'true', [CONTAINER_LABELS.id]: spec.id };
  return {
    Image: spec.image,
    Env: spec.env,
    ...(spec.command.length ? { Cmd: spec.command } : {}),
    Labels: { ...labels, 'io.vaultpanel.name': spec.name },
    ExposedPorts: exposed,
    HostConfig: {
      PortBindings: bindings,
      Mounts: spec.volumes.map((v) => ({
        Type: 'volume',
        Source: dockerVolumeName(spec.name, v.volume),
        Target: v.path,
        ReadOnly: v.readOnly,
        VolumeOptions: { Labels: labels },
      })),
      RestartPolicy: { Name: spec.restartPolicy, MaximumRetryCount: spec.restartPolicy === 'on-failure' ? 5 : 0 },
      Memory: spec.memoryMb ? spec.memoryMb * 1024 * 1024 : 0,
      NanoCpus: spec.cpuPercent ? spec.cpuPercent * 1e7 : 0,
      NetworkMode: CONTAINER_NETWORK,
      Privileged: false,
      CapAdd: [],
      Devices: [],
      SecurityOpt: ['no-new-privileges:true'],
      LogConfig: { Type: 'json-file', Config: { 'max-size': '10m', 'max-file': '3' } },
    },
    NetworkingConfig: { EndpointsConfig: { [CONTAINER_NETWORK]: { Aliases: [spec.name] } } },
  };
}

async function ensureNetwork(docker, ctx) {
  const networks = await docker$(docker.listNetworks(), 'Could not list Docker networks');
  if (networks.some((n) => n.Name === CONTAINER_NETWORK)) return;
  ctx.log('stdout', `Creating the Docker network ${CONTAINER_NETWORK}, shared by VaultPanel's containers`);
  try {
    await docker.createNetwork(CONTAINER_NETWORK, { [CONTAINER_LABELS.managed]: 'true' });
  } catch (err) {
    // Created at the same moment by another deployment.
    if (!(err instanceof DockerError && err.code === 'CONFLICT')) throw new OperationError('DOCKER_ERROR', `Could not create the network: ${err.message}`);
  }
}

export async function pullImage(docker, image, ctx) {
  ctx.log('stdout', `Pulling ${image}`);
  let last = null;
  try {
    await docker.pullImage(image, {
      timeout: ctx.timeoutMs,
      onProgress: (event) => {
        if (!event.status || QUIET_PULL_STATUSES.has(event.status)) return;
        const line = event.id && !event.status.includes(event.id) ? `${event.id}: ${event.status}` : event.status;
        if (line !== last) ctx.log('stdout', line);
        last = line;
      },
    });
  } catch (err) {
    if (err instanceof DockerError) {
      const hint = /unauthorized|denied|not found|manifest unknown/i.test(err.message)
        ? ' Check the image name and tag. Private registries are not supported yet.'
        : /toomanyrequests|rate limit/i.test(err.message)
          ? ' Docker Hub limits how often a server may pull; try again later.'
          : '';
      throw new OperationError('PULL_FAILED', `Could not pull ${image}: ${err.message}.${hint}`);
    }
    throw err;
  }
}

async function imagePresent(docker, image) {
  try {
    await docker.inspectImage(image);
    return true;
  } catch (err) {
    if (err instanceof DockerError && err.code === 'NOT_FOUND') return false;
    throw err;
  }
}

// Waits healthCheckSeconds for the new container to prove it stays up (and,
// if its image has a health check, to report healthy).
export async function waitUntilUp(docker, id, seconds, ctx) {
  const deadline = Date.now() + seconds * 1000;
  const pause = ctx.pollMs ?? 1000;
  ctx.log('stdout', `Checking the container stays up for ${seconds} seconds`);
  for (;;) {
    const info = await docker$(docker.inspectContainer(id), 'Could not read the container');
    const state = stateOf(info);
    if (!state.running || state.restarting || state.restartCount > 0) {
      const tail = await tailOf(docker, info);
      const why = state.exitCode !== null && !state.running ? ` (exit code ${state.exitCode})` : state.restarting || state.restartCount > 0 ? ' and keeps restarting' : '';
      throw new OperationError('CONTAINER_EXITED', `The container stopped${why}.${tail.length ? ` Its last output:\n${tail.join('\n')}` : ''}`);
    }
    if (state.health === 'unhealthy') throw new OperationError('CONTAINER_UNHEALTHY', 'The container’s own health check reports it unhealthy');
    if (state.health === 'healthy') return info;
    if (Date.now() >= deadline) {
      if (state.health === 'starting') ctx.log('stdout', 'Its health check has not finished yet; it is running');
      return info;
    }
    await new Promise((r) => setTimeout(r, pause));
  }
}

async function removeQuietly(docker, ref, ctx) {
  try {
    await docker.removeContainer(ref, { force: true });
  } catch (err) {
    if (!(err instanceof DockerError && err.code === 'NOT_FOUND')) ctx.log('stderr', `Could not remove ${ref}: ${err.message}`);
  }
}

async function deploy(spec, ctx) {
  const docker = await dockerFor(ctx);
  const existing = await findContainer(docker, spec.name);
  if (existing && managedIdOf(labelsOf(existing.Config?.Labels)) !== spec.id) {
    throw new OperationError('NAME_TAKEN', `A container named ${spec.name} already exists on this server and VaultPanel did not deploy it. Choose another name.`);
  }

  let pulled = false;
  if (spec.pull || !(await imagePresent(docker, spec.image))) {
    await pullImage(docker, spec.image, ctx);
    pulled = true;
  }
  await ensureNetwork(docker, ctx);

  // A leftover from an interrupted deployment.
  const previousName = `${spec.name}${PREVIOUS_SUFFIX}`;
  const leftover = await findContainer(docker, previousName);
  if (leftover && managedIdOf(labelsOf(leftover.Config?.Labels)) === spec.id) await removeQuietly(docker, leftover.Id, ctx);

  // The current container steps aside (stopped, renamed) so the new one can
  // take its name and ports; it comes back if the new one fails.
  const wasRunning = Boolean(existing?.State?.Running);
  if (existing) {
    if (wasRunning) {
      ctx.log('stdout', `Stopping the current ${spec.name}`);
      await docker$(docker.stopContainer(existing.Id, STOP_SECONDS), 'Could not stop the current container');
    }
    await docker$(docker.renameContainer(existing.Id, previousName), 'Could not set the current container aside');
  }

  let created = null;
  try {
    ctx.log('stdout', `Creating ${spec.name} from ${spec.image}`);
    created = await docker$(docker.createContainer(spec.name, containerConfig(spec)), 'Docker could not create the container');
    for (const warning of created.Warnings ?? []) ctx.log('stderr', warning);
    ctx.log('stdout', `Starting ${spec.name}`);
    await docker$(docker.startContainer(created.Id), 'Docker could not start the container');
    const info = await waitUntilUp(docker, created.Id, spec.healthCheckSeconds, ctx);
    if (existing) {
      ctx.log('stdout', 'Removing the previous container (its volumes are kept)');
      await removeQuietly(docker, existing.Id, ctx);
    }
    ctx.log('stdout', `${spec.name} is running`);
    return { output: { container: describeContainer(info), replaced: Boolean(existing), pulled } };
  } catch (err) {
    ctx.log('stderr', err.message);
    if (created) await removeQuietly(docker, created.Id, ctx);
    if (existing) {
      try {
        await docker.renameContainer(existing.Id, spec.name);
        if (wasRunning) await docker.startContainer(existing.Id);
        ctx.log('stdout', `Rolled back: the previous ${spec.name} is ${wasRunning ? 'running' : 'back'} again`);
      } catch (rollbackErr) {
        ctx.log('stderr', `Could not bring back the previous container: ${rollbackErr.message}`);
      }
    }
    throw err;
  }
}

// ---- Operations --------------------------------------------------------------

async function installDocker(ctx) {
  requireAllowed(ctx.policy);
  if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
  const deadline = Date.now() + ctx.timeoutMs;
  const remaining = () => Math.max(10_000, deadline - Date.now());
  const before = await detectDocker(ctx);
  if (before.running) {
    ctx.log('stdout', `Docker ${before.version} is already running`);
    return { output: { docker: before, changed: false } };
  }
  const dirs = [...(ctx.binDirs ?? BIN_DIRS)];
  const start = async (file, args) => {
    ctx.log('stdout', `$ ${file.split('/').pop()} ${args.join(' ')}`);
    const result = await ctx.run(file, args, { timeoutMs: remaining(), onLine: ctx.log, env: APT_ENV });
    if (result.timedOut) throw new OperationError('TIMEOUT', 'Starting Docker did not finish in time');
    if (result.error || result.exitCode !== 0) {
      throw new OperationError('START_FAILED', `Docker did not start: ${(result.stderr || result.stdout || result.error?.message || '').trim().split('\n').slice(-6).join('\n')}`);
    }
  };
  if (before.source === 'snap') {
    // The snap's daemon is the service snap.docker.dockerd, not docker.service.
    const snap = await findBinary('snap', dirs);
    if (!snap) throw new OperationError('START_FAILED', 'Docker is installed as a snap but the snap command is missing');
    await start(snap, ['start', '--enable', 'docker']);
  } else {
    if (!before.installed) await aptInstall(ctx, ['docker.io'], remaining);
    const systemctl = await findBinary('systemctl', dirs);
    if (!systemctl) throw new OperationError('START_FAILED', 'systemctl is missing, so Docker cannot be started');
    await start(systemctl, ['enable', '--now', 'docker.service']);
  }

  // The daemon takes a moment to open its socket.
  const until = Date.now() + Math.min(60_000, remaining());
  let after = await detectDocker(ctx);
  while (!after.running && Date.now() < until) {
    await new Promise((r) => setTimeout(r, ctx.pollMs ?? 2000));
    after = await detectDocker(ctx);
  }
  if (!after.running) throw new OperationError('START_FAILED', 'Docker was started but does not answer on its socket yet. Check it with: systemctl status docker');
  ctx.log('stdout', `Docker ${after.version} is running`);
  return { output: { docker: after, changed: true } };
}

export const CONTAINER_OPERATIONS = {
  DOCKER_STATUS: {
    async run(params, ctx) {
      onlyKeys(params, []);
      requireAllowed(ctx.policy);
      const docker = await detectDocker(ctx);
      if (!docker.running) return { output: { docker } };
      const client = await clientFor(ctx);
      const info = await client.info().catch(() => null);
      return {
        output: {
          docker: {
            ...docker,
            containers: info ? { total: info.Containers, running: info.ContainersRunning, stopped: info.ContainersStopped, paused: info.ContainersPaused } : null,
            images: info?.Images ?? null,
            storageDriver: info?.Driver ?? null,
            rootDir: info?.DockerRootDir ?? null,
            warnings: (info?.Warnings ?? []).slice(0, 10),
          },
        },
      };
    },
  },

  DOCKER_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, []);
      return installDocker(ctx);
    },
  },

  CONTAINER_LIST: {
    async run(params, ctx) {
      onlyKeys(params, ['protectedPorts']);
      const protectedPorts = checkProtectedPorts(params);
      const docker = await dockerFor(ctx);
      const list = await docker$(docker.listContainers(), 'Could not list containers');
      const containers = list.map((c) => summarizeContainer(c, protectedPorts)).sort((a, b) => a.name.localeCompare(b.name));
      return { output: { containers } };
    },
  },

  CONTAINER_INSPECT: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'protectedPorts']);
      const ref = checkRef(params.container);
      const protectedPorts = checkProtectedPorts(params);
      const docker = await dockerFor(ctx);
      const info = await requireContainer(docker, ref);
      const container = describeContainer(info, protectedPorts);
      if (container.state.running) {
        const stats = await docker.stats(info.Id).catch(() => null);
        if (stats) container.usage = { cpuPercent: cpuPercent(stats), memoryBytes: memoryUsed(stats), memoryLimitBytes: stats.memory_stats?.limit ?? null };
      }
      return { output: { container } };
    },
  },

  CONTAINER_LOGS: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'lines']);
      const ref = checkRef(params.container);
      const lines = params.lines ?? 200;
      if (!Number.isInteger(lines) || lines < 10 || lines > 2000) throw new OperationError('INVALID_PARAMS', 'lines must be an integer from 10 to 2000');
      const docker = await dockerFor(ctx);
      const info = await requireContainer(docker, ref);
      const buffer = await docker$(docker.logs(info.Id, { tail: lines }), 'Could not read the logs');
      return { output: { container: nameOf(info), lines: logLines(buffer, Boolean(info.Config?.Tty)).slice(-lines) } };
    },
  },

  CONTAINER_DEPLOY: {
    async run(params, ctx) {
      return deploy(checkDeploy(params), ctx);
    },
  },

  CONTAINER_START: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'protectedPorts']);
      const ref = checkRef(params.container);
      checkProtectedPorts(params);
      const docker = await dockerFor(ctx);
      const info = await requireContainer(docker, ref);
      // Starting is allowed for every container, VaultPanel's own included.
      if (info.State?.Running) {
        ctx.log('stdout', `${nameOf(info)} is already running`);
        return { output: { container: describeContainer(info, params.protectedPorts) } };
      }
      ctx.log('stdout', `Starting ${nameOf(info)}`);
      await docker$(docker.startContainer(info.Id), 'Docker could not start the container');
      const after = await waitUntilUp(docker, info.Id, ctx.startCheckSeconds ?? 3, ctx);
      return { output: { container: describeContainer(after, params.protectedPorts) } };
    },
  },

  CONTAINER_STOP: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'protectedPorts']);
      const ref = checkRef(params.container);
      const protectedPorts = checkProtectedPorts(params);
      const docker = await dockerFor(ctx);
      const info = await requireContainer(docker, ref);
      refuseProtected(info, protectedPorts, 'stop');
      if (!info.State?.Running) {
        ctx.log('stdout', `${nameOf(info)} is not running`);
      } else {
        ctx.log('stdout', `Stopping ${nameOf(info)} (it gets ${STOP_SECONDS} seconds to exit cleanly)`);
        await docker$(docker.stopContainer(info.Id, STOP_SECONDS), 'Docker could not stop the container');
      }
      return { output: { container: describeContainer(await requireContainer(docker, info.Id), protectedPorts) } };
    },
  },

  CONTAINER_RESTART: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'protectedPorts']);
      const ref = checkRef(params.container);
      const protectedPorts = checkProtectedPorts(params);
      const docker = await dockerFor(ctx);
      const info = await requireContainer(docker, ref);
      refuseProtected(info, protectedPorts, 'restart');
      ctx.log('stdout', `Restarting ${nameOf(info)}`);
      await docker$(docker.restartContainer(info.Id, STOP_SECONDS), 'Docker could not restart the container');
      const after = await waitUntilUp(docker, info.Id, ctx.startCheckSeconds ?? 3, ctx);
      return { output: { container: describeContainer(after, protectedPorts) } };
    },
  },

  CONTAINER_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['container', 'id', 'removeVolumes', 'protectedPorts']);
      const ref = checkRef(params.container);
      const protectedPorts = checkProtectedPorts(params);
      if (params.id !== undefined && (typeof params.id !== 'string' || !MANAGED_ID_PATTERN.test(params.id))) throw new OperationError('INVALID_PARAMS', 'id must be a container record id');
      if (params.removeVolumes && !params.id) throw new OperationError('INVALID_PARAMS', 'Volumes are only removed with containers VaultPanel deployed');
      const docker = await dockerFor(ctx);
      const info = await findContainer(docker, ref);
      const volumes = [];
      if (!info) {
        if (!params.id) throw new OperationError('CONTAINER_NOT_FOUND', `There is no container ${ref} on this server`);
        ctx.log('stdout', `${ref} is already gone`);
      } else {
        if (params.id && managedIdOf(labelsOf(info.Config?.Labels)) !== params.id) {
          throw new OperationError('NOT_MANAGED', `The container named ${nameOf(info)} was not deployed by VaultPanel for this record, so it is left alone`);
        }
        refuseProtected(info, protectedPorts, 'remove');
        if (info.State?.Running) {
          ctx.log('stdout', `Stopping ${nameOf(info)}`);
          await docker$(docker.stopContainer(info.Id, STOP_SECONDS), 'Docker could not stop the container');
        }
        ctx.log('stdout', `Removing ${nameOf(info)}`);
        await docker$(docker.removeContainer(info.Id, { force: true }), 'Docker could not remove the container');
        volumes.push(...(info.Mounts ?? []).filter((m) => m.Type === 'volume').map((m) => m.Name));
      }

      const removedVolumes = [];
      if (params.removeVolumes) {
        // Only the container's own volumes: vp-<name>-*, labelled with its id.
        const all = await docker$(docker.listVolumes(), 'Could not list volumes');
        const name = info ? nameOf(info) : ref;
        const own = (all.Volumes ?? []).filter((v) => v.Name.startsWith(`vp-${name}-`) && v.Labels?.[CONTAINER_LABELS.id] === params.id).map((v) => v.Name);
        for (const volume of new Set([...own, ...volumes.filter((v) => own.includes(v))])) {
          try {
            await docker.removeVolume(volume);
            removedVolumes.push(volume);
            ctx.log('stdout', `Deleted the volume ${volume}`);
          } catch (err) {
            ctx.log('stderr', `Could not delete the volume ${volume}: ${err.message}`);
          }
        }
      }
      return { output: { removed: Boolean(info), volumesRemoved: removedVolumes } };
    },
  },

  IMAGE_LIST: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const docker = await dockerFor(ctx);
      const [images, containers] = await Promise.all([docker$(docker.listImages(), 'Could not list images'), docker$(docker.listContainers(), 'Could not list containers')]);
      const usedBy = new Map();
      for (const c of containers) usedBy.set(c.ImageID, [...(usedBy.get(c.ImageID) ?? []), (c.Names?.[0] ?? '').replace(/^\//, '')]);
      return {
        output: {
          images: images
            .map((i) => ({
              id: i.Id,
              tags: (i.RepoTags ?? []).filter((t) => t !== '<none>:<none>'),
              sizeBytes: i.Size ?? null,
              createdAt: i.Created ? new Date(i.Created * 1000).toISOString() : null,
              containers: usedBy.get(i.Id) ?? [],
            }))
            .sort((a, b) => (a.tags[0] ?? '~').localeCompare(b.tags[0] ?? '~')),
        },
      };
    },
  },

  IMAGE_PULL: {
    async run(params, ctx) {
      onlyKeys(params, ['image']);
      if (typeof params.image !== 'string' || params.image.length > MAX_IMAGE_REF_LENGTH || !IMAGE_REF_PATTERN.test(params.image)) {
        throw new OperationError('INVALID_PARAMS', 'image must be an image reference');
      }
      const docker = await dockerFor(ctx);
      await pullImage(docker, params.image, ctx);
      const info = await docker$(docker.inspectImage(params.image), 'Could not read the image');
      return { output: { image: { id: info.Id, tags: info.RepoTags ?? [], sizeBytes: info.Size ?? null } } };
    },
  },

  IMAGE_REMOVE: {
    async run(params, ctx) {
      onlyKeys(params, ['image']);
      if (typeof params.image !== 'string' || !IMAGE_ID_PATTERN.test(params.image)) throw new OperationError('INVALID_PARAMS', 'image must be an image ID');
      const docker = await dockerFor(ctx);
      const users = (await docker$(docker.listContainers(), 'Could not list containers')).filter((c) => c.ImageID === params.image);
      if (users.length) {
        throw new OperationError('IMAGE_IN_USE', `The image is used by ${users.map((c) => (c.Names?.[0] ?? '').replace(/^\//, '')).join(', ')}. Remove those containers first.`);
      }
      const result = await docker$(docker.removeImage(params.image), 'Docker could not remove the image');
      ctx.log('stdout', 'Image removed');
      return { output: { removed: (result ?? []).map((r) => r.Untagged ?? r.Deleted).filter(Boolean) } };
    },
  },
};
