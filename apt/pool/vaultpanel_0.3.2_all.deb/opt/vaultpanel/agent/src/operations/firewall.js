import { lookup } from 'node:dns/promises';
import { readFile } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import {
  FIREWALL_ACTION_KEYS,
  FIREWALL_COMMENT_PATTERN,
  FIREWALL_DIRECTION_KEYS,
  FIREWALL_INCOMING_POLICY_KEYS,
  FIREWALL_OUTGOING_POLICY_KEYS,
  FIREWALL_PROTOCOL_KEYS,
  isAddressOrNetwork,
  parsePortSpec,
} from '../security/securityRules.js';
import { onlyKeys, OperationError } from './errors.js';

// The firewall, through UFW. The agent reads the rules from UFW's own files
// (they are there whether the firewall is on or off) and changes them only
// with the ufw command, with arguments it builds itself.
//
// Lockout guard: some TCP ports must stay reachable from anywhere. The SSH
// ports (read from sshd), plus any the panel names (the port people reach the
// panel on, when it runs on this server). The agent refuses a rule that would
// block them, refuses to delete the last rule that lets them in, and adds an
// allow rule for them before it turns the firewall on or makes the default
// stricter.
//
// Outgoing rules (0.34.0) have their own guard: the agent must still reach
// the panel. It refuses an outgoing block that covers the panel's address and
// port, and before outgoing connections are denied by default it allows the
// panel, DNS, the web (updates, Git, Let's Encrypt), NTP and, with a mail
// server installed, mail.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const ENV = { PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', LANG: 'C' };
const ANY_NETWORKS = new Set(['0.0.0.0/0', '::/0']);
const POLICY_NAMES = { DROP: 'deny', REJECT: 'reject', ACCEPT: 'allow' };

// One "### tuple ###" line of user.rules or user6.rules:
// <action> <proto> <dport> <dst> <sport> <src> [<dapp> <sapp>] <direction> [comment=<hex>]
export function parseTuple(line, family) {
  const match = /^### tuple ### (.+)$/.exec(line.trim());
  if (!match) return null;
  let text = match[1];
  let comment = '';
  const commentAt = text.indexOf(' comment=');
  if (commentAt >= 0) {
    try {
      comment = Buffer.from(text.slice(commentAt + 9).trim(), 'hex').toString('utf8');
    } catch {
      comment = '';
    }
    text = text.slice(0, commentAt);
  }
  const fields = text.split(' ');
  if (fields.length !== 7 && fields.length !== 9) return null;
  const [action, proto, dport, destination, sport, src] = fields;
  const app = fields.length === 9 && fields[6] !== '-' ? fields[6].replace(/%20/g, ' ') : null;
  const direction = fields[fields.length - 1];
  return {
    action: action.replace(/_log(-all)?$/, ''),
    protocol: proto === 'any' ? 'any' : proto,
    port: dport === 'any' ? '' : dport,
    source: ANY_NETWORKS.has(src) ? 'any' : src,
    destination: ANY_NETWORKS.has(destination) ? 'any' : destination,
    sourcePort: sport === 'any' ? null : sport,
    app,
    direction: direction.startsWith('in') ? 'in' : direction.startsWith('out') ? 'out' : direction,
    interface: direction.includes('_') ? direction.slice(direction.indexOf('_') + 1) : null,
    comment,
    families: [family],
  };
}

// The rules of both files, a rule present in both (added without an
// address) listed once.
export function parseRules(v4Text, v6Text) {
  const rules = [];
  const keyOf = (r) => [r.action, r.protocol, r.port, r.source, r.destination, r.sourcePort, r.app, r.direction, r.interface].join('|');
  for (const [text, family] of [[v4Text, 'ipv4'], [v6Text, 'ipv6']]) {
    for (const line of (text ?? '').split('\n')) {
      const rule = parseTuple(line, family);
      if (!rule) continue;
      const twin = rule.source === 'any' && rule.destination === 'any' ? rules.find((r) => keyOf(r) === keyOf(rule) && !r.families.includes(family)) : null;
      if (twin) twin.families.push(family);
      else rules.push(rule);
    }
  }
  // Rules the panel can show and delete: incoming ones to any address of this
  // server, and outgoing ones from it.
  const managed = (r) => !r.sourcePort && !r.interface && (r.direction === 'in' ? r.destination === 'any' : r.direction === 'out' && r.source === 'any');
  return rules.map((rule, index) => ({ ...rule, id: index + 1, managed: managed(rule) }));
}

export function parseDefaults(text) {
  const read = (key) => {
    const match = new RegExp(`^${key}="?([A-Z]+)"?`, 'm').exec(text ?? '');
    return match ? (POLICY_NAMES[match[1]] ?? match[1].toLowerCase()) : null;
  };
  return { incoming: read('DEFAULT_INPUT_POLICY'), outgoing: read('DEFAULT_OUTPUT_POLICY'), ipv6: /^IPV6=yes/m.test(text ?? '') };
}

const readText = (file) => readFile(file, 'utf8').catch(() => null);

function paths(policy) {
  const dir = policy.ufwDir ?? '/etc/ufw';
  return {
    v4: path.join(dir, 'user.rules'),
    v6: path.join(dir, 'user6.rules'),
    conf: path.join(dir, 'ufw.conf'),
    defaults: policy.ufwDefaultsFile ?? '/etc/default/ufw',
  };
}

export async function readFirewall(ctx) {
  const ufw = await findBinary('ufw', ctx.binDirs);
  if (!ufw) return { installed: false, active: false, incoming: null, outgoing: null, rules: [] };
  const p = paths(ctx.policy);
  const [v4, v6, conf, defaults] = await Promise.all([readText(p.v4), readText(p.v6), readText(p.conf), readText(p.defaults)]);
  // ufw status reads the running firewall; ufw.conf says whether it starts at boot.
  const status = await ctx.run(ufw, ['status'], { timeoutMs: 20_000, env: ENV });
  const active = status.exitCode === 0 ? /^Status: active/m.test(status.stdout) : /^ENABLED=yes/m.test(conf ?? '');
  return { installed: true, active, enabledAtBoot: /^ENABLED=yes/m.test(conf ?? ''), ...parseDefaults(defaults), rules: parseRules(v4, v6) };
}

// The TCP ports sshd listens on, from its effective settings.
export async function sshPorts(ctx) {
  const sshd = await findBinary('sshd', ctx.binDirs);
  if (sshd) {
    const result = await ctx.run(sshd, ['-T'], { timeoutMs: 15_000, env: ENV });
    if (result.exitCode === 0) {
      const ports = [...result.stdout.matchAll(/^port (\d+)$/gm)].map((m) => Number(m[1])).filter((p) => p > 0 && p < 65536);
      if (ports.length) return [...new Set(ports)];
    }
  }
  return [22];
}

// Whether the rules let anyone reach a TCP port.
export function portOpenToAll(rules, port, { except = null } = {}) {
  return rules.some(
    (r) =>
      r !== except &&
      r.managed &&
      r.direction === 'in' &&
      ['allow', 'limit'].includes(r.action) &&
      r.source === 'any' &&
      r.protocol !== 'udp' &&
      (r.app ? r.port && portInSpec(r.port, port) : !r.port || portInSpec(r.port, port)),
  );
}

function portInSpec(spec, port) {
  return Boolean(parsePortSpec(spec)?.some((r) => port >= r.from && port <= r.to));
}

export function checkRule(params, { forDelete = false } = {}) {
  const rule = {
    action: params.action,
    direction: params.direction ?? 'in',
    protocol: params.protocol ?? 'tcp',
    port: params.port ?? '',
    source: params.source ?? 'any',
    destination: params.destination ?? 'any',
    app: params.app ?? null,
  };
  if (!FIREWALL_ACTION_KEYS.includes(rule.action)) throw invalid(`action must be one of ${FIREWALL_ACTION_KEYS.join(', ')}`);
  if (!FIREWALL_DIRECTION_KEYS.includes(rule.direction)) throw invalid(`direction must be one of ${FIREWALL_DIRECTION_KEYS.join(', ')}`);
  if (!FIREWALL_PROTOCOL_KEYS.includes(rule.protocol)) throw invalid(`protocol must be one of ${FIREWALL_PROTOCOL_KEYS.join(', ')}`);
  if (rule.source !== 'any' && !isAddressOrNetwork(rule.source)) throw invalid('source must be "any", an IP address or a network');
  if (rule.destination !== 'any' && !isAddressOrNetwork(rule.destination)) throw invalid('destination must be "any", an IP address or a network');
  // Incoming rules name who connects; outgoing ones where to.
  if (rule.direction === 'in' && rule.destination !== 'any') throw invalid('An incoming rule takes a source, not a destination');
  if (rule.direction === 'out' && rule.source !== 'any') throw invalid('An outgoing rule takes a destination, not a source');
  if (rule.app !== null) {
    if (!forDelete) throw invalid('app rules can only be deleted');
    if (rule.direction !== 'in') throw invalid('app rules are incoming');
    if (typeof rule.app !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/.test(rule.app)) throw invalid('app must be a UFW application name');
    return rule;
  }
  if (rule.port) {
    const ranges = parsePortSpec(rule.port);
    if (!ranges) throw invalid('port must be a port, a list such as 80,443 or a range such as 6000:6007');
    if (rule.protocol === 'any' && (ranges.length > 1 || ranges[0].from !== ranges[0].to)) {
      throw invalid('Choose TCP or UDP for a list or range of ports');
    }
  } else if (rule.source === 'any' && rule.destination === 'any' && !forDelete) {
    throw invalid(
      rule.direction === 'in'
        ? 'Give a port, a source address, or both: a rule for every port from anywhere would open or close the whole server'
        : 'Give a port, a destination, or both: use the outgoing default for every connection',
    );
  }
  if (params.comment !== undefined && (typeof params.comment !== 'string' || !FIREWALL_COMMENT_PATTERN.test(params.comment))) {
    throw invalid('comment may hold letters, digits, spaces and . , : _ ( ) / + - (60 at most)');
  }
  return rule;
}

// The ufw arguments that describe a rule (after "ufw" or "ufw delete").
export function ruleArgs(rule) {
  const out = rule.direction === 'out';
  const from = ['from', out ? 'any' : rule.source, 'to', out ? rule.destination : 'any'];
  if (rule.app) return [rule.action, ...from, 'app', rule.app];
  return [rule.action, ...(out ? ['out'] : []), ...(rule.protocol === 'any' ? [] : ['proto', rule.protocol]), ...from, ...(rule.port ? ['port', rule.port] : [])];
}

const sameRule = (r, rule) =>
  r.managed &&
  !r.app &&
  r.direction === rule.direction &&
  r.action === rule.action &&
  r.protocol === rule.protocol &&
  r.port === rule.port &&
  r.source === rule.source &&
  r.destination === rule.destination;

// Where the agent reaches the panel: its addresses and TCP port. A panel on
// this same machine is reached over loopback, which UFW never filters.
export async function panelEndpoints(ctx) {
  let url;
  try {
    url = new URL(ctx.policy.panelUrl);
  } catch {
    return [];
  }
  const host = url.hostname.replace(/^\[|\]$/g, '');
  const port = Number(url.port) || (url.protocol === 'https:' ? 443 : 80);
  let addresses;
  if (net.isIP(host)) addresses = [host];
  else {
    try {
      addresses = (await (ctx.lookup ?? lookup)(host, { all: true })).map((a) => a.address);
    } catch {
      addresses = [];
    }
  }
  return addresses.filter((a) => !/^127\./.test(a) && a !== '::1').map((address) => ({ address, port }));
}

// Whether an outgoing rule covers a connection to address:port over TCP.
export function outRuleCovers(rule, { address, port }) {
  if (rule.direction !== 'out' || rule.protocol === 'udp') return false;
  if (rule.port && !portInSpec(rule.port, port)) return false;
  return rule.destination === 'any' || addressInNetwork(address, rule.destination);
}

// IPv4 and IPv6 network matching, for outgoing destinations.
export function addressInNetwork(address, network) {
  const [base, bitsText] = network.split('/');
  const family = net.isIP(address);
  if (!family || family !== net.isIP(base)) return false;
  const width = family === 4 ? 32 : 128;
  const bits = bitsText === undefined ? width : Number(bitsText);
  const toBig = (ip) => {
    if (family === 4) return ip.split('.').reduce((n, part) => (n << 8n) + BigInt(part), 0n);
    const blocks = new net.SocketAddress({ address: ip, family: 'ipv6' }).address;
    const [head, tail = ''] = blocks.split('::');
    const left = head ? head.split(':') : [];
    const right = tail ? tail.split(':') : [];
    const all = blocks.includes('::') ? [...left, ...Array(8 - left.length - right.length).fill('0'), ...right] : left;
    return all.reduce((n, part) => (n << 16n) + BigInt(parseInt(part || '0', 16)), 0n);
  };
  const shift = BigInt(width - bits);
  return toBig(address) >> shift === toBig(base) >> shift;
}

function checkProtected(params) {
  const extra = params.protectedPorts ?? [];
  if (!Array.isArray(extra) || extra.length > 10 || extra.some((p) => !Number.isInteger(p) || p < 1 || p > 65535)) {
    throw invalid('protectedPorts must list TCP ports');
  }
  return extra;
}

async function protectedPorts(ctx, params) {
  const ssh = await sshPorts(ctx);
  const ports = new Map(ssh.map((p) => [p, 'SSH']));
  for (const p of checkProtected(params)) if (!ports.has(p)) ports.set(p, 'the panel');
  return ports;
}

async function requireUfw(ctx) {
  if (ctx.policy.allowFirewall === false) throw new OperationError('NOT_ALLOWED', 'Firewall changes are disabled in this agent config');
  const ufw = await findBinary('ufw', ctx.binDirs);
  if (!ufw) throw new OperationError('UFW_NOT_INSTALLED', 'UFW is not installed. Install it from the Security software card first.');
  return ufw;
}

export async function ufwRun(ctx, ufw, args, what) {
  ctx.log('stdout', `$ ufw ${args.map((a) => (/\s/.test(a) ? `'${a}'` : a)).join(' ')}`);
  const result = await ctx.run(ufw, args, { timeoutMs: 60_000, env: ENV, onLine: ctx.log });
  if (result.timedOut) throw new OperationError('TIMEOUT', `${what} did not finish in time`);
  const text = `${result.stdout}\n${result.stderr}`.trim();
  if (result.error || result.exitCode !== 0 || /^ERROR:/m.test(text)) {
    throw new OperationError('COMMAND_FAILED', `${what} failed: ${text.split('\n').slice(-4).join('\n') || result.error?.message || `exit code ${result.exitCode}`}`);
  }
  return text;
}

// Adds "allow <port>/tcp" for every protected port nobody can reach yet.
async function keepProtectedOpen(ctx, ufw, ports, rules) {
  const added = [];
  for (const [port, label] of ports) {
    if (portOpenToAll(rules, port)) continue;
    await ufwRun(ctx, ufw, ['allow', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', String(port), 'comment', `VaultPanel: keep ${label} reachable`], `Allowing port ${port}`);
    added.push(port);
  }
  return added;
}

// Before outgoing connections are denied by default: allow what the server
// needs to keep working (see FIREWALL_OUTGOING_KEPT in @vaultpanel/shared).
// Returns the labels of the rules added.
export async function keepOutgoingOpen(ctx, ufw) {
  const { rules } = await readFirewall(ctx);
  const allowed = (match) => rules.some((r) => r.managed && r.direction === 'out' && r.action === 'allow' && match(r));
  const covers = (r, port, proto) => ['any', proto].includes(r.protocol) && (!r.port || portInSpec(r.port, port)) && r.destination === 'any';
  const wanted = [];
  for (const endpoint of await panelEndpoints(ctx)) {
    if (!allowed((r) => outRuleCovers(r, endpoint))) {
      wanted.push({ label: 'the panel', args: ['allow', 'out', 'proto', 'tcp', 'from', 'any', 'to', endpoint.address, 'port', String(endpoint.port), 'comment', 'VaultPanel: reach the panel'] });
    }
  }
  if (!allowed((r) => covers(r, 53, 'udp')) || !allowed((r) => covers(r, 53, 'tcp'))) {
    wanted.push({ label: 'DNS', args: ['allow', 'out', 'from', 'any', 'to', 'any', 'port', '53', 'comment', 'VaultPanel: DNS'] });
  }
  if (![80, 443].every((p) => allowed((r) => covers(r, p, 'tcp')))) {
    wanted.push({ label: 'web', args: ['allow', 'out', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', '80,443', 'comment', 'VaultPanel: updates, Git, SSL'] });
  }
  if (!allowed((r) => covers(r, 123, 'udp'))) {
    wanted.push({ label: 'NTP', args: ['allow', 'out', 'proto', 'udp', 'from', 'any', 'to', 'any', 'port', '123', 'comment', 'VaultPanel: time'] });
  }
  if ((await findBinary('postfix', ctx.binDirs)) && ![25, 465, 587].every((p) => allowed((r) => covers(r, p, 'tcp')))) {
    wanted.push({ label: 'mail', args: ['allow', 'out', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', '25,465,587', 'comment', 'VaultPanel: sending mail'] });
  }
  for (const w of wanted) await ufwRun(ctx, ufw, w.args, `Allowing outgoing ${w.label}`);
  return wanted.map((w) => w.label);
}

// Opens 80 and 443 to everyone for NGINX (websites and Let's Encrypt),
// unless one is already open or the owner blocked them on purpose.
// Returns whether a rule was added.
export async function openWebPorts(ctx, ufw) {
  const { rules } = await readFirewall(ctx);
  const blocked = rules.some((r) => r.managed && r.direction === 'in' && ['deny', 'reject'].includes(r.action) && r.source === 'any' && r.port && (portInSpec(r.port, 80) || portInSpec(r.port, 443)));
  if (blocked || (portOpenToAll(rules, 80) && portOpenToAll(rules, 443))) return false;
  await ufwRun(ctx, ufw, ['allow', 'proto', 'tcp', 'from', 'any', 'to', 'any', 'port', '80,443', 'comment', 'VaultPanel: websites'], 'Allowing ports 80 and 443');
  return true;
}

// Lets everyone reach a service's ports (DNS, mail) when the firewall is on,
// unless a rule already does or someone denied one of them on purpose.
// protocol 'any' opens both TCP and UDP. Returns true when a rule was added.
export async function allowServicePorts(ctx, ports, { protocol = 'tcp', comment }) {
  const ufw = await findBinary('ufw', ctx.binDirs);
  if (!ufw) return false;
  const { active, rules } = await readFirewall(ctx);
  if (!active) return false;
  const protocols = protocol === 'any' ? ['tcp', 'udp'] : [protocol];
  const open = (port, proto) =>
    rules.some((r) => r.managed && r.direction === 'in' && ['allow', 'limit'].includes(r.action) && r.source === 'any' && !r.app && ['any', proto].includes(r.protocol) && (!r.port || portInSpec(r.port, port)));
  const denied = rules.some((r) => r.managed && r.direction === 'in' && ['deny', 'reject'].includes(r.action) && r.source === 'any' && r.port && ports.some((p) => portInSpec(r.port, p)));
  if (denied || ports.every((port) => protocols.every((proto) => open(port, proto)))) return false;
  const list = ports.join(',');
  await ufwRun(ctx, ufw, ['allow', ...(protocol === 'any' ? [] : ['proto', protocol]), 'from', 'any', 'to', 'any', 'port', list, 'comment', comment], `Allowing port${ports.length > 1 ? 's' : ''} ${list}`);
  return true;
}

async function finish(ctx, extra = {}) {
  ctx.webInventory?.invalidate();
  return { output: { ...extra, firewall: await readFirewall(ctx) } };
}

export const FIREWALL_OPERATIONS = {
  FIREWALL_ENABLE: {
    async run(params, ctx) {
      onlyKeys(params, ['protectedPorts']);
      const ufw = await requireUfw(ctx);
      const ports = await protectedPorts(ctx, params);
      const before = await readFirewall(ctx);
      const added = await keepProtectedOpen(ctx, ufw, ports, before.rules);
      // Websites stop answering if the firewall closes the web ports.
      if (ctx.webStack?.nginx ?? (await findBinary('nginx', ctx.binDirs))) {
        if (await openWebPorts(ctx, ufw)) added.push(80, 443);
      }
      await ufwRun(ctx, ufw, ['--force', 'enable'], 'Turning on the firewall');
      const result = await finish(ctx, { opened: added });
      if (!result.output.firewall.active) throw new OperationError('ENABLE_FAILED', 'UFW did not report the firewall as active after turning it on');
      ctx.log('stdout', `Firewall on. Kept reachable: ${[...ports.entries()].map(([p, l]) => `${p} (${l})`).join(', ')}`);
      return result;
    },
  },

  FIREWALL_DISABLE: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const ufw = await requireUfw(ctx);
      await ufwRun(ctx, ufw, ['disable'], 'Turning off the firewall');
      return finish(ctx);
    },
  },

  FIREWALL_RULE_ADD: {
    async run(params, ctx) {
      onlyKeys(params, ['action', 'direction', 'protocol', 'port', 'source', 'destination', 'comment', 'protectedPorts']);
      const rule = checkRule(params);
      const ufw = await requireUfw(ctx);
      const blocking = ['deny', 'reject'].includes(rule.action);
      if (rule.direction === 'in' && blocking && rule.source === 'any') {
        for (const [port, label] of await protectedPorts(ctx, params)) {
          if (rule.protocol !== 'udp' && (!rule.port || portInSpec(rule.port, port))) {
            throw new OperationError('LOCKOUT_REFUSED', `This rule would block port ${port}, which ${label} needs, so the agent refuses it`);
          }
        }
      }
      if (rule.direction === 'out' && blocking) {
        const cut = (await panelEndpoints(ctx)).find((endpoint) => outRuleCovers(rule, endpoint));
        if (cut) {
          throw new OperationError('LOCKOUT_REFUSED', `This rule would stop this server reaching the panel (${cut.address} port ${cut.port}), so the agent refuses it`);
        }
      }
      const { rules } = await readFirewall(ctx);
      // ufw would "update" an identical rule and drop its note; keep it as is.
      const same = rules.find((r) => sameRule(r, rule));
      if (same && (!params.comment || params.comment === same.comment)) {
        ctx.log('stdout', 'The firewall already has this rule; nothing changed');
        return finish(ctx, { skipped: true });
      }
      // Blocking rules go first, or an earlier allow rule would still let the
      // traffic in. "prepend" places them before every other rule.
      const position = ['deny', 'reject'].includes(rule.action) && rules.length ? ['prepend'] : [];
      const comment = params.comment ? ['comment', params.comment] : [];
      const text = await ufwRun(ctx, ufw, [...position, ...ruleArgs(rule), ...comment], 'Adding the rule');
      return finish(ctx, { skipped: /Skipping/.test(text) });
    },
  },

  FIREWALL_RULE_DELETE: {
    async run(params, ctx) {
      onlyKeys(params, ['action', 'direction', 'protocol', 'port', 'source', 'destination', 'app', 'protectedPorts']);
      const rule = checkRule(params, { forDelete: true });
      const ufw = await requireUfw(ctx);
      const ports = await protectedPorts(ctx, params);
      const firewall = await readFirewall(ctx);
      const { rules } = firewall;
      const existing = rules.find((r) => (rule.app ? r.managed && r.direction === 'in' && r.action === rule.action && r.source === rule.source && r.app === rule.app : sameRule(r, rule)));
      if (!existing) throw new OperationError('RULE_NOT_FOUND', 'That rule is not in the firewall any more. Refresh the list.');
      // With outgoing connections denied by default, the rule that lets the
      // agent reach the panel has to stay.
      if (existing.direction === 'out' && existing.action === 'allow' && firewall.outgoing !== 'allow') {
        for (const endpoint of await panelEndpoints(ctx)) {
          const others = rules.filter((r) => r !== existing && r.managed && r.action === 'allow' && outRuleCovers(r, endpoint));
          if (outRuleCovers(existing, endpoint) && !others.length) {
            throw new OperationError('LOCKOUT_REFUSED', `This rule lets this server reach the panel (${endpoint.address} port ${endpoint.port}) while outgoing connections are denied, so the agent refuses to delete it`);
          }
        }
      }
      for (const [port, label] of existing.direction === 'in' ? ports : []) {
        if (portOpenToAll([existing], port) && !portOpenToAll(rules, port, { except: existing })) {
          throw new OperationError(
            'LOCKOUT_REFUSED',
            `This is the rule that lets ${label} in on port ${port}. Deleting it could lock everyone out, so the agent refuses. Add another rule for port ${port} first if you want to replace it.`,
          );
        }
      }
      const text = await ufwRun(ctx, ufw, ['delete', ...ruleArgs(rule)], 'Deleting the rule');
      if (/Could not delete/.test(text)) throw new OperationError('RULE_NOT_FOUND', 'UFW did not find that rule. Refresh the list.');
      return finish(ctx);
    },
  },

  FIREWALL_DEFAULTS: {
    async run(params, ctx) {
      onlyKeys(params, ['incoming', 'outgoing', 'protectedPorts']);
      const { incoming, outgoing } = params;
      if (incoming === undefined && outgoing === undefined) throw invalid('Give incoming, outgoing or both');
      if (incoming !== undefined && !FIREWALL_INCOMING_POLICY_KEYS.includes(incoming)) throw invalid(`incoming must be one of ${FIREWALL_INCOMING_POLICY_KEYS.join(', ')}`);
      if (outgoing !== undefined && !FIREWALL_OUTGOING_POLICY_KEYS.includes(outgoing)) throw invalid(`outgoing must be one of ${FIREWALL_OUTGOING_POLICY_KEYS.join(', ')}`);
      const ufw = await requireUfw(ctx);
      const ports = await protectedPorts(ctx, params);
      let added = [];
      if (incoming !== undefined) {
        if (incoming !== 'allow') added = await keepProtectedOpen(ctx, ufw, ports, (await readFirewall(ctx)).rules);
        await ufwRun(ctx, ufw, ['default', incoming, 'incoming'], 'Changing the incoming default');
      }
      let allowedOut = [];
      if (outgoing !== undefined) {
        if (outgoing !== 'allow') allowedOut = await keepOutgoingOpen(ctx, ufw);
        await ufwRun(ctx, ufw, ['default', outgoing, 'outgoing'], 'Changing the outgoing default');
      }
      return finish(ctx, { opened: added, allowedOut });
    },
  },
};
