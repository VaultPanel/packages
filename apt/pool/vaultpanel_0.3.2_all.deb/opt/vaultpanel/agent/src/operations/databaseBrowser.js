import { createHmac, randomBytes } from 'node:crypto';
import { chown, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { lookupUser } from '../services/siteFiles.js';
import { DEFAULT_PATH } from '../utils/exec.js';
import { browserAccount, checkDatabaseName, DATABASE_USER_HOSTS, grantsSql, ident, literal, mysqlClient, requireDatabases, runSql } from './databases.js';
import { onlyKeys, OperationError } from './errors.js';

// The database interface: listing tables, browsing rows and running SQL in
// one database, like phpMyAdmin does.
//
// None of it runs as the database administrator. Each database has two
// accounts of its own, made and kept up to date here: one that can only
// read it (SELECT, SHOW VIEW) and one with full access to it, and to nothing
// else on the server. The SQL a person types runs as one of them, so it
// cannot reach other databases, the mysql system tables, users or files.
//
// The mysql client runs as the unprivileged "nobody" user and, where the
// client supports it, in --sandbox mode, so its own commands (\! shell,
// source, tee) cannot reach the server either.

export const MAX_RESULT_ROWS = 1000;
export const MAX_CELL_LENGTH = 5000;
export const MAX_SQL_LENGTH = 100_000;
const MAX_OUTPUT_CHARS = 2_000_000;
const MAX_STATEMENT_SECONDS = 30;
const SEPARATOR = '--------------';

const invalid = (message) => new OperationError('INVALID_PARAMS', message);

// The password is derived from the agent's private key, so it is the same
// each time and two requests on the same database do not change it under
// each other. Without a readable key it is random for this agent run.
let fallbackSecret;
export async function accountPassword(ctx, account) {
  let secret;
  try {
    secret = ctx.policy.privateKeyPath ? await readFile(ctx.policy.privateKeyPath) : null;
  } catch {
    secret = null;
  }
  if (!secret) secret = fallbackSecret ??= randomBytes(32);
  return createHmac('sha256', secret).update(`database-browser:${account}`).digest('base64url').slice(0, 32);
}

const account = (user, host) => `${literal(user)}@${literal(host)}`;

export function browserAccountSql(database, mode, password) {
  const user = browserAccount(database, mode);
  return [
    ...DATABASE_USER_HOSTS.flatMap((host) => [
      `CREATE USER IF NOT EXISTS ${account(user, host)} IDENTIFIED BY ${literal(password)} WITH MAX_USER_CONNECTIONS 5;`,
      `ALTER USER ${account(user, host)} IDENTIFIED BY ${literal(password)} WITH MAX_USER_CONNECTIONS 5;`,
    ]),
    ...grantsSql(user, [database], mode === 'write' ? 'all' : 'readonly'),
  ];
}

// ---- Running the client ----------------------------------------------------

const sandboxSupport = new Map();
async function supportsSandbox(ctx, client) {
  if (!sandboxSupport.has(client)) {
    const help = await ctx.run(client, ['--help'], { timeoutMs: 10_000 });
    sandboxSupport.set(client, /--sandbox/.test(help.stdout ?? ''));
  }
  return sandboxSupport.get(client);
}

// Lines of the mysql client's own commands (\! shell, source, tee...), which
// an old client without --sandbox would run. Such a client gets no
// backslashes at all and no line that starts with one of these words.
const CLIENT_COMMAND = /^\s*(system|source|tee|notee|pager|nopager|edit|connect|charset|delimiter|use|warnings|nowarning|rehash|prompt|exit|quit)\b/im;

// Connection settings (not credentials) from the administrator's options file.
async function connectionOptions(policy) {
  if (!policy.mysqlDefaultsFile) return [];
  try {
    const text = await readFile(policy.mysqlDefaultsFile, 'utf8');
    return text
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => /^(host|port|socket)\s*=\s*[^\s'"\\]+$/.test(line));
  } catch {
    return [];
  }
}

// Runs SQL in a database as its read-only or full-access account and returns
// what the client printed, parsed into statements. `prefix` statements are
// run first and left out of the result.
export async function runAsBrowser(ctx, database, mode, sql) {
  requireDatabases(ctx.policy);
  const user = browserAccount(database, mode);
  const password = await accountPassword(ctx, user);
  // As the administrator: make sure the account exists with only this
  // database. runSql also starts the database server if it is down.
  await runSql(ctx, browserAccountSql(database, mode, password), { log: false });

  const client = await mysqlClient(ctx);
  const sandbox = await supportsSandbox(ctx, client);
  if (!sandbox && (sql.includes('\\') || CLIENT_COMMAND.test(sql))) {
    throw new OperationError(
      'DATABASE_CLIENT_TOO_OLD',
      'The mysql client on this server has no sandbox mode, so SQL with backslashes or client commands (such as source or system) is refused. Update MariaDB to use them.',
    );
  }
  const nobody = (await lookupUser('nobody').catch(() => null)) ?? { uid: 65534, gid: 65534 };
  if (!nobody.uid) throw new OperationError('NOT_ALLOWED', 'The database client never runs as root');

  const dir = await mkdtemp(path.join(tmpdir(), 'vp-sql-'));
  try {
    const options = path.join(dir, 'client.cnf');
    const lines = ['[client]', `user=${user}`, `password=${password}`, ...(await connectionOptions(ctx.policy))];
    await writeFile(options, `${lines.join('\n')}\n`, { mode: 0o600 });
    if (process.getuid?.() === 0) {
      await chown(dir, nobody.uid, nobody.gid);
      await chown(options, nobody.uid, nobody.gid);
    }
    const settings = [`SET SESSION sql_select_limit = ${MAX_RESULT_ROWS + 1};`];
    if (path.basename(client) === 'mariadb') settings.push(`SET SESSION max_statement_time = ${MAX_STATEMENT_SECONDS};`);
    const args = [
      `--defaults-file=${options}`,
      `--database=${database}`,
      '--batch',
      '--xml',
      '-vv',
      '--default-character-set=utf8mb4',
      '--connect-timeout=10',
      ...(sandbox ? ['--sandbox'] : []),
    ];
    const result = await ctx.run(client, args, {
      input: `${settings.join(' ')}\n${sql}\n`,
      timeoutMs: Math.max(10_000, (ctx.timeoutMs ?? 60_000) - 5_000),
      maxOutputBytes: 8 * 1024 * 1024,
      env: { PATH: DEFAULT_PATH, LANG: 'C.UTF-8', HOME: dir },
      cwd: dir,
      ...(process.getuid?.() === 0 ? { uid: nobody.uid, gid: nobody.gid } : {}),
    });
    if (result.timedOut) throw new OperationError('TIMEOUT', 'The query did not finish in time');
    if (result.error) throw new OperationError('COMMAND_FAILED', `The mysql client could not run: ${result.error.message}`);
    const statements = parseClientOutput(result.stdout ?? '').slice(settings.length);
    const error = result.exitCode === 0 ? null : clientError(result.stderr, 1);
    // The client echoes the statement that failed before it stops.
    const last = statements.at(-1);
    if (error && last?.kind === 'status' && last.affectedRows === null && !last.info) last.kind = 'error';
    if (error && /Access denied|Can't connect|Unknown database/i.test(error.message) && !statements.length) {
      throw new OperationError('DATABASE_COMMAND_FAILED', error.message);
    }
    return { statements, error };
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

// "ERROR 1146 (42S02) at line 3: Table 'shop.x' doesn't exist". Line numbers
// count the settings line the agent adds; `offset` takes it away again.
export function clientError(stderr, offset = 0) {
  const text = `${stderr ?? ''}`.trim().split('\n').filter((l) => !/^Warning:/.test(l)).join('\n') || 'The query failed';
  const match = /^ERROR (\d+)?\s*(?:\(([0-9A-Z]{5})\))?\s*at line (\d+)[^:]*:\s*([\s\S]*)$/m.exec(text);
  if (!match) return { message: text.slice(0, 2000) };
  return {
    code: match[1] ? Number(match[1]) : null,
    sqlState: match[2] ?? null,
    line: Math.max(1, Number(match[3]) - offset),
    message: match[4].trim().slice(0, 2000),
  };
}

// ---- Parsing what the client prints ----------------------------------------

const ENTITIES = { lt: '<', gt: '>', amp: '&', quot: '"', apos: "'" };
export function unescapeXml(text) {
  return text.replace(/&(#x[0-9a-f]+|#\d+|lt|gt|amp|quot|apos);/gi, (whole, name) => {
    if (name[0] === '#') {
      const code = name[1] === 'x' || name[1] === 'X' ? Number.parseInt(name.slice(2), 16) : Number(name.slice(1));
      return Number.isFinite(code) && code <= 0x10ffff ? String.fromCodePoint(code) : whole;
    }
    return ENTITIES[name.toLowerCase()] ?? whole;
  });
}

const ROW = /<row>([\s\S]*?)<\/row>/g;
const FIELD = /<field name="([^"]*)"(?:\s+xsi:nil="true"\s*\/>|\s*\/>|>([\s\S]*?)<\/field>)/g;

function parseResultset(xml, budget) {
  const columns = [];
  const rows = [];
  let truncated = false;
  let first = true;
  for (const [, body] of xml.matchAll(ROW)) {
    const row = [];
    for (const field of body.matchAll(FIELD)) {
      if (first) columns.push(unescapeXml(field[1]));
      const nil = field[2] === undefined;
      let value = nil ? null : unescapeXml(field[2]);
      if (value !== null && value.length > MAX_CELL_LENGTH) {
        value = `${value.slice(0, MAX_CELL_LENGTH)}…`;
        truncated = true;
      }
      row.push(value);
    }
    first = false;
    if (rows.length >= MAX_RESULT_ROWS || budget.left <= 0) {
      truncated = true;
      break;
    }
    budget.left -= row.reduce((n, v) => n + (v?.length ?? 4) + 4, 0);
    rows.push(row);
  }
  return { columns, rows, truncated };
}

// With -vv the client prints each statement between two separator lines,
// then either an XML result set and "N rows in set" or "Query OK, N rows
// affected" with a line of details.
export function parseClientOutput(stdout) {
  const lines = stdout.split('\n');
  const statements = [];
  const budget = { left: MAX_OUTPUT_CHARS };
  let i = 0;
  while (i < lines.length) {
    if (lines[i] !== SEPARATOR) {
      i += 1;
      continue;
    }
    const end = lines.indexOf(SEPARATOR, i + 1);
    if (end < 0) break;
    const statement = { sql: lines.slice(i + 1, end).join('\n').trim() };
    i = end + 1;
    const body = [];
    while (i < lines.length && lines[i] !== SEPARATOR) body.push(lines[i++]);
    const text = body.join('\n');
    const xmlStart = text.indexOf('<resultset');
    if (xmlStart >= 0) {
      const xmlEnd = text.indexOf('</resultset>', xmlStart);
      const xml = text.slice(xmlStart, xmlEnd < 0 ? undefined : xmlEnd);
      Object.assign(statement, { kind: 'rows', ...parseResultset(xml, budget) });
      if (xmlEnd < 0) statement.truncated = true;
    } else {
      const ok = /Query OK, (\d+) rows? affected/.exec(text);
      const info = body.map((l) => l.trim()).filter((l) => l && !/^Query OK|^Bye$/.test(l));
      Object.assign(statement, { kind: 'status', affectedRows: ok ? Number(ok[1]) : null, info: info.join(' ').slice(0, 500) || null });
    }
    statements.push(statement);
  }
  return statements;
}

// ---- Parameters ------------------------------------------------------------

// MariaDB allows almost anything in a table name; it is always quoted with
// ident(), so only length and control characters are checked.
export function checkObjectName(value, field) {
  if (typeof value !== 'string' || value.length < 1 || value.length > 64 || /\p{Cc}/u.test(value) || value !== value.trimEnd()) {
    throw invalid(`${field} must be a table or column name`);
  }
  return value;
}

function checkInteger(value, field, min, max, fallback) {
  const n = value ?? fallback;
  if (!Number.isInteger(n) || n < min || n > max) throw invalid(`${field} must be a whole number from ${min} to ${max}`);
  return n;
}

const rowsOf = (statement) => (statement?.kind === 'rows' ? statement.rows : []);
const records = (statement) => {
  const cols = statement?.columns ?? [];
  return rowsOf(statement).map((row) => Object.fromEntries(cols.map((c, i) => [c, row[i]])));
};
const num = (v) => (v === null || v === undefined || v === '' ? null : Number(v));

function failOn(result) {
  if (result.error) throw new OperationError('DATABASE_QUERY_FAILED', result.error.message);
  return result.statements;
}

export const DATABASE_BROWSER_OPERATIONS = {
  DATABASE_TABLES: {
    async run(params, ctx) {
      onlyKeys(params, ['name']);
      const name = checkDatabaseName(params.name);
      const [tables] = failOn(
        await runAsBrowser(
          ctx,
          name,
          'read',
          'SELECT TABLE_NAME AS name, TABLE_TYPE AS type, ENGINE AS engine, TABLE_ROWS AS row_estimate, DATA_LENGTH AS data_bytes, INDEX_LENGTH AS index_bytes, TABLE_COLLATION AS collation, TABLE_COMMENT AS comment, UPDATE_TIME AS updated_at FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME;',
        ),
      );
      return {
        output: {
          name,
          tables: records(tables).map((t) => ({
            name: t.name,
            type: t.type === 'VIEW' ? 'view' : 'table',
            engine: t.engine,
            rowEstimate: num(t.row_estimate),
            dataBytes: num(t.data_bytes),
            indexBytes: num(t.index_bytes),
            collation: t.collation,
            comment: (t.type !== 'VIEW' && t.comment) || null,
            updatedAt: t.updated_at || null,
          })),
        },
      };
    },
  },

  DATABASE_TABLE_ROWS: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'table', 'page', 'pageSize', 'orderBy', 'order']);
      const name = checkDatabaseName(params.name);
      const table = checkObjectName(params.table, 'table');
      const page = checkInteger(params.page, 'page', 1, 1_000_000, 1);
      const pageSize = checkInteger(params.pageSize, 'pageSize', 1, 500, 50);
      const orderBy = params.orderBy === undefined || params.orderBy === null ? null : checkObjectName(params.orderBy, 'orderBy');
      const order = params.order ?? 'asc';
      if (!['asc', 'desc'].includes(order)) throw invalid('order must be asc or desc');
      const where = `TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ${literal(table)}`;
      const sql = [
        `SELECT COLUMN_NAME AS name, COLUMN_TYPE AS type, IS_NULLABLE AS nullable, COLUMN_KEY AS col_key, COLUMN_DEFAULT AS default_value, EXTRA AS extra, COLUMN_COMMENT AS comment FROM information_schema.COLUMNS WHERE ${where} ORDER BY ORDINAL_POSITION;`,
        `SELECT INDEX_NAME AS name, NON_UNIQUE AS non_unique, COLUMN_NAME AS col, SEQ_IN_INDEX AS seq, INDEX_TYPE AS type FROM information_schema.STATISTICS WHERE ${where} ORDER BY INDEX_NAME, SEQ_IN_INDEX;`,
        `SHOW CREATE TABLE ${ident(table)};`,
        `SELECT * FROM ${ident(table)}${orderBy ? ` ORDER BY ${ident(orderBy)} ${order.toUpperCase()}` : ''} LIMIT ${pageSize + 1} OFFSET ${(page - 1) * pageSize};`,
      ].join('\n');
      const [columns, indexes, create, data] = failOn(await runAsBrowser(ctx, name, 'read', sql));
      const indexMap = new Map();
      for (const ix of records(indexes)) {
        const entry = indexMap.get(ix.name) ?? { name: ix.name, unique: ix.non_unique === '0', type: ix.type, columns: [] };
        entry.columns.push(ix.col);
        indexMap.set(ix.name, entry);
      }
      const createRow = rowsOf(create)[0] ?? [];
      const rows = rowsOf(data);
      return {
        output: {
          name,
          table,
          columns: records(columns).map((c) => ({
            name: c.name,
            type: c.type,
            nullable: c.nullable === 'YES',
            key: c.col_key || null,
            default: c.default_value,
            extra: c.extra || null,
            comment: c.comment || null,
          })),
          indexes: [...indexMap.values()],
          isView: create?.columns?.[0] === 'View',
          createStatement: createRow[1] ?? null,
          page,
          pageSize,
          orderBy,
          order,
          rows: rows.slice(0, pageSize),
          hasMore: rows.length > pageSize,
          truncated: Boolean(data?.truncated),
        },
      };
    },
  },

  DATABASE_QUERY: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'sql', 'allowChanges']);
      const name = checkDatabaseName(params.name);
      const sql = params.sql;
      if (typeof sql !== 'string' || !sql.trim() || sql.length > MAX_SQL_LENGTH) throw invalid(`sql must be 1 to ${MAX_SQL_LENGTH} characters`);
      if (sql.includes('\0')) throw invalid('sql cannot contain NUL characters');
      const allowChanges = params.allowChanges ?? false;
      if (typeof allowChanges !== 'boolean') throw invalid('allowChanges must be true or false');
      const started = Date.now();
      const { statements, error } = await runAsBrowser(ctx, name, allowChanges ? 'write' : 'read', sql);
      if (error && !allowChanges && /command denied/i.test(error.message) && !/^(SELECT|SHOW VIEW) command/i.test(error.message)) {
        error.hint = 'This ran read-only. Turn on "Allow changes" to change data or structure.';
      }
      return {
        output: {
          name,
          allowChanges,
          elapsedMs: Date.now() - started,
          statements: statements.map((s) => ({ ...s, sql: s.sql.slice(0, 2000) })),
          error,
        },
      };
    },
  },
};
