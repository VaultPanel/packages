import http from 'node:http';
import https from 'node:https';
import { chmod, lchown, lstat, mkdir, open, readdir, readFile, rename, rm, stat, symlink, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CUSTOM_CERT_MARKER, findBinary } from '../monitoring/web.js';
import { removeProviderCredentials } from '../services/acmeDns.js';
import { lookupUser, runAsSiteUser } from '../services/siteFiles.js';
import {
  apacheUser,
  checkPhpVersion,
  checkSiteName,
  checkSiteSpec,
  renderApacheSite,
  renderNginxSite,
  renderPhpPool,
  SHARED_NGINX_CONFIG,
  SITE_SPEC_KEYS,
  siteHost,
  sitePaths,
} from '../services/siteConfig.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';

// Website operations: create a site (Linux user, folders, PHP-FPM pool,
// NGINX server block), apply changed settings, delete it, read its logs.
//
// Every change to NGINX is tested with `nginx -t` before NGINX reloads, and
// put back as it was when the test fails, so a bad site never takes the web
// server down. Running an operation twice is safe: each step checks what is
// already there.

// ---- Helpers shared with the SSL and file operations ----------------------

export function requireWebsites(policy) {
  if (policy.allowWebsites === false) throw new OperationError('NOT_ALLOWED', 'Website management is disabled in this agent config');
}

export function lookup(ctx, name) {
  return ctx.lookupUser ? ctx.lookupUser(name) : lookupUser(name, ctx.policy.passwdFile);
}

export function fileRunner(ctx) {
  return ctx.runAsSiteUser ?? runAsSiteUser;
}

// The site's Linux account, refusing accounts that are not a VaultPanel site.
export async function siteAccount(ctx, name, paths) {
  const account = await lookup(ctx, name);
  if (!account) return null;
  if (account.uid === 0 || account.home !== paths.home) {
    throw new OperationError('SITE_USER_CONFLICT', `A Linux user named "${name}" already exists and is not a VaultPanel site (its home is ${account.home}). Choose another site name.`);
  }
  return account;
}

export async function requireSiteAccount(ctx, name, paths) {
  const account = await siteAccount(ctx, name, paths);
  if (!account) throw new OperationError('SITE_NOT_FOUND', `The site "${name}" does not exist on this server yet. Retry creating it from the panel.`);
  return account;
}

async function exists(p) {
  try {
    await lstat(p);
    return true;
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    throw err;
  }
}

async function readIfExists(p) {
  try {
    return await readFile(p, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
}

// Root-owned configuration files only: written beside the target, then renamed.
export async function writeFileAtomic(target, content, mode = 0o644) {
  await mkdir(path.dirname(target), { recursive: true, mode: 0o755 });
  const tmp = `${target}.vp-tmp-${process.pid}`;
  await writeFile(tmp, content, { mode });
  await chmod(tmp, mode);
  await rename(tmp, target);
}

async function restoreFile(target, previous) {
  if (previous === null) await rm(target, { force: true });
  else await writeFileAtomic(target, previous);
}

async function systemctlReloadOrStart(unit, ctx) {
  const active = await ctx.run('systemctl', ['is-active', '--quiet', `${unit}.service`], { timeoutMs: 15_000 });
  const verb = active.exitCode === 0 ? 'reload' : 'start';
  ctx.log('stdout', `$ systemctl ${verb} ${unit}`);
  assertCommandOk(await ctx.run('systemctl', [verb, `${unit}.service`], { timeoutMs: 60_000 }), `systemctl ${verb} ${unit}`);
}

// The kernel lists IPv6 addresses here only when IPv6 is enabled.
async function ipv6Available(ctx) {
  return exists(ctx.policy.ipv6ProcFile ?? '/proc/net/if_inet6');
}

export async function testNginx(ctx) {
  ctx.log('stdout', '$ nginx -t');
  const result = await ctx.run('nginx', ['-t'], { timeoutMs: 30_000 });
  if (result.timedOut || result.error || result.exitCode !== 0) {
    const detail = (result.stderr || result.error?.message || '').trim().split('\n').slice(-6).join('\n');
    return { ok: false, detail };
  }
  return { ok: true };
}

export async function reloadNginx(ctx) {
  await systemctlReloadOrStart('nginx', ctx);
}

export async function requireNginx(ctx) {
  if (!(await findBinary('nginx', ctx.binDirs))) {
    throw new OperationError('NGINX_NOT_INSTALLED', 'NGINX is not installed on this server. Install it from the Web stack card on the server page.');
  }
}

async function ensureSharedConfig(ctx) {
  const { policy } = ctx;
  const shared = path.join(policy.nginxConfD, 'vaultpanel.conf');
  if ((await readIfExists(shared)) !== SHARED_NGINX_CONFIG) await writeFileAtomic(shared, SHARED_NGINX_CONFIG);
  await ensureAcmeWebroot(policy);
}

// The shared Let's Encrypt challenge folder, readable by NGINX all the way
// down. Its parent (/var/lib/vaultpanel) also holds private state such as cron
// locks; if that was created first it is closed (0700), and NGINX answers 403
// for every challenge. The parent only needs to be passable, not listable.
export async function ensureAcmeWebroot(policy) {
  const parent = path.dirname(policy.acmeWebroot);
  const challenge = path.join(policy.acmeWebroot, '.well-known', 'acme-challenge');
  await mkdir(parent, { recursive: true, mode: 0o755 });
  await mkdir(challenge, { recursive: true, mode: 0o755 });
  await addModeBits(parent, 0o011);
  for (const dir of [policy.acmeWebroot, path.dirname(challenge), challenge]) await addModeBits(dir, 0o755);
  return challenge;
}

async function addModeBits(dir, bits) {
  const { mode } = await stat(dir);
  if ((mode & bits) !== bits) await chmod(dir, (mode & 0o7777) | bits);
}

// ---- Site user and folders ------------------------------------------------

export async function ensureSiteUser(ctx, spec, paths) {
  const { policy } = ctx;
  let account = await siteAccount(ctx, spec.name, paths);
  if (!account) {
    ctx.log('stdout', `$ useradd ${spec.name}`);
    assertCommandOk(
      await ctx.run('useradd', ['--home-dir', paths.home, '--no-create-home', '--shell', '/usr/sbin/nologin', '--user-group', spec.name], { timeoutMs: 30_000 }),
      'useradd',
    );
    account = await lookup(ctx, spec.name);
    if (!account) throw new OperationError('COMMAND_FAILED', `useradd did not create the user ${spec.name}`);
  } else {
    ctx.log('stdout', `User ${spec.name} already exists`);
  }

  // The sites root belongs to root, so only the agent creates home folders.
  await mkdir(policy.sitesRoot, { recursive: true, mode: 0o755 });
  try {
    await mkdir(paths.home, { mode: 0o750 });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
  const info = await lstat(paths.home);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new OperationError('SITE_USER_CONFLICT', `${paths.home} exists and is not a folder`);
  await (ctx.chown ?? lchown)(paths.home, account.uid, account.gid);
  await chmod(paths.home, 0o750);

  // NGINX reads the site's files through the site's group.
  if (policy.webServerUser && (await lookup(ctx, policy.webServerUser))) {
    assertCommandOk(await ctx.run('usermod', ['--append', '--groups', spec.name, policy.webServerUser], { timeoutMs: 30_000 }), 'usermod');
  }
  return account;
}

function placeholderPage(spec) {
  const domain = spec.domains[0];
  const where = `${spec.documentRoot}/`;
  if (spec.type === 'proxy') return null;
  if (spec.type === 'php') {
    return {
      name: 'index.php',
      content: `<!doctype html>\n<meta charset="utf-8">\n<title>${domain}</title>\n<h1>${domain} is ready</h1>\n<p>Running PHP <?php echo PHP_VERSION; ?>. Replace this page by uploading your files to ${where} with the VaultPanel file manager.</p>\n`,
    };
  }
  return {
    name: 'index.html',
    content: `<!doctype html>\n<meta charset="utf-8">\n<title>${domain}</title>\n<h1>${domain} is ready</h1>\n<p>Replace this page by uploading your files to ${where} with the VaultPanel file manager.</p>\n`,
  };
}

async function ensureFolders(ctx, spec, paths, account, { placeholder }) {
  return fileRunner(ctx)(
    account,
    { action: 'init', home: paths.home, documentRoot: spec.documentRoot, folders: ['tmp', 'logs'], indexFile: placeholder ? placeholderPage(spec) : null },
    { timeoutMs: 30_000 },
  );
}

// ---- PHP-FPM ----------------------------------------------------------------

async function poolVersions(ctx, name) {
  let versions;
  try {
    versions = (await readdir(ctx.policy.phpConfRoot)).filter((v) => /^[5-9]\.[0-9]$/.test(v));
  } catch {
    return [];
  }
  const found = [];
  for (const version of versions) {
    if (await exists(sitePaths(ctx.policy, name).phpPool(version))) found.push(version);
  }
  return found;
}

async function removePools(ctx, name, keepVersion = null) {
  const paths = sitePaths(ctx.policy, name);
  for (const version of await poolVersions(ctx, name)) {
    if (version === keepVersion) continue;
    ctx.log('stdout', `Removing the PHP ${version} pool of ${name}`);
    await rm(paths.phpPool(version), { force: true });
    const reload = await ctx.run('systemctl', ['reload', `php${version}-fpm.service`], { timeoutMs: 60_000 });
    if (reload.exitCode !== 0) ctx.log('stderr', `php${version}-fpm did not reload: ${(reload.stderr || '').trim()}`);
  }
}

async function syncPhpPool(ctx, spec, paths) {
  await removePools(ctx, spec.name, spec.type === 'php' ? spec.phpVersion : null);
  if (spec.type !== 'php') return null;
  const version = spec.phpVersion;
  if (!(await exists(path.join(ctx.policy.phpConfRoot, version, 'fpm', 'pool.d')))) {
    throw new OperationError('PHP_NOT_INSTALLED', `PHP ${version} with PHP-FPM is not installed on this server. Install PHP from the Web stack card on the server page, or pick an installed version.`);
  }
  const poolFile = paths.phpPool(version);
  const previous = await readIfExists(poolFile);
  const next = renderPhpPool(spec, paths, ctx.policy);
  if (previous !== next) {
    ctx.log('stdout', `Writing PHP ${version} pool ${poolFile}`);
    await writeFileAtomic(poolFile, next);
    const test = await ctx.run(`php-fpm${version}`, ['-t'], { timeoutMs: 30_000 });
    if (test.timedOut || test.error || test.exitCode !== 0) {
      await restoreFile(poolFile, previous);
      throw new OperationError('PHP_CONFIG_INVALID', `PHP-FPM rejected the pool, so it was put back: ${(test.stderr || test.error?.message || '').trim().slice(-800)}`);
    }
  }
  await systemctlReloadOrStart(`php${version}-fpm`, ctx);
  return poolFile;
}

// ---- Apache (.htaccess) -------------------------------------------------

async function apacheTest(ctx) {
  ctx.log('stdout', '$ apache2ctl configtest');
  const result = await ctx.run('apache2ctl', ['configtest'], { timeoutMs: 30_000 });
  if (result.timedOut || result.error || result.exitCode !== 0) {
    return { ok: false, detail: (result.stderr || result.error?.message || '').trim().split('\n').slice(-6).join('\n') };
  }
  return { ok: true };
}

// Writes, or removes, the Apache side of a site with .htaccess files on.
// Apache's user is in the site's group only while .htaccess files are on, so
// it can read that site's files and no others.
export async function syncApache(ctx, spec, paths) {
  const user = apacheUser(ctx.policy);
  const present = await exists(paths.apacheAvailable);
  if (!spec.htaccess) {
    if (!present && !(await exists(paths.apacheEnabled))) return null;
    ctx.log('stdout', '.htaccess files are off: removing the Apache site');
    await rm(paths.apacheEnabled, { force: true });
    await rm(paths.apacheAvailable, { force: true });
    await ctx.run('gpasswd', ['--delete', user, spec.name], { timeoutMs: 30_000 });
    if ((await findBinary('apache2', ctx.binDirs)) && (await apacheTest(ctx)).ok) await systemctlReloadOrStart('apache2', ctx);
    return null;
  }
  if (!(await findBinary('apache2', ctx.binDirs)) || !(await lookup(ctx, user))) {
    throw new OperationError('APACHE_NOT_INSTALLED', '.htaccess files need Apache. Install it from the Web stack card on the server page.');
  }
  assertCommandOk(await ctx.run('usermod', ['--append', '--groups', spec.name, user], { timeoutMs: 30_000 }), 'usermod');
  const previous = await readIfExists(paths.apacheAvailable);
  const next = renderApacheSite(spec, paths, ctx.policy);
  if (previous === next && (await exists(paths.apacheEnabled))) return paths.apacheAvailable;
  ctx.log('stdout', `Writing ${paths.apacheAvailable}`);
  await writeFileAtomic(paths.apacheAvailable, next);
  if (!(await exists(paths.apacheEnabled))) {
    await mkdir(path.dirname(paths.apacheEnabled), { recursive: true });
    await symlink(paths.apacheAvailable, paths.apacheEnabled);
  }
  const test = await apacheTest(ctx);
  if (!test.ok) {
    await restoreFile(paths.apacheAvailable, previous);
    if (previous === null) await rm(paths.apacheEnabled, { force: true });
    throw new OperationError('APACHE_CONFIG_INVALID', `Apache rejected the site's configuration, so the previous one was put back: ${test.detail}`);
  }
  await systemctlReloadOrStart('apache2', ctx);
  return paths.apacheAvailable;
}

// ---- NGINX --------------------------------------------------------------

// Writes the site's server block, enables or disables it, tests the whole
// NGINX configuration and reloads. On a failed test everything is put back.
export async function applyNginxConfig(ctx, spec, paths) {
  await ensureSharedConfig(ctx);
  const previous = { config: await readIfExists(paths.nginxAvailable), linked: await exists(paths.nginxEnabled) };
  const next = renderNginxSite(spec, paths, ctx.policy, { ipv6: await ipv6Available(ctx) });
  ctx.log('stdout', `Writing ${paths.nginxAvailable}`);
  await writeFileAtomic(paths.nginxAvailable, next);
  await setLink(paths, spec.enabled);
  ctx.log('stdout', spec.enabled ? 'Site enabled' : 'Site disabled: NGINX no longer serves it');

  const test = await testNginx(ctx);
  if (!test.ok) {
    await restoreFile(paths.nginxAvailable, previous.config);
    await setLink(paths, previous.linked && previous.config !== null);
    throw new OperationError('NGINX_CONFIG_INVALID', `NGINX rejected the configuration, so the previous one was put back: ${test.detail}`);
  }
  await reloadNginx(ctx);
  return paths.nginxAvailable;
}

async function setLink(paths, enabled) {
  const linked = await exists(paths.nginxEnabled);
  if (enabled && !linked) {
    await mkdir(path.dirname(paths.nginxEnabled), { recursive: true });
    await symlink(paths.nginxAvailable, paths.nginxEnabled);
  } else if (!enabled && linked) {
    await unlink(paths.nginxEnabled);
  }
}

// ---- Health check -------------------------------------------------------

export function httpCheck({ port, host, https: secure, timeoutMs = 8000 }) {
  return new Promise((resolve) => {
    const lib = secure ? https : http;
    const req = lib.request(
      {
        host: '127.0.0.1',
        port,
        path: '/',
        method: 'GET',
        headers: { Host: host, 'User-Agent': 'VaultPanel-HealthCheck' },
        servername: secure ? host : undefined,
        // The check is about the site answering, not about the certificate
        // (staging certificates are not trusted).
        rejectUnauthorized: false,
        timeout: timeoutMs,
      },
      (res) => {
        res.resume();
        resolve({ status: res.statusCode, location: res.headers.location ?? null });
      },
    );
    req.on('timeout', () => req.destroy(new Error(`no answer within ${timeoutMs / 1000} seconds`)));
    req.on('error', (err) => resolve({ error: err.message }));
    req.end();
  });
}

// Asks NGINX on this server for the site's front page.
export async function checkSiteHealth(ctx, spec) {
  if (!spec.enabled) return { ok: true, skipped: true, message: 'Site is disabled' };
  const secure = spec.ssl && spec.forceHttps;
  const host = siteHost(spec.domains);
  const url = `${secure ? 'https' : 'http'}://${host}/`;
  // A reload returns before NGINX's new workers take over; checking straight
  // away can reach an old worker still serving the previous configuration.
  const settleMs = ctx.healthSettleMs ?? (ctx.httpCheck ? 0 : 1500);
  if (settleMs) await new Promise((r) => setTimeout(r, settleMs));
  const reply = await (ctx.httpCheck ?? httpCheck)({ port: secure ? 443 : 80, host, https: secure });
  let result;
  if (reply.error) result = { ok: false, status: null, message: `NGINX did not answer: ${reply.error}` };
  else if (reply.status >= 500) {
    const why =
      spec.type === 'proxy' && [502, 504].includes(reply.status)
        ? `No app is answering on port ${spec.proxyPort} yet. Start your app on that port.`
        : spec.type === 'php' && [502, 504].includes(reply.status)
          ? 'PHP-FPM is not answering for this site.'
          : 'The site answered with a server error.';
    result = { ok: false, status: reply.status, message: `HTTP ${reply.status}. ${why}` };
  } else result = { ok: true, status: reply.status, message: `HTTP ${reply.status}` };
  ctx.log(result.ok ? 'stdout' : 'stderr', `Health check ${url}: ${result.message}`);
  return { url, checkedAt: new Date().toISOString(), ...result };
}

// ---- Logs -----------------------------------------------------------------

export async function tailFile(file, lines, maxBytes = 1024 * 1024) {
  let handle;
  try {
    handle = await open(file, 'r');
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
  try {
    const { size } = await handle.stat();
    const length = Math.min(size, maxBytes);
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, size - length);
    const all = buffer.toString('utf8').split('\n').filter(Boolean);
    // The first line may be cut when the file was longer than maxBytes.
    if (length < size) all.shift();
    return all.slice(-lines).map((line) => line.slice(0, 4000));
  } finally {
    await handle.close();
  }
}

// ---- Operations ---------------------------------------------------------

export const SITE_OPERATIONS = {
  CREATE_SITE: {
    async run(params, ctx) {
      onlyKeys(params, SITE_SPEC_KEYS);
      const spec = checkSiteSpec(params);
      requireWebsites(ctx.policy);
      await requireNginx(ctx);
      const paths = sitePaths(ctx.policy, spec.name);
      const account = await ensureSiteUser(ctx, spec, paths);
      ctx.log('stdout', `Creating folders in ${paths.home}`);
      const folders = await ensureFolders(ctx, spec, paths, account, { placeholder: true });
      if (folders.created) ctx.log('stdout', `Added a placeholder page at ${folders.created}`);
      // Apache first: with .htaccess on, the PHP socket belongs to its user.
      const apacheConfig = await syncApache(ctx, spec, paths);
      const phpPool = await syncPhpPool(ctx, spec, paths);
      const nginxConfig = await applyNginxConfig(ctx, spec, paths);
      const health = await checkSiteHealth(ctx, spec);
      ctx.webInventory?.invalidate();
      return {
        output: {
          site: { name: spec.name, user: account.name, home: paths.home, documentRoot: path.join(paths.home, spec.documentRoot) },
          nginxConfig,
          apacheConfig,
          phpPool,
          logs: { access: paths.accessLog, error: paths.errorLog },
          health,
        },
      };
    },
  },

  CREATE_NGINX_CONFIG: {
    async run(params, ctx) {
      onlyKeys(params, SITE_SPEC_KEYS);
      const spec = checkSiteSpec(params);
      requireWebsites(ctx.policy);
      await requireNginx(ctx);
      const paths = sitePaths(ctx.policy, spec.name);
      const account = await requireSiteAccount(ctx, spec.name, paths);
      await ensureFolders(ctx, spec, paths, account, { placeholder: false });
      // Apache first: with .htaccess on, the PHP socket belongs to its user.
      const apacheConfig = await syncApache(ctx, spec, paths);
      const phpPool = await syncPhpPool(ctx, spec, paths);
      const nginxConfig = await applyNginxConfig(ctx, spec, paths);
      const health = await checkSiteHealth(ctx, spec);
      return { output: { nginxConfig, apacheConfig, phpPool, enabled: spec.enabled, ssl: spec.ssl, health } };
    },
  },

  DELETE_SITE: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'phpVersion', 'removeFiles']);
      const name = checkSiteName(params.name);
      if (params.phpVersion !== undefined) checkPhpVersion(params.phpVersion);
      const removeFiles = params.removeFiles ?? false;
      if (typeof removeFiles !== 'boolean') throw new OperationError('INVALID_PARAMS', 'removeFiles must be true or false');
      requireWebsites(ctx.policy);
      const paths = sitePaths(ctx.policy, name);
      const account = await siteAccount(ctx, name, paths);

      // 1. Stop serving it.
      const hadConfig = (await exists(paths.nginxEnabled)) || (await exists(paths.nginxAvailable));
      await rm(paths.nginxEnabled, { force: true });
      await rm(paths.nginxAvailable, { force: true });
      if (hadConfig && (await findBinary('nginx', ctx.binDirs))) {
        const test = await testNginx(ctx);
        if (test.ok) await reloadNginx(ctx);
        else ctx.log('stderr', `NGINX was not reloaded because its configuration has another problem: ${test.detail}`);
      }
      // 2. Its Apache site and PHP pools.
      await syncApache(ctx, { name, htaccess: false }, paths);
      await removePools(ctx, name);
      // 3. Its certificate.
      if (await exists(path.join(paths.certDir, CUSTOM_CERT_MARKER))) {
        ctx.log('stdout', `Removing the uploaded certificate in ${paths.certDir}`);
        await rm(paths.certDir, { recursive: true, force: true });
      } else if ((await exists(paths.certDir)) && (await findBinary('certbot', ctx.binDirs))) {
        ctx.log('stdout', `$ certbot delete --cert-name ${paths.certName}`);
        const result = await ctx.run('certbot', ['delete', '--cert-name', paths.certName, '--non-interactive'], { timeoutMs: 60_000, onLine: ctx.log });
        if (result.exitCode !== 0) ctx.log('stderr', 'Certbot could not delete the certificate; it will expire on its own');
      }
      await removeProviderCredentials(ctx.policy, paths.certName);
      // 4. Files and user, only when asked.
      let filesRemoved = false;
      if (removeFiles) {
        if (account) {
          ctx.log('stdout', `Removing the files in ${paths.home}`);
          await fileRunner(ctx)(account, { action: 'clear', home: paths.home }, { timeoutMs: ctx.timeoutMs });
          // No process may keep running as the user once it is gone.
          await ctx.run('pkill', ['--signal', 'KILL', '--uid', name], { timeoutMs: 15_000 });
          ctx.log('stdout', `$ userdel ${name}`);
          assertCommandOk(await ctx.run('userdel', [name], { timeoutMs: 30_000 }), 'userdel');
        }
        if (await exists(paths.home)) {
          const info = await lstat(paths.home);
          if (info.isDirectory() && !info.isSymbolicLink()) await rm(paths.home, { recursive: true, force: true });
        }
        for (const log of [paths.accessLog, paths.errorLog, paths.apacheAccessLog, paths.apacheErrorLog]) await rm(log, { force: true });
        filesRemoved = true;
      } else if (account) {
        ctx.log('stdout', `Files and the user ${name} were kept in ${paths.home}. Creating a site with the same name uses them again.`);
      }
      ctx.webInventory?.invalidate();
      return { output: { name, filesRemoved, home: paths.home } };
    },
  },

  SITE_LOGS: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'log', 'lines']);
      const name = checkSiteName(params.name);
      if (!['access', 'error'].includes(params.log)) throw new OperationError('INVALID_PARAMS', 'log must be access or error');
      const lines = params.lines ?? 200;
      if (!Number.isInteger(lines) || lines < 10 || lines > 2000) throw new OperationError('INVALID_PARAMS', 'lines must be an integer from 10 to 2000');
      const paths = sitePaths(ctx.policy, name);
      const file = params.log === 'access' ? paths.accessLog : paths.errorLog;
      const entries = await tailFile(file, lines);
      return { output: { log: params.log, file, lines: entries ?? [], missing: entries === null } };
    },
  },
};
