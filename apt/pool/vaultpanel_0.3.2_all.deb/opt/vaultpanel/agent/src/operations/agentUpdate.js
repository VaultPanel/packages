import { createHash } from 'node:crypto';
import { chmod, cp, mkdir, mkdtemp, readdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { AGENT_VERSION } from '../utils/version.js';
import { assertCommandOk, onlyKeys, OperationError } from './errors.js';

// Where this agent's code is (the folder holding package.json and src/).
export const AGENT_ROOT = path.resolve(fileURLToPath(new URL('../../', import.meta.url)));

const VERSION_PATTERN = /^\d+\.\d+\.\d+$/;
const SHA256_PATTERN = /^[0-9a-f]{64}$/;
const MAX_PACKAGE_BYTES = 50 * 1024 * 1024;

// Installs a new version of this agent (phase 7). The panel names the
// version, size and SHA-256 of the package it serves, inside the signed job;
// the package itself is downloaded from the panel and must match all three.
// The new code is checked to start before it replaces the old one, which is
// kept next to it as <install dir>.previous. After the result is reported the
// agent exits and systemd starts the new version.
export const AGENT_UPDATE_OPERATIONS = {
  AGENT_UPDATE: {
    async run(params, ctx) {
      onlyKeys(params, ['version', 'sha256', 'size']);
      const { version, sha256, size } = params;
      if (typeof version !== 'string' || !VERSION_PATTERN.test(version)) throw new OperationError('INVALID_PARAMS', 'version must be like 0.7.0');
      if (typeof sha256 !== 'string' || !SHA256_PATTERN.test(sha256)) throw new OperationError('INVALID_PARAMS', 'sha256 must be a SHA-256 hash');
      if (!Number.isInteger(size) || size < 1 || size > MAX_PACKAGE_BYTES) throw new OperationError('INVALID_PARAMS', 'size must be the package size in bytes');
      if (ctx.policy.allowSelfUpdate === false) throw new OperationError('NOT_ALLOWED', 'Updating the agent from the panel is disabled in this agent config');

      const installDir = path.resolve(ctx.policy.agentInstallDir ?? '/opt/vaultpanel-agent');
      const runningFrom = path.resolve(ctx.agentRoot ?? AGENT_ROOT);
      if (runningFrom !== installDir) {
        throw new OperationError(
          'NOT_INSTALLED',
          `This agent runs from ${runningFrom}, not from ${installDir} where the install script puts it, so it cannot update itself. Update it by hand.`,
        );
      }
      const current = ctx.currentVersion ?? AGENT_VERSION;
      if (current === version) {
        ctx.log('stdout', `The agent is already on v${version}`);
        return { output: { updated: false, version } };
      }

      ctx.log('stdout', `Downloading agent v${version} from the panel`);
      let pkg;
      try {
        pkg = await ctx.panel.downloadAgentPackage({ maxBytes: size });
      } catch (err) {
        throw new OperationError('DOWNLOAD_FAILED', `Could not download the agent package: ${err.message}`);
      }
      const digest = createHash('sha256').update(pkg).digest('hex');
      if (pkg.length !== size || digest !== sha256) {
        throw new OperationError(
          'PACKAGE_MISMATCH',
          'The downloaded package is not the one this update was for (its size or hash differs). The panel may have been updated since; start the update again.',
        );
      }
      ctx.log('stdout', `Package verified (${size} bytes, sha256 ${digest.slice(0, 12)}…)`);

      const work = await mkdtemp(path.join(ctx.policy.agentUpdateTmpDir ?? tmpdir(), 'vaultpanel-agent-update-'));
      try {
        const archive = path.join(work, 'agent.tgz');
        const extractDir = path.join(work, 'extract');
        await writeFile(archive, pkg, { mode: 0o600 });
        await mkdir(extractDir, { mode: 0o700 });
        assertCommandOk(
          await ctx.run('tar', ['-xzf', archive, '-C', extractDir, '--no-same-owner'], { timeoutMs: 60_000 }),
          'Unpacking the agent',
        );
        const extracted = path.join(extractDir, 'agent');
        const manifest = await readJson(path.join(extracted, 'package.json'));
        if (manifest?.name !== '@vaultpanel/agent' || manifest.version !== version) {
          throw new OperationError('PACKAGE_MISMATCH', `The package holds ${manifest?.name ?? 'something else'} v${manifest?.version ?? '?'}, not agent v${version}`);
        }
        if (!(await exists(path.join(extracted, 'src/cli.js')))) throw new OperationError('PACKAGE_MISMATCH', 'The package has no agent program in it');

        // The new code must at least load before it replaces the old one.
        const check = await ctx.run(ctx.nodeBin ?? process.execPath, [path.join(extracted, 'src/cli.js'), 'version'], { timeoutMs: 30_000 });
        assertCommandOk(check, 'Starting the new agent');
        if (check.stdout.trim() !== version) {
          throw new OperationError('PACKAGE_MISMATCH', `The new agent reports v${check.stdout.trim() || '?'}, not v${version}`);
        }

        const staging = `${installDir}.new`;
        const previous = `${installDir}.previous`;
        await rm(staging, { recursive: true, force: true });
        await cp(extracted, staging, { recursive: true });
        await makeReadable(staging);
        await rm(previous, { recursive: true, force: true });
        await rename(installDir, previous);
        try {
          await rename(staging, installDir);
        } catch (err) {
          await rename(previous, installDir);
          throw new OperationError('INSTALL_FAILED', `Could not put the new agent in place: ${err.message}`);
        }
        ctx.log('stdout', `Installed v${version} in ${installDir}; v${current} is kept in ${previous}`);
        ctx.log('stdout', 'The agent restarts with the new version a few seconds after this result is reported');
      } finally {
        await rm(work, { recursive: true, force: true });
      }
      return {
        output: { updated: true, from: current, version },
        // systemd (Restart=always) starts the agent again, now the new version.
        after: async () => (ctx.exit ?? defaultExit)(),
      };
    },
  },
};

function defaultExit() {
  process.exit(0);
}

// Everyone may read the agent's code and only root may change it: the agent
// runs as its own user and the file manager's worker as each site's user.
// The package keeps the modes of the panel's files, which may be stricter.
async function makeReadable(dir) {
  await chmod(dir, 0o755);
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await makeReadable(full);
    else if (entry.isFile()) await chmod(full, (await stat(full)).mode & 0o111 ? 0o755 : 0o644);
  }
}

async function readJson(file) {
  try {
    return JSON.parse(await readFile(file, 'utf8'));
  } catch {
    return null;
  }
}

async function exists(file) {
  try {
    await stat(file);
    return true;
  } catch {
    return false;
  }
}
