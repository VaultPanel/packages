import { lstat, mkdir, readdir, rename, rm, statfs } from 'node:fs/promises';
import { open } from 'node:fs/promises';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import {
  BACKUP_AGENT_KINDS,
  BACKUP_ID_PATTERN,
  SHA256_PATTERN,
  STORAGE_ACCESS_KEY_PATTERN,
  STORAGE_BUCKET_PATTERN,
  STORAGE_KEY_MAX_LENGTH,
  STORAGE_KEY_PATTERN,
  STORAGE_REGION_PATTERN,
  STORAGE_SECRET_PATTERN,
  SFTP_HOST_PATTERN,
  SFTP_KNOWN_HOSTS_PATTERN,
  SFTP_PATH_PATTERN,
  SFTP_PRIVATE_KEY_PATTERN,
  SFTP_USER_PATTERN,
  checkStorageEndpoint,
} from '../security/automationRules.js';
import { APP_PORT_MAX, APP_PORT_MIN } from '../security/appRules.js';
import { appPaths } from '../services/appConfig.js';
import { checkSiteName, sitePaths } from '../services/siteConfig.js';
import { DEFAULT_PATH } from '../utils/exec.js';
import { createS3Client } from '../utils/s3.js';
import { createSftpClient } from '../utils/sftp.js';
import { hashFile, pipeFromFile, pipeToFile } from '../utils/stream.js';
import { healthCheck, startOrRestart, systemctl, unitState } from './apps.js';
import { checkDatabaseName, ident, literal, mysqlClient, mysqlArgs, requireDatabases, runSql } from './databases.js';
import { onlyKeys, OperationError } from './errors.js';
import { fileRunner, requireSiteAccount } from './sites.js';

// Backups of websites, apps and databases, kept on the server under
// backupRoot (root only, mode 700):
//
//   <backupRoot>/site/<name>/<id>.tar.gz       the site's home folder
//   <backupRoot>/app/<name>/<id>.tar.gz        the app's home folder (live release only)
//   <backupRoot>/database/<name>/<id>.sql.gz   mariadb-dump of the database
//
// Files are archived and unpacked by tar running as the site's or app's own
// user, so a backup can only read, and a restore only write, what that user
// could anyway. The agent (root) only moves the compressed stream between
// tar and the backup file. A restore checks the file's SHA-256 against the
// one recorded when it was made, and can first take a safety copy of the
// current state.
//
// Backups can also be copied to S3-compatible storage (Amazon S3, Backblaze
// B2, Wasabi, MinIO…) or to another server over SFTP. The panel sends the destination, credentials
// included, with each job that needs it; the agent keeps none of it. Once the
// copy is confirmed the local file is removed unless keepLocal is set. A
// restore or download of a backup that is only in the storage fetches it
// back first and checks its SHA-256 the same way.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);
const BACKUP_KEYS = ['backupId', 'kind', 'name'];
// Left out of website and app backups, and left as they are on a restore.
const SITE_KEEP = ['tmp', 'logs'];
const APP_KEEP = ['tmp', 'logs', '.pm2'];
// Bytes sent per upload request (base64 in JSON, within the panel's body limit).
export const UPLOAD_CHUNK_BYTES = 2 * 1024 * 1024;

export function requireBackups(policy) {
  if (policy.allowBackups === false) throw new OperationError('NOT_ALLOWED', 'Backups are disabled in this agent config');
}

export function checkBackupTarget(params) {
  const { backupId, kind, name } = params;
  if (typeof backupId !== 'string' || !BACKUP_ID_PATTERN.test(backupId)) throw invalid('backupId must be a backup id');
  if (!BACKUP_AGENT_KINDS.includes(kind)) throw invalid(`kind must be one of ${BACKUP_AGENT_KINDS.join(', ')}`);
  if (kind === 'database') checkDatabaseName(name);
  else checkSiteName(name);
  return { backupId, kind, name };
}

export function backupFile(policy, { kind, name, backupId }) {
  const dir = path.join(policy.backupRoot, kind, name);
  return { dir, file: path.join(dir, `${backupId}.${kind === 'database' ? 'sql.gz' : 'tar.gz'}`) };
}

// Creates <backupRoot>/<kind>/<name> as root-only folders, refusing links.
async function ensureBackupDir(policy, dir) {
  const parts = path.relative(policy.backupRoot, dir).split(path.sep);
  let current = policy.backupRoot;
  await mkdir(current, { recursive: true, mode: 0o700 });
  for (const part of ['', ...parts]) {
    current = part ? path.join(current, part) : current;
    try {
      await mkdir(current, { mode: 0o700 });
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
    }
    const info = await lstat(current);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new OperationError('BACKUP_DIR_INVALID', `${current} is not a folder`);
  }
}

async function requireFreeSpace(policy) {
  if (!policy.backupMinFreeBytes) return;
  let stats;
  try {
    stats = await statfs(policy.backupRoot);
  } catch {
    return;
  }
  const free = Number(stats.bavail) * Number(stats.bsize);
  if (free < policy.backupMinFreeBytes) {
    throw new OperationError('BACKUP_DISK_FULL', `Only ${Math.round(free / 1024 / 1024)} MB is free where backups are kept (${policy.backupRoot}). Free some space or delete old backups first.`);
  }
}

async function exists(p) {
  try {
    await lstat(p);
    return true;
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    throw err;
  }
}

const mb = (bytes) => `${(bytes / 1024 / 1024).toFixed(bytes < 10 * 1024 * 1024 ? 2 : 1)} MB`;

function lastLines(text, count = 6) {
  return (text ?? '').trim().split('\n').slice(-count).join('\n');
}

function pipes(ctx) {
  return { toFile: ctx.pipeToFile ?? pipeToFile, fromFile: ctx.pipeFromFile ?? pipeFromFile };
}

function tarBinary(ctx) {
  return ctx.tarBinary ?? 'tar';
}

// The account and home folder of the site or app a backup is for.
async function homeOf(ctx, kind, name) {
  const paths = kind === 'app' ? appPaths(ctx.policy, name) : sitePaths(ctx.policy, name);
  const account = await requireSiteAccount(ctx, name, paths);
  return { paths, account, home: paths.home };
}

// For an app: the release "current" points at, and tar exclusions for the
// other releases (they can be deployed again from Git).
async function appReleases(ctx, account, home) {
  const run = fileRunner(ctx);
  const link = await run(account, { action: 'readlink', home, path: 'current' }, { timeoutMs: 30_000 });
  const current = link.target?.startsWith('releases/') ? link.target.slice('releases/'.length) : null;
  const all = await readdir(path.join(home, 'releases')).catch(() => []);
  return { releaseId: current, others: all.filter((id) => id !== current) };
}

// Writes one backup and returns what the panel records about it.
export async function writeBackup(ctx, { backupId, kind, name }) {
  requireBackups(ctx.policy);
  const { dir, file } = backupFile(ctx.policy, { kind, name, backupId });
  await ensureBackupDir(ctx.policy, dir);
  await requireFreeSpace(ctx.policy);
  if (await exists(file)) throw new OperationError('BACKUP_EXISTS', `A backup with id ${backupId} already exists`);
  const partial = `${file}.partial`;
  await rm(partial, { force: true });
  const { toFile } = pipes(ctx);
  const timeoutMs = ctx.timeoutMs ?? 3_600_000;
  let result;
  let releaseId = null;

  if (kind === 'database') {
    requireDatabases(ctx.policy);
    checkDatabaseName(name);
    const found = await runSql(ctx, [`SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ${literal(name)};`], { log: false });
    if (!found.length) throw new OperationError('DATABASE_NOT_FOUND', `The database ${name} does not exist on this server`);
    const dump = (await findBinary('mariadb-dump', ctx.binDirs)) ?? (await findBinary('mysqldump', ctx.binDirs));
    if (!dump) throw new OperationError('DATABASE_SERVER_NOT_INSTALLED', 'mariadb-dump is not installed on this server. Install MariaDB from the Software card on the server page.');
    const args = [...mysqlArgs(ctx.policy), '--single-transaction', '--quick', '--routines', '--triggers', '--events', '--hex-blob', '--default-character-set=utf8mb4', name];
    ctx.log('stdout', `$ ${path.basename(dump)} ${args.filter((a) => !a.startsWith('--defaults')).join(' ')} | gzip > ${file}`);
    result = await toFile(dump, args, { target: partial, timeoutMs, onLine: ctx.log });
  } else {
    const { account, home } = await homeOf(ctx, kind, name);
    const keep = kind === 'app' ? APP_KEEP : SITE_KEEP;
    const exclude = keep.map((n) => `--exclude=./${n}`);
    if (kind === 'app') {
      const releases = await appReleases(ctx, account, home);
      releaseId = releases.releaseId;
      exclude.push(...releases.others.map((id) => `--exclude=./releases/${id}`));
      ctx.log('stdout', releaseId ? `Live release: ${releaseId} (${releases.others.length} older release${releases.others.length === 1 ? '' : 's'} left out)` : 'The app has no live release yet');
    }
    const args = ['--create', '--file=-', `--directory=${home}`, '--warning=no-file-changed', '--warning=no-file-removed', '--warning=no-file-ignored', ...exclude, '.'];
    ctx.log('stdout', `$ tar --create --directory=${home} ${exclude.join(' ')} . | gzip > ${file}  (as ${name})`);
    result = await toFile(tarBinary(ctx), args, {
      target: partial,
      timeoutMs,
      onLine: ctx.log,
      uid: account.uid,
      gid: account.gid,
      cwd: home,
      env: { PATH: DEFAULT_PATH, LANG: 'C.UTF-8', HOME: home },
    });
    // tar exits 1 when files changed while it read them: the backup is still usable.
    if (result.exitCode === 1 && !result.streamError) {
      ctx.log('stderr', 'Some files changed while they were being backed up; they are saved as they were at that moment');
      result.exitCode = 0;
    }
  }

  const failed = result.timedOut || result.error || result.streamError || result.exitCode !== 0;
  if (failed) {
    await rm(partial, { force: true });
    if (result.timedOut) throw new OperationError('TIMEOUT', 'The backup did not finish in time');
    if (result.streamError?.code === 'ENOSPC') throw new OperationError('BACKUP_DISK_FULL', `The disk filled up while writing the backup to ${ctx.policy.backupRoot}`);
    const detail = lastLines(result.stderr) || result.error?.message || result.streamError?.message || `exit code ${result.exitCode}`;
    throw new OperationError('BACKUP_FAILED', `The backup could not be written: ${detail}`);
  }
  await rename(partial, file);
  ctx.log('stdout', `Wrote ${mb(result.sizeBytes)} to ${file}`);
  ctx.log('stdout', `SHA-256 ${result.sha256}`);
  ctx.webInventory?.invalidate();
  return { backupId, kind, name, path: file, sizeBytes: result.sizeBytes, sha256: result.sha256, releaseId, createdAt: new Date().toISOString() };
}

// ---- Storage ------------------------------------------------------------------

// The S3-compatible destination of a job, checked as strictly as the panel does.
export function checkStorage(raw, { needKey = true } = {}) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw invalid('storage must be an object');
  if (raw.type === 'sftp') return checkSftpStorage(raw, { needKey });
  onlyKeys(raw, ['type', 'endpoint', 'region', 'bucket', 'accessKeyId', 'secretAccessKey', 'pathStyle', 'key', 'keepLocal']);
  if (raw.type !== 's3') throw invalid('storage.type must be s3');
  const url = checkStorageEndpoint(raw.endpoint);
  if (!url) throw invalid('storage.endpoint must be an http(s) address with no path');
  if (typeof raw.region !== 'string' || !STORAGE_REGION_PATTERN.test(raw.region)) throw invalid('storage.region must be a region name');
  if (typeof raw.bucket !== 'string' || !STORAGE_BUCKET_PATTERN.test(raw.bucket)) throw invalid('storage.bucket must be a bucket name');
  if (typeof raw.accessKeyId !== 'string' || !STORAGE_ACCESS_KEY_PATTERN.test(raw.accessKeyId)) throw invalid('storage.accessKeyId must be an access key ID');
  if (typeof raw.secretAccessKey !== 'string' || !STORAGE_SECRET_PATTERN.test(raw.secretAccessKey)) throw invalid('storage.secretAccessKey must be a secret key');
  if (raw.pathStyle !== undefined && typeof raw.pathStyle !== 'boolean') throw invalid('storage.pathStyle must be true or false');
  if (raw.keepLocal !== undefined && typeof raw.keepLocal !== 'boolean') throw invalid('storage.keepLocal must be true or false');
  if (needKey || raw.key !== undefined) {
    if (typeof raw.key !== 'string' || raw.key.length > STORAGE_KEY_MAX_LENGTH || !STORAGE_KEY_PATTERN.test(raw.key)) throw invalid('storage.key must be an object key');
  }
  return {
    type: 's3',
    endpoint: url.origin,
    region: raw.region,
    bucket: raw.bucket,
    accessKeyId: raw.accessKeyId,
    secretAccessKey: raw.secretAccessKey,
    pathStyle: raw.pathStyle ?? false,
    key: raw.key ?? null,
    keepLocal: raw.keepLocal ?? false,
  };
}

// knownHosts may be missing only for a storage check, which then reads and
// pins it; every other call refuses to connect without it (utils/sftp.js).
function checkSftpStorage(raw, { needKey }) {
  onlyKeys(raw, ['type', 'host', 'port', 'username', 'privateKey', 'knownHosts', 'path', 'key', 'keepLocal']);
  if (typeof raw.host !== 'string' || !SFTP_HOST_PATTERN.test(raw.host)) throw invalid('storage.host must be a host name or IP address');
  if (!Number.isInteger(raw.port) || raw.port < 1 || raw.port > 65535) throw invalid('storage.port must be a port');
  if (typeof raw.username !== 'string' || !SFTP_USER_PATTERN.test(raw.username)) throw invalid('storage.username must be a user name');
  if (typeof raw.privateKey !== 'string' || !SFTP_PRIVATE_KEY_PATTERN.test(raw.privateKey)) throw invalid('storage.privateKey must be an OpenSSH private key');
  if (raw.knownHosts !== undefined && (typeof raw.knownHosts !== 'string' || !SFTP_KNOWN_HOSTS_PATTERN.test(raw.knownHosts))) throw invalid('storage.knownHosts must be known_hosts lines');
  if (raw.path !== undefined && raw.path !== '' && (typeof raw.path !== 'string' || !SFTP_PATH_PATTERN.test(raw.path))) throw invalid('storage.path must be a folder');
  if (raw.keepLocal !== undefined && typeof raw.keepLocal !== 'boolean') throw invalid('storage.keepLocal must be true or false');
  if (needKey || raw.key !== undefined) {
    if (typeof raw.key !== 'string' || raw.key.length > STORAGE_KEY_MAX_LENGTH || !STORAGE_KEY_PATTERN.test(raw.key)) throw invalid('storage.key must be a file path');
  }
  return {
    type: 'sftp',
    host: raw.host,
    port: raw.port,
    username: raw.username,
    privateKey: raw.privateKey,
    knownHosts: raw.knownHosts ?? null,
    path: raw.path ?? '',
    key: raw.key ?? null,
    keepLocal: raw.keepLocal ?? false,
  };
}

function s3For(ctx, storage) {
  if (storage.type === 'sftp') return (ctx.createSftpClient ?? createSftpClient)(storage, { run: ctx.run, binDirs: ctx.binDirs, timeoutMs: ctx.timeoutMs ?? 3_600_000 });
  return (ctx.createS3Client ?? createS3Client)(storage);
}

const where = (storage) => (storage.type === 'sftp' ? `${storage.username}@${storage.host}${storage.path ? `:${storage.path}` : ''}` : `${storage.bucket} at ${new URL(storage.endpoint).host}`);

// Copies a finished backup to the storage and confirms it is there.
async function copyToStorage(ctx, storage, backup) {
  const s3 = s3For(ctx, storage);
  ctx.log('stdout', `Copying ${mb(backup.sizeBytes)} to ${where(storage)} as ${storage.key}`);
  let lastReport = 0;
  await s3.uploadFile(storage.key, backup.path, {
    sizeBytes: backup.sizeBytes,
    sha256: backup.sha256,
    onProgress: (sent) => {
      if (sent - lastReport >= 256 * 1024 * 1024 && sent < backup.sizeBytes) {
        ctx.log('stdout', `Copied ${mb(sent)} of ${mb(backup.sizeBytes)}`);
        lastReport = sent;
      }
    },
  });
  const head = await s3.headObject(storage.key);
  if (!head.exists || head.sizeBytes !== backup.sizeBytes) {
    throw new OperationError('STORAGE_UPLOAD_FAILED', `The storage does not hold the whole backup after the upload (${head.exists ? mb(head.sizeBytes) : 'nothing'} of ${mb(backup.sizeBytes)})`);
  }
  ctx.log('stdout', 'The storage confirmed the copy');
}

// The backup's file on this server, fetched from the storage first when
// it is only there. release() removes a fetched copy again.
async function backupFileFor(ctx, target, sha256, storage) {
  const { dir, file } = backupFile(ctx.policy, target);
  if (!storage || (await exists(file))) {
    const found = await requireBackupFile(ctx, target, sha256);
    return { ...found, release: async () => {} };
  }
  await ensureBackupDir(ctx.policy, dir);
  await requireFreeSpace(ctx.policy);
  const partial = `${file}.download`;
  ctx.log('stdout', `Fetching the backup from ${where(storage)} (${storage.key})`);
  let got;
  try {
    got = await s3For(ctx, storage).downloadFile(storage.key, partial);
  } catch (err) {
    await rm(partial, { force: true });
    throw storageError(err, 'STORAGE_DOWNLOAD_FAILED', 'The backup could not be fetched from the storage');
  }
  if (got.sha256 !== sha256) {
    await rm(partial, { force: true });
    throw new OperationError('BACKUP_CORRUPT', `The copy in the storage does not match the backup’s checksum (expected ${sha256.slice(0, 12)}…, found ${got.sha256.slice(0, 12)}…), so it is not used.`);
  }
  await rename(partial, file);
  ctx.log('stdout', `Fetched ${mb(got.sizeBytes)}; checksum matches`);
  return {
    file,
    sizeBytes: got.sizeBytes,
    release: async () => {
      if (storage.keepLocal) return;
      await rm(file, { force: true });
      ctx.webInventory?.invalidate();
    },
  };
}

function storageError(err, code, prefix) {
  if (err instanceof OperationError) return err;
  return new OperationError(code, `${prefix}: ${err.message}`);
}

async function requireBackupFile(ctx, target, sha256) {
  const { file } = backupFile(ctx.policy, target);
  let info;
  try {
    info = await lstat(file);
  } catch (err) {
    if (err.code === 'ENOENT') throw new OperationError('BACKUP_NOT_FOUND', `The backup file ${file} is no longer on this server`);
    throw err;
  }
  if (!info.isFile()) throw new OperationError('BACKUP_NOT_FOUND', `${file} is not a regular file`);
  if (sha256) {
    ctx.log('stdout', `Checking ${file} (${mb(info.size)})`);
    const actual = await (ctx.hashFile ?? hashFile)(file);
    if (actual.sha256 !== sha256) {
      throw new OperationError('BACKUP_CORRUPT', `The backup file does not match its checksum (expected ${sha256.slice(0, 12)}…, found ${actual.sha256.slice(0, 12)}…). It was changed or damaged after it was made, so it is not used.`);
    }
    ctx.log('stdout', 'Checksum matches');
  }
  return { file, sizeBytes: info.size };
}

async function restoreFiles(ctx, { backupId, kind, name }, file) {
  const { account, home, paths } = await homeOf(ctx, kind, name);
  const run = fileRunner(ctx);
  const fs = (request, timeoutMs = 300_000) => run(account, { ...request, home }, { timeoutMs });
  const staging = `.vp-restore-${backupId.slice(0, 8)}`;
  for (const leftover of [staging, `${staging}-old`]) {
    await fs({ action: 'delete', path: leftover }).catch((err) => {
      if (err.code !== 'FILE_NOT_FOUND') throw err;
    });
  }
  await fs({ action: 'mkdir', path: staging });
  const { fromFile } = pipes(ctx);
  ctx.log('stdout', `$ tar --extract --directory=${path.join(home, staging)}  (as ${name})`);
  const result = await fromFile(tarBinary(ctx), ['--extract', '--file=-', `--directory=${path.join(home, staging)}`, '--preserve-permissions', '--no-same-owner'], {
    source: file,
    timeoutMs: ctx.timeoutMs ?? 3_600_000,
    onLine: ctx.log,
    uid: account.uid,
    gid: account.gid,
    cwd: home,
    env: { PATH: DEFAULT_PATH, LANG: 'C.UTF-8', HOME: home },
  });
  if (result.timedOut || result.error || result.streamError || result.exitCode !== 0) {
    await fs({ action: 'delete', path: staging }).catch(() => {});
    if (result.timedOut) throw new OperationError('TIMEOUT', 'Unpacking the backup did not finish in time');
    const detail = lastLines(result.stderr) || result.error?.message || result.streamError?.message || `exit code ${result.exitCode}`;
    throw new OperationError('RESTORE_FAILED', `The backup could not be unpacked: ${detail}. Nothing was changed.`);
  }

  let stopped = false;
  if (kind === 'app' && (await unitState(ctx, paths)).exists) {
    ctx.log('stdout', `$ systemctl stop ${paths.unitName}`);
    await systemctl(ctx, ['stop', `${paths.unitName}.service`]);
    stopped = true;
  }
  const keep = kind === 'app' ? APP_KEEP : SITE_KEEP;
  ctx.log('stdout', `Replacing the files in ${home} with the backup${keep.length ? ` (${keep.join(', ')} kept as they are)` : ''}`);
  const swap = await fs({ action: 'restoreSwap', staging, keep, merge: kind === 'app' ? ['releases'] : [] });
  ctx.log('stdout', `Restored ${swap.restored} item${swap.restored === 1 ? '' : 's'}; removing the replaced files`);
  for (const leftover of [swap.old, staging]) {
    await fs({ action: 'delete', path: leftover }).catch((err) => ctx.log('stderr', `Could not remove ${leftover}: ${err.message}`));
  }
  return { account, paths, stopped };
}

async function restoreDatabase(ctx, { name }, file) {
  requireDatabases(ctx.policy);
  const client = await mysqlClient(ctx);
  // Recreating the database removes tables made since the backup. Access
  // granted to users is kept (it is stored apart from the database).
  await runSql(ctx, [`DROP DATABASE IF EXISTS ${ident(name)};`, `CREATE DATABASE ${ident(name)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`]);
  const { fromFile } = pipes(ctx);
  const args = [...mysqlArgs(ctx.policy), '--batch', name];
  ctx.log('stdout', `$ gunzip < ${file} | ${path.basename(client)} ${name}`);
  const result = await fromFile(client, args, { source: file, timeoutMs: ctx.timeoutMs ?? 3_600_000, onLine: ctx.log });
  if (result.timedOut || result.error || result.streamError || result.exitCode !== 0) {
    if (result.timedOut) throw new OperationError('TIMEOUT', 'The import did not finish in time; the database is only partly restored');
    const detail = lastLines(result.stderr) || result.error?.message || result.streamError?.message || `exit code ${result.exitCode}`;
    throw new OperationError('RESTORE_FAILED', `The import failed, so the database is only partly restored: ${detail}`);
  }
  ctx.webInventory?.invalidate();
}

function checkRestoreParams(params) {
  onlyKeys(params, [...BACKUP_KEYS, 'sha256', 'safetyBackupId', 'port', 'healthCheckSeconds', 'storage']);
  const target = checkBackupTarget(params);
  if (typeof params.sha256 !== 'string' || !SHA256_PATTERN.test(params.sha256)) throw invalid('sha256 must be a SHA-256 checksum');
  if (params.safetyBackupId !== undefined && (typeof params.safetyBackupId !== 'string' || !BACKUP_ID_PATTERN.test(params.safetyBackupId) || params.safetyBackupId === params.backupId)) {
    throw invalid('safetyBackupId must be another backup id');
  }
  if (params.port !== undefined && (!Number.isInteger(params.port) || params.port < APP_PORT_MIN || params.port > APP_PORT_MAX)) throw invalid('port must be an app port');
  const seconds = params.healthCheckSeconds ?? 30;
  if (!Number.isInteger(seconds) || seconds < 5 || seconds > 300) throw invalid('healthCheckSeconds must be from 5 to 300');
  const storage = params.storage === undefined ? null : checkStorage(params.storage);
  return { ...target, sha256: params.sha256, safetyBackupId: params.safetyBackupId ?? null, port: params.port ?? null, healthCheckSeconds: seconds, storage };
}

export const BACKUP_OPERATIONS = {
  CREATE_BACKUP: {
    async run(params, ctx) {
      onlyKeys(params, [...BACKUP_KEYS, 'storage']);
      const target = checkBackupTarget(params);
      const storage = params.storage === undefined ? null : checkStorage(params.storage);
      const backup = await writeBackup(ctx, target);
      if (!storage) return { output: { ...backup, localKept: true, stored: null } };
      try {
        await copyToStorage(ctx, storage, backup);
      } catch (err) {
        // The backup itself is good: it stays on the server, and the panel
        // records it with the reason the copy failed.
        const error = new OperationError('STORAGE_UPLOAD_FAILED', `The backup was saved on this server, but copying it to the storage failed: ${err.message}`);
        error.output = { ...backup, localKept: true, stored: null, storageError: { code: err.code ?? 'STORAGE_UPLOAD_FAILED', message: err.message } };
        throw error;
      }
      let localKept = true;
      if (!storage.keepLocal) {
        await rm(backup.path, { force: true });
        localKept = false;
        ctx.log('stdout', `Removed the copy on this server (${backup.path}); the backup is kept in the storage only`);
        ctx.webInventory?.invalidate();
      }
      return { output: { ...backup, path: localKept ? backup.path : null, localKept, stored: { key: storage.key } } };
    },
  },

  RESTORE_BACKUP: {
    async run(params, ctx) {
      const spec = checkRestoreParams(params);
      requireBackups(ctx.policy);
      const source = await backupFileFor(ctx, spec, spec.sha256, spec.storage);
      const { file } = source;

      let safetyBackup = null;
      if (spec.safetyBackupId) {
        ctx.log('stdout', 'Taking a safety copy of the current state first');
        try {
          safetyBackup = await writeBackup(ctx, { backupId: spec.safetyBackupId, kind: spec.kind, name: spec.name });
        } catch (err) {
          const error = new OperationError('SAFETY_BACKUP_FAILED', `The safety copy failed, so nothing was restored: ${err.message}`);
          error.output = { safetyBackup: null, safetyError: { code: err.code ?? 'BACKUP_FAILED', message: err.message } };
          await source.release();
          throw error;
        }
      }

      try {
        let releaseId = null;
        let health = null;
        if (spec.kind === 'database') {
          await restoreDatabase(ctx, spec, file);
        } else {
          const { account, paths, stopped } = await restoreFiles(ctx, spec, file);
          if (spec.kind === 'app') {
            const link = await fileRunner(ctx)(account, { action: 'readlink', home: paths.home, path: 'current' }, { timeoutMs: 30_000 });
            releaseId = link.target?.startsWith('releases/') ? link.target.slice('releases/'.length) : null;
            if (stopped && releaseId) {
              await startOrRestart(ctx, paths);
              health = await healthCheck(ctx, account, paths, spec.name, spec.port, spec.healthCheckSeconds);
              ctx.log(health.ok ? 'stdout' : 'stderr', health.message);
              if (!health.ok) throw new OperationError('HEALTH_CHECK_FAILED', `The files were restored but the app did not start: ${health.message}`);
            } else if (stopped) {
              ctx.log('stderr', 'The backup has no live release, so the app was left stopped. Deploy it to start it again.');
            }
          }
        }
        ctx.log('stdout', 'Restore finished');
        return { output: { restored: true, kind: spec.kind, name: spec.name, releaseId, health, safetyBackup } };
      } catch (err) {
        if (safetyBackup && err instanceof OperationError) {
          err.message = `${err.message} A safety copy of the state before the restore was saved.`;
          err.output = { safetyBackup };
        }
        throw err;
      } finally {
        await source.release();
      }
    },
  },

  DELETE_BACKUP: {
    async run(params, ctx) {
      onlyKeys(params, [...BACKUP_KEYS, 'storage']);
      const target = checkBackupTarget(params);
      const storage = params.storage === undefined ? null : checkStorage(params.storage);
      requireBackups(ctx.policy);
      if (storage) {
        ctx.log('stdout', `Deleting ${storage.key} from ${where(storage)}`);
        try {
          await s3For(ctx, storage).deleteObject(storage.key);
        } catch (err) {
          throw storageError(err, 'STORAGE_DELETE_FAILED', 'The backup could not be deleted from the storage');
        }
      }
      const { file } = backupFile(ctx.policy, target);
      const existed = await exists(file);
      await rm(file, { force: true });
      await rm(`${file}.partial`, { force: true });
      await rm(`${file}.download`, { force: true });
      if (existed || !storage) ctx.log('stdout', existed ? `Deleted ${file}` : `${file} was already gone`);
      ctx.webInventory?.invalidate();
      return { output: { deleted: existed || Boolean(storage), path: file, stored: storage ? { key: storage.key } : null } };
    },
  },

  // Sends the backup file to the panel in chunks, so it can be downloaded.
  UPLOAD_BACKUP: {
    async run(params, ctx) {
      onlyKeys(params, [...BACKUP_KEYS, 'sha256', 'storage']);
      const target = checkBackupTarget(params);
      if (typeof params.sha256 !== 'string' || !SHA256_PATTERN.test(params.sha256)) throw invalid('sha256 must be a SHA-256 checksum');
      const storage = params.storage === undefined ? null : checkStorage(params.storage);
      requireBackups(ctx.policy);
      if (!ctx.panel?.uploadBackupChunk) throw new OperationError('UNSUPPORTED_OPERATION', 'Uploading needs the panel connection');
      const source = await backupFileFor(ctx, target, params.sha256, storage);
      const { file, sizeBytes } = source;
      ctx.log('stdout', `Sending ${mb(sizeBytes)} to the panel`);
      const handle = await open(file, 'r');
      let offset = 0;
      let lastReport = 0;
      try {
        const buffer = Buffer.alloc(UPLOAD_CHUNK_BYTES);
        for (;;) {
          const { bytesRead } = await handle.read(buffer, 0, UPLOAD_CHUNK_BYTES, offset);
          const final = offset + bytesRead >= sizeBytes;
          await ctx.panel.uploadBackupChunk(target.backupId, { offset, data: buffer.subarray(0, bytesRead).toString('base64'), final });
          offset += bytesRead;
          if (offset - lastReport >= 50 * 1024 * 1024 || final) {
            ctx.log('stdout', `Sent ${mb(offset)} of ${mb(sizeBytes)}`);
            lastReport = offset;
          }
          if (final || bytesRead === 0) break;
        }
      } finally {
        await handle.close();
        await source.release();
      }
      return { output: { sizeBytes: offset, sha256: params.sha256 } };
    },
  },

  // Writes a small file to the storage, reads it back and deletes it, so a
  // destination can be checked before backups rely on it.
  TEST_BACKUP_STORAGE: {
    async run(params, ctx) {
      onlyKeys(params, ['storage']);
      const storage = checkStorage(params.storage);
      requireBackups(ctx.policy);
      let hostKey = null;
      if (storage.type === 'sftp' && !storage.knownHosts) {
        ctx.log('stdout', `Reading the host key of ${storage.host} (port ${storage.port})`);
        try {
          hostKey = await s3For(ctx, storage).scanHostKey();
        } catch (err) {
          throw storageError(err, 'STORAGE_TEST_FAILED', 'Reading the server’s host key failed');
        }
        storage.knownHosts = hostKey.knownHosts;
        ctx.log('stdout', `Host key ${hostKey.fingerprint}: the panel will trust only this key from now on`);
      }
      const s3 = s3For(ctx, storage);
      const body = Buffer.from(`VaultPanel storage check ${new Date().toISOString()}\n`);
      const steps = [];
      const step = async (label, fn) => {
        ctx.log('stdout', label);
        try {
          await fn();
          steps.push({ label, ok: true });
        } catch (err) {
          steps.push({ label, ok: false, message: err.message });
          throw storageError(err, 'STORAGE_TEST_FAILED', `${label} failed`);
        }
      };
      await step(`Writing ${storage.key} to ${where(storage)}`, () => s3.putObject(storage.key, body));
      await step('Reading it back', async () => {
        const res = await s3.getObject(storage.key);
        if (res.body !== body.toString('utf8')) throw new OperationError('STORAGE_TEST_FAILED', 'The storage returned different content than was written');
      });
      await step('Deleting it', () => s3.deleteObject(storage.key));
      ctx.log('stdout', 'The storage works: backups can be written, read and deleted');
      return { output: { ok: true, steps, ...(hostKey ? { hostKey } : {}) } };
    },
  },
};

// Backup files on this server, for the heartbeat: { id, sizeBytes } each.
export async function scanBackups(policy, limit = 5000) {
  const found = [];
  for (const kind of BACKUP_AGENT_KINDS) {
    let names;
    try {
      names = await readdir(path.join(policy.backupRoot, kind));
    } catch {
      continue;
    }
    for (const name of names) {
      let files;
      try {
        files = await readdir(path.join(policy.backupRoot, kind, name), { withFileTypes: true });
      } catch {
        continue;
      }
      for (const entry of files) {
        const match = /^([0-9a-f-]{36})\.(?:tar|sql)\.gz$/.exec(entry.name);
        if (!entry.isFile() || !match || !BACKUP_ID_PATTERN.test(match[1])) continue;
        try {
          const info = await lstat(path.join(policy.backupRoot, kind, name, entry.name));
          found.push({ id: match[1], sizeBytes: info.size });
        } catch {
          // removed meanwhile
        }
        if (found.length >= limit) return found;
      }
    }
  }
  return found;
}
