import { createPrivateKey, randomBytes, X509Certificate } from 'node:crypto';
import http from 'node:http';
import { chmod, lstat, mkdir, readdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CUSTOM_CERT_MARKER, describeCertificate, findBinary, readCertificate } from '../monitoring/web.js';
import { ensureAcmeHook, removeProviderCredentials, requireAcmeZone, stageProviderCredentials } from '../services/acmeDns.js';
import { checkDnsProvider, DNS_PROVIDER_LABELS } from '../services/dnsProviders.js';
import { checkSiteName, checkSiteSpec, SITE_SPEC_KEYS, sitePaths } from '../services/siteConfig.js';
import { certificateCovers, DOMAIN_PATTERN, EMAIL_PATTERN, isWildcardDomain } from '../security/webRules.js';
import { onlyKeys, OperationError } from './errors.js';
import { applyNginxConfig, checkSiteHealth, ensureAcmeWebroot, reloadNginx, requireNginx, requireSiteAccount, requireWebsites, writeFileAtomic } from './sites.js';

// SSL certificates from Let's Encrypt through Certbot's webroot method. The
// site's NGINX block always serves /.well-known/acme-challenge/ from a shared
// folder, so issuing works the same for static, PHP and proxied sites.
// Wildcard certificates (*.example.com) use Let's Encrypt's DNS check instead,
// through the DNS zone this server serves for the domain (services/acmeDns.js).
// A certificate bought elsewhere can be installed too (INSTALL_SSL_CERT); it
// lives where Certbot's would, marked so nothing tries to renew it.
// Certbot's own timer renews certificates (kept on by the agent, and the
// panel renews due ones itself if it does not); a deploy hook reloads NGINX
// after. How early they renew is renew_before_expiry in each certificate's
// renewal file, set from the panel.

const invalid = (message) => new OperationError('INVALID_PARAMS', message);

const RELOAD_HOOK = '#!/bin/sh\n# Installed by VaultPanel: load renewed certificates.\nsystemctl reload nginx\n';
export const RELOAD_HOOK_NAME = 'vaultpanel-reload-nginx';

async function requireCertbot(ctx) {
  if (!(await findBinary('certbot', ctx.binDirs))) {
    throw new OperationError('CERTBOT_NOT_INSTALLED', 'Certbot is not installed on this server. Install it from the Web stack card on the server page.');
  }
}

async function ensureRenewalHook(ctx) {
  const hook = path.join(ctx.policy.letsencryptDir, 'renewal-hooks', 'deploy', RELOAD_HOOK_NAME);
  let current = null;
  try {
    current = await readFile(hook, 'utf8');
  } catch {
    // not there yet
  }
  if (current !== RELOAD_HOOK) {
    await writeFileAtomic(hook, RELOAD_HOOK, 0o755);
    await chmod(hook, 0o755);
  }
}

// Certbot's renewal timer: certbot.timer from the apt package, or
// snap.certbot.renew.timer from the snap. Turned on when it is off; a masked
// timer is left alone (someone turned it off on purpose).
export const RENEWAL_TIMERS = ['certbot.timer', 'snap.certbot.renew.timer'];

export async function ensureRenewalTimer(ctx) {
  for (const unit of RENEWAL_TIMERS) {
    const state = await ctx.run('systemctl', ['is-enabled', unit], { timeoutMs: 15_000 });
    const word = String(state.stdout ?? '').trim();
    if (word === 'masked' || word === 'masked-runtime') {
      ctx.log('stderr', `${unit} is masked, so Certbot does not renew on its own here; the panel renews due certificates instead`);
      return { unit, enabled: false, masked: true };
    }
    if (word === 'disabled') {
      ctx.log('stdout', `$ systemctl enable --now ${unit}`);
      assertOk(await ctx.run('systemctl', ['enable', '--now', unit], { timeoutMs: 60_000 }), `systemctl enable --now ${unit}`);
      return { unit, enabled: true, turnedOn: true };
    }
    if (state.exitCode !== 0) continue; // not installed this way
    const active = await ctx.run('systemctl', ['is-active', '--quiet', unit], { timeoutMs: 15_000 });
    if (active.exitCode !== 0) {
      ctx.log('stdout', `$ systemctl start ${unit}`);
      assertOk(await ctx.run('systemctl', ['start', unit], { timeoutMs: 60_000 }), `systemctl start ${unit}`);
      return { unit, enabled: true, turnedOn: true };
    }
    return { unit, enabled: true };
  }
  ctx.log('stderr', 'No Certbot renewal timer on this server; the panel renews due certificates instead');
  return null;
}

function assertOk(result, what) {
  if (result.timedOut || result.error || result.exitCode !== 0) {
    throw new OperationError('COMMAND_FAILED', `${what} failed: ${String(result.stderr || result.error || `exit code ${result.exitCode}`).trim().slice(0, 300)}`);
  }
}

export const RENEW_BEFORE_MIN = 7;
export const RENEW_BEFORE_MAX = 60;

function checkRenewBefore(value) {
  if (value === undefined) return undefined;
  if (!Number.isInteger(value) || value < RENEW_BEFORE_MIN || value > RENEW_BEFORE_MAX) {
    throw new OperationError('INVALID_PARAMS', `renewBeforeDays must be a whole number from ${RENEW_BEFORE_MIN} to ${RENEW_BEFORE_MAX}`);
  }
  return value;
}

// Writes renew_before_expiry into the certificate's renewal file. Never more
// than two thirds of the certificate's lifetime: a longer window would make
// Certbot renew on every run and hit Let's Encrypt's limits.
export async function setRenewBefore(ctx, certName, days) {
  const file = path.join(ctx.policy.letsencryptDir, 'renewal', `${certName}.conf`);
  let text;
  try {
    text = await readFile(file, 'utf8');
  } catch {
    return null;
  }
  const cert = await readCertificate(path.join(ctx.policy.letsencryptDir, 'live', certName));
  const lifetime = cert ? Math.round((Date.parse(cert.notAfter) - Date.parse(cert.notBefore)) / 86_400_000) : 90;
  const effective = Math.max(1, Math.min(days, Math.floor((lifetime * 2) / 3)));
  const line = `renew_before_expiry = ${effective} days`;
  const lines = text.split('\n');
  const section = lines.findIndex((l) => /^\s*\[/.test(l));
  const head = section < 0 ? lines.length : section;
  const at = lines.slice(0, head).findIndex((l) => /^\s*#?\s*renew_before_expiry\s*=/.test(l));
  if (at >= 0) lines[at] = line;
  else lines.unshift(line);
  const next = lines.join('\n');
  if (next !== text) await writeFileAtomic(file, next, 0o644);
  return { certName, renewBeforeDays: effective };
}

// Fetches a URL from the internet's point of view: DNS as everyone sees it.
// With host, asks this server's own NGINX for that site instead.
export function fetchChallenge(url, { host, timeoutMs = 8000 } = {}) {
  return new Promise((resolve) => {
    const headers = { 'User-Agent': 'VaultPanel-DomainCheck', ...(host ? { Host: host } : {}) };
    const req = http.get(url, { timeout: timeoutMs, headers }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        if (body.length < 1000) body += chunk;
      });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('timeout', () => req.destroy(new Error(`no answer within ${timeoutMs / 1000} seconds`)));
    req.on('error', (err) => resolve({ error: err.code === 'ENOTFOUND' ? 'the domain does not resolve in DNS' : err.message }));
  });
}

// Before asking Let's Encrypt (which limits failed attempts), checks that
// every domain reaches this server over HTTP: a token placed in the challenge
// folder must come back from http://<domain>/.well-known/acme-challenge/.
async function verifyDomainsReachThisServer(ctx, domains) {
  const token = `vp-check-${randomBytes(12).toString('hex')}`;
  const dir = await ensureAcmeWebroot(ctx.policy);
  const file = path.join(dir, token);
  await writeFile(file, token, { mode: 0o644 });
  await chmod(file, 0o644);
  const fetch = ctx.fetchChallenge ?? fetchChallenge;
  const path_ = `/.well-known/acme-challenge/${token}`;
  try {
    // First this server's own NGINX: if it cannot serve the file, the problem
    // is here, not in DNS.
    const local = await fetch(`http://127.0.0.1${path_}`, { host: domains[0] });
    if (local.error || local.status !== 200 || local.body.trim() !== token) {
      const what = local.error ? `could not be reached (${local.error})` : `answered HTTP ${local.status}`;
      throw new OperationError(
        'ACME_NOT_SERVED',
        `NGINX on this server ${what} when asked for the Let’s Encrypt check file of ${domains[0]}, so no certificate was requested. Check that NGINX is running and that ${ctx.policy.acmeWebroot} is readable by ${ctx.policy.webServerUser ?? 'www-data'} (run nginx -t and look in /var/log/nginx/error.log).`,
      );
    }
    const failures = [];
    for (const domain of domains) {
      const reply = await fetch(`http://${domain}${path_}`);
      if (reply.error) failures.push(`${domain}: ${reply.error}`);
      else if (reply.status !== 200 || reply.body.trim() !== token) failures.push(`${domain}: answered HTTP ${reply.status}, but this server serves the check file, so the domain points somewhere else (another server, or a proxy such as a CDN in front)`);
      else ctx.log('stdout', `${domain} reaches this server`);
    }
    if (failures.length) {
      throw new OperationError(
        'DOMAIN_NOT_REACHABLE',
        `Some domains do not point to this server yet, so no certificate was requested:\n${failures.join('\n')}\nPoint their DNS A/AAAA records at this server, wait for DNS to update, and make sure port 80 is open.`,
      );
    }
  } finally {
    await rm(file, { force: true });
  }
}

function certbotFailure(result) {
  const lines = `${result.stderr}\n${result.stdout}`.split('\n').map((l) => l.trim()).filter(Boolean);
  const useful = lines.filter((l) => /error|detail|problem|limit|failed|unauthorized|timeout|dns|connection/i.test(l));
  return (useful.length ? useful : lines).slice(-8).join('\n') || `certbot exited with code ${result.exitCode}`;
}


// ---- Certificates someone uploads ----------------------------------------

const MAX_CERT_PEM = 64 * 1024;
const MAX_KEY_PEM = 16 * 1024;
const certInvalid = (code, message) => new OperationError(code, message);

// Checks an uploaded certificate (with its chain) and private key: they
// belong together, the certificate is valid now and covers every domain of
// the site, and the chain is in order. Returns the files to write.
export function parseCustomCertificate(certificatePem, keyPem, domains, now = Date.now()) {
  if (typeof certificatePem !== 'string' || !certificatePem.length || certificatePem.length > MAX_CERT_PEM) throw invalid(`certificate must be PEM text of up to ${MAX_CERT_PEM / 1024} KB`);
  if (typeof keyPem !== 'string' || !keyPem.length || keyPem.length > MAX_KEY_PEM) throw invalid(`privateKey must be PEM text of up to ${MAX_KEY_PEM / 1024} KB`);
  const blocks = certificatePem.match(/-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----/g);
  if (!blocks || blocks.length > 10) throw certInvalid('CERT_INVALID', 'Paste the certificate as PEM text (-----BEGIN CERTIFICATE----- ...), followed by its intermediate certificates');
  let certs;
  try {
    certs = blocks.map((b) => new X509Certificate(b));
  } catch {
    throw certInvalid('CERT_INVALID', 'One of the certificates could not be read');
  }
  if (/ENCRYPTED/.test(keyPem)) throw certInvalid('CERT_KEY_ENCRYPTED', 'The private key has a passphrase. Remove it first (openssl pkey -in key.pem -out plain.pem) and upload the plain key.');
  let key;
  try {
    key = createPrivateKey(keyPem);
  } catch {
    throw certInvalid('CERT_INVALID', 'The private key could not be read. Paste it as PEM text (-----BEGIN PRIVATE KEY----- ...).');
  }
  const leaf = certs[0];
  if (!leaf.checkPrivateKey(key)) throw certInvalid('CERT_KEY_MISMATCH', 'The private key does not belong to the certificate');
  if (Date.parse(leaf.validTo) <= now) throw certInvalid('CERT_EXPIRED', `The certificate expired on ${new Date(leaf.validTo).toISOString().slice(0, 10)}`);
  if (Date.parse(leaf.validFrom) > now + 86_400_000) throw certInvalid('CERT_NOT_YET_VALID', `The certificate is valid only from ${new Date(leaf.validFrom).toISOString().slice(0, 10)}`);
  for (let i = 0; i + 1 < certs.length; i += 1) {
    if (!certs[i].checkIssued(certs[i + 1]) || !certs[i].verify(certs[i + 1].publicKey)) {
      throw certInvalid('CERT_CHAIN_INVALID', `Certificate ${i + 2} did not issue certificate ${i + 1}. Put the site's certificate first, then each intermediate in order.`);
    }
  }
  const info = describeCertificate(blocks[0]);
  const missing = domains.filter((d) => !certificateCovers(info.domains, d));
  if (missing.length) throw certInvalid('CERT_DOMAIN_MISMATCH', `The certificate does not cover ${missing.join(', ')} (it covers ${info.domains.join(', ') || 'no domain names'})`);
  const pem = (list) => (list.length ? `${list.join('\n')}\n` : '');
  return {
    cert: pem(blocks.slice(0, 1)),
    chain: pem(blocks.slice(1)),
    fullchain: pem(blocks),
    key: key.export({ type: 'pkcs8', format: 'pem' }),
    info,
    intermediates: blocks.length - 1,
  };
}

const exists = (p) => lstat(p).then(() => true, () => false);

export async function isCustomCertificate(certDir) {
  return exists(path.join(certDir, CUSTOM_CERT_MARKER));
}

// Moves a site's certificate files aside (Certbot's live, archive and
// renewal entries, or an uploaded certificate), so a new one can take its
// place and the old one can come back if that fails.
async function moveCertificateAside(ctx, paths) {
  const le = ctx.policy.letsencryptDir;
  const dir = path.join(le, 'vaultpanel-replaced', `${paths.certName}-${Date.now()}`);
  const items = [
    [paths.certDir, 'live'],
    [path.join(le, 'archive', paths.certName), 'archive'],
    [path.join(le, 'renewal', `${paths.certName}.conf`), 'renewal.conf'],
  ];
  const moved = [];
  for (const [from, name] of items) {
    if (!(await exists(from))) continue;
    await mkdir(dir, { recursive: true, mode: 0o700 });
    await rename(from, path.join(dir, name));
    moved.push([from, name]);
  }
  return {
    moved: moved.length > 0,
    async restore() {
      for (const [from, name] of moved) {
        await rm(from, { recursive: true, force: true });
        await mkdir(path.dirname(from), { recursive: true });
        await rename(path.join(dir, name), from);
      }
      await rm(dir, { recursive: true, force: true });
    },
    async discard() {
      await rm(dir, { recursive: true, force: true });
    },
  };
}

async function writeCustomCertificate(certDir, parsed) {
  await mkdir(certDir, { recursive: true, mode: 0o755 });
  await writeFile(path.join(certDir, 'privkey.pem'), parsed.key, { mode: 0o600 });
  await chmod(path.join(certDir, 'privkey.pem'), 0o600);
  await writeFile(path.join(certDir, 'cert.pem'), parsed.cert, { mode: 0o644 });
  await writeFile(path.join(certDir, 'chain.pem'), parsed.chain, { mode: 0o644 });
  await writeFile(path.join(certDir, 'fullchain.pem'), parsed.fullchain, { mode: 0o644 });
  await writeFile(path.join(certDir, CUSTOM_CERT_MARKER), `${JSON.stringify({ installedAt: new Date().toISOString() })}\n`, { mode: 0o644 });
}

// The names a wildcard certificate for zone covers must include every
// domain of the site.
function checkWildcardZone(zone, domains) {
  if (typeof zone !== 'string' || !DOMAIN_PATTERN.test(zone)) throw invalid('wildcardZone must be a domain name');
  const names = [zone, `*.${zone}`];
  const outside = domains.filter((d) => !certificateCovers(names, d));
  if (outside.length) {
    throw invalid(`A wildcard certificate for *.${zone} covers ${zone} and names one level under it, not ${outside.join(', ')}`);
  }
  return names;
}


export const SSL_OPERATIONS = {
  ISSUE_SSL: {
    async run(params, ctx) {
      onlyKeys(params, [...SITE_SPEC_KEYS, 'email', 'staging', 'verifyDns', 'renewBeforeDays', 'wildcardZone', 'dnsProvider']);
      const { email, staging = false, verifyDns = true, renewBeforeDays, wildcardZone, dnsProvider, ...siteParams } = params;
      checkRenewBefore(renewBeforeDays);
      const spec = checkSiteSpec({ ...siteParams, ssl: true });
      if (typeof email !== 'string' || email.length > 254 || !EMAIL_PATTERN.test(email)) throw new OperationError('INVALID_PARAMS', 'email must be a valid address');
      if (typeof staging !== 'boolean' || typeof verifyDns !== 'boolean') throw new OperationError('INVALID_PARAMS', 'staging and verifyDns must be true or false');
      const wildcard = wildcardZone !== undefined && wildcardZone !== null;
      // The domain's DNS provider (0.38.0) instead of this server's zone.
      const provider = dnsProvider === undefined || dnsProvider === null ? null : checkDnsProvider(dnsProvider);
      if (provider && !wildcard) throw new OperationError('INVALID_PARAMS', 'dnsProvider needs wildcardZone');
      // Let's Encrypt's HTTP check cannot issue wildcard names, so without
      // wildcardZone the certificate covers the site's other domains.
      const plain = spec.domains.filter((d) => !isWildcardDomain(d));
      const leftOut = wildcard ? [] : spec.domains.filter(isWildcardDomain);
      if (!wildcard && !plain.length) {
        throw new OperationError('WILDCARD_CERT_NEEDED', `${leftOut.join(', ')} ${leftOut.length > 1 ? 'need' : 'needs'} a wildcard certificate, checked through this server's DNS zone for the domain (wildcardZone), or an uploaded certificate`);
      }
      const certDomains = wildcard ? checkWildcardZone(wildcardZone, spec.domains) : plain;
      if (!spec.enabled) throw new OperationError('SITE_DISABLED', 'Enable the site before issuing a certificate: Let’s Encrypt has to reach it');
      requireWebsites(ctx.policy);
      await requireNginx(ctx);
      await requireCertbot(ctx);
      const paths = sitePaths(ctx.policy, spec.name);
      await requireSiteAccount(ctx, spec.name, paths);
      await ensureRenewalHook(ctx);

      let challenge;
      if (wildcard && provider) {
        // The hook finds the credentials by the certificate's name (staged
        // just before Certbot runs), now and at each renewal.
        const hook = await ensureAcmeHook(ctx);
        challenge = ['--manual', '--preferred-challenges', 'dns', '--manual-auth-hook', `${hook} auth ${paths.certName}`, '--manual-cleanup-hook', `${hook} cleanup ${paths.certName}`];
        ctx.log('stdout', `Let’s Encrypt checks ${wildcardZone} through ${DNS_PROVIDER_LABELS[provider.type]}; the check record can take a few minutes to appear there`);
      } else if (wildcard) {
        await requireAcmeZone(ctx, wildcardZone);
        const hook = await ensureAcmeHook(ctx);
        challenge = ['--manual', '--preferred-challenges', 'dns', '--manual-auth-hook', `${hook} auth`, '--manual-cleanup-hook', `${hook} cleanup`];
        ctx.log('stdout', `Let’s Encrypt checks ${wildcardZone} through its DNS zone on this server`);
      } else {
        if (leftOut.length) ctx.log('stderr', `${leftOut.join(', ')} ${leftOut.length > 1 ? 'are' : 'is'} left out: wildcard names need a wildcard certificate`);
        if (verifyDns) await verifyDomainsReachThisServer(ctx, certDomains);
        else ctx.log('stdout', 'Skipping the domain check as asked');
        challenge = ['--webroot', '--webroot-path', ctx.policy.acmeWebroot];
      }

      // An uploaded certificate is moved aside while Certbot works, and put
      // back if it fails.
      const custom = (await isCustomCertificate(paths.certDir)) ? await moveCertificateAside(ctx, paths) : null;
      if (custom) ctx.log('stdout', 'Replacing the uploaded certificate with one from Let’s Encrypt');
      const existing = custom ? null : await readCertificate(paths.certDir);
      const args = [
        'certonly',
        ...challenge,
        '--cert-name',
        paths.certName,
        '--non-interactive',
        '--agree-tos',
        '--email',
        email,
        '--keep-until-expiring',
        '--expand',
        ...certDomains.flatMap((d) => ['--domain', d]),
      ];
      if (staging) args.push('--staging');
      // Moving from a test certificate to a real one needs a new certificate
      // even though the test one has not expired.
      if (existing?.staging && !staging) args.push('--force-renewal');
      ctx.log('stdout', `$ certbot certonly --cert-name ${paths.certName} ${certDomains.map((d) => `-d ${d}`).join(' ')}${wildcard ? ' --preferred-challenges dns' : ''}${staging ? ' --staging' : ''}`);
      let certificate;
      const credentials = provider ? await stageProviderCredentials(ctx.policy, paths.certName, provider) : null;
      try {
        const result = await ctx.run('certbot', args, { timeoutMs: ctx.timeoutMs, onLine: ctx.log });
        if (result.timedOut) throw new OperationError('TIMEOUT', 'Certbot did not finish in time');
        if (result.error || result.exitCode !== 0) {
          let hint = '';
          if (provider) hint = `\nLet’s Encrypt asks the name servers of ${wildcardZone} for the check record, so the domain must use ${DNS_PROVIDER_LABELS[provider.type]}’s name servers.`;
          else if (wildcard) hint = `\nLet’s Encrypt asks the name servers of ${wildcardZone} for the check record, so they must be this server (set at the domain registrar), and any other name server listed for the zone must serve the same zone.`;
          throw new OperationError('SSL_ISSUE_FAILED', `Let’s Encrypt did not issue the certificate:\n${certbotFailure(result)}${hint}`);
        }
        certificate = await readCertificate(paths.certDir);
        if (!certificate) throw new OperationError('SSL_ISSUE_FAILED', `Certbot finished but no certificate is in ${paths.certDir}`);
      } catch (err) {
        if (custom) await custom.restore();
        await credentials?.restore();
        throw err;
      }
      await custom?.discard();
      // Renewals check the way this certificate was issued.
      if (!provider) await removeProviderCredentials(ctx.policy, paths.certName);
      const missing = (wildcard ? spec.domains : plain).filter((d) => !certificateCovers(certificate.domains, d));
      if (missing.length) throw new OperationError('SSL_ISSUE_FAILED', `The certificate does not cover ${missing.join(', ')}`);
      ctx.log('stdout', `Certificate valid until ${certificate.notAfter}`);

      await applyNginxConfig(ctx, spec, paths);
      const health = await checkSiteHealth(ctx, spec);
      const renewal = renewBeforeDays ? await setRenewBefore(ctx, paths.certName, renewBeforeDays) : null;
      const timer = await ensureRenewalTimer(ctx);
      ctx.webInventory?.invalidate();
      return { output: { certName: paths.certName, certificate, health, renewal, timer, wildcard } };
    },
  },

  // Installs a certificate bought elsewhere (or made by another tool) for a
  // site, in place of any Let's Encrypt certificate it had.
  INSTALL_SSL_CERT: {
    async run(params, ctx) {
      onlyKeys(params, [...SITE_SPEC_KEYS, 'certificate', 'privateKey']);
      const { certificate: certificatePem, privateKey, ...siteParams } = params;
      const spec = checkSiteSpec({ ...siteParams, ssl: true });
      const parsed = parseCustomCertificate(certificatePem, privateKey, spec.domains);
      requireWebsites(ctx.policy);
      await requireNginx(ctx);
      const paths = sitePaths(ctx.policy, spec.name);
      await requireSiteAccount(ctx, spec.name, paths);
      ctx.log('stdout', `Certificate for ${parsed.info.domains.join(', ')} from ${parsed.info.issuer}, valid until ${parsed.info.notAfter}`);
      if (!parsed.intermediates) ctx.log('stderr', 'No intermediate certificates were included. Browsers may not trust the site unless the certificate was issued directly by a root they know; paste the chain after the certificate.');

      const previous = await moveCertificateAside(ctx, paths);
      if (previous.moved) ctx.log('stdout', 'The previous certificate is replaced; Certbot no longer renews it');
      try {
        await writeCustomCertificate(paths.certDir, parsed);
        await applyNginxConfig(ctx, spec, paths);
      } catch (err) {
        await rm(paths.certDir, { recursive: true, force: true });
        await previous.restore();
        if (previous.moved) await reloadNginx(ctx).catch(() => {});
        throw err;
      }
      await previous.discard();
      // Nothing renews an uploaded certificate through a DNS provider.
      await removeProviderCredentials(ctx.policy, paths.certName);
      const health = await checkSiteHealth(ctx, spec);
      ctx.webInventory?.invalidate();
      return { output: { certName: paths.certName, certificate: await readCertificate(paths.certDir), health, intermediates: parsed.intermediates } };
    },
  },

  RENEW_SSL: {
    async run(params, ctx) {
      onlyKeys(params, ['name', 'force', 'renewBeforeDays']);
      const name = checkSiteName(params.name);
      const force = params.force ?? false;
      const renewBeforeDays = checkRenewBefore(params.renewBeforeDays);
      if (typeof force !== 'boolean') throw new OperationError('INVALID_PARAMS', 'force must be true or false');
      requireWebsites(ctx.policy);
      await requireCertbot(ctx);
      const paths = sitePaths(ctx.policy, name);
      const before = await readCertificate(paths.certDir);
      if (!before) throw new OperationError('SSL_NOT_FOUND', 'This site has no certificate on the server. Issue one first.');
      if (before.custom) throw new OperationError('SSL_CUSTOM', 'This site uses an uploaded certificate, which Let’s Encrypt cannot renew. Upload the renewed certificate, or issue one from Let’s Encrypt instead.');
      await ensureRenewalHook(ctx);
      const renewal = renewBeforeDays ? await setRenewBefore(ctx, paths.certName, renewBeforeDays) : null;
      const timer = await ensureRenewalTimer(ctx);
      const args = ['renew', '--cert-name', paths.certName, '--non-interactive'];
      if (force) args.push('--force-renewal');
      ctx.log('stdout', `$ certbot ${args.join(' ')}`);
      const result = await ctx.run('certbot', args, { timeoutMs: ctx.timeoutMs, onLine: ctx.log });
      if (result.timedOut) throw new OperationError('TIMEOUT', 'Certbot did not finish in time');
      if (result.error || result.exitCode !== 0) throw new OperationError('SSL_RENEW_FAILED', `Renewal failed:\n${certbotFailure(result)}`);
      const certificate = await readCertificate(paths.certDir);
      const renewed = certificate && certificate.notAfter !== before.notAfter;
      ctx.log('stdout', renewed ? `Renewed; valid until ${certificate.notAfter}` : `Not due yet; valid until ${certificate?.notAfter}. Certbot renews it ${renewal?.renewBeforeDays ?? 30} days before expiry.`);
      if (renewed) await reloadNginx(ctx);
      ctx.webInventory?.invalidate();
      return { output: { certName: paths.certName, renewed, certificate, renewal, timer } };
    },
  },

  // Applies the panel's renewal window to every VaultPanel certificate on
  // this server and makes sure Certbot's timer is on.
  SET_SSL_RENEWAL: {
    async run(params, ctx) {
      onlyKeys(params, ['renewBeforeDays']);
      const days = checkRenewBefore(params.renewBeforeDays);
      if (days === undefined) throw new OperationError('INVALID_PARAMS', 'renewBeforeDays is required');
      await requireCertbot(ctx);
      let files = [];
      try {
        files = await readdir(path.join(ctx.policy.letsencryptDir, 'renewal'));
      } catch {
        // no certificates yet
      }
      const certificates = [];
      for (const file of files.sort()) {
        const match = file.match(/^(vp-[a-z0-9][a-z0-9-]{0,62})\.conf$/);
        if (!match) continue;
        const result = await setRenewBefore(ctx, match[1], days);
        if (result) {
          certificates.push(result);
          ctx.log('stdout', `${result.certName}: renews ${result.renewBeforeDays} days before expiry`);
        }
      }
      const timer = await ensureRenewalTimer(ctx);
      return { output: { renewBeforeDays: days, certificates, timer } };
    },
  },
};
