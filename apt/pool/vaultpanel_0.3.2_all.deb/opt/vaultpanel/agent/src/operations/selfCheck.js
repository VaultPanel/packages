import { access, constants, lstat, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { findBinary } from '../monitoring/web.js';
import { parseSystemctlShow } from '../monitoring/services.js';
import { lookupUser, runAsSiteUser } from '../services/siteFiles.js';
import { AGENT_ROOT } from './agentUpdate.js';
import { onlyKeys } from './errors.js';
import { agentSummary } from './security.js';
import { RELOAD_HOOK_NAME, RENEWAL_TIMERS } from './ssl.js';

// The server's self-check (0.39.0): what the panel's features need from the
// server and what breaks without anyone noticing until someone uses it, such
// as the agent's code readable by root only (the file manager then fails for
// every site) or an NGINX configuration that no longer passes `nginx -t`.
// Read with the inventory every few minutes and by SELF_CHECK on demand, as
// root (by the root helper when there is one). The panel turns the report
// into the server's self-check card (shared/src/selfCheck.js).

const HOME_FOLDER = /^\/(root|home)(\/|$)/;
const MAX_WALK = 5000;
const MAX_MESSAGE = 480;
const MAX_FAILED_UNITS = 20;
// Reported in the certificate renewal check instead.
const RENEWAL_SERVICES = RENEWAL_TIMERS.map((t) => t.replace(/\.timer$/, '.service'));

const clip = (text) => String(text ?? '').trim().slice(0, MAX_MESSAGE);

export async function readSelfCheck(ctx, { agentRoot = ctx.agentRoot ?? AGENT_ROOT, isRoot = process.getuid?.() === 0, fileWorker = checkFileWorker } = {}) {
  const [nginx, apache] = await Promise.all([findBinary('nginx', ctx.binDirs), findBinary('apache2ctl', ctx.binDirs).then((b) => b ?? findBinary('apachectl', ctx.binDirs))]);
  const settle = (promise) => Promise.resolve(promise).catch(() => null);
  const [agentFiles, worker, nginxTest, apacheTest, certbot, clock, failedUnits] = await Promise.all([
    settle(checkAgentFiles(agentRoot)),
    // Only root can start the worker as another user, and the file manager
    // is for websites.
    settle(isRoot && ctx.policy.allowWebsites !== false ? fileWorker() : null),
    settle(isRoot && nginx ? configTest(ctx, nginx) : null),
    settle(isRoot && apache ? configTest(ctx, apache) : null),
    settle(checkCertbot(ctx, { reloadHook: Boolean(nginx) })),
    settle(checkClock(ctx)),
    settle(readFailedUnits(ctx)),
  ]);
  const report = { checkedAt: new Date().toISOString(), agent: agentSummary(ctx), agentFiles, fileWorker: worker, nginx: nginxTest, apache: apacheTest, certbot, clock, failedUnits };
  return Object.fromEntries(Object.entries(report).filter(([, value]) => value !== null && value !== undefined));
}

// What the agent reports when its root helper does not answer: nothing that
// needs root can be checked or done then.
export function helperProblem(policy, err) {
  const agent = agentSummary({ policy });
  return { checkedAt: new Date().toISOString(), ...(agent ? { agent } : {}), helper: { ok: false, error: clip(err?.message ?? err) || 'no answer' } };
}

// Everyone must be able to read the agent's code: the agent runs as its own
// user and the file manager's worker as each site's user (see makeReadable
// in agentUpdate.js). Counts what they cannot read, folders above it
// included, and names the first. Null for an agent in a home folder, whose
// workers start as root and change user themselves (siteFiles.js).
export async function checkAgentFiles(root) {
  if (HOME_FOLDER.test(root)) return null;
  let unreadable = 0;
  let example = null;
  const note = (p) => {
    unreadable += 1;
    example ??= p;
  };
  for (let dir = path.dirname(root); ; dir = path.dirname(dir)) {
    const info = await stat(dir).catch(() => null);
    if (info && (info.mode & 0o001) === 0) note(dir);
    if (dir === path.dirname(dir)) break;
  }
  let seen = 0;
  const walk = async (p) => {
    seen += 1;
    if (seen > MAX_WALK) return;
    const info = await lstat(p);
    if (info.isDirectory()) {
      if ((info.mode & 0o005) !== 0o005) note(p);
      for (const name of (await readdir(p)).sort()) await walk(path.join(p, name));
    } else if (info.isFile() && (info.mode & 0o004) === 0) {
      note(p);
    }
  };
  await walk(root);
  return { dir: root.slice(0, 1000), unreadable, example: example && example.slice(0, 1000) };
}

// Starts the file manager's worker the way it starts for a site, as an
// account that is neither root nor the agent's.
export async function checkFileWorker({ lookup = lookupUser, run = runAsSiteUser } = {}) {
  const account = await lookup('nobody').catch(() => null);
  if (!account || !(account.uid > 0) || !(account.gid > 0)) return null;
  try {
    await run(account, { action: 'ping', home: '/' }, { timeoutMs: 30_000 });
    return { ok: true, error: null };
  } catch (err) {
    return { ok: false, error: clip(err.message) };
  }
}

// `nginx -t` or `apache2ctl -t`: whether the configuration loads.
async function configTest(ctx, binary) {
  const result = await ctx.run(binary, ['-t'], { timeoutMs: 30_000 });
  if (result.exitCode === 0) return { ok: true, error: null };
  if (result.timedOut) return { ok: false, error: `${path.basename(binary)} -t did not finish within 30 seconds` };
  return { ok: false, error: configTestError(`${result.stderr ?? ''}\n${result.stdout ?? ''}`) || clip(result.error?.message) || `exit code ${result.exitCode}` };
}

const BOILERPLATE = /test failed|syntax is ok|test is successful|^Action '.*' failed|error log may have more information/i;

// The lines that say what is wrong: NGINX's [emerg] line (after any
// warnings), or Apache's "Syntax error on line ..." and the line after it.
export function configTestError(output) {
  const lines = String(output)
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !BOILERPLATE.test(line));
  const serious = lines.filter((line) => /\[(emerg|alert|crit)\]/.test(line));
  return clip((serious.length ? serious : lines).slice(0, 2).join(' '));
}

// Certbot's renewal timer (ssl.js keeps it on when it issues or renews), how
// its last run went, and the hook that loads renewed certificates into NGINX.
async function checkCertbot(ctx, { reloadHook }) {
  if (!(await findBinary('certbot', ctx.binDirs))) return null;
  const letsencrypt = ctx.policy.letsencryptDir ?? '/etc/letsencrypt';
  const renewals = (await readdir(path.join(letsencrypt, 'renewal')).catch(() => [])).filter((name) => name.endsWith('.conf')).length;
  const shown = await ctx.run('systemctl', ['show', ...RENEWAL_TIMERS, ...RENEWAL_SERVICES, '--property=Id,LoadState,ActiveState,SubState,UnitFileState', '--no-pager'], { timeoutMs: 15_000 });
  if (shown.exitCode !== 0) return null;
  return {
    renewals,
    ...renewalState(parseSystemctlShow(shown.stdout)),
    reloadHook: reloadHook && renewals > 0 ? await access(path.join(letsencrypt, 'renewal-hooks', 'deploy', RELOAD_HOOK_NAME), constants.X_OK).then(() => true, () => false) : null,
  };
}

// From `systemctl show` of the timers and their services: the timer in use
// (apt's or the snap's), its state, and whether its last run failed.
export function renewalState(units) {
  const timer = units.find((u) => RENEWAL_TIMERS.includes(u.name) && (u.loadState === 'loaded' || u.loadState === 'masked'));
  if (!timer) return { timer: null, state: null, lastRunFailed: false };
  const service = units.find((u) => u.name === timer.name.replace(/\.timer$/, ''));
  const state = timer.loadState === 'masked' || timer.enabled === 'masked' ? 'masked' : timer.active === 'active' ? 'active' : 'inactive';
  return { timer: timer.name, state, lastRunFailed: service?.active === 'failed' };
}

// Whether systemd-timesyncd (or chrony, ntpd) keeps the clock right. Null
// where timedatectl cannot tell (containers, systemd before 239).
async function checkClock(ctx) {
  const result = await ctx.run('timedatectl', ['show', '--property=NTPSynchronized', '--value'], { timeoutMs: 10_000 });
  const value = String(result.stdout ?? '').trim();
  if (result.exitCode !== 0 || (value !== 'yes' && value !== 'no')) return null;
  return { synchronized: value === 'yes' };
}

async function readFailedUnits(ctx) {
  const result = await ctx.run('systemctl', ['list-units', '--state=failed', '--no-legend', '--plain', '--no-pager'], { timeoutMs: 15_000 });
  if (result.exitCode !== 0) return null;
  return parseFailedUnits(result.stdout).filter((unit) => !RENEWAL_SERVICES.includes(unit));
}

// `systemctl list-units --state=failed --no-legend --plain`: one unit per
// line, its name first (some versions still put "●" before it).
export function parseFailedUnits(text) {
  const units = [];
  for (const line of String(text).split('\n')) {
    const name = line.replace(/^[\s●*]+/, '').split(/\s+/)[0];
    if (name && name.length <= 255 && /^[^\s/]+\.[a-z]+$/.test(name) && !units.includes(name)) units.push(name);
    if (units.length >= MAX_FAILED_UNITS) break;
  }
  return units;
}

export const SELF_CHECK_OPERATIONS = {
  SELF_CHECK: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const selfCheck = await readSelfCheck(ctx);
      // The next heartbeat reads the inventory again, so it does not carry
      // the report from before this one.
      ctx.webInventory?.invalidate();
      return { output: { selfCheck } };
    },
  },
};
