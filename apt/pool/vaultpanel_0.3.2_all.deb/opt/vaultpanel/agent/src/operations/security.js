import { findBinary } from '../monitoring/web.js';
import { SECURITY_TOOL_KEYS } from '../security/securityRules.js';
import { onlyKeys, OperationError } from './errors.js';
import { FAIL2BAN_OPERATIONS, readFail2ban } from './fail2ban.js';
import { FIREWALL_OPERATIONS, readFirewall, sshPorts } from './firewall.js';
import { readSsh, SSH_OPERATIONS } from './ssh.js';
import { LOGIN_BANNER_OPERATIONS, readLoginBanner } from './loginBanner.js';
import { readUpdates, resetPendingCache, UPDATE_OPERATIONS } from './updates.js';
import { aptInstall } from './webStack.js';

// The security status of the server: firewall, SSH, Fail2ban, updates and
// recent SSH sign-in failures. SECURITY_STATUS reads all of it on demand;
// the heartbeat carries a short summary every few minutes.

const TOOL_PACKAGES = { ufw: ['ufw'], fail2ban: ['fail2ban', 'python3-systemd'], 'unattended-upgrades': ['unattended-upgrades'] };

// Failed SSH sign-ins in the journal: "Failed password for [invalid user] x
// from 1.2.3.4" and "Invalid user x from 1.2.3.4".
export function summarizeSshFailures(text) {
  const byAddress = new Map();
  let total = 0;
  for (const line of (text ?? '').split('\n')) {
    const match = /(?:Failed (?:password|publickey) for (?:invalid user )?\S+|Invalid user \S* ?) from (\S+)/.exec(line);
    if (!match) continue;
    total += 1;
    byAddress.set(match[1], (byAddress.get(match[1]) ?? 0) + 1);
  }
  const top = [...byAddress.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([address, count]) => ({ address, count }));
  return { total, addresses: byAddress.size, top };
}

async function sshFailures(ctx) {
  const journalctl = await findBinary('journalctl', ctx.binDirs);
  if (!journalctl) return null;
  const since = `@${Math.floor((Date.now() - 24 * 3600_000) / 1000)}`;
  const result = await ctx.run(
    journalctl,
    ['--no-pager', '--quiet', '--output=cat', `--since=${since}`, '--lines=50000', 'SYSLOG_IDENTIFIER=sshd', '+', 'SYSLOG_IDENTIFIER=sshd-session'],
    { timeoutMs: 30_000, maxOutputBytes: 16 * 1024 * 1024 },
  );
  if (result.exitCode !== 0) return null;
  return { hours: 24, ...summarizeSshFailures(result.stdout) };
}

// What the heartbeat reports: enough for the panel's security checks.
export async function readSecuritySummary(ctx) {
  const [firewall, ssh, fail2ban, updates] = await Promise.all([
    readFirewall(ctx).catch(() => null),
    readSsh(ctx).catch(() => null),
    readFail2ban(ctx, { live: false }).catch(() => null),
    readUpdates(ctx).catch(() => null),
  ]);
  return {
    checkedAt: new Date().toISOString(),
    ...(firewall ? { firewall: { installed: firewall.installed, active: firewall.active, incoming: firewall.incoming, rules: firewall.rules.length } } : {}),
    ...(ssh
      ? {
          ssh: ssh.installed
            ? {
                installed: true,
                ports: ssh.ports,
                permitRootLogin: ssh.permitRootLogin ?? null,
                passwordAuthentication: ssh.passwordAuthentication ?? null,
                rootKeys: ssh.rootKeys.length,
              }
            : { installed: false },
        }
      : {}),
    ...(fail2ban ? { fail2ban: { installed: fail2ban.installed, active: fail2ban.active, sshd: fail2ban.sshd, banned: fail2ban.banned ?? 0 } } : {}),
    ...(updates?.supported
      ? { updates: { installed: updates.installed, automatic: updates.automatic, pendingSecurity: updates.pendingSecurity, rebootRequired: updates.rebootRequired } }
      : {}),
    ...(agentSummary(ctx) ? { agent: agentSummary(ctx) } : {}),
  };
}

// Which user the agent runs as, and why root when it is (0.36.0; see services/agentMode.js).
export function agentSummary(ctx) {
  const mode = ctx.policy.agentMode;
  if (!mode?.user) return null;
  return { user: String(mode.user).slice(0, 32), reason: mode.reason ? String(mode.reason).slice(0, 480) : null };
}

export const SECURITY_OPERATIONS = {
  SECURITY_STATUS: {
    async run(params, ctx) {
      onlyKeys(params, []);
      const [firewall, ports, ssh, fail2ban, updates, failures, loginBanner] = await Promise.all([
        readFirewall(ctx),
        sshPorts(ctx),
        readSsh(ctx),
        readFail2ban(ctx),
        readUpdates(ctx),
        sshFailures(ctx).catch(() => null),
        readLoginBanner(ctx.policy),
      ]);
      return { output: { firewall: { ...firewall, sshPorts: ports }, ssh, fail2ban, updates, sshFailures: failures, loginBanner, agent: agentSummary(ctx), checkedAt: new Date().toISOString() } };
    },
  },

  SECURITY_TOOLS_INSTALL: {
    async run(params, ctx) {
      onlyKeys(params, ['components']);
      const { components } = params;
      if (!Array.isArray(components) || !components.length || components.some((c) => !SECURITY_TOOL_KEYS.includes(c)) || new Set(components).size !== components.length) {
        throw new OperationError('INVALID_PARAMS', `components must list some of: ${SECURITY_TOOL_KEYS.join(', ')}`);
      }
      if (ctx.policy.allowWebStackInstall === false) throw new OperationError('NOT_ALLOWED', 'Installing packages is disabled in this agent config');
      const deadline = Date.now() + ctx.timeoutMs;
      await aptInstall(ctx, components.flatMap((c) => TOOL_PACKAGES[c]), () => Math.max(10_000, deadline - Date.now()));
      resetPendingCache();
      ctx.webInventory?.invalidate();
      // Installing UFW does not turn it on, and changes nothing until then.
      if (components.includes('ufw')) ctx.log('stdout', 'UFW is installed but off. Review the rules, then turn it on from the Firewall card.');
      return { output: { components, summary: await readSecuritySummary(ctx) } };
    },
  },

  ...FIREWALL_OPERATIONS,
  ...SSH_OPERATIONS,
  ...LOGIN_BANNER_OPERATIONS,
  ...FAIL2BAN_OPERATIONS,
  ...UPDATE_OPERATIONS,
};
