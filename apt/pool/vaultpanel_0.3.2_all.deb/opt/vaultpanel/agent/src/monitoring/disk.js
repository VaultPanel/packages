import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { SITE_NAME_PATTERN } from '../security/webRules.js';
import { runCommand } from '../utils/exec.js';

const MAX_FOLDERS = 5000;

// Parses `du -s --block-size=1` output: "<bytes>\t<path>" per line.
export function parseDu(stdout, root) {
  const folders = [];
  for (const line of stdout.split('\n')) {
    const match = line.match(/^(\d+)\t(.+)$/);
    if (!match) continue;
    const name = path.relative(root, match[2]);
    if (!SITE_NAME_PATTERN.test(name)) continue;
    folders.push({ name, sizeBytes: Number(match[1]) });
  }
  return folders;
}

// How much disk each website's and app's folder (<sitesRoot>/<name>) takes,
// for hosting plan quotas. du can take a while on big sites, so it runs in
// the background at most every intervalMs, at low priority, and the
// heartbeat sends the last result.
export function createDiskUsage(policy, { run = runCommand, intervalMs = 15 * 60_000, now = () => Date.now() } = {}) {
  let latest = null;
  let startedAt = 0;
  let running = null;

  async function measure() {
    const root = policy.sitesRoot;
    let entries;
    try {
      entries = await readdir(root, { withFileTypes: true });
    } catch {
      return { checkedAt: new Date(now()).toISOString(), folders: [] };
    }
    const paths = entries
      .filter((e) => e.isDirectory() && SITE_NAME_PATTERN.test(e.name))
      .slice(0, MAX_FOLDERS)
      .map((e) => path.join(root, e.name));
    if (!paths.length) return { checkedAt: new Date(now()).toISOString(), folders: [] };
    // -x stays on the folder's file system. du exits non-zero when a file
    // vanishes while it counts, but still prints the totals.
    const result = await run('nice', ['-n', '19', 'du', '-s', '-x', '--block-size=1', '--', ...paths], { timeoutMs: 10 * 60_000, maxOutputBytes: 2 * 1024 * 1024 });
    if (result.timedOut || (!result.stdout && result.exitCode !== 0)) return null;
    return { checkedAt: new Date(now()).toISOString(), folders: parseDu(result.stdout, root) };
  }

  return {
    // The last measurement (null before the first one), starting a new one
    // when it is due.
    current() {
      if (!running && now() - startedAt >= intervalMs) {
        startedAt = now();
        running = measure()
          .then((value) => {
            if (value) latest = value;
          })
          .catch(() => {})
          .finally(() => {
            running = null;
          });
      }
      return latest;
    },
    wait: () => running ?? Promise.resolve(),
  };
}
