import { runCommand } from '../utils/exec.js';

const PROPERTIES = 'Id,LoadState,ActiveState,SubState,UnitFileState,Description';

// Reads the state of systemd units with one `systemctl show` call. Units that
// do not exist on this server are left out.
export async function readServiceStates(names, { run = runCommand } = {}) {
  if (!names.length) return [];
  const units = names.map((n) => (n.endsWith('.service') ? n : `${n}.service`));
  const result = await run('systemctl', ['show', ...units, `--property=${PROPERTIES}`, '--no-pager'], {
    timeoutMs: 15_000,
  });
  if (result.error || result.exitCode !== 0) return [];
  return parseSystemctlShow(result.stdout).filter((s) => s.loadState !== 'not-found');
}

export function parseSystemctlShow(text) {
  return text
    .split(/\n\s*\n/)
    .map((block) => {
      const props = {};
      for (const line of block.split('\n')) {
        const i = line.indexOf('=');
        if (i > 0) props[line.slice(0, i)] = line.slice(i + 1);
      }
      return props;
    })
    .filter((p) => p.Id)
    .map((p) => ({
      name: p.Id.replace(/\.service$/, ''),
      loadState: p.LoadState ?? null,
      active: p.ActiveState ?? 'unknown',
      sub: p.SubState ?? null,
      enabled: p.UnitFileState || null,
      description: p.Description ?? null,
    }));
}
