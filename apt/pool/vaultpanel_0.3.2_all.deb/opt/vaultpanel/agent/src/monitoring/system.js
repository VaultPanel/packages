import { readFile, readdir, statfs } from 'node:fs/promises';
import os from 'node:os';

// Static-ish facts about the machine, sent with every heartbeat.
export async function collectSystemInfo({ diskPath = '/' } = {}) {
  const osRelease = await readOsRelease();
  const disk = await diskUsage(diskPath);
  return {
    hostname: os.hostname(),
    os: { name: osRelease.NAME ?? os.type(), version: osRelease.VERSION_ID ?? osRelease.VERSION ?? null },
    kernel: os.release(),
    architecture: os.arch(),
    cpuCores: os.cpus().length,
    memoryTotalBytes: os.totalmem(),
    diskTotalBytes: disk?.total ?? null,
    uptimeSeconds: Math.round(os.uptime()),
  };
}

// Keeps the previous CPU and network counters so each sample reports usage
// since the last one rather than since boot.
export function createMetricsSampler({ diskPath = '/' } = {}) {
  let lastCpu = cpuTimes();
  let lastNet = null;

  async function sample() {
    const cpu = cpuTimes();
    const cpuPercent = cpuUsage(lastCpu, cpu);
    lastCpu = cpu;

    const net = await networkCounters();
    let netRxBytesPerSec = null;
    let netTxBytesPerSec = null;
    if (net && lastNet) {
      const seconds = (net.at - lastNet.at) / 1000;
      if (seconds > 0) {
        netRxBytesPerSec = Math.max(0, Math.round((net.rx - lastNet.rx) / seconds));
        netTxBytesPerSec = Math.max(0, Math.round((net.tx - lastNet.tx) / seconds));
      }
    }
    lastNet = net;

    const memory = await memoryUsage();
    const disk = await diskUsage(diskPath);
    return {
      cpuPercent,
      load: os.loadavg().map((v) => Math.round(v * 100) / 100),
      memoryUsedBytes: memory.used,
      memoryTotalBytes: memory.total,
      swapUsedBytes: memory.swapUsed,
      swapTotalBytes: memory.swapTotal,
      diskUsedBytes: disk?.used ?? null,
      diskTotalBytes: disk?.total ?? null,
      netRxBytesPerSec,
      netTxBytesPerSec,
      processCount: await processCount(),
      uptimeSeconds: Math.round(os.uptime()),
    };
  }

  return { sample };
}

function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    for (const [kind, value] of Object.entries(cpu.times)) {
      total += value;
      if (kind === 'idle') idle += value;
    }
  }
  return { idle, total };
}

export function cpuUsage(before, after) {
  const total = after.total - before.total;
  if (total <= 0) return 0;
  const busy = total - (after.idle - before.idle);
  return Math.min(100, Math.max(0, Math.round((busy / total) * 10000) / 100));
}

// Parses /proc/meminfo; falls back to os.freemem() elsewhere.
async function memoryUsage() {
  const info = await readMeminfo();
  if (info) return memoryFromMeminfo(info);
  return { total: os.totalmem(), used: os.totalmem() - os.freemem(), swapUsed: null, swapTotal: null };
}

export function memoryFromMeminfo(info) {
  const total = info.MemTotal;
  const available = info.MemAvailable ?? info.MemFree + (info.Buffers ?? 0) + (info.Cached ?? 0);
  return {
    total,
    used: total - available,
    swapTotal: info.SwapTotal ?? null,
    swapUsed: info.SwapTotal !== undefined ? info.SwapTotal - (info.SwapFree ?? 0) : null,
  };
}

async function readMeminfo() {
  try {
    return parseMeminfo(await readFile('/proc/meminfo', 'utf8'));
  } catch {
    return null;
  }
}

export function parseMeminfo(text) {
  const out = {};
  for (const line of text.split('\n')) {
    const match = /^(\w+):\s+(\d+)(?:\s+kB)?/.exec(line);
    if (match) out[match[1]] = Number(match[2]) * (line.includes('kB') ? 1024 : 1);
  }
  return out;
}

// Filesystems worth reporting; pseudo filesystems (tmpfs, overlay, proc...)
// and boot partitions are left out.
const REAL_FILESYSTEMS = new Set(['ext2', 'ext3', 'ext4', 'xfs', 'btrfs', 'zfs', 'f2fs', 'jfs', 'reiserfs', 'nfs', 'nfs4', 'cifs']);
const MAX_FILESYSTEMS = 20;

// Usage of every mounted real filesystem: [{ mount, device, fsType, totalBytes, usedBytes }].
export async function collectFilesystems({ readText = (p) => readFile(p, 'utf8'), stat = diskUsage } = {}) {
  let mounts;
  try {
    mounts = parseMounts(await readText('/proc/mounts'));
  } catch {
    return [];
  }
  const out = [];
  for (const m of mounts.slice(0, MAX_FILESYSTEMS)) {
    const usage = await stat(m.mount);
    if (usage && usage.total > 0) out.push({ ...m, totalBytes: usage.total, usedBytes: usage.used });
  }
  return out;
}

export function parseMounts(text) {
  const seen = new Set();
  const out = [];
  for (const line of text.split('\n')) {
    const [device, mount, fsType] = line.split(' ');
    if (!mount || !REAL_FILESYSTEMS.has(fsType)) continue;
    const mountPath = mount.replace(/\\([0-7]{3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)));
    if (mountPath.startsWith('/boot') || mountPath.startsWith('/snap/')) continue;
    // btrfs subvolumes and bind mounts repeat the same device.
    if (seen.has(device)) continue;
    seen.add(device);
    out.push({ mount: mountPath, device, fsType });
  }
  return out;
}

async function diskUsage(path) {
  try {
    const s = await statfs(path);
    const total = s.blocks * s.bsize;
    return { total, used: total - s.bfree * s.bsize };
  } catch {
    return null;
  }
}

async function networkCounters() {
  try {
    return { ...parseNetDev(await readFile('/proc/net/dev', 'utf8')), at: Date.now() };
  } catch {
    return null;
  }
}

// Sums received/transmitted bytes over all interfaces except loopback.
export function parseNetDev(text) {
  let rx = 0;
  let tx = 0;
  for (const line of text.split('\n').slice(2)) {
    const [name, rest] = line.split(':');
    if (!rest || name.trim() === 'lo') continue;
    const fields = rest.trim().split(/\s+/).map(Number);
    rx += fields[0] || 0;
    tx += fields[8] || 0;
  }
  return { rx, tx };
}

async function processCount() {
  try {
    return (await readdir('/proc')).filter((name) => /^\d+$/.test(name)).length;
  } catch {
    return null;
  }
}

async function readOsRelease() {
  try {
    return parseOsRelease(await readFile('/etc/os-release', 'utf8'));
  } catch {
    return {};
  }
}

export function parseOsRelease(text) {
  const out = {};
  for (const line of text.split('\n')) {
    const match = /^([A-Z_]+)=(.*)$/.exec(line.trim());
    if (match) out[match[1]] = match[2].replace(/^"|"$/g, '');
  }
  return out;
}
