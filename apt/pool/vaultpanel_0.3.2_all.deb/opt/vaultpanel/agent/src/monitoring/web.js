import { execFileSync } from 'node:child_process';
import { X509Certificate } from 'node:crypto';
import { accessSync, constants as fsConstants } from 'node:fs';
import { access, constants, readdir, readFile, realpath } from 'node:fs/promises';
import { networkInterfaces } from 'node:os';
import path from 'node:path';

// What the web stack looks like on this server (NGINX, PHP-FPM versions,
// Certbot) and the certificates VaultPanel issued here. Reported with the
// heartbeat so the panel can show what is installed and when certificates
// expire, including after Certbot renews them on its own.

export const BIN_DIRS = ['/usr/local/sbin', '/usr/local/bin', '/usr/sbin', '/usr/bin', '/sbin', '/bin'];

// Node.js installed in a home folder (nvm puts it in /root/.nvm) cannot run
// apps: app users cannot read /root, and the agent's service keeps home
// folders read-only, so npm cannot install PM2 there either.
export const NODE_IN_HOME_MESSAGE =
  'Node.js on this server is installed in a home folder (for example by nvm), so apps and PM2 cannot use it. Install Node.js system-wide: curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt-get install -y nodejs';
const HOME_FOLDER = /^\/(root|home)(\/|$)/;
const SYSTEM_NODE_DIRS = ['/usr/local/bin', '/usr/bin'];

// The folder with the Node.js (and npm) that apps and PM2 use: the
// nodeBinDir policy key, else the agent's own Node.js, unless that lives in
// a home folder, then a system-wide one. Null when there is none.
export function appNodeDir(policy, { execPath = process.execPath, dirs = SYSTEM_NODE_DIRS } = {}) {
  if (policy.nodeBinDir) return policy.nodeBinDir;
  const own = path.dirname(execPath);
  if (!HOME_FOLDER.test(own)) return own;
  return (
    dirs.find((dir) => {
      try {
        accessSync(path.join(dir, 'node'), fsConstants.X_OK);
        return true;
      } catch {
        return false;
      }
    }) ?? null
  );
}

function nodeVersion(nodeDir) {
  if (nodeDir === path.dirname(process.execPath)) return process.versions.node;
  try {
    return execFileSync(path.join(nodeDir, 'node'), ['--version'], { timeout: 5000, encoding: 'utf8' }).trim().replace(/^v/, '') || null;
  } catch {
    return null;
  }
}

export async function findBinary(name, dirs = BIN_DIRS) {
  for (const dir of dirs) {
    const candidate = path.join(dir, name);
    try {
      await access(candidate, constants.X_OK);
      return candidate;
    } catch {
      // keep looking
    }
  }
  return null;
}

// PHP versions with PHP-FPM installed: /etc/php/<version>/fpm plus its binary.
export async function installedPhpVersions(phpConfRoot = '/etc/php', dirs = BIN_DIRS) {
  let entries;
  try {
    entries = await readdir(phpConfRoot);
  } catch {
    return [];
  }
  const versions = [];
  for (const version of entries.filter((e) => /^[5-9]\.[0-9]$/.test(e))) {
    try {
      await access(path.join(phpConfRoot, version, 'fpm', 'pool.d'));
      if (await findBinary(`php-fpm${version}`, dirs)) versions.push(version);
    } catch {
      // config without FPM (CLI only)
    }
  }
  return versions.sort((a, b) => Number(b) - Number(a));
}

// Python 3 counts as installed for apps only with venv support (ensurepip),
// which Debian and Ubuntu ship separately as python3-venv.
export async function pythonVersion(dirs = BIN_DIRS, libRoot = '/usr/lib') {
  const binary = await findBinary('python3', dirs);
  if (!binary) return null;
  let entries;
  try {
    entries = await readdir(libRoot);
  } catch {
    return null;
  }
  // python3 is usually a link to python3.X: that is the version apps get.
  const linked = path.basename(await realpath(binary).catch(() => binary)).match(/^python3\.\d+$/)?.[0];
  const versions = (linked ? [linked] : entries.filter((e) => /^python3\.\d+$/.test(e)).sort((a, b) => Number(b.split('.')[1]) - Number(a.split('.')[1])));
  for (const dir of versions) {
    try {
      await access(path.join(libRoot, dir, 'ensurepip'));
      return dir.slice('python'.length);
    } catch {
      // no venv support for this version
    }
  }
  return null;
}

export const PHPMYADMIN_ROOT = '/usr/share/phpmyadmin';
export const PHPMYADMIN_SITE = 'vaultpanel-phpmyadmin.conf';
const fileExists = (p) => access(p).then(() => true, () => false);

// What the heartbeat reports: installed, and the port (and domain) it is on.
export async function detectPhpMyAdmin(policy) {
  const installed = await fileExists(path.join(PHPMYADMIN_ROOT, 'index.php'));
  const text = await readFile(path.join(policy.nginxSitesEnabled ?? '/etc/nginx/sites-enabled', PHPMYADMIN_SITE), 'utf8').catch(() => null);
  const marker = text && /^# vaultpanel-phpmyadmin port=(\d+)(?: domain=(\S+))?$/m.exec(text);
  return {
    installed,
    port: installed && marker ? Number(marker[1]) : null,
    domain: installed && marker?.[2] ? marker[2] : null,
  };
}

// BIND for DNS zones (operations/dns.js): its files and how to tell the
// panel set it up.
export const DNS_MANAGED_MARK = '// Managed by VaultPanel';
export function dnsPaths(policy) {
  const root = policy.bindConfDir ?? '/etc/bind';
  const dir = path.join(root, 'vaultpanel');
  return {
    root,
    options: path.join(root, 'named.conf.options'),
    local: path.join(root, 'named.conf.local'),
    dir,
    zonesConf: path.join(dir, 'zones.conf'),
    zoneFile: (zone) => path.join(dir, `${zone}.db`),
    includeLine: `include "${path.join(dir, 'zones.conf')}"; // VaultPanel DNS zones`,
  };
}

export async function detectDns(policy, dirs = BIN_DIRS) {
  if (!(await findBinary('named', dirs))) return { installed: false, configured: false };
  const paths = dnsPaths(policy);
  const [options, local] = await Promise.all([readFile(paths.options, 'utf8').catch(() => ''), readFile(paths.local, 'utf8').catch(() => '')]);
  return { installed: true, configured: options.startsWith(DNS_MANAGED_MARK) && local.includes(paths.includeLine) };
}

// Postfix, Dovecot and OpenDKIM for email hosting (operations/mail.js):
// their files and how to tell the panel set them up.
export const MAIL_MANAGED_MARK = '# Managed by VaultPanel';
export function mailPaths(policy) {
  const postfix = policy.postfixConfDir ?? '/etc/postfix';
  const dovecot = policy.dovecotConfDir ?? '/etc/dovecot';
  const opendkimDir = policy.opendkimDir ?? '/etc/opendkim';
  const postfixMaps = path.join(postfix, 'vaultpanel');
  const dkim = path.join(opendkimDir, 'vaultpanel');
  return {
    postfix,
    postfixMaps,
    domainsMap: path.join(postfixMaps, 'domains'),
    mailboxesMap: path.join(postfixMaps, 'mailboxes'),
    forwardersMap: path.join(postfixMaps, 'forwarders'),
    serialFile: path.join(postfixMaps, 'serial'),
    dovecot,
    dovecotConf: path.join(dovecot, 'conf.d', '99-vaultpanel.conf'),
    dovecotAuth: path.join(dovecot, 'conf.d', '10-auth.conf'),
    dovecotUsers: path.join(dovecot, 'vaultpanel', 'users'),
    dovecotDenied: path.join(dovecot, 'vaultpanel', 'denied'),
    opendkimConf: policy.opendkimConf ?? '/etc/opendkim.conf',
    dkim,
    dkimKeys: path.join(dkim, 'keys'),
    keyTable: path.join(dkim, 'KeyTable'),
    signingTable: path.join(dkim, 'SigningTable'),
    trustedHosts: path.join(dkim, 'TrustedHosts'),
    tlsDir: policy.mailTlsDir ?? '/etc/vaultpanel-mail',
    letsencryptDir: policy.letsencryptDir ?? '/etc/letsencrypt',
    mailRoot: policy.mailRoot ?? '/var/mail/vhosts',
    renewHook: path.join(policy.letsencryptDir ?? '/etc/letsencrypt', 'renewal-hooks', 'deploy', 'vaultpanel-mail'),
  };
}

export async function detectMail(policy, dirs = BIN_DIRS) {
  const [postfix, dovecot, opendkim] = await Promise.all(['postfix', 'dovecot', 'opendkim'].map((b) => findBinary(b, dirs)));
  if (!postfix || !dovecot || !opendkim) return { installed: false, configured: false, hostname: null };
  const conf = await readFile(mailPaths(policy).dovecotConf, 'utf8').catch(() => '');
  const host = conf.startsWith(MAIL_MANAGED_MARK) ? /^# Mail host name: (\S+)$/m.exec(conf)?.[1] ?? null : null;
  return { installed: true, configured: Boolean(host), hostname: host };
}

export async function detectWebStack(policy, dirs = BIN_DIRS) {
  const nodeDir = appNodeDir(policy);
  const appDirs = nodeDir ? [...dirs, nodeDir] : dirs;
  const [nginx, certbot, apt, phpVersions, git, pm2, python, mariadbd, mysqld, cron, apache, go, ruby, bundle, composer] = await Promise.all([
    findBinary('nginx', dirs),
    findBinary('certbot', dirs),
    findBinary('apt-get', dirs),
    installedPhpVersions(policy.phpConfRoot, dirs),
    findBinary('git', dirs),
    findBinary('pm2-runtime', appDirs),
    pythonVersion(dirs, policy.pythonLibRoot),
    findBinary('mariadbd', dirs),
    findBinary('mysqld', dirs),
    findBinary('cron', dirs),
    findBinary('apache2', dirs),
    findBinary('go', dirs),
    findBinary('ruby', dirs),
    findBinary('bundle', dirs),
    findBinary('composer', dirs),
  ]);
  return {
    nginx: Boolean(nginx),
    certbot: Boolean(certbot),
    phpVersions,
    packageManager: apt ? 'apt' : null,
    git: Boolean(git),
    pm2: Boolean(pm2),
    python,
    node: nodeDir ? nodeVersion(nodeDir) : null,
    nodeInHome: !nodeDir,
    mariadb: Boolean(mariadbd || mysqld),
    cron: Boolean(cron),
    // Apache for .htaccess files (0.18.0).
    apache: Boolean(apache),
    // Go and Ruby apps, and Composer for PHP sites deployed from Git (0.32.0).
    go: Boolean(go),
    ruby: Boolean(ruby && bundle),
    composer: Boolean(composer),
    phpmyadmin: await detectPhpMyAdmin(policy),
    dns: await detectDns(policy, dirs),
    mail: await detectMail(policy, dirs),
  };
}

// VaultPanel apps on this server: the pm2-<name> units it wrote.
export async function scanAppUnits(policy) {
  const dir = policy.systemdUnitDir ?? '/etc/systemd/system';
  let names;
  try {
    names = await readdir(dir);
  } catch {
    return [];
  }
  const apps = [];
  for (const file of names) {
    const match = file.match(/^pm2-([a-z][a-z0-9-]{1,30}[a-z0-9])\.service$/);
    if (!match) continue;
    try {
      const head = (await readFile(path.join(dir, file), 'utf8')).slice(0, 200);
      if (head.startsWith('# Managed by VaultPanel')) apps.push(match[1]);
    } catch {
      // unreadable: not ours
    }
    if (apps.length >= 500) break;
  }
  return apps;
}

// Reads a PEM certificate: validity, issuer and the names it covers.
export function describeCertificate(pem) {
  const cert = new X509Certificate(pem);
  const domains = (cert.subjectAltName ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s.startsWith('DNS:'))
    .map((s) => s.slice(4));
  const issuer = cert.issuer.replace(/\n/g, ', ');
  return {
    notBefore: new Date(cert.validFrom).toISOString(),
    notAfter: new Date(cert.validTo).toISOString(),
    issuer: issuer.slice(0, 255),
    domains,
    // Let's Encrypt's staging CA names itself "(STAGING) ...".
    staging: /STAGING|Fake LE/i.test(issuer),
  };
}

// A certificate someone uploaded (INSTALL_SSL_CERT) rather than one Certbot
// keeps: Certbot does not renew it.
export const CUSTOM_CERT_MARKER = '.vaultpanel-custom';

export async function readCertificate(certDir) {
  let info;
  try {
    info = describeCertificate(await readFile(path.join(certDir, 'cert.pem'), 'utf8'));
  } catch {
    return null;
  }
  const custom = await readFile(path.join(certDir, CUSTOM_CERT_MARKER)).then(() => true, () => false);
  return { ...info, custom };
}

// Certificates under <letsencrypt>/live named vp-<site>.
export async function scanCertificates(policy) {
  const live = path.join(policy.letsencryptDir, 'live');
  let names;
  try {
    names = await readdir(live);
  } catch {
    return [];
  }
  const certificates = [];
  for (const name of names.filter((n) => /^vp-[a-z][a-z0-9-]{1,30}[a-z0-9]$/.test(n)).slice(0, 500)) {
    const info = await readCertificate(path.join(live, name));
    if (info) certificates.push({ site: name.slice(3), ...info });
  }
  return certificates;
}

// The server's own addresses (no loopback or link-local), so the panel can
// tell whether a domain points here.
export function localAddresses(interfaces = networkInterfaces()) {
  const out = new Set();
  for (const list of Object.values(interfaces)) {
    for (const entry of list ?? []) {
      if (entry.internal || entry.address.startsWith('fe80:')) continue;
      out.add(entry.address);
    }
  }
  return [...out].slice(0, 50);
}

// Heartbeats come every 15 seconds; the web stack rarely changes, so it is
// read at most every few minutes, or right after an operation changes it.
// readDatabases(webStack) lists the databases (see operations/databases.js);
// it is passed in so this module does not depend on the operations.
export function createWebInventory(policy, { ttlMs = 5 * 60_000, readDatabases = null, readBackups = null, readSecurity = null, readSelfCheck = null } = {}) {
  let cached = null;
  let readAt = 0;
  return {
    async read() {
      if (!cached || Date.now() - readAt > ttlMs) {
        const [webStack, certificates, appUnits] = await Promise.all([detectWebStack(policy), scanCertificates(policy), scanAppUnits(policy)]);
        const databases = webStack.mariadb && readDatabases ? await readDatabases().catch(() => null) : null;
        const checkedAt = new Date().toISOString();
        const backups = readBackups ? await readBackups().catch(() => null) : null;
        const security = readSecurity ? await readSecurity().catch(() => null) : null;
        const selfCheck = readSelfCheck ? await readSelfCheck().catch(() => null) : null;
        cached = {
          webStack,
          certificates,
          addresses: localAddresses(),
          appUnits,
          ...(databases ? { databases } : {}),
          ...(backups ? { backups: { checkedAt, files: backups } } : {}),
          ...(security ? { security } : {}),
          ...(selfCheck ? { selfCheck } : {}),
        };
        readAt = Date.now();
      }
      return cached;
    },
    invalidate() {
      cached = null;
    },
  };
}
