import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync, randomBytes, sign, verify } from 'node:crypto';

// The string signed for each request to the panel. Must match
// agentSigningString() in backend/src/services/agentService.js.
export function signingString({ method, path, timestamp, nonce, body }) {
  const bodyHash = createHash('sha256').update(body ?? '').digest('hex');
  return [method.toUpperCase(), path, timestamp, nonce, bodyHash].join('\n');
}

export function generateAgentKeyPair() {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  return {
    privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }),
    publicKeyPem: publicKey.export({ type: 'spki', format: 'pem' }),
  };
}

// Returns the authentication headers for one request.
export function signRequest({ agentId, privateKeyPem, method, path, body = '' }) {
  const timestamp = String(Date.now());
  const nonce = randomBytes(18).toString('base64url');
  const signature = sign(null, Buffer.from(signingString({ method, path, timestamp, nonce, body })), createPrivateKey(privateKeyPem));
  return {
    'X-VaultPanel-Agent-Id': agentId,
    'X-VaultPanel-Timestamp': timestamp,
    'X-VaultPanel-Nonce': nonce,
    'X-VaultPanel-Signature': signature.toString('base64'),
  };
}

// Stable JSON (sorted keys); must match canonicalJson() in the backend.
export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`)
      .join(',')}}`;
  }
  return JSON.stringify(value);
}

// Checks that a job envelope was signed by the panel this agent registered with.
export function verifyEnvelopeSignature(envelope, signature, panelPublicKeyPem) {
  try {
    return verify(
      null,
      Buffer.from(canonicalJson(envelope)),
      createPublicKey(panelPublicKeyPem),
      Buffer.from(String(signature), 'base64'),
    );
  } catch {
    return false;
  }
}
