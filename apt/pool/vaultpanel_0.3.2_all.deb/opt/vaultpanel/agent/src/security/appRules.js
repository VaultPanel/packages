// The agent's own copy of the application and database rules. The agent ships
// without the panel's shared package, so these are repeated here; a panel
// test checks they match @vaultpanel/shared exactly.

export const APP_RUNTIMES = ['node', 'python', 'go', 'ruby'];
export const REPOSITORY_URL_PATTERN =
  /^(?:https:\/\/[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?\/[A-Za-z0-9_~][A-Za-z0-9._~/-]*|ssh:\/\/(?:[a-z0-9_][a-z0-9_.-]*@)?[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?\/[A-Za-z0-9_~][A-Za-z0-9._~/-]*|[a-z0-9_][a-z0-9_.-]*@[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?:[A-Za-z0-9_~][A-Za-z0-9._~/-]*)$/i;
export const MAX_REPOSITORY_URL_LENGTH = 500;
export const BRANCH_PATTERN = /^(?![-/.])(?!.*(?:\.\.|\/\/|@\{|\/\.|\.lock$|\.$|\/$))[A-Za-z0-9._/-]{1,200}$/;
export const APP_PORT_MIN = 1024;
export const APP_PORT_MAX = 65535;
export const ENV_KEY_PATTERN = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;
export const RESERVED_ENV_KEYS = ['PORT', 'PATH', 'HOME', 'USER', 'PM2_HOME'];
export const MAX_ENV_VARS = 100;
export const MAX_ENV_VALUE_LENGTH = 8192;
export const MAX_COMMAND_LINES = 10;
export const MAX_COMMAND_LENGTH = 500;
export const RELEASE_ID_PATTERN = /^[0-9]{14}-[a-f0-9]{6}$/;
export const MAX_KEEP_RELEASES = 20;

export const DATABASE_NAME_PATTERN = /^[a-z][a-z0-9_]{1,63}$/;
export const DATABASE_USER_PATTERN = /^[a-z][a-z0-9_]{1,31}$/;
export const DATABASE_PASSWORD_PATTERN = /^[A-Za-z0-9!#%+,.:=?@^_~-]{12,72}$/;
export const RESERVED_DATABASE_NAMES = new Set(['mysql', 'information_schema', 'performance_schema', 'sys', 'test', 'phpmyadmin']);
export const RESERVED_DATABASE_USERS = new Set(['root', 'mysql', 'debian_sys_maint', 'admin', 'vaultpanel', 'mariadb', 'phpmyadmin']);
export const DATABASE_PRIVILEGES = ['all', 'readonly'];
export const MAX_USER_DATABASES = 50;

// Same as splitCommand in @vaultpanel/shared (a test runs both on the same
// inputs). Returns { argv } or { error }.
export function splitCommand(line) {
  const argv = [];
  let current = '';
  let inWord = false;
  let quote = null;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quote) {
      if (ch === quote) quote = null;
      else if (ch === '\\' && quote === '"' && (line[i + 1] === '"' || line[i + 1] === '\\')) current += line[++i];
      else current += ch;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      inWord = true;
    } else if (ch === ' ' || ch === '\t') {
      if (inWord) argv.push(current);
      current = '';
      inWord = false;
    } else if (ch === '\\') {
      if (i + 1 < line.length) current += line[++i];
      inWord = true;
    } else if ('|&;<>`'.includes(ch) || (ch === '$' && line[i + 1] === '(')) {
      return { error: `Commands run without a shell, so "${ch === '$' ? '$(' : ch}" is not supported. Put each command on its own line.` };
    } else {
      current += ch;
      inWord = true;
    }
  }
  if (quote) return { error: 'A quote is not closed' };
  if (inWord) argv.push(current);
  if (!argv.length) return { error: 'Empty command' };
  return { argv };
}

export function parseCommands(text) {
  if (typeof text !== 'string' || /[\0\r]/.test(text)) return { error: 'Commands must be plain text' };
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith('#'));
  if (lines.length > MAX_COMMAND_LINES) return { error: `Up to ${MAX_COMMAND_LINES} commands` };
  const commands = [];
  for (const [i, line] of lines.entries()) {
    if (line.length > MAX_COMMAND_LENGTH) return { error: `Line ${i + 1} is longer than ${MAX_COMMAND_LENGTH} characters` };
    const { argv, error } = splitCommand(line);
    if (error) return { error: lines.length > 1 ? `Line ${i + 1}: ${error}` : error };
    commands.push(argv);
  }
  return { commands };
}
