// The agent's own copy of the container rules (phase 10). The agent ships
// without the panel's shared package, so these are repeated here; a panel
// test checks they match @vaultpanel/shared exactly.

export const CONTAINER_NAME_PATTERN = /^[a-z][a-z0-9-]{1,30}[a-z0-9]$/;
export const CONTAINER_ID_PATTERN = /^[a-f0-9]{12,64}$/;
const COMPONENT = '[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*';
export const IMAGE_REF_PATTERN = new RegExp(
  `^(?:[a-z0-9]+(?:[.-][a-z0-9]+)*(?::[0-9]{1,5})?/)?${COMPONENT}(?:/${COMPONENT})*(?::[A-Za-z0-9_][A-Za-z0-9_.-]{0,127})?(?:@sha256:[a-f0-9]{64})?$`,
);
export const MAX_IMAGE_REF_LENGTH = 255;
export const IMAGE_ID_PATTERN = /^sha256:[a-f0-9]{64}$/;
export const PORT_MAPPING_PATTERN = /^(127\.0\.0\.1|0\.0\.0\.0):(\d{1,5}):(\d{1,5})\/(tcp|udp)$/;
export const MAX_CONTAINER_PORTS = 10;
export const VOLUME_NAME_PATTERN = /^[a-z][a-z0-9-]{0,30}$/;
export const CONTAINER_PATH_PATTERN = /^\/[A-Za-z0-9._@+-]+(?:\/[A-Za-z0-9._@+-]+)*$/;
export const MAX_CONTAINER_VOLUMES = 10;
export const RESTART_POLICY_KEYS = ['unless-stopped', 'always', 'on-failure', 'no'];
export const CONTAINER_CPU_PERCENT = { min: 5, max: 6400 };
export const CONTAINER_MEMORY_MB = { min: 32, max: 262_144 };
export const CONTAINER_HEALTH_SECONDS = { min: 3, max: 300, default: 10 };
export const CONTAINER_COMMAND_PATTERN = /^[^\0\r\n]*$/;
export const MAX_CONTAINER_COMMAND_LENGTH = 1000;
export const MAX_CONTAINER_COMMAND_ARGS = 100;
export const CONTAINER_NETWORK = 'vaultpanel';
export const CONTAINER_LABELS = { managed: 'io.vaultpanel.managed', id: 'io.vaultpanel.id', protected: 'io.vaultpanel.protected' };
export const MANAGED_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export function parsePortMapping(value) {
  const match = PORT_MAPPING_PATTERN.exec(String(value));
  if (!match) return null;
  const hostPort = Number(match[2]);
  const containerPort = Number(match[3]);
  if (hostPort < 1 || hostPort > 65535 || containerPort < 1 || containerPort > 65535) return null;
  return { address: match[1], hostPort, containerPort, protocol: match[4] };
}

export function parseVolumeMapping(value) {
  const parts = String(value).split(':');
  if (parts.length < 2 || parts.length > 3) return null;
  const [volume, path, mode] = parts;
  if (!VOLUME_NAME_PATTERN.test(volume)) return null;
  if (path.length > 200 || !CONTAINER_PATH_PATTERN.test(path) || path.split('/').some((p) => p === '..' || p === '.')) return null;
  if (mode !== undefined && mode !== 'ro') return null;
  return { volume, path, readOnly: mode === 'ro' };
}

export function dockerVolumeName(container, volume) {
  return `vp-${container}-${volume}`;
}
