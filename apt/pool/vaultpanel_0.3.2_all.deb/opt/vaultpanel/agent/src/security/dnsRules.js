// The agent's own copy of the DNS rules (see @vaultpanel/shared dns.js). A
// panel test checks the patterns match exactly.

export const DNS_RECORD_TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA'];
export const DNS_CAA_TAGS = ['issue', 'issuewild', 'iodef'];
export const DNS_TTL = { min: 60, max: 604_800 };
export const MAX_DNS_RECORDS = 500;

const LABEL = '[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9])?';
export const DNS_RECORD_NAME_PATTERN = new RegExp(`^(?=.{1,200}$)(?:@|\\*|(?:\\*\\.)?${LABEL}(?:\\.${LABEL})*)$`);
export const DNS_HOSTNAME_PATTERN = new RegExp(`^(?=.{3,253}$)${LABEL}(?:\\.${LABEL})+$`);
export const DNS_TXT_PATTERN = /^[\x20-\x7E]{1,2048}$/;
export const DNS_CAA_VALUE_PATTERN = /^[A-Za-z0-9.:;/=_@+-]{1,255}$/;
export const DNS_EMAIL_PATTERN = /^[a-z0-9](?:[a-z0-9._+-]{0,62}[a-z0-9])?@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]*[a-z0-9]$/;

// DNS providers the agent adds Let's Encrypt's check record to (0.38.0).
export const DNS_PROVIDER_TYPES = ['cloudflare', 'namecheap'];
export const CLOUDFLARE_TOKEN_PATTERN = /^[A-Za-z0-9_-]{20,200}$/;
export const NAMECHEAP_USER_PATTERN = /^[A-Za-z0-9_.-]{2,64}$/;
export const NAMECHEAP_KEY_PATTERN = /^[A-Za-z0-9]{16,64}$/;
