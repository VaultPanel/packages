// The agent's own copy of the email rules (see @vaultpanel/shared mail.js). A
// panel test checks the patterns match exactly.

export const MAIL_LOCAL_PART_PATTERN = /^(?=.{1,64}$)[a-z0-9_+-]+(?:\.[a-z0-9_+-]+)*$/;
const DOMAIN = '(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?';
export const MAIL_ADDRESS_PATTERN = new RegExp(`^(?=.{6,254}$)[a-z0-9_+-]+(?:\\.[a-z0-9_+-]+)*@${DOMAIN}$`);
export const MAIL_PASSWORD_HASH_PATTERN = /^\$6\$(?:rounds=\d{4,9}\$)?[./0-9A-Za-z]{1,16}\$[./0-9A-Za-z]{86}$/;
export const MAIL_DKIM_SELECTOR_PATTERN = /^[a-z0-9]{1,32}$/;
export const MAIL_QUOTA_MB = { min: 0, max: 1_048_576 };
export const MAX_MAIL_DOMAINS = 200;
export const MAX_MAILBOXES = 2000;
export const MAX_MAIL_FORWARDERS = 2000;
export const MAX_FORWARDER_DESTINATIONS = 20;
export const MAIL_FIREWALL_PORTS = [25, 465, 587, 993, 995];
