// The agent's own copy of the backup, cron and log rules (see
// @vaultpanel/shared automation.js and cron.js). A panel test checks they
// match.

export const BACKUP_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const SHA256_PATTERN = /^[0-9a-f]{64}$/;
export const BACKUP_AGENT_KINDS = ['site', 'app', 'database'];

// What the agent writes into /etc/cron.d: five fields of digits, letters,
// "*", ",", "/" and "-" separated by single spaces. The panel checks the
// meaning; this keeps anything else (newlines, extra fields, commands) out.
export const CRON_FIELD_PATTERN = /^[0-9A-Za-z*,/-]{1,40}$/;
export const CRON_TIMEOUT_MIN = 10;
export const CRON_TIMEOUT_MAX = 24 * 3600;
export const CRON_WORKING_DIR_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,4}$/;
export const CRON_OUTPUT_MAX_BYTES = 16 * 1024;

export const LOG_SOURCE_KEYS = ['journal', 'kernel', 'auth', 'cron'];
export const LOG_PRIORITY_KEYS = ['emerg', 'alert', 'crit', 'err', 'warning', 'notice', 'info', 'debug'];
export const LOG_SEARCH_PATTERN = /^[^\p{Cc}]{1,200}$/u;

export function checkCronSchedule(schedule) {
  if (typeof schedule !== 'string') return false;
  const fields = schedule.split(' ');
  return fields.length === 5 && fields.every((f) => CRON_FIELD_PATTERN.test(f));
}

// Backup storage (S3-compatible). The panel sends the destination with each
// job that needs it; nothing is kept on the server.
export const STORAGE_REGION_PATTERN = /^[a-z0-9-]{1,40}$/;
export const STORAGE_BUCKET_PATTERN = /^[A-Za-z0-9][A-Za-z0-9.-]{1,61}[A-Za-z0-9]$/;
export const STORAGE_ACCESS_KEY_PATTERN = /^[A-Za-z0-9+/=._-]{3,128}$/;
export const STORAGE_SECRET_PATTERN = /^[\x21-\x7e]{1,256}$/;
// An object key: folders of letters, digits, ".", "_" and "-"; no "." or ".." folders.
export const STORAGE_KEY_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,15}$/;
export const STORAGE_KEY_MAX_LENGTH = 512;

// The endpoint's URL, if it is a plain http(s) origin (no path, user or query).
export function checkStorageEndpoint(endpoint) {
  if (typeof endpoint !== 'string' || endpoint.length > 255) return null;
  let url;
  try {
    url = new URL(endpoint);
  } catch {
    return null;
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return null;
  if (url.pathname !== '/' && url.pathname !== '') return null;
  return url;
}

// Backup storage on another server over SFTP.
export const SFTP_HOST_PATTERN = /^(?:(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?|[0-9A-Fa-f:]{2,39})$/;
export const SFTP_USER_PATTERN = /^[A-Za-z_][A-Za-z0-9_.-]{0,31}$/;
// The folder on that server: relative to the user's home, or absolute.
export const SFTP_PATH_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))\/?[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,15}$/;
export const SFTP_PRIVATE_KEY_PATTERN = /^-----BEGIN OPENSSH PRIVATE KEY-----\n[A-Za-z0-9+/=\n]{20,4000}-----END OPENSSH PRIVATE KEY-----\n?$/;
// known_hosts lines as ssh-keyscan prints them.
export const SFTP_KNOWN_HOSTS_PATTERN = /^(?:(?:\[[A-Za-z0-9.:-]+\]:\d{1,5}|[A-Za-z0-9.:-]+) (?:ssh-ed25519|ecdsa-sha2-nistp(?:256|384|521)|ssh-rsa) [A-Za-z0-9+/]+={0,2}(?:\n|$)){1,3}$/;
