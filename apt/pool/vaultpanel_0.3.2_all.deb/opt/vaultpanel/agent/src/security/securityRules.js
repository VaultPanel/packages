// The agent's own copy of the security rules (see @vaultpanel/shared
// security.js). A panel test checks they match.
import net from 'node:net';

export const FIREWALL_ACTION_KEYS = ['allow', 'limit', 'deny', 'reject'];
export const FIREWALL_PROTOCOL_KEYS = ['tcp', 'udp', 'any'];
export const FIREWALL_INCOMING_POLICY_KEYS = ['deny', 'reject', 'allow'];
export const FIREWALL_OUTGOING_POLICY_KEYS = ['allow', 'deny', 'reject'];
export const FIREWALL_DIRECTION_KEYS = ['in', 'out'];
export const FIREWALL_MAX_PORTS = 15;
export const FIREWALL_COMMENT_PATTERN = /^[A-Za-z0-9 .,:_()/+-]{0,60}$/;
export const SSH_ROOT_LOGIN_KEYS = ['yes', 'prohibit-password', 'no'];
export const SSH_MAX_AUTH_TRIES_MIN = 1;
export const SSH_MAX_AUTH_TRIES_MAX = 10;
export const SSH_KEY_TYPES = [
  'ssh-ed25519',
  'ssh-rsa',
  'ecdsa-sha2-nistp256',
  'ecdsa-sha2-nistp384',
  'ecdsa-sha2-nistp521',
  'sk-ssh-ed25519@openssh.com',
  'sk-ecdsa-sha2-nistp256@openssh.com',
];
export const SSH_PUBLIC_KEY_PATTERN = new RegExp(
  `^(?:${SSH_KEY_TYPES.map((t) => t.replace(/[\\.@-]/g, '\\$&')).join('|')}) [A-Za-z0-9+/]{40,16000}={0,3}(?: [\\x20-\\x7e]{1,100})?$`,
);
export const SSH_FINGERPRINT_PATTERN = /^SHA256:[A-Za-z0-9+/]{43}$/;
export const SSH_USER_PATTERN = /^[a-z_][a-z0-9_-]{0,31}$/;
export const SSH_MAX_PORTS = 2;
export const SSH_RESERVED_PORTS = [80, 443];
export const FAIL2BAN_LIMITS = {
  maxRetry: { min: 1, max: 20, default: 5 },
  findTimeMinutes: { min: 1, max: 1440, default: 10 },
  banTimeMinutes: { min: 1, max: 43_200, default: 60 },
};
export const FAIL2BAN_MAX_IGNORE = 20;
export const SECURITY_TOOL_KEYS = ['ufw', 'fail2ban', 'unattended-upgrades'];
export const APP_CPU_LIMIT = { min: 10, max: 6400 };
export const APP_MEMORY_LIMIT_MB = { min: 64, max: 262_144 };
export const APP_INSTANCES = { min: 1, max: 16 };

// Same as parsePortSpec in @vaultpanel/shared.
export function parsePortSpec(spec) {
  if (typeof spec !== 'string' || !/^[0-9:,]{1,100}$/.test(spec)) return null;
  const ranges = [];
  let count = 0;
  for (const part of spec.split(',')) {
    const bounds = part.split(':');
    if (bounds.length > 2 || bounds.some((b) => !/^[1-9]\d{0,4}$/.test(b))) return null;
    const [from, to = from] = bounds.map(Number);
    if (from > 65535 || to > 65535 || to < from || (bounds.length === 2 && to === from)) return null;
    ranges.push({ from, to });
    count += bounds.length;
  }
  return count <= FIREWALL_MAX_PORTS ? ranges : null;
}

// 203.0.113.7, 203.0.113.0/24 or 2001:db8::/32.
export function isAddressOrNetwork(value) {
  if (typeof value !== 'string' || value.length > 50) return false;
  const [address, prefix, extra] = value.split('/');
  if (extra !== undefined) return false;
  const family = net.isIP(address);
  if (!family) return false;
  if (prefix === undefined) return true;
  return /^\d{1,3}$/.test(prefix) && Number(prefix) <= (family === 4 ? 32 : 128);
}
