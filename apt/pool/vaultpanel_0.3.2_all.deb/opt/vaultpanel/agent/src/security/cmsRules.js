// The agent's own copy of the app installer rules (a copy of
// @vaultpanel/shared's cms.js; a panel test checks they match).

export const CMS_APP_KEYS = ['wordpress', 'joomla', 'drupal', 'laravel'];
export const CMS_DIRECTORY_PATTERN = /^[A-Za-z0-9_-][A-Za-z0-9._-]{0,63}(?:\/[A-Za-z0-9_-][A-Za-z0-9._-]{0,63}){0,7}$/;
export const CMS_ADMIN_USER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{2,59}$/;
export const CMS_ADMIN_PASSWORD_PATTERN = /^[\x21-\x7E]{12,128}$/;
export const CMS_TITLE_PATTERN = /^[^\p{Cc}]{1,100}$/u;
export const CMS_URL_PATTERN = /^https?:\/\/[a-z0-9.-]{4,253}(?:\/[a-z0-9._-]+){0,8}\/?$/;
export const CMS_VERSION_PATTERN = /^[0-9]{1,3}(?:\.[0-9]{1,4}){0,3}$/;
// Top-level folders of a site the installer never takes or removes.
export const CMS_RESERVED_FOLDERS = ['tmp', 'logs', 'releases', 'shared', 'current'];
