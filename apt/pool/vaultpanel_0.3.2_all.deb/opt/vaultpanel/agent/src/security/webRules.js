// The agent's own copy of the website rules. The agent ships without the
// panel's shared package, so the patterns are repeated here; a panel test
// checks they match @vaultpanel/shared exactly.

export const SITE_NAME_PATTERN = /^[a-z][a-z0-9-]{1,30}[a-z0-9]$/;
export const DOMAIN_PATTERN = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
// A site's domains may also be a wildcard (*.example.com).
export const SITE_DOMAIN_PATTERN = /^(?=.{4,253}$)(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
export const DOCUMENT_ROOT_PATTERN = /^(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+){0,4}$/;
export const PHP_VERSION_PATTERN = /^[5-9]\.[0-9]$/;
export const PHP_VERSIONS = ['7.4', '8.0', '8.1', '8.2', '8.3', '8.4', '8.5'];
export const FILE_PATH_PATTERN = /^(?:(?!\.{1,2}(?:\/|$))[^/\p{Cc}]+(?:\/(?!$)|$))*$/u;
export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const SITE_TYPES = ['static', 'php', 'proxy'];
export const MAX_SITE_DOMAINS = 20;
export const MAX_FILE_PATH_LENGTH = 1024;
export const MAX_FILE_BYTES = 1024 * 1024;
export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024 * 1024;
export const MAX_COMPRESS_NAMES = 200;
export const FILE_NAME_PATTERN = /^(?!\.{1,2}$)[^/\p{Cc}]{1,255}$/u;

// Whether a certificate's names cover a domain: the name itself, or a
// wildcard (*.example.com) one level above it. A copy of @vaultpanel/shared.
export function certificateCovers(names, domain) {
  return (names ?? []).some((n) => n === domain || (n.startsWith('*.') && domain.endsWith(n.slice(1)) && domain.length > n.length - 1 && !domain.slice(0, domain.length - n.length + 1).includes('.')));
}

export function isWildcardDomain(domain) {
  return String(domain ?? '').startsWith('*.');
}

// Accounts a site may never be created as, whatever the panel asks.
export const RESERVED_SITE_NAMES = new Set([
  'root', 'daemon', 'bin', 'sys', 'sync', 'games', 'man', 'lp', 'mail', 'news', 'uucp', 'proxy', 'www-data',
  'backup', 'list', 'irc', 'gnats', 'nobody', 'systemd-network', 'systemd-resolve', 'messagebus', 'syslog',
  'sshd', 'ubuntu', 'debian', 'admin', 'nginx', 'apache', 'mysql', 'mariadb', 'postgres', 'redis', 'vaultpanel',
  'vaultpanel-agent', 'docker', 'certbot', 'letsencrypt', 'php', 'default', 'html', 'localhost', 'operator',
]);

// Custom NGINX rules staff can add to a site's server block. Only these
// directives are accepted (a copy of @vaultpanel/shared; a panel test checks they match):
// nothing that reads or writes files outside the site, loads code, or talks
// to a local socket.
export const MAX_CUSTOM_NGINX_LENGTH = 8192;
export const CUSTOM_NGINX_BLOCKS = Object.freeze(['location', 'if', 'limit_except']);
export const CUSTOM_NGINX_DIRECTIVES = Object.freeze([
  'absolute_redirect', 'add_header', 'add_trailer', 'allow', 'autoindex', 'break', 'charset', 'client_body_timeout',
  'client_max_body_size', 'default_type', 'deny', 'error_page', 'etag', 'expires', 'fastcgi_buffer_size', 'fastcgi_buffers',
  'fastcgi_param', 'fastcgi_read_timeout', 'gzip', 'gzip_comp_level', 'gzip_min_length', 'gzip_proxied', 'gzip_types',
  'gzip_vary', 'if_modified_since', 'index', 'internal', 'keepalive_timeout', 'limit_rate', 'limit_rate_after',
  'log_not_found', 'merge_slashes', 'port_in_redirect', 'proxy_buffering', 'proxy_cache_bypass', 'proxy_connect_timeout',
  'proxy_hide_header', 'proxy_http_version', 'proxy_pass', 'proxy_pass_header', 'proxy_read_timeout', 'proxy_redirect',
  'proxy_send_timeout', 'proxy_set_header', 'return', 'rewrite', 'satisfy', 'send_timeout', 'server_name_in_redirect',
  'set', 'sub_filter', 'sub_filter_once', 'sub_filter_types', 'try_files', 'valid_referers',
]);

// The first problem with custom NGINX rules, or null. Reads them the way
// NGINX does: statements end with ";", blocks open with "{" and close with
// "}", quotes group words and "#" starts a comment.
export function customNginxProblem(text) {
  if (typeof text !== 'string') return 'Must be text';
  if (text.length > MAX_CUSTOM_NGINX_LENGTH) return `At most ${MAX_CUSTOM_NGINX_LENGTH} characters`;
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(text)) return 'Contains control characters';
  let depth = 0;
  let words = [];
  let word = '';
  let quote = null;
  let comment = false;
  const endWord = () => {
    if (word) words.push(word);
    word = '';
  };
  const check = (opensBlock) => {
    const [name, ...args] = words;
    words = [];
    if (!name) return opensBlock ? 'A "{" has no directive before it' : null;
    const allowed = opensBlock ? CUSTOM_NGINX_BLOCKS : CUSTOM_NGINX_DIRECTIVES;
    if (!allowed.includes(name)) return `${opensBlock ? 'Blocks' : 'The directive'} "${name.slice(0, 40)}" ${opensBlock ? 'are' : 'is'} not allowed in custom rules`;
    if (args.some((a) => /unix:/i.test(a))) return 'Unix sockets are not allowed in custom rules';
    // A fixed http(s) address, so a variable cannot turn it into a socket.
    if (name === 'proxy_pass' && !/^https?:\/\/[A-Za-z0-9.:[\]-]+(?:\/\S*)?$/.test(args[0] ?? '')) return 'proxy_pass needs a fixed http:// or https:// address';
    return null;
  };
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (comment) {
      if (c === '\n') comment = false;
      continue;
    }
    if (quote) {
      if (c === '\\' && i + 1 < text.length) {
        word += c + text[i + 1];
        i += 1;
      } else if (c === quote) {
        quote = null;
        word += c;
      } else word += c;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      word += c;
    } else if (c === '#' && !word) comment = true;
    else if (/\s/.test(c)) endWord();
    else if (c === ';' || c === '{') {
      endWord();
      const problem = check(c === '{');
      if (problem) return problem;
      if (c === '{') depth += 1;
    } else if (c === '}') {
      endWord();
      if (words.length) return `"${words[0].slice(0, 40)}" is missing its ";"`;
      if (depth === 0) return 'A "}" closes a block that was never opened';
      depth -= 1;
    } else word += c;
  }
  endWord();
  if (quote) return 'A quote is never closed';
  if (words.length) return `"${words[0].slice(0, 40)}" is missing its ";"`;
  if (depth) return 'A "{" is never closed';
  return null;
}
