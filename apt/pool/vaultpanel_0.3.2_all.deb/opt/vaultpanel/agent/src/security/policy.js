// Local policy: what this agent agrees to do, whatever the panel asks. The
// server owner controls it through the agent config file.

export const SERVICE_NAME_PATTERN = /^[a-zA-Z0-9][a-zA-Z0-9:_.@-]{0,99}$/;

export const DEFAULT_ALLOWED_SERVICES = [
  'nginx',
  'apache2',
  'php*-fpm',
  'mariadb',
  'mysql',
  'postgresql',
  'postgresql@*',
  'redis',
  'redis-server',
  'docker',
  'containerd',
  'cron',
  'ssh',
  'sshd',
  'ufw',
  'fail2ban',
  'pm2-*',
  'named',
  'bind9',
  'postfix',
  'dovecot',
  'opendkim',
];

export const DEFAULT_WATCH_SERVICES = [
  'nginx',
  'php8.3-fpm',
  'php8.2-fpm',
  'php8.1-fpm',
  'mariadb',
  'mysql',
  'postgresql',
  'redis-server',
  'docker',
  'cron',
  'ssh',
  'ufw',
  'named',
  'postfix',
  'dovecot',
  'opendkim',
];

// The agent's own unit and its root helper's are never restartable through a
// job: restarting them would kill the job that asked for it.
const NEVER_ALLOWED = new Set(['vaultpanel-agent', 'vaultpanel-agent-helper']);

// Services that may be restarted but never stopped from the panel: stopping
// them would lock everyone out of the server.
const NEVER_STOPPED = new Set(['ssh', 'sshd']);

// Processes the agent refuses to signal, whatever the panel asks. Killing any
// of them takes the server (or remote access to it) down.
export const PROTECTED_PROCESSES = new Set([
  'systemd',
  'init',
  'sshd',
  'systemd-journal',
  'systemd-logind',
  'systemd-udevd',
  'dbus-daemon',
]);

export function normalizeServiceName(name) {
  return String(name).replace(/\.service$/, '');
}

function globToRegExp(glob) {
  const escaped = glob.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '[a-zA-Z0-9:_.@-]*');
  return new RegExp(`^${escaped}$`);
}

export function isServiceStoppable(name) {
  return !NEVER_STOPPED.has(normalizeServiceName(name));
}

export function isServiceAllowed(name, allowList = DEFAULT_ALLOWED_SERVICES) {
  if (!SERVICE_NAME_PATTERN.test(String(name))) return false;
  const unit = normalizeServiceName(name);
  if (NEVER_ALLOWED.has(unit)) return false;
  return allowList.some((pattern) => globToRegExp(pattern).test(unit));
}
