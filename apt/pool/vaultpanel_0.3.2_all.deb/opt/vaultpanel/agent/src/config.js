import { chmod, mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { DEFAULT_ALLOWED_SERVICES, DEFAULT_WATCH_SERVICES } from './security/policy.js';

export const DEFAULT_CONFIG_PATH = process.env.VAULTPANEL_AGENT_CONFIG || '/etc/vaultpanel-agent/config.json';

export async function loadConfig(configPath = DEFAULT_CONFIG_PATH) {
  let raw;
  try {
    raw = await readFile(configPath, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') {
      throw new Error(`No agent config at ${configPath}. Run "vaultpanel-agent register" first.`, { cause: err });
    }
    throw err;
  }
  const config = JSON.parse(raw);
  for (const key of ['panelUrl', 'agentId', 'serverId', 'panelPublicKey', 'privateKeyPath']) {
    if (!config[key]) throw new Error(`Agent config is missing "${key}"`);
  }
  return withDefaults(config);
}

export function withDefaults(config) {
  return {
    heartbeatIntervalSeconds: 15,
    allowInsecureHttp: false,
    allowReboot: true,
    allowProcessSignals: true,
    allowedServices: DEFAULT_ALLOWED_SERVICES,
    watchServices: DEFAULT_WATCH_SERVICES,
    diskPath: '/',
    // Websites (phase 3). Paths follow the Ubuntu/Debian layout.
    allowWebsites: true,
    allowWebStackInstall: true,
    sitesRoot: '/var/www',
    nginxSitesAvailable: '/etc/nginx/sites-available',
    nginxSitesEnabled: '/etc/nginx/sites-enabled',
    nginxConfD: '/etc/nginx/conf.d',
    nginxLogDir: '/var/log/nginx',
    acmeWebroot: '/var/lib/vaultpanel/acme',
    letsencryptDir: '/etc/letsencrypt',
    phpConfRoot: '/etc/php',
    phpRunDir: '/run/php',
    webServerUser: 'www-data',
    // Apache for sites with .htaccess files on: behind NGINX on 127.0.0.1,
    // running as its own user so it cannot reach the www-data PHP pool.
    apacheUser: 'vp-apache',
    apachePort: 8080,
    apacheConfRoot: '/etc/apache2',
    apacheSitesAvailable: '/etc/apache2/sites-available',
    apacheSitesEnabled: '/etc/apache2/sites-enabled',
    apacheLogDir: '/var/log/apache2',
    passwdFile: '/etc/passwd',
    // Applications and databases (phase 4).
    allowApplications: true,
    allowDatabases: true,
    systemdUnitDir: '/etc/systemd/system',
    // Node.js for apps: the one the agent runs on, unless set.
    nodeBinDir: null,
    // npm's cache for installing PM2. The agent's service makes /root read-only
    // (ProtectHome), so npm cannot use ~/.npm.
    npmCacheDir: '/var/cache/vaultpanel/npm',
    // A MySQL client options file with root credentials, when root cannot
    // sign in over the unix socket.
    mysqlDefaultsFile: null,
    // Extra environment for git, npm and pip during deployments (proxy settings).
    deployEnv: {},
    // Backups, cron jobs and logs (phase 5).
    allowBackups: true,
    allowCron: true,
    backupRoot: '/var/backups/vaultpanel',
    // Backups are refused when less than this is free where they are kept.
    backupMinFreeBytes: 512 * 1024 * 1024,
    cronFile: '/etc/cron.d/vaultpanel',
    cronSpecDir: '/etc/vaultpanel-agent/cron',
    cronStateDir: '/var/lib/vaultpanel/cron',
    // Agent updates from the panel (phase 7).
    allowSelfUpdate: true,
    agentInstallDir: '/opt/vaultpanel-agent',
    // Docker containers (phase 10), through the Docker API socket (found at
    // /var/run/docker.sock or /run/docker.sock unless set).
    allowContainers: true,
    dockerSocket: null,
    // The server terminal (0.11.0): owners open a root shell from the panel.
    // false turns it off on this server.
    allowTerminal: true,
    // Start the shell outside the agent's sandboxed service (see terminal.js).
    terminalHostNamespace: true,
    // DNS zones (0.15.0), served by BIND from its Debian/Ubuntu layout.
    allowDns: true,
    bindConfDir: '/etc/bind',
    // DNS providers' credentials for wildcard certificates (0.38.0), one
    // file per certificate, readable by root only.
    acmeDnsDir: '/etc/vaultpanel-agent/acme-dns',
    // Email hosting (0.16.0): Postfix, Dovecot and OpenDKIM.
    allowMail: true,
    mailRoot: '/var/mail/vhosts',
    ...config,
  };
}

// Writes atomically with owner-only permissions.
export async function saveSecretFile(filePath, contents) {
  await mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 });
  const tmp = `${filePath}.tmp-${process.pid}`;
  await writeFile(tmp, contents, { mode: 0o600 });
  await chmod(tmp, 0o600);
  await rename(tmp, filePath);
}
