# VaultPanel

A modern, secure web control panel for Linux servers: connect a server, then deploy and run
production applications with their domains, databases, SSL, process management, monitoring,
backups and security, with minimal manual Linux administration.

**Status:** Phases 0 to 9 of the [roadmap](docs/roadmap.md) are done, and most of Phase 10
(containers, API tokens, the CLI and SDK, plugins, scaling an app on one server). What is not built
yet is listed in the roadmap and shown as unavailable in the UI. Every operation's logs are kept and
every change is audited.

## Features

**Servers**

- Connect servers through a small agent (the server the panel runs on connects itself). The agent
  runs as its own user; a root helper runs only the operations the panel has signed, from a fixed
  allow-list.
- Live and historical monitoring with charts, services and processes, and alerts by email and
  webhook. A self-check on each server confirms every 5 minutes that the panel's features will work
  there (`nginx -t`, Certbot's timer, the clock, failed units…) and shows the command to fix a
  failure.
- A root terminal in the browser for owners, with recordings that can be replayed or downloaded.
- Firewall (UFW, incoming and outgoing rules), SSH settings, port and keys, Fail2ban and security
  updates, managed from the panel.
- Server groups watched together and given one action at once: restart a service, install updates,
  reboot one at a time, update their agents.

**Websites, DNS and email**

- Static websites (with a single-page app setting), PHP sites on PHP-FPM with a PHP version per site
  (7.4 and 8.0 to 8.5), and reverse proxies to an app. NGINX is set up for you, with custom NGINX
  rules for staff and `.htaccess` support through Apache behind NGINX.
- Free Let's Encrypt certificates, your own uploaded certificates, and wildcard certificates through
  the panel's DNS zones, Cloudflare or Namecheap. A site can list `*.example.com` to serve every
  subdomain no other site claims.
- Install WordPress, Joomla, Drupal or Laravel in one step, with its database.
- A file manager, NGINX logs, DNS checks, and uptime monitoring that checks each site the way
  visitors reach it, with a **Website down** alert.
- DNS zones served by the panel's own servers (BIND), and email hosting (Postfix, Dovecot,
  OpenDKIM) with mailboxes, forwarders and DKIM-signed mail.

**Apps, databases and containers**

- Node.js, Python, Go and Ruby apps (and PHP websites) deploy from Git into release folders, run
  under PM2 as their own Linux user, and get a domain and SSL through a linked website. They can be
  rolled back, deployed on every push (signed webhooks), reloaded without downtime (Node.js), run as
  several copies on one server, and capped on CPU and memory.
- MariaDB databases and users with generated passwords, added to an app's environment in one step.
  Browse a database in the panel's SQL client, or open it in phpMyAdmin with one-click sign-in.
  MySQL 8.4 and 8.0 come in a later version.
- Docker containers from public images, with ports, volumes, environment variables and limits.
  Updates roll back automatically when the new container does not start.

**Backups and automation**

- Back up websites, apps and databases on demand or on a schedule, on the server, in an
  S3-compatible bucket (Amazon S3, Backblaze B2, Wasabi, Cloudflare R2, MinIO) or on another server
  over SFTP. Restore in place (with a safety copy first) or download.
- Cron jobs run as each site's own user, with their output kept. Server logs can be read and
  searched.
- Webhooks (JSON, Slack or Discord) report backups, cron failures, deployments, alerts and servers
  going offline.

**Hosting and billing**

- Hosting plans set how many websites, apps, databases and cron jobs a customer may have, their disk
  space and caps on each app. Customers sign in to a panel that shows only their own account, and
  can be suspended and removed.
- A billing API lets WHMCS, Blesta or your own billing system manage accounts. A
  [WHMCS module](integrations/whmcs/README.md) is included: create, suspend, upgrade, terminate,
  passwords, single sign-on and disk usage.
- A financial report of what accounts are worth at their plans' prices.

**Access and security**

- Sign-in with optional two-factor authentication and recovery codes, a session list, users and
  roles, panel access limited by IP address, and an audit log.
- The panel runs as an unprivileged `vaultpanel` user in a systemd sandbox and serves HTTPS from the
  first start. Agents installed against its self-signed certificate pin it, so servers can be added
  safely without a domain.

**AI assistant**

- Claude by default, or any OpenAI-compatible service such as Ollama, answers questions about your
  servers by reading their status and logs through the panel, and proposes fixes that run only when
  someone approves them.

**Extending VaultPanel**

- A REST API with scoped, revocable API tokens, the `@vaultpanel/sdk` JavaScript client and the
  `vaultpanel` command-line tool built on it.
- Plugins add features and connect outside services without changing the panel: an owner approves
  what each one may do, and it then works through the API, hears about events and can add its own
  page. Plugins can be installed by URL or from plugin directories.

## Install on a server

On a fresh server with Ubuntu 22.04, 24.04 or 26.04, or Debian 12 or 13 (2 GB of memory or more
recommended), as root ([docs/install.md](docs/install.md)). First update the system and make sure
`curl` and `sudo` are there:

```sh
apt update && apt -y upgrade && apt -y install curl wget sudo
```

Then download the installer, check it and run it, with the database server you want for your
websites and apps. The checksum changes with each release: copy the command with the current one
from [github.com/VaultPanel/packages](https://github.com/VaultPanel/packages), where each release
publishes it.

```sh
curl -sS https://installer.vaultpanel.net/v2/install.sh -o install.sh; \
echo "<checksum from github.com/VaultPanel/packages> install.sh" | \
sha256sum -c && sudo DB_ENGINE=MARIADB_12.3 bash install.sh
```

| System           | `DB_ENGINE`                                       |
| ---------------- | ------------------------------------------------- |
| Ubuntu 26.04 LTS | `MARIADB_12.3`, `MARIADB_11.8`                    |
| Ubuntu 24.04 LTS | `MARIADB_12.3`, `MARIADB_11.4`, `MARIADB_10.11`   |
| Ubuntu 22.04 LTS | `MARIADB_11.4`, `MARIADB_10.11`, `MARIADB_10.6`   |
| Debian 13        | `MARIADB_12.3`, `MARIADB_11.8`                    |
| Debian 12        | `MARIADB_12.3`, `MARIADB_11.4`, `MARIADB_10.11`   |

MySQL 8.4 and 8.0 come in a later version. Without `DB_ENGINE` the installer takes the newest
MariaDB for your system; `DB_ENGINE=NONE` installs no database server.

It installs the latest release (or the one given with `--version vX.Y.Z`) and runs VaultPanel as an
unprivileged service that starts at boot. The panel is served over HTTPS on port 8090 from the first
start, with a self-signed certificate; add a domain for a trusted one. The installer also schedules
a daily backup of the panel, prints the panel's address and setup token, and adds the `vaultpanel`
command on the server (address, status, logs, `update`, `backup`, `restore`, `rollback`, `https`).
Running it again updates in place.

## Quick start (development)

Requires Node.js 22+, with MariaDB and Redis (Docker can provide both). See
[docs/development.md](docs/development.md). In short:

```sh
docker compose -f docker/compose.yml up -d
cp .env.example .env   # set VAULTPANEL_SECRET_KEY=$(openssl rand -hex 32)
npm install && npm run db:migrate
npm run dev:backend & npm run dev:worker & npm run dev:frontend
```

Then open http://localhost:5173/setup and create the owner with the setup token from the API log.
Checks: `npm run lint`, `npm test` (needs MariaDB and Redis), `npm run build` and
`npm run test:e2e` ([e2e/README.md](e2e/README.md)).

## Stack

JavaScript throughout. React + Vite + Tailwind UI, Express API, MariaDB (Knex), Redis + BullMQ,
and a dependency-free Node.js agent on each server.

| Path                     | What it is                                                                                                  |
| ------------------------ | ----------------------------------------------------------------------------------------------------------- |
| `frontend/`              | Web UI                                                                                                      |
| `backend/`               | API, services, background worker                                                                            |
| `agent/`                 | Server agent (versioned on its own, see `agent/package.json`)                                               |
| `shared/`                | Permissions, roles and operation catalog shared by UI and API                                               |
| `sdk/`                   | `@vaultpanel/sdk`, the JavaScript client for the REST API                                                   |
| `cli/`                   | `vaultpanel`, the command-line tool, built on the SDK                                                       |
| `database/`              | Migrations                                                                                                  |
| `docker/`                | MariaDB and Redis for development (`compose.yml`) and for installed panels (`compose.prod.yml`)             |
| `install.sh`, `scripts/` | The installer, the agent installer and the `vaultpanel` server command                                      |
| `packaging/`             | The `vaultpanel` package, the APT repository and the public site at installer.vaultpanel.net                |
| `integrations/`          | Billing system modules (WHMCS)                                                                              |
| `examples/`              | An example plugin (`status-board-plugin`)                                                                   |
| `e2e/`                   | End-to-end smoke tests (Playwright)                                                                         |
| `docs/`                  | Documentation                                                                                               |
| `.github/`               | CI, CodeQL, the package check, releases (published to VaultPanel/packages) and npm publishing              |

## Docs

[Install](docs/install.md) · [Architecture](docs/architecture.md) · [Database](docs/database.md) · [API](docs/api.md) ·
[Agent](docs/agent.md) · [CLI](docs/cli.md) · [SDK](docs/sdk.md) · [Plugins](docs/plugins.md) ·
[Security](docs/security.md) · [Deployment](docs/deployment.md) ·
[Development](docs/development.md) · [Troubleshooting](docs/troubleshooting.md) ·
[Roadmap](docs/roadmap.md) · [Testing guide](docs/testing-vaultpanel.md) ·
[Publishing](docs/publishing.md) · [Changelog](CHANGELOG.md) · [Contributing](CONTRIBUTING.md) ·
[Security policy](SECURITY.md)

## License

VaultPanel is proprietary software, free to use under the [VaultPanel License](LICENSE): people may
install and use it, also to host their customers, but not copy, change, resell or redistribute it.
Copyright (C) 2026 Abdulwakili. Versions published while this repository was public stay under the
license they were published with (MIT, then AGPL-3.0).

The parts other software is built with stay [MIT](sdk/LICENSE), each with its own `LICENSE` file:
the SDK (`sdk/`), the CLI (`cli/`), the WHMCS module (`integrations/whmcs/`) and the example plugin
(`examples/status-board-plugin/`).
