# @vaultpanel/sdk

A JavaScript client for the REST API of [VaultPanel](https://github.com/VaultPanel/VaultPanel), a
web control panel for Linux servers. One small class over `fetch`, no dependencies.

```bash
npm install @vaultpanel/sdk
```

```js
import { VaultPanel } from '@vaultpanel/sdk';

const panel = new VaultPanel({
  baseUrl: 'https://panel.example.com',   // or VAULTPANEL_URL
  token: process.env.VAULTPANEL_TOKEN,    // an API token: Users > API Tokens in the panel
});

const { items } = await panel.servers.list();
const { job } = await panel.applications.deploy(appId);
const { job: done } = await panel.jobs.wait(job.id);   // throws on timeout, never pretends
```

Needs Node.js 22 or newer. The token acts as the person who made it, limited to its scopes.

- Methods for servers, websites, DNS, email, apps, deployments, databases, containers, backups, cron
  jobs, webhooks, alerts, monitoring, security, jobs, users, the audit log, API tokens, hosting and
  plugins; `panel.request()` and `panel.raw()` reach anything else.
- `panel.paginate()` / `panel.listAll()` walk list endpoints.
- Every failure throws a `VaultPanelError` with `status`, `code`, `fieldErrors` and `requestId`.
- `verifyEvent()` and `verifyLaunch()` check what the panel signs, for plugin authors.

Full guide: [docs/sdk.md](https://github.com/VaultPanel/VaultPanel/blob/main/docs/sdk.md).

MIT licensed.
