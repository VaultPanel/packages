import { VaultPanelError } from './errors.js';

const DEFAULT_TIMEOUT_MS = 30_000;
const RETRY_STATUSES = new Set([429, 502, 503, 504]);

// The HTTP layer: one place that adds the token, builds the URL, unwraps the
// { success, data, message, requestId } envelope and turns failures into a
// VaultPanelError. Everything else in the SDK goes through request().
export class HttpClient {
  #baseUrl;
  #token;
  #fetch;
  #timeoutMs;
  #retries;
  #userAgent;
  #onRequest;

  constructor({ baseUrl, token, fetch: fetchImpl, timeoutMs = DEFAULT_TIMEOUT_MS, retries = 2, userAgent = 'vaultpanel-sdk', onRequest = null } = {}) {
    if (!baseUrl) throw new VaultPanelError('A baseUrl is required, for example https://panel.example.com', { code: 'CONFIG' });
    this.#baseUrl = normalizeBaseUrl(baseUrl);
    this.#token = token ?? null;
    this.#fetch = fetchImpl ?? globalThis.fetch?.bind(globalThis);
    if (!this.#fetch) throw new VaultPanelError('No fetch available in this runtime; pass one as `fetch`', { code: 'CONFIG' });
    this.#timeoutMs = timeoutMs;
    this.#retries = retries;
    this.#userAgent = userAgent;
    this.#onRequest = onRequest;
  }

  get baseUrl() {
    return this.#baseUrl;
  }

  // The API's base, including the version: https://panel.example.com/api/v1
  get apiUrl() {
    return `${this.#baseUrl}/api/v1`;
  }

  urlFor(path, query) {
    const url = new URL(`${this.apiUrl}${path.startsWith('/') ? path : `/${path}`}`);
    for (const [key, value] of Object.entries(query ?? {})) {
      if (value === undefined || value === null) continue;
      if (Array.isArray(value)) value.forEach((v) => url.searchParams.append(key, String(v)));
      else url.searchParams.set(key, String(value));
    }
    return url.toString();
  }

  // Returns the envelope's `data`. `raw: true` returns the whole envelope,
  // which is how a caller gets the message and request id.
  async request(method, path, { query, body, headers, raw = false, timeoutMs, idempotent } = {}) {
    const url = this.urlFor(path, query);
    const verb = method.toUpperCase();
    const canRetry = idempotent ?? verb === 'GET';
    const init = {
      method: verb,
      headers: {
        Accept: 'application/json',
        'User-Agent': this.#userAgent,
        ...(this.#token ? { Authorization: `Bearer ${this.#token}` } : {}),
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        ...headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    };
    this.#onRequest?.({ method: verb, url });

    let lastError;
    for (let attempt = 0; attempt <= (canRetry ? this.#retries : 0); attempt += 1) {
      if (attempt > 0) await sleep(backoffMs(attempt, lastError));
      try {
        const envelope = await this.#send(url, init, timeoutMs ?? this.#timeoutMs);
        return raw ? envelope : envelope.data;
      } catch (err) {
        lastError = err;
        const retryable = err instanceof VaultPanelError && (RETRY_STATUSES.has(err.status) || err.code === 'NETWORK' || err.code === 'TIMEOUT');
        if (!retryable) throw err;
      }
    }
    throw lastError;
  }

  async #send(url, init, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res;
    try {
      res = await this.#fetch(url, { ...init, signal: controller.signal });
    } catch (err) {
      const timedOut = controller.signal.aborted;
      throw new VaultPanelError(
        timedOut ? `The panel did not answer within ${timeoutMs}ms` : `Could not reach the panel at ${this.#baseUrl}: ${err.message}`,
        { code: timedOut ? 'TIMEOUT' : 'NETWORK', cause: err },
      );
    } finally {
      clearTimeout(timer);
    }

    const text = await res.text();
    let envelope = null;
    try {
      envelope = text ? JSON.parse(text) : null;
    } catch {
      // Not JSON: a proxy error page, or the wrong URL.
    }
    if (!envelope || typeof envelope !== 'object') {
      throw new VaultPanelError(`The panel answered ${res.status} with something that is not JSON. Is ${this.apiUrl} the panel's API?`, {
        status: res.status,
        code: 'BAD_RESPONSE',
      });
    }
    if (!res.ok || envelope.success === false) {
      const error = envelope.error ?? {};
      throw new VaultPanelError(error.message ?? `The panel answered ${res.status}`, {
        status: res.status,
        code: error.code ?? 'REQUEST_FAILED',
        details: error.details ?? null,
        requestId: envelope.requestId ?? null,
      });
    }
    return envelope;
  }
}

function normalizeBaseUrl(baseUrl) {
  // Trailing slashes off, without a pattern (/\/+$/ slows down on many slashes).
  const text = String(baseUrl).trim();
  let end = text.length;
  while (end > 0 && text[end - 1] === '/') end -= 1;
  const trimmed = text.slice(0, end);
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  // Both "https://panel" and "https://panel/api/v1" are accepted.
  return withScheme.replace(/\/api\/v1$/, '');
}

function backoffMs(attempt, err) {
  const retryAfter = Number(err?.details?.retryAfterSeconds);
  if (Number.isFinite(retryAfter) && retryAfter > 0) return Math.min(retryAfter * 1000, 10_000);
  return Math.min(250 * 2 ** (attempt - 1), 4_000);
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
