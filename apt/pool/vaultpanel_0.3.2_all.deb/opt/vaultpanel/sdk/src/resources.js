// The resource methods, one object per area of the panel. Each one is a thin
// wrapper over client.request, so anything the REST API can do is reachable
// here, and anything not wrapped yet is still reachable with
// panel.request(...).
const FINAL_JOB_STATUSES = new Set(['succeeded', 'failed', 'timed_out', 'cancelled']);

export function buildResources(client, panel) {
  const get = (path, query, options) => client.request('GET', path, { query, ...options });
  const post = (path, body, options) => client.request('POST', path, { body, ...options });
  const patch = (path, body) => client.request('PATCH', path, { body });
  const put = (path, body) => client.request('PUT', path, { body });
  const del = (path, query) => client.request('DELETE', path, { query });

  return {
    servers: {
      list: (query) => get('/servers', query),
      get: (id) => get(`/servers/${id}`),
      create: (body) => post('/servers', body),
      update: (id, body) => patch(`/servers/${id}`, body),
      remove: (id) => del(`/servers/${id}`),
      metrics: (id, query) => get(`/servers/${id}/metrics`, query),
      enrollmentToken: (id) => post(`/servers/${id}/enrollment-tokens`),
      updateAgent: (id) => post(`/servers/${id}/agent-update`),
      // Runs one of the agent's allowlisted operations (see the operation
      // catalog in the panel: SERVICE_RESTART, SERVER_REBOOT...).
      runOperation: (id, body) => post(`/servers/${id}/jobs`, body),
      groups: {
        list: () => get('/server-groups'),
        get: (id) => get(`/server-groups/${id}`),
        create: (body) => post('/server-groups', body),
        update: (id, body) => patch(`/server-groups/${id}`, body),
        remove: (id) => del(`/server-groups/${id}`),
      },
    },
    bulkActions: {
      list: (query) => get('/bulk-actions', query),
      get: (id) => get(`/bulk-actions/${id}`),
      create: (body) => post('/bulk-actions', body),
      cancel: (id) => post(`/bulk-actions/${id}/cancel`),
    },
    websites: {
      list: (query) => get('/websites', query),
      get: (id) => get(`/websites/${id}`),
      create: (body) => post('/websites', body),
      update: (id, body) => patch(`/websites/${id}`, body),
      remove: (id, query) => del(`/websites/${id}`, query),
      enable: (id) => post(`/websites/${id}/enable`),
      disable: (id) => post(`/websites/${id}/disable`),
      retry: (id) => post(`/websites/${id}/retry`),
      issueSsl: (id, body) => post(`/websites/${id}/ssl`, body),
      renewSsl: (id, body) => post(`/websites/${id}/ssl/renew`, body),
      disableSsl: (id) => del(`/websites/${id}/ssl`),
      logs: (id, body) => post(`/websites/${id}/logs`, body),
      checkDns: (id) => post(`/websites/${id}/dns-check`),
      files: (id, action, body) => post(`/websites/${id}/files/${action}`, body),
    },
    domains: { list: (query) => get('/domains', query) },
    subdomains: {
      parents: () => get('/subdomains/parents'),
      create: (body) => post('/subdomains', body),
    },
    dns: {
      zones: (query) => get('/dns/zones', query),
      zone: (id) => get(`/dns/zones/${id}`),
      createZone: (body) => post('/dns/zones', body),
      updateZone: (id, body) => patch(`/dns/zones/${id}`, body),
      removeZone: (id) => del(`/dns/zones/${id}`),
      apply: (id) => post(`/dns/zones/${id}/apply`),
      check: (id) => post(`/dns/zones/${id}/check`),
      addRecord: (zoneId, body) => post(`/dns/zones/${zoneId}/records`, body),
      updateRecord: (zoneId, recordId, body) => patch(`/dns/zones/${zoneId}/records/${recordId}`, body),
      removeRecord: (zoneId, recordId) => del(`/dns/zones/${zoneId}/records/${recordId}`),
    },
    mail: {
      servers: () => get('/mail/servers'),
      setupServer: (body) => post('/mail/servers', body),
      domains: (query) => get('/mail/domains', query),
      domain: (id) => get(`/mail/domains/${id}`),
      createDomain: (body) => post('/mail/domains', body),
      removeDomain: (id, query) => del(`/mail/domains/${id}`, query),
      checkDns: (id) => post(`/mail/domains/${id}/check`),
      createMailbox: (domainId, body) => post(`/mail/domains/${domainId}/mailboxes`, body),
      updateMailbox: (domainId, id, body) => patch(`/mail/domains/${domainId}/mailboxes/${id}`, body),
      removeMailbox: (domainId, id, query) => del(`/mail/domains/${domainId}/mailboxes/${id}`, query),
      createForwarder: (domainId, body) => post(`/mail/domains/${domainId}/forwarders`, body),
      removeForwarder: (domainId, id) => del(`/mail/domains/${domainId}/forwarders/${id}`),
    },
    // One-click apps (WordPress, Joomla, Drupal, Laravel...).
    cms: {
      catalog: () => get('/cms/apps'),
      installs: (query) => get('/cms/installs', query),
      install: (body) => post('/cms/installs', body),
      get: (id) => get(`/cms/installs/${id}`),
      remove: (id, query) => del(`/cms/installs/${id}`, query),
    },
    certificates: { list: (query) => get('/ssl-certificates', query) },
    applications: {
      list: (query) => get('/applications', query),
      get: (id) => get(`/applications/${id}`),
      create: (body) => post('/applications', body),
      update: (id, body) => patch(`/applications/${id}`, body),
      remove: (id, query) => del(`/applications/${id}`, query),
      environment: (id) => get(`/applications/${id}/environment`),
      setEnvironment: (id, body) => put(`/applications/${id}/environment`, body),
      deploy: (id) => post(`/applications/${id}/deploy`),
      rollback: (id, body) => post(`/applications/${id}/rollback`, body),
      apply: (id) => post(`/applications/${id}/apply`),
      scale: (id, instances) => post(`/applications/${id}/scale`, { instances }),
      refreshStatus: (id) => post(`/applications/${id}/status`),
      logs: (id, body) => post(`/applications/${id}/logs`, body),
      start: (id) => post(`/applications/${id}/start`),
      stop: (id) => post(`/applications/${id}/stop`),
      restart: (id) => post(`/applications/${id}/restart`),
    },
    deployments: {
      list: (query) => get('/deployments', query),
      get: (id) => get(`/deployments/${id}`),
    },
    databases: {
      list: (query) => get('/databases', query),
      get: (id) => get(`/databases/${id}`),
      create: (body) => post('/databases', body),
      update: (id, body) => patch(`/databases/${id}`, body),
      remove: (id) => del(`/databases/${id}`),
      users: {
        list: (query) => get('/database-users', query),
        create: (body) => post('/database-users', body),
        update: (id, body) => patch(`/database-users/${id}`, body),
        remove: (id) => del(`/database-users/${id}`),
        password: (id) => post(`/database-users/${id}/password`),
      },
    },
    containers: {
      list: (query) => get('/containers', query),
      get: (id) => get(`/containers/${id}`),
      create: (body) => post('/containers', body),
      update: (id, body) => patch(`/containers/${id}`, body),
      remove: (id, query) => del(`/containers/${id}`, query),
      environment: (id) => get(`/containers/${id}/environment`),
      redeploy: (id, body) => post(`/containers/${id}/redeploy`, body),
      start: (id) => post(`/containers/${id}/start`),
      stop: (id) => post(`/containers/${id}/stop`),
      restart: (id) => post(`/containers/${id}/restart`),
      servers: () => get('/containers/servers'),
      // On one server, including containers VaultPanel did not deploy.
      onServer: {
        docker: (serverId) => post(`/containers/servers/${serverId}/docker/status`),
        installDocker: (serverId) => post(`/containers/servers/${serverId}/docker/install`),
        list: (serverId) => post(`/containers/servers/${serverId}/containers/list`),
        logs: (serverId, ref, body) => post(`/containers/servers/${serverId}/containers/${ref}/logs`, body),
        inspect: (serverId, ref) => post(`/containers/servers/${serverId}/containers/${ref}/inspect`),
        act: (serverId, ref, action) => post(`/containers/servers/${serverId}/containers/${ref}/${action}`),
        images: (serverId) => post(`/containers/servers/${serverId}/images/list`),
        pullImage: (serverId, body) => post(`/containers/servers/${serverId}/images/pull`, body),
      },
    },
    backups: {
      list: (query) => get('/backups', query),
      get: (id) => get(`/backups/${id}`),
      create: (body) => post('/backups', body),
      remove: (id) => del(`/backups/${id}`),
      restore: (id, body) => post(`/backups/${id}/restore`, body),
      // Where off-server copies go (S3, SFTP).
      storage: {
        list: () => get('/backup-storage'),
        get: (id) => get(`/backup-storage/${id}`),
        create: (body) => post('/backup-storage', body),
        update: (id, body) => put(`/backup-storage/${id}`, body),
        remove: (id) => del(`/backup-storage/${id}`),
        test: (id, body) => post(`/backup-storage/${id}/test`, body),
      },
      schedules: {
        list: (query) => get('/backup-schedules', query),
        save: (body) => put('/backup-schedules', body),
        remove: (id) => del(`/backup-schedules/${id}`),
      },
    },
    cronJobs: {
      list: (query) => get('/cron-jobs', query),
      get: (id) => get(`/cron-jobs/${id}`),
      create: (body) => post('/cron-jobs', body),
      update: (id, body) => patch(`/cron-jobs/${id}`, body),
      remove: (id) => del(`/cron-jobs/${id}`),
      run: (id) => post(`/cron-jobs/${id}/run`),
      runs: (id, query) => get(`/cron-jobs/${id}/runs`, query),
    },
    webhooks: {
      list: (query) => get('/webhooks', query),
      get: (id) => get(`/webhooks/${id}`),
      create: (body) => post('/webhooks', body),
      update: (id, body) => patch(`/webhooks/${id}`, body),
      remove: (id) => del(`/webhooks/${id}`),
      test: (id) => post(`/webhooks/${id}/test`),
      deliveries: (id, query) => get(`/webhooks/${id}/deliveries`, query),
    },
    alerts: {
      summary: () => get('/alerts/summary'),
      events: (query) => get('/alerts/events', query),
      acknowledge: (id) => post(`/alerts/events/${id}/acknowledge`),
      rules: () => get('/alerts/rules'),
      createRule: (body) => post('/alerts/rules', body),
      updateRule: (id, body) => patch(`/alerts/rules/${id}`, body),
      removeRule: (id) => del(`/alerts/rules/${id}`),
    },
    monitoring: {
      overview: () => get('/monitoring/overview'),
      services: (query) => get('/monitoring/services', query),
    },
    security: {
      overview: () => get('/security/overview'),
      server: (serverId) => get(`/security/servers/${serverId}`),
      setFirewall: (serverId, body) => put(`/security/servers/${serverId}/firewall`, body),
      addFirewallRule: (serverId, body) => post(`/security/servers/${serverId}/firewall/rules`, body),
      removeFirewallRule: (serverId, body) => post(`/security/servers/${serverId}/firewall/rules/delete`, body),
      installUpdates: (serverId) => post(`/security/servers/${serverId}/updates/install`),
    },
    jobs: {
      list: (query) => get('/jobs', query),
      get: (id, query) => get(`/jobs/${id}`, query),
      operations: () => get('/jobs/operations'),
      cancel: (id) => post(`/jobs/${id}/cancel`),
      // Polls until the job finishes. Returns the finished job; throws on a
      // timeout so a script never carries on as if the work had succeeded.
      wait: (id, { timeoutMs = 600_000, intervalMs = 2_000, onProgress } = {}) => panel.waitForJob(id, { timeoutMs, intervalMs, onProgress }),
    },
    users: {
      list: (query) => get('/users', query),
      get: (id) => get(`/users/${id}`),
      invite: (body) => post('/users', body),
      update: (id, body) => patch(`/users/${id}`, body),
      roles: () => get('/roles'),
    },
    auditLog: { list: (query) => get('/audit-logs', query) },
    plugins: {
      list: () => get('/plugins'),
      get: (id) => get(`/plugins/${id}`),
      // Pages the signed-in person may open. Installing, updating and
      // replacing a plugin's credentials are done in the panel.
      pages: () => get('/plugins/pages'),
      preview: (body) => post('/plugins/preview', body),
      enable: (id) => post(`/plugins/${id}/enable`),
      disable: (id) => post(`/plugins/${id}/disable`),
      remove: (id) => del(`/plugins/${id}`),
      deliveries: (id, query) => get(`/plugins/${id}/deliveries`, query),
      test: (id) => post(`/plugins/${id}/test`),
      // Plugin directories. Adding one is done in the panel.
      directory: () => get('/plugins/directory'),
      refreshDirectories: () => post('/plugins/directory/refresh'),
      refreshDirectory: (directoryId) => post(`/plugins/directory/sources/${directoryId}/refresh`),
      removeDirectory: (directoryId) => del(`/plugins/directory/sources/${directoryId}`),
    },
    apiTokens: {
      list: (query) => get('/api-tokens', query),
      // The scopes the panel offers, with what each one allows.
      scopes: () => get('/api-tokens/scopes'),
      // Creating and revoking tokens is done in the panel while signed in; a
      // token cannot mint another one.
      create: (body) => post('/api-tokens', body),
      revoke: (id) => post(`/api-tokens/${id}/revoke`),
    },
    hosting: {
      plans: () => get('/hosting/plans'),
      createPlan: (body) => post('/hosting/plans', body),
      updatePlan: (id, body) => patch(`/hosting/plans/${id}`, body),
      removePlan: (id) => del(`/hosting/plans/${id}`),
      customers: (query) => get('/hosting/customers', query),
      customer: (id) => get(`/hosting/customers/${id}`),
      createCustomer: (body) => post('/hosting/customers', body),
      updateCustomer: (id, body) => patch(`/hosting/customers/${id}`, body),
      changePlan: (id, planId) => post(`/hosting/customers/${id}/plan`, { planId }),
      suspend: (id, reason) => post(`/hosting/customers/${id}/suspend`, reason ? { reason } : {}),
      unsuspend: (id) => post(`/hosting/customers/${id}/unsuspend`),
      terminate: (id) => post(`/hosting/customers/${id}/terminate`),
      me: () => get('/hosting/me'),
    },
    dashboard: () => get('/dashboard'),
    health: () => get('/health'),
  };
}

export { FINAL_JOB_STATUSES };
