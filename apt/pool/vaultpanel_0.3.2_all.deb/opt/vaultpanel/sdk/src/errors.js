// Every failed call throws a VaultPanelError carrying what the panel sent
// back, so a script can branch on `code` instead of parsing messages.
export class VaultPanelError extends Error {
  constructor(message, { status = 0, code = 'REQUEST_FAILED', details = null, requestId = null, cause = null } = {}) {
    super(message);
    this.name = 'VaultPanelError';
    this.status = status;
    this.code = code;
    this.details = details;
    this.requestId = requestId;
    if (cause) this.cause = cause;
  }

  // Field errors from a 422, as { field: message }.
  get fieldErrors() {
    const fields = {};
    for (const item of Array.isArray(this.details) ? this.details : []) {
      if (item?.field) fields[item.field] = item.message;
    }
    return fields;
  }

  get isAuthError() {
    return this.status === 401 || this.status === 403;
  }

  get isValidationError() {
    return this.status === 422;
  }
}
